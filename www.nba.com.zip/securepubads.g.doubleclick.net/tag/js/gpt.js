(function(sttc) {
    var window = this;
    if (window.googletag && googletag.evalScripts) {
        googletag.evalScripts();
    }
    if (window.googletag && googletag._loaded_) return;
    var q, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        ea = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        u = {},
        fa = {},
        v = function(a, b, c) {
            if (!c || a != null) {
                c = fa[b];
                if (c == null) return a[b];
                c = a[c];
                return c !== void 0 ? c : a[b]
            }
        },
        w = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = d.length === 1;
                var e = d[0],
                    f;!a && e in u ? f = u : f = da;
                for (e = 0; e < d.length - 1; e++) {
                    var g = d[e];
                    if (!(g in f)) break a;
                    f = f[g]
                }
                d = d[d.length - 1];c = ea && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ba(u, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (fa[d] === void 0 && (a = Math.random() * 1E9 >>> 0, fa[d] = ea ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, fa[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        },
        ha;
    if (ea && typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
    else {
        var ia;
        a: {
            var ja = {
                    a: !0
                },
                ka = {};
            try {
                ka.__proto__ = ja;
                ia = ka.a;
                break a
            } catch (a) {}
            ia = !1
        }
        ha = ia ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var la = ha,
        x = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (la) la(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Lb = b.prototype
        },
        ma = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        y = function(a) {
            var b = typeof u.Symbol != "undefined" && v(u.Symbol, "iterator") && a[v(u.Symbol, "iterator")];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: ma(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        A = function(a) {
            if (!(a instanceof Array)) {
                a = y(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        oa = function(a) {
            return na(a, a)
        },
        na = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        C = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        pa = ea && typeof v(Object, "assign") == "function" ? v(Object, "assign") : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) C(d, e) && (a[e] = d[e])
            }
            return a
        };
    w("Object.assign", function(a) {
        return a || pa
    }, "es6");
    var qa = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    w("globalThis", function(a) {
        return a || da
    }, "es_2020");
    w("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    w("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, u.Symbol)("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return sa(ma(this))
            }
        });
        return a
    }, "es6");
    var sa = function(a) {
        a = {
            next: a
        };
        a[v(u.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    w("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    }, "es6");
    w("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return h === "object" && g !== null || h === "function"
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (k.get(g) != 2 || k.get(h) != 3) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && k.get(h) == 4
                } catch (m) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = y(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!C(g, d)) {
                var k = new b;
                ba(g, d, {
                    value: k
                })
            }
            if (!C(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && C(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && C(g, d) && C(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && C(g, d) && C(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    w("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !v(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(y([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var m = v(k, "entries").call(k),
                        n = m.next();
                    if (n.done || n.value[0] != h || n.value[1] != "s") return !1;
                    n = m.next();
                    return n.done || n.value[0].x != 4 || n.value[1] != "t" || !m.next().done ? !1 : !0
                } catch (l) {
                    return !1
                }
            }()) return a;
        var b = new u.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = y(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var m = d(this, h);
            m.list || (m.list = this[0][m.id] = []);
            m.entry ? m.entry.value = k : (m.entry = {
                next: this[1],
                H: this[1].H,
                head: this[1],
                key: h,
                value: k
            }, m.list.push(m.entry), this[1].H.next = m.entry, this[1].H = m.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.H.next = h.entry.next, h.entry.next.H = h.entry.H, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].H = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var m = v(this, "entries").call(this), n; !(n = m.next()).done;) n = n.value, h.call(k, n[1], n[0], this)
        };
        c.prototype[v(u.Symbol, "iterator")] = v(c.prototype, "entries");
        var d = function(h, k) {
                var m = k && typeof k;
                m == "object" || m == "function" ? b.has(k) ? m = b.get(k) : (m = "" + ++g, b.set(k, m)) : m = "p_" + k;
                var n = h[0][m];
                if (n && C(h[0], m))
                    for (h = 0; h < n.length; h++) {
                        var l = n[h];
                        if (k !== k && l.key !== l.key || k === l.key) return {
                            id: m,
                            list: n,
                            index: h,
                            entry: l
                        }
                    }
                return {
                    id: m,
                    list: n,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var m = h[1];
                return sa(function() {
                    if (m) {
                        for (; m.head != h[1];) m = m.H;
                        for (; m.next != m.head;) return m = m.next, {
                            done: !1,
                            value: k(m)
                        };
                        m = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.H = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    w("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !v(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(y([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = v(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new u.Map;
            if (c) {
                c = y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return v(this.g, "entries").call(this.g)
        };
        b.prototype.values = function() {
            return v(this.g, "values").call(this.g)
        };
        b.prototype.keys = v(b.prototype, "values");
        b.prototype[v(u.Symbol, "iterator")] = v(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    w("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) C(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    w("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    w("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || v(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    var ta = function(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    w("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return ta(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    }, "es6");
    w("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof u.Symbol != "undefined" && v(u.Symbol, "iterator") && b[v(u.Symbol, "iterator")];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    w("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) C(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    w("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    }, "es6");
    w("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    w("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    }, "es6");
    w("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return v(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    w("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return v(Number, "isInteger").call(Number, b) && Math.abs(b) <= v(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    w("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ta(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    var ua = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[v(u.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    w("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ua(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    w("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    }, "es6");
    w("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    }, "es6");
    w("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ua(this, function(b) {
                return b
            })
        }
    }, "es6");
    w("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ua(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    w("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = ta(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    w("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = ta(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? v(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var D = this || self,
        wa = function(a, b) {
            var c = va("CLOSURE_FLAGS");
            a = c && c[a];
            return a != null ? a : b
        },
        va = function(a) {
            a = a.split(".");
            for (var b = D, c = 0; c < a.length; c++)
                if (b = b[a[c]], b == null) return null;
            return b
        },
        xa = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        ya = function(a, b, c) {
            a = a.split(".");
            c = c || D;
            for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };

    function za(a) {
        D.setTimeout(function() {
            throw a;
        }, 0)
    };
    var Aa = function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };

    function Ba(a, b) {
        var c = 0;
        a = Aa(String(a)).split(".");
        b = Aa(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
            var f = a[e] || "",
                g = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                if (f[0].length == 0 && g[0].length == 0) break;
                c = Ca(f[1].length == 0 ? 0 : parseInt(f[1], 10), g[1].length == 0 ? 0 : parseInt(g[1], 10)) || Ca(f[2].length == 0, g[2].length == 0) || Ca(f[2], g[2]);
                f = f[3];
                g = g[3]
            } while (c == 0)
        }
        return c
    }

    function Ca(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var Da = wa(610401301, !1),
        Ea = wa(748402147, !0),
        Fa = wa(824656860, wa(1, !0));
    var Ga, Ha = D.navigator;
    Ga = Ha ? Ha.userAgentData || null : null;

    function Ia(a) {
        if (!Da || !Ga) return !1;
        for (var b = 0; b < Ga.brands.length; b++) {
            var c = Ga.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function E(a) {
        var b;
        a: {
            if (b = D.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return b.indexOf(a) != -1
    };

    function Ja() {
        return Da ? !!Ga && Ga.brands.length > 0 : !1
    }

    function Ka() {
        return Ja() ? !1 : E("Opera")
    }

    function La() {
        return E("Firefox") || E("FxiOS")
    }

    function Ma() {
        return E("Safari") && !(Na() || (Ja() ? 0 : E("Coast")) || Ka() || (Ja() ? 0 : E("Edge")) || (Ja() ? Ia("Microsoft Edge") : E("Edg/")) || (Ja() ? Ia("Opera") : E("OPR")) || La() || E("Silk") || E("Android"))
    }

    function Na() {
        return Ja() ? Ia("Chromium") : (E("Chrome") || E("CriOS")) && !(Ja() ? 0 : E("Edge")) || E("Silk")
    };
    var Oa = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };

    function Pa(a, b) {
        a: {
            for (var c = typeof a === "string" ? a.split("") : a, d = a.length - 1; d >= 0; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    };
    var Qa = function(a) {
        Qa[" "](a);
        return a
    };
    Qa[" "] = function() {};
    var Ra = null;

    function Sa(a) {
        var b = [];
        Ta(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Ta(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var m = a.charAt(d++),
                    n = Ra[m];
                if (n != null) return n;
                if (!/^[\s\xa0]*$/.test(m)) throw Error("Unknown base64 encoding at char: " + m);
            }
            return k
        }
        Ua();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Ua() {
        if (!Ra) {
            Ra = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++)
                for (var d = a.concat(b[c].split("")), e = 0; e < d.length; e++) {
                    var f = d[e];
                    Ra[f] === void 0 && (Ra[f] = e)
                }
        }
    };

    function Va(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Wa = void 0,
        Xa;

    function Ya(a) {
        if (Xa) throw Error("");
        Xa = function(b) {
            D.setTimeout(function() {
                a(b)
            }, 0)
        }
    }

    function Za(a) {
        if (Xa) try {
            Xa(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function $a(a) {
        a = Error(a);
        Va(a, "warning");
        Za(a);
        return a
    };

    function ab() {
        return typeof BigInt === "function"
    };
    var db = typeof u.Symbol === "function" && typeof(0, u.Symbol)() === "symbol";

    function eb(a, b, c) {
        return typeof u.Symbol === "function" && typeof(0, u.Symbol)() === "symbol" ? (c === void 0 ? 0 : c) && u.Symbol.for && a ? u.Symbol.for(a) : a != null ? (0, u.Symbol)(a) : (0, u.Symbol)() : b
    }
    var fb = eb("jas", void 0, !0),
        gb = eb(void 0, "0di"),
        hb = eb(void 0, "1oa"),
        ib = eb(void 0, "0actk"),
        jb = eb("m_m", "Kb", !0);
    var kb = {
            eb: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        lb = Object.defineProperties,
        F = db ? fb : "eb",
        mb, nb = [];
    G(nb, 7);
    mb = Object.freeze(nb);

    function ob(a, b) {
        db || F in a || lb(a, kb);
        a[F] |= b
    }

    function G(a, b) {
        db || F in a || lb(a, kb);
        a[F] = b
    }

    function pb(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function qb(a) {
        ob(a, 32);
        return a
    };
    var rb = {};

    function H(a, b) {
        return b === void 0 ? a.g !== sb && !!(2 & (a.i[F] | 0)) : !!(2 & b) && a.g !== sb
    }
    var sb = {};

    function tb(a, b) {
        if (typeof b !== "number" || b < 0 || b >= a.length) throw Error();
    }
    var ub = Object.freeze({}),
        vb = Object.freeze({});

    function wb(a) {
        var b = xb;
        if (!a) throw Error((typeof b === "function" ? b() : b) || String(a));
    }

    function yb(a) {
        a.Jb = !0;
        return a
    }
    var xb = void 0;
    var zb = yb(function(a) {
            return typeof a === "number"
        }),
        Ab = yb(function(a) {
            return typeof a === "string"
        }),
        Bb = yb(function(a) {
            return typeof a === "boolean"
        });
    var Cb = typeof D.BigInt === "function" && typeof D.BigInt(0) === "bigint";

    function Db(a) {
        var b = a;
        if (Ab(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
        } else if (zb(b) && !v(Number, "isSafeInteger").call(Number, b)) throw Error(String(b));
        return Cb ? BigInt(a) : a = Bb(a) ? a ? "1" : "0" : Ab(a) ? a.trim() || "0" : String(a)
    }
    var Jb = yb(function(a) {
            return Cb ? a >= Eb && a <= Fb : a[0] === "-" ? Gb(a, Hb) : Gb(a, Ib)
        }),
        Hb = v(Number, "MIN_SAFE_INTEGER").toString(),
        Eb = Cb ? BigInt(v(Number, "MIN_SAFE_INTEGER")) : void 0,
        Ib = v(Number, "MAX_SAFE_INTEGER").toString(),
        Fb = Cb ? BigInt(v(Number, "MAX_SAFE_INTEGER")) : void 0;

    function Gb(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var I = 0,
        J = 0;

    function Kb(a) {
        var b = a >>> 0;
        I = b;
        J = (a - b) / 4294967296 >>> 0
    }

    function Lb(a) {
        if (a < 0) {
            Kb(-a);
            var b = y(Mb(I, J));
            a = b.next().value;
            b = b.next().value;
            I = a >>> 0;
            J = b >>> 0
        } else Kb(a)
    }

    function Nb(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else ab() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + Ob(c) + Ob(a));
        return c
    }

    function Ob(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function Pb() {
        var a = I,
            b = J;
        b & 2147483648 ? ab() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = y(Mb(a, b)), a = b.next().value, b = b.next().value, a = "-" + Nb(a, b)) : a = Nb(a, b);
        return a
    }

    function Mb(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function Qb(a) {
        return Array.prototype.slice.call(a)
    };

    function Rb(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    var Sb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Tb = v(Number, "isSafeInteger"),
        Ub = v(Number, "isFinite"),
        Vb = v(Math, "trunc");

    function Wb(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Xb(a) {
        if (typeof a !== "boolean") throw Error("Expected boolean but got " + xa(a) + ": " + a);
        return a
    }
    var Yb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Zb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Ub(a);
            case "string":
                return Yb.test(a);
            default:
                return !1
        }
    }

    function $b(a) {
        if (!Ub(a)) throw $a("enum");
        return a | 0
    }

    function ac(a) {
        return a == null ? a : Ub(a) ? a | 0 : void 0
    }

    function bc(a) {
        if (typeof a !== "number") throw $a("int32");
        if (!Ub(a)) throw $a("int32");
        return a | 0
    }

    function cc(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Ub(a) ? a | 0 : void 0
    }

    function dc(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Ub(a) ? a >>> 0 : void 0
    }

    function ec(a) {
        var b = void 0;
        b != null || (b = Fa ? 1024 : 0);
        if (!Zb(a)) throw $a("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return fc(a);
                    case "bigint":
                        return String(Sb(64, a));
                    default:
                        return hc(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return ic(a);
                    case "bigint":
                        return Db(Sb(64, a));
                    default:
                        return jc(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return fc(a);
                    case "bigint":
                        return Db(Sb(64, a));
                    default:
                        return kc(a)
                }
            default:
                return Rb(b, "Unknown format requested type for int64")
        }
    }

    function lc(a) {
        var b = a.length;
        if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
        if (a.length < 16) Lb(Number(a));
        else if (ab()) a = BigInt(a), I = Number(a & BigInt(4294967295)) >>> 0, J = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            b = +(a[0] === "-");
            J = I = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), J *= 1E6, I = I * 1E6 + d, I >= 4294967296 && (J += v(Math, "trunc").call(Math, I / 4294967296), J >>>= 0, I >>>= 0);
            b && (b = y(Mb(I, J)), a = b.next().value, b = b.next().value, I = a, J = b)
        }
        return Pb()
    }

    function kc(a) {
        a = Vb(a);
        if (!Tb(a)) {
            Lb(a);
            var b = I,
                c = J;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            var d = c * 4294967296 + (b >>> 0);
            b = v(Number, "isSafeInteger").call(Number, d) ? d : Nb(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function hc(a) {
        a = Vb(a);
        Tb(a) ? a = String(a) : (Lb(a), a = Pb());
        return a
    }

    function fc(a) {
        var b = Vb(Number(a));
        if (Tb(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return lc(a)
    }

    function ic(a) {
        var b = Vb(Number(a));
        if (Tb(b)) return Db(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return ab() ? Db(Sb(64, BigInt(a))) : Db(lc(a))
    }

    function jc(a) {
        return Tb(a) ? Db(kc(a)) : Db(hc(a))
    }

    function mc(a, b) {
        b = b === void 0 ? !1 : b;
        var c = typeof a;
        if (a == null) return a;
        if (c === "bigint") return String(Sb(64, a));
        if (Zb(a)) return c === "string" ? fc(a) : b ? hc(a) : kc(a)
    }

    function nc(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Db(Sb(64, a));
        if (Zb(a)) return b === "string" ? ic(a) : jc(a)
    }

    function oc(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function pc(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function qc(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function rc(a, b, c, d) {
        if (a != null && a[jb] === rb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[gb] || (b[gb] = sc(b)) : new b : void 0;
        c = a[F] | 0;
        d = c | d & 32 | d & 2;
        d !== c && G(a, d);
        return new b(a)
    }

    function sc(a) {
        a = new a;
        ob(a.i, 34);
        return a
    };

    function tc(a) {
        return a
    };

    function uc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            m = !!(b & 64),
            n = m ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var l = g && a[g - 1];
            l != null && typeof l === "object" && l.constructor === Object ? (g--, h = g) : l = void 0;
            if (m && !(b & 128) && !e) {
                k = !0;
                var p;
                h = ((p = vc) != null ? p : tc)(h - n, n, a, l, void 0) + n
            }
        }
        b = void 0;
        for (e = 0; e < g; e++)
            if (p = a[e], p != null && (p = c(p, d)) != null)
                if (m && e >= h) {
                    var r = e - n,
                        t = void 0;
                    ((t = b) != null ? t : b = {})[r] = p
                } else f[e] = p;
        if (l)
            for (var z in l) Object.prototype.hasOwnProperty.call(l, z) && (a = l[z], a != null && (a = c(a, d)) != null && (g = +z, e = void 0, m && !v(Number, "isNaN").call(Number, g) && (e = g + n) < h ? f[e] = a : (g = void 0, ((g = b) != null ? g : b = {})[z] = a)));
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function wc(a) {
        switch (typeof a) {
            case "number":
                return v(Number, "isFinite").call(Number, a) ? a : "" + a;
            case "bigint":
                return Jb(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    var b = a[F] | 0;
                    return a.length === 0 && b & 1 ? void 0 : uc(a, b, wc)
                }
                if (a != null && a[jb] === rb) return K(a);
                return
        }
        return a
    }
    var xc = typeof structuredClone != "undefined" ? structuredClone : function(a) {
            return uc(a, 0, wc)
        },
        vc;

    function K(a) {
        a = a.i;
        return uc(a, a[F] | 0, wc)
    };

    function L(a, b, c) {
        return yc(a, b, c, 2048)
    }

    function yc(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[F] | 0;
            if (Ea && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && zc();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && G(a, e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1,
                        h = c[g];
                    if (h != null && typeof h === "object" && h.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var k in h) Object.prototype.hasOwnProperty.call(h, k) && (f = +k, f < g && (c[f + b] = h[k], delete h[k]));
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (k > 1024) throw Error("spvt");
                    e = e & -16760833 | (k & 1023) << 14
                }
            }
        }
        G(a, e | 64 | d);
        return a
    }

    function zc() {
        if (Ea) throw Error("carr");
        if (ib != null) {
            var a;
            var b = (a = Wa) != null ? a : Wa = {};
            a = b[ib] || 0;
            a >= 5 || (b[ib] = a + 1, b = Error(), Va(b, "incident"), Xa ? Za(b) : za(b))
        }
    };

    function Ac(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[F] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = Bc(a, c, !1, b && !(c & 16)) : (ob(a, 34), c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[jb] === rb) return b = a.i, c = b[F] | 0, H(a, c) ? a : Cc(a, b, c) ? Dc(a, b) : Bc(b, c)
    }

    function Dc(a, b, c) {
        a = new a.constructor(b);
        c && (a.g = sb);
        a.j = sb;
        return a
    }

    function Bc(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = uc(a, b, Ac, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        G(a, b);
        return a
    }

    function Ec(a) {
        var b = a.i,
            c = b[F] | 0;
        return H(a, c) ? Cc(a, b, c) ? Dc(a, b, !0) : new a.constructor(Bc(b, c, !1)) : a
    }

    function Fc(a) {
        var b = a.i,
            c = b[F] | 0;
        return H(a, c) ? a : Cc(a, b, c) ? Dc(a, b) : new a.constructor(Bc(b, c, !0))
    }

    function Gc(a) {
        if (a.g !== sb) return !1;
        var b = a.i;
        b = Bc(b, b[F] | 0);
        ob(b, 2048);
        a.i = b;
        a.g = void 0;
        a.j = void 0;
        return !0
    }

    function Hc(a) {
        if (!Gc(a) && H(a, a.i[F] | 0)) throw Error();
    }

    function Ic(a, b) {
        b === void 0 && (b = a[F] | 0);
        b & 32 && !(b & 4096) && G(a, b | 4096)
    }

    function Cc(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (G(b, c | 2), a.g = sb, !0) : !1
    };
    var Jc = Db(0),
        M = function(a, b, c, d) {
            a = Kc(a.i, b, c, d);
            if (a !== null) return a
        },
        Kc = function(a, b, c, d) {
            if (b === -1) return null;
            var e = b + (c ? 0 : -1),
                f = a.length - 1;
            if (!(f < 1 + (c ? 0 : -1))) {
                if (e >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        c = g[b];
                        var h = !0
                    } else if (e === f) c = g;
                    else return
                } else c = a[e];
                if (d && c != null) {
                    d = d(c);
                    if (d == null) return d;
                    if (!v(Object, "is").call(Object, d, c)) return h ? g[b] = d : a[e] = d, d
                }
                return c
            }
        },
        O = function(a, b, c) {
            Hc(a);
            var d = a.i;
            N(d, d[F] | 0, b, c);
            return a
        };

    function N(a, b, c, d) {
        var e = c + -1,
            f = a.length - 1;
        if (f >= 0 && e >= f) {
            var g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        if (d !== void 0) {
            var h;
            f = ((h = b) != null ? h : b = a[F] | 0) >> 14 & 1023 || 536870912;
            c >= f ? d != null && (e = {}, a[f + -1] = (e[c] = d, e)) : a[e] = d
        }
        return b
    }
    var Mc = function(a, b, c) {
            a = a.i;
            return Lc(a, a[F] | 0, b, c) !== void 0
        },
        P = function(a) {
            return a === ub ? 2 : 4
        };

    function Nc(a, b, c, d, e) {
        var f = a.i,
            g = f[F] | 0;
        d = H(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && Gc(a) && (f = a.i, g = f[F] | 0);
        a = Kc(f, b);
        a = Array.isArray(a) ? a : mb;
        var h = a === mb ? 7 : a[F] | 0,
            k = Oc(h, g);
        var m = 4 & k ? !1 : !0;
        if (m) {
            4 & k && (a = Qb(a), h = 0, k = Pc(k, g), g = N(f, g, b, a));
            for (var n = 0, l = 0; n < a.length; n++) {
                var p = c(a[n]);
                p != null && (a[l++] = p)
            }
            l < n && (a.length = l);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (G(a, k), 2 & k && Object.freeze(a));
        return a = Qc(a, k, f, g, b, d, m, e)
    }

    function Qc(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Rc(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && G(a, b), Object.freeze(a)) : (f === 2 && Rc(b) && (a = Qb(a), k = 0, b = Pc(b, d), d = N(c, d, e, a)), Rc(b) || (h || (b |= 16), b !== k && G(a, b)));
        2 & b || !(4096 & b || 16 & b) || Ic(c, d);
        return a
    }

    function Oc(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Rc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Sc(a, b, c, d) {
        Hc(a);
        var e = a.i,
            f = e[F] | 0;
        if (c == null) return N(e, f, b), a;
        var g = c === mb ? 7 : c[F] | 0,
            h = g,
            k = Rc(g),
            m = k || Object.isFrozen(c);
        k || (g = 0);
        m || (c = Qb(c), h = 0, g = Pc(g, f), m = !1);
        g |= 5;
        var n;
        k = (n = pb(g)) != null ? n : Fa ? 1024 : 0;
        g |= k;
        for (n = 0; n < c.length; n++) {
            var l = c[n],
                p = d(l, k);
            v(Object, "is").call(Object, l, p) || (m && (c = Qb(c), h = 0, g = Pc(g, f), m = !1), c[n] = p)
        }
        g !== h && (m && (c = Qb(c), g = Pc(g, f)), G(c, g));
        N(e, f, b, c);
        return a
    }

    function Tc(a, b, c, d) {
        Hc(a);
        var e = a.i;
        N(e, e[F] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }
    var Xc = function(a, b, c, d) {
            Hc(a);
            var e = a.i,
                f = e[F] | 0;
            if (d == null) {
                var g = Uc(e);
                if (Vc(g, e, f, c) === b) g.set(c, 0);
                else return a
            } else f = Wc(e, f, c, b);
            N(e, f, b, d);
            return a
        },
        Zc = function(a, b, c) {
            return Yc(a, b) === c ? c : -1
        },
        Yc = function(a, b) {
            a = a.i;
            return Vc(Uc(a), a, void 0, b)
        };

    function Uc(a) {
        if (db) {
            var b;
            return (b = a[hb]) != null ? b : a[hb] = new u.Map
        }
        if (hb in a) return a[hb];
        b = new u.Map;
        Object.defineProperty(a, hb, {
            value: b
        });
        return b
    }

    function Wc(a, b, c, d) {
        var e = Uc(a),
            f = Vc(e, a, b, c);
        f !== d && (f && (b = N(a, b, f)), e.set(c, d));
        return b
    }

    function Vc(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        for (var f = e = 0; f < d.length; f++) {
            var g = d[f];
            Kc(b, g) != null && (e !== 0 && (c = N(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }
    var $c = function(a, b, c) {
        Hc(a);
        a = a.i;
        var d = a[F] | 0,
            e = Kc(a, c),
            f = void 0 === vb;
        b = rc(e, b, !f, d);
        if (!f || b) return b = Ec(b), e !== b && (d = N(a, d, c, b), Ic(a, d)), b
    };

    function Lc(a, b, c, d) {
        var e = !1;
        d = Kc(a, d, void 0, function(f) {
            var g = rc(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !H(d) && Ic(a, b), d
    }
    var ad = function(a, b, c) {
            a = a.i;
            return Lc(a, a[F] | 0, b, c) || b[gb] || (b[gb] = sc(b))
        },
        Q = function(a, b, c) {
            var d = a.i,
                e = d[F] | 0;
            b = Lc(d, e, b, c);
            if (b == null) return b;
            e = d[F] | 0;
            if (!H(a, e)) {
                var f = Ec(b);
                f !== b && (Gc(a) && (d = a.i, e = d[F] | 0), b = f, e = N(d, e, c, b), Ic(d, e))
            }
            return b
        };

    function bd(a, b, c, d, e, f, g, h) {
        var k = H(a, c);
        f = k ? 1 : f;
        g = !!g || f === 3;
        k = h && !k;
        (f === 2 || k) && Gc(a) && (b = a.i, c = b[F] | 0);
        a = Kc(b, e);
        a = Array.isArray(a) ? a : mb;
        var m = a === mb ? 7 : a[F] | 0,
            n = Oc(m, c);
        if (h = !(4 & n)) {
            var l = a,
                p = c,
                r = !!(2 & n);
            r && (p |= 2);
            for (var t = !r, z = !0, B = 0, ra = 0; B < l.length; B++) {
                var bb = rc(l[B], d, !1, p);
                if (bb instanceof d) {
                    if (!r) {
                        var cb = H(bb);
                        t && (t = !cb);
                        z && (z = cb)
                    }
                    l[ra++] = bb
                }
            }
            ra < B && (l.length = ra);
            n |= 4;
            n = z ? n & -4097 : n | 4096;
            n = t ? n | 8 : n & -9
        }
        n !== m && (G(a, n), 2 & n && Object.freeze(a));
        if (k && !(8 & n || !a.length && (f === 1 || (f !== 4 ? 0 : 2 & n || !(16 & n) && 32 & c)))) {
            Rc(n) && (a = Qb(a), n = Pc(n, c), c = N(b, c, e, a));
            d = a;
            k = n;
            for (m = 0; m < d.length; m++) l = d[m], n = Ec(l), l !== n && (d[m] = n);
            k |= 8;
            n = k = d.length ? k | 4096 : k & -4097;
            G(a, n)
        }
        return a = Qc(a, n, b, c, e, f, h, g)
    }
    var R = function(a, b, c, d) {
        var e = a.i;
        return bd(a, e, e[F] | 0, b, c, d, !1, !0)
    };

    function cd(a) {
        a == null && (a = void 0);
        return a
    }
    var dd = function(a, b, c) {
            c = cd(c);
            O(a, b, c);
            c && !H(c) && Ic(a.i);
            return a
        },
        ed = function(a, b, c, d) {
            d = cd(d);
            Xc(a, b, c, d);
            d && !H(d) && Ic(a.i);
            return a
        },
        fd = function(a, b, c) {
            Hc(a);
            var d = a.i,
                e = d[F] | 0;
            if (c == null) return N(d, e, b), a;
            for (var f = c === mb ? 7 : c[F] | 0, g = f, h = Rc(f), k = h || Object.isFrozen(c), m = !0, n = !0, l = 0; l < c.length; l++) {
                var p = c[l];
                h || (p = H(p), m && (m = !p), n && (n = p))
            }
            h || (f = m ? 13 : 5, f = n ? f & -4097 : f | 4096);
            k && f === g || (c = Qb(c), g = 0, f = Pc(f, e));
            f !== g && G(c, f);
            e = N(d, e, b, c);
            2 & f || !(4096 & f || 16 & f) || Ic(d, e);
            return a
        };

    function Pc(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function gd(a, b) {
        Hc(a);
        a = Nc(a, 4, qc, 2, !0);
        var c, d = (c = pb(a === mb ? 7 : a[F] | 0)) != null ? c : Fa ? 1024 : 0;
        if (Array.isArray(b)) {
            c = b.length;
            for (var e = 0; e < c; e++) a.push(oc(b[e], d))
        } else
            for (b = y(b), c = b.next(); !c.done; c = b.next()) a.push(oc(c.value, d))
    }
    var hd = function(a, b) {
            var c = c === void 0 ? !1 : c;
            a = M(a, b);
            a = a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0;
            return a != null ? a : c
        },
        id = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = cc(M(a, b));
            return a != null ? a : c
        },
        jd = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = dc(M(a, b));
            return a != null ? a : c
        },
        kd = function(a, b) {
            var c = c === void 0 ? Jc : c;
            a = Fa ? M(a, b, void 0, nc) : nc(M(a, b));
            return a != null ? a : c
        },
        ld = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = M(a, b, void 0, Wb);
            return a != null ? a : c
        },
        S = function(a, b) {
            var c = c === void 0 ? "" : c;
            var d;
            return (d = qc(M(a, b))) != null ? d : c
        },
        T = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = ac(M(a, b));
            return a != null ? a : c
        },
        md = function(a, b, c) {
            a = Nc(a, b, cc, 3, !0);
            tb(a, c);
            return a[c]
        },
        nd = function(a, b, c) {
            return T(a, Zc(a, c, b))
        },
        od = function(a, b, c) {
            return Tc(a, b, c == null ? c : bc(c), 0)
        },
        pd = function(a, b, c) {
            return Tc(a, b, c == null ? c : ec(c), "0")
        },
        qd = function(a, b, c) {
            return Xc(a, 2, b, c == null ? c : ec(c))
        },
        rd = function(a, b, c) {
            return Tc(a, b, pc(c), "")
        },
        sd = function(a, b, c) {
            return O(a, b, c == null ? c : $b(c))
        },
        td = function(a, b, c) {
            return Tc(a, b, c == null ? c : $b(c), 0)
        },
        ud = function(a, b, c, d) {
            return Xc(a, b, c, d == null ? d : $b(d))
        };
    var U = function(a, b, c) {
        this.i = L(a, b, c)
    };
    U.prototype.toJSON = function() {
        return K(this)
    };
    var vd = function(a) {
        return Fc(a)
    };
    U.prototype[jb] = rb;

    function wd(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(qb(b))
    };

    function xd(a) {
        return function(b) {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(qb(b))
            }
            return b
        }
    };
    var yd = function(a) {
        this.i = L(a)
    };
    x(yd, U);
    var zd = function(a) {
        return S(a, 1)
    };
    var Ad = function(a) {
        this.i = L(a)
    };
    x(Ad, U);

    function Bd(a) {
        var b = b === void 0 ? !1 : b;
        var c = c === void 0 ? D : c;
        for (var d = 0; c && d++ < 40;) {
            var e;
            if (!(e = b)) try {
                var f;
                if (f = !!c && c.location.href != null) b: {
                    try {
                        Qa(c.foo);
                        f = !0;
                        break b
                    } catch (h) {}
                    f = !1
                }
                e = f
            } catch (h) {
                e = !1
            }
            if (e && a(c)) break;
            a: {
                try {
                    var g = c.parent;
                    if (g && g != c) {
                        c = g;
                        break a
                    }
                } catch (h) {}
                c = null
            }
        }
    }

    function Cd(a) {
        var b = a;
        Bd(function(c) {
            b = c;
            return !1
        });
        return b
    };
    var Dd = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };

    function Ed() {
        return Da && Ga ? !Ga.mobile && (E("iPad") || E("Android") || E("Silk")) : E("iPad") || E("Android") && !E("Mobile") || E("Silk")
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Fd;

    function Gd() {
        Fd === void 0 && (Fd = null);
        return Fd
    };
    var Hd = function(a) {
        this.g = a
    };
    Hd.prototype.toString = function() {
        return this.g + ""
    };

    function Id(a) {
        var b = Gd();
        a = b ? b.createScriptURL(a) : a;
        return new Hd(a)
    }

    function Jd(a) {
        if (a instanceof Hd) return a.g;
        throw Error("");
    };
    var Kd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    var Ld = function(a) {
        this.g = a
    };
    Ld.prototype.toString = function() {
        return this.g + ""
    };

    function Md(a) {
        a = a === void 0 ? document : a;
        var b, c;
        a = (c = (b = a).querySelector) == null ? void 0 : c.call(b, "script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function Nd(a, b) {
        a.src = Jd(b);
        (b = Md(a.ownerDocument)) && a.setAttribute("nonce", b)
    };
    var Od = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Pd(a, b) {
        var c = a.write;
        if (b instanceof Ld) b = b.g;
        else throw Error("");
        c.call(a, b)
    };
    var Qd = Dd(function() {
        return (Da && Ga ? Ga.mobile : !Ed() && (E("iPod") || E("iPhone") || E("Android") || E("IEMobile"))) ? 2 : Ed() ? 1 : 0
    });

    function Rd(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Sd() {
        if (!u.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            u.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    var Td, Ud = 64;

    function Vd() {
        try {
            return Td != null || (Td = new Uint32Array(64)), Ud >= 64 && (crypto.getRandomValues(Td), Ud = 0), Td[Ud++]
        } catch (a) {
            return Math.floor(Math.random() * 4294967296)
        }
    };

    function Wd(a, b) {
        if (!zb(a.goog_pvsid)) try {
            var c = Vd() + (Vd() & 2097151) * 4294967296;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (d) {
            b.G({
                methodName: 784,
                I: d
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.G({
            methodName: 784,
            I: Error("Invalid correlator, " + a)
        });
        return a || -1
    };

    function Xd(a, b) {
        a = Jd(a).toString();
        a = '<script src="' + Yd(a) + '"';
        if (b == null ? 0 : b.async) a += " async";
        (b == null ? void 0 : b.attributionSrc) !== void 0 && (a += ' attributionsrc="' + Yd(b.attributionSrc) + '"');
        if (b == null ? 0 : b.Va) a += ' custom-element="' + Yd(b.Va) + '"';
        if (b == null ? 0 : b.defer) a += " defer";
        if (b == null ? 0 : b.id) a += ' id="' + Yd(b.id) + '"';
        if (b == null ? 0 : b.nonce) a += ' nonce="' + Yd(b.nonce) + '"';
        if (b == null ? 0 : b.type) a += ' type="' + Yd(b.type) + '"';
        if (b == null ? 0 : b.Ha) a += ' crossorigin="' + Yd(b.Ha) + '"';
        b = a + ">\x3c/script>";
        b = (a = Gd()) ? a.createHTML(b) : b;
        return new Ld(b)
    }

    function Yd(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    };

    function Zd(a) {
        var b = qa.apply(1, arguments);
        if (b.length === 0) return Id(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Id(c)
    }

    function $d(a, b) {
        a = Jd(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return ae(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function ae(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(function(k) {
                return e(k, h)
            }) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = v(Object, "entries").call(Object, d));
        Array.isArray(d) ? d.forEach(function(g) {
            return e(g[1], g[0])
        }) : d.forEach(e);
        return Id(a + b + c)
    };

    function be(a, b) {
        if (a.length && b.head) {
            a = y(a);
            for (var c = a.next(); !c.done; c = a.next())
                if ((c = c.value) && b.head) {
                    var d = ce("META");
                    b.head.appendChild(d);
                    d.httpEquiv = "origin-trial";
                    d.content = c
                }
        }
    }
    var de = function(a) {
            return Wd(a, {
                G: function() {}
            })
        },
        ce = function(a, b) {
            b = b === void 0 ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function ee(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    var fe = {
        Eb: 0,
        Db: 1,
        Ab: 2,
        ub: 3,
        Bb: 4,
        wb: 5,
        Cb: 6,
        yb: 7,
        zb: 8,
        tb: 9,
        xb: 10,
        Fb: 11
    };
    var ge = {
        Hb: 0,
        Ib: 1,
        Gb: 2
    };
    var he = function(a) {
        this.i = L(a)
    };
    x(he, U);
    he.prototype.getVersion = function() {
        return id(this, 2)
    };

    function ie(a) {
        return Sa(a.length % 4 !== 0 ? a + "A" : a).map(function(b) {
            return (q = b.toString(2), v(q, "padStart")).call(q, 8, "0")
        }).join("")
    }

    function je(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    }

    function ke(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function le(a) {
        var b = ie(a),
            c = je(b.slice(0, 6));
        a = je(b.slice(6, 12));
        var d = new he;
        c = od(d, 1, c);
        a = od(c, 2, a);
        b = b.slice(12);
        c = je(b.slice(0, 12));
        d = [];
        for (var e = b.slice(12).replace(/0+$/, ""), f = 0; f < c; f++) {
            if (e.length === 0) throw Error("Found " + f + " of " + c + " sections [" + d + "] but reached end of input [" + b + "]");
            var g = je(e[0]) === 0;
            e = e.slice(1);
            var h = me(e, b),
                k = d.length === 0 ? 0 : d[d.length - 1];
            k = ke(h) + k;
            e = e.slice(h.length);
            if (g) d.push(k);
            else {
                g = me(e, b);
                h = ke(g);
                for (var m = 0; m <= h; m++) d.push(k + m);
                e = e.slice(g.length)
            }
        }
        if (e.length > 0) throw Error("Found " + c + " sections [" + d + "] but has remaining input [" + e + "], entire input [" + b + "]");
        return Sc(a, 3, d, bc)
    }

    function me(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    var ne = ee(fe).map(function(a) {
            return Number(a)
        }),
        oe = ee(ge).map(function(a) {
            return Number(a)
        });
    var pe = function(a) {
        this.i = L(a)
    };
    x(pe, U);
    var qe = function() {
            var a = new pe;
            return pd(a, 1, 0)
        },
        re = function(a) {
            var b = Number;
            var c = c === void 0 ? "0" : c;
            var d = Fa ? mc(M(a, 1, void 0, nc)) : mc(M(a, 1), !0);
            b = b(d != null ? d : c);
            a = id(a, 2);
            return new Date(b * 1E3 + a / 1E6)
        };

    function se(a) {
        if (a != null) return te(a)
    }

    function te(a) {
        return Jb(a) ? Number(a) : String(a)
    };
    var ue = function(a) {
            this.j = a;
            this.g = 0;
            if (/[^01]/.test(this.j)) throw Error("Input bitstring " + this.j + " is malformed!");
        },
        ve = function(a) {
            var b = function() {
                var c = V(a, 6);
                if (c > 25 || c < 0) throw Error("Invalid character code, expected in range [0,25], got: " + c);
                return String.fromCharCode(97 + c)
            };
            return b() + b()
        },
        ye = function(a) {
            var b = V(a, 16);
            if (!!V(a, 1) === !0) {
                a = we(a);
                for (var c = y(a), d = c.next(); !d.done; d = c.next())
                    if (d = d.value, d > b) throw Error("ID " + d + " is past MaxVendorId " + b + "!");
                return a
            }
            return xe(a, b)
        },
        we = function(a) {
            for (var b = V(a, 12), c = []; b--;) {
                var d = !!V(a, 1) === !0,
                    e = V(a, 16);
                if (d)
                    for (d = V(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        xe = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (V(a, 1)) {
                    var f = e + 1;
                    if (c && c.indexOf(f) === -1) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        V = function(a, b) {
            if (a.g + b > a.j.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.j.substring(a.g, a.g + b);
            a.g += b;
            return parseInt(c, 2)
        };
    ue.prototype.skip = function(a) {
        this.g += a
    };

    function ze(a) {
        try {
            var b = a.split("."),
                c = Sa(b[0]).map(function(f) {
                    return (q = f.toString(2), v(q, "padStart")).call(q, 8, "0")
                }).join(""),
                d = new ue(c);
            a = {
                tcString: a != null ? a : void 0,
                gdprApplies: !0
            };
            d.skip(78);
            a.cmpId = V(d, 12);
            a.cmpVersion = V(d, 12);
            d.skip(30);
            a.tcfPolicyVersion = V(d, 6);
            a.isServiceSpecific = !!V(d, 1);
            a.useNonStandardStacks = !!V(d, 1);
            a.specialFeatureOptins = Ae(xe(d, 12, oe), oe);
            a.purpose = {
                consents: Ae(xe(d, 24, ne), ne),
                legitimateInterests: Ae(xe(d, 24, ne), ne)
            };
            a.purposeOneTreatment = !!V(d, 1);
            a.publisherCC = ve(d);
            a.vendor = {
                consents: Ae(ye(d), null),
                legitimateInterests: Ae(ye(d), null)
            };
            var e = Be(b);
            e && (a.vendor.vendorsDisclosed = e);
            return a
        } catch (f) {
            return null
        }
    }

    function Be(a) {
        a.shift();
        a = y(a);
        for (var b = a.next(); !b.done; b = a.next())
            if (b = Sa(b.value).map(function(c) {
                    return (q = c.toString(2), v(q, "padStart")).call(q, 8, "0")
                }).join(""), b = new ue(b), V(b, 3) === 1) return Ae(ye(b), null)
    }

    function Ae(a, b) {
        var c = {};
        if (Array.isArray(b) && b.length !== 0) {
            b = y(b);
            for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = a.indexOf(d) !== -1
        } else
            for (a = y(a), b = a.next(); !b.done; b = a.next()) c[b.value] = !0;
        delete c[0];
        return c
    };
    var Ce = function(a) {
        this.i = L(a)
    };
    x(Ce, U);
    var De = function(a, b) {
        var c = c === void 0 ? {} : c;
        this.error = a;
        this.meta = c;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror"
    };

    function Ee(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = ce("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Array.prototype.indexOf.call(g, e, void 0);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, !1);
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, !1)
            };
            typeof e.addEventListener === "function" && e.addEventListener("load", f, !1);
            typeof e.addEventListener === "function" && e.addEventListener("error", f, !1)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function Fe(a) {
        var b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=rcs_internal";
        Rd(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        Ge(c, b)
    }

    function Ge(a, b) {
        var c = window;
        b = b === void 0 ? !1 : b;
        var d = d === void 0 ? !1 : d;
        c.fetch ? (b = {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
            eventSourceEligible: "true",
            triggerEligible: "false"
        } : b.headers = {
            "Attribution-Reporting-Eligible": "event-source"
        }), c.fetch(a, b)) : Ee(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };

    function He(a, b) {
        try {
            var c = function(d) {
                var e = {};
                return [(e[d.ba] = d.Z, e)]
            };
            return JSON.stringify([a.filter(function(d) {
                return d.S
            }).map(c), K(b), a.filter(function(d) {
                return !d.S
            }).map(c)])
        } catch (d) {
            return Ie(d, b), ""
        }
    }

    function Ie(a, b) {
        try {
            var c = a instanceof Error ? a : Error(String(a)),
                d = c.toString();
            c.name && d.indexOf(c.name) == -1 && (d += ": " + c.name);
            c.message && d.indexOf(c.message) == -1 && (d += ": " + c.message);
            if (c.stack) a: {
                var e = c.stack;a = d;
                try {
                    e.indexOf(a) == -1 && (e = a + "\n" + e);
                    for (var f; e != f;) f = e, e = e.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    d = e.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (g) {
                    d = a;
                    break a
                }
                d = void 0
            }
            Fe({
                m: d,
                b: T(b, 1) || null,
                v: S(b, 2) || null
            })
        } catch (g) {}
    }
    var Je = function(a, b, c) {
            this.N = c;
            c = new Ce;
            a = td(c, 1, a);
            this.C = rd(a, 2, b)
        },
        Ke = function(a) {
            if (a.N) {
                var b = a.C,
                    c = [],
                    d = c.concat,
                    e = u.Set,
                    f = [],
                    g = f.concat;
                var h = Nc(a.C, 3, cc, P());
                c = d.call(c, A(new e(g.call(f, A(h), A(a.N())))));
                Sc(b, 3, c, bc)
            }
            return Fc(a.C)
        };
    var Le = function(a) {
        this.i = L(a)
    };
    x(Le, U);
    var Ne = function(a, b) {
            return Xc(a, 3, Me, b == null ? b : Xb(b))
        },
        Me = [1, 2, 3];
    var Oe = function(a) {
        this.i = L(a)
    };
    x(Oe, U);
    var Qe = function(a, b) {
            return qd(a, Pe, b)
        },
        Pe = [2, 4];
    var Re = function(a) {
        this.i = L(a)
    };
    x(Re, U);
    var Se = function(a) {
            var b = new Re;
            return rd(b, 1, a)
        },
        Te = function(a, b) {
            return dd(a, 3, b)
        },
        Ue = function(a, b) {
            var c = b;
            Hc(a);
            b = a.i;
            var d = bd(a, b, b[F] | 0, Le, 4, 2, !0);
            c = c != null ? c : new Le;
            d.push(c);
            var e = d === mb ? 7 : d[F] | 0,
                f = e;
            (c = H(c)) ? (e &= -9, d.length === 1 && (e &= -4097)) : e |= 4096;
            e !== f && G(d, e);
            c || Ic(b);
            return a
        };
    var Ve = function(a) {
        this.i = L(a)
    };
    x(Ve, U);
    var We = function(a) {
        this.i = L(a)
    };
    x(We, U);
    var Xe = function(a, b) {
            return td(a, 1, b)
        },
        Ye = function(a, b) {
            return td(a, 2, b)
        };
    var Ze = function(a) {
        this.i = L(a)
    };
    x(Ze, U);
    var $e = [1, 2];
    var af = function(a) {
        this.i = L(a)
    };
    x(af, U);
    var bf = function(a, b) {
            return dd(a, 1, b)
        },
        cf = function(a, b) {
            return fd(a, 2, b)
        },
        df = function(a, b) {
            return Sc(a, 4, b, bc)
        },
        ef = function(a, b) {
            return fd(a, 5, b)
        },
        ff = function(a, b) {
            return td(a, 6, b)
        };
    var gf = function(a) {
        this.i = L(a)
    };
    x(gf, U);
    var hf = [1, 2, 3, 4, 6];
    var jf = function(a) {
        this.i = L(a)
    };
    x(jf, U);
    var kf = function(a) {
        this.i = L(a)
    };
    x(kf, U);
    var lf = [2, 3, 4];
    var mf = function(a) {
        this.i = L(a)
    };
    x(mf, U);
    var nf = [3, 4, 5],
        of = [6, 7];
    var pf = function(a) {
        this.i = L(a)
    };
    x(pf, U);
    var qf = [4, 5];
    var rf = function(a) {
        this.i = L(a)
    };
    x(rf, U);
    rf.prototype.getTagSessionCorrelator = function() {
        return kd(this, 2)
    };
    var tf = function(a) {
            var b = new rf;
            return ed(b, 4, sf, a)
        },
        sf = [4, 5, 7, 8, 9];
    var uf = function(a) {
        this.i = L(a)
    };
    x(uf, U);
    var vf = function(a) {
        this.i = L(a)
    };
    x(vf, U);
    var wf = [1, 2, 4, 5, 6, 9, 10, 11];
    var xf = function(a) {
        this.i = L(a)
    };
    x(xf, U);
    xf.prototype.getTagSessionCorrelator = function() {
        return kd(this, 2)
    };
    xf.prototype.da = function(a) {
        return md(this, 4, a)
    };
    var yf = function(a) {
        this.i = L(a)
    };
    x(yf, U);
    yf.prototype.ab = function() {
        return id(this, 2)
    };
    yf.prototype.Za = function(a) {
        var b = Nc(this, 3, qc, 3, !0);
        tb(b, a);
        return b[a]
    };
    var zf = function(a) {
        this.i = L(a)
    };
    x(zf, U);
    var Af = function(a) {
        this.i = L(a)
    };
    x(Af, U);
    Af.prototype.getTagSessionCorrelator = function() {
        return kd(this, 1)
    };
    Af.prototype.da = function(a) {
        return md(this, 2, a)
    };
    var Bf = function(a) {
        this.i = L(a)
    };
    x(Bf, U);
    var Cf = [1, 7],
        Df = [4, 6, 8];
    var Ff = function(a) {
            this.g = a;
            this.ja = new Ef(this.g)
        },
        Ef = function(a) {
            this.g = a;
            this.ea = new Gf(this.g)
        },
        Gf = function(a) {
            this.g = a;
            this.outstream = new Hf;
            this.request = new If;
            this.threadYield = new Jf;
            this.Ia = new Kf(this.g);
            this.cb = new Lf(this.g);
            this.gb = new Mf(this.g);
            this.nb = new Nf(this.g)
        },
        Kf = function(a) {
            this.g = a
        };
    Kf.prototype.J = function(a) {
        this.g.o(Te(Ue(Se("av7Wxb"), Ne(new Le, a.Ma)), Qe(new Oe, Math.round(a.K))))
    };
    var Lf = function(a) {
        this.g = a
    };
    Lf.prototype.J = function(a) {
        this.g.o(Te(Ue(Ue(Se("JwITQ"), Ne(new Le, a.oa)), Ne(new Le, a.qa)), Qe(new Oe, Math.round(a.K))))
    };
    var Mf = function(a) {
        this.g = a
    };
    Mf.prototype.J = function(a) {
        this.g.o(Te(Ue(Ue(Se("Pn3Upd"), Ne(new Le, a.oa)), Ne(new Le, a.qa)), Qe(new Oe, Math.round(a.K))))
    };
    var Nf = function(a) {
        this.g = a
    };
    Nf.prototype.J = function(a) {
        var b = this.g,
            c = b.o,
            d = Se("rkgGzc");
        var e = new Le;
        e = qd(e, Me, a.source);
        d = Ue(d, e);
        e = new Le;
        e = qd(e, Me, a.Ua);
        c.call(b, Te(Ue(d, e), Qe(new Oe, Math.round(a.K))))
    };
    var Hf = function() {},
        If = function() {},
        Jf = function() {},
        Of = function() {
            Je.apply(this, arguments);
            this.ga = new Ff(this)
        };
    x(Of, Je);
    var Pf = function() {
        Of.apply(this, arguments)
    };
    x(Pf, Of);
    Pf.prototype.rb = function() {
        this.l.apply(this, A(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 2,
                Z: K(a)
            }
        })))
    };
    Pf.prototype.qb = function() {
        this.l.apply(this, A(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 29,
                Z: K(a)
            }
        })))
    };
    Pf.prototype.ha = function() {
        this.l.apply(this, A(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 4,
                Z: K(a)
            }
        })))
    };
    Pf.prototype.sb = function() {
        this.l.apply(this, A(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 15,
                Z: K(a)
            }
        })))
    };
    Pf.prototype.o = function() {
        this.l.apply(this, A(qa.apply(0, arguments).map(function(a) {
            return {
                S: !1,
                ba: 1,
                Z: K(a)
            }
        })))
    };

    function Qf(a, b) {
        if (u.globalThis.fetch) u.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var Rf = function(a, b, c, d, e, f, g, h, k) {
        Pf.call(this, a, b, k);
        this.X = c;
        this.W = d;
        this.Y = e;
        this.U = f;
        this.V = g;
        this.L = h;
        this.g = [];
        this.j = null;
        this.O = !1
    };
    x(Rf, Pf);
    var Sf = function(a) {
        a.j !== null && (clearTimeout(a.j), a.j = null);
        if (a.g.length) {
            var b = He(a.g, Ke(a));
            a.W(a.X + "?e=1", b);
            a.g = []
        }
    };
    Rf.prototype.l = function() {
        var a = qa.apply(0, arguments),
            b = this;
        try {
            this.V && He(this.g.concat(a), Ke(this)).length >= 65536 && Sf(this), this.L && !this.O && (this.O = !0, this.L.g(function() {
                Sf(b)
            })), this.g.push.apply(this.g, A(a)), this.g.length >= this.U && Sf(this), this.g.length && this.j === null && (this.j = setTimeout(function() {
                Sf(b)
            }, this.Y))
        } catch (c) {
            Ie(c, Ke(this))
        }
    };
    var Tf = function(a, b, c, d, e, f, g) {
        Rf.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", Qf, c === void 0 ? 1E3 : c, d === void 0 ? 100 : d, (e === void 0 ? !1 : e) && !!u.globalThis.fetch, f, g)
    };
    x(Tf, Rf);
    var Uf = function(a) {
            this.g = a;
            this.defaultValue = !1
        },
        Vf = function(a, b) {
            this.g = a;
            this.defaultValue = b === void 0 ? 0 : b
        };
    var Wf = new Vf(695925491, 20),
        Xf = new Uf(45624259),
        Yf = new Vf(635239304, 100),
        Zf = new Uf(662101539),
        $f = new Vf(682056200, 100),
        ag = new Vf(24),
        bg = new function(a, b) {
            b = b === void 0 ? [] : b;
            this.g = a;
            this.defaultValue = b
        }(1934, ["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A93bovR+QVXNx2/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A1S5fojrAunSDrFbD8OfGmFHdRFZymSM/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"]);
    var cg = function() {
            this.g = {}
        },
        gg = function() {
            var a = dg;
            eg || (eg = new fg);
            var b = eg.g[a.key];
            if (a.valueType === "proto") {
                try {
                    var c = JSON.parse(b);
                    if (Array.isArray(c)) return c
                } catch (d) {}
                return a.defaultValue
            }
            return typeof b === typeof a.defaultValue ? b : a.defaultValue
        };
    var hg = function(a) {
        this.i = L(a)
    };
    x(hg, U);
    var ig = function(a) {
        this.i = L(a)
    };
    x(ig, U);
    var jg = function(a) {
        this.i = L(a)
    };
    x(jg, U);
    var kg = function(a) {
        this.i = L(a)
    };
    x(kg, U);
    var lg = xd(kg);
    var dg = new function() {
        this.key = "45749097";
        this.defaultValue = !1;
        this.valueType = "boolean"
    };
    var fg = function() {
            this.g = {};
            var a = D.__fcexpdef || "";
            try {
                var b = JSON.parse(a)[0];
                a = "";
                for (var c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                this.g = JSON.parse(a)
            } catch (d) {}
        },
        eg;
    x(fg, cg);

    function mg(a) {
        this.g = a || {
            cookie: ""
        }
    }
    mg.prototype.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.ib
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ? ";samesite=" + e : "")
    };
    mg.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = Aa(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    mg.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    mg.prototype.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = Aa(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; a >= 0; a--) c = b[a], this.get(c), this.set(c, "", {
            ib: 0,
            path: void 0,
            domain: void 0
        })
    };

    function ng(a) {
        a = og(a);
        try {
            var b = a ? lg(a) : null
        } catch (c) {
            b = null
        }
        return b ? Q(b, jg, 4) || null : null
    }

    function og(a) {
        var b;
        if (!(b = !gg())) {
            var c;
            b = a == null ? void 0 : (c = a.location) == null ? void 0 : c.origin;
            b = b !== "null"
        }
        a = b ? (new mg(a)).get("FCCDCF", "") : "";
        if (a)
            if (v(a, "startsWith").call(a, "%")) try {
                var d = decodeURIComponent(a)
            } catch (e) {
                d = null
            } else d = a;
            else d = null;
        return d
    };
    ee(fe).map(function(a) {
        return Number(a)
    });
    ee(ge).map(function(a) {
        return Number(a)
    });
    var pg = function(a) {
            this.g = a
        },
        rg = function(a) {
            a.__tcfapiPostMessageReady || qg(new pg(a))
        },
        qg = function(a) {
            a.j = function(b) {
                var c = typeof b.data === "string";
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__tcfapiCall;
                e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.g.__tcfapi)(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__tcfapiReturn = e.command === "removeEventListener" ? {
                        success: f,
                        callId: e.callId
                    } : {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                    return f
                }, e.parameter)
            };
            a.g.addEventListener("message", a.j);
            a.g.__tcfapiPostMessageReady = !0
        };
    var sg = function(a) {
            this.g = a;
            this.j = null
        },
        ug = function(a) {
            a.__uspapiPostMessageReady || tg(new sg(a))
        },
        tg = function(a) {
            a.j = function(b) {
                var c = typeof b.data === "string";
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__uspapiCall;
                e && e.command === "getUSPData" && a.g.__uspapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__uspapiReturn = {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                    return f
                })
            };
            a.g.addEventListener("message", a.j);
            a.g.__uspapiPostMessageReady = !0
        };
    var vg = function(a) {
        this.i = L(a)
    };
    x(vg, U);
    var wg = function(a) {
        this.i = L(a)
    };
    x(wg, U);
    var xg = xd(wg);

    function yg(a, b) {
        function c(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 4));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function d(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function e(l) {
            if (l.length < 12) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(8, 12));
            l = m(l);
            return "1" + p + l + "N"
        }

        function f(l) {
            if (l.length < 18) return null;
            var p = h(l.slice(0, 8));
            p = k(p);
            l = h(l.slice(12, 18));
            l = m(l);
            return "1" + p + l + "N"
        }

        function g(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function h(l) {
            for (var p = [], r = 0, t = 0; t < l.length / 2; t++) p.push(je(l.slice(r, r + 2))), r += 2;
            return p
        }

        function k(l) {
            return l.every(function(p) {
                return p === 1
            }) ? "Y" : "N"
        }

        function m(l) {
            return l.some(function(p) {
                return p === 1
            }) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = ie(a[0]);
        var n = je(a.slice(0, 6));
        a = a.slice(6);
        if (n !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function zg(a, b) {
        var c = a.document,
            d = function() {
                if (!a.frames[b])
                    if (c.body) {
                        var e = ce("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var Cg = function(a) {
            this.g = a;
            var b = og(this.g.document);
            try {
                var c = b ? lg(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = Q(b, ig, 5) || null, b = R(b, hg, 7, P()), b = Ag(b != null ? b : []), c = {
                Ga: c,
                Ja: b
            }) : c = {
                Ga: null,
                Ja: null
            };
            b = c;
            c = Bg(b.Ja);
            b = b.Ga;
            if (b != null && qc(M(b, 2)) != null && S(b, 2).length !== 0) {
                var d = Mc(b, pe, 1) ? Q(b, pe, 1) : qe();
                b = {
                    uspString: S(b, 2),
                    la: re(d)
                }
            } else b = null;
            this.l = b && c ? c.la > b.la ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.tcString = (c = ng(a.document)) && qc(M(c, 1)) != null ? S(c, 1) : null;
            this.j = (a = ng(a.document)) && qc(M(a, 2)) != null ? S(a, 2) : null
        },
        Fg = function(a) {
            a === a.top && (a = new Cg(a), Dg(a), Eg(a))
        },
        Dg = function(a) {
            !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", zg(a.g, "__uspapiLocator"), ya("__uspapi", function(b, c, d) {
                typeof d === "function" && b === "getUSPData" && d({
                    version: 1,
                    uspString: a.l
                }, !0)
            }, a.g), ug(a.g))
        },
        Ag = function(a) {
            a = v(a, "find").call(a, function(b) {
                return b && T(b, 1) === 13
            });
            if (a == null ? 0 : qc(M(a, 2)) != null) try {
                return xg(S(a, 2))
            } catch (b) {}
            return null
        },
        Bg = function(a) {
            if (a == null || qc(M(a, 1)) == null || S(a, 1).length === 0 || R(a, vg, 2, P()).length === 0) return null;
            var b = S(a, 1);
            try {
                var c = le(b.split("~")[0]);
                var d = v(b, "includes").call(b, "~") ? b.split("~").slice(1) : []
            } catch (e) {
                return null
            }
            a = R(a, vg, 2, P()).reduce(function(e, f) {
                var g = Gg(e);
                g = kd(g, 1);
                g = te(g);
                var h = Gg(f);
                h = kd(h, 1);
                return g > te(h) ? e : f
            });
            c = Nc(c, 3, cc, P()).indexOf(id(a, 1));
            return c === -1 || c >= d.length ? null : {
                uspString: yg(d[c], id(a, 1)),
                la: re(Gg(a))
            }
        },
        Gg = function(a) {
            return Mc(a, pe, 2) ? Q(a, pe, 2) : qe()
        },
        Eg = function(a) {
            !a.tcString || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", zg(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], ya("__tcfapi", function(b, c, d, e) {
                if (typeof d === "function")
                    if (c && (c > 2.3 || c <= 1)) d(null, !1);
                    else switch (c = a.g.__tcfapiEventListeners, b) {
                        case "ping":
                            d({
                                gdprApplies: !0,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.3",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            b = c.push(d) - 1;
                            a.tcString ? (e = ze(a.tcString), e.addtlConsent = a.j != null ? a.j : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && c[e] ? (c[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
            }, a.g), rg(a.g))
        };
    var Hg = oa(["https://pagead2.googlesyndication.com/pagead/managed/dict/", "/gpt"]),
        Ig = oa(["https://securepubads.g.doubleclick.net/pagead/managed/dict/", "/gpt"]);

    function Jg(a, b, c) {
        try {
            var d = a.createElement("link"),
                e, f;
            if (((e = d.relList) == null ? 0 : (f = e.supports) == null ? 0 : f.call(e, "compression-dictionary")) && Na()) {
                if (b instanceof Hd) d.href = Jd(b).toString(), d.rel = "compression-dictionary";
                else {
                    if (Od.indexOf("compression-dictionary") === -1) throw Error('TrustedResourceUrl href attribute required with rel="compression-dictionary"');
                    var g = Kd.test(b) ? b : void 0;
                    g !== void 0 && (d.href = g, d.rel = "compression-dictionary")
                }
                a.head.appendChild(d)
            }
        } catch (h) {
            c.G({
                methodName: 1296,
                I: h
            })
        }
    }

    function Kg(a, b) {
        return b ? Zd(Hg, a) : Zd(Ig, a)
    };
    var Lg = null;

    function Mg(a, b) {
        var c = R(a, mf, 2, P());
        if (!c.length) return Ng(a, b);
        a = T(a, 1);
        if (a === 1) {
            var d = Mg(c[0], b);
            return d.success ? {
                success: !0,
                value: !d.value
            } : d
        }
        c = Oa(c, function(h) {
            return Mg(h, b)
        });
        switch (a) {
            case 2:
                var e;
                return (e = (d = v(c, "find").call(c, function(h) {
                    return h.success && !h.value
                })) != null ? d : v(c, "find").call(c, function(h) {
                    return !h.success
                })) != null ? e : {
                    success: !0,
                    value: !0
                };
            case 3:
                var f, g;
                return (g = (f = v(c, "find").call(c, function(h) {
                    return h.success && h.value
                })) != null ? f : v(c, "find").call(c, function(h) {
                    return !h.success
                })) != null ? g : {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    B: 3
                }
        }
    }

    function Ng(a, b) {
        var c = Yc(a, nf);
        a: {
            switch (c) {
                case 3:
                    var d = nd(a, 3, nf);
                    break a;
                case 4:
                    d = nd(a, 4, nf);
                    break a;
                case 5:
                    d = nd(a, 5, nf);
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            B: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            T: d,
            aa: c,
            B: 1
        };
        try {
            var e = b.apply;
            var f = Nc(a, 8, qc, P());
            var g = e.call(b, null, A(f))
        } catch (h) {
            return {
                success: !1,
                T: d,
                aa: c,
                B: 2
            }
        }
        e = T(a, 1);
        if (e === 4) return {
            success: !0,
            value: !!g
        };
        if (e === 5) return {
            success: !0,
            value: g != null
        };
        if (e === 12) a = S(a, Zc(a, of , 7));
        else a: {
            switch (c) {
                case 4:
                    a = ld(a, Zc(a, of , 6));
                    break a;
                case 5:
                    a = S(a, Zc(a, of , 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            T: d,
            aa: c,
            B: 3
        };
        if (e === 6) return {
            success: !0,
            value: g === a
        };
        if (e === 9) return {
            success: !0,
            value: g != null && Ba(String(g), a) === 0
        };
        if (g == null) return {
            success: !1,
            T: d,
            aa: c,
            B: 4
        };
        switch (e) {
            case 7:
                c = g < a;
                break;
            case 8:
                c = g > a;
                break;
            case 12:
                c = Ab(a) && Ab(g) && (new RegExp(a)).test(g);
                break;
            case 10:
                c = g != null && Ba(String(g), a) === -1;
                break;
            case 11:
                c = g != null && Ba(String(g), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    B: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function Og(a, b) {
        return a ? b ? Mg(a, b) : {
            success: !1,
            B: 1
        } : {
            success: !0,
            value: !0
        }
    };
    var Pg = function(a) {
        this.i = L(a)
    };
    x(Pg, U);
    var Qg = function(a) {
        return Nc(a, 4, qc, P())
    };
    var Rg = function(a) {
        this.i = L(a)
    };
    x(Rg, U);
    Rg.prototype.getValue = function() {
        return Q(this, Pg, 2)
    };
    var Sg = function(a) {
        this.i = L(a)
    };
    x(Sg, U);
    var Tg = xd(Sg),
        Ug = [1, 2, 3, 6, 7, 8];
    var Vg = function(a, b, c) {
            var d = d === void 0 ? new Tf(6, "unknown", b) : d;
            this.C = a;
            this.o = c;
            this.j = d;
            this.g = [];
            this.l = a > 0 && Sd() < 1 / a
        },
        Xg = function(a, b, c, d, e, f) {
            if (a.l) {
                var g = Ye(Xe(new We, b), c);
                b = ff(cf(bf(ef(df(new af, d), e), g), a.g.slice()), f);
                b = tf(b);
                a.j.ha(Wg(a, b));
                if (f === 1 || f === 3 || f === 4 && !a.g.some(function(h) {
                        return T(h, 1) === T(g, 1) && T(h, 2) === c
                    })) a.g.push(g), a.g.length > 100 && a.g.shift()
            }
        },
        Yg = function(a, b, c, d) {
            if (a.l) {
                var e = new Ve;
                b = O(e, 1, b == null ? b : bc(b));
                c = O(b, 2, c == null ? c : bc(c));
                d = sd(c, 3, d);
                c = new rf;
                d = ed(c, 8, sf, d);
                a.j.ha(Wg(a, d))
            }
        },
        Zg = function(a, b, c, d, e) {
            if (a.l) {
                var f = new pf;
                b = dd(f, 1, b);
                c = sd(b, 2, c);
                d = O(c, 3, d == null ? d : bc(d));
                if (e.aa === void 0) ud(d, 4, qf, e.B);
                else switch (e.aa) {
                    case 3:
                        c = new kf;
                        c = ud(c, 2, lf, e.T);
                        e = sd(c, 1, e.B);
                        ed(d, 5, qf, e);
                        break;
                    case 4:
                        c = new kf;
                        c = ud(c, 3, lf, e.T);
                        e = sd(c, 1, e.B);
                        ed(d, 5, qf, e);
                        break;
                    case 5:
                        c = new kf, c = ud(c, 4, lf, e.T), e = sd(c, 1, e.B), ed(d, 5, qf, e)
                }
                e = new rf;
                e = ed(e, 9, sf, d);
                a.j.ha(Wg(a, e))
            }
        },
        Wg = function(a, b) {
            var c = Date.now();
            c = v(Number, "isFinite").call(Number, c) ? Math.round(c) : 0;
            b = pd(b, 1, c);
            c = de(window);
            b = pd(b, 2, c);
            return pd(b, 6, a.C)
        };
    var W = function(a) {
        var b = "na";
        if (a.na && a.hasOwnProperty(b)) return a.na;
        b = new a;
        return a.na = b
    };
    var $g = function() {
        var a = {};
        this.A = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    var ah = /^true$/.test("false");

    function bh(a, b) {
        switch (b) {
            case 1:
                return nd(a, 1, Ug);
            case 2:
                return nd(a, 2, Ug);
            case 3:
                return nd(a, 3, Ug);
            case 6:
                return nd(a, 6, Ug);
            case 8:
                return nd(a, 8, Ug);
            default:
                return null
        }
    }

    function ch(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return hd(a, 1);
            case 7:
                return S(a, 3);
            case 2:
                return ld(a, 2);
            case 3:
                return S(a, 3);
            case 6:
                return Qg(a);
            case 8:
                return Qg(a);
            default:
                return null
        }
    }
    var dh = Dd(function() {
        if (!ah) return {};
        try {
            var a = a === void 0 ? window : a;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch (c) {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch (c) {}
        return {}
    });

    function eh(a, b, c, d) {
        var e = d = d === void 0 ? 0 : d,
            f, g;
        W(fh).l[e] = (g = (f = W(fh).l[e]) == null ? void 0 : f.add(b)) != null ? g : (new u.Set).add(b);
        e = dh();
        if (e[b] != null) return e[b];
        b = gh(d)[b];
        if (!b) return c;
        b = Tg(JSON.stringify(b));
        b = hh(b);
        a = ch(b, a);
        return a != null ? a : c
    }

    function hh(a) {
        var b = W($g).A;
        if (b && Yc(a, Ug) !== 8) {
            var c = Pa(R(a, Rg, 5, P()), function(f) {
                f = Og(Q(f, mf, 1), b);
                return f.success && f.value
            });
            if (c) {
                var d;
                return (d = c.getValue()) != null ? d : null
            }
        }
        var e;
        return (e = Q(a, Pg, 4)) != null ? e : null
    }
    var fh = function() {
        this.j = {};
        this.o = [];
        this.l = {};
        this.g = new u.Map
    };

    function ih(a, b, c) {
        return !!eh(1, a, b === void 0 ? !1 : b, c)
    }

    function jh(a, b, c) {
        b = b === void 0 ? 0 : b;
        a = Number(eh(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function kh(a, b, c) {
        b = b === void 0 ? "" : b;
        a = eh(3, a, b, c);
        return typeof a === "string" ? a : b
    }

    function lh(a, b, c) {
        b = b === void 0 ? [] : b;
        a = eh(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function mh(a, b, c) {
        b = b === void 0 ? [] : b;
        a = eh(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function gh(a) {
        return W(fh).j[a] || (W(fh).j[a] = {})
    }

    function nh(a, b) {
        var c = gh(b);
        Rd(a, function(d, e) {
            if (c[e]) {
                d = Tg(JSON.stringify(d));
                var f = Zc(d, Ug, 8);
                if (ac(M(d, f)) != null) {
                    var g = Tg(JSON.stringify(c[e]));
                    f = $c(d, Pg, 4);
                    g = Qg(ad(g, Pg, 4));
                    gd(f, g)
                }
                c[e] = K(d)
            } else c[e] = d
        })
    }

    function oh(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        var f = [],
            g = [];
        b = y(b);
        for (var h = b.next(); !h.done; h = b.next()) {
            h = h.value;
            for (var k = gh(h), m = y(a), n = m.next(); !n.done; n = m.next()) {
                n = n.value;
                var l = Yc(n, Ug),
                    p = bh(n, l);
                if (p) {
                    var r = void 0,
                        t = void 0,
                        z = void 0;
                    var B = (r = (z = W(fh).g.get(h)) == null ? void 0 : (t = z.get(p)) == null ? void 0 : t.slice(0)) != null ? r : [];
                    a: {
                        r = p;t = l;z = new gf;
                        switch (t) {
                            case 1:
                                ud(z, 1, hf, r);
                                break;
                            case 2:
                                ud(z, 2, hf, r);
                                break;
                            case 3:
                                ud(z, 3, hf, r);
                                break;
                            case 6:
                                ud(z, 4, hf, r);
                                break;
                            case 8:
                                ud(z, 6, hf, r);
                                break;
                            default:
                                B = void 0;
                                break a
                        }
                        Sc(z, 5, B, bc);B = z
                    }
                    if (r = B) t = void 0, r = !((t = W(fh).l[h]) == null || !t.has(p));
                    r && f.push(B);
                    if (l === 8 && k[p]) B = Tg(JSON.stringify(k[p])), l = $c(n, Pg, 4), B = Qg(ad(B, Pg, 4)), gd(l, B);
                    else {
                        if (l = B) r = void 0, l = !((r = W(fh).g.get(h)) == null || !r.has(p));
                        l && g.push(B)
                    }
                    e || (l = p, B = h, r = d, t = W(fh), t.g.has(B) || t.g.set(B, new u.Map), t.g.get(B).has(l) || t.g.get(B).set(l, []), r && t.g.get(B).get(l).push(r));
                    k[p] = K(n)
                }
            }
        }
        if (f.length || g.length) a = d != null ? d : void 0, c.l && c.o && (d = new jf, f = fd(d, 2, f), g = fd(f, 3, g), a && od(g, 1, a), f = new rf, g = ed(f, 7, sf, g), c.j.ha(Wg(c, g)))
    }

    function ph(a, b) {
        b = gh(b);
        a = y(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            var d = Tg(JSON.stringify(c)),
                e = Yc(d, Ug);
            (d = bh(d, e)) && (b[d] || (b[d] = c))
        }
    }

    function qh() {
        return v(Object, "keys").call(Object, W(fh).j).map(function(a) {
            return Number(a)
        })
    }

    function rh(a) {
        (q = W(fh).o, v(q, "includes")).call(q, a) || nh(gh(4), a)
    };

    function X(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Y(a, b, c) {
        return b[a] || c
    }

    function sh(a) {
        X(5, ih, a);
        X(6, jh, a);
        X(7, kh, a);
        X(8, lh, a);
        X(17, mh, a);
        X(13, ph, a);
        X(15, rh, a)
    }

    function th(a) {
        X(4, function(b) {
            W($g).A = b
        }, a);
        X(9, function(b, c) {
            var d = W($g);
            d.A[3][b] == null && (d.A[3][b] = c)
        }, a);
        X(10, function(b, c) {
            var d = W($g);
            d.A[4][b] == null && (d.A[4][b] = c)
        }, a);
        X(11, function(b, c) {
            var d = W($g);
            d.A[5][b] == null && (d.A[5][b] = c)
        }, a);
        X(14, function(b) {
            for (var c = W($g), d = y([3, 4, 5]), e = d.next(); !e.done; e = d.next()) e = e.value, v(Object, "assign").call(Object, c.A[e], b[e])
        }, a)
    }

    function uh(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var vh = function() {};
    vh.prototype.g = function() {};
    vh.prototype.j = function() {};
    vh.prototype.l = function() {
        return []
    };
    var wh = function(a, b, c) {
        a.j = function(d, e) {
            Y(2, b, function() {
                return []
            })(d, c, e)
        };
        a.l = function(d) {
            return Y(3, b, function() {
                return []
            })(d != null ? d : c)
        };
        a.g = function(d) {
            Y(16, b, function() {})(d, c)
        }
    };

    function xh(a) {
        W(vh).g(a)
    }

    function yh(a) {
        return W(vh).l(a)
    };

    function zh(a, b) {
        try {
            var c = a.split(".");
            a = D;
            for (var d = 0, e; a != null && d < c.length; d++) e = a, a = a[c[d]], typeof a === "function" && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var Ah = {},
        Bh = {},
        Ch = {},
        Dh = {},
        Eh = (Dh[3] = (Ah[8] = function(a) {
            try {
                return va(a) != null
            } catch (b) {}
        }, Ah[9] = function(a) {
            try {
                var b = va(a)
            } catch (c) {
                return
            }
            if (a = typeof b === "function") b = b && b.toString && b.toString(), a = typeof b === "string" && b.indexOf("[native code]") != -1;
            return a
        }, Ah[10] = function() {
            return window === window.top
        }, Ah[6] = function(a, b) {
            b = yh(b ? Number(b) : void 0);
            return Array.prototype.indexOf.call(b, Number(a), void 0) >= 0
        }, Ah[27] = function(a) {
            a = zh(a, "boolean");
            return a !== void 0 ? a : void 0
        }, Ah[60] = function(a) {
            try {
                return !!D.document.querySelector(a)
            } catch (b) {}
        }, Ah[80] = function(a) {
            try {
                return !!D.matchMedia(a).matches
            } catch (b) {}
        }, Ah[69] = function(a) {
            var b = D.document;
            b = b === void 0 ? document : b;
            var c;
            return !((c = b.featurePolicy) == null || !(q = c.features(), v(q, "includes")).call(q, a))
        }, Ah[70] = function(a) {
            var b = D.document;
            b = b === void 0 ? document : b;
            var c;
            return !((c = b.featurePolicy) == null || !(q = c.allowedFeatures(), v(q, "includes")).call(q, a))
        }, Ah[79] = function(a) {
            var b = D.navigator;
            b = b === void 0 ? navigator : b;
            try {
                var c, d;
                var e = !!((c = b.protectedAudience) == null ? 0 : (d = c.queryFeatureSupport) == null ? 0 : d.call(c, a))
            } catch (f) {
                e = !1
            }
            return e
        }, Ah), Dh[4] = (Bh[3] = function() {
            return Qd()
        }, Bh[6] = function(a) {
            a = zh(a, "number");
            return a !== void 0 ? a : void 0
        }, Bh), Dh[5] = (Ch[2] = function() {
            return window.location.href
        }, Ch[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, Ch[4] = function(a) {
            a = zh(a, "string");
            return a !== void 0 ? a : void 0
        }, Ch[12] = function(a) {
            try {
                var b = zh(a, "string");
                if (b !== void 0) return atob(b)
            } catch (c) {}
        }, Ch), Dh);

    function Fh() {
        var a = a === void 0 ? D : a;
        return a.ggeac || (a.ggeac = {})
    };
    var Gh = function(a) {
        this.i = L(a)
    };
    x(Gh, U);
    Gh.prototype.getId = function() {
        return id(this, 1)
    };
    var Hh = function(a) {
        this.i = L(a)
    };
    x(Hh, U);
    var Ih = function(a) {
        return R(a, Gh, 2, P())
    };
    var Jh = function(a) {
        this.i = L(a)
    };
    x(Jh, U);
    var Kh = function(a) {
        this.i = L(a)
    };
    x(Kh, U);
    var Lh = function(a) {
        this.i = L(a)
    };
    x(Lh, U);

    function Mh(a) {
        var b = {};
        return Nh((b[0] = new u.Map, b[1] = new u.Map, b[2] = new u.Map, b), a)
    }

    function Nh(a, b) {
        for (var c = new u.Map, d = y(v(a[1], "entries").call(a[1])), e = d.next(); !e.done; e = d.next()) {
            var f = y(e.value);
            e = f.next().value;
            f = f.next().value;
            f = f[f.length - 1];
            c.set(e, f.Sa + f.Na * f.Oa)
        }
        b = y(b);
        for (d = b.next(); !d.done; d = b.next())
            for (d = d.value, e = R(d, Hh, 2, P()), e = y(e), f = e.next(); !f.done; f = e.next())
                if (f = f.value, Ih(f).length !== 0) {
                    var g = jd(f, 8);
                    if (T(f, 4) && !T(f, 13) && !T(f, 14)) {
                        var h = void 0;
                        g = (h = c.get(T(f, 4))) != null ? h : 0;
                        h = jd(f, 1) * Ih(f).length;
                        c.set(T(f, 4), g + h)
                    }
                    h = [];
                    for (var k = 0; k < Ih(f).length; k++) {
                        var m = {
                            Sa: g,
                            Na: jd(f, 1),
                            Oa: Ih(f).length,
                            jb: k,
                            ca: T(d, 1),
                            ia: f,
                            F: Ih(f)[k]
                        };
                        h.push(m)
                    }
                    Oh(a[2], T(f, 10), h) || Oh(a[1], T(f, 4), h) || Oh(a[0], Ih(f)[0].getId(), h)
                }
        return a
    }

    function Oh(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        var d;
        (d = a.get(b)).push.apply(d, A(c));
        return !0
    };
    var Ph = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Qh(a) {
        return a ? decodeURI(a) : a
    }
    var Rh = /#|$/;

    function Sh(a, b) {
        var c = a.search(Rh);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };

    function Th(a) {
        var b = a.length;
        if (b === 0) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };

    function Uh() {
        var a = de(window);
        a = a === void 0 ? Sd() : a;
        return function(b) {
            return Th(b + " + " + a) % 1E3
        }
    };
    var Vh = [12, 13, 20],
        Wh = function(a, b, c, d) {
            d = d === void 0 ? {} : d;
            var e = d.ma === void 0 ? !1 : d.ma;
            d = d.pb === void 0 ? [] : d.pb;
            this.R = a;
            this.u = c;
            this.o = {};
            this.ma = e;
            a = {};
            this.g = (a[b] = [], a[4] = [], a);
            this.j = {};
            this.l = {};
            var f = f === void 0 ? window : f;
            if (Lg === null) {
                Lg = "";
                try {
                    b = "";
                    try {
                        b = f.top.location.hash
                    } catch (h) {
                        b = f.location.hash
                    }
                    if (b) {
                        var g = b.match(/\bdeid=([\d,]+)/);
                        Lg = g ? g[1] : ""
                    }
                } catch (h) {}
            }
            if (f = Lg)
                for (f = y(f.split(",") || []), g = f.next(); !g.done; g = f.next())(g = Number(g.value)) && (this.j[g] = !0);
            d = y(d);
            for (f = d.next(); !f.done; f = d.next()) this.j[f.value] = !0
        },
        Zh = function(a, b, c, d) {
            var e = [],
                f;
            if (f = b !== 9) a.o[b] ? f = !0 : (a.o[b] = !0, f = !1);
            if (f) return Xg(a.u, b, c, e, [], 4), e;
            f = v(Vh, "includes").call(Vh, b);
            for (var g = [], h = [], k = y([0, 1, 2]), m = k.next(); !m.done; m = k.next()) {
                m = m.value;
                for (var n = y(v(a.R[m], "entries").call(a.R[m])), l = n.next(); !l.done; l = n.next()) {
                    var p = y(l.value);
                    l = p.next().value;
                    p = p.next().value;
                    var r = l,
                        t = p;
                    l = new Ze;
                    p = t.filter(function(cb) {
                        return cb.ca === b && a.j[cb.F.getId()] && Xh(a, cb)
                    });
                    if (p.length)
                        for (l = y(p), p = l.next(); !p.done; p = l.next()) h.push(p.value.F);
                    else if (!a.ma) {
                        p = void 0;
                        m === 2 ? (p = d[1], ud(l, 2, $e, r)) : p = d[0];
                        var z = void 0,
                            B = void 0;
                        p = (B = (z = p) == null ? void 0 : z(String(r))) != null ? B : m === 2 && T(t[0].ia, 11) === 1 ? void 0 : d[0](String(r));
                        if (p !== void 0) {
                            r = y(t);
                            for (t = r.next(); !t.done; t = r.next())
                                if (t = t.value, t.ca === b) {
                                    z = p - t.Sa;
                                    var ra = t;
                                    B = ra.Na;
                                    var bb = ra.Oa;
                                    ra = ra.jb;
                                    z < 0 || z >= B * bb || z % bb !== ra || !Xh(a, t) || (z = T(t.ia, 13), z !== 0 && z !== void 0 && (B = a.l[String(z)], B !== void 0 && B !== t.F.getId() ? Yg(a.u, a.l[String(z)], t.F.getId(), z) : a.l[String(z)] = t.F.getId()), h.push(t.F))
                                }
                            Yc(l, $e) !== 0 && (od(l, 3, p), g.push(l))
                        }
                    }
                }
            }
            d = y(h);
            for (h = d.next(); !h.done; h = d.next()) h = h.value, k = h.getId(), e.push(k), Yh(a, k, f ? 4 : c), oh(R(h, Sg, 2, P()), f ? qh() : [c], a.u, k);
            Xg(a.u, b, c, e, g, 1);
            return e
        },
        Yh = function(a, b, c) {
            a.g[c] || (a.g[c] = []);
            a = a.g[c];
            v(a, "includes").call(a, b) || a.push(b)
        },
        Xh = function(a, b) {
            var c = W($g).A,
                d = Og(Q(b.ia, mf, 3), c);
            if (!d.success) return Zg(a.u, Q(b.ia, mf, 3), b.ca, b.F.getId(), d), !1;
            if (!d.value) return !1;
            c = Og(Q(b.F, mf, 3), c);
            return c.success ? c.value ? !0 : !1 : (Zg(a.u, Q(b.F, mf, 3), b.ca, b.F.getId(), c), !1)
        },
        $h = function(a, b) {
            b = b.map(function(c) {
                return new Jh(c)
            }).filter(function(c) {
                return !v(Vh, "includes").call(Vh, T(c, 1))
            });
            a.R = Nh(a.R, b)
        },
        ai = function(a, b) {
            X(1, function(c) {
                a.j[c] = !0
            }, b);
            X(2, function(c, d, e) {
                return Zh(a, c, d, e)
            }, b);
            X(3, function(c) {
                return (a.g[c] || []).concat(a.g[4])
            }, b);
            X(12, function(c) {
                return void $h(a, c)
            }, b);
            X(16, function(c, d) {
                return void Yh(a, c, d)
            }, b)
        };
    var bi = function() {
        var a = {};
        this.g = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.j = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.L = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.l = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.C = function(b, c) {
            return a[b] != null ? c.concat(a[b]) : c
        };
        this.o = function() {}
    };

    function ci(a) {
        return W(bi).j(a.g, a.defaultValue)
    };
    var di = function() {
            this.g = function() {}
        },
        ei = function(a, b) {
            a.g = Y(14, b, function() {})
        };

    function fi(a) {
        W(di).g(a)
    };
    var gi, hi, ii, ji, ki, li;

    function mi(a) {
        var b = a.Ya;
        var c = a.A;
        var d = a.config;
        var e = a.Ta === void 0 ? Fh() : a.Ta;
        var f = a.Fa === void 0 ? 0 : a.Fa;
        var g = a.u === void 0 ? new Vg((ji = se((gi = Q(b, Kh, 5)) == null ? void 0 : kd(gi, 2))) != null ? ji : 0, (ki = se((hi = Q(b, Kh, 5)) == null ? void 0 : kd(hi, 4))) != null ? ki : 0, (li = (ii = Q(b, Kh, 5)) == null ? void 0 : hd(ii, 3)) != null ? li : !1) : a.u;
        a = a.R === void 0 ? Mh(R(b, Jh, 2, P(ub))) : a.R;
        e.hasOwnProperty("init-done") ? (Y(12, e, function() {})(R(b, Jh, 2, P()).map(function(h) {
            return K(h)
        })), Y(13, e, function() {})(R(b, Sg, 1, P()).map(function(h) {
            return K(h)
        }), f), c && Y(14, e, function() {})(c), ni(f, e)) : (ai(new Wh(a, f, g, d), e), sh(e), th(e), uh(e), ni(f, e), oh(R(b, Sg, 1, P(ub)), [f], g, void 0, !0), ah = ah || !(!d || !d.pa), fi(Eh), c && fi(c))
    }

    function ni(a, b) {
        var c = b = b === void 0 ? Fh() : b;
        wh(W(vh), c, a);
        oi(b, a);
        a = b;
        ei(W(di), a);
        W(bi).o()
    }

    function oi(a, b) {
        var c = W(bi);
        c.g = function(d, e) {
            return Y(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.j = function(d, e) {
            return Y(6, a, function() {
                return 0
            })(d, e, b)
        };
        c.L = function(d, e) {
            return Y(7, a, function() {
                return ""
            })(d, e, b)
        };
        c.l = function(d, e) {
            return Y(8, a, function() {
                return []
            })(d, e, b)
        };
        c.C = function(d, e) {
            return Y(17, a, function() {
                return []
            })(d, e, b)
        };
        c.o = function() {
            Y(15, a, function() {})(b)
        }
    };
    var pi = oa(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        qi = function() {
            var a = a === void 0 ? "jserror" : a;
            var b = b === void 0 ? .01 : b;
            var c = c === void 0 ? Zd(pi) : c;
            this.g = a;
            this.l = b;
            this.j = c
        };
    var ri = function() {
        var a;
        this.P = a = a === void 0 ? {
            kb: Vd() + (Vd() & 2097151) * 4294967296,
            Wa: v(Number, "MAX_SAFE_INTEGER")
        } : a
    };

    function si(a, b) {
        return b > 0 && a.kb * b <= a.Wa
    };
    var ti = function(a) {
        this.i = L(a)
    };
    x(ti, U);
    var ui = function(a) {
            return hd(a, 1)
        },
        vi = function(a) {
            return hd(a, 2)
        };

    function wi(a) {
        a = a === void 0 ? D : a;
        return (a = a.performance) && a.now ? a.now() : null
    };

    function xi(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function yi(a, b) {
        var c = wi(b);
        c && xi({
            label: a,
            type: 9,
            value: c
        }, b)
    }

    function zi(a, b, c) {
        var d = !1;
        d = d === void 0 ? !1 : d;
        var e = window,
            f = typeof queueMicrotask !== "undefined";
        return function() {
            var g = qa.apply(0, arguments);
            d && f && queueMicrotask(function() {
                e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                e.google_rum_task_id_counter += 1
            });
            var h = wi(),
                k = 3;
            try {
                var m = b.apply(this, g)
            } catch (n) {
                k = 13;
                if (!c) throw n;
                c(a, n)
            } finally {
                e.google_measure_js_timing && h && xi(v(Object, "assign").call(Object, {}, {
                    label: a.toString(),
                    value: h,
                    duration: (wi() || 0) - h,
                    type: k
                }, d && f && {
                    taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                }), e)
            }
            return m
        }
    }

    function Ai(a, b) {
        return zi(a, b, function(c, d) {
            var e = new qi;
            var f = f === void 0 ? e.l : f;
            var g = g === void 0 ? e.g : g;
            Math.random() > f || (d.error && d.meta && d.id || (d = new De(d, {
                context: c,
                id: g
            })), D.google_js_errors = D.google_js_errors || [], D.google_js_errors.push(d), D.error_rep_loaded || (f = D.document, c = ce("SCRIPT", f), Nd(c, e.j), (e = f.getElementsByTagName("script")[0]) && e.parentNode && e.parentNode.insertBefore(c, e), D.error_rep_loaded = !0))
        })
    };

    function Z(a, b) {
        return b == null ? "&" + a + "=null" : "&" + a + "=" + Math.floor(b)
    }

    function Bi(a, b) {
        return "&" + a + "=" + b.toFixed(3)
    }

    function Ci() {
        var a = new u.Set;
        var b = window.googletag;
        b = (b == null ? 0 : b.apiReady) ? b : void 0;
        try {
            if (!b) return a;
            for (var c = b.pubads(), d = y(c.getSlots()), e = d.next(); !e.done; e = d.next()) a.add(e.value.getSlotId().getDomId())
        } catch (f) {}
        return a
    }

    function Di(a) {
        a = a.id;
        return a != null && (Ci().has(a) || v(a, "startsWith").call(a, "google_ads_iframe_") || v(a, "startsWith").call(a, "aswift"))
    }

    function Ei(a, b, c) {
        if (!a.sources) return !1;
        switch (Fi(a)) {
            case 2:
                var d = Gi(a);
                if (d) return c.some(function(f) {
                    return Hi(d, f)
                });
                break;
            case 1:
                var e = Ii(a);
                if (e) return b.some(function(f) {
                    return Hi(e, f)
                })
        }
        return !1
    }

    function Fi(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(function(b) {
            return b.previousRect && b.currentRect
        });
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function Ii(a) {
        return Ji(a, function(b) {
            return b.currentRect
        })
    }

    function Gi(a) {
        return Ji(a, function(b) {
            return b.previousRect
        })
    }

    function Ji(a, b) {
        return a.sources.reduce(function(c, d) {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function Hi(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : c * a * 100 / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }
    var Ki = function() {
            this.l = this.j = this.X = this.V = this.N = 0;
            this.Ba = this.ya = Number.NEGATIVE_INFINITY;
            this.g = [];
            this.O = {};
            this.va = 0;
            this.W = Infinity;
            this.ta = this.wa = this.xa = this.za = this.Ea = this.C = this.Da = this.ka = this.o = 0;
            this.ua = !1;
            this.Y = this.U = this.L = 0;
            this.u = null;
            this.Aa = !1;
            this.sa = function() {};
            var a = document.querySelector("[data-google-query-id]");
            this.Ca = a ? a.getAttribute("data-google-query-id") : null
        },
        Li, Mi, Pi = function() {
            var a = new Ki;
            if (W(bi).g(Zf.g, Zf.defaultValue)) {
                var b = window;
                if (!b.google_plmetrics && window.PerformanceObserver) {
                    b.google_plmetrics = !0;
                    b = y(["layout-shift", "largest-contentful-paint", "first-input", "longtask", "event"]);
                    for (var c = b.next(); !c.done; c = b.next()) {
                        c = c.value;
                        var d = {
                            type: c,
                            buffered: !0
                        };
                        c === "event" && (d.durationThreshold = 40);
                        Ni(a).observe(d)
                    }
                    Oi(a)
                }
            }
        },
        Ni = function(a) {
            a.u || (a.u = new PerformanceObserver(Ai(640, function(b) {
                Qi(a, b)
            })));
            return a.u
        },
        Oi = function(a) {
            var b = Ai(641, function() {
                    var d = document;
                    if (d.prerendering) d = 3;
                    else {
                        var e;
                        d = (e = {
                            visible: 1,
                            hidden: 2,
                            prerender: 3,
                            preview: 4,
                            unloaded: 5,
                            "": 0
                        }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""]) != null ? e : 0
                    }
                    d === 2 && Ri(a)
                }),
                c = Ai(641, function() {
                    return void Ri(a)
                });
            document.addEventListener("visibilitychange", b);
            document.addEventListener("pagehide", c);
            a.sa = function() {
                document.removeEventListener("visibilitychange", b);
                document.removeEventListener("pagehide", c);
                Ni(a).disconnect()
            }
        },
        Ri = function(a) {
            if (!a.Aa) {
                a.Aa = !0;
                Ni(a).takeRecords();
                var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                window.LayoutShift && (b += Bi("cls", a.N), b += Bi("mls", a.V), b += Z("nls", a.X), window.LayoutShiftAttribution && (b += Bi("cas", a.C), b += Z("nas", a.za), b += Bi("was", a.Ea)), b += Bi("wls", a.ka), b += Bi("tls", a.Da));
                window.LargestContentfulPaint && (b += Z("lcp", a.xa), b += Z("lcps", a.wa));
                window.PerformanceEventTiming && a.ua && (b += Z("fid", a.ta));
                window.PerformanceLongTaskTiming && (b += Z("cbt", a.L), b += Z("mbt", a.U), b += Z("nlt", a.Y));
                for (var c = 0, d = y(document.getElementsByTagName("iframe")), e = d.next(); !e.done; e = d.next()) Di(e.value) && c++;
                b += Z("nif", c);
                c = window.google_unique_id;
                b += Z("ifi", typeof c === "number" ? c : 0);
                c = yh();
                b += "&eid=" + encodeURIComponent(c.join());
                b += "&top=" + (D === D.top ? 1 : 0);
                b += a.Ca ? "&qqid=" + encodeURIComponent(a.Ca) : Z("pvsid", de(D));
                window.googletag && (b += "&gpt=1");
                c = Math.min(a.g.length - 1, Math.floor((a.u ? a.va : performance.interactionCount || 0) / 50));
                c >= 0 && (c = a.g[c].latency, c >= 0 && (b += Z("inp", c)));
                window.fetch(b, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                });
                a.sa()
            }
        },
        Si = function(a, b, c, d) {
            if (!b.hadRecentInput) {
                a.N += Number(b.value);
                Number(b.value) > a.V && (a.V = Number(b.value));
                a.X += 1;
                if (c = Ei(b, c, d)) a.C += b.value, a.za++;
                if (b.startTime - a.ya > 5E3 || b.startTime - a.Ba > 1E3) a.ya = b.startTime, a.j = 0, a.l = 0;
                a.Ba = b.startTime;
                a.j += b.value;
                c && (a.l += b.value);
                a.j > a.ka && (a.ka = a.j, a.Ea = a.l, a.Da = b.startTime + b.duration)
            }
        },
        Qi = function(a, b) {
            var c = Li !== window.scrollX || Mi !== window.scrollY ? [] : Ti,
                d = Ui();
            b = y(b.getEntries());
            for (var e = b.next(), f = {}; !e.done; f = {
                    D: void 0
                }, e = b.next()) switch (f.D = e.value, e = f.D.entryType, e) {
                case "layout-shift":
                    Si(a, f.D, c, d);
                    break;
                case "largest-contentful-paint":
                    f = f.D;
                    a.xa = Math.floor(f.renderTime || f.loadTime);
                    a.wa = f.size;
                    break;
                case "first-input":
                    e = f.D;
                    a.ta = Number((e.processingStart - e.startTime).toFixed(3));
                    a.ua = !0;
                    a.g.some(function(g) {
                        return function(h) {
                            return v(h, "entries").some(function(k) {
                                return g.D.duration === k.duration && g.D.startTime === k.startTime
                            })
                        }
                    }(f)) || Vi(a, f.D);
                    break;
                case "longtask":
                    f = Math.max(0, f.D.duration - 50);
                    a.L += f;
                    a.U = Math.max(a.U, f);
                    a.Y += 1;
                    break;
                case "event":
                    Vi(a, f.D);
                    break;
                default:
                    Rb(e)
            }
        },
        Vi = function(a, b) {
            Wi(a, b);
            var c = a.g[a.g.length - 1],
                d = a.O[b.interactionId];
            if (d || a.g.length < 10 || b.duration > c.latency) d ? (v(d, "entries").push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
                id: b.interactionId,
                latency: b.duration,
                entries: [b]
            }, a.O[b.id] = b, a.g.push(b)), a.g.sort(function(e, f) {
                return f.latency - e.latency
            }), a.g.splice(10).forEach(function(e) {
                delete a.O[e.id]
            })
        },
        Wi = function(a, b) {
            b.interactionId && (a.W = Math.min(a.W, b.interactionId), a.o = Math.max(a.o, b.interactionId), a.va = a.o ? (a.o - a.W) / 7 + 1 : 0)
        },
        Ui = function() {
            var a = v(Array, "from").call(Array, document.getElementsByTagName("iframe")).filter(Di),
                b = [].concat(A(Ci())).map(function(c) {
                    return document.getElementById(c)
                }).filter(function(c) {
                    return c !== null
                });
            Li = window.scrollX;
            Mi = window.scrollY;
            return Ti = [].concat(A(a), A(b)).map(function(c) {
                return c.getBoundingClientRect()
            })
        },
        Ti = [];
    var Xi = function(a) {
        this.i = L(a)
    };
    x(Xi, U);
    Xi.prototype.getVersion = function() {
        return S(this, 2)
    };
    var Yi = function(a) {
        this.i = L(a)
    };
    x(Yi, U);
    var Zi = function(a, b) {
            return O(a, 2, pc(b))
        },
        $i = function(a, b) {
            return O(a, 3, pc(b))
        },
        aj = function(a, b) {
            return O(a, 4, pc(b))
        },
        bj = function(a, b) {
            return O(a, 5, pc(b))
        },
        cj = function(a, b) {
            return O(a, 9, pc(b))
        },
        dj = function(a, b) {
            return fd(a, 10, b)
        },
        ej = function(a, b) {
            return O(a, 11, b == null ? b : Xb(b))
        },
        fj = function(a, b) {
            return O(a, 1, pc(b))
        },
        gj = function(a, b) {
            return O(a, 7, b == null ? b : Xb(b))
        };
    var hj = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function ij(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function jj(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function kj(a) {
        if (!jj(a)) return null;
        var b = ij(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(hj).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function lj(a) {
        var b;
        return ej(dj(bj(Zi(fj(aj(gj(cj($i(new Yi, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new Xi;
            d = O(d, 1, pc(c.brand));
            return O(d, 2, pc(c.version))
        })) || []), a.wow64 || !1)
    }

    function mj(a) {
        var b, c;
        return (c = (b = kj(a)) == null ? void 0 : b.then(function(d) {
            return lj(d)
        })) != null ? c : null
    };
    var nj = function(a) {
        this.i = L(a)
    };
    x(nj, U);
    var oj = function(a) {
        this.i = L(a)
    };
    x(oj, U);
    var pj = function(a) {
        var b = new oj;
        return dd(b, 1, a)
    };

    function qj(a, b, c) {
        try {
            wb(!b._b_);
            var d = {
                d: K(a.data),
                p: a.lb
            };
            b._b_ = d
        } catch (e) {
            c.G({
                methodName: 1298,
                I: e
            })
        }
    };
    var rj = function(a, b, c) {
        this.g = a;
        this.M = b;
        this.j = c
    };
    rj.prototype.G = function(a) {
        var b = si(this.M.P, 1E3),
            c = ci(Wf),
            d = si(this.M.P, c);
        if (b || d) {
            var e = this.j,
                f = e.Qa,
                g = e.Pa,
                h = e.Ka,
                k = e.da,
                m = e.ab;
            e = e.Za;
            k = k();
            var n = a.I;
            try {
                var l = Ab(n == null ? void 0 : n.name) ? n.name : "Unknown error"
            } catch (z) {
                l = "e.name threw"
            }
            try {
                var p = Ab(n == null ? void 0 : n.message) ? n.message : "Caught " + n
            } catch (z) {
                p = "e.message threw"
            }
            try {
                var r = Ab(n == null ? void 0 : n.stack) ? n.stack : Error().stack;
                var t = r ? r.split(/\n\s*/) : []
            } catch (z) {
                t = ["e.stack threw"]
            }
            r = t;
            t = new Bf;
            t = pd(t, 5, 1E3);
            n = new zf;
            a = td(n, 1, a.methodName);
            a = rd(a, 2, l);
            a = rd(a, 3, p);
            a = Sc(a, 4, r, oc);
            a = Fc(a);
            a = ed(t, 1, Cf, a);
            l = new Af;
            f = pd(l, 1, f);
            f = Sc(f, 2, k, bc);
            g = rd(f, 3, g);
            g = Fc(g);
            g = dd(a, 2, g);
            g = Fc(g);
            g = Ec(g);
            f = new yf;
            h = rd(f, 1, h);
            m = m == null ? void 0 : m();
            m = od(h, 2, m);
            e = e == null ? void 0 : e();
            e = Sc(m, 3, e, oc);
            e = Fc(e);
            e = ed(g, 4, Df, e);
            b && this.g.rb(e);
            if (d) {
                pd(e, 5, c);
                a: {
                    Hc(e);
                    if (void 0 === vb) {
                        if (Zc(e, Cf, 1) !== 1) {
                            b = void 0;
                            break a
                        }
                    } else Wc(e.i, void 0, Cf, 1);b = $c(e, zf, 1)
                }
                b != null && O(b, 4);
                this.g.qb(e)
            }
        }
    };

    function sj(a) {
        var b = {};
        b = (b[0] = Uh(), b);
        W(vh).j(a, b)
    };
    var tj = {},
        uj = (tj[253] = !1, tj[246] = [], tj[150] = "", tj[263] = !1, tj[36] = /^true$/.test("false"), tj[172] = null, tj[260] = void 0, tj[251] = null, tj),
        vj = function() {
            this.g = !1
        };

    function wj(a) {
        W(vj).g = !0;
        return uj[a]
    }

    function xj(a, b) {
        W(vj).g = !0;
        uj[a] = b
    };
    var yj = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js)/;

    function zj(a) {
        var b = a.La;
        var c = a.hb;
        var d = a.Ra;
        var e = a.fb;
        var f = a.Xa;
        var g = a.bb;
        var h = b ? !yj.test(b.src) : !0;
        a = {};
        b = {};
        var k = {};
        return k[3] = (a[3] = function() {
            return !h
        }, a[59] = function() {
            var m = qa.apply(0, arguments),
                n = v(m, "includes"),
                l = String,
                p;
            var r = r === void 0 ? window : r;
            var t;
            r = (t = (p = Qh(r.location.href.match(Ph)[3] || null)) == null ? void 0 : p.split(".")) != null ? t : [];
            p = r.length < 2 ? null : (q = ["uk", "br", "nz", "mx"], v(q, "includes")).call(q, r[r.length - 1]) ? r.length < 3 ? null : Th(r.splice(r.length - 3).join(".")) : Th(r.splice(r.length - 2).join("."));
            return n.call(m, l(p))
        }, a[74] = function() {
            return v(qa.apply(0, arguments), "includes").call(qa.apply(0, arguments), String(Th(window.location.href)))
        }, a[61] = function() {
            return e
        }, a[63] = function() {
            return e || g === ".google.ch"
        }, a[73] = function(m) {
            return v(d, "includes").call(d, Number(m))
        }, a), k[4] = (b[1] = function() {
            return f
        }, b[13] = function() {
            return c
        }, b), k[5] = {}, k
    };

    function Aj(a, b) {
        if (W(bi).g(Xf.g, Xf.defaultValue)) {
            var c = function(d) {
                d.data != null && d.data !== "" || d.origin.indexOf("android-app://") !== 0 || (b(), a.removeEventListener("message", c))
            };
            a.addEventListener("message", c)
        }
    };

    function Bj(a) {
        return !(a == null || !a.src) && Qh(a.src.match(Ph)[3] || null) === "pagead2.googlesyndication.com"
    };
    var Cj = oa(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl.js"]),
        Dj = oa(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl.js"]);

    function Ej(a) {
        a = Bj(a) ? Zd(Cj, "m202602100101") : Zd(Dj, "m202602100101");
        var b = ci(ag);
        return b ? $d(a, new u.Map([
            ["cb", b]
        ])) : a
    };

    function Fj(a, b) {
        var c = wj(246);
        c = xc(c);
        c = wd(Lh, c);
        if (!R(c, Sg, 1, P()).length && R(a, Sg, 1, P()).length) {
            var d = R(a, Sg, 1, P());
            fd(c, 1, d)
        }!R(c, Jh, 2, P()).length && R(a, Jh, 2, P()).length && (d = R(a, Jh, 2, P()), fd(c, 2, d));
        !Mc(c, Kh, 5) && Mc(a, Kh, 5) && (a = Q(a, Kh, 5), dd(c, 5, a));
        xj(246, K(c));
        mi({
            Ya: c,
            A: zj(b),
            Fa: 2,
            config: {
                pa: b.pa
            }
        });
        b.Ra.forEach(xh)
    };
    var Gj = function(a, b, c) {
        rj.call(this, a, b, c);
        this.j = c
    };
    x(Gj, rj);
    var Hj = oa(["https://pagead2.googlesyndication.com/pagead/ppub_config"]),
        Ij = oa(["https://securepubads.g.doubleclick.net/pagead/ppub_config"]);

    function Jj(a, b, c, d, e) {
        a = a.location.host;
        var f = Sh(b.src, "domain");
        b = Sh(b.src, "network-code");
        if (a || f || b) {
            var g = new u.Map;
            a && g.set("ippd", a);
            f && g.set("pppd", f);
            b && g.set("pppnc", b);
            a = g
        } else a = void 0;
        a ? (c = c ? Zd(Hj) : Zd(Ij), c = $d(c, a), Kj(c, d, e)) : e(new u.globalThis.Error("no provided or inferred data"))
    }

    function Kj(a, b, c) {
        u.globalThis.fetch(a.toString(), {
            method: "GET",
            credentials: "omit"
        }).then(function(d) {
            d.status < 300 ? (yi("13", window), d.status === 204 ? b("") : d.text().then(function(e) {
                b(e)
            })) : c(new u.globalThis.Error("resp:" + d.status))
        }).catch(function(d) {
            d instanceof Error ? c(new u.globalThis.Error(d.message)) : c(new u.globalThis.Error("fetch error: " + d))
        })
    };
    var Lj = function(a, b, c) {
            this.M = a;
            this.ra = b;
            this.fa = c;
            this.g = []
        },
        Pj = function(a, b, c, d, e) {
            var f = e == null ? void 0 : zd(ad(e, yd, 1));
            (f == null ? 0 : f.length) && v(b.location.hostname, "includes").call(b.location.hostname, f) ? (Mj(a), Nj(a, {
                mb: e
            })) : (q = ["http:", "https:"], v(q, "includes")).call(q, b.location.protocol) ? c ? (Mj(a), Jj(Cd(b), c, d, function(g) {
                return void Nj(a, {
                    ob: g
                })
            }, function(g) {
                Nj(a, {
                    error: g
                })
            })) : Oj(a, 5) : Oj(a, 4)
        },
        Mj = function(a) {
            wj(260);
            xj(260, function(b) {
                a.j !== void 0 || a.l ? b(a.j, a.l) : a.g.push(b)
            })
        },
        Nj = function(a, b) {
            var c = b.ob;
            var d = b.mb;
            b = b.error;
            a.j = c != null ? c : d == null ? void 0 : JSON.stringify(K(d));
            a.l = b;
            d = y(a.g);
            for (var e = d.next(); !e.done; e = d.next()) e = e.value, e(a.j, a.l);
            a.g.length = 0;
            Oj(a, b ? 6 : c ? 3 : 2)
        },
        Oj = function(a, b) {
            var c = ci($f);
            si(a.M.P, c) && a.ra.ga.ja.ea.nb.J({
                K: c,
                source: b,
                Ua: !E("Android") || Na() || La() || Ka() || E("Silk") ? Na() ? 2 : (Ja() ? 0 : E("Edge")) ? 3 : La() ? 4 : (Ja() ? 0 : E("Trident") || E("MSIE")) ? 5 : !E("iPad") && !E("iPhone") || Ma() || Na() || (Ja() ? 0 : E("Coast")) || La() || !E("AppleWebKit") ? Ka() ? 6 : Ma() ? 7 : E("Silk") ? 8 : 0 : 9 : 1
            });
            a = a.fa;
            var d = ci($f);
            if (si(a.M.P, d)) {
                var e = a.j,
                    f = e.Ka,
                    g = e.da;
                c = e.Pa;
                e = e.Qa;
                var h = new xf;
                e = pd(h, 2, e);
                f = rd(e, 3, f);
                e = Math;
                h = e.trunc;
                a: {
                    if (u.globalThis.performance) {
                        var k = performance.timeOrigin + performance.now();
                        if (v(Number, "isFinite").call(Number, k) && k > 0) break a
                    }
                    k = Date.now();k = v(Number, "isFinite").call(Number, k) && k > 0 ? k : 0
                }
                f = pd(f, 1, h.call(e, k));
                g = g();
                g = Sc(f, 4, g, bc);
                d = pd(g, 5, d);
                c = rd(d, 6, c);
                d = new vf;
                g = new uf;
                b = sd(g, 1, b);
                b = Fc(b);
                b = ed(d, 10, wf, b);
                b = Fc(b);
                b = dd(c, 7, b);
                b = Fc(b);
                a.g.sb(b)
            }
        };
    var Qj = function(a) {
            return function(b) {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Expected jspb data to be an array, got " + xa(b) + ": " + b);
                ob(b, 34);
                return new a(b)
            }
        }(nj),
        Rj = function(a) {
            return function() {
                return a[gb] || (a[gb] = sc(a))
            }
        }(nj);

    function Sj(a, b) {
        try {
            var c = xb;
            if (!Ab(a)) {
                var d, e, f = (e = (d = typeof c === "function" ? c() : c) == null ? void 0 : d.concat("\n")) != null ? e : "";
                throw Error(f + String(a));
            }
            return Qj(a)
        } catch (g) {
            return b.G({
                methodName: 838,
                I: g
            }), Rj()
        }
    };

    function Tj() {
        var a;
        return (a = D.googletag) != null ? a : D.googletag = {
            cmd: []
        }
    }

    function Uj(a, b) {
        var c = Tj();
        c.hasOwnProperty(a) || (c[a] = b)
    };

    function Vj() {
        var a = sttc,
            b = Wj(),
            c = b.M,
            d = b.ra,
            e = b.fa;
        b = window;
        if (b.fetch) {
            si(c.P, 1E3) && d.ga.ja.ea.Ia.J({
                K: 1E3,
                Ma: !0
            });
            Ya(function(B) {
                e.G({
                    methodName: 1189,
                    I: B
                })
            });
            var f = Tj();
            a = Sj(a, e);
            wb(!W(vj).g);
            v(Object, "assign").call(Object, uj, f._vars_);
            f._vars_ = uj;
            a && (hd(a, 3) && xj(36, !0), S(a, 6) && xj(150, S(a, 6)), vi(ad(a, ti, 13)) && xj(263, !0));
            var g = ad(a, Lh, 1),
                h = {
                    fb: ui(ad(a, ti, 13)),
                    hb: id(a, 2),
                    Ra: Nc(a, 10, cc, P()),
                    Xa: id(a, 7),
                    bb: S(a, 6),
                    pa: hd(a, 4)
                },
                k = Q(a, Ad, 9),
                m = b.document;
            Uj("_loaded_", !0);
            Uj("cmd", []);
            var n, l = (n = Xj(m)) != null ? n : Yj(m);
            Zj(g, b, v(Object, "assign").call(Object, {}, {
                La: l
            }, h));
            try {
                Pi()
            } catch (B) {}
            yi("1", b);
            n = Ej(l);
            g = (l == null ? void 0 : l.crossOrigin) === "anonymous";
            h = ci(Yf);
            if (si(c.P, h)) {
                var p = d.ga.ja.ea;
                p.gb.J({
                    K: h,
                    oa: (l == null ? void 0 : l.crossOrigin) === "anonymous",
                    qa: Bj(l)
                });
                p.cb.J({
                    K: h,
                    oa: g,
                    qa: Qh(n.toString().match(Ph)[3] || null) === "pagead2.googlesyndication.com"
                })
            }
            var r = !1;
            qj({
                data: vd(pj(a)),
                lb: function() {
                    return r
                }
            }, f, e);
            if (!ak(m)) {
                h = "gpt-impl-" + Math.random();
                try {
                    Pd(m, Xd(n, {
                        id: h,
                        nonce: Md(document),
                        Ha: g ? "anonymous" : void 0
                    }))
                } catch (B) {}
                m.getElementById(h) && (f._loadStarted_ = !0)
            }
            if (!f._loadStarted_) {
                h = ce("SCRIPT");
                Nd(h, n);
                h.async = !0;
                g && (h.crossOrigin = "anonymous");
                n = m.body;
                g = m.documentElement;
                var t, z;
                ((z = (t = m.head) != null ? t : n) != null ? z : g).appendChild(h);
                f._loadStarted_ = !0
            }
            if (b === b.top) try {
                Fg(b, ad(a, ti, 13))
            } catch (B) {
                e.G({
                    methodName: 1209,
                    I: B
                })
            }
            Pj(new Lj(c, d, e), b, l, Bj(l), k);
            Aj(b, function() {
                r = !0
            });
            S(a, 14) && Jg(b.document, Kg(S(a, 14), Bj(l)), e)
        } else d.ga.ja.ea.Ia.J({
            K: 1,
            Ma: !1
        })
    }

    function Wj() {
        var a = de(window),
            b = new ri,
            c = new Tf(11, "m202602100101", 1E3, void 0, void 0, void 0, yh);
        return {
            ra: c,
            M: b,
            fa: new Gj(c, b, {
                Qa: a,
                Pa: window.document.URL,
                Ka: "m202602100101",
                da: yh
            })
        }
    }

    function Xj(a) {
        return (a = a.currentScript) ? a : null
    }

    function Yj(a) {
        var b;
        a = y((b = a.scripts) != null ? b : []);
        for (b = a.next(); !b.done; b = a.next())
            if (b = b.value, v(b.src, "includes").call(b.src, "/tag/js/gpt")) return b;
        return null
    }

    function Zj(a, b, c) {
        xj(172, c.La);
        Fj(a, c);
        sj(12);
        sj(5);
        (a = mj(b)) && a.then(function(d) {
            return void xj(251, JSON.stringify(K(d)))
        });
        be(W(bi).l(bg.g, bg.defaultValue), b.document)
    }

    function ak(a) {
        var b = Xj(a);
        return a.readyState === "complete" || a.readyState === "loaded" || !(b == null || !b.async)
    };
    try {
        Vj()
    } catch (a) {
        try {
            Wj().fa.G({
                methodName: 420,
                I: a
            })
        } catch (b) {}
    };
}).call(this, "[[[[862291051,null,null,[]],[772510493,null,null,[1]],[null,7,null,[null,0.1]],[null,null,null,[],[[[4,null,83],[null,null,null,[\"1 bidderRequests.bids bidder userIdAsEids.source\",\"2 bidderRequests.bids.userIdAsEids source provider\",\"3 bidderRequests.bids bidder ortb2Imp.ext.tid?\",\"5 bidderRequests.bids bidder mediaTypes.banner\",\"6 bidderRequests.bids bidder mediaTypes.native?\",\"7 bidderRequests.bids bidder mediaTypes.video\",\"8 bidderRequests.bids bidder ortb2Imp.ext.gpid?\",\"9 bidderRequests.bids bidder ortb2.site.content.data.segment?\",\"10 bidderRequests.bids bidder ortb2.site.page\",\"11 bidderRequests.bids bidder ortb2.user.data.segment?\",\"12 bidderRequests.bids bidder ortb2.user.data.ext.segtax?\",\"13 bidsReceived adId creativeId\",\"14 bidderRequests.bids.userIdAsEids source uids.ext.provider\",\"15 bidderRequests.bids.userIdAsEids source uids.atype\",\"16 bidderRequests.bids.userIdAsEids source uids.length\",\"17 bidsReceived adId ttl\",\"18 bidsReceived adId meta.primaryCatId\",\"19 bidsReceived adId meta.secondaryCatIds\",\"26 bidderRequests.bids bidder transactionId\",\"27 bidderRequests.bids.userIdAsEids source mm\",\"28 bidderRequests.bids.userIdAsEids source matcher\",\"29 bidderRequests.bids.userIdAsEids source inserter\"]]]],657770675],[null,659575329,null,null,[[[4,null,83],[null,1]]]],[null,612427114,null,null,[[[4,null,83],[null,100]]]],[null,663827948,null,[null,-1]],[null,659579380,null,[null,-1],[[[4,null,83],[null,5000]]]],[null,659579379,null,[null,-1],[[[4,null,83],[null,60000]]]],[null,null,null,[null,null,null,[\"1 dbm\/(ad|clkk)\"]],[[[4,null,83],[null,null,null,[\"1 dbm\/(ad|clkk)\",\"2 (adsrvr|adserver)\\\\.org\/bid\/\",\"3 criteo.com\/(delivery|[a-z]+\/auction)\",\"4 yahoo.com\/bw\/[a-z]+\/imp\/\",\"5 (adnxs|adnxs-simple).com\/it\",\"6 amazon-adsystem.com\/[a-z\/]+\/impb\"]]]],655300591],[null,643045660,null,null,[[[4,null,83],[null,1]]]],[null,741624914,null,[null,100]],[null,612427113,null,[null,128]],[null,699982590,null,null,[[[4,null,83],[null,128]]]],[null,749055567,null,[null,100]],[null,732179314,null,[null,10]],[null,null,null,[],[[[4,null,83],[null,null,null,[\"1~version~~~\",\"2~installedModules~~~\",\"3~getConfig~~~enableSendAllBids\"]]]],822748682],[null,822748680,null,[null,100]],[null,578655462,null,[null,1000]],[736254283,null,null,[1]],[697841467,null,null,[1]],[null,704895900,null,[null,1000]],[null,770246397,null,[null,1000]],[null,826507539,null,[null,1000]],[null,797753679,null,[null,40]],[null,797753680,null,[null,160]],[null,797753681,null,[null,600]],[null,797753678,null,[null,20]],[null,815698561,null,[null,200]],[null,815698562,null,[null,40]],[829536667,null,null,[1]],[null,853402579,null,[null,100]],[847763316,null,null,[1]],[760666257,null,null,[1]],[null,758465301,null,[null,100]],[817685600,null,null,[1]],[null,815871886,null,[null,0.5]],[null,625028672,null,[null,100]],[null,629733890,null,[null,1000]],[null,695925491,null,[null,20]],[null,null,null,[],null,489560439],[null,null,null,[],null,505762507],[null,1921,null,[null,72]],[null,1920,null,[null,12]],[null,426169222,null,[null,1000]],[null,377289019,null,[null,10000]],[null,750987462,null,[null,10000]],[null,529,null,[null,20]],[null,573282293,null,[null,0.01]],[null,684553008,null,[null,100]],[776685356,null,null,[]],[45624259,null,null,[],[[[4,null,59,null,null,null,null,[\"2452487976\"]],[1]]]],[45627954,null,null,[1]],[45646888,null,null,[]],[45622305,null,null,[1]],[null,447000223,null,[null,0.01]],[360245597,null,null,[1]],[null,716359135,null,[null,10]],[null,716359138,null,[null,50]],[null,716359132,null,[null,100]],[null,716359134,null,[null,1000]],[null,716359137,null,[null,0.25]],[null,716359136,null,[null,10]],[null,716359133,null,[null,5]],[777553338,null,null,[1]],[777625444,null,null,[1]],[777355828,null,null,[1]],[null,729624435,null,[null,10000]],[null,794150638,null,[null,5000]],[null,729624436,null,[null,500]],[null,794664882,null,[null,0.5]],[842717298,null,null,[1]],[null,550718589,null,[null,250],[[[3,[[4,null,15,null,null,null,null,[\"22814497764\"]],[4,null,15,null,null,null,null,[\"6581\"]],[4,null,15,null,null,null,null,[\"18190176\"]],[4,null,15,null,null,null,null,[\"21881754602\"]],[4,null,15,null,null,null,null,[\"6782\"]],[4,null,15,null,null,null,null,[\"309565630\"]],[4,null,15,null,null,null,null,[\"22306534072\"]],[4,null,15,null,null,null,null,[\"7229\"]],[4,null,15,null,null,null,null,[\"28253241\"]],[4,null,15,null,null,null,null,[\"1254144\"]],[4,null,15,null,null,null,null,[\"21732118914\"]],[4,null,15,null,null,null,null,[\"5441\"]],[4,null,15,null,null,null,null,[\"162717810\"]],[4,null,15,null,null,null,null,[\"51912183\"]],[4,null,15,null,null,null,null,[\"23202586\"]],[4,null,15,null,null,null,null,[\"44520695\"]],[4,null,15,null,null,null,null,[\"1030006\"]],[4,null,15,null,null,null,null,[\"21830601346\"]],[4,null,15,null,null,null,null,[\"23081961\"]],[4,null,15,null,null,null,null,[\"21880406607\"]],[4,null,15,null,null,null,null,[\"93656639\"]],[4,null,15,null,null,null,null,[\"1020351\"]],[4,null,15,null,null,null,null,[\"5931321\"]],[4,null,15,null,null,null,null,[\"3355436\"]],[4,null,15,null,null,null,null,[\"22106840220\"]],[4,null,15,null,null,null,null,[\"22875833199\"]],[4,null,15,null,null,null,null,[\"32866417\"]],[4,null,15,null,null,null,null,[\"8095840\"]],[4,null,15,null,null,null,null,[\"71161633\"]],[4,null,15,null,null,null,null,[\"22668755367\"]],[4,null,15,null,null,null,null,[\"6177\"]],[4,null,15,null,null,null,null,[\"147246189\"]],[4,null,15,null,null,null,null,[\"22152718\"]],[4,null,15,null,null,null,null,[\"21751243814\"]],[4,null,15,null,null,null,null,[\"22013536576\"]],[4,null,15,null,null,null,null,[\"4444\"]],[4,null,15,null,null,null,null,[\"44890869\"]],[4,null,15,null,null,null,null,[\"248415179\"]],[4,null,15,null,null,null,null,[\"5293\"]],[4,null,15,null,null,null,null,[\"21675937462\"]],[4,null,15,null,null,null,null,[\"21726375739\"]],[4,null,15,null,null,null,null,[\"1002212\"]],[4,null,15,null,null,null,null,[\"6718395\"]]]],[null,500]]]],[null,575880738,null,[null,10]],[null,586681283,null,[null,100]],[null,45679761,null,[null,30000]],[null,732179799,null,[null,250]],[null,745376890,null,[null,1]],[null,745376891,null,[null,2]],[null,820769768,null,[null,1440]],[843772200,null,null,[1]],[null,635239304,null,[null,100]],[834298346,null,null,[1]],[801020663,null,null,[]],[801020662,null,null,[]],[788110566,null,null,[]],[null,740510593,null,[null,0.5]],[null,618260805,null,[null,10]],[752401957,null,null,null,[[[1,[[4,null,59,null,null,null,null,[\"473346114\"]]]],[1]]]],[null,532520346,null,[null,30]],[838459558,null,null,[1]],[null,723123766,null,[null,100]],[null,735866756,null,[null,100]],[834317941,null,null,[1]],[761958081,null,null,[1]],[null,758860411,null,[null,60]],[null,751161866,null,[null,30000]],[null,630428304,null,[null,100]],[730909248,null,null,null,[[[1,[[4,null,59,null,null,null,null,[\"473346114\"]]]],[1]]]],[746075837,null,null,[]],[null,624264750,null,[null,-1]],[759731353,null,null,[1]],[607106222,null,null,[1]],[null,398776877,null,[null,60000]],[null,374201269,null,[null,60000]],[null,371364213,null,[null,60000]],[null,682056200,null,[null,100]],[570764855,null,null,[]],[null,null,579921177,[null,null,\"control_1\\\\.\\\\d\"]],[null,570764854,null,[null,50]],[578725095,null,null,[1]],[null,836731937,null,[null,0.1]],[null,830548804,null,[null,1]],[791241077,null,null,[1]],[830573627,null,null,[1]],[null,null,null,[null,null,null,[\"enable_config_tab_in_pubconsole\"]],null,null,null,667640709],[850063930,null,null,[1]],[829106692,null,null,[1]],[377936516,null,null,[1]],[null,851417689,null,[null,1100]],[null,851417690,null,[null,0.5]],[null,599575765,null,[null,1000]],[null,null,2,[null,null,\"1-0-45\"]],[null,707091695,null,[null,100]],[null,626653285,null,[null,1000]],[null,626653286,null,[null,2]],[null,642407444,null,[null,10]],[null,844811789,null,[null,1000]],[null,741215712,null,[null,100]],[852467256,null,null,[1]],[853758703,null,null,[1]],[853232709,null,null,[1]],[738482525,null,null,[1]],[855280099,null,null,[1]],[855219597,null,null,[1]],[856794751,null,null,[1]],[855279818,null,null,[1]],[null,506394061,null,[null,100]],[null,733365673,null,[null,2],[[[4,null,59,null,null,null,null,[\"1282204929\"]],[null,1]]]],[null,null,null,[null,null,null,[\"95335247\"]],null,631604025],[null,694630217,null,[null,670]],[null,783316493,null,[null,4000]],[783316492,null,null,[1]],[null,null,null,[],null,489],[811042160,null,null,[1]],[null,754057781,null,null,[[[6,null,null,3,null,2],[null,2]]]],[392065905,null,null,null,[[[3,[[4,null,68],[4,null,83]]],[1]]]],[null,360245595,null,[null,500]],[null,762520832,null,[null,1000]],[null,715129739,null,[null,30]],[null,681088477,null,[null,100]],[813899658,null,null,[1]],[null,812862060,null,[null,1000]],[676934885,null,null,[1],[[[4,null,59,null,null,null,null,[\"4214592683\",\"3186860772\",\"2930824068\",\"4127372480\",\"3985777170\",\"2998550476\",\"1946945953\",\"2901923877\",\"1931583037\",\"733037847\",\"287365726\",\"396735883\",\"2445204049\"]],[]]]],[776823724,null,null,[]],[751082905,null,null,[1]],[null,861895050,null,[null,100]],[703102329,null,null,[1]],[703102335,null,null,[1]],[703102334,null,null,[1]],[703102333,null,null,[1]],[703102330,null,null,[1]],[703102332,null,null,[1]],[555237688,null,null,[1]],[555237686,null,null,[1]],[null,638742197,null,[null,500]],[399705355,null,null,[1]],[null,514795754,null,[null,2]],[null,697023992,null,[null,500]],[null,null,null,[null,null,null,[\"679602798\",\"965728666\",\"3786422334\",\"4071951799\"]],null,603422363],[590730356,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!1[0-1]\\\\d)(?!12[0-3])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[564724551,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[0-6])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[null,596918936,null,[null,500]],[null,607730666,null,[null,10]],[616896918,null,null,[1]],[767691923,null,null,[1]],[506738118,null,null,[1]],[null,null,null,[null,null,null,[\"AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"Amm8\/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq\/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A93bovR+QVXNx2\/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A1S5fojrAunSDrFbD8OfGmFHdRFZymSM\/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1\/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[1]]],[[3,[[null,[[1337,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]],[84,null,null,[1]],[188,null,null,[1]]]]]],[10,[[31088080],[31088081]]],[10,[[83322595],[83322596]],null,136],[50,[[83322745],[83322746]],null,136],[10,[[95383157],[95383170,[[785049535,null,null,[1]],[null,788997299,null,[null,2]]]],[95383173,[[785049535,null,null,[1]],[null,788997299,null,[null,2]]]]],null,163],[1,[[95383172,[[null,788997299,null,[null,1]]]],[95383178],[95383179,[[null,788997299,null,[null,2]]]]],null,163],[null,[[676982960],[676982998]]]]],[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,59],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\",\"4\"]]],[10,[[95379823,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]],[95379824,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]],null,77]]],[9,[[1000,[[31083577]],[4,null,13,null,null,null,null,[\"cxbbhbxm\",\"hzwxrfqd\"]]]]],[5,[[1000,[[31084129,null,[2,[[2,[[8,null,null,1,null,-1],[7,null,null,1,null,10]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1000,[[31084130,null,[2,[[2,[[8,null,null,1,null,9],[7,null,null,1,null,20]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1,[[31095431],[31095432,[[null,784887894,null,[null,1]]]]]],[10,[[31096386],[31096387,[[808203838,null,null,[1]]]],[31096388,[[815806652,null,null,[1]]]],[31096389,[[815806756,null,null,[1]]]],[31096390,[[815806652,null,null,[1]],[815806756,null,null,[1]],[808203838,null,null,[1]]]]]],[100,[[31096592],[31096593,[[856794603,null,null,[1]]]]]],[1000,[[31096717,[[null,24,null,[null,31096717]]],[6,null,null,13,null,31096717]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31096718,[[null,24,null,[null,31096718]]],[6,null,null,13,null,31096718]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31096743,[[null,24,null,[null,31096743]]],[6,null,null,13,null,31096743]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31096744,[[null,24,null,[null,31096744]]],[6,null,null,13,null,31096744]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[10,[[31096749],[31096750,[[853365647,null,null,[1]]]]]],[10,[[31096751],[31096752,[[676934885,null,null,[1]]]]]],[100,[[31096753],[31096754,[[846803188,null,null,[1]]]]]],[10,[[31096761],[31096762,[[866170535,null,null,[1]]]]]],[10,[[31096763],[31096764,[[862407104,null,null,[1]]]]]],[100,[[95379659],[95379660,[[831440719,null,null,[1]],[822748685,null,null,[1]]]]]],[null,[[95381722],[95381723,[[842764578,null,null,[1]]]]]],[50,[[95382762],[95382763,[[850484730,null,null,[1]]]]]]]],[2,[[10,[[31084489],[31084490]],null,null,null,null,32,null,null,142,1],[1000,[[31084739,[[null,612427114,null,[null,100]]]]],[4,null,6,null,null,null,null,[\"31065645\",\"2\"]]],[10,[[31084865],[31084866]],null,null,null,null,35,null,null,166,1],[1000,[[31087377,null,[2,[[4,null,86],[4,null,6,null,null,null,null,[\"31065644\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1000,[[31087378,null,[2,[[4,null,86],[4,null,6,null,null,null,null,[\"31065645\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1000,[[31087490,null,[2,[[1,[[4,null,86]]],[4,null,6,null,null,null,null,[\"31065644\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1000,[[31087491,null,[2,[[1,[[4,null,86]]],[4,null,6,null,null,null,null,[\"31065645\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1,[[31095503],[31095504,[[45736287,null,null,[1]]]]],[1,[[4,null,61]]],null,null,null,null,null,null,232,1],[null,[[31096155],[31096156,[[815698560,null,null,[1]]]]],null,null,null,null,null,null,null,198,1],[null,[[31096448],[31096449,[[853911270,null,null,[1]]]],[31096488,[[853911270,null,null,[1]],[846803188,null,null,[1]]]]],null,null,null,null,null,500,null,198,1],[50,[[31096727,[[865532499,null,null,[1]]]],[31096728]],null,null,null,null,null,750,null,198,1],[50,[[83322598]],null,null,null,null,null,null,null,231,1],[50,[[83322599,[[813899658,null,null,[]]]]],null,null,null,null,null,50,null,231,1],[50,[[83322600]],null,null,null,null,null,100,null,231,1],[50,[[83322601]],null,null,null,null,null,150,null,231,1],[50,[[83322602]],null,null,null,null,null,200,null,231,1],[50,[[83322603]],null,null,null,null,null,250,null,231,1],[1,[[95365417,null,[4,null,92,null,null,null,null,[\"userId\"]]]]],[1,[[95365418,null,[4,null,92,null,null,null,null,[\"chromeAiRtdProvider\"]]]]],[50,[[95381655],[95381656,[[null,855937804,null,[null,3]],[851417688,null,null,[1]]]]],null,162],[1,[[95382216,null,[1,[[4,null,86]]]],[95382217,[[null,856365016,null,[null,30000]],[851417688,null,null,[1]]],[1,[[4,null,86]]]]],null,162],[10,[[95382368],[95382369,[[null,855937804,null,[null,1]],[851417688,null,null,[1]]]],[95382370,[[null,855937804,null,[null,5]],[851417688,null,null,[1]]]],[95382371,[[null,855937804,null,[null,10]],[851417688,null,null,[1]]]]],null,162]]],[27,[[50,[[31090502,null,[2,[[4,null,59,null,null,null,null,[\"1282204929\",\"2762681000\",\"1201683087\",\"1405537016\",\"1184328227\",\"3766824835\",\"107843290\",\"2849015825\",\"2285744699\",\"125820391\",\"1242812256\",\"2369380032\",\"3013643711\",\"77481481\",\"2269399977\",\"3906315807\",\"2791111070\",\"2128463204\",\"3298531905\",\"2399173495\",\"3986628766\",\"149255127\",\"896865192\",\"643747965\",\"1028035958\"]],[8,null,null,17,null,0]]]],[31090503,[[728394046,null,null,[1]]],[2,[[4,null,59,null,null,null,null,[\"1282204929\",\"2762681000\",\"1201683087\",\"1405537016\",\"1184328227\",\"3766824835\",\"107843290\",\"2849015825\",\"2285744699\",\"125820391\",\"1242812256\",\"2369380032\",\"3013643711\",\"77481481\",\"2269399977\",\"3906315807\",\"2791111070\",\"2128463204\",\"3298531905\",\"2399173495\",\"3986628766\",\"149255127\",\"896865192\",\"643747965\",\"1028035958\"]],[8,null,null,17,null,0]]]]]]]],[4,[[null,[[31095827],[31095828,[[729624434,null,null,[1]]]],[31095829,[[725693774,null,null,[1]]]],[31095830,[[775698922,null,null,[1]]]],[31095831,[[729624434,null,null,[1]],[725693774,null,null,[1]]]],[31095832,[[775698922,null,null,[1]],[729624434,null,null,[1]]]],[31095833,[[775698922,null,null,[1]],[725693774,null,null,[1]]]],[31095834,[[775698922,null,null,[1]],[729624434,null,null,[1]],[725693774,null,null,[1]]]]]],[null,[[44714449,[[null,7,null,[null,1]]]],[676982961,[[null,7,null,[null,0.4]],[212,null,null,[1]]]],[676982996,[[null,7,null,[null,1]]]]],null,78]]]],null,null,[null,1000,1,1000]],null,null,null,null,\".google.com.ph\",39,null,[[\"nba.com\",null,\"https:\/\/www.nba.com\/\",null,null,[\"129853887\",\"2117\",\"21622890900\",\"22784401475\",\"23278934576\",\"65889844\",\"67970281\",\"8663477\"]],[],[],null,[[null,null,null,[null,[\"8848288020558152080\"]]]],[[\"2117\",[[\"google.com\",null,1]]]],null,[[[\"1000648\",1],[\"10597297\",1],[\"1096601\",1],[\"112573735\",1],[\"117775582\",1],[\"129853887\",1],[\"146702834\",1],[\"162057381\",1],[\"2117\",1],[\"2148142\",1],[\"21622890900\",1],[\"21825036571\",1],[\"22220760\",1],[\"2266533\",1],[\"22784401475\",1],[\"23278934576\",1],[\"30577400\",1],[\"322090529\",1],[\"3446059\",1],[\"34981613\",1],[\"4126965\",1],[\"4635328\",1],[\"50347861\",1],[\"570780431\",1],[\"61584570\",1],[\"6499\",0],[\"6579959\",1],[\"65889844\",1],[\"67970281\",1],[\"75822427\",1],[\"81283550\",1],[\"8663477\",1],[\"90593245\",1]]],[[[\"1000648\",1],[\"10597297\",1],[\"1096601\",1],[\"112573735\",1],[\"117775582\",1],[\"129853887\",1],[\"146702834\",1],[\"162057381\",1],[\"2117\",1],[\"2148142\",1],[\"21622890900\",1],[\"21825036571\",1],[\"22220760\",1],[\"2266533\",1],[\"22784401475\",1],[\"23278934576\",1],[\"30577400\",1],[\"322090529\",1],[\"3446059\",1],[\"34981613\",1],[\"4126965\",1],[\"4635328\",1],[\"50347861\",1],[\"570780431\",1],[\"61584570\",1],[\"6499\",1],[\"6579959\",1],[\"65889844\",1],[\"67970281\",1],[\"75822427\",1],[\"81283550\",1],[\"8663477\",1],[\"90593245\",1]]],null,[[11239,1771222800],[44295,1771224000],[50575,1771225200],[54323,1771226400]],[1]],null,null,null,[0,0,0],\"m202602120101\"]")