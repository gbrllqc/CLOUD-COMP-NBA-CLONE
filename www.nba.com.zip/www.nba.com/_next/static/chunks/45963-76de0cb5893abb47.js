"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [45963], {
        30603: function(e, t, n) {
            var r = n(47568),
                i = n(34051),
                a = n.n(i),
                u = n(14648),
                s = "leaguestandingsv3",
                o = function(e) {
                    return {
                        standings: e.find((function(e) {
                            return "Standings" === e.name
                        })).rows
                    }
                },
                c = function() {
                    return {
                        standings: []
                    }
                },
                f = function() {
                    var e = (0, r.Z)(a().mark((function e(t) {
                        var n;
                        return a().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = {
                                        resource: s,
                                        transform: o,
                                        params: t,
                                        fail: c
                                    }, e.abrupt("return", u.Z.get(n));
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }();
            t.Z = {
                resource: s,
                transform: o,
                get: f,
                fail: c
            }
        },
        52884: function(e, t, n) {
            n.d(t, {
                Gu: function() {
                    return s
                },
                o$: function() {
                    return u
                }
            });
            var r = n(45697),
                i = n.n(r),
                a = i().shape({
                    name: i().string.isRequired,
                    label: i().string.isRequired,
                    options: i().arrayOf(i().shape({})),
                    selected: i().oneOfType([i().string, i().number]).isRequired,
                    isDefault: i().bool.isRequired,
                    placeholder: i().string,
                    disabled: i().bool,
                    showLabel: i().bool
                }),
                u = {
                    split: a.isRequired,
                    updateSplit: i().func.isRequired,
                    className: i().string,
                    disabled: i().bool,
                    showLabel: i().bool
                },
                s = {
                    splits: i().arrayOf(a).isRequired,
                    updateSplit: i().func.isRequired,
                    className: i().string,
                    label: i().string.isRequired,
                    disabled: i().bool
                }
        },
        28189: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return h
                }
            });
            var r = n(47568),
                i = n(14924),
                a = n(26042),
                u = n(69396),
                s = n(99534),
                o = n(10253),
                c = n(29815),
                f = n(34051),
                l = n.n(f),
                p = n(51695),
                d = n(11163),
                v = n(67294);

            function h(e) {
                var t = e.initialSplits,
                    n = void 0 === t ? {} : t,
                    f = e.autoRun,
                    h = void 0 === f ? [] : f,
                    m = e.onChange,
                    w = e.runOnMount,
                    g = void 0 !== w && w,
                    x = e.comboSplits,
                    k = void 0 === x ? [
                        []
                    ] : x,
                    y = function(e) {
                        return h.length > 0 && h.includes(e)
                    },
                    S = function(e) {
                        return k.length > 0 && k.some((function(t) {
                            return t.includes(e)
                        }))
                    },
                    R = (0, v.useRef)(g),
                    E = (0, d.useRouter)(),
                    q = E.query,
                    O = E.push,
                    j = (q.props, (0, s.Z)(q, ["props"])),
                    A = (0, v.useState)({}),
                    C = A[0],
                    N = A[1],
                    _ = (0, v.useMemo)((function() {
                        return function(e, t, n) {
                            if (!t) return e;
                            var r = (0, a.Z)({}, e);
                            return Object.entries(r).forEach((function(e) {
                                var i = (0, o.Z)(e, 2),
                                    s = i[0],
                                    c = i[1],
                                    f = c.def,
                                    l = void 0 === f ? "" : f,
                                    p = c.selected,
                                    d = void 0 === t[s] || t[s] === l,
                                    v = null !== p && void 0 !== p ? p : l;
                                void 0 !== n[s] ? v = n[s] : void 0 !== t[s] && (v = t[s]), r[s] = (0, u.Z)((0, a.Z)({}, c), {
                                    selected: v,
                                    isDefault: d
                                })
                            })), r
                        }(n, q, C)
                    }), [n, q, C]),
                    L = (0, v.useCallback)((function(e) {
                        return O({
                            pathname: window.location.pathname,
                            query: e
                        }, void 0, {
                            shallow: !0
                        })
                    }), [O]);
                if (!Array.isArray(k[0])) throw new Error("Invalid comboSplits value, must be string[][]");

                function P() {
                    return (P = (0, r.Z)(l().mark((function e(t, r) {
                        var s, o, f, p, d;
                        return l().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (void 0 !== n[t]) {
                                        e.next = 2;
                                        break
                                    }
                                    throw new Error('Attempting to update the split "'.concat(t, "\" but it doesn't exist"));
                                case 2:
                                    if (s = (0, a.Z)({}, C), o = (0, a.Z)({}, j), !S(t)) {
                                        e.next = 14;
                                        break
                                    }
                                    if (f = k.filter((function(e) {
                                            return e.includes(t)
                                        })).flat(), p = (0, c.Z)(new Set(f)), d = !1, p.forEach((function(e) {
                                            y(e) && (d = !0), e === t ? (o[e] = r, s[e] = r) : (o[e] = void 0, s[e] = void 0)
                                        })), !d) {
                                        e.next = 12;
                                        break
                                    }
                                    return e.next = 12, L(b(o));
                                case 12:
                                    return N(s), e.abrupt("return");
                                case 14:
                                    y(t) ? L((0, u.Z)((0, a.Z)({}, j), (0, i.Z)({}, t, r))) : N((function(e) {
                                        return (0, u.Z)((0, a.Z)({}, e), (0, i.Z)({}, t, r))
                                    }));
                                case 15:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))).apply(this, arguments)
                }

                function D() {
                    return (D = (0, r.Z)(l().mark((function e() {
                        var t;
                        return l().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return t = b((0, a.Z)({}, j, C)), e.next = 3, L(t);
                                case 3:
                                    N({});
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))).apply(this, arguments)
                }

                function H() {
                    return H = (0, r.Z)(l().mark((function e() {
                        var t;
                        return l().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (t = {}, 0 !== Object.keys(j).length) {
                                        e.next = 4;
                                        break
                                    }
                                    return N({}), e.abrupt("return");
                                case 4:
                                    return Object.entries(j).forEach((function(e) {
                                        var r = (0, o.Z)(e, 2),
                                            i = r[0],
                                            a = r[1];
                                        void 0 === n[i] && (t[i] = a)
                                    })), e.next = 7, L(t);
                                case 7:
                                    N({});
                                case 8:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    }))), H.apply(this, arguments)
                }

                function M() {
                    return (M = (0, r.Z)(l().mark((function e(t) {
                        var r, s, o;
                        return l().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (void 0 !== n[t]) {
                                        e.next = 2;
                                        break
                                    }
                                    throw new Error('Attempting to reset the split "'.concat(t, "\" but it doesn't exist"));
                                case 2:
                                    if (r = void 0 !== j[t], s = void 0 !== C[t], o = n[t].def, s && N(Z(t, C)), !r) {
                                        e.next = 10;
                                        break
                                    }
                                    if (void 0 === o) {
                                        e.next = 10;
                                        break
                                    }
                                    return e.next = 10, L((0, u.Z)((0, a.Z)({}, j), (0, i.Z)({}, t, o)));
                                case 10:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))).apply(this, arguments)
                }
                return (0, v.useEffect)((function() {
                    if (R && R.current) {
                        if (m) {
                            var e = {};
                            Object.values(n).forEach((function(t) {
                                var n, r = t.name,
                                    i = t.selected,
                                    a = void 0 === i ? "" : i;
                                e[r] = null !== (n = q[r]) && void 0 !== n ? n : a
                            })), m(e)
                        }! function(e, t) {
                            var n = {};
                            Object.values(e).forEach((function(e) {
                                var r = e.name,
                                    i = e.def,
                                    a = void 0 === i ? "" : i;
                                t[r] && t[r] !== a && (n[r] = t[r])
                            }));
                            var r = Object.entries(n).map((function(e) {
                                    var t = (0, o.Z)(e, 2),
                                        n = t[0],
                                        r = t[1];
                                    return "".concat(n, "=").concat(r)
                                })).join("; "),
                                i = Object.keys(n).length;
                            (0, p.uK)(r, i)
                        }(n, q)
                    }
                    return R.current = !0,
                        function() {}
                }), [q, m, n]), {
                    splits: _,
                    updateSplit: function(e, t) {
                        return P.apply(this, arguments)
                    },
                    runSplits: function() {
                        return D.apply(this, arguments)
                    },
                    resetSplit: function(e) {
                        return M.apply(this, arguments)
                    },
                    resetSplits: function() {
                        return H.apply(this, arguments)
                    }
                }
            }

            function b(e) {
                var t = (0, a.Z)({}, e);
                return Object.entries(t).forEach((function(e) {
                    var n = (0, o.Z)(e, 2),
                        r = n[0];
                    void 0 === n[1] && delete t[r]
                })), t
            }

            function Z(e, t) {
                var n = (0, a.Z)({}, t);
                return void 0 !== n[e] && delete n[e], n
            }
        },
        71522: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(26042),
                i = n(12474),
                a = function() {
                    var e = (0, i.x)().constants.season;
                    return (0, r.Z)({}, null === e || void 0 === e ? void 0 : e.pages, null === e || void 0 === e ? void 0 : e.stats)
                }
        },
        41912: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var r = n(47568),
                i = n(26042),
                a = n(34051),
                u = n.n(a),
                s = n(67294);

            function o(e) {
                var t = e.initialState,
                    n = e.hanaService,
                    a = e.parseResponse,
                    o = void 0 === a ? function(e) {
                        return e
                    } : a,
                    c = e.params,
                    f = void 0 === c ? {} : c,
                    l = (0, s.useState)(!1),
                    p = l[0],
                    d = l[1],
                    v = (0, s.useState)(t),
                    h = v[0],
                    b = v[1],
                    Z = (0, s.useState)(n.params || n.defaultParams || {}),
                    m = Z[0],
                    w = Z[1];

                function g() {
                    return (g = (0, r.Z)(u().mark((function e(t) {
                        var r, a;
                        return u().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (d(!0), n) {
                                        e.next = 3;
                                        break
                                    }
                                    throw new Error("Hana Service is missing");
                                case 3:
                                    if ("function" === typeof n.get) {
                                        e.next = 5;
                                        break
                                    }
                                    throw new Error("Requested Hana Service is missing a .get function");
                                case 5:
                                    return e.next = 7, n.get((0, i.Z)({}, t, f));
                                case 7:
                                    r = e.sent, r && r.error ? b(null) : (a = o ? o(r) : r, b(a)), w((0, i.Z)({}, n.params, n.defaultParams, t, f)), d(!1);
                                case 12:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))).apply(this, arguments)
                }
                return {
                    stats: h,
                    getStats: function(e) {
                        return g.apply(this, arguments)
                    },
                    statsParams: m,
                    isStatsLoading: p,
                    isStatsReady: void 0 !== h
                }
            }
        }
    }
]);