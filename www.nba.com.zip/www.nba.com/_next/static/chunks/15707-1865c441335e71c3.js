(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [15707], {
        2433: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return g
                }
            });
            var n = i(26042),
                a = i(69396),
                s = i(99534),
                o = i(85893),
                r = i(93967),
                l = i.n(r),
                c = i(45697),
                d = i.n(c),
                p = {
                    children: d().node,
                    className: d().string,
                    noPadding: d().bool,
                    maxWidth: d().oneOf(["xs", "sm", "md", "lg", "xl", "xxl"]),
                    adSlot: d().bool
                },
                m = i(10514),
                u = i.n(m);

            function g(e) {
                var t = e.adSlot,
                    i = void 0 !== t && t,
                    r = e.children,
                    c = e.className,
                    d = e.maxWidth,
                    p = void 0 === d ? "xl" : d,
                    m = e.noPadding,
                    g = void 0 !== m && m,
                    h = (0, s.Z)(e, ["adSlot", "children", "className", "maxWidth", "noPadding"]);
                return (0, o.jsx)("div", (0, a.Z)((0, n.Z)({
                    className: l()(u().mwc, c),
                    "data-padding": !g,
                    "data-ad-slot": i,
                    "data-max-width": p
                }, h), {
                    children: r
                }))
            }
            g.propTypes = p
        },
        97847: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return c
                }
            });
            var n = i(26042),
                a = i(85893),
                s = i(9008),
                o = i.n(s),
                r = i(67724),
                l = i(11163);

            function c(e) {
                var t, i = e.title,
                    s = void 0 === i ? "" : i,
                    c = e.description,
                    d = void 0 === c ? "" : c,
                    p = e.seo,
                    m = e.children,
                    u = void 0 === m ? null : m,
                    g = e.featuredImage,
                    h = void 0 === g ? null : g,
                    f = e.isHomePage,
                    _ = void 0 !== f && f,
                    x = e.overrideCanonicalUrl,
                    b = void 0 === x ? "" : x,
                    v = e.excerpt,
                    y = (0, l.useRouter)(),
                    T = null === y || void 0 === y || null === (t = y.asPath) || void 0 === t ? void 0 : t.split("?")[0],
                    N = "https://".concat(r.$g).concat(T),
                    j = "".concat(s, " ").concat(r.Ti).trim(),
                    w = !!(p && Array.isArray(p) && p.length),
                    A = w && p.find((function(e) {
                        return "og:title" === e.name
                    })),
                    k = A ? A.content : j,
                    P = w && p.find((function(e) {
                        return "description" === e.name
                    })),
                    Z = w && p.find((function(e) {
                        return "og:image" === e.name
                    })),
                    S = "".concat(r.$, "/logos/nba/fallback/NBA.Com-National-Basketball-Association.png"),
                    L = w && p.find((function(e) {
                        return "noindex" === e.name
                    })),
                    E = w && p.find((function(e) {
                        return "canonical" === e.name
                    })),
                    C = N;
                E ? C = E.content : b && (C = b);
                return (0, a.jsxs)(o(), {
                    children: [(0, a.jsx)("title", {
                        children: k
                    }), d && !P && (0, a.jsx)("meta", {
                        name: "description",
                        content: d
                    }), _ && (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("meta", {
                            property: "og:title",
                            content: "The official site of the NBA for the latest NBA Scores, Stats & News. | NBA.com"
                        }), (0, a.jsx)("meta", {
                            property: "og:url",
                            content: "https://www.nba.com"
                        }), (0, a.jsx)("meta", {
                            property: "og:locale",
                            content: "en_US"
                        }), (0, a.jsx)("meta", {
                            name: "description",
                            content: "Follow the action on NBA scores, schedules, stats, news, teams, and players. Buy tickets or watch the games anywhere with NBA League Pass."
                        }), (0, a.jsx)("meta", {
                            property: "og:image",
                            content: "https://cdn.nba.com/next/fallback.jpg"
                        }), (0, a.jsx)("meta", {
                            property: "og:type",
                            content: "website"
                        }), (0, a.jsx)("meta", {
                            name: "twitter:site",
                            content: "@NBA"
                        }), (0, a.jsx)("meta", {
                            name: "twitter:card",
                            content: "summary_large_image"
                        })]
                    }), (0, a.jsx)("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    }), (0, a.jsx)("link", {
                        rel: "icon",
                        type: "image/png",
                        sizes: "32x32",
                        href: "/favicon-32x32.png"
                    }), (0, a.jsx)("link", {
                        rel: "icon",
                        type: "image/png",
                        sizes: "16x16",
                        href: "/favicon-16x16.png"
                    }), (0, a.jsx)("link", {
                        rel: "apple-touch-icon",
                        href: "/apple-touch-icon.png"
                    }), (0, a.jsx)("link", {
                        rel: "apple-touch-icon",
                        sizes: "180x180",
                        href: "/apple-touch-icon.png"
                    }), (0, a.jsx)("link", {
                        rel: "apple-touch-icon",
                        sizes: "120x120",
                        href: "/apple-touch-icon.png"
                    }), (0, a.jsx)("link", {
                        href: "/apple-touch-icon.png"
                    }), (0, a.jsx)("meta", {
                        name: "msapplication-TileColor",
                        content: "#da532c"
                    }), (0, a.jsx)("meta", {
                        property: "og:site_name",
                        content: "NBA"
                    }), (0, a.jsx)("link", {
                        rel: "mask-icon",
                        href: "/safari-pinned-tab.svg",
                        color: "#051c2d"
                    }), (0, a.jsx)("link", {
                        rel: "canonical",
                        href: C
                    }), w && p.map((function(e) {
                        return (0, a.jsx)("meta", (0, n.Z)({}, e), e.name)
                    })), !Z && h && (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("meta", {
                            property: "og:image",
                            content: h
                        }), (0, a.jsx)("meta", {
                            name: "twitter:card",
                            property: "twitter:card",
                            content: "summary_large_image"
                        }), (0, a.jsx)("meta", {
                            name: "twitter:title",
                            property: "twitter:title",
                            content: s
                        }), (0, a.jsx)("meta", {
                            name: "twitter:image",
                            property: "twitter:image",
                            content: h
                        }), (0, a.jsx)("meta", {
                            name: "twitter:image:alt",
                            content: s
                        }), (0, a.jsx)("meta", {
                            name: "twitter:description",
                            content: v
                        }), (0, a.jsx)("meta", {
                            name: "twitter:site",
                            content: "@NBA"
                        })]
                    }), !Z && !h && (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("meta", {
                            property: "og:image",
                            content: S
                        }), (0, a.jsx)("meta", {
                            property: "twitter:image",
                            content: S
                        })]
                    }), L && (0, a.jsx)("meta", {
                        name: "robots",
                        content: "noindex, nofollow"
                    }), u]
                }, "page-meta")
            }
        },
        58819: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return b
                }
            });
            var n, a = i(85893),
                s = i(93967),
                o = i.n(s),
                r = i(26042),
                l = i(99534),
                c = i(67294);

            function d() {
                return d = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var i = arguments[t];
                        for (var n in i)({}).hasOwnProperty.call(i, n) && (e[n] = i[n])
                    }
                    return e
                }, d.apply(null, arguments)
            }
            var p = e => c.createElement("svg", d({
                xmlns: "http://www.w3.org/2000/svg",
                width: 8,
                height: 9,
                viewBox: "0 0 8 9"
            }, e), n || (n = c.createElement("g", {
                fill: "none",
                fillRule: "evenodd"
            }, c.createElement("path", {
                d: "M0 0H8V8H0z",
                transform: "translate(0 1)"
            }), c.createElement("g", null, c.createElement("path", {
                fill: "currentColor",
                fillRule: "nonzero",
                d: "M1.153 2.667H.878c-.485 0-.878.36-.878.804v3.724C0 7.64.393 8 .878 8h5.058c.485 0 .878-.36.878-.805V3.471c0-.444-.393-.804-.878-.804H1.153zm3.709 0H1.939h2.923zm-1.01 2.618v.997c0 .229-.196.409-.445.409s-.446-.18-.446-.409v-.997c-.21-.132-.353-.348-.353-.6 0-.409.353-.733.799-.733.446 0 .8.324.8.733-.014.252-.145.468-.354.6z",
                transform: "translate(0 1) translate(.5)"
            }), c.createElement("path", {
                stroke: "currentColor",
                strokeWidth: 1.5,
                d: "M1.704 3.556V1.739C1.704 1.56 1.74 0 3.376 0s1.735 1.573 1.735 1.573V3.48",
                transform: "translate(0 1) translate(.5)"
            })))));

            function m(e) {
                var t = e.alt,
                    i = e.className,
                    n = e.role,
                    s = void 0 === n ? "presentation" : n,
                    o = e.style,
                    c = e.title,
                    d = (0, l.Z)(e, ["alt", "className", "role", "style", "title"]);
                return (0, a.jsx)(p, (0, r.Z)({
                    alt: t,
                    className: i,
                    "data-no-icon": !0,
                    role: s,
                    style: o,
                    title: c
                }, d))
            }
            var u = i(45697),
                g = i.n(u),
                h = {
                    propTypes: {
                        type: g().string,
                        subscribed: g().bool,
                        className: g().string
                    },
                    defaultProps: {
                        type: null,
                        className: "",
                        subscribed: !0
                    }
                },
                f = i(80428),
                _ = i.n(f),
                x = i(61971);

            function b(e) {
                var t = e.type,
                    i = e.subscribed,
                    n = e.className;
                if (!t || t === x.w.FREE) return null;
                var s = function(e) {
                    return {
                        tagText: (e.includes("local-access") ? x.A[x.w.LOCAL_ACCESS] : x.A[e]) || ""
                    }
                }(t).tagText;
                return (0, a.jsxs)("div", {
                    className: o()(_().tag, n),
                    "data-subtype": t,
                    children: [!i && (0, a.jsx)(m, {
                        className: _().lockIcon
                    }), s]
                })
            }
            b.propTypes = h.propTypes, b.defaultProps = h.defaultProps
        },
        29740: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return w
                }
            });
            var n = i(26042),
                a = i(69396),
                s = i(85893),
                o = i(93967),
                r = i.n(o),
                l = i(12185),
                c = i(41684),
                d = i(37346),
                p = i(58819),
                m = i(34180),
                u = i(44501),
                g = i.n(u),
                h = i(29717),
                f = i(18919),
                _ = i(93529),
                x = i(51966),
                b = i.n(x);

            function v() {
                return (0, s.jsx)("div", {
                    className: b().np,
                    children: (0, s.jsx)("p", {
                        className: b().npText,
                        children: "Now Playing"
                    })
                })
            }
            var y = i(45697),
                T = i.n(y),
                N = {
                    propTypes: {
                        analytics: T().oneOfType([T().shape({
                            articleType: T().oneOf(["homepage", "main", "side", "bottom", "latest", "latestSide", "collection", "podcast", "writer-archive", "quicklink", "newsstrip", "newsstripshort", "dazn", "tentpole-hub"]),
                            collectionName: T().string,
                            id: T().oneOfType([T().string, T().number]),
                            index: T().number,
                            totalArticles: T().number,
                            exclusiveTo: T().oneOfType([T().bool, T().string])
                        }), T().bool]),
                        category: T().string,
                        isLive: T().bool,
                        href: T().string.isRequired,
                        className: T().string,
                        img: T().string,
                        subfeatured: T().bool,
                        subtitle: T().string,
                        timestamp: T().oneOfType([T().string, T().number]),
                        title: T().string.isRequired,
                        shortTitle: T().string,
                        runtime: T().string,
                        type: T().oneOf(["post", "video", "podcast", "hyperlink", "page", "event", "nbabet", "dazn", "game"]),
                        imgSize: T().string,
                        noPadding: T().bool,
                        noFallbackImg: T().bool,
                        entitlements: T().oneOf(["nba-tv", "league-pass", "free", "", "league-pass-premium"]),
                        isWebView: T().bool,
                        template: T().oneOf(["default", "nbabet"]),
                        sponsor: T().oneOfType([T().shape({
                            sponsorUrl: T().string,
                            sponsorLogoUrl: T().string,
                            sponsorName: T().string
                        }), T().bool]),
                        activeVideo: T().string,
                        programId: T().string,
                        isClientSideRouting: T().bool,
                        isWatchPlaylist: T().bool,
                        taxonomy: T().object
                    },
                    defaultProps: {
                        analytics: {},
                        entitlements: "",
                        category: "",
                        isLive: !1,
                        subfeatured: !1,
                        img: "",
                        imgSize: void 0,
                        subtitle: "",
                        timestamp: "",
                        shortTitle: "",
                        runtime: "",
                        type: "post",
                        noPadding: !1,
                        noFallbackImg: !1,
                        className: "",
                        isWebView: !1,
                        template: "default",
                        sponsor: !1,
                        activeVideo: "",
                        programId: "",
                        isWatchPlaylist: !1,
                        taxonomy: {}
                    }
                },
                j = i(21227);

            function w(e) {
                var t = e.timestamp,
                    i = e.img,
                    o = e.imgSize,
                    u = e.subtitle,
                    x = e.title,
                    b = e.shortTitle,
                    y = e.href,
                    T = e.className,
                    N = e.category,
                    w = e.isLive,
                    A = e.runtime,
                    k = e.type,
                    P = e.analytics,
                    Z = e.subfeatured,
                    S = e.noPadding,
                    L = e.noFallbackImg,
                    E = e.entitlements,
                    C = e.sponsor,
                    V = e.activeVideo,
                    B = e.programId,
                    M = e.isClientSideRouting,
                    I = e.isWatchPlaylist,
                    R = e.taxonomy,
                    z = (0, f.Z)(k),
                    U = z.isVideo,
                    O = z.isPodcast,
                    H = (0, h.Z)((0, a.Z)((0, n.Z)({}, P), {
                        title: x,
                        exclusiveTo: !1,
                        isVideo: U,
                        shortTitle: b,
                        sponsor: C,
                        category: N,
                        taxonomy: R,
                        type: k,
                        isLive: w
                    })),
                    F = (0, f.e)(P),
                    W = C || {},
                    D = W.sponsorName,
                    G = W.sponsorLogoUrl,
                    q = W.sponsorUrl,
                    Y = !!(G && q && D);
                Y && H && (C && C.sponsorName && (H["data-text"] = C.sponsorName), H["data-section-pos"] = 1, H["data-content"] = x);
                var X = (0, n.Z)({}, P, {
                        title: x,
                        section: P.collectionName
                    }),
                    J = (0, j.Z)();
                return (0, s.jsx)("div", {
                    className: r()(g().tile, T),
                    "data-padding": !S,
                    "data-featured": Z,
                    "data-podcast": O,
                    "data-sponser": Y,
                    children: (0, s.jsxs)("article", {
                        className: g().tileArticle,
                        children: [!L && (0, s.jsx)(c.Z, (0, a.Z)((0, n.Z)({
                            title: "Article link for ".concat(x)
                        }, H), {
                            href: y,
                            className: g().tileThumnailLink,
                            isClientSideRouting: M,
                            children: (0, s.jsxs)("div", {
                                className: g().tileImage,
                                children: [V && V === B && (0, s.jsx)(v, {}), (0, s.jsx)(l.Z, {
                                    className: g().tileThumbnail,
                                    disabled: !U,
                                    src: i,
                                    imgSize: o,
                                    alt: x,
                                    runtime: A,
                                    height: "100%",
                                    "data-type": "image",
                                    iconSize: 24
                                })]
                            })
                        })), (0, s.jsxs)("div", {
                            className: g().tileMain,
                            children: [(0, s.jsx)("div", {
                                className: g().tileMainContent,
                                children: (0, s.jsx)(c.Z, (0, a.Z)((0, n.Z)({
                                    title: "Article link for ".concat(x)
                                }, H), {
                                    href: y,
                                    className: g().tileHeadlineLink,
                                    isClientSideRouting: M,
                                    children: (0, s.jsxs)("header", {
                                        "data-type": "headline",
                                        children: [(N && F || O) && (0, s.jsx)(d.Z, {
                                            is: "h4",
                                            text: O ? "podcast" : N,
                                            className: g().tileCat
                                        }), (0, s.jsx)(d.Z, {
                                            is: "h4",
                                            className: g().tileTitle,
                                            text: b || x,
                                            maxLines: 3
                                        }), u && (0, s.jsx)(d.Z, {
                                            is: "p",
                                            className: g().tileSub,
                                            text: u,
                                            maxLines: 2
                                        })]
                                    })
                                }))
                            }), (0, s.jsxs)("div", {
                                className: g().tileMeta,
                                children: [(0, s.jsxs)(c.Z, (0, a.Z)((0, n.Z)({
                                    title: "Article link for ".concat(x)
                                }, H), {
                                    href: y,
                                    className: g().tileMetaLink,
                                    isClientSideRouting: M,
                                    children: [(0, s.jsx)(p.Z, {
                                        type: E,
                                        className: g().tileSubscription
                                    }), J ? t && !I && (0, s.jsx)("div", {
                                        className: g().tileTimestamp,
                                        children: (0, m.k)(t)
                                    }) : (0, s.jsx)("div", {
                                        className: r()(g().tileTimestampSkeleton, g().tileTimestamp)
                                    })]
                                })), Y && (0, s.jsx)(_.Z, {
                                    sponsor: C,
                                    analytics: X
                                })]
                            })]
                        })]
                    })
                })
            }
            w.propTypes = N.propTypes, w.defaultProps = N.defaultProps
        },
        93529: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return g
                }
            });
            var n = i(26042),
                a = i(69396),
                s = i(85893),
                o = i(7410),
                r = i(41684),
                l = i(9849),
                c = i(45697),
                d = i.n(c),
                p = {
                    propTypes: {
                        sponsor: d().shape({
                            sponsorUrl: d().string,
                            sponsorName: d().string,
                            sponsorLogoUrl: d().string
                        }),
                        height: d().number,
                        width: d().number,
                        text: d().string,
                        analytics: d().shape(),
                        noBullet: d().bool
                    },
                    defaultProps: {
                        sponsor: {
                            sponsorUrl: "",
                            sponsorName: "",
                            sponsorLogoUrl: ""
                        },
                        height: 13,
                        width: 78,
                        text: "Published by",
                        analytics: {},
                        noBullet: !1
                    }
                },
                m = i(84919),
                u = i.n(m);

            function g(e) {
                var t = e.sponsor,
                    i = e.height,
                    c = e.width,
                    d = e.text,
                    p = e.analytics,
                    m = e.noBullet,
                    g = (0, l.BP)({
                        content: p.title || "",
                        contentId: p.id,
                        pos: p.index + 1,
                        sectionPos: p.sectionPosition,
                        sponsor: t.sponsorName,
                        section: p.section
                    });
                return (0, s.jsxs)("div", {
                    className: u().pa,
                    children: [!m && (0, s.jsx)("span", {
                        className: u().paBullet,
                        children: "\u2b24"
                    }), (0, s.jsx)("span", {
                        className: u().paSpan,
                        "data-has-bullet": !m,
                        children: d
                    }), (0, s.jsx)(r.Z, (0, a.Z)((0, n.Z)({
                        href: t.sponsorUrl
                    }, g), {
                        children: (0, s.jsx)(o.Z, {
                            src: t.sponsorLogoUrl,
                            alt: t.sponsorName,
                            style: {
                                width: c,
                                height: i
                            }
                        })
                    }))]
                })
            }
            g.propTypes = p.propTypes, g.defaultProps = p.defaultProps
        },
        18919: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return a
                },
                e: function() {
                    return o
                }
            });
            var n = i(92033);

            function a(e) {
                var t = {
                    isHyperLink: !1,
                    isPage: !1,
                    isPodcast: !1,
                    isPost: !1,
                    isVideo: !1
                };
                switch (e) {
                    case "hyperlink":
                        t.isHyperLink = !0;
                        break;
                    case "page":
                        t.isPage = !0;
                        break;
                    case "podcast":
                        t.isPodcast = !0;
                        break;
                    case "dazn":
                    case "nbabet":
                    case "post":
                        t.isPost = !0;
                        break;
                    case "video":
                    case "event":
                        t.isVideo = !0;
                        break;
                    default:
                        console.warn("Unexpected article type of: ", e)
                }
                return t
            }
            var s = ["latestSide"],
                o = function(e) {
                    return s.includes((0, n.Z)(["articleType"], e))
                }
        },
        29717: function(e, t, i) {
            "use strict";
            var n = i(26042),
                a = i(11163),
                s = i(92033),
                o = i(9849),
                r = i(3542),
                l = i(6277),
                c = ["writer-archive", "podcast"],
                d = {
                    "/news/[...article]": "newsArticle",
                    "/nbabet/[...article]": "nbabetNewsArticle",
                    "/fantasy": "fantasy",
                    "/news": "newsMain",
                    "/news/category/[collection]": "newsCollection",
                    "/news/writers-archive/[id]/[name]": "writerCollection",
                    "/nbabet": "nbabetMain",
                    "/webview/nbabet": "nbabetMain",
                    "/webview/nbabet/[...article]": "nbabetNewsArticle"
                };
            t.Z = function(e) {
                var t = (0, a.useRouter)(),
                    i = e || {},
                    p = i.articleType,
                    m = i.collectionName,
                    u = i.index,
                    g = i.id,
                    h = i.title,
                    f = i.exclusiveTo,
                    _ = i.isVideo,
                    x = i.sectionPosition,
                    b = i.componentType,
                    v = i.shortTitle,
                    y = i.sponsor,
                    T = i.category,
                    N = i.taxonomy,
                    j = i.type,
                    w = i.isLive,
                    A = i.totalArticles,
                    k = (0, s.Z)(["route"], t);
                if (!e || !p || !k) return {};
                var P = (0, s.Z)(["asPath"], t),
                    Z = d[k] || "tentpole";
                if ("homepage" === p) return (0, o._v)({
                    isVideo: _,
                    index: u,
                    id: g,
                    isPremium: f,
                    title: h,
                    isHome: "/" === P,
                    collectionName: m,
                    sectionPosition: x,
                    componentType: b,
                    shortTitle: v,
                    type: j,
                    isLive: w,
                    category: T,
                    taxonomy: N
                });
                if (c.includes(p)) return (0, o.J6)({
                    articleType: p,
                    id: g,
                    title: h,
                    index: u
                });
                var S = (0, s.Z)([Z, p], (0, o.oR)({
                        collectionName: m || Z
                    })) || {},
                    L = S.dataId,
                    E = S.dataType,
                    C = S.section;
                return (0, n.Z)({
                    "data-track": _ ? "video" : "click",
                    "data-type": E,
                    "data-id": _ && "fantasy" === Z ? "nba:fantasy:hero" : L,
                    "data-pos": "".concat(Number(u + 1), "/").concat(Number(A)),
                    "data-section": m ? (0, r.Z)(null === m || void 0 === m ? void 0 : m.replaceAll("'", "")) : C,
                    "data-section-pos": x,
                    "data-content": v || h,
                    "data-content-id": g,
                    "data-premium": f ? "true" : "false"
                }, y && {
                    "data-text": y.sponsorName
                }, _ && {
                    "data-franchise": (0, l.Z)(N),
                    "data-cat-type": T || "",
                    "data-live-vod": "event" === j && w ? "live" : "vod"
                })
            }
        },
        12185: function(e, t, i) {
            "use strict";
            i.d(t, {
                Z: function() {
                    return u
                }
            });
            var n = i(26042),
                a = i(69396),
                s = i(99534),
                o = i(85893),
                r = i(93967),
                l = i.n(r),
                c = i(7410),
                d = i(86414),
                p = i(17194),
                m = i.n(p);

            function u(e) {
                var t = e.src,
                    i = void 0 === t ? "" : t,
                    r = e.imgSize,
                    p = e.runtime,
                    u = e.iconSize,
                    g = void 0 === u ? 30 : u,
                    h = e.className,
                    f = e.height,
                    _ = void 0 === f ? "100%" : f,
                    x = e.alt,
                    b = void 0 === x ? "" : x,
                    v = e.isHero,
                    y = void 0 !== v && v,
                    T = e.disabled,
                    N = void 0 !== T && T,
                    j = (0, s.Z)(e, ["src", "imgSize", "runtime", "iconSize", "className", "height", "alt", "isHero", "disabled"]),
                    w = y ? m().heroBase : null,
                    A = y ? m().heroRuntime : null,
                    k = y ? 50 : g,
                    P = {
                        height: k,
                        width: k
                    };
                return (0, o.jsxs)("figure", (0, a.Z)((0, n.Z)({}, j), {
                    className: l()(m().figure, h),
                    style: {
                        height: _
                    },
                    children: [(0, o.jsx)(c.Z, {
                        src: i,
                        alt: b,
                        size: r,
                        className: m().image
                    }), !N && (0, o.jsxs)("div", {
                        className: l()(m().base, w),
                        children: [(0, o.jsx)(d.Z, {
                            style: P
                        }), p ? (0, o.jsx)("span", {
                            className: l()(m().runtime, A),
                            children: p
                        }) : (0, o.jsx)(o.Fragment, {})]
                    })]
                }))
            }
        },
        61971: function(e, t, i) {
            "use strict";
            i.d(t, {
                A: function() {
                    return o
                },
                w: function() {
                    return s
                }
            });
            var n, a = i(14924),
                s = {
                    NBA_TV: "nba-tv",
                    LEAGUE_PASS: "league-pass",
                    LEAGUE_PASS_PREMIUM: "league-pass-premium",
                    MEMBER_GATED: "member-gated",
                    VIVO: "vivo",
                    FREE: "free",
                    FIBA_WORLD_CUP: "fiba-world-cupgp",
                    LOCAL_ACCESS: "local-access",
                    TVE_LP: "tve-lp",
                    TVE_NBA_TV: "tve-nba-tv",
                    NONE: "none"
                },
                o = (n = {}, (0, a.Z)(n, s.NBA_TV, "League Pass"), (0, a.Z)(n, s.LEAGUE_PASS, "League Pass"), (0, a.Z)(n, s.LEAGUE_PASS_PREMIUM, "League Pass"), (0, a.Z)(n, s.MEMBER_GATED, "NBA ID"), (0, a.Z)(n, s.FIBA_WORLD_CUP, "World Cup Pass"), (0, a.Z)(n, s.VIVO, "Vivo"), n)
        },
        10514: function(e) {
            e.exports = {
                mwc: "MaxWidthContainer_mwc__ID5AG"
            }
        },
        80428: function(e) {
            e.exports = {
                tag: "SubscriptionTag_tag__mx_8c",
                lockIcon: "SubscriptionTag_lockIcon__TFSBk"
            }
        },
        44501: function(e) {
            e.exports = {
                tile: "ArticleTile_tile__y70gI",
                tileImage: "ArticleTile_tileImage__no39y",
                tileMain: "ArticleTile_tileMain__cXeUE",
                tileMainContent: "ArticleTile_tileMainContent__c_bU1",
                tileArticle: "ArticleTile_tileArticle__XV7_D",
                tileThumnailLink: "ArticleTile_tileThumnailLink__g_e9w",
                tileHeadlineLink: "ArticleTile_tileHeadlineLink__9Ed4y",
                tileTitle: "ArticleTile_tileTitle__aA8g7",
                tileSub: "ArticleTile_tileSub__kiMA0",
                tileCat: "ArticleTile_tileCat__YILNy",
                tileThumbnail: "ArticleTile_tileThumbnail__Frz_J",
                tileSubscription: "ArticleTile_tileSubscription__LSTyu",
                tileMeta: "ArticleTile_tileMeta__D6w6A",
                tileTimestamp: "ArticleTile_tileTimestamp__xz7Ky",
                tileTimestampSkeleton: "ArticleTile_tileTimestampSkeleton__Llte2",
                tileMetaLink: "ArticleTile_tileMetaLink__tmnHx",
                featured: "ArticleTile_featured__6PTK6",
                subfeatured: "ArticleTile_subfeatured__jqvgT",
                newsHeroFeature: "ArticleTile_newsHeroFeature__bpQ89",
                newsHeroSubfeature: "ArticleTile_newsHeroSubfeature__yCu9M"
            }
        },
        51966: function(e) {
            e.exports = {
                np: "NowPlaying_np__76jdh",
                npText: "NowPlaying_npText__4sygn"
            }
        },
        84919: function(e) {
            e.exports = {
                pa: "PartnerAttribution_pa__yWFrn",
                paSpan: "PartnerAttribution_paSpan__OFnRR",
                paBullet: "PartnerAttribution_paBullet__YwYi0"
            }
        },
        17194: function(e) {
            e.exports = {
                figure: "VideoThumbnail_figure__IaI8E",
                image: "VideoThumbnail_image__fa2Go",
                base: "VideoThumbnail_base__qYWav",
                heroBase: "VideoThumbnail_heroBase__RUEfW",
                runtime: "VideoThumbnail_runtime__dD_GO",
                heroRuntime: "VideoThumbnail_heroRuntime__gIM_X"
            }
        }
    }
]);