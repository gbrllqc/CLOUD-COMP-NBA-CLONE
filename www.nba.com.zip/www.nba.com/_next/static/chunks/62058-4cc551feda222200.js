"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [62058], {
        62058: function(e, t, a) {
            a.d(t, {
                Z: function() {
                    return Ce
                }
            });
            var n = {};
            a.r(n), a.d(n, {
                AheadBehind: function() {
                    return r
                },
                CloseDefDistRange: function() {
                    return c
                },
                ClutchTime: function() {
                    return u
                },
                College: function() {
                    return v
                },
                Conference: function() {
                    return p
                },
                Country: function() {
                    return x.Z
                },
                DateFrom: function() {
                    return S
                },
                DateTo: function() {
                    return h
                },
                DefenseCategory: function() {
                    return f
                },
                Direction: function() {
                    return m
                },
                DistanceRange: function() {
                    return y
                },
                Division: function() {
                    return T.Z
                },
                DraftPick: function() {
                    return g
                },
                DraftYear: function() {
                    return b
                },
                DribbleRange: function() {
                    return P
                },
                EndPeriod: function() {
                    return A
                },
                EndRange: function() {
                    return k
                },
                GameScope: function() {
                    return M
                },
                GameSegment: function() {
                    return L
                },
                GeneralRange: function() {
                    return O
                },
                GroupQuantity: function() {
                    return D
                },
                Height: function() {
                    return R
                },
                ISTRound: function() {
                    return N
                },
                LastNGames: function() {
                    return F
                },
                LeagueID: function() {
                    return G.Z
                },
                Location: function() {
                    return V
                },
                Matchup: function() {
                    return w
                },
                Month: function() {
                    return B.Z
                },
                OpponentTeamID: function() {
                    return W
                },
                Outcome: function() {
                    return E
                },
                PORound: function() {
                    return U
                },
                PaceAdjust: function() {
                    return H
                },
                PerMode: function() {
                    return Y
                },
                Period: function() {
                    return I.ZP
                },
                PlayerExperience: function() {
                    return z
                },
                PlayerOrTeam: function() {
                    return K
                },
                PlayerPosition: function() {
                    return J.Z
                },
                PlusMinus: function() {
                    return Z
                },
                PointDiff: function() {
                    return Q
                },
                RangeType: function() {
                    return _
                },
                Rank: function() {
                    return j
                },
                ReportType: function() {
                    return q
                },
                Scope: function() {
                    return X
                },
                Season: function() {
                    return ee
                },
                SeasonSegment: function() {
                    return te
                },
                SeasonType: function() {
                    return ae.Z
                },
                SeasonYear: function() {
                    return ne
                },
                ShotClockRange: function() {
                    return oe
                },
                Split: function() {
                    return le
                },
                StartPeriod: function() {
                    return se
                },
                StartRange: function() {
                    return re
                },
                StarterBench: function() {
                    return ie
                },
                StatCategory: function() {
                    return ce
                },
                TeamID: function() {
                    return ue.Z
                },
                TeamName: function() {
                    return de.Z
                },
                TouchTimeRange: function() {
                    return ve
                },
                TwoWay: function() {
                    return pe
                },
                TypeGrouping: function() {
                    return xe
                },
                VsConference: function() {
                    return Se
                },
                VsDivision: function() {
                    return he
                },
                VsOpponents: function() {
                    return fe
                },
                Weight: function() {
                    return me
                }
            });
            var o, l, i = a(26042),
                s = a(77226),
                r = {
                    name: "AheadBehind",
                    label: "Ahead or Behind",
                    def: "Ahead or Behind",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "Ahead or Behind",
                        text: "Ahead or Behind"
                    }, {
                        val: "Behind or Tied",
                        text: "Behind or Tied"
                    }, {
                        val: "Ahead or Tied",
                        text: "Ahead or Tied"
                    }]
                },
                c = {
                    name: "CloseDefDistRange",
                    label: "Closest Defender Distance Range",
                    def: "0-2 Feet - Very Tight",
                    type: "select",
                    desc: "Closest Defender Distance Range range for shot dashboard.",
                    options: [{
                        val: "0-2 Feet - Very Tight",
                        text: "0 - 2 Feet (Very Tight)"
                    }, {
                        val: "2-4 Feet - Tight",
                        text: "2-4 Feet (Tight)"
                    }, {
                        val: "4-6 Feet - Open",
                        text: "4-6 Feet (Open)"
                    }, {
                        val: "6+ Feet - Wide Open",
                        text: "6+ Feet (Wide Open)"
                    }]
                },
                u = {
                    name: "ClutchTime",
                    label: "Clutch Time",
                    def: "Last 5 Minutes",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "Last 5 Minutes",
                        text: "Last 5 Minutes"
                    }, {
                        val: "Last 4 Minutes",
                        text: "Last 4 Minutes"
                    }, {
                        val: "Last 3 Minutes",
                        text: "Last 3 Minutes"
                    }, {
                        val: "Last 2 Minutes",
                        text: "Last 2 Minutes"
                    }, {
                        val: "Last 1 Minute",
                        text: "Last 1 Minute"
                    }, {
                        val: "Last 30 Seconds",
                        text: "Last 30 Seconds"
                    }, {
                        val: "Last 10 Seconds",
                        text: "Last 10 Seconds"
                    }]
                },
                d = ["Acadia (CAN)", "Adams State", "Adelphi", "Air Force", "Akron", "Alabama", "Alabama A&M", "Alabama-Birmingham", "Alabama-Huntsville", "Alabama State", "Albany", "Albany State (GA)", "Alcorn State", "Alliance", "American", "American International", "Angelo State", "Appalachian State", "Arizona", "Arizona State", "Arkansas", "Arkansas-Fort Smith", "Arkansas-Little Rock", "Arkansas-Pine Bluff", "Arkansas State", "Army", "Assumption", "Auburn", "Auburn-Montgomery", "Augsburg", "Augustana (IL)", "Augustana (SD)", "Augusta State", "Aurora", "Austin Peay", "Averett", "Azusa Pacific", "Ball State", "Baltimore", "Barton", "Barton Community College", "Baylor", "Belmont", "Belmont Abbey", "Beloit", "Bemidji State", "Benedict", "Bethel (TN)", "Binghamton", "Biola", "Blinn", "Bloomfield", "Bloomsburg", "Bluefield", "Boise State", "Boston College", "Boston University", "Bowie State", "Bowling Green", "Bradley", "Brevard Community College", "Brewton-Parker", "Bridgeport", "Brigham Young", "Brigham Young-Hawaii", "Brooklyn", "Brown", "Bryant", "Bucknell", "Buffalo", "Buffalo State", "Butler", "Butler Community College", "C.W. Post", "California", "California (PA)", "California-Berkeley", "California-Davis", "California-Irvine", "California-Los Angeles", "California-Riverside", "California-Santa Barbara", "Cal State-Bakersfield", "Cal State-Dominguez Hills", "Cal State-Fullerton", "Cal State-Los Angeles", "Cal State-Northridge", "Cal State-Poly Pomona", "Cal State-San Bernardino", "Campbell", "Campbellsville", "Canisius", "Case Western", "Catholic", "Centenary (LA)", "Central Arkansas", "Central Connecticut State", "Central Florida", "Central Michigan", "Central Missouri", "Central Oklahoma", "Central State (OH)", "Central Washington", "Charleston (WV)", "Cheyney", "Chicago State", "Christopher Newport", "Cincinnati", "City College of New York", "Claflin", "Clark Atlanta", "Clayton State", "Clemson", "Cleveland State", "Colgate", "College of Charleston", "College of New Jersey", "Colorado", "Colorado Christian", "Colorado State", "Colorado State-Pueblo", "Columbia", "Columbus State", "Concordia", "Concordia-Irvine", "Connecticut", "Coppin State", "Cornell", "Corpus Christi", "Creighton", "Culver-Stockton", "Dakota Wesleyan", "Dartmouth", "Davidson", "Davis & Elkins", "Dayton", "Delaware", "Delaware State", "Delta State", "Denver", "DePaul", "DePauw", "Detroit Mercy", "Dillard", "District of Columbia", "Drake", "Drexel", "Duke", "Duquesne", "East Carolina", "East Central", "Eastern Illinois", "Eastern Kentucky", "Eastern Michigan", "Eastern New Mexico", "Eastern Oklahoma State (Junior College)", "Eastern Washington", "East Tennessee State", "Eckerd", "Elizabeth City State", "Elon", "Evangel", "Evansville", "Fairfield", "Fairleigh Dickinson", "Fayetteville State", "Ferris State", "Findlay", "Florida", "Florida A&M", "Florida Atlantic", "Florida Community College", "Florida Gulf Coast", "Florida International", "Florida State", "Fordham", "Fort Valley State", "Franklin", "Fresno State", "Friends", "Furman", "Gannon", "Gardner-Webb", "George Mason", "Georgetown", "Georgetown College", "George Washington", "Georgia", "Georgia Southern", "Georgia State", "Georgia Tech", "Gonzaga", "Grambling", "Grand Canyon", "Green Bay", "Grinnell College", "Guilford", "Hamline", "Hampton", "Hardin-Simmons", "Hartford", "Harvard", "Hawaii", "High Point", "Hillsborough Community College", "Hillsdale", "Hofstra", "Holy Cross", "Holy Family", "Houston", "Houston Baptist", "Howard", "Humboldt State", "Huntington", "Idaho", "Idaho State", "Illinois", "Illinois-Chicago", "Illinois State", "Illinois Wesleyan", "Incarnate Word", "Indiana", "Indianapolis", "Indiana Purdue-Fort Wayne", "Indiana Purdue-Indianapolis", "Indiana State", "Indiana Tech", "Indian Hills Community College", "Iona", "Iowa", "Iowa State", "Jackson State", "Jacksonville", "Jacksonville State", "James Madison", "Johnson C. Smith", "Kansas", "Kansas State", "Kennesaw State", "Kent State", "Kentucky", "Kentucky State", "Kentucky Wesleyan", "Kenyon", "King's (NY)", "Lafayette", "Lamar", "La Salle", "Lawrence Tech", "Lebanon Valley", "Lee", "Lehigh", "Le Moyne", "Lewis", "Liberty", "Lincoln (MO)", "Lipscomb", "Long Beach State", "Long Island-Brooklyn", "Longwood", "Los Angeles Community College", "Louisiana-Lafayette", "Louisiana-Monroe", "Louisiana State", "Louisiana Tech", "Louisville", "Loyola-Chicago", "Loyola-Maryland", "Loyola-Marymount", "Maine", "Manhattan", "Marist", "Marquette", "Marshall", "Maryland", "Maryland-Eastern Shore", "Massachusetts", "Master's", "McNeese State", "Memphis", "Mercer", "Meridian Community College", "Merrimack", "Metro State", "Miami (FL)", "Miami (OH)", "Michigan", "Michigan State", "Middle Tennessee State", "Midland", "Midwestern State", "Miles", "Millersville", "Minnesota", "Minnesota-Duluth", "Minnesota State-Mankato", "Mississippi", "Mississippi Gulf Community College", "Mississippi State", "Mississippi Valley State", "Missouri", "Missouri-Kansas City", "Missouri State", "Missouri Western State", "Monmouth", "Montana", "Montana State", "Montevallo", "Morehead State", "Morehouse", "Morgan State", "Mountain State", "Mount St. Mary's", "Mount Union", "Mt. San Antonio", "Muhlenberg", "Murray State", "Navy", "Nebraska", "Nebraska-Kearney", "Nebraska-Omaha", "Nevada", "Nevada-Las Vegas", "Nevada-Reno", "New Jersey Institute of Technology", "New Mexico", "New Mexico Highlands", "New Mexico State", "New Mexico Tech", "New Orleans", "New York University", "Niagara", "Nicholls State", "Norfolk State", "North Carolina", "North Carolina A&T", "North Carolina-Asheville", "North Carolina Central", "North Carolina-Charlotte", "North Carolina-Greensboro", "North Carolina State", "North Carolina-Wilmington", "North Dakota", "North Dakota State", "Northeastern", "Northeastern State", "Northeast Mississippi Community College", "Northern Arizona", "Northern Colorado", "Northern Illinois", "Northern Iowa", "Northern Kentucky", "North Park", "North Texas", "Northwestern", "Northwestern Oklahoma", "Northwestern Oklahoma State", "Northwestern State", "Northwest Florida State", "Northwest Nazarene", "Northwood", "Notre Dame", "Oakland", "Ohio", "Ohio State", "Ohio Wesleyan", "Oklahoma", "Oklahoma Baptist", "Oklahoma City", "Oklahoma Science and Arts", "Oklahoma State", "Oklahoma Wesleyan", "Old Dominion", "Oral Roberts", "Oregon", "Oregon State", "Ouachita Baptist", "Pacific", "Paine", "Penn State", "Pennsylvania", "Pennsylvania-Kutztown", "Pepperdine", "Pfeiffer", "Phillips", "Pikeville", "Pittsburgh", "Portland", "Portland State", "Potsdam", "Prairie View A&M", "Princeton", "Providence", "Puget Sound", "Purdue", "Queens (NY)", "Quincy", "Rhode Island", "Rice", "Richmond", "Rider", "Robert Morris (IL)", "Rochester (NY)", "Rockhurst", "Rutgers", "Sacramento State", "Sacred Heart", "Saginaw Valley", "Saint Augustine's", "Saint Francis (PA)", "Saint Joseph's", "Saint Louis", "Saint Mary's (CA)", "Saint Mary's (MN)", "Saint Peter's", "Saint Rose", "Saint Vincent", "Salem International", "Sam Houston State", "San Diego", "San Diego State", "San Francisco", "San Jose State", "Santa Clara", "Scranton", "Seattle", "Seton Hall", "Seward County Community College", "Shaw", "Shippensburg", "Siena", "Slippery Rock", "South Alabama", "South Carolina", "South Carolina-Aiken", "South Carolina State", "South Carolina Upstate", "South Dakota", "South Dakota State", "Southeastern Illinois", "Southeastern Louisiana", "Southeastern Oklahoma State", "Southeast Missouri State", "Southern", "Southern California", "Southern Illinois", "Southern Methodist", "Southern Mississippi", "Southern Nazarene", "Southern Utah", "South Florida", "Southwest Baptist", "Springfield", "St. Ambrose", "St. Anselm", "St. Bonaventure", "St. Cloud State", "St. Francis Brooklyn", "St. John's (NY)", "St. Mary's (CA)", "St. Mary's (TX)", "St. Peter's", "St. Thomas (FL)", "Stanford", "Stephen F. Austin", "Stetson", "Stony Brook", "Syracuse", "Tampa", "Tarleton State", "Temple", "Tennessee", "Tennessee-Chattanooga", "Tennessee-Martin", "Tennessee State", "Tennessee Tech", "Texas", "Texas A&M", "Texas A&M-Commerce", "Texas A&M-Corpus Christi", "Texas-Arlington", "Texas Christian", "Texas-El Paso", "Texas-Pan American", "Texas-San Antonio", "Texas Southern", "Texas State", "Texas Tech", "Texas Wesleyan", "Thomas More", "Toledo", "Towson", "Trinity Valley Community College", "Troy State", "Truman State", "Tulane", "Tulsa", "Tuskegee", "UCLA", "Utah", "Utah State", "Utah Valley", "Valdosta State", "Valparaiso", "Vanderbilt", "Venezuela", "Vermont", "Villanova", "Virginia", "Virginia Commonwealth", "Virginia Military Institute", "Virginia Tech", "Virginia Union", "Voorhees", "Vorhees", "Wake Forest", "Walsh", "Washington", "Washington & Jefferson", "Washington State", "Wayne State (MI)", "Weber State", "Western Carolina", "Western Illinois", "Western Kentucky", "Western Michigan", "Western Washington", "West Florida", "West Georgia", "Westminster (PA)", "West Texas A&M", "West Virginia", "West Virginia State", "West Virginia Tech", "West Virginia Wesleyan", "Wheaton (IL)", "Whitworth", "Wichita State", "Wilberforce", "William & Mary", "William Jessup", "William Paterson", "William Penn", "Wingate", "Winona State", "Winston-Salem State", "Winthrop (SC)", "Wisconsin", "Wisconsin-Eau Claire", "Wisconsin-Green Bay", "Wisconsin-Milwaukee", "Wisconsin-Parkside", "Wisconsin-River Falls", "Wisconsin-Stevens Point", "Wisconsin-Whitewater", "Wofford", "Wooster", "Wright State", "Wyoming", "Xavier", "Xavier (LA)", "Yale", "Yonsei (KOR)", "Youngstown State"],
                v = {
                    name: "College",
                    label: "College",
                    def: "",
                    type: "select",
                    searchFields: ["text"],
                    placeholder: "Search for a school",
                    desc: "",
                    options: function() {
                        var e = [{
                            val: "",
                            text: "All Affiliations"
                        }, {
                            val: "High School",
                            text: "High School"
                        }, {
                            val: "None",
                            text: "No College"
                        }, {
                            val: "",
                            text: "---"
                        }];
                        return d.forEach((function(t) {
                            e.push({
                                val: t,
                                text: t
                            })
                        })), e
                    }()
                },
                p = {
                    name: "Conference",
                    label: "Conference",
                    order: 280,
                    def: "",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "",
                        text: "All Conferences"
                    }, {
                        val: "East",
                        text: "East"
                    }, {
                        val: "West",
                        text: "West"
                    }]
                },
                x = a(34999),
                S = {
                    name: "DateFrom",
                    label: "Date From",
                    def: "",
                    type: "datepicker",
                    description: "",
                    placeholder: "MM/DD/YYYY",
                    selected: {
                        val: "",
                        text: ""
                    }
                },
                h = {
                    name: "DateTo",
                    label: "Date To",
                    def: "",
                    type: "datepicker",
                    description: "",
                    placeholder: "MM/DD/YYYY",
                    selected: {
                        val: "",
                        text: ""
                    }
                },
                f = {
                    name: "DefenseCategory",
                    label: "Defense Category",
                    def: "Overall",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "Overall",
                        text: "Overall"
                    }, {
                        val: "3 Pointers",
                        text: "3 Pointers"
                    }, {
                        val: "2 Pointers",
                        text: "2 Pointers"
                    }, {
                        val: "Less Than 6Ft",
                        text: "Less Than 6Ft"
                    }, {
                        val: "Less Than 10Ft",
                        text: "Less Than 10Ft"
                    }, {
                        val: "Less Than 10Ft",
                        text: "Less Than 10Ft"
                    }, {
                        val: "Greater Than 15Ft",
                        text: "Greater Than 15Ft"
                    }]
                },
                m = {
                    name: "Direction",
                    label: "Sort Direction",
                    def: "DESC",
                    type: "select",
                    desc: "Select Sort Direction for Gamelogs",
                    options: [{
                        val: "ASC",
                        text: "Ascending"
                    }, {
                        val: "DESC",
                        text: "Descending"
                    }]
                },
                y = {
                    name: "DistanceRange",
                    label: "Distance Range",
                    def: "5ft Range",
                    type: "select",
                    desc: "Filter results to shots made from a certain distance",
                    options: [{
                        val: "5ft Range",
                        text: "5ft Range"
                    }, {
                        val: "8ft Range",
                        text: "8ft Range"
                    }, {
                        val: "By Zone",
                        text: "By Zone"
                    }]
                },
                T = a(60055),
                g = {
                    name: "DraftPick",
                    label: "Draft Pick",
                    def: "",
                    type: "select",
                    desc: "Draft Round",
                    options: [{
                        val: "",
                        text: "All Draft Rounds"
                    }, {
                        val: "1st Round",
                        text: "1st Round"
                    }, {
                        val: "2nd Round",
                        text: "2nd Round"
                    }, {
                        val: "1st Pick",
                        text: "1st Pick"
                    }, {
                        val: "Lottery Pick",
                        text: "Lottery Pick"
                    }, {
                        val: "Top 5 Pick",
                        text: "Top 5 Pick"
                    }, {
                        val: "Top 10 Pick",
                        text: "Top 10 Pick"
                    }, {
                        val: "Top 15 Pick",
                        text: "Top 15 Pick"
                    }, {
                        val: "Top 20 Pick",
                        text: "Top 20 Pick"
                    }, {
                        val: "Top 25 Pick",
                        text: "Top 25 Pick"
                    }, {
                        val: "Picks 11 Thru 20",
                        text: "Picks 11 Thru 20"
                    }, {
                        val: "Picks 21 Thru 30",
                        text: "Picks 21 Thru 30"
                    }, {
                        val: "Undrafted",
                        text: "Undrafted"
                    }]
                },
                C = a(64324),
                b = {
                    name: "DraftYear",
                    label: "Draft Year",
                    def: "",
                    type: "select",
                    desc: "Filter stats to players drafted in a selected year",
                    options: function() {
                        for (var e = [{
                                val: "",
                                text: "All Draft Years"
                            }], t = C.Nc.YearTo; t >= C.Nc.YearFrom; --t) e.push({
                            val: "".concat(t),
                            text: "".concat(t)
                        });
                        return e
                    }()
                },
                P = {
                    name: "DribbleRange",
                    label: "Dribble Range",
                    def: "0 Dribbles",
                    type: "select",
                    desc: "Dribble range for shot dashboard.",
                    options: [{
                        val: "0 Dribbles",
                        text: "0 Dribbles"
                    }, {
                        val: "1 Dribble",
                        text: "1 Dribble"
                    }, {
                        val: "2 Dribbles",
                        text: "2 Dribbles"
                    }, {
                        val: "3-6 Dribbles",
                        text: "3-6 Dribbles"
                    }, {
                        val: "7+ Dribbles",
                        text: "7+ Dribbles"
                    }]
                },
                A = {
                    name: "EndPeriod",
                    label: "End Period",
                    def: 10,
                    type: "number",
                    desc: "",
                    skipLabel: !0,
                    options: [{
                        val: 10
                    }]
                },
                k = {
                    name: "EndRange",
                    label: "End Range",
                    def: 28800,
                    type: "number",
                    desc: "",
                    skipLabel: !0,
                    options: [{
                        val: 28800
                    }]
                },
                M = {
                    name: "GameScope",
                    label: "Game Scope",
                    type: "select",
                    desc: "",
                    def: "",
                    displayOptionText: !0,
                    options: [{
                        val: "",
                        text: "Season"
                    }, {
                        val: "Yesterday",
                        text: "Yesterday"
                    }, {
                        val: "Last10",
                        text: "Last 10 Games"
                    }]
                },
                L = {
                    name: "GameSegment",
                    label: "By Half",
                    type: "select",
                    desc: "The option to view a player or team's stats in either the first half or the second half of a game.",
                    def: "",
                    options: [{
                        val: "",
                        text: "Entire Game"
                    }, {
                        val: "First Half",
                        text: "First Half"
                    }, {
                        val: "Second Half",
                        text: "Second Half"
                    }, {
                        val: "Overtime",
                        text: "Overtime"
                    }]
                },
                O = {
                    name: "GeneralRange",
                    label: "Shot Range",
                    type: "select",
                    desc: "Shot range for shot dashboard.",
                    def: "Overall",
                    options: [{
                        val: "Overall",
                        text: "Overall"
                    }, {
                        val: "Catch and Shoot",
                        text: "Catch and Shoot"
                    }, {
                        val: "Pullups",
                        text: "Pullups"
                    }, {
                        val: "Less Than 10 ft",
                        text: "Less Than 10 ft"
                    }]
                },
                D = {
                    name: "GroupQuantity",
                    label: "Lineups",
                    def: "5",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "5",
                        text: "5 Player Lineups"
                    }, {
                        val: "4",
                        text: "4 Player Lineups"
                    }, {
                        val: "3",
                        text: "3 Player Lineups"
                    }, {
                        val: "2",
                        text: "2 Player Lineups"
                    }]
                },
                R = {
                    name: "Height",
                    label: "Height",
                    def: "",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "",
                        text: "All Heights"
                    }, {
                        val: "LT 6-0",
                        text: "< 6-0"
                    }, {
                        val: "GT 6-0",
                        text: "> 6-0"
                    }, {
                        val: "LT 6-4",
                        text: "< 6-4"
                    }, {
                        val: "GT 6-4",
                        text: "> 6-4"
                    }, {
                        val: "LT 6-7",
                        text: "< 6-7"
                    }, {
                        val: "GT 6-7",
                        text: "> 6-7"
                    }, {
                        val: "LT 6-10",
                        text: "< 6-10"
                    }, {
                        val: "GT 6-10",
                        text: "> 6-10"
                    }, {
                        val: "LT 7-0",
                        text: "< 7-0"
                    }, {
                        val: "GT 7-0",
                        text: "> 7-0"
                    }]
                },
                N = {
                    name: "ISTRound",
                    label: "In-Season Tournament Round",
                    def: "",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "",
                        text: "---"
                    }, {
                        val: "All",
                        text: "All IST"
                    }, {
                        val: "Group",
                        text: "Group Play"
                    }, {
                        val: "Knockout",
                        text: "Knockout - All"
                    }, {
                        val: "Semi",
                        text: "Knockout Round - Semi"
                    }, {
                        val: "Quarter",
                        text: "Knockout Round - Quarter"
                    }, {
                        val: "Championship",
                        text: "Knockout Round - Championship"
                    }]
                },
                F = {
                    name: "LastNGames",
                    label: "Last N Games",
                    def: "0",
                    type: "select",
                    desc: "Filter stats to the Last N Games played by a team or player",
                    displayOptionText: !0,
                    options: [{
                        val: "0",
                        text: "All Games"
                    }, {
                        val: "1",
                        text: "Last Game"
                    }, {
                        val: "2",
                        text: "Last 2 Games"
                    }, {
                        val: "3",
                        text: "Last 3 Games"
                    }, {
                        val: "4",
                        text: "Last 4 Games"
                    }, {
                        val: "5",
                        text: "Last 5 Games"
                    }, {
                        val: "6",
                        text: "Last 6 Games"
                    }, {
                        val: "7",
                        text: "Last 7 Games"
                    }, {
                        val: "8",
                        text: "Last 8 Games"
                    }, {
                        val: "9",
                        text: "Last 9 Games"
                    }, {
                        val: "10",
                        text: "Last 10 Games"
                    }, {
                        val: "11",
                        text: "Last 11 Games"
                    }, {
                        val: "12",
                        text: "Last 12 Games"
                    }, {
                        val: "13",
                        text: "Last 13 Games"
                    }, {
                        val: "14",
                        text: "Last 14 Games"
                    }, {
                        val: "15",
                        text: "Last 15 Games"
                    }]
                },
                G = a(90662),
                V = {
                    name: "Location",
                    label: "Location",
                    def: "",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "",
                        text: "All Locations"
                    }, {
                        val: "Home",
                        text: "Home"
                    }, {
                        val: "Road",
                        text: "Road"
                    }]
                },
                w = {
                    name: "Matchup",
                    type: "select",
                    label: "Player On",
                    def: "Defense",
                    desc: "",
                    options: [{
                        val: "Offense",
                        text: "Offense"
                    }, {
                        val: "Defense",
                        text: "Defense"
                    }]
                },
                B = a(14064),
                W = {
                    name: "OpponentTeamID",
                    label: "VS Team",
                    def: "0",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "0",
                        text: "VS All Teams"
                    }, {
                        val: "1610612737",
                        text: "VS Atlanta Hawks"
                    }, {
                        val: "1610612738",
                        text: "VS Boston Celtics"
                    }, {
                        val: "1610612751",
                        text: "VS Brooklyn Nets"
                    }, {
                        val: "1610612766",
                        text: "VS Charlotte Hornets"
                    }, {
                        val: "1610612741",
                        text: "VS Chicago Bulls"
                    }, {
                        val: "1610612739",
                        text: "VS Cleveland Cavaliers"
                    }, {
                        val: "1610612742",
                        text: "VS Dallas Mavericks"
                    }, {
                        val: "1610612743",
                        text: "VS Denver Nuggets"
                    }, {
                        val: "1610612765",
                        text: "VS Detroit Pistons"
                    }, {
                        val: "1610612744",
                        text: "VS Golden State Warriors"
                    }, {
                        val: "1610612745",
                        text: "VS Houston Rockets"
                    }, {
                        val: "1610612754",
                        text: "VS Indiana Pacers"
                    }, {
                        val: "1610612746",
                        text: "VS LA Clippers"
                    }, {
                        val: "1610612747",
                        text: "VS Los Angeles Lakers"
                    }, {
                        val: "1610612763",
                        text: "VS Memphis Grizzlies"
                    }, {
                        val: "1610612748",
                        text: "VS Miami Heat"
                    }, {
                        val: "1610612749",
                        text: "VS Milwaukee Bucks"
                    }, {
                        val: "1610612750",
                        text: "VS Minnesota Timberwolves"
                    }, {
                        val: "1610612740",
                        text: "VS New Orleans Pelicans"
                    }, {
                        val: "1610612752",
                        text: "VS New York Knicks"
                    }, {
                        val: "1610612760",
                        text: "VS Oklahoma City Thunder"
                    }, {
                        val: "1610612753",
                        text: "VS Orlando Magic"
                    }, {
                        val: "1610612755",
                        text: "VS Philadelphia 76ers"
                    }, {
                        val: "1610612756",
                        text: "VS Phoenix Suns"
                    }, {
                        val: "1610612757",
                        text: "VS Portland Trail Blazers"
                    }, {
                        val: "1610612758",
                        text: "VS Sacramento Kings"
                    }, {
                        val: "1610612759",
                        text: "VS San Antonio Spurs"
                    }, {
                        val: "1610612761",
                        text: "VS Toronto Raptors"
                    }, {
                        val: "1610612762",
                        text: "VS Utah Jazz"
                    }, {
                        val: "1610612764",
                        text: "VS Washington Wizards"
                    }]
                },
                E = {
                    name: "Outcome",
                    label: "Outcome",
                    def: "",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "",
                        text: "All Outcomes"
                    }, {
                        val: "W",
                        text: "Wins"
                    }, {
                        val: "L",
                        text: "Losses"
                    }]
                },
                H = {
                    name: "PaceAdjust",
                    label: "Pace Adjust",
                    def: "N",
                    type: "toggle",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "Y",
                        text: "Pace On"
                    }, {
                        val: "N",
                        text: "Pace Off"
                    }]
                },
                I = a(83993),
                Y = {
                    name: "PerMode",
                    label: "Per Mode",
                    def: "PerGame",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "Totals",
                        text: "Totals"
                    }, {
                        val: "PerGame",
                        text: "Per Game"
                    }]
                },
                z = {
                    name: "PlayerExperience",
                    label: "Experience",
                    def: "",
                    type: "select",
                    desc: "The option to view either only rookies, or to exclude rookies from the data set.",
                    options: [{
                        val: "",
                        text: "All Experience"
                    }, {
                        val: "Rookie",
                        text: "Rookie"
                    }, {
                        val: "Sophomore",
                        text: "Sophomore"
                    }, {
                        val: "Veteran",
                        text: "Veteran"
                    }]
                },
                K = {
                    name: "PlayerOrTeam",
                    label: "Player Or Team",
                    def: "T",
                    type: "select",
                    desc: "Select Stats for Player or Team",
                    displayOptionText: !0,
                    options: [{
                        val: "P",
                        text: "Player"
                    }, {
                        val: "T",
                        text: "Team"
                    }]
                },
                J = a(66485),
                Z = {
                    name: "PlusMinus",
                    label: "Differentials",
                    def: "N",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "Y",
                        text: "Differentials On"
                    }, {
                        val: "N",
                        text: "Differentials Off"
                    }]
                },
                Q = {
                    name: "PointDiff",
                    label: "PointDiff",
                    def: "5",
                    type: "select",
                    description: "",
                    displayOptionText: !0,
                    options: [{
                        val: "5",
                        text: "5 Point Diff or Less"
                    }, {
                        val: "4",
                        text: "4 Point Diff or Less"
                    }, {
                        val: "3",
                        text: "3 Point Diff or Less"
                    }, {
                        val: "2",
                        text: "2 Point Diff or Less"
                    }, {
                        val: "1",
                        text: "1 Point Diff"
                    }]
                },
                U = {
                    name: "PORound",
                    label: "Playoff Round",
                    def: "0",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "0",
                        text: "All Playoff Rounds"
                    }, {
                        val: "1",
                        text: "Conference Quarter-Finals"
                    }, {
                        val: "2",
                        text: "Conference Semi-Finals"
                    }, {
                        val: "3",
                        text: "Conference Finals"
                    }, {
                        val: "4",
                        text: "Finals"
                    }]
                },
                _ = {
                    name: "RangeType",
                    label: "Range Type",
                    type: "number",
                    desc: "",
                    skipLabel: !0,
                    def: 0,
                    selected: {
                        val: 0
                    }
                },
                j = {
                    name: "Rank",
                    label: "Rank",
                    def: "N",
                    type: "toggle",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "Y",
                        text: "Rank On"
                    }, {
                        val: "N",
                        text: "Rank Off"
                    }]
                },
                q = {
                    name: "ReportType",
                    label: "Report-Type",
                    def: "Team",
                    type: "select",
                    desc: "The option to select player or team",
                    options: [{
                        val: "Team",
                        text: "Team"
                    }, {
                        val: "Player",
                        text: "Player"
                    }]
                },
                X = {
                    name: "Scope",
                    label: "Scope",
                    type: "select",
                    desc: "",
                    def: "S",
                    displayOptionText: !0,
                    options: [{
                        val: "S",
                        text: "All Players"
                    }, {
                        val: "Rookies",
                        text: "Rookies"
                    }]
                },
                $ = a(29815),
                ee = {
                    name: "Season",
                    label: "Season",
                    def: C.ii.Season,
                    desc: "",
                    type: "select",
                    displayOptionText: !0,
                    options: (o = 1969, l = C.ii.YearTo, (0, $.Z)(Array(l - o)).map((function(e, t) {
                        var a = "".concat(l - t, "-").concat("".concat(l + 1 - t).substr(-2));
                        return {
                            val: a,
                            text: a
                        }
                    })))
                },
                te = {
                    name: "SeasonSegment",
                    label: "Season Segment",
                    def: "",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "",
                        text: "Entire Season"
                    }, {
                        val: "Pre All-Star",
                        text: "Pre All-Star"
                    }, {
                        val: "Post All-Star",
                        text: "Post All-Star"
                    }]
                },
                ae = a(41486),
                ne = {
                    name: "SeasonYear",
                    label: "Season",
                    def: C.ii.Season,
                    desc: "",
                    type: "select",
                    options: function(e, t) {
                        return (0, $.Z)(Array(t - e)).map((function(e, a) {
                            var n = "".concat(t - a, "-").concat("".concat(t + 1 - a).substr(-2));
                            return {
                                val: n,
                                text: n
                            }
                        }))
                    }(1969, C.ii.YearTo)
                },
                oe = {
                    name: "ShotClockRange",
                    label: "Shot Clock Range",
                    def: "",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "",
                        text: "All Shot Clock Ranges"
                    }, {
                        val: "24-22",
                        text: "24-22"
                    }, {
                        val: "22-18 Very Early",
                        text: "22-18 Very Early"
                    }, {
                        val: "18-15 Early",
                        text: "18-15 Early"
                    }, {
                        val: "15-7 Average",
                        text: "15-7 Average"
                    }, {
                        val: "7-4 Late",
                        text: "7-4 Late"
                    }, {
                        val: "4-0 Very Late",
                        text: "4-0 Very Late"
                    }]
                },
                le = {
                    name: "Split",
                    label: "Split",
                    def: "general",
                    initial: "general",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        text: "General Splits",
                        val: "general",
                        endpoint: "playerdashboardbygeneralsplits"
                    }, {
                        text: "Opponent Splits",
                        val: "opp",
                        endpoint: "playerdashboardbyopponent"
                    }, {
                        text: "Last N Games Splits",
                        val: "lastn",
                        endpoint: "playerdashboardbylastngames"
                    }, {
                        text: "In Game Splits",
                        val: "ingame",
                        endpoint: "playerdashboardbygamesplits"
                    }, {
                        text: "Clutch Splits",
                        val: "clutch",
                        endpoint: "playerdashboardbyclutch"
                    }, {
                        text: "Team Performance Splits",
                        val: "teamperf",
                        endpoint: "playerdashboardbyteamperformance"
                    }, {
                        text: "Year Over Year Splits",
                        val: "yoy",
                        endpoint: "playerdashboardbyyearoveryear"
                    }]
                },
                ie = {
                    name: "StarterBench",
                    label: "Starter/Bench",
                    def: "",
                    type: "select",
                    desc: "The option to view stats by either the starters or the bench of a team.",
                    options: [{
                        val: "",
                        text: "All Players"
                    }, {
                        val: "Starters",
                        text: "Starters"
                    }, {
                        val: "Bench",
                        text: "Bench"
                    }]
                },
                se = {
                    name: "StartPeriod",
                    label: "Start Period",
                    type: "number",
                    desc: "",
                    skipLabel: !0,
                    def: 1,
                    options: [{
                        val: 1
                    }]
                },
                re = {
                    name: "StartRange",
                    label: "Start Range",
                    type: "number",
                    desc: "",
                    skipLabel: !0,
                    def: 0
                },
                ce = {
                    name: "StatCategory",
                    label: "Stat Category",
                    def: "PTS",
                    type: "select",
                    desc: "Official League Leader Categories",
                    displayOptionText: !0,
                    options: [{
                        val: "MIN",
                        text: "MIN"
                    }, {
                        val: "FGM",
                        text: "FGM"
                    }, {
                        val: "FGA",
                        text: "FGA"
                    }, {
                        val: "FG_PCT",
                        text: "FG%"
                    }, {
                        val: "FG3M",
                        text: "3PM"
                    }, {
                        val: "FG3A",
                        text: "3PA"
                    }, {
                        val: "FG3_PCT",
                        text: "3P%"
                    }, {
                        val: "FTM",
                        text: "FTM"
                    }, {
                        val: "FTA",
                        text: "FTA"
                    }, {
                        val: "FT_PCT",
                        text: "FT%"
                    }, {
                        val: "OREB",
                        text: "OREB"
                    }, {
                        val: "DREB",
                        text: "DREB"
                    }, {
                        val: "REB",
                        text: "REB"
                    }, {
                        val: "AST",
                        text: "AST"
                    }, {
                        val: "STL",
                        text: "STL"
                    }, {
                        val: "BLK",
                        text: "BLK"
                    }, {
                        val: "TOV",
                        text: "TOV"
                    }, {
                        val: "EFF",
                        text: "EFF"
                    }, {
                        val: "PTS",
                        text: "PTS"
                    }, {
                        val: "AST_TOV",
                        text: "AST/TO"
                    }, {
                        val: "STL_TOV",
                        text: "STL/TOV"
                    }, {
                        val: "PF",
                        text: "PF"
                    }]
                },
                ue = a(76882),
                de = a(44221),
                ve = {
                    name: "TouchTimeRange",
                    label: "Touch Time Range",
                    type: "select",
                    desc: "Touch Time range for shot dashboard.",
                    def: "Touch < 2 Seconds",
                    options: [{
                        val: "Touch < 2 Seconds",
                        text: "0 - 2 Seconds"
                    }, {
                        val: "Touch 2-6 Seconds",
                        text: "2-6 Seconds"
                    }, {
                        val: "Touch 6+ Seconds",
                        text: "6+ Seconds"
                    }]
                },
                pe = {
                    name: "TwoWay",
                    label: "Two-Way",
                    def: "0",
                    type: "select",
                    desc: "The option to view only players with Two-Way Contracts",
                    displayOptionText: !0,
                    options: [{
                        val: "0",
                        text: "All Players"
                    }, {
                        val: "1",
                        text: "Two-Way Contract"
                    }]
                },
                xe = {
                    name: "TypeGrouping",
                    label: "Offensive or Defensive",
                    def: "offensive",
                    type: "select",
                    desc: "",
                    displayOptionText: !0,
                    options: [{
                        val: "offensive",
                        text: "Offensive"
                    }, {
                        val: "defensive",
                        text: "Defensive"
                    }]
                },
                Se = {
                    name: "VsConference",
                    label: "VS Conference",
                    def: "",
                    type: "select",
                    desc: "Stats for team or player against a selected conference",
                    options: [{
                        val: "",
                        text: "VS All Conferences"
                    }, {
                        val: "East",
                        text: "VS East"
                    }, {
                        val: "West",
                        text: "VS West"
                    }]
                },
                he = {
                    name: "VsDivision",
                    label: "VS Division",
                    def: "",
                    type: "select",
                    desc: "Stats for team or player against a selected division",
                    options: [{
                        val: "",
                        text: "VS All Divisions"
                    }, {
                        val: "Atlantic",
                        text: "VS Atlantic"
                    }, {
                        val: "Central",
                        text: "VS Central"
                    }, {
                        val: "Southeast",
                        text: "VS Southeast"
                    }, {
                        val: "Pacific",
                        text: "VS Pacific"
                    }, {
                        val: "Northwest",
                        text: "VS Northwest"
                    }, {
                        val: "Southwest",
                        text: "VS Southwest"
                    }]
                },
                fe = {
                    name: "VsOpponents",
                    label: "Vs Opponents",
                    def: "",
                    type: "select",
                    desc: "",
                    options: [{
                        val: "",
                        text: "All"
                    }, {
                        val: "Conference",
                        text: "Conference"
                    }, {
                        val: "Divisions",
                        text: "Divisions"
                    }, {
                        val: "Team",
                        text: "Team"
                    }]
                },
                me = {
                    name: "Weight",
                    label: "Weight",
                    def: "",
                    type: "select",
                    desc: "Player weight",
                    displayOptionText: !0,
                    options: [{
                        val: "",
                        text: "All Weights"
                    }, {
                        val: "LT 200",
                        text: "< 200"
                    }, {
                        val: "GT 200",
                        text: "> 200"
                    }, {
                        val: "LT 225",
                        text: "< 225"
                    }, {
                        val: "GT 225",
                        text: "> 225"
                    }, {
                        val: "LT 250",
                        text: "< 250"
                    }, {
                        val: "GT 250",
                        text: "> 250"
                    }, {
                        val: "LT 275",
                        text: "< 275"
                    }, {
                        val: "GT 275",
                        text: "> 275"
                    }, {
                        val: "LT 300",
                        text: "< 300"
                    }, {
                        val: "GT 300",
                        text: "> 300"
                    }]
                },
                ye = a(10253);

            function Te(e, t) {
                return -1 === e.indexOf(t.val)
            }

            function ge(e, t) {
                var a = e.name,
                    n = e.type,
                    o = e.def,
                    l = e.initial;
                if (e.range) {
                    var i, r = (0, ye.Z)(e.range, 2),
                        c = r[0],
                        u = r[1];
                    e.options = (0, s.w6)(+c, +u).map((function(e) {
                        return {
                            val: e,
                            text: e
                        }
                    })).reverse(), e.def = null === (i = e.options[0]) || void 0 === i ? void 0 : i.val
                }
                if (e.seasonRange) {
                    var d, v = (0, ye.Z)(e.seasonRange, 2),
                        p = v[0],
                        x = v[1];
                    e.options = (0, s.w6)(+p, +x, s.kE).map((function(e) {
                        return {
                            val: e,
                            text: e,
                            num: +e.substr(0, 4)
                        }
                    })).reverse(), e.def = null === (d = e.options[0]) || void 0 === d ? void 0 : d.val
                }
                e.without && e.options && (e.options = e.options.filter(Te.bind("", e.without))), e.append && e.options && (e.options = e.options.concat(e.append)), e.prepend && e.options && (e.options = e.prepend.concat(e.options)), e.reverse && e.options && e.options.reverse(), e.options && e.options.forEach((function(t) {
                    t.key = e.name, t.label = e.label
                })), "toggle" === e.type && e.options && e.options.forEach((function(e, t) {
                    e.idx = t
                }));
                var S = null,
                    h = null;
                ((0, s.gK)(t[a]) ? h = t[a] : (0, s.gK)(l) ? h = l : (0, s.gK)(o) && (h = o), ["select", "combo", "toggle"].includes(n)) && (S = (e.options.find((function(e) {
                    return e.val == h
                })) || e.options[0] || {}).val);
                return ["datepicker", "text", "pseudo"].includes(n) && (S = h || ""), ["number"].includes(n) && (S = h || 0), e.selected = S, e.as && (e.name = e.as), e
            }

            function Ce(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    a = t.query,
                    o = void 0 === a ? null : a,
                    l = o || (0, s.ir)(window.location.search),
                    r = e.map((function(e) {
                        return "string" === typeof e ? ge((0, i.Z)({}, n[e]), l) : "object" === typeof e ? ge((0, i.Z)({}, n[e.name], e), l) : null
                    })).filter(Boolean),
                    c = r.reduce((function(e, t) {
                        return e.splits[t.name] = t, e.params[t.name] = t.selected, e
                    }), {
                        splits: {},
                        params: {}
                    });
                return c
            }
        },
        14064: function(e, t, a) {
            a.d(t, {
                z: function() {
                    return n
                }
            });
            var n = [{
                val: "01",
                text: "January"
            }, {
                val: "02",
                text: "February"
            }, {
                val: "03",
                text: "March"
            }, {
                val: "04",
                text: "April"
            }, {
                val: "05",
                text: "May"
            }, {
                val: "06",
                text: "June"
            }, {
                val: "07",
                text: "July"
            }, {
                val: "08",
                text: "August"
            }, {
                val: "09",
                text: "September"
            }, {
                val: "10",
                text: "October"
            }, {
                val: "11",
                text: "November"
            }, {
                val: "12",
                text: "December"
            }];
            t.Z = {
                name: "Month",
                label: "Month",
                order: 140,
                def: "0",
                type: "select",
                desc: "",
                options: [{
                    val: "0",
                    text: "All Months",
                    iso: null
                }, {
                    val: "4",
                    text: "January",
                    iso: "01"
                }, {
                    val: "5",
                    text: "February",
                    iso: "02"
                }, {
                    val: "6",
                    text: "March",
                    iso: "03"
                }, {
                    val: "7",
                    text: "April",
                    iso: "04"
                }, {
                    val: "8",
                    text: "May",
                    iso: "05"
                }, {
                    val: "9",
                    text: "June",
                    iso: "06"
                }, {
                    val: "10",
                    text: "July",
                    iso: "07"
                }, {
                    val: "11",
                    text: "August",
                    iso: "08"
                }, {
                    val: "12",
                    text: "September",
                    iso: "09"
                }, {
                    val: "1",
                    text: "October",
                    iso: "10"
                }, {
                    val: "2",
                    text: "November",
                    iso: "11"
                }, {
                    val: "3",
                    text: "December",
                    iso: "12"
                }]
            }
        },
        83993: function(e, t, a) {
            function n(e) {
                var t = 7200,
                    a = 3e3,
                    n = 28800,
                    o = e < 5 ? e * t : (e - 4) * a + n,
                    l = new Array(e).fill(0).map((function(e, t) {
                        return t + 1
                    })).map((function(e) {
                        var l = {
                            RangeType: 1,
                            lp: e,
                            isOT: e > 4,
                            text: e < 5 ? "Q".concat(e) : "OT".concat(e - 4),
                            startTime: e < 5 ? (e - 1) * t : (e - 5) * a + n,
                            endTime: e < 5 ? e * t : (e - 4) * a + n,
                            startPeriod: e,
                            endPeriod: e,
                            isPeriod: !0
                        };
                        return l.val = l.text, l.pct = l.startTime / o, l
                    })),
                    i = {
                        min: 0,
                        max: o,
                        ps: l
                    };
                i.ps.push({
                    RangeType: 1,
                    lp: 0,
                    isOT: !1,
                    text: "1st Half",
                    val: "1stHalf",
                    startTime: 0,
                    endTime: 14400,
                    startPeriod: 1,
                    endPeriod: 2
                }, {
                    RangeType: 1,
                    lp: 0,
                    isOT: !1,
                    text: "2nd Half",
                    val: "2ndHalf",
                    startTime: 14400,
                    endTime: 28800,
                    startPeriod: 3,
                    endPeriod: 4
                }), e > 5 && i.ps.push({
                    RangeType: 1,
                    lp: 0,
                    isOT: !0,
                    text: "All OT",
                    val: "AllOT",
                    startTime: 28800,
                    endTime: o,
                    startPeriod: 5,
                    endPeriod: e
                }), i.ps.map((function(e) {
                    return void 0 === e.val && (e.val = e.text), e.json = JSON.stringify({
                        rangeType: e.RangeType,
                        startPeriod: e.startPeriod,
                        endPeriod: e.endPeriod,
                        startRange: e.startTime,
                        endRange: e.endTime
                    }), e
                }));
                var s = {
                    RangeType: 0,
                    lp: 0,
                    isOT: !1,
                    text: "All Periods",
                    val: "All",
                    startTime: 0,
                    endTime: o,
                    startPeriod: 0,
                    endPeriod: 0
                };
                return s.json = JSON.stringify({
                    rangeType: s.RangeType,
                    startPeriod: s.startPeriod,
                    endPeriod: s.endPeriod,
                    startRange: s.startTime,
                    endRange: s.endTime
                }), i.ps.unshift(s), i.ps
            }
            a.d(t, {
                zh: function() {
                    return n
                }
            }), t.ZP = {
                name: "Period",
                label: "Quarter",
                order: 210,
                def: "0",
                type: "select",
                desc: "",
                displayOptionText: !0,
                options: [{
                    val: "0",
                    text: "All Quarters"
                }, {
                    val: "1",
                    text: "1st Quarter"
                }, {
                    val: "2",
                    text: "2nd Quarter"
                }, {
                    val: "3",
                    text: "3rd Quarter"
                }, {
                    val: "4",
                    text: "4th Quarter"
                }, {
                    val: "5",
                    text: "OT 1"
                }, {
                    val: "6",
                    text: "OT 2"
                }, {
                    val: "7",
                    text: "OT 3"
                }, {
                    val: "8",
                    text: "OT 4"
                }, {
                    val: "9",
                    text: "OT 5"
                }, {
                    val: "10",
                    text: "OT 6"
                }, {
                    val: "11",
                    text: "OT 7"
                }, {
                    val: "12",
                    text: "OT 8"
                }, {
                    val: "13",
                    text: "OT 9"
                }, {
                    val: "14",
                    text: "OT 10"
                }]
            }
        },
        66485: function(e, t) {
            t.Z = {
                name: "PlayerPosition",
                label: "Position",
                def: "",
                type: "select",
                desc: "Filter out players by position to view either only Guards, Forwards, or Centers.",
                displayOptionText: !0,
                options: [{
                    val: "",
                    text: "All Positions"
                }, {
                    val: "F",
                    text: "Forward"
                }, {
                    val: "C",
                    text: "Center"
                }, {
                    val: "G",
                    text: "Guard"
                }]
            }
        },
        41486: function(e, t) {
            t.Z = {
                name: "SeasonType",
                label: "Season Type",
                def: "Regular Season",
                type: "select",
                desc: "",
                options: [{
                    val: "Pre Season",
                    text: "Preseason",
                    st: 1
                }, {
                    val: "Regular Season",
                    text: "Regular Season",
                    st: 2
                }, {
                    val: "Playoffs",
                    text: "Playoffs",
                    st: 4
                }, {
                    val: "All Star",
                    text: "All-Star",
                    st: 3
                }, {
                    val: "PlayIn",
                    text: "Play In",
                    st: 5
                }]
            }
        },
        44221: function(e, t) {
            t.Z = {
                name: "TeamName",
                label: "Team",
                order: 300,
                def: "0",
                type: "select",
                desc: "",
                options: [{
                    val: "all",
                    text: "All Teams"
                }, {
                    val: "hawks",
                    text: "Atlanta Hawks"
                }, {
                    val: "celtics",
                    text: "Boston Celtics"
                }, {
                    val: "nets",
                    text: "Brooklyn Nets"
                }, {
                    val: "hornets",
                    text: "Charlotte Hornets"
                }, {
                    val: "bulls",
                    text: "Chicago Bulls"
                }, {
                    val: "cavaliers",
                    text: "Cleveland Cavaliers"
                }, {
                    val: "mavericks",
                    text: "Dallas Mavericks"
                }, {
                    val: "nuggets",
                    text: "Denver Nuggets"
                }, {
                    val: "pistons",
                    text: "Detroit Pistons"
                }, {
                    val: "warriors",
                    text: "Golden State Warriors"
                }, {
                    val: "rockets",
                    text: "Houston Rockets"
                }, {
                    val: "pacers",
                    text: "Indiana Pacers"
                }, {
                    val: "clippers",
                    text: "LA Clippers"
                }, {
                    val: "lakers",
                    text: "Los Angeles Lakers"
                }, {
                    val: "grizzlies",
                    text: "Memphis Grizzlies"
                }, {
                    val: "heat",
                    text: "Miami Heat"
                }, {
                    val: "bucks",
                    text: "Milwaukee Bucks"
                }, {
                    val: "timberwolves",
                    text: "Minnesota Timberwolves"
                }, {
                    val: "pelicans",
                    text: "New Orleans Pelicans"
                }, {
                    val: "knicks",
                    text: "New York Knicks"
                }, {
                    val: "thunder",
                    text: "Oklahoma City Thunder"
                }, {
                    val: "magic",
                    text: "Orlando Magic"
                }, {
                    val: "sixers",
                    text: "Philadelphia 76ers"
                }, {
                    val: "suns",
                    text: "Phoenix Suns"
                }, {
                    val: "blazers",
                    text: "Portland Trail Blazers"
                }, {
                    val: "kings",
                    text: "Sacramento Kings"
                }, {
                    val: "spurs",
                    text: "San Antonio Spurs"
                }, {
                    val: "raptors",
                    text: "Toronto Raptors"
                }, {
                    val: "jazz",
                    text: "Utah Jazz"
                }, {
                    val: "wizards",
                    text: "Washington Wizards"
                }]
            }
        }
    }
]);