(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [35913], {
        35913: function(e, a, t) {
            "use strict";
            t.r(a), t.d(a, {
                default: function() {
                    return I
                }
            });
            var n = t(26042),
                r = t(85893),
                i = t(67294),
                s = t(82266),
                c = t(96143),
                d = t(60421),
                o = t(43002),
                l = t(45697),
                u = t.n(l),
                f = t(916),
                h = u().shape({
                    x: u().number,
                    LOC_X: u().number,
                    y: u().number,
                    LOC_Y: u().number,
                    side: u().string,
                    actionType: u().string,
                    shotResult: u().string
                }),
                x = u().shape({
                    name: u().string,
                    fgm: u().number,
                    fga: u().number,
                    fgp: u().number,
                    dist: u().number,
                    svg: u().shape({
                        d: u().string,
                        zone: u().string
                    }),
                    label: u().shape({
                        x: u().number,
                        y: u().number
                    }),
                    la: u().shape({
                        fgm: u().number,
                        fga: u().number,
                        fgp: u().number,
                        perfRange: u().number
                    }),
                    perf: u().string
                }),
                g = u().shape({
                    top: u().number,
                    left: u().number,
                    padding: u().number
                }),
                m = {
                    propTypes: {
                        title: u().string,
                        events: u().arrayOf(h),
                        averages: u().arrayOf(f.Ly),
                        type: u().string,
                        canSave: u().bool,
                        analytics: o.Z0
                    },
                    defaultProps: {
                        title: "",
                        events: [],
                        averages: [],
                        type: "ngss",
                        canSave: !1,
                        analytics: o.m_
                    }
                },
                p = t(54473),
                v = t.n(p);

            function b() {
                return (0, r.jsx)("g", {
                    className: "footer",
                    transform: "translate(10, 560)",
                    children: (0, r.jsx)("text", {
                        fontFamily: "Roboto, sans-serif",
                        children: "FG% vs League Average"
                    })
                })
            }

            function y(e) {
                var a = e.title;
                return (0, r.jsx)("g", {
                    className: "title",
                    transform: "translate(5, 21)",
                    children: (0, r.jsx)("text", {
                        fontFamily: "Roboto, sans-serif",
                        children: a
                    })
                })
            }
            y.propTypes = {
                title: u().string.isRequired
            };
            var F = t(69396),
                G = t(54005);

            function j(e) {
                var a, t, i = e.width,
                    s = e.height,
                    c = e.zone,
                    d = {
                        dx: 35,
                        textAnchor: "middle",
                        fontSize: 12,
                        fontFamily: "Roboto Condensed, sans-serif"
                    },
                    o = (0, G.BYU)([-25, 25], [0, i]),
                    l = (0, G.BYU)([-5, 42], [0, s]);
                return (0, r.jsxs)("g", {
                    className: "label",
                    transform: "translate(".concat(o(null === (a = c.label) || void 0 === a ? void 0 : a.x) - 35, ", ").concat(l(null === (t = c.label) || void 0 === t ? void 0 : t.y), ")"),
                    children: [(0, r.jsx)("rect", {
                        fill: "rgba(255,255,255,.8)",
                        height: 70,
                        width: 70,
                        rx: "3",
                        ry: "3"
                    }), (0, r.jsxs)("text", (0, F.Z)((0, n.Z)({}, d), {
                        fontSize: "16",
                        dy: "16",
                        children: [c.FGM, "/", c.FGA]
                    })), (0, r.jsxs)("text", (0, F.Z)((0, n.Z)({}, d), {
                        dy: "32",
                        children: [(100 * c.fgp).toFixed(1), "%"]
                    })), (0, r.jsxs)("text", (0, F.Z)((0, n.Z)({}, d), {
                        dy: "48",
                        children: ["LA: ", (100 * c.la.fgp).toFixed(1), "%"]
                    })), (0, r.jsxs)("text", (0, F.Z)((0, n.Z)({}, d), {
                        dy: "62",
                        children: ["DIST: ", (100 * c.dist).toFixed(1), "%"]
                    }))]
                })
            }
            j.propTypes = {
                width: u().number.isRequired,
                height: u().number.isRequired,
                zone: x.isRequired
            };
            var A = t(25066),
                _ = t(10253);

            function R(e) {
                if (e) try {
                    var a = {};
                    return e.split(";").forEach((function(e) {
                        var t = (0, _.Z)(e.split(":"), 2),
                            n = t[0],
                            r = t[1];
                        a[n.replace(/-([a-z])/g, (function(e) {
                            return e[1].toUpperCase()
                        }))] = r
                    })), a
                } catch (t) {
                    return {}
                }
            }

            function C() {
                return A.Z.markings.map((function(e) {
                    return (0, r.jsx)("path", {
                        className: "mark",
                        fill: "none",
                        stroke: "#1d2266",
                        strokeWidth: "2.6",
                        d: e.d,
                        style: R(e.style)
                    }, e.d)
                }))
            }

            function z(e) {
                var a = e.width,
                    t = e.height,
                    n = e.zones;
                return (0, r.jsxs)(r.Fragment, {
                    children: [n.map((function(e) {
                        var a;
                        return (0, r.jsx)("path", {
                            className: "zone",
                            "data-zone": e.name,
                            d: null === (a = e.svg) || void 0 === a ? void 0 : a.d,
                            fillOpacity: "0.7",
                            "data-traditional-scale-value": e.traditionalPerf,
                            "data-extended-scale-value": e.extendedPerf
                        }, e.name)
                    })), (0, r.jsx)(C, {}), n.map((function(e) {
                        return (0, r.jsx)(j, {
                            zone: e,
                            width: a,
                            height: t
                        }, "".concat(e.name, "-label"))
                    }))]
                })
            }

            function S(e) {
                var a = e.width,
                    t = e.height,
                    n = e.zones,
                    i = A.Z.advancedMarkings;
                return (0, r.jsxs)(r.Fragment, {
                    children: [n.map((function(e) {
                        var a;
                        return (0, r.jsx)("path", {
                            className: "advancedZone",
                            "data-zone": e.name,
                            d: null === (a = e.svg) || void 0 === a ? void 0 : a.d,
                            fillOpacity: "0.7",
                            "data-traditional-scale-value": e.traditionalPerf,
                            "data-extended-scale-value": e.extendedPerf,
                            transform: "scale(0.835)"
                        }, e.name)
                    })), (0, r.jsx)(C, {}), i.map((function(e) {
                        return (0, r.jsx)("path", {
                            className: "mark",
                            fill: "none",
                            stroke: "#333333",
                            strokeWidth: "2.6",
                            d: e.d,
                            style: R(e.style),
                            transform: "scale(0.835)"
                        }, e.d)
                    })), n.map((function(e) {
                        return (0, r.jsx)(j, {
                            zone: e,
                            width: a,
                            height: t
                        }, "".concat(e.name, "-label"))
                    }))]
                })
            }
            z.propTypes = {
                zones: u().arrayOf(x).isRequired,
                width: u().number.isRequired,
                height: u().number.isRequired
            }, S.propTypes = {
                zones: u().arrayOf(x).isRequired,
                width: u().number.isRequired,
                height: u().number.isRequired
            };
            var T = t(67724);

            function N(e) {
                var a = e.children,
                    t = e.margin,
                    n = e.width,
                    i = e.height;
                return (0, r.jsxs)("g", {
                    className: "court",
                    transform: "translate(".concat(t.left, ", ").concat(t.top, ")"),
                    children: [(0, r.jsx)("g", {
                        className: "background",
                        children: (0, r.jsx)("image", {
                            xlinkHref: "".concat(T.$, "/next/charts/court-floor.png"),
                            x: -t.left,
                            y: -t.padding,
                            width: n + 2 * t.padding,
                            height: i + 2 * t.padding
                        })
                    }), a]
                })
            }

            function M(e) {
                var a = e.width,
                    t = e.height,
                    n = e.margin,
                    i = t + n.top,
                    s = a + n.left;
                return (0, r.jsx)("g", {
                    className: "watermark",
                    transform: "translate(".concat(s, ", ").concat(i, ")"),
                    children: (0, r.jsx)("text", {
                        textAnchor: "end",
                        dy: "-5",
                        dx: "-5",
                        fontSize: "22px",
                        fontWeight: "600",
                        fontFamily: "Roboto, sans-serif",
                        children: "NBA.com"
                    })
                })
            }

            function O(e) {
                var a = e.margin,
                    t = e.height;
                return (0, r.jsxs)("g", {
                    className: "abbreviationLegend",
                    transform: "translate(".concat(a.left + 4, ", ").concat(t + 20, ")"),
                    children: [(0, r.jsx)("text", {
                        fontFamily: "Roboto Condensed, sans-serif",
                        dy: "0",
                        children: "LA - League Average"
                    }), (0, r.jsx)("text", {
                        fontFamily: "Roboto Condensed, sans-serif",
                        dy: "20",
                        children: "DST - Distribution"
                    })]
                })
            }
            N.propTypes = {
                children: u().node,
                width: u().number.isRequired,
                height: u().number.isRequired,
                margin: g.isRequired
            }, N.defaultProps = {
                children: null
            }, M.propTypes = {
                width: u().number.isRequired,
                height: u().number.isRequired,
                margin: g.isRequired
            }, O.propTypes = {
                height: u().number.isRequired,
                margin: g.isRequired
            };
            var k = {
                basic: {
                    "Restricted Area": {
                        x: 0,
                        y: -2
                    },
                    "In The Paint (Non-RA)": {
                        x: 0,
                        y: 6
                    },
                    "Mid-Range": {
                        x: 0,
                        y: 16
                    },
                    "Above the Break 3": {
                        x: 0,
                        y: 25
                    },
                    "Left Corner 3": {
                        x: -23,
                        y: 0
                    },
                    "Right Corner 3": {
                        x: 23,
                        y: 0
                    },
                    Backcourt: {
                        x: 0,
                        y: 36
                    }
                },
                advanced: {
                    "Left Side(L) | 8-16 ft.": {
                        x: -12,
                        y: -2
                    },
                    "Left Side(L) | 16-24 ft.": {
                        x: -18,
                        y: 5
                    },
                    "Left Side(L) | 24+ ft.": {
                        x: -23,
                        y: -2
                    },
                    "Left Side Center(LC) | 16-24 ft.": {
                        x: -12,
                        y: 13
                    },
                    "Left Side Center(LC) | 24+ ft.": {
                        x: -18,
                        y: 25
                    },
                    "Center(C) | Less Than 8 ft.": {
                        x: 0,
                        y: -2
                    },
                    "Center(C) | 8-16 ft.": {
                        x: 0,
                        y: 8
                    },
                    "Center(C) | 16-24 ft.": {
                        x: 0,
                        y: 16
                    },
                    "Center(C) | 24+ ft.": {
                        x: 0,
                        y: 25
                    },
                    "Right Side Center(RC) | 16-24 ft.": {
                        x: 12,
                        y: 13
                    },
                    "Right Side Center(RC) | 24+ ft.": {
                        x: 18,
                        y: 25
                    },
                    "Right Side(R) | 8-16 ft.": {
                        x: 12,
                        y: -2
                    },
                    "Right Side(R) | 16-24 ft.": {
                        x: 18,
                        y: 5
                    },
                    "Right Side(R) | 24+ ft.": {
                        x: 23,
                        y: -2
                    },
                    "Back Court(BC) | Back Court Shot": {
                        x: 0,
                        y: 36
                    }
                }
            };
            var P = {
                traditional: [{
                    text: "-10",
                    c: "#fff",
                    scaleValue: {
                        "data-traditional-scale-value": 1
                    }
                }, {
                    text: "0",
                    c: "#000",
                    scaleValue: {
                        "data-traditional-scale-value": 3
                    }
                }, {
                    text: "+10",
                    c: "#fff",
                    scaleValue: {
                        "data-traditional-scale-value": 5
                    }
                }],
                extended: [{
                    text: "-10",
                    c: "#fff",
                    scaleValue: {
                        "data-extended-scale-value": 1
                    }
                }, {
                    text: "-5",
                    c: "#000",
                    scaleValue: {
                        "data-extended-scale-value": 2
                    }
                }, {
                    text: "0",
                    c: "#000",
                    scaleValue: {
                        "data-extended-scale-value": 3
                    }
                }, {
                    text: "+5",
                    c: "#000",
                    scaleValue: {
                        "data-extended-scale-value": 4
                    }
                }, {
                    text: "+10",
                    c: "#fff",
                    scaleValue: {
                        "data-extended-scale-value": 5
                    }
                }]
            };

            function E(e) {
                var a = e.colorScale,
                    t = e.margin,
                    i = e.height,
                    s = P[a.toLocaleLowerCase()];
                return (0, r.jsx)("g", {
                    className: "legend",
                    transform: "translate(190, ".concat(t.top + i + 25, ")"),
                    children: s.map((function(e, a) {
                        return (0, r.jsxs)("g", {
                            transform: "translate(".concat(45 * a, ", 0)"),
                            children: [(0, r.jsx)("rect", (0, n.Z)({
                                y: 0,
                                height: 20,
                                width: 50,
                                stroke: "#000"
                            }, e.scaleValue)), (0, r.jsx)("text", {
                                fill: e.c,
                                textAnchor: "middle",
                                dx: 23,
                                dy: 15,
                                fontSize: 14,
                                fontFamily: "Roboto",
                                children: e.text
                            })]
                        }, e.text)
                    }))
                })
            }
            E.propTypes = {
                colorScale: u().string.isRequired,
                height: u().number.isRequired,
                margin: u().shape({
                    top: u().number
                }).isRequired
            };
            var Z = 470,
                L = 500,
                q = {
                    top: 50,
                    left: 20,
                    bottom: 50,
                    right: 20,
                    padding: 20
                },
                w = Z + q.top + q.bottom,
                B = L + q.left + q.right;

            function H(e) {
                var a = e.title,
                    t = e.events,
                    o = e.averages,
                    l = e.type,
                    u = e.canSave,
                    f = e.analytics,
                    h = (0, i.createRef)(),
                    x = f.analyticsId,
                    g = f.analyticsExtraProps,
                    m = (0, i.useState)("Traditional"),
                    p = m[0],
                    F = m[1],
                    G = (0, n.Z)({
                        "data-id": x,
                        "data-section": "Shot Zone"
                    }, g),
                    j = (0, s.Z)(l, t),
                    _ = function(e) {
                        return {
                            basic: Object.values(e.basic).map((function(e) {
                                return e.fgp = e.FGM / e.FGA, e.svg = A.Z.zones.find((function(a) {
                                    return a.zone === e.name
                                })), e.label = k.basic[e.name], e
                            })),
                            advanced: Object.values(e.advanced).map((function(e) {
                                return e.fgp = e.FGM / e.FGA, e.svg = A.Z.advancedZones.find((function(a) {
                                    return a.zone === e.name
                                })), e.label = k.advanced[e.name], e
                            }))
                        }
                    }((0, c.PL)(j, o)),
                    R = _.basic,
                    T = _.advanced,
                    P = o && o.length > 0,
                    H = R.length > 0,
                    I = T.length > 0,
                    V = (0, i.useState)(I ? "Advanced" : "Basic"),
                    D = V[0],
                    Y = V[1],
                    U = "Basic" === D && P && H,
                    W = "Advanced" === D && P && I,
                    Q = H && I,
                    X = !H && !I,
                    $ = (0, i.useCallback)((function(e) {
                        F(e.currentTarget.value)
                    }), []),
                    J = (0, i.useCallback)((function(e) {
                        Y(e.currentTarget.value)
                    }), []);
                return (0, r.jsxs)("div", {
                    className: v().chart,
                    children: [(0, r.jsxs)("svg", {
                        viewBox: "0 0 ".concat(B, " ").concat(w),
                        preserveAspectRatio: "xMidYMid meet",
                        style: {
                            background: "#ffffff"
                        },
                        className: v().svg,
                        "data-scale-type": p.toLowerCase(),
                        ref: h,
                        children: [(0, r.jsxs)(N, {
                            width: L,
                            height: Z,
                            margin: q,
                            children: [U && (0, r.jsx)(z, {
                                width: L,
                                height: Z,
                                zones: R
                            }), W && (0, r.jsx)(S, {
                                width: L,
                                height: Z,
                                zones: T
                            }), X && (0, r.jsx)(C, {})]
                        }), (0, r.jsx)(y, {
                            title: a
                        }), (0, r.jsx)(O, {
                            margin: q,
                            height: Z
                        }), (0, r.jsx)(E, {
                            colorScale: p,
                            margin: q,
                            height: Z
                        }), (0, r.jsx)(M, {
                            width: L,
                            height: Z,
                            margin: q
                        }), (0, r.jsx)(b, {})]
                    }), (0, r.jsxs)("div", {
                        className: v().szContainer,
                        children: [Q && (0, r.jsx)("form", {
                            className: v().szForm,
                            children: (0, r.jsxs)("div", {
                                className: v().szCol,
                                children: [(0, r.jsx)("label", {
                                    className: v().optionLabel,
                                    children: "Zone Mode"
                                }), (0, r.jsxs)("label", {
                                    children: [(0, r.jsx)("input", {
                                        type: "radio",
                                        value: "Basic",
                                        name: "zoneMode",
                                        checked: "Basic" === D,
                                        onChange: J,
                                        className: v().szInput
                                    }), (0, r.jsx)("span", {
                                        children: "Basic"
                                    })]
                                }), (0, r.jsxs)("label", {
                                    children: [(0, r.jsx)("input", {
                                        type: "radio",
                                        value: "Advanced",
                                        name: "zoneMode",
                                        checked: "Advanced" === D,
                                        onChange: J,
                                        className: v().szInput
                                    }), (0, r.jsx)("span", {
                                        children: "Advanced"
                                    })]
                                })]
                            })
                        }), (0, r.jsx)("form", {
                            className: v().szForm,
                            children: (0, r.jsxs)("div", {
                                className: v().szCol,
                                children: [(0, r.jsx)("label", {
                                    className: v().optionLabel,
                                    children: "Color Scale"
                                }), (0, r.jsxs)("label", {
                                    children: [(0, r.jsx)("input", {
                                        type: "radio",
                                        value: "Traditional",
                                        name: "colorScale",
                                        checked: "Traditional" === p,
                                        onChange: $,
                                        className: v().szInput
                                    }), (0, r.jsx)("span", {
                                        children: "Traditional"
                                    })]
                                }), (0, r.jsxs)("label", {
                                    children: [(0, r.jsx)("input", {
                                        type: "radio",
                                        value: "Extended",
                                        name: "colorScale",
                                        checked: "Extended" === p,
                                        onChange: $,
                                        className: v().szInput
                                    }), (0, r.jsx)("span", {
                                        children: "Extended"
                                    })]
                                })]
                            })
                        })]
                    }), (0, r.jsx)("div", {
                        children: u && (0, r.jsx)(d.Z, (0, n.Z)({
                            chartRef: h,
                            filename: "".concat(a, ".png")
                        }, G))
                    })]
                })
            }
            H.propTypes = m.propTypes, H.defaultProps = m.defaultProps;
            var I = (0, i.memo)(H)
        },
        96143: function(e, a, t) {
            "use strict";

            function n(e, a, t) {
                var n, r = Math.sqrt(Math.pow(e, 2) + Math.pow(a, 2));
                return 3 === t && (n = a < 8.8 && e < 0 ? "Left Corner 3" : a < 8.8 && e > 0 ? "Right Corner 3" : a > 41.8 ? "Backcourt" : "Above the Break 3"), 2 === t && (n = e > -8 && e < 8 && a < 13.9 ? r < 4 && a > -1.2 ? "Restricted Area" : "In The Paint (Non-RA)" : "Mid-Range"), n
            }

            function r(e) {
                var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                    t = Array.isArray(a) && a.length > 0,
                    r = e.reduce((function(e, a) {
                        var t = a.data,
                            r = t.x,
                            i = t.y,
                            s = t.type,
                            c = t.made,
                            d = n(r, i, s),
                            o = "undefined" !== typeof a.SHOT_ZONE_AREA && "undefined" !== typeof a.SHOT_ZONE_RANGE,
                            l = "".concat(a.SHOT_ZONE_AREA, " | ").concat(a.SHOT_ZONE_RANGE);
                        return e.basic[d] || (e.basic[d] = {
                            FGM: 0,
                            FGA: 0
                        }), o && !e.advanced[l] && (e.advanced[l] = {
                            FGM: 0,
                            FGA: 0
                        }), e.basic[d].name = d, e.basic[d].FGA += 1, e.basic[d].FGM += c ? 1 : 0, o && (e.advanced[l].name = l, e.advanced[l].FGA += 1, e.advanced[l].FGM += c ? 1 : 0), e
                    }), {
                        basic: {},
                        advanced: {}
                    });
                if (Object.keys(r.basic).forEach((function(n) {
                        var i = r.basic[n];
                        i.FG_PCT = i.FGM / i.FGA, i.dist = i.FGA / e.length, i.la = [], t && (i.la = a.filter((function(e) {
                            return e.SHOT_ZONE_BASIC === n
                        })).reduce((function(e, a) {
                            return e.FGM += a.FGM, e.FGA += a.FGA, e.fgp = e.FGM / e.FGA, e.perfRange = .1 * e.fgp, e
                        }), {
                            FGM: 0,
                            FGA: 0,
                            fgp: 0
                        }))
                    })), Object.keys(r.advanced).forEach((function(n) {
                        var i = r.advanced[n];
                        i.FG_PCT = i.FGM / i.FGA, i.dist = i.FGA / e.length, i.la = [], t && (i.la = a.filter((function(e) {
                            return "".concat(e.SHOT_ZONE_AREA, " | ").concat(e.SHOT_ZONE_RANGE) === n
                        })).reduce((function(e, a) {
                            return e.FGM += a.FGM, e.FGA += a.FGA, e.fgp = e.FGM / e.FGA, e.perfRange = .1 * e.fgp, e
                        }), {
                            FGM: 0,
                            FGA: 0,
                            fgp: 0
                        }))
                    })), t) {
                    var c = i(a);
                    s(r, c, "advanced"), s(r, c, "basic")
                }
                return r
            }

            function i(e) {
                var a = {
                        basic: {},
                        advanced: {}
                    },
                    t = "SHOT_ATTEMPTED_FLAG",
                    n = "SHOT_MADE_FLAG";
                return Object.keys(e).forEach((function(r) {
                    var i = e[r],
                        s = i.SHOT_ZONE_BASIC,
                        c = "".concat(i.SHOT_ZONE_AREA, " | ").concat(i.SHOT_ZONE_RANGE);
                    a.basic[s] || (a.basic[s] = {}, a.basic[s].shots = [], a.basic[s].FGM = 0, a.basic[s].FGA = 0), a.advanced[c] || (a.advanced[c] = {}, a.advanced[c].shots = [], a.advanced[c].FGM = 0, a.advanced[c].FGA = 0), a.basic[s].shots.push(i), a.advanced[c].shots.push(i), i[t] ? (a.basic[s].FGA += i[t], a.basic[s].FGM += i[n], a.advanced[c].FGA += i[t], a.advanced[c].FGM += i[n]) : (a.basic[s].FGA += i.FGA || 0, a.basic[s].FGM += i.FGM || 0, a.advanced[c].FGA += i.FGA || 0, a.advanced[c].FGM += i.FGM || 0)
                })), Object.keys(a.basic).forEach((function(e) {
                    a.basic[e].FG_PCT = a.basic[e].FGM / a.basic[e].FGA
                })), Object.keys(a.advanced).forEach((function(e) {
                    a.advanced[e].FG_PCT = a.advanced[e].FGM / a.advanced[e].FGA
                })), a
            }

            function s(e, a, t) {
                Object.keys(e[t]).forEach((function(n) {
                    var r = e[t][n],
                        i = a[t][n];
                    r.leagueFG_PCT = i.FG_PCT;
                    var s = (r.FG_PCT - i.FG_PCT) / i.FG_PCT * 100;
                    r.calcPctDiff = s, s < -10 ? (r.traditionalPerf = 1, r.extendedPerf = 1) : s < -5 ? (r.traditionalPerf = 3, r.extendedPerf = 2) : s > 10 ? (r.traditionalPerf = 5, r.extendedPerf = 5) : s > 5 ? (r.traditionalPerf = 3, r.extendedPerf = 4) : (r.traditionalPerf = 3, r.extendedPerf = 3), r.zPerf = s < -9 ? "q0" : s < -3 ? "q1" : s > 3 ? "q3" : s > 9 ? "q4" : "q2"
                }))
            }
            t.d(a, {
                PL: function() {
                    return r
                }
            })
        },
        54473: function(e) {
            e.exports = {
                chart: "Shotzone_chart__68ift",
                optionLabel: "Shotzone_optionLabel___AM2c",
                svg: "Shotzone_svg__Dlze3",
                szContainer: "Shotzone_szContainer__M65_7",
                szForm: "Shotzone_szForm__QaiVl",
                szCol: "Shotzone_szCol__HZGa9",
                szInput: "Shotzone_szInput__z8zYR"
            }
        }
    }
]);