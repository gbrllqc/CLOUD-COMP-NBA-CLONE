(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [59380], {
        85992: function(e, t, n) {
            "use strict";
            n.d(t, {
                D4: function() {
                    return d
                },
                sH: function() {
                    return s
                }
            });
            var i = n(45697),
                r = n.n(i),
                s = {
                    rows: r().array,
                    params: r().object,
                    title: r().string,
                    footer: r().oneOfType([r().object, r().array]),
                    filters: r().shape()
                },
                d = {
                    rows: [],
                    params: {},
                    title: "",
                    footer: {},
                    filters: {}
                };
            r().oneOfType([r().arrayOf(r().node), r().node]).isRequired, r().string, r().string, r().string, r().oneOfType([r().string, r().number]), r().func, r().func
        },
        43007: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return b
                }
            });
            var i = n(26042),
                r = n(69396),
                s = n(85893),
                d = n(67294),
                a = n(77226),
                l = n(91567),
                c = n(93967),
                h = n.n(c),
                o = n(55244),
                f = n(34405),
                m = n(26192),
                u = n(1569),
                x = n(44762),
                j = n(92033),
                S = n(31105),
                g = n(85992),
                T = n(28726),
                v = n.n(T),
                A = n(67724),
                p = {
                    field: "Conference",
                    sections: [{
                        order: 1,
                        title: "Eastern Conference",
                        name: "East"
                    }, {
                        order: 2,
                        title: "Western Conference",
                        name: "West"
                    }, {
                        order: 3,
                        title: "",
                        name: "Utah"
                    }, {
                        order: 4,
                        title: "",
                        name: "summer"
                    }, {
                        order: 5,
                        title: "",
                        name: "Sacramento"
                    }, {
                        order: 6,
                        title: "",
                        name: "California"
                    }, {
                        order: 7,
                        title: "",
                        name: "Vegas"
                    }]
                },
                C = {
                    field: "Division",
                    sections: [{
                        order: 1,
                        title: "Atlantic Division",
                        name: "Atlantic"
                    }, {
                        order: 2,
                        title: "Central Division",
                        name: "Central"
                    }, {
                        order: 3,
                        title: "Midwest Division",
                        name: "Midwest"
                    }, {
                        order: 4,
                        title: "Southeast Division",
                        name: "Southeast"
                    }, {
                        order: 5,
                        title: "Northwest Division",
                        name: "Northwest"
                    }, {
                        order: 6,
                        title: "Pacific Division",
                        name: "Pacific"
                    }, {
                        order: 7,
                        title: "Southwest Division",
                        name: "Southwest"
                    }]
                };
            var L = n(45777),
                O = n.n(L),
                P = function(e) {
                    var t = e.row,
                        n = e.params,
                        d = e.index,
                        l = "conf" === n.GroupBy,
                        c = (0, j.Z)(["cutoff", "clinch"], n),
                        o = (0, j.Z)(["cutoff", "wildcard"], n),
                        m = S.Z.find((function(e) {
                            return e[0] === String(t.TeamID)
                        })),
                        u = l ? t.ConferenceGamesBack : t.DivisionGamesBack,
                        g = m ? (null === n || void 0 === n ? void 0 : n.isWebView) ? "gametime://webview?url=https://".concat(A.$g, "/webview/team/").concat(t.TeamID, "/").concat(t.TeamSlug, "?hidenav=true") : "/team/".concat(t.TeamID, "/").concat(t.TeamSlug) : null,
                        T = null,
                        p = null,
                        C = (0, s.jsxs)(s.Fragment, {
                            children: [(0, s.jsx)("td", {
                                className: h()(v().text, v().primary, v().sticky, O().primary),
                                "data-wide": "true",
                                children: (0, s.jsxs)(f.Z, (0, r.Z)((0, i.Z)({
                                    className: O().teamLink,
                                    href: g
                                }, (function(e) {
                                    return {
                                        "data-track": "click",
                                        "data-type": e,
                                        "data-id": l ? "nba:standings:conference:".concat(t.Conference, "ern") : "nba:standings:division:".concat(t.Conference, "ern:").concat(t.Division),
                                        "data-pos": d,
                                        "data-section": l ? "".concat(t.Conference, "ern") : t.Division,
                                        "data-text": "".concat(t.TeamCity, " ").concat(t.TeamName),
                                        "data-content": t.TeamID
                                    }
                                })), {
                                    children: [(0, s.jsx)("span", {
                                        className: O().teamRank,
                                        children: d + 1
                                    }), (0, s.jsx)("div", {
                                        className: O().teamLogoBlock,
                                        children: (0, s.jsx)(x.Z, {
                                            className: O().teamLogo,
                                            tid: t.TeamID,
                                            season: n.Season,
                                            logoType: n.logoType
                                        })
                                    }), (0, s.jsxs)("span", {
                                        className: O().teamCity,
                                        children: [t.TeamCity, "\xa0"]
                                    }), (0, s.jsx)("span", {
                                        className: O().teamName,
                                        children: t.TeamName
                                    }), (0, s.jsx)("span", {
                                        className: O().teamClinch,
                                        children: t.ClinchIndicator
                                    })]
                                }))
                            }), (0, s.jsx)("td", {
                                children: t.WINS
                            }), (0, s.jsx)("td", {
                                children: t.LOSSES
                            }), (0, s.jsx)("td", {
                                children: (0, a.Ss)(t.WinPCT)
                            }), (0, s.jsx)("td", {
                                children: u || "--"
                            })]
                        });
                    return "overall" === n.Section && (p = (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("td", {
                            children: t.ConferenceRecord
                        }), (0, s.jsx)("td", {
                            children: t.DivisionRecord
                        }), (0, s.jsx)("td", {
                            children: t.HOME
                        }), (0, s.jsx)("td", {
                            children: t.ROAD
                        }), (0, s.jsx)("td", {
                            children: t.NEUTRAL
                        }), (0, s.jsx)("td", {
                            children: t.OT
                        }), (0, s.jsx)("td", {
                            children: t.L10
                        }), (0, s.jsx)("td", {
                            children: (0, a.bc)(t.CurrentStreak)
                        })]
                    })), "streaks" === n.Section && (p = (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("td", {
                            children: (0, a.bc)(t.CurrentStreak)
                        }), (0, s.jsx)("td", {
                            children: (0, a.bc)(t.CurrentHomeStreak)
                        }), (0, s.jsx)("td", {
                            children: (0, a.bc)(t.CurrentRoadStreak)
                        }), (0, s.jsx)("td", {
                            children: t.L10
                        }), (0, s.jsx)("td", {
                            children: t.Last10Home
                        }), (0, s.jsx)("td", {
                            children: t.Last10Road
                        }), (0, s.jsx)("td", {
                            children: (0, a.bc)(t.LongHomeStreak)
                        }), (0, s.jsx)("td", {
                            children: (0, a.bc)(t.LongRoadStreak)
                        })]
                    })), "ab" === n.Section && (p = (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("td", {
                            children: t.AheadAtHalf
                        }), (0, s.jsx)("td", {
                            children: t.BehindAtHalf
                        }), (0, s.jsx)("td", {
                            children: t.TiedAtHalf
                        }), (0, s.jsx)("td", {
                            children: t.AheadAtThird
                        }), (0, s.jsx)("td", {
                            children: t.BehindAtThird
                        }), (0, s.jsx)("td", {
                            children: t.TiedAtThird
                        }), (0, s.jsx)("td", {
                            children: (0, a.OK)(t.PointsPG, 1)
                        }), (0, s.jsx)("td", {
                            children: (0, a.OK)(t.OppPointsPG, 1)
                        }), (0, s.jsx)("td", {
                            children: (0, a.OK)(t.DiffPointsPG, 1)
                        })]
                    })), "margins" === n.Section && (p = (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("td", {
                            children: t.ThreePTSOrLess
                        }), (0, s.jsx)("td", {
                            children: t.TenPTSOrMore
                        }), (0, s.jsx)("td", {
                            children: t.Score100PTS
                        }), (0, s.jsx)("td", {
                            children: t.OppScore100PTS
                        }), (0, s.jsx)("td", {
                            children: t.OppOver500
                        }), (0, s.jsx)("td", {
                            children: t.LeadInFGPCT
                        }), (0, s.jsx)("td", {
                            children: t.LeadInReb
                        }), (0, s.jsx)("td", {
                            children: t.FewerTurnovers
                        })]
                    })), "vs" === n.Section && (p = (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("td", {
                            children: t.vsEast
                        }), (0, s.jsx)("td", {
                            children: t.vsWest
                        }), (0, s.jsx)("td", {
                            children: t.vsAtlantic
                        }), (0, s.jsx)("td", {
                            children: t.vsCentral
                        }), (0, s.jsx)("td", {
                            children: t.vsSoutheast
                        }), (0, s.jsx)("td", {
                            children: t.vsNorthwest
                        }), (0, s.jsx)("td", {
                            children: t.vsPacific
                        }), (0, s.jsx)("td", {
                            children: t.vsSouthwest
                        })]
                    })), "calendar" === n.Section && (p = (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("td", {
                            children: t.Oct || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Nov || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Dec || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Jan || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Feb || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Mar || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Apr || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Jul || "--"
                        }), (0, s.jsx)("td", {
                            children: t.Aug || "--"
                        })]
                    })), n.isSummerLeague && (T = (0, s.jsx)(s.Fragment, {
                        children: (0, s.jsx)("td", {
                            children: (0, a.OK)(t.DiffPointsPG, 1)
                        })
                    })), (0, s.jsxs)("tr", {
                        className: O().row,
                        "data-is-clinch": c === d && !n.isSummerLeague,
                        "data-is-wildcard": o === d && !n.isSummerLeague,
                        children: [C, p, T]
                    }, t.__id)
                };

            function b(e) {
                var t = e.rows,
                    n = e.params,
                    c = e.isStatsReady,
                    f = (0, d.useContext)(l.N),
                    x = f.themeName,
                    S = f.isWebView;
                if (!c) return (0, s.jsx)(m.Z, {});
                if (!t || 0 === t.length) return (0, s.jsx)(u.Z, {
                    text: "No Standings Available For The Selected Filters"
                });
                var g, T = "div" === n.GroupBy ? C : p,
                    A = T.field,
                    L = T.sections,
                    b = (0, a.vM)(t, A),
                    R = (g = n.Season) && (0, a.V5)(g) < 2020 ? {
                        wildcard: null,
                        clinch: 8
                    } : {
                        wildcard: 6,
                        clinch: 10
                    },
                    D = function(e) {
                        var t = [(0, s.jsx)("th", {
                            field: "TEAM_ID",
                            className: h()(v().text, v().primary, v().sticky, O().primary),
                            "data-wide": "true",
                            children: "Team"
                        }), (0, s.jsx)("th", {
                            field: "WINS",
                            children: "w"
                        }), (0, s.jsx)("th", {
                            field: "LOSSES",
                            children: "L"
                        }), (0, s.jsx)("th", {
                            field: "WIN_PCT",
                            children: "WIN%"
                        }), (0, s.jsx)("th", {
                            field: "GB",
                            children: "GB"
                        })];
                        return "overall" === e.Section && t.push((0, s.jsx)("th", {
                            field: "ConferenceRecord",
                            children: "CONF"
                        }), (0, s.jsx)("th", {
                            field: "DivisionRecord",
                            children: "DIV"
                        }), (0, s.jsx)("th", {
                            field: "HOME",
                            children: "HOME"
                        }), (0, s.jsx)("th", {
                            field: "ROAD",
                            children: "ROAD"
                        }), (0, s.jsx)("th", {
                            field: "NEUTRAL",
                            children: "Neutral"
                        }), (0, s.jsx)("th", {
                            field: "OT",
                            children: "OT"
                        }), (0, s.jsx)("th", {
                            field: "L10",
                            children: "LAST10"
                        }), (0, s.jsx)("th", {
                            field: "CurrentStreak",
                            children: "STREAK"
                        })), "streaks" === e.Section && t.push((0, s.jsx)("th", {
                            field: "CurrentStreak",
                            children: "CURRENT"
                        }), (0, s.jsx)("th", {
                            field: "CurrentHomeStreak",
                            children: "HOME"
                        }), (0, s.jsx)("th", {
                            field: "CurrentRoadStreak",
                            children: "ROAD"
                        }), (0, s.jsx)("th", {
                            field: "L10",
                            children: "LAST10"
                        }), (0, s.jsx)("th", {
                            field: "Last10Home",
                            children: "L10\xa0HOME"
                        }), (0, s.jsx)("th", {
                            field: "Last10Road",
                            children: "L10\xa0ROAD"
                        }), (0, s.jsx)("th", {
                            field: "LongHomeStreak",
                            children: "HOME\xa0LONG"
                        }), (0, s.jsx)("th", {
                            field: "LongRoadStreak",
                            children: "ROAD\xa0LONG"
                        })), "ab" === e.Section && t.push((0, s.jsx)("th", {
                            field: "AheadAtHalf",
                            children: "AHEAD\xa0HALF"
                        }), (0, s.jsx)("th", {
                            field: "BehindAtHalf",
                            children: "BEHIND\xa0HALF"
                        }), (0, s.jsx)("th", {
                            field: "TiedAtHalf",
                            children: "TIED\xa0HALF"
                        }), (0, s.jsx)("th", {
                            field: "AheadAtThird",
                            children: "AHEAD\xa03RD"
                        }), (0, s.jsx)("th", {
                            field: "BehindAtThird",
                            children: "BEHIND\xa03RD"
                        }), (0, s.jsx)("th", {
                            field: "TiedAtThird",
                            children: "TIED\xa03RD"
                        }), (0, s.jsx)("th", {
                            field: "PointsPG",
                            children: "PTS/G"
                        }), (0, s.jsx)("th", {
                            field: "OppPointsPG",
                            children: "PA/G"
                        }), (0, s.jsx)("th", {
                            field: "DiffPointsPG",
                            children: "+/-"
                        })), "margins" === e.Section && t.push((0, s.jsx)("th", {
                            field: "ThreePTSOrLess",
                            children: "3PTS\xa0OR\xa0LESS"
                        }), (0, s.jsx)("th", {
                            field: "TenPTSOrMore",
                            children: "10PTS\xa0OR\xa0MORE"
                        }), (0, s.jsx)("th", {
                            field: "Score100PTS",
                            children: "SCORE\xa0100+"
                        }), (0, s.jsx)("th", {
                            field: "OppScore100PTS",
                            children: "OPP\xa0SCORE100+"
                        }), (0, s.jsx)("th", {
                            field: "OppOver500",
                            children: "OPP\xa0.500+"
                        }), (0, s.jsx)("th", {
                            field: "LeadInFGPCT",
                            children: "LEAD\xa0FG%"
                        }), (0, s.jsx)("th", {
                            field: "LeadInReb",
                            children: "LEAD\xa0REB"
                        }), (0, s.jsx)("th", {
                            field: "FewerTurnovers",
                            children: "FEWER\xa0TOV"
                        })), "vs" === e.Section && t.push((0, s.jsx)("th", {
                            field: "vsEast",
                            children: "EAST"
                        }), (0, s.jsx)("th", {
                            field: "vsWest",
                            children: "WEST"
                        }), (0, s.jsx)("th", {
                            field: "vsAtlantic",
                            children: "ATLANTIC"
                        }), (0, s.jsx)("th", {
                            field: "vsCentral",
                            children: "CENTRAL"
                        }), (0, s.jsx)("th", {
                            field: "vsSoutheast",
                            children: "SOUTHEAST"
                        }), (0, s.jsx)("th", {
                            field: "vsNorthwest",
                            children: "NORTHWEST"
                        }), (0, s.jsx)("th", {
                            field: "vsPacific",
                            children: "PACIFIC"
                        }), (0, s.jsx)("th", {
                            field: "vsSouthwest",
                            children: "SOUTHWEST"
                        })), "calendar" === e.Section && t.push((0, s.jsx)("th", {
                            field: "Oct",
                            children: "OCT"
                        }), (0, s.jsx)("th", {
                            field: "Nov",
                            children: "NOV"
                        }), (0, s.jsx)("th", {
                            field: "Dec",
                            children: "DEC"
                        }), (0, s.jsx)("th", {
                            field: "Jan",
                            children: "JAN"
                        }), (0, s.jsx)("th", {
                            field: "Feb",
                            children: "FEB"
                        }), (0, s.jsx)("th", {
                            field: "Mar",
                            children: "MAR"
                        }), (0, s.jsx)("th", {
                            field: "Apr",
                            children: "APR"
                        }), (0, s.jsx)("th", {
                            field: "Jul",
                            children: "JUL"
                        }), (0, s.jsx)("th", {
                            field: "Aug",
                            children: "AUG"
                        })), e.isSummerLeague && t.push((0, s.jsx)("th", {
                            field: "DiffPointsPg",
                            children: "+/-\xa0PTS"
                        })), t
                    }(n);
                return L.map((function(e) {
                    var t = b.find((function(t) {
                            return t.key === e.name
                        })),
                        d = (0, j.Z)(["items"], t);
                    return d ? (0, s.jsx)(o.Z, {
                        caption: e.title,
                        headers: D,
                        params: (0, r.Z)((0, i.Z)({}, n), {
                            logoType: x,
                            cutoff: R,
                            isWebView: S
                        }),
                        getRow: P,
                        rows: d,
                        hidePagination: !0
                    }, e.order) : null
                }))
            }
            b.propTypes = g.sH, b.defaultProps = g.D4
        },
        16201: function(e, t, n) {
            "use strict";
            n.d(t, {
                EI: function() {
                    return d
                },
                mi: function() {
                    return a
                }
            });
            var i = n(45697),
                r = n.n(i),
                s = n(38799),
                d = (r().shape({
                    header: r().string,
                    field: r().string,
                    classes: r().string,
                    render: r().func
                }), r().shape({
                    LeagueID: r().string,
                    SeasonID: r().string,
                    TeamID: r().number,
                    TeamCity: r().string,
                    TeamName: r().string,
                    Conference: r().string,
                    ConferenceRecord: r().string,
                    PlayoffRank: r().number,
                    QUARTER_PTS: r().number,
                    ClinchIndicator: r().string,
                    Division: r().string,
                    DivisionRecord: r().string,
                    DivisionRank: r().number,
                    WINS: r().number,
                    LOSSES: r().number,
                    WinPCT: r().number,
                    LeagueRank: r().number,
                    Record: r().string,
                    HOME: r().string,
                    ROAD: r().string,
                    L10: r().string,
                    Last10Home: r().string,
                    Last10Road: r().string,
                    OT: r().string,
                    ThreePTSOrLess: r().string,
                    TenPTSOrMore: r().string,
                    LongHomeStreak: r().number,
                    strLongHomeStreak: r().string,
                    LongRoadStreak: r().number,
                    strLongRoadStreak: r().string,
                    LongWinStreak: r().number,
                    LongLossStreak: r().number,
                    CurrentHomeStreak: r().number,
                    strCurrentHomeStreak: r().string,
                    CurrentRoadStreak: r().number,
                    strCurrentRoadStreak: r().string,
                    CurrentStreak: r().number,
                    strCurrentStreak: r().string,
                    ConferenceGamesBack: r().number,
                    DivisionGamesBack: r().number,
                    ClinchedConferenceTitle: r().number,
                    ClinchedDivisionTitle: r().number,
                    ClinchedPlayoffBirth: r().number,
                    EliminatedConference: r().number,
                    EliminatedDivision: r().number,
                    AheadAtHalf: r().string,
                    BehindAtHalf: r().string,
                    TiedAtHalf: r().string,
                    AheadAtThird: r().string,
                    BehindAtThird: r().string,
                    TiedAtThird: r().string,
                    Score100PTS: r().string,
                    OppScore100PTS: r().string,
                    OppOver500: r().string,
                    LeadInFGPCT: r().string,
                    LeadInReb: r().string,
                    FewerTurnovers: r().string,
                    PointsPG: r().number,
                    OppPointsPG: r().number,
                    DiffPointsPG: r().number,
                    vsEast: r().string,
                    vsAtlantic: r().string,
                    vsCentral: r().string,
                    vsSoutheast: r().string,
                    vsWest: r().string,
                    vsNorthwest: r().string,
                    vsPacific: r().string,
                    vsSouthwest: r().string,
                    Jan: r().string,
                    Feb: r().string,
                    Mar: r().string,
                    Apr: r().string,
                    May: r().string,
                    Jun: r().string,
                    Jul: r().string,
                    Aug: r().string,
                    Sep: r().string,
                    Oct: r().string,
                    Nov: r().string,
                    Dec: r().string
                })),
                a = {
                    layout: s.x0.isRequired,
                    region: r().string
                }
        },
        45777: function(e) {
            e.exports = {
                teamLink: "StatsStandingsTable_teamLink__8f7tE",
                teamRank: "StatsStandingsTable_teamRank__dbHMs",
                teamLogoBlock: "StatsStandingsTable_teamLogoBlock__hoBe5",
                teamLogo: "StatsStandingsTable_teamLogo__tKP5Z",
                teamCity: "StatsStandingsTable_teamCity__WJIh9",
                teamClinch: "StatsStandingsTable_teamClinch__5RBud",
                row: "StatsStandingsTable_row__o6A7G",
                primary: "StatsStandingsTable_primary__x5K4w"
            }
        }
    }
]);