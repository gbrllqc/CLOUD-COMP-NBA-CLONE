(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6210, 4621], {
        90638: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(96856).Z;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                var n = o.default,
                    i = {
                        loading: function(e) {
                            e.error, e.isLoading;
                            return e.pastDelay, null
                        }
                    };
                r(e, Promise) ? i.loader = function() {
                    return e
                } : "function" === typeof e ? i.loader = e : "object" === typeof e && (i = a({}, i, e));
                !1;
                (i = a({}, i, t)).loadableGenerated && delete(i = a({}, i, i.loadableGenerated)).loadableGenerated;
                if ("boolean" === typeof i.ssr && !i.suspense) {
                    if (!i.ssr) return delete i.ssr, s(n, i);
                    delete i.ssr
                }
                return n(i)
            }, t.noSSR = s;
            var a = n(6495).Z,
                i = n(92648).Z,
                o = (i(n(67294)), i(n(14302)));

            function s(e, t) {
                return delete t.webpack, delete t.modules, e(t)
            }("function" === typeof t.default || "object" === typeof t.default && null !== t.default) && "undefined" === typeof t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        16319: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LoadableContext = void 0;
            var r = (0, n(92648).Z)(n(67294)).default.createContext(null);
            t.LoadableContext = r
        },
        14302: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(79658).Z,
                a = n(7222).Z;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(6495).Z,
                o = (0, n(92648).Z)(n(67294)),
                s = n(16319),
                l = n(67294).useSyncExternalStore,
                u = [],
                d = [],
                c = !1;

            function p(e) {
                var t = e(),
                    n = {
                        loading: !0,
                        loaded: null,
                        error: null
                    };
                return n.promise = t.then((function(e) {
                    return n.loading = !1, n.loaded = e, e
                })).catch((function(e) {
                    throw n.loading = !1, n.error = e, e
                })), n
            }
            var h = function() {
                function e(t, n) {
                    r(this, e), this._loadFn = t, this._opts = n, this._callbacks = new Set, this._delay = null, this._timeout = null, this.retry()
                }
                return a(e, [{
                    key: "promise",
                    value: function() {
                        return this._res.promise
                    }
                }, {
                    key: "retry",
                    value: function() {
                        var e = this;
                        this._clearTimeouts(), this._res = this._loadFn(this._opts.loader), this._state = {
                            pastDelay: !1,
                            timedOut: !1
                        };
                        var t = this._res,
                            n = this._opts;
                        t.loading && ("number" === typeof n.delay && (0 === n.delay ? this._state.pastDelay = !0 : this._delay = setTimeout((function() {
                            e._update({
                                pastDelay: !0
                            })
                        }), n.delay)), "number" === typeof n.timeout && (this._timeout = setTimeout((function() {
                            e._update({
                                timedOut: !0
                            })
                        }), n.timeout))), this._res.promise.then((function() {
                            e._update({}), e._clearTimeouts()
                        })).catch((function(t) {
                            e._update({}), e._clearTimeouts()
                        })), this._update({})
                    }
                }, {
                    key: "_update",
                    value: function(e) {
                        this._state = i({}, this._state, {
                            error: this._res.error,
                            loaded: this._res.loaded,
                            loading: this._res.loading
                        }, e), this._callbacks.forEach((function(e) {
                            return e()
                        }))
                    }
                }, {
                    key: "_clearTimeouts",
                    value: function() {
                        clearTimeout(this._delay), clearTimeout(this._timeout)
                    }
                }, {
                    key: "getCurrentValue",
                    value: function() {
                        return this._state
                    }
                }, {
                    key: "subscribe",
                    value: function(e) {
                        var t = this;
                        return this._callbacks.add(e),
                            function() {
                                t._callbacks.delete(e)
                            }
                    }
                }]), e
            }();

            function m(e) {
                return function(e, t) {
                    var n = function() {
                            if (!u) {
                                var t = new h(e, a);
                                u = {
                                    getCurrentValue: t.getCurrentValue.bind(t),
                                    subscribe: t.subscribe.bind(t),
                                    retry: t.retry.bind(t),
                                    promise: t.promise.bind(t)
                                }
                            }
                            return u.promise()
                        },
                        r = function() {
                            n();
                            var e = o.default.useContext(s.LoadableContext);
                            e && Array.isArray(a.modules) && a.modules.forEach((function(t) {
                                e(t)
                            }))
                        },
                        a = Object.assign({
                            loader: null,
                            loading: null,
                            delay: 200,
                            timeout: null,
                            webpack: null,
                            modules: null,
                            suspense: !1
                        }, t);
                    a.suspense && (a.lazy = o.default.lazy(a.loader));
                    var u = null;
                    if (!c) {
                        var p = a.webpack ? a.webpack() : a.modules;
                        p && d.push((function(e) {
                            var t = !0,
                                r = !1,
                                a = void 0;
                            try {
                                for (var i, o = p[Symbol.iterator](); !(t = (i = o.next()).done); t = !0) {
                                    var s = i.value;
                                    if (-1 !== e.indexOf(s)) return n()
                                }
                            } catch (l) {
                                r = !0, a = l
                            } finally {
                                try {
                                    t || null == o.return || o.return()
                                } finally {
                                    if (r) throw a
                                }
                            }
                        }))
                    }
                    var m = a.suspense ? function(e, t) {
                        return r(), o.default.createElement(a.lazy, i({}, e, {
                            ref: t
                        }))
                    } : function(e, t) {
                        r();
                        var n = l(u.subscribe, u.getCurrentValue, u.getCurrentValue);
                        return o.default.useImperativeHandle(t, (function() {
                            return {
                                retry: u.retry
                            }
                        }), []), o.default.useMemo((function() {
                            return n.loading || n.error ? o.default.createElement(a.loading, {
                                isLoading: n.loading,
                                pastDelay: n.pastDelay,
                                timedOut: n.timedOut,
                                error: n.error,
                                retry: u.retry
                            }) : n.loaded ? o.default.createElement((t = n.loaded) && t.__esModule ? t.default : t, e) : null;
                            var t
                        }), [e, n])
                    };
                    return m.preload = function() {
                        return n()
                    }, m.displayName = "LoadableComponent", o.default.forwardRef(m)
                }(p, e)
            }

            function f(e, t) {
                for (var n = []; e.length;) {
                    var r = e.pop();
                    n.push(r(t))
                }
                return Promise.all(n).then((function() {
                    if (e.length) return f(e, t)
                }))
            }
            m.preloadAll = function() {
                return new Promise((function(e, t) {
                    f(u).then(e, t)
                }))
            }, m.preloadReady = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                return new Promise((function(t) {
                    var n = function() {
                        return c = !0, t()
                    };
                    f(d, e).then(n, n)
                }))
            }, window.__NEXT_PRELOADREADY = m.preloadReady;
            var _ = m;
            t.default = _
        },
        32343: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return V
                }
            });
            var r = n(85893),
                a = n(67294),
                i = n(9008),
                o = n.n(i),
                s = n(91567),
                l = n(72887),
                u = n(20606),
                d = n(11750),
                c = n(26042),
                p = n(69396),
                h = n(42298),
                m = n(41684),
                f = n(7410),
                _ = n(38800),
                g = n(29717),
                b = n(45697),
                x = n.n(b),
                v = {
                    propTypes: {
                        author: x().shape({
                            authorPhoto: x().string,
                            name: x().string.isRequired,
                            organization: x().string,
                            slug: x().string,
                            socialHandle: x().string,
                            socialLink: x().string,
                            isNBAStaff: x().bool,
                            featuredAuthor: x().bool,
                            id: x().number
                        }).isRequired
                    },
                    defaultProps: {}
                },
                y = n(45309),
                j = n.n(y);

            function k(e) {
                var t = e.author;
                if (!t) return null;
                if (t.isNBAStaff) return (0, r.jsx)("h4", {
                    className: j().authorStaff,
                    children: t.name
                });
                var n = t.name,
                    a = t.authorPhoto,
                    i = t.organization,
                    o = t.socialHandle,
                    s = t.socialLink,
                    l = t.id,
                    u = t.slug,
                    d = t.featuredAuthor,
                    c = o && s && u;
                return (0, r.jsxs)("div", {
                    className: j().base,
                    children: [a && (0, r.jsx)("img", {
                        src: a,
                        alt: n,
                        className: j().authorPhoto
                    }), (0, r.jsxs)("div", {
                        className: j().bio,
                        children: [(0, r.jsxs)("div", {
                            children: [n && (0, r.jsx)("p", {
                                className: j().authorName,
                                children: n
                            }), i && (0, r.jsx)("p", {
                                className: j().authorOrg,
                                children: i
                            })]
                        }), (0, r.jsxs)("div", {
                            className: j().authorSocial,
                            children: [c && (0, r.jsx)(m.Z, {
                                text: o,
                                href: s,
                                styled: !0
                            }), c && d && " | ", d && (0, r.jsx)(m.Z, {
                                text: "Archive",
                                href: "/news/writers-archive/".concat(l, "/").concat(u),
                                styled: !0
                            })]
                        })]
                    })]
                })
            }
            k.propTypes = v.propTypes, k.defaultProps = v.defaultProps;
            var w = {
                    propTypes: {
                        id: x().oneOfType([x().string, x().number]),
                        title: x().string.isRequired,
                        subtitle: x().string,
                        author: x().oneOfType([x().string, x().object]).isRequired,
                        timestamp: x().number.isRequired,
                        category: x().string.isRequired,
                        taxonomy: x().object,
                        authorHide: x().bool.isRequired,
                        showAd: x().bool,
                        isUpdated: x().bool,
                        sponsor: x().shape({
                            sponsorName: x().string,
                            sponsorLogo: x().string,
                            sponsorUrl: x().string
                        })
                    },
                    defaultProps: {
                        taxonomy: {},
                        id: 0,
                        subtitle: "",
                        isUpdated: !1,
                        showAd: !1,
                        sponsor: null
                    }
                },
                Z = n(8391),
                A = n.n(Z),
                T = ["migrated_user"];

            function N(e) {
                var t = e.id,
                    n = e.title,
                    a = e.subtitle,
                    i = e.author,
                    o = e.timestamp,
                    s = e.category,
                    l = void 0 === s ? "" : s,
                    u = e.taxonomy,
                    d = e.authorHide,
                    b = e.showAd,
                    x = e.isUpdated,
                    v = e.sponsor,
                    y = (i || {}).name,
                    j = -1 !== T.indexOf(y),
                    w = o ? (0, h.Z)(o, "MMMM d, yyyy p") : "",
                    Z = x ? "Updated on " : "",
                    N = l.toLocaleLowerCase(),
                    P = (0, g.Z)({
                        articleType: N,
                        collectionName: N,
                        category: l,
                        taxonomy: u
                    }),
                    R = function(e, t) {
                        var a = e.sponsorName,
                            i = e.sponsorLogo,
                            o = e.sponsorUrl;
                        if (!!(!i || !o)) return null;
                        var s = {
                            title: "Published by ".concat(a),
                            url: o,
                            "data-track": "click",
                            "data-type": "link",
                            "data-id": P["data-id"],
                            "data-text": a,
                            "data-content": n,
                            "data-content-id": t
                        };
                        return (0, r.jsx)("div", {
                            className: A().ahSponser,
                            children: (0, r.jsxs)(m.Z, (0, p.Z)((0, c.Z)({}, s), {
                                children: [(0, r.jsx)("span", {
                                    className: A().ahSponseredby,
                                    children: "Published by"
                                }), (0, r.jsx)(f.Z, {
                                    className: A().ahSponserImage,
                                    alt: a,
                                    src: i
                                })]
                            }))
                        })
                    }(v || {}, t);
                return (0, r.jsxs)("div", {
                    className: A().ah,
                    children: [(0, r.jsxs)("div", {
                        className: A().ahBlock,
                        children: [(0, r.jsxs)("div", {
                            className: A().ahCategory,
                            children: [(0, r.jsx)("h3", {
                                className: A().ahCattext,
                                children: l
                            }), b && (0, r.jsx)(_.Z, {
                                placementId: "article_ad_r_1",
                                domId: "article_ad_s_1",
                                type: "sponsor"
                            })]
                        }), (0, r.jsx)("h1", {
                            className: A().ahTitle,
                            children: n
                        }), a && (0, r.jsx)("p", {
                            className: A().ahSubtitle,
                            children: a
                        })]
                    }), (0, r.jsxs)("div", {
                        className: A().ahBy,
                        children: [(0, r.jsxs)("div", {
                            className: A().ahAuthor,
                            children: [d || j ? (0, r.jsx)("div", {}) : (0, r.jsx)(k, {
                                author: i
                            }), (0, r.jsx)("time", {
                                className: A().ahDate,
                                children: "".concat(Z).concat(w)
                            })]
                        }), R]
                    })]
                })
            }
            N.propTypes = w.propTypes, N.defaultProps = w.defaultProps;
            var P = n(93967),
                R = n.n(P),
                C = n(44762),
                S = n(31465),
                I = n.n(S);
            var L = {
                    propTypes: {
                        powerRankings: x().arrayOf(x().shape({
                            currentWeekRank: x().number,
                            lastWeekRank: x().number,
                            powerRankSummary: x().string,
                            teamId: x().number,
                            teamLink: x().string,
                            teamName: x().string
                        }))
                    },
                    defaultProps: {}
                },
                H = n(59678),
                O = n.n(H);
            B.propTypes = L.propTypes, B.defaultProps = L.defaultProps;

            function B(e) {
                var t = e.powerRankings;
                if (!t) return null;
                var n = t.map((function(e) {
                    var t, n, a = (t = e.currentWeekRank, n = e.lastWeekRank, t < n ? {
                        arrow: "\u2191",
                        positive: !0
                    } : t > n ? {
                        arrow: "\u2193",
                        positive: !1
                    } : {
                        arrow: "",
                        positive: !0
                    });
                    return (0, r.jsxs)("div", {
                        className: O().pr,
                        children: [(0, r.jsxs)("div", {
                            className: O().prTop,
                            children: [(0, r.jsx)("div", {
                                className: O().prRank,
                                title: "Previous Week: ".concat(e.lastWeekRank),
                                children: (0, r.jsxs)("span", {
                                    children: ["#", e.currentWeekRank]
                                })
                            }), (0, r.jsx)("div", {
                                className: O().prLogo,
                                children: (0, r.jsx)(C.Z, {
                                    tid: e.teamId
                                })
                            }), (0, r.jsx)(m.Z, {
                                text: e.teamName,
                                href: e.teamLink,
                                styled: !0,
                                className: O().prTeam
                            })]
                        }), (0, r.jsxs)("span", {
                            children: [(0, r.jsx)("span", {
                                className: O().prPreviousRank,
                                children: "Last Week:"
                            }), (0, r.jsxs)("span", {
                                className: O().prChange,
                                "data-rank-increased": a.positive,
                                children: [e.lastWeekRank, (0, r.jsx)("span", {
                                    className: O().prChangeSymbol,
                                    children: a.arrow
                                })]
                            })]
                        }), (0, r.jsx)("div", {
                            className: R()(I().article, I().power),
                            dangerouslySetInnerHTML: {
                                __html: e.powerRankSummary
                            }
                        })]
                    }, e.teamId)
                }));
                return (0, r.jsx)(r.Fragment, {
                    children: n
                })
            }
            var G = n(48240),
                M = n(364),
                E = n(86488),
                F = n.n(E);

            function V(e) {
                var t, n = e.article,
                    i = e.related,
                    c = void 0 === i ? [] : i,
                    p = e.showSponsorAd,
                    h = void 0 !== p && p,
                    m = (0, a.useContext)(s.N).isWebView,
                    f = c.length > 0,
                    _ = n.author || {
                        name: n.authorName
                    },
                    g = "nbabet" === n.type ? {
                        sponsorName: n.sponsorName,
                        sponsorLogo: n.sponsorLogo,
                        sponsorUrl: n.sponsorUrl
                    } : {};
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsxs)(o(), {
                        children: [!n.hasSeo && (0, r.jsxs)(r.Fragment, {
                            children: [(0, r.jsx)("meta", {
                                name: "twitter:card",
                                content: "summary_large_image"
                            }), (0, r.jsx)("meta", {
                                name: "twitter:title",
                                content: n.title
                            }), (0, r.jsx)("meta", {
                                name: "twitter:image",
                                content: n.featuredImage
                            }), (0, r.jsx)("meta", {
                                property: "og:title",
                                content: n.title
                            }), (0, r.jsx)("meta", {
                                property: "og:description",
                                content: n.excerpt
                            }), (0, r.jsx)("meta", {
                                property: "og:image",
                                content: n.featuredImage
                            })]
                        }), m && (0, r.jsx)("meta", {
                            name: "robots",
                            content: "noindex"
                        })]
                    }), (0, r.jsx)(u.Z, {
                        padding: F().arBlock,
                        children: (0, r.jsxs)("article", {
                            className: F().arContainer,
                            children: [(0, r.jsx)(N, {
                                id: n.id,
                                title: n.title,
                                subtitle: n.excerpt,
                                category: null === (t = n.categoryPrimary) || void 0 === t ? void 0 : t.name,
                                taxonomy: n.taxonomy,
                                author: _,
                                timestamp: n.timestamp,
                                authorHide: n.authorHide || !1,
                                showAd: h,
                                isUpdated: n.useUpdatedDate,
                                sponsor: g
                            }), f && !m ? (0, r.jsxs)(d.oe, {
                                children: [(0, r.jsxs)(d.dv, {
                                    children: [(0, r.jsx)(G.Z, {
                                        content: n.contentFiltered
                                    }), (0, r.jsx)(B, {
                                        powerRankings: n.powerRankings
                                    })]
                                }), (0, r.jsx)(d.O6, {
                                    className: F().arRight,
                                    children: (0, r.jsxs)("aside", {
                                        children: [(0, r.jsx)("h3", {
                                            className: F().arAsidetext,
                                            children: "Related"
                                        }), (0, r.jsx)("ul", {
                                            children: c.map((function(e, t) {
                                                var n;
                                                return (0, r.jsx)("li", {
                                                    className: F().arRelateditem,
                                                    children: (0, r.jsx)(M.Z, {
                                                        subtitle: e.excerpt,
                                                        title: e.title,
                                                        shortTitle: e.shortTitle,
                                                        category: null === (n = e.categoryPrimary) || void 0 === n ? void 0 : n.name,
                                                        taxonomy: e.taxonomy,
                                                        type: e.type,
                                                        href: (0, l.Z)(e),
                                                        analytics: {
                                                            totalArticles: c.length,
                                                            articleType: "side",
                                                            id: e.id,
                                                            index: t
                                                        }
                                                    })
                                                }, e.id)
                                            }))
                                        })]
                                    })
                                })]
                            }) : (0, r.jsxs)(r.Fragment, {
                                children: [(0, r.jsx)(G.Z, {
                                    content: n.contentFiltered
                                }), (0, r.jsx)(B, {
                                    powerRankings: n.powerRankings
                                })]
                            })]
                        })
                    })]
                })
            }
        },
        48240: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return l
                }
            });
            var r = n(85893),
                a = n(31465),
                i = n.n(a),
                o = n(45697),
                s = {
                    propTypes: {
                        content: n.n(o)().string
                    },
                    defaultProps: {
                        content: null
                    }
                };

            function l(e) {
                var t = e.content;
                return t ? (0, r.jsx)("div", {
                    className: i().article,
                    dangerouslySetInnerHTML: {
                        __html: t
                    }
                }) : null
            }
            l.propTypes = s.propTypes, l.defaultProps = s.defaultProps
        },
        31929: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return u
                }
            });
            var r = n(85893),
                a = n(67294),
                i = n(42669),
                o = n(38800),
                s = n(89637),
                l = n.n(s);

            function u(e) {
                var t = e.image,
                    n = e.mobileImage,
                    s = e.showAd,
                    u = void 0 !== s && s,
                    d = e.adId,
                    c = e.domAdId,
                    p = (0, i.Z)().width,
                    h = (0, a.useMemo)((function() {
                        return {
                            backgroundImage: "url(".concat(p <= 480 ? n : t, ")")
                        }
                    }), [t, n, p]);
                return t || n ? (0, r.jsx)("div", {
                    "data-testid": "page-banner",
                    className: l().banner,
                    style: h,
                    children: u && d && (0, r.jsx)("div", {
                        children: (0, r.jsx)(o.Z, {
                            type: "sponsor",
                            placementId: d,
                            domId: c
                        })
                    })
                }) : (0, r.jsx)(r.Fragment, {})
            }
        },
        91736: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(47568),
                a = n(34051),
                i = n.n(a),
                o = n(85893),
                s = n(67294),
                l = n(45697),
                u = n.n(l),
                d = n(41226),
                c = n(91567),
                p = n(84974),
                h = n(2433),
                m = n(97847),
                f = n(41684),
                _ = n(99731),
                g = n.n(_),
                b = n(38799);

            function x(e) {
                e.statusCode;
                var t = e.layout,
                    n = (0, s.useContext)(c.N).isWebView;
                return (0, o.jsxs)(p.Z, {
                    layout: t,
                    isWebView: n,
                    children: [(0, o.jsx)(m.Z, {
                        title: "Page Not Found"
                    }), (0, o.jsx)(h.Z, {
                        children: (0, o.jsxs)("div", {
                            className: g().container,
                            children: [(0, o.jsx)("h1", {
                                className: g().title,
                                children: "Page not found."
                            }), (0, o.jsx)("p", {
                                children: "The page you are looking for is not available."
                            }), (0, o.jsxs)("p", {
                                children: ["Go to the", " ", (0, o.jsx)(f.Z, {
                                    href: "/",
                                    className: g().link,
                                    children: "homepage"
                                }), " or ", (0, o.jsx)(f.Z, {
                                    href: "/search",
                                    className: g().link,
                                    children: "search"
                                }), "."]
                            })]
                        })
                    })]
                })
            }
            x.getInitialProps = function() {
                var e = (0, r.Z)(i().mark((function e(t) {
                    var n, r, a, o;
                    return i().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.res, r = t.err, a = (null === n || void 0 === n ? void 0 : n.statusCode) || (null === r || void 0 === r ? void 0 : r.statusCode) || 404, e.next = 4, (0, d.sC)({
                                    path: "E404"
                                });
                            case 4:
                                return o = e.sent, e.abrupt("return", {
                                    statusCode: a,
                                    layout: o
                                });
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })));
                return function(t) {
                    return e.apply(this, arguments)
                }
            }(), x.propTypes = {
                layout: b.x0.isRequired,
                statusCode: u().number.isRequired
            }, t.default = x
        },
        25085: function(e, t, n) {
            "use strict";
            n.d(t, {
                i: function() {
                    return R
                }
            });
            var r, a = n(26042),
                i = n(69396),
                o = n(85893),
                s = n(93967),
                l = n.n(s),
                u = n(14924),
                d = n(5152),
                c = n.n(d),
                p = c()((function() {
                    return n.e(4566).then(n.bind(n, 4566))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [4566]
                        }
                    },
                    ssr: !0
                }),
                h = c()((function() {
                    return n.e(67488).then(n.bind(n, 67488))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [67488]
                        }
                    },
                    ssr: !1
                }),
                m = c()((function() {
                    return n.e(31726).then(n.bind(n, 31726))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [31726]
                        }
                    },
                    ssr: !0
                }),
                f = c()((function() {
                    return n.e(19268).then(n.bind(n, 19268))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [19268]
                        }
                    },
                    ssr: !0
                }),
                _ = c()((function() {
                    return n.e(63459).then(n.bind(n, 63459))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [63459]
                        }
                    },
                    ssr: !0
                }),
                g = c()((function() {
                    return n.e(63340).then(n.bind(n, 63340))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [63340]
                        }
                    },
                    ssr: !0
                }),
                b = c()((function() {
                    return n.e(21111).then(n.bind(n, 21111))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [21111]
                        }
                    },
                    ssr: !0
                }),
                x = c()((function() {
                    return n.e(58395).then(n.bind(n, 58395))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [58395]
                        }
                    },
                    ssr: !1
                }),
                v = c()((function() {
                    return n.e(70581).then(n.bind(n, 70581))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [70581]
                        }
                    },
                    ssr: !1
                }),
                y = c()((function() {
                    return n.e(5526).then(n.bind(n, 5526))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [5526]
                        }
                    },
                    ssr: !1
                }),
                j = c()((function() {
                    return n.e(56443).then(n.bind(n, 56443))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [56443]
                        }
                    },
                    ssr: !0
                }),
                k = c()((function() {
                    return n.e(57914).then(n.bind(n, 57914))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [57914]
                        }
                    },
                    ssr: !0
                }),
                w = c()((function() {
                    return n.e(11643).then(n.bind(n, 11643))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [11643]
                        }
                    },
                    ssr: !0
                }),
                Z = c()((function() {
                    return n.e(28425).then(n.bind(n, 28425))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [28425]
                        }
                    },
                    ssr: !0
                }),
                A = c()((function() {
                    return n.e(52446).then(n.bind(n, 52446))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [52446]
                        }
                    },
                    ssr: !0
                }),
                T = c()((function() {
                    return n.e(63221).then(n.bind(n, 63221))
                }), {
                    loadableGenerated: {
                        webpack: function() {
                            return [63221]
                        }
                    },
                    ssr: !0
                }),
                N = (r = {}, (0, u.Z)(r, "manage-nba/opin-discount-partners", h), (0, u.Z)(r, "manage-nba/packages-rebuild-hero", p), (0, u.Z)(r, "manage-nba/league-packages-hero", m), (0, u.Z)(r, "manage-nba/packages-portal", f), (0, u.Z)(r, "manage-nba/promo-banner", g), (0, u.Z)(r, "manage-nba/blockout-module", _), (0, u.Z)(r, "manage-nba/packages-rebuild-packages-content", v), (0, u.Z)(r, "manage-nba/packages-rebuild-packages-content-item", y), (0, u.Z)(r, "manage-nba/packages-rebuild-transactional-purchases", b), (0, u.Z)(r, "manage-nba/packages-rebuild-transactional-purchases-item", x), (0, u.Z)(r, "manage-nba/how-to-watch", j), (0, u.Z)(r, "manage-nba/packages-rebuild-existing-subs", null), (0, u.Z)(r, "manage-nba/paragraph", k), (0, u.Z)(r, "manage-nba/heading", w), (0, u.Z)(r, "manage-nba/spacer", Z), (0, u.Z)(r, "manage-nba/group", A), (0, u.Z)(r, "manage-nba/cta-card", T), r);

            function P(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                    r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                    s = e.type,
                    u = e.attributes,
                    d = e.content,
                    c = e.data,
                    p = u || {},
                    h = p.hideOnMobile,
                    m = void 0 !== h && h,
                    f = N[s];
                if (!f) return null;
                var _ = r || n,
                    g = n,
                    b = l()(m && "hide_on_mobile");
                return (0, o.jsx)(f, (0, i.Z)((0, a.Z)({
                    sectionPos: _.toString(),
                    pos: g.toString(),
                    className: b
                }, u, c, t), {
                    children: d && d.map((function(e, n) {
                        return (null === e || void 0 === e ? void 0 : e.type) ? P(e, t, n, _) : null
                    })).filter(Boolean)
                }), "".concat(s, "-").concat(n))
            }

            function R(e) {
                var t, n = e || {},
                    r = n.blocks,
                    a = n.blockProps;
                return r ? null === (t = r.map((function(e, t) {
                    return P(e, a, t)
                }))) || void 0 === t ? void 0 : t.filter(Boolean) : []
            }
        },
        6210: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return S
                }
            });
            var r = n(26042),
                a = n(69396),
                i = n(85893),
                o = n(67294),
                s = n(84974),
                l = n(38800),
                u = n(2433),
                d = n(17594),
                c = n(25085),
                p = n(31929),
                h = n(97847),
                m = n(31465),
                f = n.n(m),
                _ = n(93860),
                g = n.n(_),
                b = n(32343),
                x = n(91736),
                v = n(67724),
                y = n(92033),
                j = n(45697),
                k = n.n(j),
                w = n(38799),
                Z = {
                    propTypes: {
                        layout: w.x0,
                        page: w.cm.isRequired,
                        region: k().string
                    },
                    defaultProps: {
                        layout: null,
                        region: ""
                    }
                },
                A = n(60196),
                T = n(20606),
                N = n(37346),
                P = {
                    children: k().node.isRequired
                };

            function R(e) {
                var t = e.children;
                return (0, i.jsx)("div", {
                    onClick: function(e) {
                        e.preventDefault(), e.stopPropagation()
                    },
                    children: t
                })
            }

            function C(e) {
                var t = e.children,
                    n = e.pageTitle,
                    r = void 0 === n ? "" : n,
                    a = e.disableLinks,
                    o = void 0 !== a && a,
                    s = (0, i.jsx)(T.Z, {
                        header: r ? (0, i.jsx)("div", {
                            className: g().contentTitleContainer,
                            children: (0, i.jsx)(N.Z, {
                                is: "h1",
                                className: g().contentTitle,
                                text: r
                            })
                        }) : (0, i.jsx)(i.Fragment, {}),
                        children: t
                    });
                return (0, i.jsx)(u.Z, {
                    children: o ? (0, i.jsx)(R, {
                        children: s
                    }) : s
                })
            }

            function S(e) {
                var t, n, m = e.layout,
                    _ = e.page,
                    j = e.region,
                    k = function() {
                        return (0, o.useEffect)((function() {
                            var e = document.querySelector(".full-size-iframe");
                            if (e) {
                                var t = e.firstChild,
                                    n = function() {
                                        return t.contentWindow.postMessage("requestFrameSize", v.Zz)
                                    };
                                window.onresize = function() {
                                    n()
                                }, t.onload = function() {
                                    n(), setInterval((function() {
                                        n()
                                    }), 1e3)
                                }, window.addEventListener("message", (function(t) {
                                    if (new URL(t.origin).host.endsWith("nba.com")) try {
                                        var n = JSON.parse(t.data);
                                        if (!("requestFrameSize" === n.type)) return;
                                        e.height = n.height
                                    } catch (r) {}
                                }), !1)
                            }
                        }), []), (0, i.jsx)("section", {
                            dangerouslySetInnerHTML: {
                                __html: B
                            },
                            className: f().article
                        })
                    };
                if ("404" === _) return (0, i.jsx)(x.default, {
                    statusCode: 404,
                    layout: m
                });
                var w = (_ || {}).contentExpanded,
                    Z = void 0 === w ? [] : w,
                    T = Z.length > 0,
                    N = null === _ || void 0 === _ || null === (t = _.name) || void 0 === t ? void 0 : t.includes("spectrum-sportsnet"),
                    P = null === _ || void 0 === _ || null === (n = _.name) || void 0 === n ? void 0 : n.includes("clippervision"),
                    R = !(null === _ || void 0 === _ ? void 0 : _.hideDisplayAds),
                    S = _.title,
                    I = _.excerpt,
                    L = _.shortTitle,
                    H = _.categoryPrimary,
                    O = void 0 === H ? {} : H,
                    B = _.contentFiltered,
                    G = _.components,
                    M = void 0 === G ? [] : G,
                    E = _.treatAsArticle,
                    F = _.template,
                    V = _.showSponsorship,
                    W = _.draft,
                    q = void 0 === W ? {} : W,
                    D = O.menu,
                    U = O.bannerImage,
                    z = O.mobileBannerImage,
                    K = O.adfuelTarget,
                    J = !(!U || !V || N || P),
                    Y = J || !V ? "" : K,
                    X = !!U,
                    Q = (0, y.Z)(["taxonomy", "categories"], _, {}),
                    $ = Object.values(Q),
                    ee = function() {
                        return U ? (0, i.jsx)(p.Z, {
                            image: U,
                            mobileImage: z,
                            showAd: J,
                            adId: "pages_ad_r_1",
                            domAdId: "pages_ad_s_1"
                        }) : null
                    },
                    te = function() {
                        if (E) return (0, i.jsx)(u.Z, {
                            children: (0, i.jsx)(b.Z, {
                                article: _
                            })
                        });
                        switch (F) {
                            case "default":
                            case "nbabet":
                                return (0, i.jsxs)(i.Fragment, {
                                    children: [ee(), _.afterHeader && (0, i.jsx)("div", {
                                        className: g().header,
                                        dangerouslySetInnerHTML: {
                                            __html: _.afterHeader
                                        }
                                    }), R ? (0, i.jsx)(l.Z, {
                                        className: g().ad,
                                        placementId: A.AK.B1,
                                        singleton: "ad_mod_baa3571cc",
                                        domId: "pages_ad_b_1",
                                        marketingDomId: "pages_ad_m_1"
                                    }) : (0, i.jsx)("div", {
                                        className: g().adEmpty
                                    }), (0, i.jsxs)(i.Fragment, {
                                        children: [(T || B) && (0, i.jsx)(C, {
                                            pageTitle: _.title,
                                            children: T ? (0, c.i)({
                                                blocks: Z
                                            }) : (0, i.jsx)(k, {})
                                        }), (0, i.jsx)(d.Z, {
                                            feed: M,
                                            isTentpole: !0,
                                            region: null,
                                            adfuelTarget: Y,
                                            isWebview: !1,
                                            template: F
                                        })]
                                    })]
                                });
                            case "webview":
                                return (0, i.jsxs)(i.Fragment, {
                                    children: [(T || B) && (0, i.jsx)(C, {
                                        pageTitle: _.title,
                                        disableLinks: !0,
                                        children: T ? (0, c.i)({
                                            blocks: Z
                                        }) : (0, i.jsx)(k, {})
                                    }), (0, i.jsx)(d.Z, {
                                        feed: M,
                                        isTentpole: !0,
                                        region: null,
                                        adfuelTarget: K,
                                        isWebview: !0,
                                        template: F
                                    })]
                                });
                            case "full-bleed":
                                return (0, i.jsxs)(i.Fragment, {
                                    children: [ee(), T ? (0, c.i)({
                                        blocks: Z
                                    }) : (0, i.jsx)(k, {})]
                                });
                            default:
                                return null
                        }
                    };
                return "webview" === F ? (0, i.jsxs)(s.Z, {
                    layout: (0, r.Z)({}, m),
                    region: j,
                    isWebView: !0,
                    children: [(0, i.jsx)(h.Z, {
                        title: S,
                        children: (0, i.jsx)("meta", {
                            name: "post-id",
                            content: _.id
                        })
                    }), (0, i.jsx)("main", {
                        children: te()
                    })]
                }) : (0, i.jsxs)(s.Z, {
                    layout: (0, a.Z)((0, r.Z)({}, m), {
                        subNav: D
                    }),
                    region: j,
                    draftTracker: q,
                    hasBanner: X,
                    children: [(0, i.jsxs)(h.Z, {
                        title: S,
                        seo: _.seo,
                        description: I || S || L,
                        children: [(0, i.jsx)("meta", {
                            name: "post-id",
                            content: _.id
                        }), (0, i.jsx)("meta", {
                            name: "keywords",
                            content: $.join(", ")
                        })]
                    }), (0, i.jsx)("main", {
                        className: g().tentpoleMain,
                        children: te()
                    })]
                })
            }
            R.propTypes = P, S.propTypes = Z.propTypes, S.defaultProps = Z.defaultProps
        },
        86488: function(e) {
            e.exports = {
                arBlock: "Article_arBlock__s35Il",
                arContainer: "Article_arContainer__18r3N",
                arRight: "Article_arRight__NaiJE",
                arAsidetext: "Article_arAsidetext__ThBVI",
                arRelateditem: "Article_arRelateditem__yyBf3"
            }
        },
        45309: function(e) {
            e.exports = {
                base: "ArticleAuthor_base__LYqxf",
                bio: "ArticleAuthor_bio__f9ODF",
                authorPhoto: "ArticleAuthor_authorPhoto__35xV4",
                authorStaff: "ArticleAuthor_authorStaff__aHDxv",
                authorName: "ArticleAuthor_authorName___AnQD",
                authorOrg: "ArticleAuthor_authorOrg__prhnv",
                authorSocial: "ArticleAuthor_authorSocial__dBwO2"
            }
        },
        8391: function(e) {
            e.exports = {
                ah: "ArticleHeader_ah__BBZ33",
                ahBlock: "ArticleHeader_ahBlock__aoXAL",
                ahCategory: "ArticleHeader_ahCategory__txfsx",
                ahCattext: "ArticleHeader_ahCattext__ukmoa",
                ahTitle: "ArticleHeader_ahTitle__mIo92",
                ahSubtitle: "ArticleHeader_ahSubtitle__4qa5C",
                ahBy: "ArticleHeader_ahBy__2ddjx",
                ahAuthor: "ArticleHeader_ahAuthor__NbBw0",
                ahDate: "ArticleHeader_ahDate__J3fwr",
                ahSponser: "ArticleHeader_ahSponser__ejTJw",
                ahSponseredBy: "ArticleHeader_ahSponseredBy__nrpRO",
                ahSponserimage: "ArticleHeader_ahSponserimage__bTbcU"
            }
        },
        59678: function(e) {
            e.exports = {
                pr: "ArticlePowerRankings_pr__payHO",
                prTop: "ArticlePowerRankings_prTop__UrGiu",
                prRank: "ArticlePowerRankings_prRank__mE_b1",
                prPreviousRank: "ArticlePowerRankings_prPreviousRank__bcK1F",
                prLogo: "ArticlePowerRankings_prLogo__5ZnGA",
                prTeam: "ArticlePowerRankings_prTeam__dTyqP",
                prChangeSymbol: "ArticlePowerRankings_prChangeSymbol__qbV5G",
                prChange: "ArticlePowerRankings_prChange__o7x88"
            }
        },
        89637: function(e) {
            e.exports = {
                banner: "PageBanner_banner__t0EWb"
            }
        },
        99731: function(e) {
            e.exports = {
                container: "error_container___K0av",
                title: "error_title__TRWKY",
                link: "error_link__F6PIR"
            }
        },
        93860: function(e) {
            e.exports = {
                header: "TentpoleView_header__uu5HV",
                tentpoleMain: "TentpoleView_tentpoleMain__zA_vK",
                contentTitleContainer: "TentpoleView_contentTitleContainer___ovxP",
                contentTitle: "TentpoleView_contentTitle__VZ0w7",
                ad: "TentpoleView_ad__H85yO",
                adEmpty: "TentpoleView_adEmpty__gHeff"
            }
        },
        5152: function(e, t, n) {
            e.exports = n(90638)
        }
    }
]);