(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [46456], {
        44010: function(e, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/[[...root]]", function() {
                return n(98953)
            }])
        },
        51101: function(e, t, n) {
            "use strict";
            n.d(t, {
                dd: function() {
                    return W
                },
                He: function() {
                    return G
                },
                HM: function() {
                    return q
                },
                Xw: function() {
                    return M
                },
                pE: function() {
                    return E
                },
                Q3: function() {
                    return F
                }
            });
            var a = n(47568),
                r = n(26042),
                i = n(69396),
                s = n(10253),
                o = n(34051),
                c = n.n(o),
                l = n(77226),
                d = n(14648),
                u = n(67724),
                m = "boxscoresummaryv3",
                p = {
                    LeagueID: u.i8,
                    GameID: ""
                },
                h = function(e) {
                    return e.boxScoreSummary
                },
                x = function() {
                    return {}
                },
                v = function() {
                    var e = (0, a.Z)(c().mark((function e(t) {
                        var n;
                        return c().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = {
                                        resource: m,
                                        transform: h,
                                        parse: function(e) {
                                            return e
                                        },
                                        params: (0, r.Z)({}, p, t),
                                        fail: x
                                    }, e.abrupt("return", d.Z.get(n));
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                f = {
                    resource: m,
                    params: p,
                    transform: h,
                    get: v,
                    fail: x
                },
                _ = "boxscoretraditionalv3",
                g = {
                    LeagueID: u.i8,
                    GameID: "",
                    startPeriod: 0,
                    endPeriod: 0,
                    startRange: 0,
                    endRange: 0,
                    rangeType: 0
                },
                y = function(e) {
                    return e.boxScoreTraditional
                },
                Z = (function() {
                    var e = (0, a.Z)(c().mark((function e(t) {
                        var n;
                        return c().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = {
                                        resource: _,
                                        transform: y,
                                        parse: function(e) {
                                            return e
                                        },
                                        params: (0, r.Z)({}, g, t)
                                    }, e.abrupt("return", d.Z.get(n));
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))
                }(), "boxscoretraditionalv3"),
                b = {
                    traditional: "boxscoretraditionalv3",
                    advanced: "boxscoreadvancedv3",
                    misc: "boxscoremiscv3",
                    fourfactors: "boxscorefourfactorsv3",
                    usage: "boxscoreusagev3",
                    scoring: "boxscorescoringv3",
                    tracking: "boxscoreplayertrackv3",
                    hustle: "boxscorehustlev2",
                    defense: "boxscoredefensivev2",
                    matchups: "boxscorematchupsv3"
                },
                j = {
                    LeagueID: u.i8,
                    GameID: "",
                    startPeriod: 0,
                    endPeriod: 0,
                    startRange: 0,
                    endRange: 0,
                    rangeType: 0
                },
                T = function(e) {
                    return e[Object.keys(e)[1]]
                },
                S = function() {
                    return {}
                },
                N = function() {
                    var e = (0, a.Z)(c().mark((function e() {
                        var t, n, a, i = arguments;
                        return c().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return t = i.length > 0 && void 0 !== i[0] ? i[0] : Z, n = i.length > 1 ? i[1] : void 0, a = {
                                        resource: t.length ? b[t] : b.traditional,
                                        transform: T,
                                        parse: function(e) {
                                            return e
                                        },
                                        params: (0, r.Z)({}, j, n),
                                        fail: S
                                    }, e.abrupt("return", d.Z.get(a));
                                case 3:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                I = {
                    params: j,
                    transform: T,
                    get: N,
                    fail: S,
                    resources: b
                },
                w = "playbyplayv3",
                k = {
                    LeagueID: u.i8,
                    StartPeriod: 0,
                    EndPeriod: 0
                },
                C = function(e) {
                    return e.game
                },
                L = function() {
                    return {}
                },
                R = (function() {
                    var e = (0, a.Z)(c().mark((function e(t) {
                        var n;
                        return c().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = {
                                        resource: w,
                                        transform: C,
                                        parse: function(e) {
                                            return e
                                        },
                                        params: (0, r.Z)({}, k, t),
                                        fail: L
                                    }, e.abrupt("return", d.Z.get(n));
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))
                }(), n(88513)),
                P = n(28981);

            function H(e) {
                try {
                    var t = e.slice(0, 2);
                    if ("00" !== t) {
                        var n = (0, l.AA)(t);
                        if (n.length > 0) return "".concat(R.R1, "/").concat(n, "/liveData")
                    }
                } catch (a) {
                    (0, P.Z)({
                        action: "getLivePathBase for ".concat(e),
                        error: a
                    })
                }
                return R.Cs
            }

            function G(e) {
                return O.apply(this, arguments)
            }

            function O() {
                return (O = (0, a.Z)(c().mark((function e(t) {
                    var n, a, r, i;
                    return c().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = "".concat(H(t), "/boxscore/boxscore_").concat(t, ".json"), e.next = 3, (0, R.aY)(n);
                            case 3:
                                return a = e.sent, r = a.game, i = void 0 === r ? {} : r, e.abrupt("return", i);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            function q(e) {
                return B.apply(this, arguments)
            }

            function B() {
                return (B = (0, a.Z)(c().mark((function e(t) {
                    var n, a, s;
                    return c().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = "".concat(H(t), "/playbyplay/playbyplay_").concat(t, ".json"), e.next = 3, (0, R.aY)(n);
                            case 3:
                                return a = e.sent, s = a.game || {
                                    gameId: t,
                                    actions: []
                                }, e.abrupt("return", (0, i.Z)((0, r.Z)({}, s), {
                                    source: "ngss"
                                }));
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            function M(e) {
                return A.apply(this, arguments)
            }

            function A() {
                return (A = (0, a.Z)(c().mark((function e(t) {
                    var n;
                    return c().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, f.get({
                                    GameID: t
                                });
                            case 2:
                                return n = e.sent, e.abrupt("return", n);
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            function E(e) {
                return D.apply(this, arguments)
            }

            function D() {
                return (D = (0, a.Z)(c().mark((function e(t) {
                    var n, a;
                    return c().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = "".concat(R.Cs, "/gameOdds/").concat(t, ".json"), e.next = 3, (0, R.aY)(n);
                            case 3:
                                return a = e.sent.odds, e.abrupt("return", a);
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            function W(e) {
                return U.apply(this, arguments)
            }

            function U() {
                return U = (0, a.Z)(c().mark((function e(t) {
                    var n, a, r, i, o, l, d, u, m, p, h, x, v, f, _;
                    return c().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.resource, a = t.gameId, r = t.rangePeriod, i = t.rangeTime, o = void 0 === i ? [0, 0] : i, l = t.isCustomRange, d = void 0 !== l && l, u = r ? JSON.parse(r) : {
                                    startPeriod: 0,
                                    endPeriod: 0,
                                    rangeType: 0
                                }, m = u.startPeriod, p = u.endPeriod, h = u.rangeType, x = (0, s.Z)(o, 2), v = x[0], f = x[1], d && (h = 2), e.next = 8, I.get(n, {
                                    GameID: a,
                                    endPeriod: p,
                                    rangeType: h,
                                    startPeriod: m,
                                    startRange: v,
                                    endRange: f
                                });
                            case 8:
                                return _ = e.sent, e.abrupt("return", _);
                            case 10:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                }))), U.apply(this, arguments)
            }

            function F() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments.length > 1 ? arguments[1] : void 0;
                if (!t) return e;
                var n = e.homeTeam || {},
                    a = e.awayTeam || {},
                    s = t.homeTeam || {},
                    o = t.awayTeam || {};
                return (0, i.Z)((0, r.Z)({}, e, t), {
                    homeTeam: (0, r.Z)({}, n, s),
                    awayTeam: (0, r.Z)({}, a, o)
                })
            }
        },
        83466: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return s
                }
            });
            var a = n(85893),
                r = n(67294),
                i = n(88322);

            function s(e) {
                var t = e.date,
                    n = e.className,
                    s = (0, r.useMemo)((function() {
                        try {
                            return t ? (0, i.Z)(t, "MMMM d, yyyy") : null
                        } catch (e) {
                            return null
                        }
                    }), [t]);
                return s ? (0, a.jsx)("span", {
                    className: n,
                    children: s
                }) : null
            }
        },
        21728: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return T
                }
            });
            var a = n(26042),
                r = n(69396),
                i = n(85893),
                s = n(93967),
                o = n.n(s),
                c = n(9849),
                l = n(72887),
                d = n(20606),
                u = n(41684),
                m = n(86414),
                p = n(58819),
                h = n(38800),
                x = n(92033),
                v = n(61184),
                f = n.n(v),
                _ = n(45697),
                g = n.n(_),
                y = n(38799),
                Z = n(88050),
                b = {
                    items: g().arrayOf(g().oneOfType([y.c7, Z.Z])),
                    className: g().string,
                    headlineLocation: g().oneOf(["main", "siderail"]).isRequired
                },
                j = {
                    main: {
                        domId: "home_ad_s_4",
                        placementId: ""
                    },
                    siderail: {
                        domId: "home_ad_b_5",
                        placementId: "nat_atf_01"
                    }
                };

            function T(e) {
                var t, n, s = e.items,
                    v = void 0 === s ? [] : s,
                    _ = e.className,
                    g = e.headlineLocation;
                return (0, i.jsx)(d.Z, {
                    title: "Headlines",
                    titleLink: {
                        text: "See more",
                        href: "/news"
                    },
                    className: o()(f().hl, _),
                    "data-component-id": "headlines",
                    "data-component-location": g,
                    titleAs: "h3",
                    children: (0, i.jsxs)("ul", {
                        children: [(0, i.jsx)("li", {
                            className: f().hlAd,
                            children: (0, i.jsx)(h.Z, {
                                type: "contextual",
                                lazyLoad: !0,
                                placementId: (null === (t = j[g]) || void 0 === t ? void 0 : t.placementId) || "",
                                domId: (null === (n = j[g]) || void 0 === n ? void 0 : n.domId) || ""
                            })
                        }), v.map((function(e, t) {
                            var n = [(0, x.Z)(["id"], e, t), (0, x.Z)(["type"], e, ""), (0, x.Z)(["shortTitle"], e, ""), (0, x.Z)(["title"], e, ""), (0, x.Z)(["entitlements"], e, ""), (0, x.Z)(["category"], e, ""), (0, x.Z)(["categoryPrimary"], e, ""), (0, x.Z)(["taxonomy"], e, {})],
                                s = n[0],
                                o = n[1],
                                d = n[2],
                                h = n[3],
                                v = n[4],
                                _ = n[5],
                                g = n[6],
                                y = n[7],
                                Z = "".concat(o, "-").concat(s),
                                b = d || h,
                                j = function(e) {
                                    return "video" === e ? (0, i.jsx)(m.Z, {
                                        className: f().hlVideoIcon
                                    }) : null
                                }(o),
                                T = "hyperlink" === o,
                                S = (0, l.Z)(e),
                                N = (0, c.O0)({
                                    isVideo: "video" === o,
                                    title: h,
                                    index: t,
                                    isPremium: !1,
                                    dataContent: s,
                                    category: _,
                                    categoryPrimary: g,
                                    taxonomy: y
                                });
                            return (0, i.jsxs)("li", {
                                className: f().hlItem,
                                children: [(0, i.jsx)("h4", {
                                    children: (0, i.jsxs)(u.Z, (0, r.Z)((0, a.Z)({
                                        showExternalIcon: T
                                    }, N), {
                                        href: S,
                                        children: [j, " ", b]
                                    }))
                                }), v ? (0, i.jsx)("div", {
                                    children: (0, i.jsx)(p.Z, {
                                        type: v,
                                        className: f().hlSubTag
                                    })
                                }) : null]
                            }, Z)
                        }))]
                    })
                })
            }
            T.propTypes = b
        },
        96473: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return N
                }
            });
            var a = n(26042),
                r = n(69396),
                i = n(99534),
                s = n(85893),
                o = n(93967),
                c = n.n(o),
                l = n(77226),
                d = n(47347),
                u = n(83466),
                m = n(10253),
                p = n(45697),
                h = n.n(p),
                x = {
                    propTypes: {
                        gameStatus: h().number.isRequired,
                        gameStatusText: h().string,
                        lightPreseasonText: h().bool,
                        isPreseason: h().bool.isRequired,
                        hideScores: h().bool
                    },
                    defaultProps: {
                        lightPreseasonText: !1,
                        gameStatusText: null,
                        hideScores: !1
                    }
                },
                v = n(50427),
                f = n.n(v);

            function _(e) {
                var t = e.isPreseason,
                    n = e.gameStatus,
                    i = e.gameStatusText,
                    o = e.lightPreseasonText,
                    c = e.hideScores;
                if (!n) return null;
                var d = (0, m.Z)((0, l.uM)(n), 3),
                    u = (d[0], d[1]),
                    p = d[2],
                    h = c ? "FINAL" : i;
                return (0, s.jsxs)("div", (0, r.Z)((0, a.Z)({
                    className: f().base,
                    "data-game-status": n
                }, u && {
                    "aria-label": "Live game in progress"
                }), {
                    children: [t && (0, s.jsx)("span", {
                        className: f().preseason,
                        "data-is-light": o,
                        children: "PRESEASON"
                    }), !p && (0, s.jsx)("p", {
                        className: f().gameStatus,
                        "data-is-live": u,
                        children: i
                    }), p && (0, s.jsx)("p", {
                        className: f().gameStatus,
                        children: h
                    })]
                }))
            }
            _.propTypes = x.propTypes, _.defaultProps = x.defaultProps;
            var g = n(19167),
                y = n(29221),
                Z = n(2395),
                b = n.n(Z),
                j = n(916),
                T = {
                    as: h().string,
                    game: j.ZP,
                    className: h().string,
                    hideScores: h().bool,
                    enableTeamTricode: h().bool,
                    showDate: h().bool,
                    noPadding: h().bool,
                    logoType: h().string
                },
                S = n(49507);

            function N(e) {
                var t = e.as,
                    n = void 0 === t ? "div" : t,
                    o = e.game,
                    m = e.className,
                    p = e.showDate,
                    h = void 0 !== p && p,
                    x = e.hideScores,
                    v = void 0 !== x && x,
                    f = e.enableTeamTricode,
                    Z = void 0 !== f && f,
                    j = e.noPadding,
                    T = void 0 !== j && j,
                    N = e.logoType,
                    I = (0, i.Z)(e, ["as", "game", "className", "showDate", "hideScores", "enableTeamTricode", "noPadding", "logoType"]);
                if (!o || 0 === Object.keys(o).length) return null;
                var w = o.homeTeam,
                    k = o.awayTeam,
                    C = o.gameStatusText,
                    L = o.gameTimeUTC,
                    R = o.gameStatus,
                    P = o.gameId,
                    H = (0, l.rT)(P),
                    G = H.Season,
                    O = H.seasonyear,
                    q = H.isPre,
                    B = R === S.Z.Upcoming,
                    M = R === S.Z.Final,
                    A = M && k.score > w.score,
                    E = M && !A,
                    D = void 0 !== w.seed && Number(w.seed) > 0 && void 0 !== k.seed && Number(k.seed) > 0,
                    W = !v && D;
                return (0, s.jsxs)(n, (0, r.Z)((0, a.Z)({}, I), {
                    "data-date": h,
                    "data-padding": !T,
                    className: c()(b().matchup, m),
                    children: [h && (0, s.jsx)(u.Z, {
                        date: L,
                        className: b().date
                    }), (0, s.jsxs)("div", {
                        className: b().block,
                        children: [(0, s.jsx)("article", {
                            className: b().sideContent,
                            children: Z ? (0, s.jsxs)("div", {
                                children: [(0, s.jsx)(y.Z, {
                                    className: b().logoSmall,
                                    teamId: k.teamId,
                                    season: G,
                                    seasonYear: O,
                                    logoType: N
                                }), (0, s.jsxs)("div", {
                                    className: b().textContent,
                                    children: [W && (0, s.jsx)("span", {
                                        className: b().seed,
                                        children: k.seed
                                    }), (0, s.jsx)("span", {
                                        className: b().teamTricode,
                                        children: k.teamTricode || "TBD"
                                    })]
                                })]
                            }) : (0, s.jsx)(y.Z, {
                                className: b().logo,
                                teamId: k.teamId,
                                season: G,
                                seasonYear: O,
                                logoType: N
                            })
                        }), (0, s.jsxs)("div", {
                            className: b().status,
                            children: [!B && (0, s.jsx)("div", {
                                className: b().team,
                                "data-team": "away",
                                "data-winner": A,
                                children: (0, s.jsx)(g.Z, {
                                    score: k.score,
                                    hideScores: v,
                                    className: b().scoreCard,
                                    gameStatus: R,
                                    children: (0, s.jsx)(d.Z, {
                                        className: b().win
                                    })
                                })
                            }), (0, s.jsx)("div", {
                                className: b().statusText,
                                children: (0, s.jsx)(_, {
                                    isPreseason: q,
                                    gameStatus: R,
                                    gameStatusText: C,
                                    hideScores: v,
                                    lightPreseasonText: !0
                                })
                            }), !B && (0, s.jsx)("div", {
                                className: b().team,
                                "data-team": "home",
                                "data-winner": E,
                                children: (0, s.jsx)(g.Z, {
                                    score: w.score,
                                    hideScores: v,
                                    className: b().scoreCard,
                                    gameStatus: R,
                                    children: (0, s.jsx)(d.Z, {
                                        dir: "right",
                                        className: b().win
                                    })
                                })
                            })]
                        }), (0, s.jsx)("article", {
                            className: b().sideContent,
                            children: Z ? (0, s.jsxs)("div", {
                                children: [(0, s.jsx)(y.Z, {
                                    className: b().logoSmall,
                                    teamId: w.teamId,
                                    season: G,
                                    seasonYear: O,
                                    logoType: N
                                }), (0, s.jsxs)("div", {
                                    className: b().textContent,
                                    children: [W && (0, s.jsx)("span", {
                                        className: b().seed,
                                        children: w.seed
                                    }), (0, s.jsx)("span", {
                                        className: b().teamTricode,
                                        children: w.teamTricode || "TBD"
                                    })]
                                })]
                            }) : (0, s.jsx)(y.Z, {
                                className: b().logo,
                                teamId: w.teamId,
                                season: G,
                                seasonYear: O,
                                logoType: N
                            })
                        })]
                    })]
                }))
            }
            N.propTypes = T
        },
        42991: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            var a = n(67294);

            function r(e, t) {
                var n = (0, a.useRef)(t);
                return (0, a.useEffect)((function() {
                    n.current = e
                }), [e]), n.current
            }
        },
        98953: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                __N_SSP: function() {
                    return ht
                },
                default: function() {
                    return xt
                }
            });
            var a = n(85893),
                r = n(93967),
                i = n.n(r),
                s = n(33246),
                o = n(11750),
                c = n(38800),
                l = n(21728),
                d = n(67294),
                u = n(14924),
                m = n(26042),
                p = n(98885),
                h = n(42991),
                x = {
                    slideDuration: 500,
                    initial: {
                        transition: "all ".concat(500, "ms ease-in-out"),
                        opacity: 0
                    },
                    transitions: {
                        entering: {
                            opacity: 1
                        },
                        entered: {
                            opacity: 1
                        },
                        exiting: {
                            opacity: 0
                        },
                        exited: {
                            opacity: 0
                        }
                    }
                },
                v = n(47568),
                f = n(34051),
                _ = n.n(f),
                g = n(72378),
                y = n.n(g),
                Z = n(37346),
                b = n(96473),
                j = n(18377),
                T = n(48517),
                S = n(12324),
                N = n(91567),
                I = n(21059),
                w = n(77226),
                k = n(51101),
                C = n(28981),
                L = n(72887),
                R = n(98698),
                P = n(86972),
                H = n(41684),
                G = n(69396),
                O = n(10253),
                q = n(9849),
                B = n(67724),
                M = n(36924),
                A = n(66738),
                E = n(75788),
                D = n(21259),
                W = n(49507);

            function U(e) {
                return (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, e), {
                    outlineButtonStyle: !0,
                    className: "mr-5 last:m-0"
                }))
            }
            var F = n(14705),
                Y = n(86414),
                z = n(45697),
                K = n.n(z),
                V = {
                    propTypes: {
                        content: K().arrayOf(K().shape({
                            id: K().number.isRequired,
                            title: K().string.isRequired,
                            permalink: K().string.isRequired
                        }))
                    },
                    defaultProps: {
                        content: []
                    }
                },
                Q = n(72331),
                X = n.n(Q);

            function J(e) {
                var t = e.content,
                    n = e.pos;
                if (!t.length) return null;
                return (0, a.jsxs)("div", {
                    className: X().content,
                    children: [(0, a.jsx)(Z.Z, {
                        is: "h4",
                        text: "Related Content",
                        className: X().title
                    }), (0, a.jsx)("ul", {
                        children: t.slice(0, 3).map((function(e) {
                            var t = (0, q.BF)({
                                pos: n,
                                id: e.id,
                                text: e.title,
                                type: e.type
                            });
                            return (0, a.jsx)("li", {
                                className: X().item,
                                children: (0, a.jsxs)(F.Z, {
                                    lines: 1,
                                    children: ["video" === e.type && (0, a.jsx)(Y.Z, {
                                        className: X().icon
                                    }), (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, t), {
                                        href: e.permalink,
                                        text: e.title,
                                        className: X().link
                                    }))]
                                })
                            }, e.id)
                        }))
                    })]
                })
            }
            J.propTypes = V.propTypes, J.defaultProps = V.defaultProps;
            var $ = n(73544),
                ee = n.n($),
                te = n(54994),
                ne = n(63393),
                ae = n.n(ne),
                re = n(99295),
                ie = n(9197),
                se = n(59342);

            function oe(e) {
                var t = e.broadcasters,
                    n = void 0 === t ? [] : t,
                    r = (0, d.useMemo)((function() {
                        return (0, se.Z)(n)
                    }), [n]);
                return r && r.length ? (0, a.jsx)("div", {
                    className: ae().broadcasters,
                    children: r.map((function(e) {
                        var t = e || {},
                            n = t.broadcasterDisplay,
                            r = void 0 === n ? "" : n,
                            i = t.broadcasterVideoLink,
                            s = void 0 === i ? "" : i,
                            o = t.broadcasterId;
                        return (0, a.jsx)(re.Z, {
                            broadcasterName: r,
                            broadcasterLink: s,
                            isPrioritizeLink: !0,
                            children: (0, a.jsx)(ie.Z, {
                                className: ae().broadcaster,
                                broadcaster: r,
                                isDark: !0,
                                alt: r,
                                showFallbackText: !0
                            })
                        }, o)
                    }))
                }) : null
            }

            function ce(e) {
                var t = e.content,
                    n = e.pos,
                    r = (0, d.useContext)(S.M).liveGames,
                    s = void 0 === r ? [] : r,
                    o = (0, d.useContext)(N.N),
                    c = o.hideScores,
                    l = o.global,
                    u = o.ticketLinkOrigin,
                    p = l.hideTicketLinks,
                    h = (0, d.useContext)(I.aR).ESI,
                    x = (void 0 === h ? {} : h).isMobile,
                    f = t || {},
                    g = f.idGame,
                    F = f.isBreaking,
                    Y = f.headline,
                    z = void 0 === Y ? "" : Y,
                    K = f.excerpt,
                    V = void 0 === K ? "" : K,
                    Q = f.providers,
                    X = void 0 === Q ? [] : Q,
                    $ = f.hero,
                    ne = void 0 === $ ? {} : $,
                    ae = ne.cta,
                    re = void 0 === ae ? {} : ae,
                    ie = ne.relatedContent,
                    se = void 0 === ie ? [] : ie,
                    ce = s.find((function(e) {
                        return e.gameId === g
                    })),
                    le = (0, d.useState)(ce || {}),
                    de = le[0],
                    ue = le[1],
                    me = (0, d.useState)(!!ce),
                    pe = me[0],
                    he = me[1];
                (0, d.useEffect)((function() {
                    var e = function() {
                        var e = (0, v.Z)(_().mark((function e() {
                            var t;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, (0, k.Xw)(g);
                                    case 3:
                                        t = e.sent, ue(t), he(!0), e.next = 12;
                                        break;
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(0), (0, C.Z)({
                                            action: "Homepage Hero Gameslide",
                                            error: e.t0
                                        }), he(!0);
                                    case 12:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 8]
                            ])
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }();
                    pe || e(g)
                }), [pe, g]);
                var xe = X.filter((function(e) {
                        return "natl" === (null === e || void 0 === e ? void 0 : e.broadcasterScope)
                    })) || [],
                    ve = y()(de, ce || {}),
                    fe = ve.seriesGameNumber,
                    _e = ve.ifNecessary,
                    ge = ve.gameId,
                    ye = ve.gameSubtype,
                    Ze = ve.gameLabel,
                    be = void 0 === Ze ? "" : Ze,
                    je = ve.gameSubLabel,
                    Te = void 0 === je ? "" : je,
                    Se = function(e, t, n, r, i, s, o, c) {
                        var l = n.id,
                            d = function(e) {
                                return (0, q.el)({
                                    id: l,
                                    text: e,
                                    pos: r
                                })
                            },
                            u = {
                                "data-track": "video",
                                "data-id": "nba:home:hero:cta",
                                "data-content": "".concat(l, ":WATCH"),
                                "data-text": "Watch",
                                "data-type": "cta",
                                "data-pos": r,
                                "data-section": "hero",
                                "data-premium": "true"
                            },
                            p = n.permalink ? n.permalink.replace(/\/$/, "") : "/game/".concat(n.idGame),
                            h = e && Object.keys(e).length,
                            x = (0, O.Z)((0, w.uM)(null === e || void 0 === e ? void 0 : e.gameStatus), 3),
                            v = (x[0], x[1], x[2]),
                            f = (0, D.Z)(v),
                            _ = "".concat(p),
                            g = p + M.y.boxscore,
                            y = "".concat(p).concat(f),
                            Z = p + M.y.watchParty,
                            b = "Watch",
                            j = "Preview",
                            T = "Box Score",
                            S = t || "Game Details",
                            N = "WATCH PARTY",
                            I = "Tickets",
                            k = s.seasonyear,
                            C = h && +e.gameStatus === W.Z.Upcoming ? (0, E.Z)({
                                ticketLinkOrigin: c,
                                seasonYear: k,
                                gameId: l,
                                placement: B.FL.gameHeroHomepage
                            }) : "",
                            L = d(T),
                            R = d(S),
                            P = d(I),
                            H = (0, q.el)({
                                id: l,
                                text: N,
                                pos: r,
                                isPremium: !0
                            });
                        if (h) switch (+e.gameStatus) {
                            case 1:
                                return i ? (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(U, (0, m.Z)({
                                        href: _,
                                        text: j,
                                        title: j
                                    }, u)), !o && (0, a.jsx)(U, (0, m.Z)({
                                        href: C,
                                        text: I,
                                        title: I
                                    }, P))]
                                }) : (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(U, (0, m.Z)({
                                        href: _,
                                        text: j,
                                        title: j
                                    }, u)), B.zU && (0, a.jsx)(U, (0, m.Z)({
                                        href: Z,
                                        title: N,
                                        text: N
                                    }, H, A.c)), (0, a.jsx)(U, (0, m.Z)({
                                        href: C,
                                        text: I,
                                        title: I
                                    }, P))]
                                });
                            case 2:
                                return i ? (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(U, (0, m.Z)({
                                        href: _,
                                        text: b,
                                        title: b
                                    }, u)), (0, a.jsx)(U, (0, G.Z)((0, m.Z)({}, L), {
                                        href: g,
                                        text: T,
                                        title: T
                                    }))]
                                }) : (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(U, (0, m.Z)({
                                        href: y,
                                        text: b,
                                        title: b
                                    }, u)), B.zU && (0, a.jsx)(U, (0, m.Z)({
                                        href: Z,
                                        title: N,
                                        text: N
                                    }, H, A.c)), (0, a.jsx)(U, (0, G.Z)((0, m.Z)({}, L), {
                                        href: g,
                                        text: T,
                                        title: T
                                    }))]
                                });
                            case 3:
                                return i ? (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(U, (0, m.Z)({
                                        href: _,
                                        text: b,
                                        title: b
                                    }, u)), (0, a.jsx)(U, (0, G.Z)((0, m.Z)({}, L), {
                                        href: g,
                                        text: T,
                                        title: T
                                    }))]
                                }) : (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(U, (0, m.Z)({
                                        href: y,
                                        text: b,
                                        title: b
                                    }, u)), (0, a.jsx)(U, (0, G.Z)((0, m.Z)({}, L), {
                                        href: g,
                                        text: T,
                                        title: T
                                    }))]
                                });
                            default:
                                return null
                        }
                        return (0, a.jsx)(U, (0, G.Z)((0, m.Z)({}, R), {
                            href: p,
                            text: S,
                            title: S
                        }))
                    }(de, re, t, n, x, ge ? (0, w.rT)(ge) : {}, p, u),
                    Ne = ve.heroText;
                return ((0, P.Z)(ye) || (0, te.Z)(ge) || (0, R.Z)(ge)) && (Ne = [be, Te].filter(Boolean).join(": ")), (0, a.jsxs)("div", {
                    className: i()(ee().gs, "gameSlide"),
                    children: [x ? (0, a.jsx)("div", {}) : (0, a.jsx)(oe, {
                        broadcasters: xe
                    }), pe && (0, a.jsx)("div", {
                        className: ee().card,
                        children: (0, a.jsx)(b.Z, {
                            game: ve,
                            logoType: "dark",
                            hideScores: c,
                            noPadding: !0
                        })
                    }), (0, a.jsxs)("div", {
                        children: [(0, a.jsx)(T.Z, {
                            className: ee().infoText,
                            seriesGameNumber: fe,
                            shouldShowOnlySeriesText: (0, R.Z)(ge),
                            seriesText: Ne,
                            ifNecessary: _e,
                            hideScores: c
                        }), F && (0, a.jsx)(j.Z, {
                            className: ee().badge,
                            large: !0,
                            defaultText: "BREAKING"
                        }), x && (0, a.jsx)(oe, {
                            broadcasters: xe
                        }), z && (0, a.jsx)(H.Z, {
                            href: (0, L.Z)(t),
                            children: (0, a.jsx)(Z.Z, {
                                is: "h2",
                                className: ee().headline,
                                maxLines: 3,
                                children: z
                            })
                        }), V && (0, a.jsx)(Z.Z, {
                            is: "p",
                            text: V,
                            className: ee().excerpt,
                            maxLines: 3
                        }), (0, a.jsx)("div", {
                            className: ee().buttons,
                            children: Se
                        }), (0, a.jsx)(J, {
                            content: se,
                            pos: n
                        })]
                    })]
                })
            }
            var le = n(92033),
                de = n(6277);

            function ue(e, t) {
                var n, r = e || {},
                    i = r.id,
                    s = r.category,
                    o = r.categoryPrimary,
                    c = r.taxonomy,
                    l = r.type,
                    d = r.isLive,
                    u = {
                        outlineButtonStyle: !0,
                        className: "mr-5 last:m-0"
                    },
                    p = null === (n = e.hero) || void 0 === n ? void 0 : n.cta,
                    h = function(e) {
                        return (0, m.Z)({}, u, function(e) {
                            return {
                                "data-track": "video",
                                "data-id": "nba:home:hero:cta",
                                "data-content": i,
                                "data-text": e,
                                "data-pos": t,
                                "data-type": "cta",
                                "data-section": "hero",
                                "data-premium": "false",
                                "data-franchise": (0, de.Z)(c),
                                "data-cat-type": (null === o || void 0 === o ? void 0 : o.name) || s || "",
                                "data-live-vod": "event" === l && d ? "live" : "vod"
                            }
                        }(e))
                    },
                    x = function(e) {
                        return (0, m.Z)({}, u, function(e) {
                            return (0, q.el)({
                                id: i,
                                text: e,
                                pos: t
                            })
                        }(e))
                    },
                    v = h(p || e.isLive ? "Watch" : "Preview"),
                    f = h(p || "Watch"),
                    _ = x(p || "Read Article"),
                    g = x(p || "See more");
                switch (e.type) {
                    case "event":
                        return (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, v), {
                            href: (0, L.Z)(e),
                            text: p || e.isLive ? "Watch" : "Preview",
                            title: p || e.isLive ? "Watch" : "Preview"
                        }));
                    case "video":
                        return (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, f), {
                            href: (0, L.Z)(e),
                            text: p || "Watch",
                            title: p || "Watch"
                        }));
                    case "post":
                        return (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, _), {
                            href: (0, L.Z)(e),
                            text: p || "Read Article",
                            title: p || "Read Article"
                        }));
                    case "hyperlink":
                    case "page":
                        return (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, g), {
                            href: (0, L.Z)(e),
                            text: p || "See more",
                            title: p || "See more"
                        }));
                    default:
                        return null
                }
            }
            var me = {
                    propTypes: {
                        content: K().shape({
                            type: K().string.isRequired,
                            slug: K().string.isRequired,
                            isLive: K().bool,
                            buttons: K().arrayOf(K().shape({
                                id: K().number.isRequired,
                                url: K().string.isRequired,
                                text: K().string.isRequired
                            })),
                            excerpt: K().string,
                            description: K().string,
                            live: K().bool,
                            relatedContent: K().arrayOf(K().shape({
                                id: K().number.isRequired,
                                text: K().string.isRequired,
                                url: K().string.isRequired
                            })),
                            sponsor: K().shape({
                                logo: K().string,
                                name: K().string
                            }),
                            subtitle: K().string,
                            title: K().string,
                            hero: K().shape({
                                image: K().string,
                                cta: K().string,
                                tabTitle: K().string,
                                relatedContent: K().arrayOf(K().shape({
                                    id: K().number.isRequired,
                                    title: K().string.isRequired,
                                    permalink: K().string.isRequired
                                }))
                            })
                        }).isRequired,
                        pos: K().number.isRequired
                    },
                    defaultProps: {
                        content: {},
                        pos: 0
                    }
                },
                pe = n(19802),
                he = n.n(pe);

            function xe(e) {
                var t, n = e.content,
                    r = e.pos,
                    s = (0, q.Mf)({
                        pos: r,
                        id: n.id,
                        title: n.title,
                        track: n.type
                    }),
                    o = (0, le.Z)(["sponsor", "name"], n, ""),
                    c = (0, le.Z)(["sponsor", "logo"], n, "");
                return (0, a.jsxs)("div", {
                    className: i()(he().gs, "genericSlide"),
                    children: [(0, a.jsxs)("div", {
                        className: he().header,
                        children: [n.live && (0, a.jsx)(j.Z, {
                            className: he().badge,
                            large: !0
                        }), n.isBreaking && (0, a.jsx)(j.Z, {
                            className: he().badge,
                            large: !0,
                            defaultText: "BREAKING"
                        }), (0, a.jsx)(Z.Z, {
                            is: "span",
                            className: he().subtitle,
                            text: n.subtitle
                        })]
                    }), (0, a.jsxs)("div", {
                        children: [(0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({}, s), {
                            href: (0, L.Z)(n),
                            children: (0, a.jsx)(Z.Z, {
                                is: "h2",
                                text: n.title,
                                className: he().title,
                                maxLines: 3
                            })
                        })), (0, a.jsx)(Z.Z, {
                            is: "p",
                            text: n.excerpt || n.description,
                            className: he().desc,
                            maxLines: 3
                        }), (0, a.jsx)("div", {
                            className: he().buttons,
                            children: ue(n, r)
                        }), (0, a.jsx)(J, {
                            content: null === (t = n.hero) || void 0 === t ? void 0 : t.relatedContent,
                            pos: r
                        }), c && (0, a.jsxs)("div", {
                            className: he().sponser,
                            children: [(0, a.jsx)("span", {
                                className: he().sponserText,
                                children: "Sponsored By"
                            }), (0, a.jsx)("img", {
                                src: c,
                                alt: o,
                                className: he().logo
                            })]
                        })]
                    })]
                })
            }
            xe.propTypes = me.propTypes, xe.defaultPros = me.defaultProps;
            var ve = n(1283),
                fe = n.n(ve),
                _e = n(916),
                ge = K().shape({
                    id: K().number,
                    type: K().string,
                    title: K().string,
                    headline: K().string,
                    idGame: K().string,
                    gameStatus: K().number,
                    gameStatusText: K().string,
                    providers: K().arrayOf(_e.bk)
                }),
                ye = K().arrayOf(ge),
                Ze = {
                    carousel: ye.isRequired,
                    userHasInteracted: K().bool.isRequired,
                    visibleSlideIndex: K().number.isRequired,
                    showTime: K().bool.isRequired
                };

            function be(e) {
                var t = e.carousel,
                    n = e.userHasInteracted,
                    r = e.visibleSlideIndex,
                    s = e.showTime,
                    o = (0, h.Z)(r),
                    c = function(e) {
                        var t = e === r,
                            a = e === o,
                            i = "";
                        if (!n && (t && (i = fe().contentInRight), a)) return fe().contentOutLeft;
                        if (n)
                            if (r > o) {
                                if (t) return fe().contentInRight;
                                if (a) return fe().contentOutLeft
                            } else {
                                if (t) return fe().contentInLeft;
                                if (a) return fe().contentOutRight
                            }
                        return i
                    },
                    l = function(e, t) {
                        var n = t + 1;
                        switch (e.type) {
                            case "game":
                                return (0, a.jsx)(ce, {
                                    content: e,
                                    pos: n
                                });
                            case "video":
                            case "event":
                            case "post":
                            case "page":
                            case "hyperlink":
                                return (0, a.jsx)(xe, {
                                    content: e,
                                    pos: n
                                });
                            default:
                                return console.error("Unexpected slide type: ".concat(e.type)), null
                        }
                    };
                return t.map((function(e, t) {
                    return (0, a.jsx)(p.ZP, { in: r === t,
                        timeout: x.slideDuration,
                        children: function(n) {
                            var d;
                            return (0, a.jsx)("div", {
                                className: i()(fe().content, (d = {}, (0, u.Z)(d, fe().showtime, s), (0, u.Z)(d, c(t), void 0 !== o), d)),
                                style: (0, m.Z)({
                                    zIndex: r === t ? 20 : 10
                                }, x.initial, x.transitions[n]),
                                children: l(e, t)
                            })
                        }
                    }, e.id)
                }))
            }
            be.propTypes = Ze;
            var je = n(7410),
                Te = {
                    carousel: ye.isRequired,
                    userHasInteracted: K().bool.isRequired,
                    visibleSlideIndex: K().number.isRequired
                },
                Se = n(95527),
                Ne = n.n(Se);

            function Ie(e) {
                var t = e.carousel,
                    n = e.visibleSlideIndex,
                    r = e.userHasInteracted,
                    i = e.showTime ? "showtime" : "hero",
                    s = function(e) {
                        return n === e
                    },
                    o = function(e) {
                        return s(e) && !r
                    },
                    c = function(e) {
                        return (0, le.Z)(["hero", "image"], e, e.imageGame || e.featuredImage)
                    };
                return (0, a.jsx)(a.Fragment, {
                    children: t.map((function(e, t) {
                        return (0, a.jsx)(je.Z, {
                            "data-is-visible": s(t),
                            "data-should-scale": o(t),
                            className: Ne().background,
                            src: c(e),
                            size: i,
                            alt: e.title
                        }, e.id)
                    }))
                })
            }
            Ie.propTypes = Te;
            var we = n(67554),
                ke = n.n(we),
                Ce = {
                    slide: ge.isRequired,
                    currentSlide: K().bool,
                    showTime: K().bool,
                    liveGame: K().shape({
                        gameStatus: K().number,
                        gameStatusText: K().string
                    })
                };

            function Le(e) {
                var t = e.slide,
                    n = e.currentSlide,
                    r = void 0 !== n && n,
                    i = e.showTime,
                    s = void 0 !== i && i,
                    o = e.liveGame,
                    c = void 0 === o ? null : o,
                    l = (0, le.Z)(["hero", "tabTitle"], t, ""),
                    d = t.type,
                    u = t.isBreaking,
                    m = function(e) {
                        return (0, a.jsxs)(a.Fragment, {
                            children: [u && (0, a.jsx)(j.Z, {
                                defaultText: "BREAKING"
                            }), (0, a.jsx)("p", {
                                className: ke().ctlHeroText,
                                children: l || e
                            })]
                        })
                    },
                    p = m(),
                    h = "";
                if ("game" === d) {
                    var x = t.providers,
                        v = void 0 === x ? [] : x,
                        f = t.gameStatus,
                        _ = t.gameStatusText,
                        g = c || {},
                        y = g.gameStatus || f,
                        Z = g.gameStatusText || _,
                        b = (0, O.Z)((0, w.uM)(y), 2),
                        T = b[0],
                        S = b[1],
                        N = (v.find((function(e) {
                            return "natl" === e.broadcasterScope
                        })) || {
                            broadcasterDisplay: "NBA LEAGUE PASS"
                        }).broadcasterDisplay;
                    p = S ? (0, a.jsx)(j.Z, {}) : m(Z), h = T || S ? N : ""
                }
                return (0, a.jsx)("div", {
                    className: ke().clt,
                    "data-is-showtime": s,
                    children: (0, a.jsxs)("span", {
                        className: ke().cltSlide,
                        "data-is-current": r,
                        children: [p, h && (0, a.jsx)("span", {
                            className: ke().ctlTuneIn,
                            children: h
                        })]
                    })
                })
            }
            Le.propTypes = Ce;
            var Re = {
                    carousel: ye.isRequired,
                    visibleSlideIndex: K().number.isRequired
                },
                Pe = n(77617),
                He = n.n(Pe);

            function Ge(e) {
                var t = e.carousel,
                    n = e.visibleSlideIndex,
                    r = function(e) {
                        return e === n + 1 || 0 === e && n === t.length - 1
                    };
                return (0, a.jsx)("div", {
                    className: He().un,
                    children: t.map((function(e, t) {
                        return (0, a.jsxs)("p", {
                            "data-is-visible": r(t),
                            children: ["Next: ", e.title]
                        }, e.id)
                    }))
                })
            }
            Ge.propTypes = Re;
            var Oe = n(2936),
                qe = n.n(Oe),
                Be = {
                    carousel: ye.isRequired,
                    userHasInteracted: K().bool.isRequired,
                    visibleSlideIndex: K().number.isRequired,
                    handleUserSlideChange: K().func.isRequired,
                    showTime: K().bool.isRequired
                };

            function Me(e) {
                var t = e.carousel,
                    n = e.visibleSlideIndex,
                    r = e.userHasInteracted,
                    i = e.handleUserSlideChange,
                    s = e.showTime,
                    o = (0, d.useContext)(S.M).liveGames,
                    c = void 0 === o ? [] : o;
                return (0, a.jsxs)("div", {
                    className: qe().cl,
                    children: [(0, a.jsx)("div", {
                        className: qe().clInner,
                        children: t.map((function(e, t) {
                            var o = n === t,
                                l = (0, q.b4)({
                                    title: e.title,
                                    type: e.type,
                                    index: t,
                                    isPremium: !1,
                                    isBreaking: e.isBreaking
                                }),
                                d = "game" === e.type ? c.find((function(t) {
                                    return t.gameId === e.idGame
                                })) : null,
                                u = e.headline || e.title,
                                p = o && !r,
                                h = o && r;
                            return (0, a.jsxs)("button", (0, G.Z)((0, m.Z)({
                                title: "Link For ".concat(u),
                                type: "button",
                                onClick: function() {
                                    return i(t)
                                }
                            }, l), {
                                className: qe().clButton,
                                "data-showtime": s,
                                children: [(0, a.jsx)("div", {
                                    className: qe().clBar,
                                    children: (0, a.jsx)("div", {
                                        className: qe().clTrack,
                                        "data-track-in": p,
                                        "data-track-full": h
                                    })
                                }), (0, a.jsx)(Le, {
                                    slide: e,
                                    showTime: s,
                                    currentSlide: o,
                                    liveGame: d
                                }), (0, a.jsx)(Z.Z, {
                                    maxLines: 3,
                                    className: qe().clText,
                                    "data-is-current-slide": o,
                                    children: u
                                })]
                            }), e.id)
                        }))
                    }), (0, a.jsx)(Ge, {
                        carousel: t,
                        visibleSlideIndex: n
                    })]
                })
            }
            Me.propTypes = Be;
            var Ae = n(99534),
                Ee = n(36617),
                De = n(95014),
                We = n.n(De),
                Ue = {
                    carousel: ye.isRequired,
                    visibleSlideIndex: K().number.isRequired
                },
                Fe = {
                    gameId: K().string.isRequired,
                    link: K().string.isRequired
                };

            function Ye(e) {
                var t = e.gameId,
                    n = e.link,
                    r = (0, Ae.Z)(e, ["gameId", "link"]),
                    i = (0, d.useContext)(S.M).liveGames,
                    s = (void 0 === i ? [] : i).find((function(e) {
                        return e.gameId === t
                    })),
                    o = (0, d.useState)(y()(s)),
                    c = o[0],
                    l = o[1],
                    u = (0, d.useState)(!!s),
                    p = u[0],
                    h = u[1];
                (0, d.useEffect)((function() {
                    var e = function() {
                        var e = (0, v.Z)(_().mark((function e() {
                            var n;
                            return _().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, (0, k.Xw)(t);
                                    case 3:
                                        n = e.sent, l(n), h(!0), e.next = 12;
                                        break;
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(0), (0, C.Z)({
                                            action: "Homepage Hero Gameslide",
                                            error: e.t0
                                        }), h(!0);
                                    case 12:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [0, 8]
                            ])
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }();
                    p || e(t)
                }), [p, t]);
                var x = y()(c, s || {}),
                    f = n,
                    g = !1;
                if (x) {
                    var Z = x.hometeam,
                        b = void 0 === Z ? {} : Z,
                        j = x.awayTeam,
                        T = void 0 === j ? {} : j,
                        N = x.gameStatus,
                        I = (0, O.Z)((0, w.uM)(Number(N)), 2),
                        L = I[0],
                        R = I[1];
                    if (L) return null;
                    f = (0, Ee.Z)(t, T.teamTricode, b.teamTricode, M.y.watch), R && (g = !0)
                }
                var P = "".concat(B.$, "/next/icons/icon-event-play").concat(g ? "-live" : "", ".svg");
                return (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({
                    href: f,
                    className: We().eventLink
                }, r), {
                    children: (0, a.jsx)("img", {
                        src: P,
                        alt: "Event Icon",
                        className: We().playIcon
                    })
                }))
            }

            function ze(e) {
                var t = e.carousel,
                    n = e.visibleSlideIndex,
                    r = function(e) {
                        return n === e
                    },
                    s = function(e, t, n) {
                        return {
                            "data-track": "video",
                            "data-type": "image",
                            "data-id": "nba:home:hero:image",
                            "data-section": "hero",
                            "data-content": e,
                            "data-content-id": t,
                            "data-pos": "".concat(n + 1),
                            "data-premium": "false"
                        }
                    },
                    o = function(e, t, n) {
                        return {
                            "data-franchise": (0, de.Z)(e),
                            "data-cat-type": (null === n || void 0 === n ? void 0 : n.name) || t || "",
                            "data-live-vod": "vod"
                        }
                    };
                return t.map((function(e, t) {
                    var n = e || {},
                        c = n.category,
                        l = n.categoryPrimary,
                        d = n.taxonomy,
                        p = n.type,
                        h = n.idGame,
                        x = n.title,
                        v = n.id;
                    return "video" === p || "game" === p ? "game" === p ? (0, a.jsx)("div", {
                        className: i()(We().contentLink, (0, u.Z)({}, We().active, r(t))),
                        children: (0, a.jsx)(Ye, (0, m.Z)({
                            gameId: h,
                            link: e.permalink
                        }, s(x, v, t)))
                    }, e.id) : (0, a.jsx)("div", {
                        className: i()(We().contentLink, (0, u.Z)({}, We().active, r(t))),
                        children: (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({
                            href: e.permalink,
                            className: We().eventLink
                        }, s(x, v, t), o(d, c, l)), {
                            children: (0, a.jsx)("img", {
                                src: "".concat(B.$, "/next/icons/icon-event-play.svg"),
                                alt: "Event Icon",
                                className: We().playIcon
                            })
                        }))
                    }, e.id) : null
                }))
            }
            Ye.propTypes = Fe, Ye.defaultProps = {}, ze.propTypes = Ue, ze.defaultProps = {};
            var Ke = ze,
                Ve = n(65708),
                Qe = n.n(Ve),
                Xe = {
                    carousel: ye.isRequired,
                    className: K().string,
                    showTime: K().bool,
                    scoreboard: K().arrayOf(_e.ZP)
                };

            function Je(e) {
                var t = e.carousel,
                    n = e.className,
                    r = e.showTime,
                    s = void 0 !== r && r,
                    o = (0, d.useState)(0),
                    c = o[0],
                    l = o[1],
                    u = (0, d.useState)(!1),
                    m = u[0],
                    p = u[1];
                (0, d.useEffect)((function() {
                    var e;
                    return m || (e = setTimeout((function() {
                            l(c === t.length - 1 ? 0 : c + 1)
                        }), 7e3)),
                        function() {
                            return clearTimeout(e)
                        }
                }), [t.length, m, c]);
                var h = function(e) {
                        var n = t.length - 1;
                        e < 0 || e > n || (l(e), m || p(!0))
                    },
                    x = t.filter((function(e, t) {
                        return "game" === e.type && t === c
                    })),
                    v = x && x.length > 0 && x[0];
                return (0, a.jsx)("div", {
                    className: Qe().hero,
                    children: (0, a.jsxs)("div", {
                        className: i()(Qe().heroLayer, n),
                        children: [(0, a.jsx)(Ie, {
                            carousel: t,
                            userHasInteracted: m,
                            visibleSlideIndex: c,
                            showTime: s
                        }), v ? (0, a.jsx)("div", {
                            className: Qe().gameHeroShadow
                        }) : (0, a.jsx)("div", {
                            className: Qe().heroShadow
                        }), (0, a.jsx)(Ke, {
                            carousel: t,
                            visibleSlideIndex: c
                        }), (0, a.jsx)(be, {
                            carousel: t,
                            userHasInteracted: m,
                            visibleSlideIndex: c,
                            handleUserSlideChange: h,
                            showTime: s
                        }), (0, a.jsx)(Me, {
                            carousel: t,
                            userHasInteracted: m,
                            visibleSlideIndex: c,
                            handleUserSlideChange: h,
                            showTime: s
                        })]
                    })
                })
            }
            Je.propTypes = Xe;
            var $e = {
                    banner: K().shape({
                        image: K().string,
                        url: K().string,
                        mobileImage: K().string,
                        mobileUrl: K().string
                    })
                },
                et = n(80990),
                tt = n.n(et);

            function nt(e) {
                var t = e.banner,
                    n = t || {},
                    r = n.image,
                    i = void 0 === r ? "" : r,
                    s = n.url,
                    o = void 0 === s ? "" : s,
                    c = n.mobileImage,
                    l = void 0 === c ? "" : c,
                    u = n.mobileUrl,
                    p = void 0 === u ? "" : u,
                    h = (0, d.useState)({
                        image: i,
                        url: o
                    }),
                    x = h[0],
                    v = h[1],
                    f = (0, d.useRef)(null),
                    _ = "Tune In Banner";
                if ((0, d.useEffect)((function() {
                        l && f && f.current && f.current.clientWidth <= 768 && v({
                            image: l,
                            url: p || o
                        })
                    }), [t, o, f]), !t) return null;
                if (!i || !o) return null;
                var g = o.lastIndexOf("/") > 0 && !p.includes("packages") && o.slice(o.lastIndexOf("/") + 1);
                return (0, a.jsx)("div", {
                    className: tt().ti,
                    ref: f,
                    children: (0, a.jsx)(H.Z, (0, G.Z)((0, m.Z)({
                        href: x.url
                    }, (0, m.Z)({
                        "data-track": "click",
                        "data-type": "image",
                        "data-id": "nba:home:tune-in-banner"
                    }, g && {
                        "data-text": g.split("-").join(" ")
                    })), {
                        children: (0, a.jsx)(je.Z, {
                            src: x.image,
                            title: _,
                            alt: _,
                            className: tt().tiImage
                        })
                    }))
                })
            }
            nt.propTypes = $e;
            var at = n(1207),
                rt = n(84974),
                it = n(2433),
                st = n(97847),
                ot = n(17594),
                ct = n(89525),
                lt = n(3661),
                dt = n(54234),
                ut = n.n(dt);

            function mt(e) {
                var t, n, r, d, u, m, p, h, x = e.layout,
                    v = e.home,
                    f = e.region,
                    _ = void 0 === f ? "" : f,
                    g = e.homepageSettings,
                    y = (0, le.Z)(["carousel", "showtime"], v, !1),
                    Z = (0, le.Z)(["carousel", "items"], v, []),
                    b = (0, le.Z)(["headlines", "items"], v, []),
                    j = (0, s.R7)(),
                    T = (0, s.C6)(),
                    S = (0, s.bh)(),
                    N = {
                        showDraftTracker: (0, le.Z)(["draft", "enableDraftTracker"], g, !1),
                        showDraftLogo: !0,
                        seasonYear: (0, le.Z)(["draft", "seasonYear"], g, null)
                    },
                    I = null === v || void 0 === v || null === (t = v.siderail) || void 0 === t ? void 0 : t.find((function(e) {
                        return "LEAGUE PASS" === e.title
                    }));
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(st.Z, {
                        title: "The official site of the NBA for the latest NBA Scores, Stats & News.",
                        description: "The official site of the National Basketball Association. Follow the action on NBA scores, schedules, stats, news, Team and Player news.",
                        seo: v.seo,
                        isHomePage: !0
                    }), (0, a.jsx)(at.Z, {
                        json: j
                    }), (0, a.jsx)(at.Z, {
                        json: T
                    }), (0, a.jsx)(at.Z, {
                        json: S
                    }), (0, a.jsxs)(rt.Z, {
                        layout: x,
                        region: _,
                        draftTracker: N,
                        showScoreStrip: !0,
                        children: [v.overrideContent && (0, a.jsx)("div", {
                            className: ut().viewOverride,
                            dangerouslySetInnerHTML: {
                                __html: null === (n = v.overrideContent) || void 0 === n ? void 0 : n.content
                            }
                        }), (0, a.jsx)(c.Z, {
                            className: ut().viewDisplayAdTop,
                            placementId: "home_ad_b_1",
                            singleton: "ad_mod_bf8146298",
                            domId: "home_ad_b_1",
                            marketingDomId: "home_ad_m_1"
                        }), y && (0, a.jsx)(nt, {
                            banner: v.tuneInBanner
                        }), y && (0, a.jsx)(Je, {
                            carousel: Z,
                            showTime: !0
                        }), (0, a.jsx)(it.Z, {
                            children: (0, a.jsxs)(o.oe, {
                                children: [(0, a.jsxs)(o.dv, {
                                    children: [!y && (0, a.jsx)(nt, {
                                        banner: v.tuneInBanner
                                    }), !y && (0, a.jsx)(Je, {
                                        carousel: Z,
                                        className: ut().viewHomeHero
                                    }), (0, a.jsx)(lt.Z, {
                                        containerId: "homepage-stories"
                                    }), (0, a.jsx)(l.Z, {
                                        headlineLocation: "main",
                                        items: b,
                                        className: ut().viewHeadlinesLeft
                                    }), (0, a.jsx)(ot.Z, {
                                        feed: v.mainFeed,
                                        isTentpole: !1,
                                        region: _,
                                        adfuelTarget: "",
                                        isWebview: !1,
                                        template: "default",
                                        position: "mainfeed",
                                        section: q.Ee.home.contentWell
                                    }), (0, a.jsx)(c.Z, {
                                        className: ut().viewDisplayAdLeft,
                                        lazyLoad: !0,
                                        placementId: "home_ad_b_4",
                                        domId: "home_ad_b_4"
                                    })]
                                }), (0, a.jsxs)(o.O6, {
                                    children: [(0, a.jsx)(it.Z, {
                                        noPadding: !0,
                                        children: (0, a.jsx)(ct.Z, {
                                            promos: null === I || void 0 === I || null === (r = I.value) || void 0 === r ? void 0 : r.carousels,
                                            title: null === I || void 0 === I ? void 0 : I.title,
                                            section: q.Ee.home.rightRail,
                                            placementId: null === I || void 0 === I ? void 0 : I.placementId,
                                            mainFeed: null === I || void 0 === I || null === (d = I.value) || void 0 === d || null === (u = d.homePageContent) || void 0 === u ? void 0 : u.mainFeed,
                                            sideRail: null === I || void 0 === I || null === (m = I.value) || void 0 === m || null === (p = m.homePageContent) || void 0 === p ? void 0 : p.sideRail
                                        })
                                    }, null === I || void 0 === I ? void 0 : I.id), (0, a.jsx)(l.Z, {
                                        headlineLocation: "siderail",
                                        items: b,
                                        className: i()(ut().viewHeadlinesRight)
                                    }), (0, a.jsx)(ot.Z, {
                                        feed: null === v || void 0 === v || null === (h = v.siderail) || void 0 === h ? void 0 : h.filter((function(e) {
                                            return "LEAGUE PASS" !== e.title
                                        })),
                                        isTentpole: !1,
                                        region: _,
                                        adfuelTarget: "",
                                        isWebview: !1,
                                        template: "default",
                                        position: "",
                                        section: q.Ee.home.rightRail
                                    })]
                                })]
                            })
                        })]
                    })]
                })
            }
            var pt = n(6210),
                ht = !0;

            function xt(e) {
                var t = e.layout,
                    n = e.home,
                    r = e.oldrollingschedule,
                    i = e.scoreboard,
                    s = e.page,
                    o = e.region,
                    c = e.homepageSettings,
                    l = e.isTentpole,
                    d = e.rollingSchedule,
                    u = void 0 === d ? {} : d;
                return l ? (0, a.jsx)(pt.Z, {
                    layout: t,
                    page: s,
                    region: o
                }) : (0, a.jsx)(mt, {
                    layout: t,
                    home: n,
                    oldrollingschedule: r,
                    scoreboard: i,
                    region: o,
                    homepageSettings: c,
                    rollingSchedule: u
                })
            }
        },
        54994: function(e, t, n) {
            "use strict";

            function a(e) {
                return !!e && "3" === e[2]
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        61184: function(e) {
            e.exports = {
                hl: "Headlines_hl__MDhQ9",
                hlAd: "Headlines_hlAd__ryyJO",
                hlItem: "Headlines_hlItem__I3wdq",
                hlSubTag: "Headlines_hlSubTag__eic7_",
                hlVideoIcon: "Headlines_hlVideoIcon__qckC_"
            }
        },
        95527: function(e) {
            e.exports = {
                background: "BackgroundImageLayer_background__IEXRc",
                "scale-up": "BackgroundImageLayer_scale-up__LLu57",
                none: "BackgroundImageLayer_none___jTQB"
            }
        },
        1283: function(e) {
            e.exports = {
                content: "ContentLayer_content__cn6_K",
                showtime: "ContentLayer_showtime__6X59Q",
                "animation-base": "ContentLayer_animation-base__O3kYT",
                contentInRight: "ContentLayer_contentInRight__oJ4sG ContentLayer_animation-base__O3kYT",
                "slide-in-right": "ContentLayer_slide-in-right__oUWK_",
                contentInLeft: "ContentLayer_contentInLeft__1yNM5 ContentLayer_animation-base__O3kYT",
                "slide-in-left": "ContentLayer_slide-in-left__ZmqRL",
                contentOutLeft: "ContentLayer_contentOutLeft__awqvo ContentLayer_animation-base__O3kYT",
                "slide-out-left": "ContentLayer_slide-out-left__OEfbl",
                contentOutRight: "ContentLayer_contentOutRight__QPWBC ContentLayer_animation-base__O3kYT",
                "slide-out-right": "ContentLayer_slide-out-right__m6hT_"
            }
        },
        95014: function(e) {
            e.exports = {
                contentLink: "ContentLink_contentLink__OP4Oa",
                active: "ContentLink_active__T9sdi",
                playIcon: "ContentLink_playIcon__zStxp",
                eventLink: "ContentLink_eventLink__uJCDy",
                slideMatchupMaxWidth: "ContentLink_slideMatchupMaxWidth__uaN1C"
            }
        },
        67554: function(e) {
            e.exports = {
                clt: "ControlLayerTitle_clt__Fjury",
                ctlHeroText: "ControlLayerTitle_ctlHeroText__w6B1p",
                cltSlide: "ControlLayerTitle_cltSlide__zRgxU",
                ctlTuneIn: "ControlLayerTitle_ctlTuneIn__nQJtI",
                ctl: "ControlLayerTitle_ctl__aV2cK"
            }
        },
        2936: function(e) {
            e.exports = {
                cl: "ControlsLayer_cl__bplcI",
                clInner: "ControlsLayer_clInner__rHxoO",
                clButton: "ControlsLayer_clButton__0h6WG",
                clText: "ControlsLayer_clText__G2Lx7",
                clBar: "ControlsLayer_clBar__egy1X",
                clTrack: "ControlsLayer_clTrack__FiJ8Z",
                "slide-in": "ControlsLayer_slide-in__zxQqG"
            }
        },
        65708: function(e) {
            e.exports = {
                hero: "HomeHero_hero__ArLh4",
                heroLayer: "HomeHero_heroLayer__fKsod",
                gameHeroShadow: "HomeHero_gameHeroShadow__WRzEE",
                heroShadow: "HomeHero_heroShadow__bqT2i"
            }
        },
        73544: function(e) {
            e.exports = {
                gs: "GameSlide_gs__eKZhI",
                card: "GameSlide_card__R67ca",
                badge: "GameSlide_badge__ZeOnq",
                infoText: "GameSlide_infoText__Tb_I1",
                headline: "GameSlide_headline__Fb8gR",
                excerpt: "GameSlide_excerpt__tHU44",
                buttons: "GameSlide_buttons__W5AKU"
            }
        },
        63393: function(e) {
            e.exports = {
                broadcaster: "GameSlideBroadcasters_broadcaster___x3qI",
                broadcasters: "GameSlideBroadcasters_broadcasters__wOagL"
            }
        },
        19802: function(e) {
            e.exports = {
                gs: "GenericSlide_gs__Zu0Gq",
                badge: "GenericSlide_badge__tdjMN",
                subtitle: "GenericSlide_subtitle__UsYkc",
                header: "GenericSlide_header__4bLaT",
                title: "GenericSlide_title__xATM6",
                desc: "GenericSlide_desc__K_stI",
                buttons: "GenericSlide_buttons__UKfgC",
                sponser: "GenericSlide_sponser__3xwp6",
                logo: "GenericSlide_logo__Ah_CZ",
                sponserText: "GenericSlide_sponserText__5IHK_"
            }
        },
        72331: function(e) {
            e.exports = {
                content: "RelatedContent_content__jNGo3",
                title: "RelatedContent_title__Ic818",
                icon: "RelatedContent_icon__92deW",
                link: "RelatedContent_link___ri0C",
                item: "RelatedContent_item__6jrl7"
            }
        },
        77617: function(e) {
            e.exports = {
                un: "UpNext_un__wv5r5"
            }
        },
        2395: function(e) {
            e.exports = {
                matchup: "MatchupCard_matchup__QjHLw",
                block: "MatchupCard_block__RWCas",
                sideContent: "MatchupCard_sideContent__udPUu",
                logoSmall: "MatchupCard_logoSmall__OnlVO",
                logo: "MatchupCard_logo__mw1vC",
                textContent: "MatchupCard_textContent__AnmKx",
                teamTricode: "MatchupCard_teamTricode__rtkR9",
                seed: "MatchupCard_seed__iC1gR",
                status: "MatchupCard_status__Qry3p",
                statusText: "MatchupCard_statusText__WhNDS",
                scoreCard: "MatchupCard_scoreCard___eGCr",
                team: "MatchupCard_team__a_Pzk",
                win: "MatchupCard_win__wQhcW"
            }
        },
        50427: function(e) {
            e.exports = {
                base: "MatchupCardStatusText_base__ogjQQ",
                preseason: "MatchupCardStatusText_preseason__VDg9r",
                gameStatus: "MatchupCardStatusText_gameStatus__SWUxE"
            }
        },
        80990: function(e) {
            e.exports = {
                ti: "TuneInBanner_ti__npOkk",
                tiImage: "TuneInBanner_tiImage__y9hqu"
            }
        },
        54234: function(e) {
            e.exports = {
                viewOverride: "HomePageView_viewOverride__1cxJG",
                viewDisplayAdTop: "HomePageView_viewDisplayAdTop__Dx7nz",
                viewHeadlinesLeft: "HomePageView_viewHeadlinesLeft__09eEi",
                viewHomeHero: "HomePageView_viewHomeHero__mmHU5",
                viewHeadlinesRight: "HomePageView_viewHeadlinesRight___vvZG"
            }
        }
    },
    function(e) {
        e.O(0, [99940, 41470, 72378, 56642, 38998, 84974, 38800, 62058, 55244, 12866, 15707, 20592, 64122, 84934, 2139, 52333, 90659, 59380, 45963, 35913, 60805, 33951, 42346, 13300, 79129, 6210, 49774, 92888, 40179], (function() {
            return t = 44010, e(e.s = t);
            var t
        }));
        var t = e.O();
        _N_E = t
    }
]);