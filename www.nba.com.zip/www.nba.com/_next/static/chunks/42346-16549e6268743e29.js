(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [42346], {
        77473: function(e, i, t) {
            "use strict";
            t.d(i, {
                Z: function() {
                    return K
                }
            });
            var s = t(26042),
                a = t(85893),
                l = t(20606),
                r = t(65507),
                n = t(69396),
                d = t(41684),
                o = t(58819),
                c = t(7410),
                _ = t(37346),
                u = t(86414),
                p = t(93612),
                m = t(45697),
                g = t.n(m),
                v = {
                    propTypes: {
                        id: g().number.isRequired,
                        href: g().string.isRequired,
                        img: g().string.isRequired,
                        title: g().string.isRequired,
                        shortTitle: g().string,
                        runtime: g().string.isRequired,
                        exclusiveTo: g().oneOf(["nba-tv", "league-pass", "free", "", "league-pass-premium"]),
                        isLive: g().bool
                    },
                    defaultProps: {
                        exclusiveTo: "",
                        shortTitle: "",
                        pageForAnalytics: "",
                        isLive: !1
                    }
                },
                h = t(39296),
                f = t.n(h);

            function S(e) {
                var i = e.img,
                    t = e.title,
                    l = e.shortTitle,
                    r = e.href,
                    m = e.runtime,
                    g = e.exclusiveTo,
                    v = e.analytics,
                    h = e.isLive;
                return (0, a.jsxs)(d.Z, (0, n.Z)((0, s.Z)({
                    href: r,
                    className: f().slide
                }, v), {
                    children: [h ? (0, a.jsx)(p.Z, {
                        className: f().liveBadge
                    }) : null, (0, a.jsxs)("figure", {
                        className: f().figure,
                        children: [(0, a.jsx)(c.Z, {
                            src: i,
                            size: "list-large",
                            className: f().image
                        }), (0, a.jsxs)("div", {
                            className: f().playIcon,
                            children: [(0, a.jsx)(u.Z, {
                                width: "26",
                                height: "26"
                            }), m && (0, a.jsx)("span", {
                                className: f().runtime,
                                children: m
                            })]
                        })]
                    }), (0, a.jsxs)("div", {
                        className: f().caption,
                        children: [(0, a.jsx)(_.Z, {
                            className: f().title,
                            maxLines: 2,
                            children: l || t
                        }), g && "free" !== g && (0, a.jsx)("div", {
                            className: f().subscriptionTags,
                            children: (0, a.jsx)(o.Z, {
                                type: g
                            })
                        })]
                    })]
                }))
            }
            S.propTypes = v.propTypes, S.defaultProps = v.defaultProps;
            var x = t(69154),
                j = t.n(x);

            function Z(e) {
                var i = e.img,
                    t = e.href,
                    l = e.title,
                    r = e.analytics,
                    o = e.isLive,
                    u = void 0 !== o && o;
                return (0, a.jsxs)(d.Z, (0, n.Z)((0, s.Z)({
                    href: t,
                    className: j().slide
                }, r), {
                    children: [u ? (0, a.jsx)(p.Z, {
                        className: j().liveBadge
                    }) : null, (0, a.jsx)("figure", {
                        className: j().figure,
                        children: (0, a.jsx)(c.Z, {
                            src: i,
                            size: "list-large",
                            className: j().image
                        })
                    }), (0, a.jsx)("div", {
                        className: j().caption,
                        children: (0, a.jsx)(_.Z, {
                            is: "h3",
                            className: j().text,
                            maxLines: 2,
                            children: l
                        })
                    })]
                }))
            }
            var N = {
                    propTypes: {
                        id: g().number.isRequired,
                        href: g().string.isRequired,
                        img: g().string.isRequired,
                        title: g().string.isRequired,
                        shortTitle: g().string,
                        isLive: g().bool
                    },
                    defaultProps: {
                        exclusiveTo: "",
                        shortTitle: "",
                        pageForAnalytics: "",
                        isLive: !1
                    }
                },
                y = t(30629),
                T = t.n(y);

            function L(e) {
                var i = e.img,
                    t = e.href,
                    l = e.title,
                    r = e.analytics,
                    o = e.isLive;
                return (0, a.jsxs)(d.Z, (0, n.Z)((0, s.Z)({
                    href: t,
                    className: T().slide
                }, r), {
                    children: [o ? (0, a.jsx)(p.Z, {
                        className: T().liveBadge
                    }) : null, (0, a.jsx)("figure", {
                        className: T().figure,
                        children: (0, a.jsx)(c.Z, {
                            src: i,
                            size: "list-large",
                            className: T().image
                        })
                    }), (0, a.jsx)("div", {
                        className: T().caption,
                        children: (0, a.jsx)(_.Z, {
                            className: T().title,
                            maxLines: 2,
                            children: l
                        })
                    })]
                }))
            }
            L.propTypes = N.propTypes, L.defaultProps = N.defaultProps;
            var b = L,
                k = {
                    date: g().string.isRequired,
                    title: g().string.isRequired,
                    isLive: g().bool
                },
                G = t(64770),
                R = t.n(G);

            function B(e) {
                var i = e.title,
                    t = void 0 === i ? "" : i,
                    s = e.date,
                    l = void 0 === s ? "" : s,
                    r = e.isLive,
                    n = void 0 !== r && r;
                return (0, a.jsxs)("div", {
                    className: R().slide,
                    children: [n ? (0, a.jsx)(p.Z, {
                        className: R().liveBadge
                    }) : null, (0, a.jsxs)("div", {
                        className: R().caption,
                        children: [(0, a.jsx)("p", {
                            className: R().title,
                            children: t
                        }), (0, a.jsx)("p", {
                            className: R().date,
                            children: l
                        })]
                    })]
                })
            }
            B.propTypes = k;
            var q = t(92033),
                C = {
                    coverImage: g().string.isRequired,
                    permalink: g().string.isRequired,
                    description: g().string.isRequired,
                    latest: g().arrayOf(g().any),
                    isLive: g().bool
                },
                F = t(66978),
                V = t.n(F);

            function A(e) {
                var i = e.coverImage,
                    t = void 0 === i ? "" : i,
                    s = e.permalink,
                    l = void 0 === s ? "" : s,
                    r = e.description,
                    n = void 0 === r ? "" : r,
                    o = e.latest,
                    m = void 0 === o ? [] : o,
                    g = e.isLive,
                    v = void 0 !== g && g,
                    h = (0, q.Z)(["0", "permalink"], m, l),
                    f = (0, q.Z)(["0", "title"], m, "");
                return (0, a.jsxs)(d.Z, {
                    href: h,
                    className: V().slide,
                    children: [v ? (0, a.jsx)(p.Z, {
                        className: V().liveBadge
                    }) : null, (0, a.jsx)("figure", {
                        className: V().figure,
                        children: (0, a.jsx)(c.Z, {
                            src: t.landscape,
                            size: "list-large",
                            className: V().image
                        })
                    }), (0, a.jsx)("div", {
                        className: V().caption,
                        children: (0, a.jsx)(_.Z, {
                            is: "p",
                            className: V().desc,
                            maxLines: 7,
                            children: n
                        })
                    }), (0, a.jsx)("div", {
                        className: V().latest,
                        children: (0, a.jsxs)("div", {
                            className: V().content,
                            children: [(0, a.jsxs)("div", {
                                className: V().top,
                                children: [(0, a.jsx)("span", {
                                    className: V().latestLabel,
                                    children: "Latest Episode"
                                }), (0, a.jsx)("p", {
                                    className: V().episodeTitle,
                                    children: f
                                })]
                            }), (0, a.jsx)("div", {
                                className: V().bot,
                                children: (0, a.jsx)("div", {
                                    className: V().invert,
                                    children: (0, a.jsx)(u.Z, {
                                        width: "16",
                                        height: "16"
                                    })
                                })
                            })]
                        })
                    })]
                })
            }
            A.propTypes = C;
            var I = t(9849),
                w = t(6277);
            var P = ["Broadcast", "Verified"],
                z = ["Completed", "Over", "Final"],
                O = function(e) {
                    if (!e) return !1;
                    if ("event" !== e.type) return !0;
                    var i = e.productionStatus;
                    return !i || 0 === i.length || !i.every((function(e) {
                        return z.includes(e.status)
                    }))
                },
                W = function(e) {
                    if (e && "event" === e.type) {
                        var i = e.productionStatus;
                        if (!i || 0 === i.length) return e;
                        var t = i.some((function(e) {
                            return P.includes(e.status)
                        }));
                        return (0, n.Z)((0, s.Z)({}, e), {
                            isLive: t
                        })
                    }
                    return e
                },
                D = {
                    video: S,
                    game: b,
                    hyperlink: Z,
                    page: Z,
                    event: Z,
                    post: Z,
                    stat: B,
                    show: A,
                    series: A,
                    collection: A
                };

            function K(e) {
                var i, t = e.content,
                    n = e.pageForAnalytics,
                    d = e.snap,
                    o = void 0 === d || d,
                    c = e.positionForAnalytics,
                    _ = e.titleWithLogo,
                    u = e.blockAd,
                    p = e.blockTitleLeft,
                    m = (0, q.Z)(["title"], t, ""),
                    g = null === t || void 0 === t || null === (i = t.value) || void 0 === i ? void 0 : i.content,
                    v = g ? (0, q.Z)(["value", "content"], t, []) : (0, q.Z)(["value", "items"], t, []),
                    h = (0, q.Z)(["sponsor"], t, ""),
                    f = m.replace(/\\/g, ""),
                    S = (0, I.dF)(n, f, c, h),
                    x = v.filter(O).map(W);
                return x.length ? (0, a.jsx)(l.Z, {
                    as: "section",
                    title: f,
                    hasCarousel: !0,
                    titleWithLogo: _,
                    blockAd: u,
                    blockTitleLeft: p,
                    titleAs: "h3",
                    children: (0, a.jsx)(r.Z, {
                        buttonAnalytics: S,
                        slideGap: 20,
                        slideViewport: !0,
                        snap: o,
                        children: x.map((function(e, i) {
                            var t = g ? D[e.type] : D.series;
                            if (!t) return null;
                            var l = "".concat(i + 1);
                            if (!g) return (0, a.jsx)(t, (0, s.Z)({
                                pos: l
                            }, e), e.id);
                            var r = function(e, i, t, a, l) {
                                var r, n = a.replace(/\W/g, "-").toLowerCase(),
                                    d = e.shortTitle || e.title,
                                    o = e.isLive,
                                    c = (0, s.Z)({
                                        "data-track": "video" === e.type ? "video" : "click",
                                        "data-id": "nba:".concat(t, ":carousel:card"),
                                        "data-type": "card",
                                        "data-pos": i,
                                        "data-section": n,
                                        "data-section-pos": l,
                                        "data-content": d,
                                        "data-content-id": e.id,
                                        "data-premium": "free" === e.entitlement ? "true" : "false"
                                    }, "video" === e.type && {
                                        "data-franchise": (0, w.Z)(e.taxonomy),
                                        "data-cat-type": (null === (r = e.categoryPrimary) || void 0 === r ? void 0 : r.name) || e.category || "",
                                        "data-live-vod": "vod"
                                    });
                                switch (e.type) {
                                    case "game":
                                        var _ = e.gameTile && Object.keys(e.gameTile) ? Object.values(e.gameTile)[0] : e.imageGame;
                                        return {
                                            id: e.id,
                                            img: _,
                                            title: d,
                                            href: "/game/".concat(e.idGame, "/"),
                                            analytics: (0, s.Z)({}, c, {
                                                "data-content-id": e.idGame
                                            }, {
                                                "data-content": "".concat(e.headline, ", ").concat(e.name.substr(0, 10))
                                            }),
                                            isLive: o
                                        };
                                    case "video":
                                        return {
                                            id: e.id,
                                            videoId: e.id,
                                            img: e.featuredImage,
                                            title: d,
                                            shortTitle: e.shortTitle,
                                            href: e.permalink,
                                            runtime: e.videoDuration,
                                            exclusiveTo: e.entitlements,
                                            analytics: (0, s.Z)({}, c),
                                            isLive: o
                                        };
                                    case "stat":
                                        return {
                                            id: e.id,
                                            title: e.text_expanded,
                                            date: e.date,
                                            isStats: !0,
                                            isLive: o
                                        };
                                    default:
                                        return {
                                            id: e.id,
                                            img: e.featuredImage,
                                            title: d,
                                            shortTitle: e.shortTitle,
                                            href: e.permalink,
                                            analytics: (0, s.Z)({}, c),
                                            isLive: o
                                        }
                                }
                            }(e, l, n, f, c);
                            return (0, a.jsx)(t, (0, s.Z)({}, r), e.id)
                        }))
                    })
                }) : (0, a.jsx)(a.Fragment, {})
            }
        },
        69154: function(e) {
            e.exports = {
                slide: "ContentSlide_slide__Mr2Ug",
                figure: "ContentSlide_figure__QZWMJ",
                image: "ContentSlide_image__cNZKg",
                runtime: "ContentSlide_runtime__394Xx",
                caption: "ContentSlide_caption__e7MAJ",
                subscriptionTags: "ContentSlide_subscriptionTags__k3DE9",
                text: "ContentSlide_text__m_W0K",
                liveBadge: "ContentSlide_liveBadge__hN06R"
            }
        },
        30629: function(e) {
            e.exports = {
                slide: "GameSlide_slide__VQG_9",
                figure: "GameSlide_figure__u6eSO",
                image: "GameSlide_image__SWDWH",
                playIcon: "GameSlide_playIcon__Xa3Kx",
                runtime: "GameSlide_runtime__Ve_zu",
                caption: "GameSlide_caption__rSFRL",
                subscriptionTags: "GameSlide_subscriptionTags__jFKA2",
                title: "GameSlide_title__kOQxL",
                liveBadge: "GameSlide_liveBadge___AKZw"
            }
        },
        66978: function(e) {
            e.exports = {
                slide: "SeriesSlide_slide__wJ8J5",
                figure: "SeriesSlide_figure__7cMlr",
                image: "SeriesSlide_image__iZM0q",
                caption: "SeriesSlide_caption__1tgnX",
                date: "SeriesSlide_date__bg0K_",
                title: "SeriesSlide_title__PcVXy",
                latest: "SeriesSlide_latest__l_GDX",
                t8: "SeriesSlide_t8__gksGP",
                invert: "SeriesSlide_invert__GFUSX",
                desc: "SeriesSlide_desc__RMLeG",
                content: "SeriesSlide_content__3LBGm",
                top: "SeriesSlide_top__uaJW2",
                bot: "SeriesSlide_bot__A0xZl",
                episodeTitle: "SeriesSlide_episodeTitle__EdrIz",
                latestLabel: "SeriesSlide_latestLabel__7Ne1Z",
                liveBadge: "SeriesSlide_liveBadge__A7etR"
            }
        },
        64770: function(e) {
            e.exports = {
                slide: "StatSlide_slide__goih4",
                caption: "StatSlide_caption__vMKuQ",
                date: "StatSlide_date__tFGQb",
                title: "StatSlide_title__R7hgZ",
                liveBadge: "StatSlide_liveBadge__oTFCL"
            }
        },
        39296: function(e) {
            e.exports = {
                slide: "VideoSlide_slide__f1U4c",
                figure: "VideoSlide_figure__itD2l",
                image: "VideoSlide_image__2xwP_",
                playIcon: "VideoSlide_playIcon__2vLDz",
                runtime: "VideoSlide_runtime__UgOso",
                caption: "VideoSlide_caption__FoEjF",
                subscriptionTags: "VideoSlide_subscriptionTags__oItqL",
                title: "VideoSlide_title__PDzkh",
                liveBadge: "VideoSlide_liveBadge__N2_nS"
            }
        }
    }
]);