(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [38800], {
        38800: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return R
                }
            });
            var r = n(14924),
                a = n(26042),
                i = n(69396),
                o = n(99534),
                d = n(85893),
                u = n(67294),
                s = n(31682),
                c = n(10253),
                l = n(77226),
                f = n(60196),
                g = n(93967),
                v = n.n(g),
                m = n(91567),
                p = n(67724),
                h = n(52638),
                _ = n.n(h),
                b = n(44691),
                y = ["sponsor", "smallSponsor"];

            function w(e) {
                var t = e.className,
                    n = e.placementId,
                    r = e.singleton,
                    s = e.type,
                    c = void 0 === s ? "banner" : s,
                    l = e.overrideWebview,
                    f = e.lazyLoad,
                    g = void 0 !== f && f,
                    h = e.isSchedulePage,
                    w = void 0 !== h && h,
                    S = (0, o.Z)(e, ["className", "placementId", "singleton", "type", "overrideWebview", "lazyLoad", "isSchedulePage"]),
                    x = (0, u.useState)(!0),
                    I = x[0],
                    E = x[1],
                    Z = (0, u.useRef)(null),
                    N = (0, u.useContext)(m.N).isWebView,
                    W = (0, u.useContext)(b.E).featureFlags;
                (0, u.useEffect)((function() {
                    var e;
                    return r && Z.current && (e = new MutationObserver((function(e) {
                            e[0].target.offsetWidth && e[0].target.offsetHeight && E(!1)
                        }))).observe(Z.current, {
                            attributes: !0
                        }),
                        function() {
                            return e && e.disconnect()
                        }
                }), [r]);
                var k = y.includes(c),
                    z = I && "banner" === c;
                return (null === W || void 0 === W ? void 0 : W.disableAdFuel) || !p.dL || N && !l ? (0, d.jsx)(d.Fragment, {}) : p.dL && "contextual" === c ? (0, d.jsx)("div", {
                    id: n
                }) : p.dL ? (0, d.jsxs)("div", (0, i.Z)((0, a.Z)({
                    className: v()(_().ad, t),
                    "data-centered": !k,
                    "data-ad-type": c
                }, S), {
                    children: [(0, d.jsx)("div", {
                        id: n,
                        className: _().placement,
                        "data-full-width": z,
                        "data-lazy": g
                    }), r && (0, d.jsx)("div", {
                        ref: Z,
                        className: _().singleton,
                        id: r,
                        "data-is-schedule-page": w
                    })]
                })) : (0, d.jsx)(d.Fragment, {})
            }
            var S = n(38901),
                x = n(18014);
            var I = n(61277);

            function E(e) {
                var t = e.elm,
                    n = e.onRefresh,
                    r = (0, x.kd)().refreshSettings,
                    a = function() {
                        var e = (0, u.useState)("undefined" === typeof document || "hidden" !== document.visibilityState),
                            t = e[0],
                            n = e[1];
                        return (0, u.useEffect)((function() {
                            if ("undefined" !== typeof document && "visibilityState" in document) {
                                var e = function() {
                                    n("hidden" !== document.visibilityState)
                                };
                                return document.addEventListener("visibilitychange", e),
                                    function() {
                                        document.removeEventListener("visibilitychange", e)
                                    }
                            }
                        }), []), t
                    }(),
                    i = (0, I.Z)("#fixed-layout"),
                    o = (0, u.useRef)(null),
                    d = (0, u.useState)(0),
                    s = d[0],
                    l = d[1],
                    f = (0, u.useState)(!1),
                    g = f[0],
                    v = f[1],
                    m = function(e, t) {
                        var n = (0, u.useState)(!1),
                            r = n[0],
                            a = n[1];
                        return (0, u.useEffect)((function() {
                            if (e.current) {
                                var n = new IntersectionObserver((function(e) {
                                    var t = (0, c.Z)(e, 1)[0];
                                    a(t.isIntersecting)
                                }), t);
                                return n.observe(e.current),
                                    function() {
                                        n.disconnect()
                                    }
                            }
                        }), [e, t]), r
                    }(t, (0, u.useMemo)((function() {
                        return {
                            root: null,
                            threshold: .5,
                            rootMargin: "-".concat(i, "px 0px 0px 0px")
                        }
                    }), [i]));
                (0, u.useEffect)((function() {
                    if (r) return s >= r.max ? (clearTimeout(o.current), void(o.current = null)) : void(m && a && !o.current ? o.current = setTimeout((function() {
                        v(!0)
                    }), r.dur) : m && a || (clearTimeout(o.current), o.current = null))
                }), [m, a, r, s]), (0, u.useEffect)((function() {
                    n && g && (n(), clearTimeout(o.current), o.current = null, v(!1), l((function(e) {
                        return e + 1
                    })))
                }), [g, n]), (0, u.useEffect)((function() {
                    return function() {
                        o.current && (clearTimeout(o.current), o.current = null)
                    }
                }), [])
            }
            var Z = n(43070),
                N = n.n(Z);

            function W(e) {
                var t = e.className,
                    n = e.placementId,
                    r = e.type,
                    i = e.onSlotRender,
                    s = e.overrideWebview,
                    f = (0, o.Z)(e, ["className", "placementId", "type", "onSlotRender", "overrideWebview"]),
                    g = (0, S.Z)(),
                    m = function(e, t) {
                        var n = (0, x.kd)(),
                            r = n.enabled,
                            i = n.getAdSlotForDomId,
                            o = n.hasRunOnce,
                            d = n.hasAuthInit,
                            s = n.target,
                            f = (0, u.useRef)(null),
                            g = (0, u.useRef)(null);
                        return (0, u.useEffect)((function() {
                            if (d && r && "undefined" !== typeof googletag && e) {
                                var n = i(e);
                                if (n) {
                                    var o = (0, l.XZ)(["sizeMap", 0, "sizes", 0], n, [0, 0]);
                                    return googletag.cmd.push((function() {
                                            googletag.pubads().collapseEmptyDivs(!1);
                                            var r = googletag.defineSlot(n.gamId, o, n.domId);
                                            if (r) {
                                                n.targets && n.targets.length && n.targets.forEach((function(e) {
                                                    var t = (0, c.Z)(e, 2),
                                                        n = t[0],
                                                        a = t[1];
                                                    return r.setTargeting(n, a)
                                                })), s && r.setTargeting("category", s);
                                                var i = googletag.sizeMapping();
                                                n.sizeMap.forEach((function(e) {
                                                    var t = e.viewport,
                                                        n = e.sizes;
                                                    i.addSize(t, n)
                                                }));
                                                var d = i.build();
                                                r.defineSizeMapping(d), r.addService(googletag.pubads());
                                                var u = function(n) {
                                                    n.slot.getSlotElementId() === e && (null === t || void 0 === t || t((0, a.Z)({
                                                        placementId: e,
                                                        adUnitPath: n.slot.getAdUnitPath()
                                                    }, n)))
                                                };
                                                googletag.pubads().addEventListener("slotRenderEnded", u), g.current = u, googletag.display(e), f.current = r
                                            }
                                        })),
                                        function() {
                                            googletag.cmd.push((function() {
                                                g.current && (googletag.pubads().removeEventListener("slotRenderEnded", g.current), g.current = null), f.current && (googletag.destroySlots([f.current]), f.current = null)
                                            }))
                                        }
                                }
                            }
                        }), [o, d, e, s, r]), {
                            enabled: r,
                            adSlot: f
                        }
                    }(n, i),
                    p = m.enabled,
                    h = m.adSlot,
                    _ = (0, u.useRef)(null);
                return E({
                    elm: _,
                    onRefresh: (0, u.useCallback)((function() {
                        p && h && h.current && googletag && googletag.cmd.push((function() {
                            googletag.pubads().refresh([h.current])
                        }))
                    }), [p, h])
                }), !p || g && !s || !n ? (0, d.jsx)(d.Fragment, {}) : (0, d.jsx)("div", (0, a.Z)({
                    className: v()(N().ad, t),
                    id: n,
                    "data-ad-type": r,
                    ref: _
                }, f))
            }
            var k = n(66472),
                z = n.n(k);

            function R(e) {
                var t = e.className,
                    n = e.isSchedulePage,
                    g = void 0 !== n && n,
                    v = e.lazyLoad,
                    m = void 0 !== v && v,
                    p = e.overrideWebview,
                    h = e.placementId,
                    _ = e.singleton,
                    b = e.domId,
                    y = void 0 === b ? "" : b,
                    S = e.marketingDomId,
                    x = e.type,
                    I = void 0 === x ? "banner" : x,
                    E = (0, o.Z)(e, ["className", "isSchedulePage", "lazyLoad", "overrideWebview", "placementId", "singleton", "domId", "marketingDomId", "type"]),
                    Z = (0, s.L)(),
                    N = Z.isGamNetwork,
                    k = Z.isGamEnabled,
                    R = Z.isWmNetwork,
                    j = Z.isWmEnabled,
                    A = (0, u.useState)({}),
                    D = A[0],
                    L = A[1],
                    M = (D[y] || {}).creativeId,
                    T = (0, u.useCallback)((function(e) {
                        L((function(t) {
                            return (0, i.Z)((0, a.Z)({}, t), (0, r.Z)({}, e.placementId, e))
                        }))
                    }), [D]),
                    F = (0, u.useMemo)((function() {
                        return function(e) {
                            var t = e.adMeta,
                                n = e.domId,
                                r = e.marketingDomId;
                            try {
                                var a = function(e, t) {
                                    return e[t].size
                                }(t, n);
                                return !!n && !!r && !!a && !(0, l.yD)(a) && f.qA.some((function(e) {
                                    var t = (0, c.Z)(e, 2),
                                        n = t[0],
                                        r = t[1];
                                    return a[0] === n && a[1] === r
                                }))
                            } catch (i) {
                                return !1
                            }
                        }({
                            adMeta: D,
                            domId: y,
                            marketingDomId: S
                        })
                    }), [D, M]);
                return N && k ? (0, d.jsx)("div", {
                    className: z().adTransitioner,
                    children: F ? (0, d.jsxs)("div", {
                        "data-no-display-ad": "true",
                        "data-type": "gb",
                        className: t,
                        children: [(0, d.jsx)(W, {
                            placementId: y,
                            type: "banner",
                            onSlotRender: T,
                            overrideWebview: p
                        }), (0, d.jsx)(W, {
                            placementId: S,
                            type: "marketing",
                            onSlotRender: T,
                            overrideWebview: p
                        })]
                    }) : (0, d.jsx)(W, {
                        className: t,
                        placementId: y,
                        type: I,
                        onSlotRender: T,
                        overrideWebview: p
                    })
                }) : R && j ? (0, d.jsx)(w, (0, a.Z)({
                    className: t,
                    isSchedulePage: g,
                    lazyLoad: m,
                    overrideWebview: p,
                    placementId: h,
                    singleton: _,
                    type: I
                }, E)) : (0, d.jsx)(d.Fragment, {})
            }
        },
        60196: function(e, t, n) {
            "use strict";
            n.d(t, {
                AK: function() {
                    return a
                },
                gU: function() {
                    return r
                },
                qA: function() {
                    return i
                }
            });
            var r = {
                    S1: "watch_video_ad_s_1",
                    V1: "watch_video_ad_b_1",
                    B1: "watch_event_ad_b_1",
                    E1: "watch_event_ad_s_1"
                },
                a = {
                    B1: "pages_ad_b_1"
                },
                i = [
                    [970, 90],
                    [728, 90]
                ]
        },
        61277: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var r = n(67294),
                a = n(42669);

            function i() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "#fixed-layout",
                    t = (0, a.Z)(),
                    n = t.height,
                    i = t.width,
                    o = (0, r.useMemo)((function() {
                        var t, n = document.querySelector(e);
                        return n && null !== (t = n.offsetHeight) && void 0 !== t ? t : 0
                    }), [e, n, i]);
                return o
            }
        },
        42669: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var r = n(67294);

            function a() {
                var e = (0, r.useState)({
                        width: void 0,
                        height: void 0
                    }),
                    t = e[0],
                    n = e[1];
                return (0, r.useEffect)((function() {
                    var e = function() {
                        n({
                            width: window.innerWidth,
                            height: window.innerHeight
                        })
                    };
                    return window.addEventListener("resize", e), e(),
                        function() {
                            return window.removeEventListener("resize", e)
                        }
                }), []), t
            }
        },
        66472: function(e) {
            e.exports = {
                ad: "DisplayAd_ad__YpTBs",
                placement: "DisplayAd_placement__gO0o0",
                singleton: "DisplayAd_singleton___iXtO",
                adTransitioner: "DisplayAd_adTransitioner__mnGK7"
            }
        },
        43070: function(e) {
            e.exports = {
                ad: "GoogleDisplayAd_ad__gNdkB"
            }
        },
        52638: function(e) {
            e.exports = {
                ad: "WarnerDisplayAd_ad__in_ug",
                placement: "WarnerDisplayAd_placement__r9MR2",
                singleton: "WarnerDisplayAd_singleton__WkbbK"
            }
        }
    }
]);