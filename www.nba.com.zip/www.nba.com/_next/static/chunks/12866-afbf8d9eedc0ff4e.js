"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [12866], {
        88597: function(t, e, n) {
            n.d(e, {
                Z: function() {
                    return s
                }
            });
            var a = n(85893),
                o = n(28981),
                i = n(45697),
                c = {
                    propTypes: {
                        json: n.n(i)().shape({}).isRequired
                    },
                    defaultProps: {}
                };

            function s(t) {
                var e = t.json;
                try {
                    var n = JSON.stringify(e);
                    return (0, a.jsx)("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: n
                        }
                    })
                } catch (i) {
                    return (0, o.Z)(i), null
                }
            }
            s.propTypes = c.propTypes, s.defaultProps = c.defaultProps
        },
        1207: function(t, e, n) {
            n.d(e, {
                Z: function() {
                    return a.Z
                }
            });
            var a = n(88597)
        },
        33246: function(t, e, n) {
            n.d(e, {
                jC: function() {
                    return o
                },
                Kx: function() {
                    return u
                },
                Jx: function() {
                    return h
                },
                UD: function() {
                    return l
                },
                zj: function() {
                    return d
                },
                Hz: function() {
                    return g
                },
                bh: function() {
                    return y
                },
                R7: function() {
                    return L
                },
                C6: function() {
                    return f
                },
                Ww: function() {
                    return A
                },
                SP: function() {
                    return B
                },
                Hh: function() {
                    return v
                },
                yd: function() {
                    return P
                },
                Rs: function() {
                    return T
                },
                M1: function() {
                    return w
                },
                Ni: function() {
                    return S
                },
                Hs: function() {
                    return x
                },
                gA: function() {
                    return $
                },
                OD: function() {
                    return C
                },
                eg: function() {
                    return _
                },
                K9: function() {
                    return H
                },
                Pw: function() {
                    return O
                },
                Kl: function() {
                    return M
                },
                M$: function() {
                    return k
                }
            });
            var a = n(67724);

            function o(t) {
                var e = t.title,
                    n = t.name;
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: " https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA News",
                        item: " https://".concat(a.$g, "/news")
                    }, {
                        "@type": "ListItem",
                        position: 3,
                        name: e,
                        item: " https://".concat(a.$g, "/news/").concat(n)
                    }]
                }
            }
            var i = n(29815),
                c = n(77226),
                s = n(92033),
                r = "liveblog",
                m = "LiveBlogPosting",
                p = "Article";

            function u(t) {
                var e, n = t.permalink,
                    o = t.title,
                    u = t.contentText,
                    h = t.date,
                    l = t.featuredImage,
                    d = t.modified,
                    g = t.excerpt,
                    y = t.seo,
                    f = t.contentFiltered,
                    L = {
                        "@context": "https://schema.org/",
                        "@type": p,
                        "@id": n,
                        headline: o,
                        url: n,
                        articleBody: u,
                        dateCreated: h,
                        description: g,
                        thumbnailUrl: l,
                        articleSection: (0, s.Z)(["categoryPrimary", "name"], t),
                        creator: {
                            "@type": "Person",
                            name: (0, s.Z)(["author", "name"], t)
                        },
                        author: {
                            "@type": "Person",
                            name: (0, s.Z)(["author", "name"], t)
                        },
                        datePublished: h,
                        image: l,
                        publisher: {
                            "@type": "Organization",
                            name: "NBA.com",
                            logo: {
                                "@type": "ImageObject",
                                url: "".concat(a.WT, "/logo-nba.svg"),
                                Width: "30",
                                Height: "50"
                            }
                        },
                        dateModified: d,
                        mainEntityOfPage: n
                    },
                    A = null === y || void 0 === y ? void 0 : y.find((function(t) {
                        return "schemaType" === t.name
                    }));
                (null === A || void 0 === A ? void 0 : A.content) === r && (L["@type"] = m, L.coverageStartTime = h, L.coverageEndTime = (null === (e = null === y || void 0 === y ? void 0 : y.find((function(t) {
                    return "coverageEndTime" === t.name
                }))) || void 0 === e ? void 0 : e.content) || new Date(new Date(h).getTime() + 864e5).toISOString(), L.liveBlogUpdate = (0, i.Z)(function(t, e, n) {
                    try {
                        return (0, c.sk)() ? [] : function(t, e, n) {
                            if (!t) return [];
                            var a = [],
                                o = Array.from(t.children || []);
                            if (o.some((function(t) {
                                    return "H2" === t.tagName
                                }))) {
                                var i = null;
                                o.forEach((function(t) {
                                    var o;
                                    "H2" === t.tagName ? (i && a.push(i), i = {
                                        headline: (null === (o = t.textContent) || void 0 === o ? void 0 : o.trim()) || n,
                                        "@type": "BlogPosting",
                                        datePublished: e,
                                        articleBody: ""
                                    }) : "P" === t.tagName && t.textContent && (i ? i.articleBody += (i.articleBody ? "\n\n" : "") + t.textContent.trim() : i = {
                                        headline: n,
                                        "@type": "BlogPosting",
                                        datePublished: e,
                                        articleBody: t.textContent.trim()
                                    })
                                })), i && a.push(i)
                            } else o.forEach((function(t) {
                                "P" === t.tagName && t.textContent && a.push({
                                    headline: n,
                                    "@type": "BlogPosting",
                                    datePublished: e,
                                    articleBody: t.textContent.trim()
                                })
                            }));
                            return a
                        }((new DOMParser).parseFromString(t || "", "text/html").body, e, n)
                    } catch (a) {
                        return []
                    }
                }(f, d, o)));
                return L
            }

            function h(t) {
                var e = t.name,
                    n = t.type,
                    o = t.isWriters,
                    c = t.title;
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: e,
                        item: "https://".concat(a.$g, "/").concat(n)
                    }].concat((0, i.Z)(o ? [{
                        "@type": "ListItem",
                        position: 3,
                        name: c,
                        item: "https://".concat(a.$g, "/news/writers-archive")
                    }] : []))
                }
            }

            function l(t, e, n) {
                var o = t.homeTeam,
                    c = t.awayTeam;
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Games",
                        item: "https://".concat(a.$g, "/games")
                    }, {
                        "@type": "ListItem",
                        position: 3,
                        name: "".concat(o.teamTricode, " vs ").concat(c.teamTricode),
                        item: "https://".concat(a.$g, "/game/").concat(e)
                    }].concat((0, i.Z)("summary" !== n.id ? [{
                        "@type": "ListItem",
                        position: 4,
                        name: n.label,
                        item: "https://".concat(a.$g, "/game/").concat(e, "/").concat(n.id)
                    }] : []))
                }
            }

            function d(t, e) {
                var n = t.awayTeam,
                    o = t.homeTeam,
                    i = t.arena,
                    c = t.arenaStreetAddress,
                    s = t.arenaCity,
                    r = t.arenaState,
                    m = t.arenaPostalCode,
                    p = t.arenaCountry;
                return {
                    "@context": "http://www.schema.org",
                    "@type": "SportsEvent",
                    name: "".concat(n.teamName, " @ ").concat(o.teamName),
                    url: "https://".concat(a.$g, "/game/").concat(e),
                    description: "NBA Game - ".concat(n.teamName, " vs. ").concat(o.teamName),
                    startDate: t.gameEt,
                    location: {
                        "@type": "Place",
                        name: "".concat(i.arenaName, ", ").concat(i.arenaCity, ", ").concat(i.arenaState),
                        address: {
                            "@type": "PostalAddress",
                            streetAddress: c,
                            addressLocality: s,
                            addressRegion: r,
                            postalCode: m,
                            addressCountry: p
                        }
                    }
                }
            }

            function g() {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Games",
                        item: "https://".concat(a.$g, "/games")
                    }]
                }
            }

            function y() {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: {
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }
                }
            }

            function f() {
                return {
                    "@context": "http://schema.org",
                    "@type": "WebPage",
                    mainEntityOfPage: {
                        "@type": "WebPage",
                        "@id": "https://".concat(a.$g)
                    },
                    headline: "NBA.com | The official site of the National Basketball Association",
                    url: "https://".concat(a.$g)
                }
            }

            function L() {
                return {
                    "@context": "https://schema.org",
                    "@type": "SportsOrganization",
                    name: "NBA",
                    alternateName: "National Basketball Association",
                    url: "https://".concat(a.$g),
                    description: "Follow the action on NBA scores, schedules, stats, news, teams, and players. Buy tickets or watch the games anywhere with NBA League Pass.",
                    logo: "".concat(a.WT, "/logo-nba.svg"),
                    brand: {
                        "@type": "Organization",
                        name: "National Basketball Association"
                    },
                    sport: "Basketball",
                    sameAs: ["https://www.youtube.com/user/NBA", "https://twitter.com/nba", "https://www.facebook.com/NBA", "https://www.instagram.com/nba/", "https://www.linkedin.com/company/national-basketball-association/", "https://www.pinterest.com/NBA/"]
                }
            }

            function A() {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA News",
                        item: "https://".concat(a.$g, "/news")
                    }]
                }
            }

            function B() {
                return {
                    "@context": "https://schema.org",
                    "@type": "LiveBlogPosting",
                    "@id": "https://www.nba.com/summer-league/2024",
                    coverageStartTime: "2024-07-12T00:00:00-07:00",
                    coverageEndTime: "2024-07-22T23:59:59-07:00",
                    headline: "NBA Summer League 2024",
                    description: "Live updates and coverage of the NBA Summer League taking place in Las Vegas.",
                    about: {
                        "@type": "Event",
                        startDate: "2024-07-12",
                        endDate: "2024-07-22",
                        name: "NBA Summer League",
                        location: {
                            "@type": "Place",
                            name: "Las Vegas"
                        }
                    },
                    liveBlogUpdate: [{
                        "@type": "BlogPosting",
                        headline: "NBA Summer League kicks off in Las Vegas",
                        datePublished: "2024-07-12T09:00:00-07:00",
                        articleBody: "The NBA Summer League begins today in Las Vegas, featuring all 30 NBA teams showcasing their talent."
                    }, {
                        "@type": "BlogPosting",
                        headline: "Exciting matchups scheduled for today's games",
                        datePublished: "2024-07-12T12:00:00-07:00",
                        articleBody: "Check out today's schedule for the NBA Summer League, including key matchups between rising stars."
                    }, {
                        "@type": "BlogPosting",
                        headline: "Highlights from the opening ceremony",
                        datePublished: "2024-07-12T17:00:00-07:00",
                        articleBody: "Catch up on the highlights from the NBA Summer League opening ceremony."
                    }]
                }
            }

            function v(t) {
                var e = t.playerInfo,
                    n = t.section,
                    o = e.PERSON_ID,
                    c = e.PLAYER_SLUG,
                    s = e.DISPLAY_FIRST_LAST;
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Players",
                        item: "https://".concat(a.$g, "/players")
                    }, {
                        "@type": "ListItem",
                        position: 3,
                        name: s,
                        item: "https://".concat(a.$g, "/player/").concat(o, "/").concat(c)
                    }].concat((0, i.Z)("profile" !== n ? [{
                        "@type": "ListItem",
                        position: 4,
                        name: n.charAt(0).toUpperCase() + n.slice(1),
                        item: "https://".concat(a.$g, "/player/").concat(o, "/").concat(c, "/").concat(n)
                    }] : []))
                }
            }
            var N = n(42298),
                I = n(23855),
                E = n(34575),
                b = n(92826);

            function P(t) {
                var e = t.playerInfo,
                    n = t.coach,
                    o = e.PERSON_ID,
                    i = e.PLAYER_SLUG,
                    c = e.DISPLAY_FIRST_LAST,
                    s = e.HEIGHT,
                    r = e.BIRTHDATE,
                    m = e.TEAM_ID,
                    p = e.TEAM_CITY,
                    u = e.TEAM_NAME,
                    h = e.TEAM_SLUG,
                    l = r ? (0, N.Z)((0, I.Z)(r), "LLLL d, yyyy") : "",
                    d = (n || {}).COACH_NAME,
                    g = void 0 === d ? "" : d;
                return {
                    "@context": "http://schema.org",
                    "@type": "person",
                    "@id": (0, b.xA)(o, i),
                    givenName: c,
                    height: s,
                    birthDate: l,
                    image: {
                        "@type": "ImageObject",
                        caption: c,
                        representativeOfPage: !0,
                        contentUrl: "https://cdn.nba.com/headshots/nba/latest/1040x760/".concat(o, ".png")
                    },
                    memberOf: [{
                        "@type": "SportsTeam",
                        name: "".concat(p, " ").concat(u),
                        "@id": (0, E.HB)(m, h),
                        coach: g,
                        sport: "Basketball",
                        memberOf: [{
                            "@type": "SportsOrganization",
                            name: "National Basketball Association",
                            "@id": "https://".concat(a.$g)
                        }]
                    }]
                }
            }

            function T() {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Players",
                        item: "https://".concat(a.$g, "/players")
                    }]
                }
            }

            function w(t, e, n, o) {
                var c = t.name,
                    r = t.slug;
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Podcasts",
                        item: "https://".concat(a.$g, "/podcasts")
                    }, {
                        "@type": "ListItem",
                        position: 3,
                        name: c,
                        item: "https://".concat(a.$g, "/podcasts/").concat(r)
                    }].concat((0, i.Z)(e ? [{
                        "@type": "ListItem",
                        position: 4,
                        name: (0, s.Z)(["title"], n),
                        item: "https://".concat(a.$g).concat(o.asPath)
                    }] : []))
                }
            }

            function S(t, e, n) {
                var o = e.title,
                    i = e.date,
                    c = e.description,
                    s = n.omnySlug,
                    r = n.name,
                    m = n.slug;
                return {
                    "@context": "http://schema.org/",
                    "@type": "PodcastEpisode",
                    url: "https://".concat(a.$g).concat(t.asPath),
                    name: o,
                    datePublished: (0, N.Z)(new Date(i), "yyyy-MM-dd"),
                    description: c,
                    associatedMedia: {
                        "@type": "MediaObject",
                        contentUrl: "https://omny.fm/shows/".concat(s, "/").concat(t.query.all[1])
                    },
                    partOfSeries: {
                        "@type": "PodcastSeries",
                        name: r,
                        url: "https://".concat(a.$g, "/podcasts/").concat(m)
                    }
                }
            }

            function $() {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Standings",
                        item: "https://".concat(a.$g, "/standings")
                    }]
                }
            }

            function x(t) {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Schedule",
                        item: "https://".concat(a.$g, "/schedule")
                    }].concat((0, i.Z)("all" !== t ? [{
                        "@type": "ListItem",
                        position: 3,
                        name: t.charAt(0).toUpperCase() + t.slice(1),
                        item: "https://".concat(a.$g, "/schedule/").concat(t)
                    }] : []))
                }
            }

            function C(t) {
                var e = t.id,
                    n = t.info,
                    o = n.TEAM_NAME,
                    i = n.TEAM_SLUG,
                    c = (0, E.HB)(e, i);
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Teams",
                        item: "https://".concat(a.$g, "/teams")
                    }, {
                        "@type": "ListItem",
                        position: 3,
                        name: o,
                        item: "https://".concat(a.$g).concat(c)
                    }]
                }
            }

            function _(t) {
                var e = t.id,
                    n = t.info,
                    o = n.TEAM_CITY,
                    i = n.TEAM_NAME,
                    c = n.TEAM_SLUG,
                    s = "".concat(o, " ").concat(i),
                    r = (0, E.HB)(e, c);
                return {
                    "@context": "https://schema.org/",
                    "@type": "WebPage",
                    headline: "".concat((0, E.PS)(s), " ").concat(a.Ti),
                    url: r,
                    description: "".concat((0, E.dy)(s))
                }
            }

            function H(t) {
                var e = t.id,
                    n = t.info,
                    o = n.TEAM_CITY,
                    i = n.TEAM_NAME,
                    c = n.TEAM_CODE,
                    s = n.TEAM_CONFERENCE,
                    r = n.TEAM_DIVISION,
                    m = n.TEAM_SLUG,
                    p = t.social,
                    u = void 0 === p ? [] : p,
                    h = t.links,
                    l = h.tickets,
                    d = h.store,
                    g = t.coaches,
                    y = t.roster,
                    f = t.background,
                    L = f.ARENA,
                    A = f.CITY,
                    B = "".concat(o, " ").concat(i),
                    v = (0, E.HB)(e, m),
                    N = "".concat((0, E.dy)(B)),
                    I = g.find((function(t) {
                        return "Head Coach" === t.COACH_TYPE
                    })) || {},
                    P = I.COACH_NAME,
                    T = I.FIRST_NAME,
                    w = I.LAST_NAME;
                return {
                    "@context": "http://schema.org",
                    "@type": "SportsTeam",
                    "@id": v,
                    Name: i,
                    url: v,
                    sameAs: u.map((function(t) {
                        return t.WEBSITE_LINK
                    })),
                    logo: "".concat(a.yS, "/").concat(e, "/primary/logo.svg"),
                    description: N,
                    makesOffer: [{
                        "@type": "Offer",
                        name: "Buy Tickets",
                        url: l || "https://www.nba.com/".concat(c, "/tickets")
                    }, {
                        "@type": "Offer",
                        name: "Store",
                        url: d
                    }],
                    location: {
                        "@type": "Place",
                        name: L,
                        address: {
                            "@type": "PostalAddress",
                            addressLocality: A
                        }
                    },
                    coach: {
                        "@type": "Person",
                        name: P,
                        givenName: T,
                        familyName: w
                    },
                    athlete: y.map((function(t) {
                        return {
                            "@id": (0, b.xA)(t.PLAYER_ID),
                            name: t.PLAYER
                        }
                    })),
                    memberOf: [{
                        "@type": "Organization",
                        name: "National Basketball Association"
                    }, {
                        "@type": "Organization",
                        name: s
                    }, {
                        "@type": "Organization",
                        name: r
                    }]
                }
            }

            function O() {
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA Teams",
                        item: "https://".concat(a.$g, "/teams")
                    }]
                }
            }

            function M(t, e, n) {
                var o = e.name,
                    c = e.headline;
                return {
                    "@context": "https://schema.org",
                    "@type": "BreadcrumbList",
                    itemListElement: [{
                        "@type": "ListItem",
                        position: 1,
                        name: "Home",
                        item: "https://".concat(a.$g)
                    }, {
                        "@type": "ListItem",
                        position: 2,
                        name: "NBA News",
                        item: "https://".concat(a.$g, "/news")
                    }].concat((0, i.Z)(t ? [{
                        "@type": "ListItem",
                        position: 3,
                        name: "Writers Archive",
                        item: "https://".concat(a.$g, "/news/writers-archive")
                    }, {
                        "@type": "ListItem",
                        position: 4,
                        name: o,
                        item: "https://".concat(a.$g).concat(n.asPath)
                    }] : [{
                        "@type": "ListItem",
                        position: 3,
                        name: c,
                        item: "https://".concat(a.$g).concat(n.asPath)
                    }]))
                }
            }

            function k(t, e) {
                var n = t.authorPhoto,
                    o = t.name,
                    i = t.socialLink;
                return {
                    "@context": "https://schema.org",
                    "@type": "Person",
                    image: n,
                    name: o,
                    url: "https://".concat(a.$g).concat(e.asPath),
                    sameAs: [i]
                }
            }
        },
        34575: function(t, e, n) {
            n.d(e, {
                HB: function() {
                    return a
                },
                PS: function() {
                    return o
                },
                dy: function() {
                    return i
                }
            });
            var a = function(t, e) {
                    return e ? "/team/".concat(t, "/").concat(e) : "/team/".concat(t)
                },
                o = function(t) {
                    return "".concat(t, " Team Info and News")
                },
                i = function(t) {
                    return "View the ".concat(t, "'s Official NBA Schedule, Roster & Standings. Watch ").concat(t, "'s Games with NBA League Pass.")
                }
        },
        92826: function(t, e, n) {
            function a() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                return "".concat(t, " bio, latest news, videos, and exclusive content. Discover his awards, honors, and career achievements. Stay updated and find out when his next game is.")
            }

            function o(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return e ? "/player/".concat(t, "/").concat(e) : "/player/".concat(t)
            }

            function i(t, e) {
                return "".concat(t, " ").concat(e)
            }

            function c(t, e) {
                return "Active" === t || "Y" === e
            }

            function s(t, e, n) {
                var a = [t, e, n].filter((function(t) {
                    return t && !t.match(/^\s$/)
                }));
                return !a.length >= 1 ? "" : a.length > 1 ? a.join(" | ") : a[0]
            }
            n.d(e, {
                Co: function() {
                    return i
                },
                ge: function() {
                    return c
                },
                sK: function() {
                    return s
                },
                wv: function() {
                    return a
                },
                xA: function() {
                    return o
                }
            })
        }
    }
]);