(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [90659], {
        9299: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return p
                }
            });
            var i = t(85893),
                r = t(93967),
                o = t.n(r),
                a = t(37346),
                l = t(45697),
                n = t.n(l),
                c = {
                    propTypes: {
                        as: n().string,
                        children: n().node.isRequired,
                        className: n().string,
                        hideBorderSmall: n().bool,
                        small: n().bool
                    },
                    defaultProps: {
                        as: "h2",
                        className: "",
                        hideBorderSmall: !1,
                        small: !1
                    }
                },
                d = t(4713),
                m = t.n(d);

            function p(e) {
                var s = e.as,
                    t = e.children,
                    r = e.className,
                    l = e.hideBorderSmall,
                    n = e.small;
                return (0, i.jsx)(a.Z, {
                    is: s,
                    className: o()(m().base, r),
                    "data-small": n,
                    "data-hide-small-border": l,
                    children: t
                })
            }
            p.propTypes = c.propTypes, p.defaultProps = c.defaultProps
        },
        90659: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return B
                }
            });
            var i = t(26042),
                r = t(69396),
                o = t(99534),
                a = t(85893),
                l = t(93967),
                n = t.n(l),
                c = t(72887),
                d = t(9299),
                m = t(38800),
                p = t(41684),
                u = t(2433),
                _ = t(12185),
                h = t(37346),
                y = t(34180),
                k = t(29717),
                x = t(18919),
                N = t(93529),
                g = t(45697),
                T = t.n(g),
                b = {
                    propsTypes: {
                        analytics: T().shape({
                            articleType: T().oneOf(["main", "side", "bottom", "latest", "latestSide", "collection", "homepage"]),
                            collectionName: T().string,
                            id: T().oneOfType([T().string, T().number]),
                            index: T().number,
                            totalArticles: T().number
                        }),
                        category: T().string,
                        taxonomy: T().object,
                        href: T().string.isRequired,
                        as: T().string,
                        img: T().string,
                        subtitle: T().string,
                        timestamp: T().oneOfType([T().string, T().number]),
                        shortTitle: T().string,
                        title: T().string.isRequired,
                        runtime: T().string,
                        type: T().oneOf(["post", "video", "hyperlink", "podcast", "nbabet", "page"]).isRequired,
                        sponsor: T().oneOfType([T().shape({
                            sponsorUrl: T().string,
                            sponsorLogoUrl: T().string,
                            sponsorName: T().string
                        }), T().bool])
                    },
                    defaultProps: {
                        as: "",
                        category: "",
                        taxonomy: {},
                        img: "",
                        subtitle: "",
                        timestamp: "",
                        runtime: "",
                        analytics: {},
                        shortTitle: "",
                        sponsor: !1
                    }
                },
                f = t(70886),
                v = t.n(f);

            function j(e) {
                var s = e.timestamp,
                    t = e.as,
                    o = e.img,
                    l = e.subtitle,
                    n = e.title,
                    c = e.shortTitle,
                    d = e.href,
                    m = e.category,
                    u = e.taxonomy,
                    g = e.runtime,
                    T = e.type,
                    b = e.analytics,
                    f = e.sponsor,
                    j = (0, k.Z)((0, r.Z)((0, i.Z)({}, b), {
                        title: n,
                        sponsor: f,
                        category: m,
                        taxonomy: u
                    })),
                    w = (0, x.Z)(T),
                    A = w.isVideo,
                    Z = w.isPodcast,
                    H = (0, x.e)(b),
                    S = f || {},
                    I = S.sponsorName,
                    L = S.sponsorLogoUrl,
                    B = S.sponsorUrl,
                    F = !!(L && B && I),
                    R = (0, y.k)(s);
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(p.Z, (0, r.Z)((0, i.Z)({
                        title: "Article link for ".concat(n),
                        "data-sponser": F
                    }, j), {
                        href: d,
                        as: t,
                        className: v().link,
                        children: (0, a.jsxs)("article", {
                            className: v().article,
                            children: [(0, a.jsx)("div", {
                                className: v().videoContent,
                                children: (0, a.jsx)(_.Z, {
                                    isHero: !0,
                                    disabled: !A,
                                    className: v().videoThumb,
                                    src: o,
                                    imgSize: "article",
                                    alt: n,
                                    runtime: g,
                                    height: "100%",
                                    "data-type": "image"
                                })
                            }), (0, a.jsxs)("div", {
                                className: v().summary,
                                children: [(0, a.jsx)("div", {
                                    className: v().summaryInner,
                                    children: (0, a.jsxs)("header", {
                                        "data-type": "headline",
                                        children: [(m && H || Z) && (0, a.jsx)(h.Z, {
                                            is: "h4",
                                            text: Z ? "podcast" : m,
                                            className: v().category
                                        }), (0, a.jsx)(h.Z, {
                                            is: "h3",
                                            text: c || n,
                                            className: v().title,
                                            maxLines: 2
                                        }), l && (0, a.jsx)(h.Z, {
                                            is: "p",
                                            className: v().subtitle,
                                            text: l,
                                            maxLines: 2
                                        })]
                                    })
                                }), s && !F && (0, a.jsx)("div", {
                                    className: v().timestampBlock,
                                    children: (0, a.jsx)("span", {
                                        className: v().timestamp,
                                        children: R
                                    })
                                })]
                            })]
                        })
                    })), s && F && (0, a.jsxs)("div", {
                        className: v().timestampSponser,
                        children: [(0, a.jsx)("span", {
                            className: v().timestamp,
                            children: R
                        }), f && (0, a.jsx)(N.Z, {
                            sponsor: f,
                            analytics: (0, i.Z)({}, b, {
                                title: n,
                                section: b.collectionName
                            })
                        })]
                    })]
                })
            }
            j.propTypes = b.propsTypes, j.defaultProps = b.defaultProps;
            var w = t(95226),
                A = t(364),
                Z = t(28313),
                H = t(38799),
                S = {
                    propTypes: {
                        articles: T().arrayOf(H.c7),
                        title: T().string,
                        seeMoreAttributes: T().shape({}),
                        withRow: T().bool,
                        seeMoreLink: T().string,
                        analytics: T().bool,
                        withSiderail: T().bool,
                        blockAdId: T().string,
                        isTentpole: T().bool,
                        positionForAnalytics: T().string
                    },
                    defaultProps: {
                        seeMoreAttributes: null,
                        withRow: !1,
                        seeMoreLink: "",
                        analytics: !1,
                        title: null,
                        withSiderail: !1,
                        blockAdId: "",
                        isTentpole: !1,
                        positionForAnalytics: ""
                    }
                },
                I = t(83348),
                L = t.n(I);

            function B(e) {
                var s, t, l = e.articles,
                    _ = void 0 === l ? [] : l,
                    h = e.title,
                    y = e.seeMoreAttributes,
                    k = e.seeMoreLink,
                    x = e.withRow,
                    N = e.analytics,
                    g = e.withSiderail,
                    T = e.blockAdId,
                    b = e.positionForAnalytics,
                    f = e.isTentpole,
                    v = e.isLoading,
                    H = void 0 !== v && v,
                    S = (0, o.Z)(e, ["articles", "title", "seeMoreAttributes", "seeMoreLink", "withRow", "analytics", "withSiderail", "blockAdId", "positionForAnalytics", "isTentpole", "isLoading"]),
                    I = _[0],
                    B = _.slice(1, 4),
                    F = _.slice(4, 9),
                    R = x ? _.length : B.length + 1;
                return I ? H ? (0, a.jsx)(Z.Z, {}) : (0, a.jsx)("section", (0, r.Z)((0, i.Z)({
                    className: n()(L().newsBase),
                    "data-has-siderail": g
                }, S), {
                    children: (0, a.jsxs)(u.Z, {
                        className: L().newsContainer,
                        noPadding: !0,
                        children: [h && (0, a.jsxs)(d.Z, {
                            className: L().blockTitle,
                            children: [(0, a.jsx)("p", {
                                className: L().title,
                                children: h
                            }), T && (0, a.jsx)(m.Z, {
                                placementId: T,
                                type: "sponsor"
                            }), k && (0, a.jsx)(p.Z, (0, r.Z)((0, i.Z)({}, y), {
                                href: k,
                                text: "See More",
                                className: L().seeMore,
                                styled: !0,
                                isBlockTitle: !0
                            }))]
                        }), (0, a.jsxs)("div", {
                            className: L().hero,
                            children: [(0, a.jsx)("div", {
                                className: L().heroInner,
                                children: (0, a.jsx)(j, {
                                    runtime: I.videoDuration || (null === I || void 0 === I || null === (s = I.program) || void 0 === s ? void 0 : s.runtimeHours),
                                    type: I.type,
                                    title: I.title,
                                    shortTitle: I.shortTitle,
                                    subtitle: I.excerpt,
                                    category: null === (t = I.categoryPrimary) || void 0 === t ? void 0 : t.name,
                                    taxonomy: I.taxonomy,
                                    href: (0, c.Z)(I),
                                    img: I.featuredImage || I.img || I.image,
                                    featured: !0,
                                    analytics: N ? {
                                        id: I.id,
                                        index: 0,
                                        totalArticles: R,
                                        articleType: f ? "main" : "homepage",
                                        isVideo: "video" === I.type,
                                        collectionName: h,
                                        sectionPosition: b || "1",
                                        componentType: "top-story-module"
                                    } : {},
                                    className: L().heroTile,
                                    sponsor: I.sponsor,
                                    timestamp: I.timestamp
                                })
                            }), (0, a.jsx)("div", {
                                className: L().aside,
                                children: (0, a.jsx)(w.Z, {
                                    analytics: {
                                        totalArticles: R,
                                        articleType: "main",
                                        collectionName: h
                                    },
                                    articles: B,
                                    isTentpole: f,
                                    positionForAnalytics: b || "1"
                                })
                            })]
                        }), F.length > 0 && x && (0, a.jsx)("ul", {
                            className: L().list,
                            children: F.map((function(e, s) {
                                var t;
                                return (0, a.jsx)("li", {
                                    className: L().item,
                                    children: (0, a.jsx)(A.Z, {
                                        type: e.type,
                                        title: e.title,
                                        shortTitle: e.shortTitle,
                                        subtitle: e.excerpt,
                                        category: null === (t = e.categoryPrimary) || void 0 === t ? void 0 : t.name,
                                        taxonomy: e.taxonomy,
                                        href: (0, c.Z)(e),
                                        analytics: N && {
                                            id: e.id,
                                            totalArticles: _.length,
                                            index: s + 4,
                                            articleType: "bottom",
                                            sectionPosition: b || "1"
                                        },
                                        sponsor: e.sponsor,
                                        timestamp: e.timestamp
                                    })
                                }, e.nbaId || e.id)
                            }))
                        })]
                    })
                })) : null
            }
            B.propTypes = S.propTypes, B.defaultProps = S.defaultProps
        },
        28313: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return c
                }
            });
            var i = t(29815),
                r = t(85893),
                o = t(93967),
                a = t.n(o),
                l = t(36629),
                n = t.n(l);

            function c() {
                return (0, r.jsxs)("div", {
                    className: n().sk,
                    children: [(0, r.jsxs)("div", {
                        className: n().skTop,
                        children: [(0, r.jsxs)("div", {
                            className: n().skFeature,
                            children: [(0, r.jsx)("div", {
                                className: n().skFeatureImage
                            }), (0, r.jsxs)("div", {
                                className: n().skFeatureMain,
                                children: [(0, r.jsx)("div", {
                                    className: a()(n().skFeatureBlurb, n().skFeatureBlurbLeft)
                                }), (0, r.jsx)("div", {
                                    className: a()(n().skFeatureBlurb, n().skFeatureBlurbRight)
                                })]
                            })]
                        }), (0, r.jsx)("div", {
                            className: n().skAside,
                            children: (0, i.Z)(Array(3)).map((function(e, s) {
                                return (0, r.jsxs)("div", {
                                    className: n().skAsideItem,
                                    children: [(0, r.jsx)("div", {
                                        className: n().skThumbNail
                                    }), (0, r.jsxs)("div", {
                                        className: n().skAsideItemElements,
                                        children: [(0, r.jsx)("div", {
                                            className: a()(n().skText, n().skHeadline)
                                        }), (0, r.jsx)("div", {
                                            className: a()(n().skText, n().skBlurb)
                                        }), (0, r.jsx)("div", {
                                            className: a()(n().skText, n().skBlurb2)
                                        }), (0, r.jsx)("div", {
                                            className: a()(n().skText, n().skSource)
                                        })]
                                    })]
                                }, s)
                            }))
                        })]
                    }), (0, r.jsx)("div", {
                        className: n().skBot,
                        children: (0, i.Z)(Array(5)).map((function(e, s) {
                            return (0, r.jsxs)("div", {
                                className: n().skItem,
                                children: [(0, r.jsx)("div", {
                                    className: a()(n().skText, n().skArticle, n().skHeadline)
                                }), (0, r.jsx)("div", {
                                    className: a()(n().skText, n().skArticle, n().skBlurb)
                                })]
                            }, s)
                        }))
                    })]
                })
            }
        },
        95226: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return k
                }
            });
            var i = t(26042),
                r = t(69396),
                o = t(85893),
                a = t(93967),
                l = t.n(a),
                n = t(29740),
                c = t(72887),
                d = t(77226),
                m = t(45697),
                p = t.n(m),
                u = t(38799),
                _ = {
                    propTypes: {
                        articles: p().arrayOf(u.c7).isRequired,
                        className: p().string,
                        analytics: p().shape({
                            articleType: p().string,
                            totalArticles: p().number
                        }),
                        hideImg: p().bool,
                        isTentpole: p().bool,
                        positionForAnalytics: p().string,
                        isWatchPlaylist: p().bool,
                        activeVideo: p().string,
                        isClientSideRouting: p().bool
                    },
                    defaultProps: {
                        className: "",
                        analytics: {},
                        hideImg: !1,
                        isTentpole: !1,
                        positionForAnalytics: "",
                        isWatchPlaylist: !1,
                        activeVideo: ""
                    }
                },
                h = t(39516),
                y = t.n(h);

            function k(e) {
                var s = e.articles,
                    t = e.className,
                    a = e.analytics,
                    m = e.hideImg,
                    p = e.isTentpole,
                    u = e.positionForAnalytics,
                    _ = e.isWatchPlaylist,
                    h = e.activeVideo,
                    k = e.isClientSideRouting,
                    x = _ ? y().video : y().rabArticle;
                if ((0, d.yD)(s)) return null;
                var N = s.map((function(e, s) {
                    var d, N = e || {};
                    return (0, o.jsx)("li", {
                        className: l()(y().rabItem, t),
                        children: (0, o.jsx)(n.Z, {
                            isWatchPlaylist: _,
                            className: x,
                            type: N.type,
                            title: N.title,
                            shortTitle: N.shortTitle,
                            subtitle: N.excerpt,
                            activeVideo: h,
                            programId: N.mediakindExternalProgramId,
                            category: null === (d = N.categoryPrimary) || void 0 === d ? void 0 : d.name,
                            isLive: N.isLive,
                            href: (0, c.Z)(N),
                            img: m ? null : N.featuredImage || N.image,
                            imgSize: "featured",
                            timestamp: N.timestamp,
                            taxonomy: N.taxonomy,
                            runtime: N.videoDuration,
                            subfeatured: !0,
                            isClientSideRouting: k,
                            analytics: a && (0, r.Z)((0, i.Z)({}, a), {
                                id: N.id,
                                index: s + 1,
                                articleType: p ? "main" : "homepage",
                                isVideo: "video" === N.type,
                                sectionPosition: u,
                                componentType: "top-story-module"
                            }),
                            sponsor: N.sponsor
                        })
                    }, N.id)
                }));
                return (0, o.jsx)("ul", {
                    className: y().rab,
                    children: N
                })
            }
            k.propTypes = _.propTypes, k.defaultProps = _.defaultProps
        },
        364: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return N
                }
            });
            var i = t(26042),
                r = t(69396),
                o = t(85893),
                a = t(93967),
                l = t.n(a),
                n = t(41684),
                c = t(37346),
                d = t(34180),
                m = t(29717),
                p = t(18919),
                u = t(93529),
                _ = t(45697),
                h = t.n(_),
                y = {
                    propTypes: {
                        analytics: h().shape({
                            articleType: h().oneOf(["main", "side", "bottom", "latest", "latestSide", "collection"]).isRequired,
                            collectionName: h().string,
                            id: h().oneOfType([h().string, h().number]),
                            index: h().number,
                            totalArticles: h().number
                        }).isRequired,
                        as: h().string,
                        category: h().string,
                        taxonomy: h().object,
                        href: h().string.isRequired,
                        subtitle: h().string,
                        title: h().string.isRequired,
                        shortTitle: h().string,
                        type: h().oneOf(["post", "video", "podcast", "nbabet"]).isRequired,
                        sponsor: h().oneOfType([h().shape({
                            sponsorUrl: h().string,
                            sponsorLogoUrl: h().string,
                            sponsorName: h().string
                        }), h().bool]),
                        timestamp: h().oneOfType([h().string, h().number])
                    },
                    defaultProps: {
                        as: "",
                        category: "",
                        taxonomy: {},
                        subtitle: "",
                        shortTitle: "",
                        sponsor: !1,
                        timestamp: ""
                    }
                },
                k = t(49824),
                x = t.n(k);

            function N(e) {
                var s = e.as,
                    t = e.subtitle,
                    a = e.title,
                    _ = e.shortTitle,
                    h = e.href,
                    y = e.category,
                    k = e.taxonomy,
                    N = e.type,
                    g = e.analytics,
                    T = e.timestamp,
                    b = e.sponsor,
                    f = (0, m.Z)((0, r.Z)((0, i.Z)({}, g), {
                        title: a,
                        sponsor: b,
                        category: y,
                        taxonomy: k
                    })),
                    v = (0, p.Z)(N).isPodcast,
                    j = (0, p.e)(g),
                    w = b || {},
                    A = w.sponsorName,
                    Z = w.sponsorLogoUrl,
                    H = w.sponsorUrl,
                    S = !!(Z && H && A),
                    I = (0, d.k)(T);
                return (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)(n.Z, (0, r.Z)((0, i.Z)({}, f), {
                        title: "Article link for ".concat(a),
                        href: h,
                        as: s,
                        className: l()(x().rat, s),
                        "data-show-sponser": S,
                        children: (0, o.jsx)("article", {
                            children: (0, o.jsx)("div", {
                                className: x().article,
                                children: (0, o.jsx)("div", {
                                    className: x().inner,
                                    children: (0, o.jsxs)("header", {
                                        "data-type": "headline",
                                        children: [(y && j || v) && (0, o.jsx)("h4", {
                                            is: "h4",
                                            className: x().category,
                                            children: v ? "podcast" : y
                                        }), (0, o.jsx)(c.Z, {
                                            is: "h3",
                                            text: _ || a,
                                            className: x().shortTitle,
                                            maxLines: 2
                                        }), t && (0, o.jsx)(c.Z, {
                                            is: "p",
                                            className: x().subtitle,
                                            text: t,
                                            maxLines: 2
                                        }), T && !S && (0, o.jsx)("div", {
                                            className: x().noSponser,
                                            children: (0, o.jsx)("span", {
                                                className: x().timestamp,
                                                children: I
                                            })
                                        })]
                                    })
                                })
                            })
                        })
                    })), T && S && (0, o.jsxs)("div", {
                        className: x().sponser,
                        children: [(0, o.jsx)("span", {
                            className: x().timestamp,
                            children: I
                        }), (0, o.jsx)(u.Z, {
                            sponsor: b,
                            analytics: (0, i.Z)({}, g, {
                                title: a,
                                section: g.collectionName
                            })
                        })]
                    })]
                })
            }
            N.propTypes = y.propTypes, N.defaultProps = y.defaultProps
        },
        72887: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            var i = t(77226);

            function r(e) {
                if (e.permalink) return e.permalink;
                if (!e.type && e.slug) return e.slug;
                switch (e.type) {
                    case "post":
                    case "event":
                        return "/news/".concat(e.slug);
                    case "video":
                        var s = new URL(e.link),
                            t = !(0, i.Qr)(Object.fromEntries(s.searchParams)) ? "?".concat(s.searchParams) : "";
                        return "".concat(s.pathname).concat(t);
                    case "page":
                        return e.slug;
                    case "hyperlink":
                        return e.url;
                    case "podcast":
                        return "/podcast/".concat(e.slug);
                    default:
                        return "/"
                }
            }
        },
        4713: function(e) {
            e.exports = {
                base: "BlockTitle_base__TF_Zm"
            }
        },
        83348: function(e) {
            e.exports = {
                newsBase: "NewsHero_newsBase__wENDX",
                blockTitle: "NewsHero_blockTitle__2Xdn5",
                newsContainer: "NewsHero_newsContainer__mxh7G",
                aside: "NewsHero_aside__k7byp",
                hero: "NewsHero_hero__W5tfB",
                heroInner: "NewsHero_heroInner__Kj4Ua",
                heroTile: "NewsHero_heroTile__zIIgA",
                list: "NewsHero_list__l7EUw",
                item: "NewsHero_item__W4BTN",
                seeMore: "NewsHero_seeMore__tuqIm",
                title: "NewsHero_title__i0E99"
            }
        },
        36629: function(e) {
            e.exports = {
                sk: "NewsHeroSkeletonLoader_sk__6KI7s",
                skTop: "NewsHeroSkeletonLoader_skTop__a0uVm",
                skBot: "NewsHeroSkeletonLoader_skBot__ZtasE",
                skFeature: "NewsHeroSkeletonLoader_skFeature__7QZtJ",
                skFeatureMain: "NewsHeroSkeletonLoader_skFeatureMain__hzH7l",
                skItem: "NewsHeroSkeletonLoader_skItem__P8A_f",
                skFeatureBlurbLeft: "NewsHeroSkeletonLoader_skFeatureBlurbLeft__wBWFN",
                skFeatureBlurbRight: "NewsHeroSkeletonLoader_skFeatureBlurbRight__0j28B",
                skAside: "NewsHeroSkeletonLoader_skAside__onXjy",
                skAsideItem: "NewsHeroSkeletonLoader_skAsideItem__T3p9Z",
                skAsideItemElements: "NewsHeroSkeletonLoader_skAsideItemElements__1IQv4",
                skFeatureImage: "NewsHeroSkeletonLoader_skFeatureImage__6Nbbq",
                skFeatureBlurb: "NewsHeroSkeletonLoader_skFeatureBlurb__6mcBQ",
                skThumbNail: "NewsHeroSkeletonLoader_skThumbNail__8vOF1",
                skText: "NewsHeroSkeletonLoader_skText__CdQIy",
                skHeadline: "NewsHeroSkeletonLoader_skHeadline__Xc3nT",
                skBlurb: "NewsHeroSkeletonLoader_skBlurb__ijo_Q",
                skBlurb2: "NewsHeroSkeletonLoader_skBlurb2__7LJS6",
                skSource: "NewsHeroSkeletonLoader_skSource__wm9lO",
                skArticle: "NewsHeroSkeletonLoader_skArticle___D8ow"
            }
        },
        39516: function(e) {
            e.exports = {
                rab: "RelatedArticleBlock_rab__Uxqzk",
                rabItem: "RelatedArticleBlock_rabItem__jhzhF",
                video: "RelatedArticleBlock_video__ausLg"
            }
        },
        70886: function(e) {
            e.exports = {
                link: "HeroArticleTile_link__dpISn",
                article: "HeroArticleTile_article__g_eA2",
                videoContent: "HeroArticleTile_videoContent__JV_om",
                videoThumb: "HeroArticleTile_videoThumb__6yGxN",
                timestampBlock: "HeroArticleTile_timestampBlock__pHrhA",
                timestampSponser: "HeroArticleTile_timestampSponser__KSdj6",
                timestamp: "HeroArticleTile_timestamp__2W3ch",
                title: "HeroArticleTile_title__Z_U5M",
                subtitle: "HeroArticleTile_subtitle__tvFki",
                category: "HeroArticleTile_category__bfwU0",
                summary: "HeroArticleTile_summary__hN09a",
                summaryInner: "HeroArticleTile_summaryInner__n18GE"
            }
        },
        49824: function(e) {
            e.exports = {
                rat: "RowArticleTile_rat__dEezz",
                timestamp: "RowArticleTile_timestamp__Tdoab",
                sponser: "RowArticleTile_sponser__uihki",
                noSponser: "RowArticleTile_noSponser__wlTf9",
                subtitle: "RowArticleTile_subtitle__L2ROx",
                shortTitle: "RowArticleTile_shortTitle__ONkur",
                category: "RowArticleTile_category__4PO3Z",
                inner: "RowArticleTile_inner__b0HV2",
                article: "RowArticleTile_article__XI7_I"
            }
        }
    }
]);