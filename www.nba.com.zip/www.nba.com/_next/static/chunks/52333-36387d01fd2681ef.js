(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [52333], {
        11750: function(e, a, s) {
            "use strict";
            s.d(a, {
                oe: function() {
                    return m
                },
                dv: function() {
                    return u
                },
                O6: function() {
                    return p
                }
            });
            var r = s(85893),
                t = s(93967),
                i = s.n(t),
                o = s(45697),
                c = s.n(o),
                n = {
                    children: c().node.isRequired,
                    className: c().string
                },
                d = s(74744),
                l = s.n(d);

            function m(e) {
                var a = e.children,
                    s = e.className;
                return (0, r.jsx)("div", {
                    className: i()(l().col, s),
                    children: a
                })
            }

            function u(e) {
                var a = e.children,
                    s = e.className;
                return (0, r.jsx)("div", {
                    className: i()(l().left, s),
                    children: a
                })
            }

            function p(e) {
                var a = e.children,
                    s = e.className;
                return (0, r.jsx)("div", {
                    className: i()(l().right, s),
                    children: a
                })
            }
            m.propTypes = n, u.propTypes = n, p.propTypes = n
        },
        85298: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return Y
                }
            });
            var r = s(14924),
                t = s(26042),
                i = s(69396),
                o = s(99534),
                c = s(85893),
                n = s(67294),
                d = s(93967),
                l = s.n(d),
                m = s(77226),
                u = s(92033),
                p = s(47347),
                h = s(29221),
                f = s(6771),
                _ = s(45697),
                g = s.n(_),
                N = s(916),
                x = {
                    propTypes: {
                        team: N.QN,
                        hideScores: g().bool,
                        isFavorite: g().bool,
                        isAway: g().bool,
                        isHome: g().bool,
                        className: g().string
                    },
                    defaultProps: {
                        hideScores: !1,
                        isFavorite: !1,
                        isAway: !1,
                        isHome: !1,
                        className: null
                    }
                },
                T = s(57366),
                v = s.n(T);

            function S(e) {
                var a = e.team,
                    s = e.isFavorite,
                    r = e.isAway,
                    t = e.isHome,
                    i = e.hideScores,
                    o = e.className,
                    n = a || {},
                    d = n.seed,
                    m = void 0 === d ? null : d,
                    u = n.specialInfoPrefix,
                    p = void 0 === u ? null : u,
                    h = n.teamName,
                    _ = n.teamId,
                    g = Number(m) || Number(p) || 0,
                    N = !i && g > 0,
                    x = h || "TBD";
                return (0, c.jsxs)("div", {
                    className: l()(v().base, o),
                    "data-team-id": _,
                    children: [N && (0, c.jsx)("span", {
                        className: v().seed,
                        children: g
                    }), (0, c.jsx)("span", {
                        className: v().teamName,
                        children: x
                    }), s && (0, c.jsx)("span", {
                        className: v().favorite,
                        "data-is-home": t,
                        "data-is-away": r,
                        children: (0, c.jsx)(f.Z, {
                            title: "Follow Team Star Symbol",
                            style: {
                                height: 9,
                                width: 9
                            }
                        })
                    })]
                })
            }
            S.propTypes = x.propTypes, S.defaultProps = x.defaultProps;
            var C = {
                    propTypes: {
                        team: N.QN.isRequired,
                        hideScores: g().bool
                    },
                    defaultProps: {
                        hideScores: !1
                    }
                },
                b = s(81508),
                y = s.n(b);

            function j(e) {
                var a = e.team,
                    s = e.hideScores,
                    r = e.isPriorityFieldSubTitle,
                    t = a || {},
                    i = t.teamSubtitle,
                    o = void 0 === i ? "" : i,
                    d = t.losses,
                    l = t.wins,
                    m = (0, n.useMemo)((function() {
                        var e = l && d ? "".concat(l, "-").concat(d) : "";
                        return s ? "-" : o || e ? r ? o || e : e || o : ""
                    }), [o, l, d, s, r]);
                return (0, c.jsx)("p", {
                    className: y().record,
                    children: m
                })
            }
            j.propTypes = C.propTypes, j.defaultProps = C.defaultProps;
            var M = s(19167),
                Z = s(48517),
                G = s(10253),
                P = s(83940),
                D = s(61318),
                w = s.n(D);

            function R(e) {
                var a = e.isPreseason,
                    s = e.gameStatus,
                    r = e.gameStatusText,
                    t = e.hideScores,
                    i = void 0 !== t && t,
                    o = e.gameState,
                    n = e.localizedTime;
                if (!s) return null;
                var d = (0, G.Z)((0, m.uM)(s), 3),
                    l = d[1],
                    u = d[2],
                    p = o === P.Z.PreGame,
                    h = o === P.Z.Scheduled,
                    f = o === P.Z.OpponentTBD,
                    _ = h || f;
                return (0, c.jsxs)("div", {
                    className: w().gcs,
                    "data-is-preseason": a,
                    "data-game-status": s,
                    children: [p && !l && (0, c.jsx)("p", {
                        "data-testid": "game-status",
                        "data-is-live": p,
                        className: w().gcsText,
                        children: "PREGAME"
                    }), l && !u && (0, c.jsx)("p", {
                        "data-testid": "game-status",
                        "data-is-live": "true",
                        className: w().gcsText,
                        children: i ? "LIVE" : r
                    }), !l && !p && u && (0, c.jsx)("p", {
                        "data-testid": "game-status",
                        "data-is-live": "false",
                        className: w().gcsText,
                        children: i ? "FINAL" : r
                    }), !l && !p && !u && (0, c.jsx)("p", {
                        "data-testid": "game-status",
                        "data-is-live": "false",
                        className: w().gcsText,
                        children: _ ? n : r
                    })]
                })
            }
            var W = s(28249),
                E = {
                    propTypes: {
                        seriesConference: g().string,
                        seriesDescription: g().string,
                        seriesGameNumber: g().string,
                        className: g().string
                    },
                    defaultProps: {
                        seriesConference: null,
                        seriesDescription: null,
                        seriesGameNumber: "",
                        className: null
                    }
                },
                B = s(61627),
                F = s.n(B);

            function L(e) {
                var a = e.seriesConference,
                    s = e.seriesDescription,
                    r = e.seriesGameNumber,
                    t = e.className,
                    i = "string" === typeof a && (null === a || void 0 === a ? void 0 : a.length) > 0,
                    o = "string" === typeof s && (null === s || void 0 === s ? void 0 : s.length) > 0,
                    n = r && (0, c.jsx)("span", {
                        className: F().seriesGameNumberWithDot,
                        children: r
                    });
                return o || r ? !i && o ? (0, c.jsxs)("p", {
                    className: t,
                    children: [(0, c.jsx)("span", {
                        children: s
                    }), n]
                }) : i || o || !r ? (0, c.jsxs)("p", {
                    className: t,
                    children: [(0, c.jsx)("span", {
                        children: a
                    }), (0, c.jsxs)("span", {
                        children: [" - ", s]
                    }), n]
                }) : (0, c.jsx)("p", {
                    className: t,
                    children: (0, c.jsx)("span", {
                        children: r
                    })
                }) : null
            }
            L.propTypes = E.propTypes, L.defaultProps = E.defaultProps;
            var I = s(9083),
                k = s(89327),
                z = s.n(k),
                A = {
                    propTypes: {
                        as: g().string,
                        game: N.ZP.isRequired,
                        className: g().string,
                        hideScores: g().bool,
                        hideNames: g().bool,
                        hideRecords: g().bool,
                        withDate: g().bool
                    },
                    defaultProps: {
                        as: "div",
                        className: null,
                        hideScores: !1,
                        hideNames: !1,
                        hideRecords: !1,
                        withDate: !1
                    }
                },
                O = s(49507);

            function q(e) {
                var a = e.as,
                    s = e.game,
                    d = e.className,
                    f = (e.hideNames, e.hideRecords, e.hideScores),
                    _ = e.withDate,
                    g = (0, o.Z)(e, ["as", "game", "className", "hideNames", "hideRecords", "hideScores", "withDate"]),
                    N = s || {},
                    x = N.gameStatusText,
                    T = N.gameStatus,
                    v = N.gameState,
                    C = N.gameId,
                    b = N.info,
                    y = N.subInfo,
                    G = N.seriesGameNumber,
                    D = N.seriesText,
                    w = N.ifNecessary,
                    E = N.cardHat,
                    B = N.seriesConference,
                    F = N.poRoundDesc,
                    k = N.gameTimeUtc,
                    A = (0, I.Z)(k, "EEE MMM d", "EEE d MMM"),
                    q = A.localizedTime,
                    Y = A.localizedDate,
                    H = A.timeZoneShort,
                    X = A.localizedDay,
                    Q = "TBD" === x,
                    U = q && !Q ? "".concat(q, " ").concat(H) : x,
                    V = (0, u.Z)(["homeTeam"], s, {}) || {},
                    K = (0, u.Z)(["awayTeam"], s, {}) || {},
                    J = (0, m.rT)(C) || {},
                    $ = J.isPre,
                    ee = J.isAllstar,
                    ae = J.isPlayoffs,
                    se = J.Season,
                    re = J.seasonyear,
                    te = T === O.Z.Upcoming,
                    ie = T === O.Z.Final,
                    oe = (0, n.useContext)(W.S).nbaProfile,
                    ce = (0, u.Z)(["favoriteTeams"], oe, []),
                    ne = (0, u.Z)(["teamId"], K, ""),
                    de = (0, u.Z)(["teamId"], V, ""),
                    le = (0, u.Z)(["score"], K, 0),
                    me = (0, u.Z)(["score"], V, 0),
                    ue = void 0 !== ce.find((function(e) {
                        return e.followed && Number(e.teamId) === Number(ne)
                    })),
                    pe = void 0 !== ce.find((function(e) {
                        return e.followed && Number(e.teamId) === Number(de)
                    })),
                    he = ie && le > me,
                    fe = ie && !he,
                    _e = (0, n.useMemo)((function() {
                        return function(e) {
                            var a = e.gameState,
                                s = e.withDate,
                                r = e.isPregame,
                                t = e.localizedDay,
                                i = e.isGameTBD,
                                o = a === P.Z.Forfeited,
                                c = a === P.Z.Postponed;
                            return !(!(s && r && t) || i || o || c)
                        }({
                            gameState: v,
                            withDate: _,
                            isPregame: te,
                            localizedDay: X,
                            isGameTBD: Q
                        })
                    }), [v, _, te, X, Q]),
                    ge = !!E || !!F || !!b || !!G,
                    Ne = !!b || !(!G && !ee) || !!y || !!D;
                return (0, c.jsxs)(a, (0, i.Z)((0, t.Z)({}, g), {
                    className: l()(d, z().gameCardMatchup),
                    children: [ge && (0, c.jsx)(L, {
                        className: z().gamePlayoffRoundText,
                        seriesConference: B || null,
                        seriesDescription: F || E,
                        seriesGameNumber: b || G
                    }), (0, c.jsxs)("div", {
                        className: z().wrapper,
                        children: [(0, c.jsxs)("article", {
                            className: z().article,
                            children: [(0, c.jsx)(h.Z, {
                                teamId: ne,
                                season: se,
                                seasonYear: re,
                                className: z().matchupCardTeamLogo
                            }), (0, c.jsx)(S, {
                                team: K,
                                isFavorite: ue,
                                hideScores: f,
                                isAway: !0
                            }), !(ae || ee) && (0, c.jsx)(j, {
                                team: K,
                                hideScores: f,
                                isPriorityFieldSubTitle: !0
                            })]
                        }), (0, c.jsxs)("div", {
                            className: z().statusWrapper,
                            children: [!te && (0, c.jsx)("div", {
                                className: z().matchupScoreCardWrapper,
                                children: (0, c.jsx)(M.Z, {
                                    score: le,
                                    hideScores: f,
                                    className: l()(z().matchupScoreCard, (0, r.Z)({}, z().scoreLoser, fe))
                                })
                            }), (0, c.jsxs)("div", {
                                className: z().gameCardMatchupStatusWrapper,
                                children: [(0, c.jsxs)("div", {
                                    children: [_e && (0, c.jsx)("p", {
                                        className: z().gcmDate,
                                        children: Y
                                    }), (0, c.jsx)(R, {
                                        isPreseason: $,
                                        gameStatus: T,
                                        gameStatusText: x,
                                        hideScores: f,
                                        gameState: v,
                                        localizedTime: U
                                    })]
                                }), !te && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(p.Z, {
                                        className: l()(z().awayWin, (0, r.Z)({}, z().won, he && !f))
                                    }), (0, c.jsx)(p.Z, {
                                        dir: "right",
                                        className: l()(z().homeWin, (0, r.Z)({}, z().won, fe && !f))
                                    })]
                                })]
                            }), !te && (0, c.jsx)("div", {
                                className: z().matchScorecardAlignRight,
                                children: (0, c.jsx)(M.Z, {
                                    score: me,
                                    hideScores: f,
                                    className: l()(z().matchupScoreCard, (0, r.Z)({}, z().scoreLoser, he))
                                })
                            })]
                        }), (0, c.jsxs)("article", {
                            className: z().article,
                            children: [(0, c.jsx)(h.Z, {
                                teamId: de,
                                season: se,
                                seasonYear: re,
                                className: z().matchupCardTeamLogo
                            }), (0, c.jsx)(S, {
                                team: V,
                                isFavorite: pe,
                                hideScores: f,
                                isHome: !0
                            }), !(ae || ee) && (0, c.jsx)(j, {
                                team: V,
                                hideScores: f,
                                isPriorityFieldSubTitle: !0
                            })]
                        })]
                    }), Ne && (0, c.jsx)(Z.Z, {
                        className: z().gameSeriesText,
                        seriesGameNumber: b || G,
                        seriesText: y || D,
                        ifNecessary: D ? w : null,
                        hideScores: f,
                        shouldShowOnlySeriesText: !0
                    })]
                }))
            }
            q.propTypes = A.propTypes, q.defaultProps = A.defaultProps;
            var Y = q
        },
        1416: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return u
                }
            });
            var r = s(85893),
                t = s(67294),
                i = s(93967),
                o = s.n(i),
                c = s(45697),
                n = s.n(c),
                d = {
                    isLoading: n().bool.isRequired,
                    delay: n().number,
                    fadeOut: n().bool,
                    children: n().node,
                    fadeDuration: n().number
                },
                l = s(28075),
                m = s.n(l);

            function u(e) {
                var a = e.className,
                    s = e.isLoading,
                    i = e.delay,
                    c = e.fadeOut,
                    n = e.children,
                    d = e.fadeDuration,
                    l = void 0 === d ? 100 : d,
                    u = e.relative,
                    p = void 0 !== u && u,
                    h = (0, t.useState)(!0),
                    f = h[0],
                    _ = h[1],
                    g = (0, t.useState)(!1),
                    N = g[0],
                    x = g[1],
                    T = {
                        transitionDuration: "".concat(l, "ms")
                    };
                return (0, t.useEffect)((function() {
                    var e, a;
                    return !0 === s ? i ? e = setTimeout((function() {
                            _(!1)
                        }), i) : _(!1) : (clearTimeout(e), c ? (x(!0), a = setTimeout((function() {
                            x(!1), _(!0)
                        }), l)) : _(!0)),
                        function() {
                            clearTimeout(e), clearTimeout(a)
                        }
                }), [s, i, c]), (0, r.jsx)("div", {
                    className: o()(m().loader, a),
                    "data-is-fading": N,
                    "data-hidden": f,
                    "data-relative": p,
                    style: T,
                    children: n
                })
            }
            u.propTypes = d
        },
        19167: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return u
                }
            });
            var r = s(85893),
                t = s(93967),
                i = s.n(t),
                o = s(77226),
                c = s(45697),
                n = s.n(c),
                d = {
                    score: n().number.isRequired,
                    className: n().string,
                    children: n().node,
                    hideScores: n().bool,
                    gameStatus: n().oneOf(["1", "2", "3", 1, 2, 3])
                },
                l = s(95823),
                m = s.n(l);

            function u(e) {
                var a = e.score,
                    s = e.className,
                    t = e.children,
                    c = e.hideScores,
                    n = void 0 !== c && c,
                    d = e.gameStatus;
                return n ? null : (0, o.sk)() && +d < 3 ? (0, r.jsx)("p", {
                    className: i()(m().p, s),
                    children: "--"
                }) : (0, r.jsxs)("p", {
                    className: i()(m().p, s),
                    children: [a, t]
                })
            }
            u.propTypes = d
        },
        29221: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return p
                }
            });
            var r = s(85893),
                t = s(93967),
                i = s.n(t),
                o = s(64324),
                c = s(44762),
                n = s(45697),
                d = s.n(n),
                l = {
                    propTypes: {
                        teamId: d().oneOfType([d().string, d().number]),
                        logoType: d().string,
                        season: d().string,
                        seasonYear: d().number,
                        className: d().string
                    },
                    defaultProps: {
                        logoType: null,
                        season: "",
                        seasonYear: 0,
                        className: null
                    }
                },
                m = s(16846),
                u = s.n(m);

            function p(e) {
                var a = e.teamId,
                    s = e.logoType,
                    t = e.season,
                    n = e.seasonYear,
                    d = e.className,
                    l = t && n && +n < o.lz.YearTo ? t : "";
                return (0, r.jsx)("figure", {
                    className: i()(u().base, d),
                    children: (0, r.jsx)(c.Z, {
                        tid: a,
                        alt: "",
                        logoType: s,
                        season: l
                    })
                })
            }
            p.propTypes = l.propTypes, p.defaultProps = l.defaultProps
        },
        52681: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return f
                }
            });
            var r = s(85893),
                t = s(67294),
                i = s(73935),
                o = s(47896),
                c = s(77226),
                n = s(34405),
                d = s(92033),
                l = s(45697),
                m = s.n(l),
                u = {
                    pageName: m().string.isRequired,
                    forceDisclaimer: m().bool
                },
                p = s(67605),
                h = s.n(p);

            function f(e) {
                var a = e.pageName,
                    s = e.forceDisclaimer,
                    l = void 0 !== s && s,
                    m = (0, t.useState)(0),
                    u = m[0],
                    p = m[1],
                    f = (0, t.useContext)(o.o),
                    _ = f.oddsExist,
                    g = f.hideOdds,
                    N = f.oddsConfig,
                    x = N || {},
                    T = x.disclaimer,
                    v = void 0 === T ? [] : T,
                    S = x.disclaimerLink,
                    C = {
                        backgroundColor: (0, d.Z)(["bannerBg"], N, ""),
                        borderColor: (0, d.Z)(["bannerBg"], N, ""),
                        color: (0, d.Z)(["bannerColor"], N, "")
                    };
                return (0, t.useEffect)((function() {
                    var e = setTimeout((function() {
                        u + 1 < v.length ? p(u + 1) : p(0)
                    }), 6e4);
                    return function() {
                        return clearTimeout(e)
                    }
                }), [u, v.length]), (_ || l) && v.length ? g && !l || (0, c.sk)() ? null : (0, r.jsx)(r.Fragment, {
                    children: (0, i.createPortal)((0, r.jsx)("div", {
                        className: h().oddsDisclaimer,
                        style: C,
                        children: (0, r.jsx)(n.Z, {
                            disabled: !S,
                            href: S,
                            "data-track": "click",
                            "data-type": "cta",
                            "data-id": "nba:".concat(a, ":responsible-gambling:cta"),
                            children: (0, r.jsx)("p", {
                                children: v[u]
                            })
                        })
                    }), document.body)
                }) : null
            }
            f.propTypes = u
        },
        74744: function(e) {
            e.exports = {
                col: "Columns_col__wZTNG",
                left: "Columns_left__XkWXE",
                right: "Columns_right__RMqRd"
            }
        },
        89327: function(e) {
            e.exports = {
                team: "GameCardMatchup_team__vEn_V",
                logo: "GameCardMatchup_logo__cphnV",
                awayWin: "GameCardMatchup_awayWin__zD021",
                homeWin: "GameCardMatchup_homeWin__5E_iM",
                won: "GameCardMatchup_won__89eVM",
                date: "GameCardMatchup_date__ztCaS",
                gcmDate: "GameCardMatchup_gcmDate__fXKRQ",
                gameCardMatchup: "GameCardMatchup_gameCardMatchup__H0uPe",
                gamePlayoffRoundText: "GameCardMatchup_gamePlayoffRoundText__Sy2Tn",
                gameSeriesText: "GameCardMatchup_gameSeriesText__zqvUF",
                wrapper: "GameCardMatchup_wrapper__uUdW8",
                article: "GameCardMatchup_article__Fsvx9",
                matchupCardTeamLogo: "GameCardMatchup_matchupCardTeamLogo__ZqZXC",
                statusWrapper: "GameCardMatchup_statusWrapper__TDbQz",
                matchupScoreCardWrapper: "GameCardMatchup_matchupScoreCardWrapper__X50gw",
                matchupScoreCard: "GameCardMatchup_matchupScoreCard__owb6w",
                gameCardMatchupStatusWrapper: "GameCardMatchup_gameCardMatchupStatusWrapper__8rQ8v",
                showBroadcasters: "GameCardMatchup_showBroadcasters__B7lu2",
                matchScorecardAlignRight: "GameCardMatchup_matchScorecardAlignRight__n20ov",
                localAccessBroadcaster: "GameCardMatchup_localAccessBroadcaster__MM6ap",
                scoreLoser: "GameCardMatchup_scoreLoser__FLa7T"
            }
        },
        61318: function(e) {
            e.exports = {
                gcs: "GameCardMatchupStatusText_gcs__2yfjE",
                gcsText: "GameCardMatchupStatusText_gcsText__PcQUX",
                gcsBadge: "GameCardMatchupStatusText_gcsBadge__bWCRV"
            }
        },
        61627: function(e) {
            e.exports = {
                seriesGameNumberWithDot: "GameCardPlayoffRoundText_seriesGameNumberWithDot__aRVj_"
            }
        },
        28075: function(e) {
            e.exports = {
                loader: "LoadingOverlay_loader__iZ0Nm"
            }
        },
        95823: function(e) {
            e.exports = {
                p: "MatchupCardScore_p__dfNvc"
            }
        },
        16846: function(e) {
            e.exports = {
                base: "MatchupCardTeamLogo_base__WZl01"
            }
        },
        57366: function(e) {
            e.exports = {
                base: "MatchupCardTeamName_base__PBkuX",
                seed: "MatchupCardTeamName_seed__Bb84k",
                teamName: "MatchupCardTeamName_teamName__9YaBA",
                favorite: "MatchupCardTeamName_favorite__jS7zU"
            }
        },
        81508: function(e) {
            e.exports = {
                record: "MatchupCardTeamRecord_record__20YHe"
            }
        },
        67605: function(e) {
            e.exports = {
                oddsDisclaimer: "OddsDisclaimer_oddsDisclaimer__Msnbb"
            }
        }
    }
]);