(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [20592], {
        20606: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return h
                }
            });
            var n = t(14924),
                s = t(26042),
                r = t(69396),
                o = t(99534),
                i = t(85893),
                c = t(93967),
                d = t.n(c),
                l = t(41684),
                u = t(38800),
                m = t(72302),
                p = t(37346),
                f = t(70321),
                y = t.n(f);

            function h(e) {
                var a = e.as,
                    t = void 0 === a ? "section" : a,
                    c = e.children,
                    f = e.className,
                    h = e.title,
                    x = e.titleLogo,
                    b = void 0 === x ? "" : x,
                    v = e.titleLink,
                    k = e.titleButton,
                    g = e.titleClass,
                    T = void 0 === g ? "" : g,
                    Z = e.titleAs,
                    _ = void 0 === Z ? "h1" : Z,
                    C = e.titleWithLogo,
                    j = e.header,
                    N = e.footer,
                    w = e.blockAd,
                    O = e.domAdId,
                    L = e.padding,
                    P = e.searchBlock,
                    B = e.hasCarousel,
                    I = void 0 !== B && B,
                    E = e.blockTitleLeft,
                    A = void 0 !== E && E,
                    R = e.hasCompanionAd,
                    S = void 0 !== R && R,
                    D = e.hasNestedBlocks,
                    V = void 0 !== D && D,
                    z = e.isNestedBlock,
                    H = void 0 !== z && z,
                    G = e.isSchedulePage,
                    M = void 0 !== G && G,
                    U = e.isBlockBorderHidden,
                    W = void 0 !== U && U,
                    q = (0, o.Z)(e, ["as", "children", "className", "title", "titleLogo", "titleLink", "titleButton", "titleClass", "titleAs", "titleWithLogo", "header", "footer", "blockAd", "domAdId", "padding", "searchBlock", "hasCarousel", "blockTitleLeft", "hasCompanionAd", "hasNestedBlocks", "isNestedBlock", "isSchedulePage", "isBlockBorderHidden"]),
                    Y = !L && !I,
                    F = !!(w || v || k || P || S),
                    J = !!h,
                    K = !!C,
                    Q = !b || K,
                    X = w && (w.placementId || w),
                    $ = "string" === typeof h && h.toLowerCase().includes("draft board");
                return (0, i.jsxs)(t, (0, r.Z)((0, s.Z)({
                    className: d()(y().block, f),
                    "data-has-container": Y,
                    "data-has-carousel": I,
                    "data-has-logo": K,
                    "data-has-ad-container": F,
                    "data-has-title": J,
                    "data-has-nested-blocks": V,
                    "data-is-nested-block": H
                }, q), {
                    children: [j, (0, i.jsxs)("div", {
                        className: d()(y().blockContent, L),
                        children: [h && (0, i.jsxs)("div", {
                            "data-is-block-border-hidden": W,
                            className: d()((0, n.Z)({}, y().titleContainerBetween, !A), (0, n.Z)({}, y().titleContainerLeft, A)),
                            children: [Q && (0, i.jsxs)("div", {
                                className: y().flexAd,
                                children: [(0, i.jsx)(p.Z, {
                                    is: _,
                                    className: d()(y().blockTitleText, T),
                                    children: h
                                }), M && (0, i.jsx)(u.Z, {
                                    className: y().inlineAd,
                                    singleton: "ad_ns_atf_01",
                                    domId: O,
                                    type: "sponsor",
                                    isSchedulePage: !0,
                                    overrideWebview: !0
                                })]
                            }), b && (0, i.jsx)("img", {
                                src: b,
                                alt: h,
                                className: y().blockTitleLogo
                            }), K && C, F && (0, i.jsxs)("div", {
                                className: y().blockAd,
                                children: [S && X && (0, i.jsx)(m.Z, {
                                    children: (0, i.jsx)(u.Z, {
                                        type: "sponsor",
                                        placementId: X,
                                        domId: O,
                                        lazyLoad: !0
                                    })
                                }), X && !S && (0, i.jsx)(u.Z, {
                                    type: "sponsor",
                                    placementId: X,
                                    domId: O,
                                    lazyLoad: !0,
                                    overrideWebview: $
                                }), v && (0, i.jsx)(l.Z, (0, r.Z)((0, s.Z)({}, v), {
                                    className: y().blockTitleLink,
                                    isBlockTitle: !0
                                })), k && (0, i.jsx)("button", {
                                    type: "button",
                                    onClick: k.onClick,
                                    className: y().blockButton,
                                    children: k.text
                                }), P && P]
                            })]
                        }), c]
                    }), N]
                }))
            }
        },
        18958: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return s
                }
            });
            var n = t(26042);

            function s(e, a) {
                return (0, n.Z)({
                    "data-track": "click",
                    "data-type": e.analyticsType,
                    "data-id": e.analyticsId ? "".concat(e.analyticsId, ":").concat(e.analyticsType) : void 0,
                    "data-text": a,
                    "data-content-type": "packages",
                    "data-section": e.analyticsSection
                }, e.analyticsExtraProps)
            }
        },
        99295: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return l
                }
            });
            var n = t(26042),
                s = t(69396),
                r = t(85893),
                o = t(43612),
                i = t(18958),
                c = t(43002),
                d = t(41684);

            function l(e) {
                var a = e.broadcasterName,
                    t = e.children,
                    l = e.analytics,
                    u = void 0 === l ? c.m_ : l,
                    m = e.broadcasterLink,
                    p = void 0 === m ? "" : m,
                    f = e.isPrioritizeLink,
                    y = e.disableLink;
                if (!t) return null;
                var h = o.Z[a];
                if (y || (!h || !(null === h || void 0 === h ? void 0 : h.link)) && !p) return t;
                var x = (0, i.Z)(u, a),
                    b = f ? p || (null === h || void 0 === h ? void 0 : h.link) : (null === h || void 0 === h ? void 0 : h.link) || p;
                return (0, r.jsx)(d.Z, (0, s.Z)((0, n.Z)({
                    href: b
                }, x), {
                    children: t
                }))
            }
        },
        61050: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return y
                }
            });
            var n = t(26042),
                s = t(69396),
                r = t(85893),
                o = t(67294),
                i = t(93967),
                c = t.n(i),
                d = t(41684),
                l = t(45697),
                u = t.n(l),
                m = {
                    radioBroadcaster: u().shape({
                        broadcasterDisplayName: u().string,
                        broadcasterDisplay: u().string,
                        broadcastDisplay: u().string,
                        broadcasterVideoLink: u().string
                    })
                },
                p = t(34774),
                f = t.n(p);

            function y(e) {
                var a = e.className,
                    t = e.linkAnalyticsObject,
                    i = e.radioBroadcaster,
                    l = i.broadcasterDisplayName,
                    u = i.broadcasterDisplay,
                    m = i.broadcastDisplay,
                    p = i.broadcasterVideoLink,
                    y = (0, o.useMemo)((function() {
                        return l || u || m
                    }), [l, u, m]),
                    h = t ? (0, s.Z)((0, n.Z)({}, t), {
                        "data-text": y
                    }) : {};
                if (!y) return null;
                var x = (0, r.jsx)("span", {
                    className: c()(f().radioText, a),
                    children: y
                });
                return p ? (0, r.jsx)(d.Z, (0, n.Z)({
                    href: p,
                    text: y,
                    className: c()(f().radioText, a)
                }, h)) : x
            }
            y.propTypes = m
        },
        48517: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return s
                }
            });
            var n = t(85893);

            function s(e) {
                var a = e.seriesText,
                    t = e.seriesGameNumber,
                    s = e.ifNecessary,
                    r = e.hideScores,
                    o = e.shouldShowOnlySeriesText,
                    i = void 0 !== o && o,
                    c = e.className,
                    d = e.gameSubLabel,
                    l = "If Necessary",
                    u = !!a && !r,
                    m = !!t;
                return i && u && !d ? (0, n.jsx)("p", {
                    className: c,
                    children: (0, n.jsx)("span", {
                        children: a
                    })
                }) : s ? d ? (0, n.jsx)("p", {
                    className: c,
                    children: (0, n.jsxs)("span", {
                        children: [d, ": ", l]
                    })
                }) : (0, n.jsx)("p", {
                    className: c,
                    children: (0, n.jsxs)("span", {
                        children: [t ? "".concat(t, ": ") : "", l]
                    })
                }) : d ? (0, n.jsx)("p", {
                    className: c,
                    children: (0, n.jsxs)("span", {
                        children: [d, u ? ": ".concat(a) : ""]
                    })
                }) : !m || u || i ? !m || !u && i ? null : (0, n.jsx)("p", {
                    className: c,
                    children: (0, n.jsxs)("span", {
                        children: [t, ": ", a]
                    })
                }) : (0, n.jsx)("p", {
                    className: c,
                    children: (0, n.jsx)("span", {
                        children: t
                    })
                })
            }
        },
        47347: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return l
                }
            });
            var n, s = t(26042),
                r = t(99534),
                o = t(85893),
                i = t(67294);

            function c() {
                return c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var a = 1; a < arguments.length; a++) {
                        var t = arguments[a];
                        for (var n in t)({}).hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }
                    return e
                }, c.apply(null, arguments)
            }
            var d = e => i.createElement("svg", c({
                xmlns: "http://www.w3.org/2000/svg",
                width: 7,
                height: 12,
                viewBox: "0 0 7 12"
            }, e), n || (n = i.createElement("path", {
                fill: "currentColor",
                fillRule: "nonzero",
                d: "M.5 6l6 5.5V.5z"
            })));

            function l(e) {
                var a = e.alt,
                    t = e.className,
                    n = e.role,
                    i = void 0 === n ? "presentation" : n,
                    c = e.style,
                    l = e.title,
                    u = e.dir,
                    m = void 0 === u ? "left" : u,
                    p = (0, r.Z)(e, ["alt", "className", "role", "style", "title", "dir"]);
                return (0, o.jsx)(d, (0, s.Z)({
                    alt: a,
                    className: t,
                    "data-no-icon": m,
                    role: i,
                    style: c,
                    title: l
                }, p))
            }
        },
        28867: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return l
                }
            });
            var n, s = t(26042),
                r = t(99534),
                o = t(85893),
                i = t(67294);

            function c() {
                return c = Object.assign ? Object.assign.bind() : function(e) {
                    for (var a = 1; a < arguments.length; a++) {
                        var t = arguments[a];
                        for (var n in t)({}).hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }
                    return e
                }, c.apply(null, arguments)
            }
            var d = e => i.createElement("svg", c({
                width: 12,
                height: 12,
                viewBox: "0 0 12 12",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
            }, e), n || (n = i.createElement("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M7 2.5H8.79297L4.64648 6.64648L5.35359 7.35359L9.5 3.20718V5V6H10.5V1.5H6V2.5H7ZM4.5 4H2V10H8V7.5H7V9H3V5H4.5V4Z",
                fill: "currentColor"
            })));

            function l(e) {
                var a = e.alt,
                    t = e.className,
                    n = e.role,
                    i = void 0 === n ? "presentation" : n,
                    c = e.style,
                    l = e.title,
                    u = void 0 === l ? "Deeplink icon" : l,
                    m = (0, r.Z)(e, ["alt", "className", "role", "style", "title"]);
                return (0, o.jsx)(d, (0, s.Z)({
                    alt: a,
                    className: t,
                    "data-no-icon": !0,
                    role: i,
                    style: c,
                    title: u
                }, m))
            }
        },
        18377: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return c
                }
            });
            var n = t(85893),
                s = t(93967),
                r = t.n(s),
                o = t(1805),
                i = t.n(o);

            function c(e) {
                var a = e.className,
                    t = e.large,
                    s = void 0 !== t && t,
                    o = e.defaultText,
                    c = void 0 === o ? "LIVE" : o;
                return (0, n.jsx)("span", {
                    className: r()(i().lb, a),
                    "data-large": s,
                    children: c
                })
            }
        },
        75294: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return y
                }
            });
            var n = t(26042),
                s = t(69396),
                r = t(99534),
                o = t(85893),
                i = t(93967),
                c = t.n(i),
                d = t(41684),
                l = t(45697),
                u = t.n(l),
                m = {
                    propTypes: {
                        href: u().string.isRequired,
                        children: u().node.isRequired,
                        className: u().string,
                        analytics: u().shape({})
                    },
                    defaultProps: {
                        className: null,
                        analytics: {}
                    }
                },
                p = t(1269),
                f = t.n(p);

            function y(e) {
                var a = e.href,
                    t = e.children,
                    i = e.className,
                    l = e.analytics,
                    u = (0, r.Z)(e, ["href", "children", "className", "analytics"]);
                return (0, o.jsx)("li", (0, s.Z)((0, n.Z)({
                    className: c()(f().tab, i)
                }, u), {
                    children: (0, o.jsx)(d.Z, (0, s.Z)((0, n.Z)({
                        className: f().link,
                        href: a
                    }, l), {
                        children: t
                    }))
                }))
            }
            y.propTypes = m.propTypes, y.defaultProps = m.defaultProps
        },
        29070: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return d
                }
            });
            var n = t(85893),
                s = t(45697),
                r = t.n(s),
                o = {
                    propTypes: {
                        children: r().node.isRequired,
                        hideBorder: r().bool,
                        hasRoundedCTAs: r().bool
                    },
                    defaultProps: {
                        hideBorder: !1
                    }
                },
                i = t(28281),
                c = t.n(i);

            function d(e) {
                var a = e.children,
                    t = e.hideBorder,
                    s = e.hasRoundedCTAs,
                    r = void 0 !== s && s;
                return (0, n.jsx)("ul", {
                    className: c().tab,
                    "data-show-border": !t,
                    "data-has-rounded-ctas": r,
                    children: a
                })
            }
            d.propTypes = o.propTypes, d.defaultProps = o.defaultProps
        },
        53174: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return V
                }
            });
            var n, s = t(26042),
                r = t(69396),
                o = t(10253),
                i = t(85893),
                c = t(67294),
                d = t(11163),
                l = t(77226),
                u = t(9849),
                m = t(45697),
                p = t.n(m),
                f = t(67724),
                y = function(e, a, t, n, s, r) {
                    return {
                        "data-track": "click",
                        "data-type": "cta",
                        "data-id": n ? "".concat(n, ":").concat(e, ":cta") : "".concat(e, ":cta"),
                        "data-text": a,
                        "data-content": t,
                        "data-content-id": s,
                        "data-section": r
                    }
                },
                h = function(e) {
                    var a = e.matchupString,
                        t = e.gameIdObject,
                        n = e.awayTeam,
                        s = e.homeTeam,
                        r = e.analyticsId,
                        o = e.section;
                    try {
                        var i = t.st,
                            c = t.seasonyear,
                            d = t.GameID,
                            l = {
                                watch: y("watch", "WATCH", a, r, d, o),
                                boxscore: y("box-score", "BOX SCORE", a, r, d, o),
                                gameDetails: y("game-details", "GAME DETAILS", a, r, d, o),
                                preview: y("preview", "PREVIEW", a, r, d, o),
                                gameCharts: y("game-charts", "GAME CHARTS", a, r, d, o),
                                tickets: y("tickets", "TICKETS", a, r, d, o),
                                watchParty: y("watch-party", "WATCH PARTY", a, r, d),
                                gameRecapTracking: y("game-recap", "GAME RECAP", a, r, d)
                            };
                        if (4 === i && c >= f.ZP.playoffHubSeasonMinYear) {
                            var u = t.conference,
                                m = t.round,
                                p = n.seed < s.seed,
                                h = p ? n : s,
                                x = p ? s : n,
                                b = "4".concat(c, " ").concat(u, " ").concat(m, ": [").concat(h.seed, "] ").concat(h.teamTricode, " vs [").concat(x.seed, "] ").concat(x.teamTricode);
                            l.playoffHubTracking = y("view-playoffs-series", "VIEW SERIES", b, r)
                        }
                        return l
                    } catch (v) {
                        return {}
                    }
                },
                x = t(91567),
                b = t(21059),
                v = t(66738),
                k = t(36924),
                g = t(46866),
                T = t(75788),
                Z = t(36617),
                _ = t(92033),
                C = t(52454),
                j = t(2504),
                N = t(21259),
                w = t(54141),
                O = t(43002),
                L = t(916),
                P = t(62624),
                B = t(75294),
                I = t(29070),
                E = t(99534);

            function A() {
                return A = Object.assign ? Object.assign.bind() : function(e) {
                    for (var a = 1; a < arguments.length; a++) {
                        var t = arguments[a];
                        for (var n in t)({}).hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }
                    return e
                }, A.apply(null, arguments)
            }
            var R = e => c.createElement("svg", A({
                width: 17,
                height: 16,
                viewBox: "0 0 17 16",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
            }, e), n || (n = c.createElement("path", {
                d: "M13.3335 7.13398C14.0002 7.51888 14.0002 8.48113 13.3335 8.86603L6.3335 12.9075C5.66683 13.2924 4.8335 12.8113 4.8335 12.0415L4.8335 3.95855C4.8335 3.18875 5.66683 2.70763 6.3335 3.09253L13.3335 7.13398Z",
                fill: "black"
            })));

            function S(e) {
                var a = e.alt,
                    t = e.className,
                    n = e.role,
                    r = void 0 === n ? "presentation" : n,
                    o = e.style,
                    c = e.title,
                    d = (0, E.Z)(e, ["alt", "className", "role", "style", "title"]);
                return (0, i.jsx)(R, (0, s.Z)({
                    alt: a,
                    className: t,
                    "data-no-icon": !0,
                    role: r,
                    style: o,
                    title: c
                }, d))
            }

            function D(e) {
                var a = e.game,
                    t = e.placement,
                    n = e.analytics,
                    m = e.hasRoundedCTAs,
                    p = (0, d.useRouter)(),
                    y = a.gameStatus,
                    O = a.gameId,
                    L = a.gameEt,
                    E = a.gameTimeEastern,
                    A = (0, _.Z)(["homeTeam"], a, {}) || {},
                    R = (0, _.Z)(["awayTeam"], a, {}) || {},
                    D = L || E,
                    V = (0, _.Z)(["pathname"], p, "").split("/")[1],
                    z = (0, c.useContext)(b.aR).ESI,
                    H = void 0 === z ? {} : z,
                    G = H.isDomestic,
                    M = H.isMobile,
                    U = (0, c.useContext)(x.N),
                    W = U.global,
                    q = U.games,
                    Y = U.ticketLinkOrigin,
                    F = W.hideTicketLinks,
                    J = q.leaguePassArchiveRestrictionsDomestic,
                    K = q.leaguePassArchiveRestrictionsInternational,
                    Q = !1 === G ? K : J,
                    X = !(0, C.Z)(O, Q),
                    $ = (0, P.O)(a),
                    ee = (0, o.Z)((0, l.uM)(y), 3),
                    ae = ee[0],
                    te = ee[1],
                    ne = ee[2],
                    se = (0, l.rT)(O),
                    re = se.isAllstar,
                    oe = se.isPlayoffs,
                    ie = se.seasonyear,
                    ce = (0, w.e)({
                        awayTeamTricode: R.teamTricode,
                        homeTeamTricode: A.teamTricode,
                        gameEt: D
                    }),
                    de = "" === A.teamTricode || "" === R.teamTricode,
                    le = oe && ie >= f.ZP.playoffHubSeasonMinYear,
                    ue = n.analyticsId,
                    me = $ ? "?".concat(g.Z.CONDENSED_GAME) : (0, N.Z)(ne),
                    pe = h({
                        matchupString: ce,
                        gameIdObject: se,
                        awayTeam: R,
                        homeTeam: A,
                        analyticsId: ue,
                        section: V
                    }),
                    fe = pe.preview,
                    ye = pe.gameCharts,
                    he = pe.tickets,
                    xe = pe.playoffHubTracking,
                    be = pe.watchParty,
                    ve = pe.boxscore,
                    ke = pe.gameDetails,
                    ge = pe.gameRecapTracking,
                    Te = (0, u.bl)({
                        id: O,
                        title: ce,
                        pageName: V,
                        section: V,
                        isPremium: !0,
                        analyticsId: ue
                    }),
                    Ze = !re && !de,
                    _e = !F && !le,
                    Ce = f.zU && X,
                    je = (0, Z.Z)(O, R.teamTricode, A.teamTricode),
                    Ne = je + k.y.boxscore,
                    we = je + k.y.watchParty,
                    Oe = je + k.y.gamecharts,
                    Le = je + k.y.story,
                    Pe = le ? (0, j.Z)(se) : null,
                    Be = ae && t ? (0, T.Z)({
                        ticketLinkOrigin: Y,
                        seasonYear: ie,
                        gameId: O,
                        placement: t
                    }) : "";
                return M ? ae ? (0, i.jsxs)(I.Z, {
                    hasRoundedCTAs: m,
                    children: [(0, i.jsx)(B.Z, {
                        analytics: fe,
                        href: je,
                        children: "Preview"
                    }), Ze && !le && (0, i.jsx)(B.Z, {
                        analytics: ye,
                        href: Oe,
                        children: "Game charts"
                    }), le && (0, i.jsx)(B.Z, {
                        analytics: xe,
                        href: Pe,
                        children: "View series"
                    }), _e && (0, i.jsx)(B.Z, {
                        analytics: he,
                        href: Be,
                        rel: "noopener",
                        children: "Tickets"
                    })]
                }) : te ? (0, i.jsxs)(I.Z, {
                    hasRoundedCTAs: m,
                    children: [X && (0, i.jsxs)(B.Z, {
                        analytics: Te,
                        href: (0, Z.Z)(O, R.teamTricode, A.teamTricode, me),
                        children: [m && (0, i.jsx)(S, {}), "Watch"]
                    }), (0, i.jsx)(B.Z, {
                        analytics: ve,
                        href: Ne,
                        children: "Box score"
                    }), le && (0, i.jsx)(B.Z, {
                        analytics: xe,
                        href: Pe,
                        children: "View series"
                    })]
                }) : (0, i.jsxs)(I.Z, {
                    hasRoundedCTAs: m,
                    children: [X && (0, i.jsxs)(B.Z, {
                        analytics: Te,
                        href: (0, Z.Z)(O, R.teamTricode, A.teamTricode, me),
                        children: [m && (0, i.jsx)(S, {}), "Watch"]
                    }), !le && (0, i.jsx)(B.Z, {
                        analytics: ge,
                        href: Le,
                        children: "Game recap"
                    }), (0, i.jsx)(B.Z, {
                        analytics: ve,
                        href: Ne,
                        children: "Box score"
                    }), le && (0, i.jsx)(B.Z, {
                        analytics: xe,
                        href: Pe,
                        children: "View series"
                    })]
                }) : ae ? (0, i.jsxs)(I.Z, {
                    hasRoundedCTAs: m,
                    children: [(0, i.jsx)(B.Z, {
                        analytics: fe,
                        href: je,
                        children: "Preview"
                    }), Ce && (0, i.jsx)(B.Z, (0, r.Z)((0, s.Z)({
                        analytics: be,
                        href: we
                    }, v.c), {
                        children: "Watch party"
                    })), le && (0, i.jsx)(B.Z, {
                        analytics: xe,
                        href: Pe,
                        children: "View series"
                    }), _e && (0, i.jsx)(B.Z, {
                        analytics: he,
                        href: Be,
                        rel: "noopener",
                        children: "Tickets"
                    })]
                }) : te ? (0, i.jsxs)(I.Z, {
                    hasRoundedCTAs: m,
                    children: [X && (0, i.jsxs)(B.Z, {
                        analytics: Te,
                        href: (0, Z.Z)(O, R.teamTricode, A.teamTricode, me),
                        children: [m && (0, i.jsx)(S, {}), "Watch"]
                    }), Ce && !le && (0, i.jsx)(B.Z, (0, r.Z)((0, s.Z)({
                        analytics: be,
                        href: we
                    }, v.c), {
                        children: "Watch party"
                    })), (0, i.jsx)(B.Z, {
                        analytics: ve,
                        href: Ne,
                        children: "Box score"
                    }), le && (0, i.jsx)(B.Z, {
                        analytics: xe,
                        href: Pe,
                        children: "View series"
                    })]
                }) : (0, i.jsxs)(I.Z, {
                    hasRoundedCTAs: m,
                    children: [X && (0, i.jsxs)(B.Z, {
                        analytics: Te,
                        href: (0, Z.Z)(O, R.teamTricode, A.teamTricode, me),
                        children: [m && (0, i.jsx)(S, {}), "Watch"]
                    }), (0, i.jsx)(B.Z, {
                        analytics: ve,
                        href: Ne,
                        children: "Box score"
                    }), !le && (0, i.jsx)(B.Z, {
                        analytics: ke,
                        href: je,
                        children: "Game details"
                    }), le && (0, i.jsx)(B.Z, {
                        analytics: xe,
                        href: Pe,
                        children: "View series"
                    })]
                })
            }
            D.propTypes = {
                game: L.ZP.isRequired,
                placement: p().string,
                analytics: O.Z0,
                hasRoundedCTAs: p().bool
            }, D.defaultProps = {
                placement: null,
                analytics: O.m_
            };
            var V = D
        },
        72302: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return f
                }
            });
            var n = t(47568),
                s = t(34051),
                r = t.n(s),
                o = t(85893),
                i = t(67294),
                c = t(92033),
                d = t(84714),
                l = t(45697),
                u = t.n(l),
                m = function() {
                    var e = (0, n.Z)(r().mark((function e(a) {
                        return r().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, fetch(a);
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(a) {
                        return e.apply(this, arguments)
                    }
                }();

            function p(e) {
                var a = e.children,
                    t = (0, i.useState)(null),
                    n = t[0],
                    s = t[1],
                    r = (0, c.Z)(["trackingEvents", "0", "url"], n, null);
                if ((0, i.useEffect)((function() {
                        null === d.mkEventChannel || void 0 === d.mkEventChannel || d.mkEventChannel.on(d.EVENT_TYPES.AMC_COMPANION_AD, (function(e) {
                            s(null === e || void 0 === e ? void 0 : e[0])
                        }))
                    }), []), (0, i.useEffect)((function() {
                        r && m(r)
                    }), [n]), !n && !a) return null;
                if (!n && a) return a;
                var l = n.adSlotId,
                    u = n.clickThroughUrl,
                    p = n.height,
                    f = n.width,
                    y = n.resource,
                    h = n.id;
                return y ? (0, o.jsx)(o.Fragment, {
                    children: (0, o.jsx)("span", {
                        id: l,
                        className: "cp-ad-parent",
                        children: (0, o.jsx)("a", {
                            href: u,
                            id: h,
                            className: "cp-ad-anchor",
                            target: "_blank",
                            rel: "noreferrer",
                            children: (0, o.jsx)("img", {
                                height: p,
                                width: f,
                                src: y.url,
                                alt: "companion-ad",
                                className: "cp-ad-image"
                            })
                        })
                    })
                }) : null
            }
            p.propTypes = {
                children: u().oneOfType([u().node, u().bool])
            }, p.defaultProps = {
                children: !1
            };
            var f = p
        },
        29391: function(e, a) {
            "use strict";
            a.Z = [{
                country: "AU",
                oddsDataProviderCountry: "AU",
                market: "2way",
                name: "tabaustralia",
                sponsorNames: ["tabaustralia"],
                sponsorText: "Odds by",
                prefixOddsText: "$",
                suffixOddsText: "",
                disclaimer: ["CHANCES ARE YOU\u2019RE ABOUT TO LOSE. Set a deposit limit."],
                disclaimerLink: "",
                oddsType: "odds"
            }, {
                country: "FR",
                oddsDataProviderCountry: "FR",
                market: "2way",
                name: "francepari3",
                sponsorNames: ["francepari3"],
                sponsorText: "cotes du match",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["Jouer comporte des risques : endettement, d\xe9pendance... Appelez le 09-74-75-13-13 (appel non surtax\xe9).", "Jouer comporte des risques : isolement, endettement... Appelez le 09-74-75-13-13 (appel non surtax\xe9).", "Jouer comporte des risques : d\xe9pendance, isolement... Appelez le 09-74-75-13-13 (appel non surtax\xe9)."],
                disclaimerLink: "https://www.joueurs-info-service.fr/",
                oddsType: "odds",
                themeColor: "#dedede"
            }, {
                country: "US",
                oddsDataProviderCountry: "US",
                market: "spread",
                name: "fanduel",
                sponsorNames: ["fanduel"],
                sponsorText: "Pregame Odds by",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["If you or someone you know has a gambling problem and wants help, call 1-800-GAMBLER"],
                disclaimerLink: "",
                oddsType: "spread"
            }, {
                country: "CA",
                region: "ON",
                oddsDataProviderCountry: "US",
                market: "spread",
                name: "fanduel",
                sponsorNames: ["fanduel", "igaming"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["19+ and physically located in Ontario. Gambling Problem? Call, 1-866-531-2600 or visit connexontario.ca"],
                disclaimerLink: "https://www.connexontario.ca/en-ca/",
                oddsType: "spread",
                themeColor: "#0078ff"
            }, {
                country: "CO",
                oddsDataProviderCountry: "CO",
                market: "2way",
                name: "betplay",
                sponsorNames: ["betplay"],
                sponsorText: "Probabilidades presentadas por",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["El juego es entretenimiento, juega con moderaci\xf3n"],
                disclaimerLink: "",
                oddsType: "odds"
            }, {
                country: "DE",
                oddsDataProviderCountry: "DE",
                market: "",
                name: "bildBet",
                sponsorNames: ["bildBet"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: [""],
                disclaimerLink: "",
                oddsType: "odds"
            }, {
                country: "UY",
                oddsDataProviderCountry: "UY",
                market: "2way",
                name: "supermatch",
                sponsorNames: ["supermatch"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["18+ Juegue responsablemente. Prevenci\xf3n y ayuda al juego patol\xf3gico: l\xednea de atenci\xf3n gratuita 0800-2000"],
                disclaimerLink: "",
                oddsType: "odds",
                bookmakerId: "sr:book:818",
                themeColor: "#dedede"
            }, {
                country: "EE",
                oddsDataProviderCountry: "EE",
                market: "2way",
                name: "olybet",
                sponsorNames: ["olybet"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["T\xe4helepanu! Tegemist on hasartm\xe4ngu reklaamiga. Hasartm\xe4ng pole sobiv viis rahaliste probleemide lahendamiseks. Tutvuge reeglitega ja k\xe4ituge vastutustundlikult"],
                disclaimerLink: "",
                oddsType: "odds",
                bookmakerId: 23879,
                themeColor: "#ed1c24",
                bannerBg: "#ed1c24",
                bannerColor: "#ffffff"
            }, {
                country: "RS",
                oddsDataProviderCountry: "RS",
                market: "spread",
                name: "mozzartBet",
                sponsorNames: ["mozzartBet"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["Zabranjeno je u\u010de\u0161\u0107e maloletnih lica u igrama na sre\u0107u. Igre na sre\u0107u mogu izazvati zavisnost. Igraj odgovorno."],
                disclaimerLink: "",
                oddsType: "spread",
                themeColor: "#3e2fa8",
                bookmakerId: "sr:book:5277"
            }, {
                country: "GR",
                oddsDataProviderCountry: "GR",
                market: "2way",
                name: "novibet",
                sponsorNames: ["novibet"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["21+ | \u03a0\u03b1\u03af\u03be\u03b5 \u03a5\u03c0\u03b5\u03cd\u03b8\u03c5\u03bd\u03b1"],
                disclaimerLink: "",
                oddsType: "odds",
                themeColor: "#212735",
                bookmakerId: "sr:book:6565"
            }, {
                country: "CY",
                oddsDataProviderCountry: "CY",
                market: "2way",
                name: "novibet",
                sponsorNames: ["novibet"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["21+ | \u03a0\u03b1\u03af\u03be\u03b5 \u03a5\u03c0\u03b5\u03cd\u03b8\u03c5\u03bd\u03b1"],
                disclaimerLink: "",
                oddsType: "odds",
                themeColor: "#212735",
                bookmakerId: "sr:book:6565"
            }, {
                country: "BR",
                oddsDataProviderCountry: "BR",
                market: "spread",
                name: "sportingbetBr",
                sponsorNames: ["sportingbetBr"],
                sponsorText: "",
                prefixOddsText: "",
                suffixOddsText: "",
                disclaimer: ["+18. Jogue com responsabilidade.  \ud83d\udea8 Se deixar de ser divers\xe3o, pare \u270b"],
                disclaimerLink: "",
                oddsType: "spread",
                themeColor: "#0e3450",
                bookmakerId: "sr:book:38812"
            }]
        },
        63087: function(e, a, t) {
            "use strict";
            t.d(a, {
                U: function() {
                    return b
                },
                Z: function() {
                    return v
                }
            });
            var n = t(10253),
                s = t(85893),
                r = t(77226),
                o = t(67294),
                i = t(93967),
                c = t.n(i),
                d = t(47896),
                l = t(92033),
                u = t(41684),
                m = t(29391),
                p = t(45697),
                f = t.n(p),
                y = {
                    gameId: f().string.isRequired,
                    gameStatus: f().number.isRequired,
                    homeTeamTricode: f().string.isRequired,
                    awayTeamTricode: f().string.isRequired,
                    className: f().string,
                    pageName: f().string.isRequired,
                    contentFor: f().string.isRequired
                },
                h = t(76458),
                x = t.n(h),
                b = function(e) {
                    var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "odds",
                        t = Boolean(e[a]),
                        n = t && "spread" === a,
                        s = t ? e[a] : e.odds,
                        o = n ? Number(s) : (0, r.OK)(s, 2);
                    return n && o > 0 ? "+".concat(o) : o
                };

            function v(e) {
                var a = e.gameId,
                    t = e.gameStatus,
                    i = e.homeTeamTricode,
                    p = e.awayTeamTricode,
                    f = e.className,
                    y = void 0 === f ? "" : f,
                    h = e.pageName,
                    v = e.contentFor,
                    k = (0, o.useContext)(d.o),
                    g = k.liveOdds,
                    T = void 0 === g ? [] : g,
                    Z = k.hideOdds,
                    _ = k.bookLogosSrc,
                    C = k.countryCode,
                    j = T.find((function(e) {
                        return e.gameId === a
                    })),
                    N = (0, l.Z)(["book", "outcomes", "length"], j, 0);
                if (!(!Z && a && i && p && t && 3 !== t && 2 === N)) return null;
                var w = j.book,
                    O = void 0 === w ? {} : w,
                    L = O.outcomes,
                    P = void 0 === L ? [] : L,
                    B = O.name,
                    I = O.url,
                    E = B.toLowerCase(),
                    A = (0, n.Z)(P, 2),
                    R = A[0],
                    S = A[1],
                    D = m.Z.find((function(e) {
                        var a = e || {},
                            t = a.name,
                            n = a.country;
                        return t && t.toLowerCase() === E && n && n.toLowerCase() === C.toLowerCase()
                    }));
                if (!D) return null;
                var V = D || {},
                    z = V.sponsorText,
                    H = V.sponsorNames,
                    G = V.prefixOddsText,
                    M = V.suffixOddsText,
                    U = V.oddsType,
                    W = void 0 === U ? "odds" : U,
                    q = b(R, W),
                    Y = b(S, W);
                return (0, s.jsx)(u.Z, {
                    href: I,
                    "data-track": "click",
                    "data-type": "cta",
                    "data-id": "nba:".concat(h, ":betting-odds:cta"),
                    "data-text": B,
                    "data-content": v,
                    children: (0, s.jsxs)("div", {
                        className: c()(x().oddsContainer, x()["book-".concat(E)], y),
                        children: [(0, s.jsxs)("div", {
                            className: x().oddsInfo,
                            children: [(0, s.jsxs)("div", {
                                className: x().oddsInfoTeam,
                                children: [(0, s.jsx)("p", {
                                    className: x().teamCode,
                                    children: p
                                }), (0, s.jsxs)("p", {
                                    className: x().oddsNumber,
                                    children: [G, Y, M]
                                })]
                            }), (0, s.jsxs)("div", {
                                className: x().oddsInfoTeam,
                                children: [(0, s.jsx)("p", {
                                    className: x().teamCode,
                                    children: i
                                }), (0, s.jsxs)("p", {
                                    className: x().oddsNumber,
                                    children: [G, q, M]
                                })]
                            })]
                        }), (0, s.jsxs)("div", {
                            className: x().sponsorInfo,
                            children: [(0, s.jsx)("p", {
                                className: x().sponsorText,
                                children: z
                            }), (0, r.yD)(_) ? null : _.map((function(e, a) {
                                if (!e) return null;
                                var t = (0, l.Z)(["".concat(a)], H, "");
                                return (0, s.jsx)("img", {
                                    className: x().sponsorLogo,
                                    title: t,
                                    alt: t,
                                    src: e
                                }, e)
                            }))]
                        })]
                    })
                })
            }
            v.propTypes = y
        },
        43002: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z0: function() {
                    return f
                },
                ZP: function() {
                    return m
                },
                m_: function() {
                    return y
                }
            });
            var n = t(51438),
                s = t(52951),
                r = t(88029),
                o = t(26042),
                i = t(91224),
                c = t(85893),
                d = t(67294),
                l = t(45697),
                u = t.n(l);

            function m(e) {
                var a = e.component,
                    t = e.primaryCategory,
                    l = e.secondaryCategory,
                    u = e.section,
                    m = e.extraProps,
                    f = e.type;
                return function(e) {
                    (0, r.Z)(y, e);
                    var d = (0, i.Z)(y);

                    function y(e) {
                        var a;
                        (0, n.Z)(this, y), a = d.call(this, e);
                        var s = ["nba", t, l].filter(p).join(":");
                        return a.state = {
                            analyticsPrimaryCategory: t,
                            analyticsSecondaryCategory: l,
                            analyticsId: s,
                            analyticsSection: u,
                            analyticsExtraProps: m,
                            analyticsType: f
                        }, a
                    }
                    return (0, s.Z)(y, [{
                        key: "componentDidMount",
                        value: function() {}
                    }, {
                        key: "componentWillUnmount",
                        value: function() {}
                    }, {
                        key: "render",
                        value: function() {
                            if (!a) return null;
                            var e = this.state,
                                t = e.analyticsPrimaryCategory,
                                n = e.analyticsSecondaryCategory,
                                s = e.analyticsId,
                                r = e.analyticsSection,
                                i = e.analyticsExtraProps,
                                d = e.analyticsType;
                            return (0, c.jsx)(a, (0, o.Z)({
                                analytics: {
                                    analyticsPrimaryCategory: t,
                                    analyticsSecondaryCategory: n,
                                    analyticsId: s,
                                    analyticsSection: r,
                                    analyticsExtraProps: i,
                                    analyticsType: d
                                }
                            }, this.props))
                        }
                    }]), y
                }(d.Component)
            }

            function p(e) {
                return "string" === typeof e && e.length > 0 || "number" === typeof e
            }
            var f = u().shape({
                    analyticsPrimaryCategory: u().string,
                    analyticsSecondaryCategory: u().string,
                    analyticsId: u().string,
                    analyticsSection: u().string,
                    analyticsExtraProps: u().shape({})
                }),
                y = {
                    analyticsPrimaryCategory: "",
                    analyticsSecondaryCategory: "",
                    analyticsId: "",
                    analyticsSection: "",
                    analyticsExtraProps: {}
                }
        },
        36924: function(e, a, t) {
            "use strict";
            t.d(a, {
                X: function() {
                    return n
                },
                y: function() {
                    return s
                }
            });
            var n = {
                    summary: {
                        id: "summary",
                        label: "Summary"
                    },
                    "box-score": {
                        id: "box-score",
                        label: "Box Score"
                    },
                    "game-charts": {
                        id: "game-charts",
                        label: "Game Charts"
                    },
                    "play-by-play": {
                        id: "play-by-play",
                        label: "Play-By-Play"
                    }
                },
                s = {
                    boxscore: "/box-score#box-score",
                    gamecharts: "/game-charts#game-charts",
                    playbyplay: "/play-by-play#play-by-play",
                    boxscoreTab: "/box-score",
                    gamechartsTab: "/game-charts",
                    playbyplayTab: "/play-by-play",
                    watch: "?watchFullGame",
                    listen: "?listen",
                    story: "#story",
                    watchParty: "?watchParty"
                }
        },
        66738: function(e, a, t) {
            "use strict";
            t.d(a, {
                c: function() {
                    return s
                }
            });
            var n = t(67724),
                s = (n.zU, n.zU ? {
                    "data-watch-party": 0
                } : {})
        },
        2504: function(e, a, t) {
            "use strict";

            function n(e) {
                var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                if (!e) return "/playoffs/";
                var t = e.round,
                    n = e.series,
                    s = e.seasonyear,
                    r = "/playoffs/".concat(s + 1);
                if (4 === t) return "".concat(r, "/the-finals").concat(a);
                if (3 === t) {
                    var o = 0 === n ? "east" : "west";
                    return "".concat(r, "/").concat(o, "-final").concat(a)
                }
                if (2 === t) {
                    var i = n < 2 ? "east" : "west",
                        c = "east" === i ? n + 1 : n - 1;
                    return "".concat(r, "/").concat(i, "-semifinal-").concat(c).concat(a)
                }
                if (1 === t) {
                    var d = n < 4 ? "east" : "west",
                        l = "east" === d ? n + 1 : n - 3;
                    return "".concat(r, "/").concat(d, "-first-round-").concat(l)
                }
                return "/playoffs/".concat(s).concat(a).toLowerCase()
            }
            t.d(a, {
                Z: function() {
                    return n
                }
            })
        },
        21259: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return s
                }
            });
            var n = t(46866);

            function s(e) {
                return "?".concat(e ? n.Z.FULL_GAME : n.Z.LIVE)
            }
        },
        75788: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return s
                }
            });
            var n = t(98698);

            function s(e) {
                var a = e.ticketLinkOrigin,
                    t = e.seasonYear,
                    s = e.gameId,
                    r = e.placement;
                return (0, n.Z)(s) ? "https://nbaevents.nba.com/summerleague" : a && t && s && r ? "".concat(a, "single/").concat(t, "/").concat(s, "/").concat(r) : "https://nbatickets.nba.com/"
            }
        },
        62624: function(e, a, t) {
            "use strict";
            t.d(a, {
                O: function() {
                    return o
                }
            });
            var n = t(77226),
                s = t(67724),
                r = t(28981);

            function o(e) {
                if (!e) return !1;
                var a = e.gameId,
                    t = (0, n.rT)(a).seasonyear,
                    o = s.ZP.seasonYear,
                    i = !1;
                try {
                    i = t < o
                } catch (c) {
                    (0, r.t)({
                        level: "error",
                        error: c
                    })
                }
                return i
            }
        },
        98698: function(e, a, t) {
            "use strict";

            function n(e) {
                if ("string" !== typeof e || !e || e.length < 2) return !1;
                var a = null === e || void 0 === e ? void 0 : e.slice(0, 2);
                return "13" === a || "14" === a || "15" === a || "16" === a
            }
            t.d(a, {
                Z: function() {
                    return n
                }
            })
        },
        52454: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return s
                }
            });
            var n = t(77226);

            function s(e, a) {
                return a > (0, n.rT)(e).seasonyear
            }
        },
        70321: function(e) {
            e.exports = {
                block: "Block_block__62M07",
                blockContent: "Block_blockContent__6iJ_n",
                titleContainerBetween: "Block_titleContainerBetween__0GYet",
                titleContainerLeft: "Block_titleContainerLeft__8gulQ",
                titleContainer: "Block_titleContainer__Hn0PI",
                blockAd: "Block_blockAd__1Q_77",
                blockTitleText: "Block_blockTitleText__tX1TF",
                blockTitleLink: "Block_blockTitleLink___pjNR",
                blockTitleLogo: "Block_blockTitleLogo__e0rzo",
                blockButton: "Block_blockButton__iAbLb",
                flexAd: "Block_flexAd__oXSF4",
                inlineAd: "Block_inlineAd__5s6Ec"
            }
        },
        34774: function(e) {
            e.exports = {
                radioText: "BroadcasterRadioLink_radioText__gPZ8o"
            }
        },
        1805: function(e) {
            e.exports = {
                lb: "LiveBadge_lb__qV_my"
            }
        },
        1269: function(e) {
            e.exports = {
                tab: "TabLink_tab__uKOPj",
                link: "TabLink_link__f_15h"
            }
        },
        28281: function(e) {
            e.exports = {
                tab: "Tabs_tab__rnewb"
            }
        },
        76458: function(e) {
            e.exports = {
                oddsContainer: "Odds_oddsContainer__eC7dG",
                "book-sportsbet": "Odds_book-sportsbet__2BQCp",
                "book-tabaustralia": "Odds_book-tabaustralia__uxdBL",
                "book-francepari3": "Odds_book-francepari3__ru0NY",
                "book-fanduel": "Odds_book-fanduel__LWgzm",
                "book-betplay": "Odds_book-betplay__tGgQF",
                "book-olybet": "Odds_book-olybet__hhOgR",
                "book-supermatch": "Odds_book-supermatch__rzxjE",
                "book-mozzartbet": "Odds_book-mozzartbet__6_d1H",
                "book-novibet": "Odds_book-novibet__8CJN7",
                "book-sportingbetbr": "Odds_book-sportingbetbr__ymmXG",
                oddsInfo: "Odds_oddsInfo__FvV4T",
                oddsInfoTeam: "Odds_oddsInfoTeam__f_lnU",
                teamCode: "Odds_teamCode__eBMCP",
                oddsNumber: "Odds_oddsNumber__LK6aQ",
                sponsorInfo: "Odds_sponsorInfo__VkKb5",
                sponsorText: "Odds_sponsorText__86n6r",
                sponsorLogo: "Odds_sponsorLogo__Fg4qL"
            }
        }
    }
]);