(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [60805], {
        61317: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return j
                }
            });
            var r = a(47568),
                s = a(26042),
                n = a(34051),
                i = a.n(n),
                c = a(14648),
                o = a(88513),
                l = {
                    0: "PlayoffPicture",
                    1: "PlayInBracket",
                    2: "PlayoffBracket",
                    3: "ISTBracket"
                },
                d = function() {
                    var e = (0, r.Z)(i().mark((function e(t) {
                        var a, r, s, n, c, d = arguments;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (a = d.length > 1 && void 0 !== d[1] ? d[1] : 0, t) {
                                        e.next = 3;
                                        break
                                    }
                                    return e.abrupt("return", {});
                                case 3:
                                    return r = "".concat(o.Sm, "/brackets/").concat(t, "/").concat(l[a], ".json"), e.next = 6, (0, o.aY)(r);
                                case 6:
                                    return s = e.sent, n = s.bracket, c = void 0 === n ? {} : n, e.abrupt("return", c);
                                case 10:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                h = d,
                x = a(67724),
                f = "playoffbracket",
                u = {
                    LeagueID: x.i8,
                    SeasonYear: 2020,
                    State: 0
                },
                g = function(e) {
                    return e.bracket || {}
                },
                m = function() {
                    return {}
                },
                p = function() {
                    var e = (0, r.Z)(i().mark((function e(t) {
                        var a, r, n, o, l, d, x = arguments;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (a = x.length > 1 && void 0 !== x[1] ? x[1] : 2020, n = (r = t || u).SeasonYear, o = r.State, !(Number(n) > a)) {
                                        e.next = 7;
                                        break
                                    }
                                    return e.next = 5, h(n, o);
                                case 5:
                                    return l = e.sent, e.abrupt("return", l);
                                case 7:
                                    return d = {
                                        resource: f,
                                        parse: function(e) {
                                            return e
                                        },
                                        transform: g,
                                        params: (0, s.Z)({}, u, t),
                                        fail: m
                                    }, e.abrupt("return", c.Z.get(d));
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                j = {
                    resource: f,
                    params: u,
                    transform: g,
                    get: p,
                    fail: m
                }
        },
        19665: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return ge
                }
            });
            var r = a(47568),
                s = a(26042),
                n = a(69396),
                i = a(34051),
                c = a.n(i),
                o = a(85893),
                l = a(67294),
                d = a(77837),
                h = a(61317),
                x = a(41226),
                f = a(77226),
                u = a(67724),
                g = a(91567),
                m = a(45697),
                p = a.n(m);

            function j(e) {
                var t = e.result;
                return (0, o.jsx)("svg", {
                    viewBox: "0 0 31 20",
                    height: "20",
                    width: "31",
                    children: (0, o.jsxs)("g", {
                        children: [(0, o.jsx)("rect", {
                            fill: "#000",
                            height: "20",
                            width: "20",
                            rx: "50"
                        }), (0, o.jsx)("text", {
                            transform: "translate(10, 15)",
                            textAnchor: "middle",
                            fill: "#FFFFFF",
                            fontFamily: "Roboto",
                            fontWeight: "800",
                            fontSize: "12px",
                            children: t
                        })]
                    })
                })
            }
            j.propTypes = {
                result: p().string
            };
            var k = a(10253),
                b = a(82858),
                y = function(e) {
                    if (!e || 0 === Object.keys(e).length) return "";
                    var t = e.highSeedRank,
                        a = e.highSeedTricode,
                        r = void 0 === a ? "TBD" : a,
                        s = e.lowSeedRank,
                        n = e.lowSeedTricode,
                        i = void 0 === n ? "TBD" : n;
                    return "[".concat(t, "] ").concat(r, " vs [").concat(s, "] ").concat(i)
                },
                v = function(e) {
                    var t = y(e),
                        a = function(e) {
                            if (!e || 0 === Object.keys(e).length) return "";
                            var t = e.seriesId,
                                a = void 0 === t ? "" : t,
                                r = e.conference,
                                s = void 0 === r ? "" : r,
                                n = e.seriesConference,
                                i = void 0 === n ? "" : n,
                                c = e.highSeedRank,
                                o = e.highSeedTricode,
                                l = void 0 === o ? "TBD" : o,
                                d = e.lowSeedRank,
                                h = e.lowSeedTricode,
                                x = void 0 === h ? "TBD" : h,
                                f = "";
                            if ("string" === typeof a && a.length) {
                                var u = (0, k.Z)(a.split("_"), 3),
                                    g = u[1],
                                    m = void 0 === g ? "" : g,
                                    p = u[2],
                                    j = void 0 === p ? 0 : p;
                                m && (f += "".concat(m, " ")), f += "".concat(s || i, " ").concat(j)
                            }
                            return c && "string" === typeof l && l.length && "TBD" !== l && d && "string" === typeof x && x.length && "TBD" !== x && ("string" === typeof a && a.length && (f += ": "), f += y(e)), f
                        }(e);
                    return e.link ? {
                        "data-track": "click",
                        "data-type": "card",
                        "data-id": "nba:playoffs:bracket:series:card",
                        "data-text": t,
                        "data-content": a
                    } : {}
                },
                w = a(36617);

            function S(e) {
                return e && "string" === typeof e ? "".concat("gametime://game/").concat(e) : "/games"
            }
            var _ = a(81990),
                N = a.n(_);

            function L(e) {
                var t = e.series,
                    a = void 0 === t ? {} : t,
                    r = e.low,
                    i = e.high,
                    c = e.swap,
                    d = void 0 !== c && c,
                    h = e.enableAnchor,
                    x = a.nextGameId,
                    f = a.lowSeedTricode,
                    m = a.highSeedTricode,
                    p = a.link,
                    j = a.matchupType,
                    y = (0, l.useContext)(g.N).isWebView,
                    _ = (0, b.Z)(),
                    L = (0, k.Z)(d ? [50, 0] : [0, 50], 2),
                    T = L[0],
                    B = L[1],
                    P = _.isDomestic ? "primary" : "global",
                    W = (0, l.useMemo)((function() {
                        var e = null === j || void 0 === j ? void 0 : j.includes("Play-In");
                        return f && m && h ? y ? S(x) : (0, w.Z)(x, f, m) : p && !e ? p : null
                    }), [f, m, h, x, p, j, y]);
                if (!a) return null;
                var I = W ? "a" : "g",
                    Z = v(a);
                return (0, o.jsx)(I, (0, n.Z)((0, s.Z)({
                    href: W,
                    className: N().bracketPlayinTile
                }, Z), {
                    children: (0, o.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 203 101",
                        height: "101",
                        width: "203",
                        children: [(0, o.jsx)("g", {
                            height: "101",
                            width: "203",
                            children: (0, o.jsx)("rect", {
                                x: "0",
                                y: "0",
                                width: "203",
                                height: "101",
                                className: N().matchupCardBackground,
                                strokeWidth: "1"
                            })
                        }), (0, o.jsx)("g", {
                            className: N().team,
                            "data-type": "htm",
                            transform: "translate(0, ".concat(T, ")"),
                            children: a.highSeedId ? (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("image", {
                                    transform: "translate(10, 10)",
                                    width: "30",
                                    height: "30",
                                    xlinkHref: "".concat(u.$, "/logos/nba/").concat(a.highSeedId, "/").concat(P, "/L/logo.svg")
                                }), (0, o.jsx)("text", {
                                    transform: "translate(58, 30)",
                                    textAnchor: "end",
                                    children: a.highSeedRank
                                }), (0, o.jsx)("text", {
                                    transform: "translate(65, 30)",
                                    children: a.highSeedName
                                }), (0, o.jsxs)("text", {
                                    transform: "translate(190, 30)",
                                    textAnchor: "end",
                                    fontWeight: "400",
                                    children: [a.highSeedRegSeasonWins, " - ", a.highSeedRegSeasonLosses]
                                })]
                            }) : (0, o.jsx)("text", {
                                transform: "translate(72, 30)",
                                className: N().team,
                                children: i
                            })
                        }), (0, o.jsx)("g", {
                            className: N().team,
                            "data-type": "vtm",
                            transform: "translate(0, ".concat(B, ")"),
                            children: a.lowSeedId ? (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("image", {
                                    transform: "translate(10, 10)",
                                    width: "30",
                                    height: "30",
                                    xlinkHref: "".concat(u.$, "/logos/nba/").concat(a.lowSeedId, "/").concat(P, "/L/logo.svg")
                                }), (0, o.jsx)("text", {
                                    transform: "translate(58, 30)",
                                    textAnchor: "end",
                                    children: a.lowSeedRank
                                }), (0, o.jsx)("text", {
                                    transform: "translate(65, 30)",
                                    children: a.lowSeedName
                                }), (0, o.jsxs)("text", {
                                    transform: "translate(190, 30)",
                                    textAnchor: "end",
                                    fontWeight: "400",
                                    children: [a.lowSeedRegSeasonWins, " - ", a.lowSeedRegSeasonLosses]
                                })]
                            }) : (0, o.jsx)("text", {
                                transform: "translate(72, 30)",
                                className: N().team,
                                children: r
                            })
                        }), (0, o.jsx)("g", {
                            className: N().stroke,
                            strokeWidth: "1",
                            strokeLinecap: "round",
                            children: (0, o.jsx)("line", {
                                x1: "0",
                                x2: "200",
                                y1: "49",
                                y2: "49"
                            })
                        })]
                    })
                }))
            }

            function T(e) {
                var t = e.bracket,
                    a = e.hideLinks,
                    r = e.bracketParagraph,
                    s = e.bracketTitle,
                    n = e.bracketLogoUrl,
                    i = void 0 === n ? "" : n,
                    c = e.ctaLabel,
                    d = e.ctaLink,
                    h = e.description,
                    x = e.enableAnchor,
                    f = (0, l.useContext)(g.N).isWebView;
                return t ? (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsxs)("svg", {
                        viewBox: "80 0 1110 620",
                        children: [(0, o.jsxs)("g", {
                            className: "bracket__background",
                            children: [(0, o.jsxs)("radialGradient", {
                                id: "bggd",
                                cx: "-12.171",
                                cy: "1255.9979",
                                r: "1.613",
                                gradientTransform: "matrix(668.1881 412.0066 412.0065 -668.1883 -508712.7812 844650.1875)",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, o.jsx)("stop", {
                                    offset: "0",
                                    stopColor: "#082B44"
                                }), (0, o.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#000000"
                                })]
                            }), (0, o.jsx)("rect", {
                                className: N().background,
                                width: "1268",
                                height: "800"
                            })]
                        }), (0, o.jsx)("g", {
                            className: "bracket__logo",
                            transform: "translate(522, 30)",
                            children: (0, o.jsx)("image", {
                                width: "240",
                                height: "60",
                                xlinkHref: i
                            })
                        }), h && (0, o.jsx)("g", {
                            className: N().bracketHeaderText,
                            fontFamily: "Roboto",
                            fontSize: "14",
                            children: (0, o.jsx)("text", {
                                transform: "translate(634, 109)",
                                fontSize: "16",
                                textAnchor: "middle",
                                children: h
                            })
                        }), (0, o.jsxs)("g", {
                            className: N().bracketText,
                            children: [(0, o.jsx)("text", {
                                transform: "translate(101, 50)",
                                children: "WEST"
                            }), (0, o.jsx)("text", {
                                transform: "translate(1115, 50)",
                                children: "EAST"
                            })]
                        }), (0, o.jsxs)("g", {
                            className: N().bracketPlayinText,
                            children: [(0, o.jsx)("text", {
                                transform: "translate(600, 150)",
                                children: "FIRST ROUND"
                            }), (0, o.jsx)("text", {
                                transform: "translate(250, 150)",
                                children: "PLAY-IN"
                            }), (0, o.jsx)("text", {
                                textAnchor: "end",
                                transform: "translate(1020, 150)",
                                children: "PLAY-IN"
                            })]
                        }), (0, o.jsxs)("g", {
                            className: "bracket__wpi",
                            fill: "#EA07E4",
                            transform: "translate(0, -50)",
                            children: [(0, o.jsx)("g", {
                                transform: "translate(103,285)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.pi910,
                                    enableAnchor: x
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(173,396)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.piLast,
                                    swap: !0,
                                    high: "Loser 7/8",
                                    low: "Winner 9/10",
                                    enableAnchor: x
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(103,507)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.pi78,
                                    enableAnchor: x
                                })
                            })]
                        }), (0, o.jsxs)("g", {
                            className: "bracket__epi",
                            fill: "#EA07E4",
                            transform: "translate(0, -50)",
                            children: [(0, o.jsx)("g", {
                                transform: "translate(962,285)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.pi910,
                                    enableAnchor: x
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(892,396)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.piLast,
                                    swap: !0,
                                    high: "Loser 7/8",
                                    low: "Winner 9/10",
                                    enableAnchor: x
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(962,507)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.pi78,
                                    enableAnchor: x
                                })
                            })]
                        }), (0, o.jsxs)("g", {
                            className: "bracket__er1",
                            transform: "translate(649, -50)",
                            children: [(0, o.jsx)("g", {
                                transform: "translate(0,229)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.rd[0],
                                    low: "8 Seed"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(0,342)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.rd[3]
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(0,451)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.rd[2]
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(0,562)",
                                children: (0, o.jsx)(L, {
                                    series: t.east.rd[1],
                                    low: "7 Seed"
                                })
                            })]
                        }), (0, o.jsxs)("g", {
                            className: "bracket__wr1",
                            transform: "translate(416, -50)",
                            children: [(0, o.jsx)("g", {
                                transform: "translate(0,229)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.rd[0],
                                    low: "8 Seed"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(0,342)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.rd[3]
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(0,451)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.rd[2]
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(0,562)",
                                children: (0, o.jsx)(L, {
                                    series: t.west.rd[1],
                                    low: "7 Seed"
                                })
                            })]
                        }), (0, o.jsxs)("g", {
                            className: N().bracketLines,
                            fill: "none",
                            strokeWidth: "1",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            transform: "translate(0, -50)",
                            children: [(0, o.jsx)("path", {
                                d: "M411.8,304l-8.6-8.8c-0.3-0.3-0.7-0.3-1,0c-0.3,0.3-0.3,0.8,0,1l8.1,8.2l-8.1,8.2c-0.3,0.3-0.3,0.8,0,1c0.1,0.1,0.3,0.2,0.5,0.2c0.2,0,0.4-0.1,0.5-0.2l8.6-8.8c0.1-0.1,0.2-0.3,0.2-0.5S411.9,304.1,411.8,304z"
                            }), (0, o.jsx)("path", {
                                d: "M856.2,304l8.6-8.8c0.3-0.3,0.7-0.3,1,0c0.3,0.3,0.3,0.8,0,1l-8.1,8.2l8.1,8.2c0.3,0.3,0.3,0.8,0,1c-0.1,0.1-0.3,0.2-0.5,0.2c-0.2,0-0.4-0.1-0.5-0.2l-8.6-8.8c-0.1-0.1-0.2-0.3-0.2-0.5S856.1,304.1,856.2,304z"
                            }), (0, o.jsx)("path", {
                                d: "M925.5,501.7l8.8,8.6c0.3,0.3,0.3,0.7,0,1c-0.3,0.3-0.8,0.3-1,0l-8.2-8.1l-8.2,8.1c-0.3,0.3-0.8,0.3-1,0c-0.1-0.1-0.2-0.3-0.2-0.5c0-0.2,0.1-0.4,0.2-0.5l8.8-8.6c0.1-0.1,0.3-0.2,0.5-0.2C925.2,501.5,925.4,501.6,925.5,501.7z"
                            }), (0, o.jsx)("path", {
                                d: "M919.5,391.3l8.8-8.6c0.3-0.3,0.3-0.7,0-1c-0.3-0.3-0.8-0.3-1,0l-8.2,8.1l-8.2-8.1c-0.3-0.3-0.8-0.3-1,0c-0.1,0.1-0.2,0.3-0.2,0.5c0,0.2,0.1,0.4,0.2,0.5l8.8,8.6c0.1,0.1,0.3,0.2,0.5,0.2C919.2,391.5,919.4,391.4,919.5,391.3z"
                            }), (0, o.jsx)("path", {
                                d: "M856.2,633l8.6,8.8c0.3,0.3,0.7,0.3,1,0c0.3-0.3,0.3-0.8,0-1l-8.1-8.2l8.1-8.2c0.3-0.3,0.3-0.8,0-1c-0.1-0.1-0.3-0.2-0.5-0.2c-0.2,0-0.4,0.1-0.5,0.2l-8.6,8.8c-0.1,0.1-0.2,0.3-0.2,0.5C856,632.7,856.1,632.9,856.2,633z"
                            }), (0, o.jsx)("path", {
                                d: "M342.5,501.7l-8.8,8.6c-0.3,0.3-0.3,0.7,0,1c0.3,0.3,0.8,0.3,1,0l8.2-8.1l8.2,8.1c0.3,0.3,0.8,0.3,1,0c0.1-0.1,0.2-0.3,0.2-0.5c0-0.2-0.1-0.4-0.2-0.5l-8.8-8.6c-0.1-0.1-0.3-0.2-0.5-0.2S342.6,501.6,342.5,501.7z"
                            }), (0, o.jsx)("path", {
                                d: "M348.5,391.3l-8.8-8.6c-0.3-0.3-0.3-0.7,0-1c0.3-0.3,0.8-0.3,1,0l8.2,8.1l8.2-8.1c0.3-0.3,0.8-0.3,1,0c0.1,0.1,0.2,0.3,0.2,0.5c0,0.2-0.1,0.4-0.2,0.5l-8.8,8.6c-0.1,0.1-0.3,0.2-0.5,0.2S348.6,391.4,348.5,391.3z"
                            }), (0, o.jsx)("path", {
                                d: "M411.8,633l-8.6,8.8c-0.3,0.3-0.7,0.3-1,0c-0.3-0.3-0.3-0.8,0-1l8.1-8.2l-8.1-8.2c-0.3-0.3-0.3-0.8,0-1c0.1-0.1,0.3-0.2,0.5-0.2c0.2,0,0.4,0.1,0.5,0.2l8.6,8.8c0.1,0.1,0.2,0.3,0.2,0.5C412,632.7,411.9,632.9,411.8,633z"
                            }), (0, o.jsx)("polyline", {
                                points: "411,304 393.7,304 393.7,447 381,447"
                            }), (0, o.jsx)("polyline", {
                                points: "857,304 874.3,304 874.3,447 887,447"
                            }), (0, o.jsx)("polyline", {
                                points: "957,553 925,553 925,504"
                            }), (0, o.jsx)("polyline", {
                                points: "957,335 919,335 919,390"
                            }), (0, o.jsx)("polyline", {
                                points: "858,632 925,632 925,561.2 957,561"
                            }), (0, o.jsx)("polyline", {
                                points: "311,553 343,553 343,504"
                            }), (0, o.jsx)("polyline", {
                                points: "311,335 349,335 349,390"
                            }), (0, o.jsx)("polyline", {
                                points: "410,632 343,632 343,561.2 311,561"
                            })]
                        }), (0, o.jsxs)("g", {
                            className: "bracket__results",
                            transform: "translate(0, -50)",
                            children: [(0, o.jsx)("g", {
                                transform: "translate(338,349)",
                                children: (0, o.jsx)(j, {
                                    result: "W",
                                    conf: "West"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(383,358)",
                                children: (0, o.jsx)(j, {
                                    result: "W",
                                    conf: "West"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(332,586)",
                                children: (0, o.jsx)(j, {
                                    result: "W",
                                    conf: "West"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(332,519)",
                                children: (0, o.jsx)(j, {
                                    result: "L",
                                    conf: "West"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(908,349)",
                                children: (0, o.jsx)(j, {
                                    result: "W",
                                    conf: "East"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(864,358)",
                                children: (0, o.jsx)(j, {
                                    result: "W",
                                    conf: "East"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(914,586)",
                                children: (0, o.jsx)(j, {
                                    result: "W",
                                    conf: "East"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(914,519)",
                                children: (0, o.jsx)(j, {
                                    result: "L",
                                    conf: "East"
                                })
                            })]
                        })]
                    }), (0, o.jsx)("div", {
                        className: N().bracketFooterText,
                        children: (0, o.jsxs)("div", {
                            className: N().bracketParagraphContainer,
                            children: [(0, o.jsx)("text", {
                                className: N().bracketParagraphTitle,
                                children: s
                            }), (0, o.jsx)("text", {
                                className: N().bracketParagraph,
                                children: r
                            }), !(a || f || !c || !d) && (0, o.jsx)("a", {
                                href: d,
                                "data-track": "click",
                                "data-type": "link",
                                "data-id": "nba:playoffs:play-in:learn-more:link",
                                "data-text": "Learn more about Play-In here",
                                children: (0, o.jsx)("text", {
                                    textAnchor: "middle",
                                    className: N().bracketParagraphFootnote,
                                    children: c
                                })
                            })]
                        })
                    })]
                }) : null
            }

            function B(e) {
                var t = e.result;
                return (0, o.jsx)("svg", {
                    viewBox: "0 0 20 20",
                    height: "20",
                    width: "20",
                    children: (0, o.jsxs)("g", {
                        children: [(0, o.jsx)("rect", {
                            fill: "#000",
                            height: "20",
                            width: "20",
                            rx: "10"
                        }), (0, o.jsx)("text", {
                            transform: "translate(10, 15)",
                            textAnchor: "middle",
                            fill: "#FFFFFF",
                            fontFamily: "Roboto",
                            fontWeight: "800",
                            fontSize: "12px",
                            children: t
                        })]
                    })
                })
            }
            var P = a(65843),
                W = a.n(P);

            function I(e) {
                var t = e.series,
                    a = void 0 === t ? {} : t,
                    r = e.low,
                    i = e.high,
                    c = e.swap,
                    d = void 0 !== c && c,
                    h = e.enableAnchor,
                    x = a.nextGameId,
                    f = a.lowSeedTricode,
                    m = a.highSeedTricode,
                    p = a.link,
                    j = a.matchupType,
                    y = (0, l.useContext)(g.N).isWebView,
                    _ = (0, b.Z)(),
                    N = (0, k.Z)(d ? [45, 0] : [0, 45], 2),
                    L = N[0],
                    T = N[1],
                    B = _.isDomestic ? "primary" : "global",
                    P = (0, l.useMemo)((function() {
                        var e = null === j || void 0 === j ? void 0 : j.includes("Play-In");
                        return f && m && h ? y ? S(x) : (0, w.Z)(x, f, m) : p && !e ? p : null
                    }), [f, m, h, x, p, j, y]);
                if (!a) return null;
                var I = P ? "a" : "g",
                    Z = v(a);
                return (0, o.jsx)(I, (0, n.Z)((0, s.Z)({
                    href: P,
                    className: W().bracketPlayinTile
                }, Z), {
                    children: (0, o.jsxs)("svg", {
                        viewBox: "0 0 64 91",
                        height: "91",
                        width: "64",
                        children: [(0, o.jsx)("g", {
                            children: (0, o.jsx)("rect", {
                                x: "0",
                                y: "0",
                                width: "64",
                                height: "91",
                                className: W().matchupCardBackground,
                                strokeWidth: "1"
                            })
                        }), (0, o.jsx)("g", {
                            className: W().team,
                            transform: "translate(0, ".concat(L, ")"),
                            children: a.highSeedId ? (0, o.jsxs)("g", {
                                className: W().team,
                                children: [(0, o.jsx)("image", {
                                    transform: "translate(29, 10)",
                                    width: "22",
                                    height: "22",
                                    xlinkHref: "".concat(u.$, "/logos/nba/").concat(a.highSeedId, "/").concat(B, "/L/logo.svg")
                                }), (0, o.jsx)("text", {
                                    transform: "translate(14, 24)",
                                    children: a.highSeedRank
                                })]
                            }) : (0, o.jsx)("g", {
                                className: W().team,
                                children: (0, o.jsx)("foreignObject", {
                                    x: "2",
                                    y: "15",
                                    width: "60",
                                    height: "30",
                                    children: (0, o.jsx)("div", {
                                        children: i
                                    })
                                })
                            })
                        }), (0, o.jsx)("g", {
                            className: W().team,
                            transform: "translate(0, ".concat(T, ")"),
                            children: a.lowSeedId ? (0, o.jsxs)("g", {
                                className: W().team,
                                children: [(0, o.jsx)("image", {
                                    transform: "translate(29, 10)",
                                    width: "22",
                                    height: "22",
                                    xlinkHref: "".concat(u.$, "/logos/nba/").concat(a.lowSeedId, "/").concat(B, "/L/logo.svg")
                                }), (0, o.jsx)("text", {
                                    transform: "translate(14, 24)",
                                    children: a.lowSeedRank
                                })]
                            }) : (0, o.jsx)("g", {
                                className: W().team,
                                children: (0, o.jsx)("foreignObject", {
                                    x: "2",
                                    y: "15",
                                    width: "60",
                                    height: "30",
                                    children: (0, o.jsx)("div", {
                                        children: r
                                    })
                                })
                            })
                        }), (0, o.jsx)("g", {
                            className: W().stroke,
                            strokeWidth: "1",
                            strokeLinecap: "round",
                            children: (0, o.jsx)("line", {
                                x1: "0",
                                x2: "65",
                                y1: "45",
                                y2: "45"
                            })
                        })]
                    })
                }))
            }

            function Z(e) {
                var t = e.bracket,
                    a = e.hideLinks,
                    r = e.bracketParagraph,
                    s = e.bracketTitle,
                    n = e.bracketLogoUrl,
                    i = void 0 === n ? "" : n,
                    c = e.ctaLabel,
                    d = e.ctaLink,
                    h = e.description,
                    x = e.enableAnchor,
                    f = (0, l.useContext)(g.N).isWebView;
                return t ? (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsxs)("svg", {
                        viewBox: "0 0 360 600",
                        children: [(0, o.jsx)("g", {
                            className: "bracket__background",
                            children: (0, o.jsx)("rect", {
                                height: "770",
                                width: "360",
                                className: W().background
                            })
                        }), (0, o.jsx)("g", {
                            className: W().bracketHeaderText,
                            children: (0, o.jsx)("text", {
                                transform: "translate(180, 94)",
                                textAnchor: "middle",
                                children: h
                            })
                        }), (0, o.jsxs)("g", {
                            className: W().bracketPlayinText,
                            children: [(0, o.jsx)("text", {
                                transform: "translate(145, 164)",
                                children: "FIRST ROUND"
                            }), (0, o.jsx)("text", {
                                transform: "translate(30, 219)",
                                children: "PLAY-IN"
                            }), (0, o.jsx)("text", {
                                transform: "translate(290, 219)",
                                children: "PLAY-IN"
                            }), (0, o.jsx)("text", {
                                className: W().bracketText,
                                transform: "translate(85, 135)",
                                children: "WEST"
                            }), (0, o.jsx)("text", {
                                className: W().bracketText,
                                transform: "translate(230, 135)",
                                children: "EAST"
                            })]
                        }), (0, o.jsxs)("g", {
                            children: [(0, o.jsxs)("g", {
                                className: "wpi",
                                children: [(0, o.jsx)("g", {
                                    transform: "translate(15, 228)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.pi910,
                                        enableAnchor: x
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(15, 339)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.piLast,
                                        swap: !0,
                                        high: "Loser 7/8",
                                        low: "Winner 9/10",
                                        enableAnchor: x
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(15, 450)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.pi78,
                                        low: "",
                                        height: "",
                                        enableAnchor: x
                                    })
                                })]
                            }), (0, o.jsxs)("g", {
                                className: "epi",
                                children: [(0, o.jsx)("g", {
                                    transform: "translate(281, 228)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.pi910,
                                        enableAnchor: x
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(281, 339)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.piLast,
                                        swap: !0,
                                        high: "Loser 7/8",
                                        low: "Winner 9/10",
                                        enableAnchor: x
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(281, 450)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.pi78,
                                        enableAnchor: x
                                    })
                                })]
                            }), (0, o.jsxs)("g", {
                                className: "er1",
                                children: [(0, o.jsx)("g", {
                                    transform: "translate(185, 173)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.rd[0],
                                        low: "8 Seed"
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(185, 284)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.rd[3]
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(185, 395)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.rd[2]
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(185, 506)",
                                    children: (0, o.jsx)(I, {
                                        series: t.east.rd[1],
                                        low: "7 Seed"
                                    })
                                })]
                            }), (0, o.jsxs)("g", {
                                className: "wr1",
                                children: [(0, o.jsx)("g", {
                                    transform: "translate(111, 173)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.rd[0],
                                        low: "8 Seed"
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(111, 284)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.rd[3]
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(111, 395)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.rd[2]
                                    })
                                }), (0, o.jsx)("g", {
                                    transform: "translate(111, 506)",
                                    children: (0, o.jsx)(I, {
                                        series: t.west.rd[1],
                                        low: "7 Seed"
                                    })
                                })]
                            })]
                        }), (0, o.jsxs)("g", {
                            fill: "none",
                            className: W().bracketLines,
                            strokeWidth: "0.5",
                            children: [(0, o.jsx)("path", {
                                d: "m251.2 241.1l6.9-6.9c0.2-0.2 0.6-0.2 0.8 0s0.2 0.6 0 0.8l-6.4 6.5 6.4 6.5c0.2 0.2 0.2 0.6 0 0.8-0.1 0.1-0.3 0.2-0.4 0.2s-0.3-0.1-0.4-0.2l-6.9-6.9c-0.1-0.1-0.2-0.3-0.2-0.4s0.1-0.3 0.2-0.4z"
                            }), (0, o.jsx)("path", {
                                d: "m108.8 241.1l-6.9-6.9c-0.2-0.2-0.6-0.2-0.8 0s-0.2 0.6 0 0.8l6.4 6.5-6.4 6.5c-0.2 0.2-0.2 0.6 0 0.8 0.1 0.1 0.3 0.2 0.4 0.2s0.3-0.1 0.4-0.2l6.9-6.9c0.1-0.1 0.2-0.3 0.2-0.4s-0.1-0.3-0.2-0.4z"
                            }), (0, o.jsx)("path", {
                                d: "m108.8 573.1l-6.9-6.9c-0.2-0.2-0.6-0.2-0.8 0s-0.2 0.6 0 0.8l6.4 6.5-6.4 6.5c-0.2 0.2-0.2 0.6 0 0.8 0.1 0.1 0.3 0.2 0.4 0.2s0.3-0.1 0.4-0.2l6.9-6.9c0.1-0.1 0.2-0.3 0.2-0.4s-0.1-0.3-0.2-0.4z"
                            }), (0, o.jsx)("path", {
                                d: "m251.2 573.1l6.9-6.9c0.2-0.2 0.6-0.2 0.8 0s0.2 0.6 0 0.8l-6.4 6.5 6.4 6.5c0.2 0.2 0.2 0.6 0 0.8-0.1 0.1-0.3 0.2-0.4 0.2s-0.3-0.1-0.4-0.2l-6.9-6.9c-0.1-0.1-0.2-0.3-0.2-0.4s0.1-0.3 0.2-0.4z"
                            })]
                        }), (0, o.jsxs)("g", {
                            fill: "none",
                            className: W().bracketLines,
                            strokeWidth: "1",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: [(0, o.jsx)("path", {
                                d: "m252 241.6h13.4v143h12.8"
                            }), (0, o.jsx)("path", {
                                d: "M108,241.6H94.6v143H81.7"
                            }), (0, o.jsx)("path", {
                                d: "M108,573.4H95v-78H81.8"
                            }), (0, o.jsx)("path", {
                                d: "m252 573.4h13v-78h13.2"
                            })]
                        }), (0, o.jsxs)("g", {
                            children: [(0, o.jsx)("g", {
                                transform: "translate(85,298)",
                                children: (0, o.jsx)(B, {
                                    result: "W",
                                    conf: "West"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(85,521)",
                                children: (0, o.jsx)(B, {
                                    result: "W",
                                    conf: "West"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(255,298)",
                                children: (0, o.jsx)(B, {
                                    result: "W",
                                    conf: "East"
                                })
                            }), (0, o.jsx)("g", {
                                transform: "translate(255,521)",
                                children: (0, o.jsx)(B, {
                                    result: "W",
                                    conf: "East"
                                })
                            })]
                        }), (0, o.jsx)("g", {
                            transform: "translate(100, 20)",
                            children: (0, o.jsx)("image", {
                                width: "160",
                                height: "40",
                                xlinkHref: i
                            })
                        })]
                    }), (0, o.jsx)("div", {
                        className: W().bracketFooterText,
                        children: (0, o.jsxs)("div", {
                            className: W().bracketParagraphContainer,
                            children: [(0, o.jsx)("text", {
                                className: W().bracketParagraphTitle,
                                children: s
                            }), (0, o.jsx)("text", {
                                className: W().bracketParagraph,
                                children: r
                            }), !(a || f || !c || !d) && (0, o.jsx)("a", {
                                href: d,
                                "data-track": "click",
                                "data-type": "link",
                                "data-id": "nba:playoffs:play-in:learn-more:link",
                                "data-text": "Learn more about Play-In here",
                                children: (0, o.jsx)("text", {
                                    textAnchor: "middle",
                                    className: W().bracketParagraphFootnote,
                                    children: c
                                })
                            })]
                        })
                    })]
                }) : null
            }
            var C = a(81803),
                A = a(26085),
                F = a(61277),
                E = a(38901),
                R = a(85121),
                D = a(16978),
                H = a(99534);

            function M(e) {
                e.alt;
                var t = e.className,
                    a = e.role,
                    r = void 0 === a ? "presentation" : a,
                    i = e.style,
                    c = (e.title, (0, H.Z)(e, ["alt", "className", "role", "style", "title"]));
                return (0, o.jsxs)("svg", (0, n.Z)((0, s.Z)({
                    className: t,
                    "data-no-icon": !0,
                    role: r,
                    style: i,
                    fill: "currentColor",
                    viewBox: "0 0 24 24",
                    xmlns: "http://www.w3.org/2000/svg"
                }, c), {
                    children: [(0, o.jsx)("path", {
                        d: "M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z",
                        opacity: ".25"
                    }), (0, o.jsx)("path", {
                        d: "M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z",
                        children: (0, o.jsx)("animateTransform", {
                            attributeName: "transform",
                            type: "rotate",
                            dur: "0.75s",
                            values: "0 12 12;360 12 12",
                            repeatCount: "indefinite"
                        })
                    })]
                }))
            }
            var z = a(54005);
            var Y = a(93967),
                U = a.n(Y),
                X = a(91509),
                K = a.n(X);

            function O(e) {
                var t = e.className;
                return (0, o.jsxs)("svg", {
                    width: "1041",
                    height: "64",
                    viewBox: "0 0 1041 64",
                    preserveAspectRatio: "xMidYMin slice",
                    fontFamily: "Roboto",
                    className: U()(K().nav, t),
                    children: [(0, o.jsx)("rect", {
                        className: K().bg,
                        width: "1041",
                        height: "64"
                    }), (0, o.jsx)(G, {
                        x: 73,
                        y: 5,
                        conf: "WEST",
                        round: "First Round"
                    }), (0, o.jsx)(G, {
                        x: 219,
                        y: 5,
                        conf: "WEST",
                        round: "Conf. Semifinals"
                    }), (0, o.jsx)(G, {
                        x: 365,
                        y: 5,
                        conf: "WEST",
                        round: "Conf. Finals"
                    }), (0, o.jsx)(G, {
                        x: 511,
                        y: 5,
                        conf: "NBA",
                        round: "Finals"
                    }), (0, o.jsx)(G, {
                        x: 657,
                        y: 5,
                        conf: "EAST",
                        round: "Conf. Finals"
                    }), (0, o.jsx)(G, {
                        x: 803,
                        y: 5,
                        conf: "EAST",
                        round: "Conf. Semifinals"
                    }), (0, o.jsx)(G, {
                        x: 949,
                        y: 5,
                        conf: "EAST",
                        round: "First Round"
                    })]
                })
            }

            function G(e) {
                var t = e.x,
                    a = void 0 === t ? 0 : t,
                    r = e.y,
                    s = void 0 === r ? 0 : r,
                    n = e.conf,
                    i = e.round;
                return (0, o.jsxs)("g", {
                    transform: "translate(".concat(a, ",").concat(s, ")"),
                    textAnchor: "middle",
                    children: [(0, o.jsx)("text", {
                        fontSize: "10",
                        dy: "10",
                        children: n
                    }), (0, o.jsx)("text", {
                        fontSize: "14",
                        fontWeight: "700",
                        dy: "30",
                        children: i
                    })]
                })
            }
            var V = a(61436),
                q = a(88322);

            function $(e) {
                var t = function(e, t, a) {
                        if (!e || !e.name || !e.id || "TBD" === e.tricode) return {
                            exists: !1,
                            name: "TBD"
                        };
                        var n = t && t === e.id,
                            i = "".concat(u.yS, "/").concat(e.id, "/").concat(c.location, "/").concat(r, "/logo.svg"),
                            o = "West" === a ? "right" : "left";
                        return (0, s.Z)({
                            exists: !0,
                            isSeriesWinner: n,
                            teamLogoSrc: i,
                            winIndicatorPosition: o
                        }, e)
                    },
                    a = (0, b.Z)(),
                    r = "light" === (0, l.useContext)(g.N).themeName ? "L" : "D",
                    i = (0, l.useState)({
                        hasSeriesData: !1,
                        location: "primary"
                    }),
                    c = i[0],
                    o = i[1];
                return (0, l.useEffect)((function() {
                    e && e.constructor === Object && 0 !== Object.keys(e).length ? function(a) {
                        var r, i = a.link ? "a" : "g",
                            c = a.link || "",
                            l = 2 === a.seriesStatus,
                            d = 1 === a.seriesStatus && 0 !== a.nextGameStatus,
                            h = 3 === a.seriesStatus,
                            x = h || !a.nextGameDateTimeEt,
                            f = 2 === a.nextGameStatus,
                            u = l || d,
                            g = new Date(a.nextGameDateTimeUTC),
                            m = (0, V.Z)(g) && (0, q.Z)(g, "LLL dd"),
                            p = (null === (r = a.nextGameStatusText) || void 0 === r ? void 0 : r.toUpperCase()) || "",
                            j = function(e) {
                                if (!e.isSet) return ["", ""];
                                if (e.lowSeedSeriesWins === e.highSeedSeriesWins) return ["SERIES TIED", "".concat(e.lowSeedSeriesWins, "-").concat(e.highSeedSeriesWins)];
                                var t = 3 === e.seriesStatus ? "WINS" : "LEADS";
                                return e.lowSeedSeriesWins > e.highSeedSeriesWins ? ["".concat(e.lowSeedTricode, " ").concat(t), "".concat(e.lowSeedSeriesWins, "-").concat(e.highSeedSeriesWins)] : ["".concat(e.highSeedTricode, " ").concat(t), "".concat(e.highSeedSeriesWins, "-").concat(e.lowSeedSeriesWins)]
                            }(a),
                            k = v(a),
                            b = t(e.top, e.seriesWinner, e.seriesConference),
                            y = t(e.bot, e.seriesWinner, e.seriesConference),
                            w = function(e) {
                                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 23;
                                return e && e.length ? e.length > t ? "".concat(e.slice(0, t - 3), "...") : e : ""
                            }(e.nextGameBroadcasterDisplay);
                        o((function(e) {
                            return (0, n.Z)((0, s.Z)({}, e), {
                                hasSeriesData: !0,
                                Tag: i,
                                href: c,
                                isSeriesLive: l,
                                isSeriesUpcoming: d,
                                hasNextGame: x,
                                isGameLive: f,
                                isSeriesComplete: h,
                                gameDateUTC: g,
                                gameDateEST: m,
                                nextGameStatusText: p,
                                seriesRecords: j,
                                showTuneIn: u,
                                analytics: k,
                                top: b,
                                bot: y,
                                broadcaster: w,
                                series: (0, s.Z)({}, a)
                            })
                        }))
                    }(e) : o((function(e) {
                        return (0, n.Z)((0, s.Z)({}, e), {
                            hasSeriesData: !1
                        })
                    }))
                }), [e]), (0, l.useEffect)((function() {
                    o((function(e) {
                        return (0, n.Z)((0, s.Z)({}, e), {
                            location: a.isDomestic ? "primary" : "global",
                            shouldHideBroadcasters: !a.isDomestic
                        })
                    }))
                }), [a.isDomestic]), c
            }
            var Q = {
                    tileWidth: 128,
                    tileHeight: 134,
                    hatHeight: 32,
                    hatHeightNoBroadcaster: 20,
                    hatY: 0,
                    hatYNoBroadcaster: 12,
                    hatLiveRadius: 3,
                    hatLiveY: 9,
                    hatLiveX: 6,
                    hatDx: 8,
                    hatDy: 13,
                    hatFontSize: 9,
                    teamHeight: 40,
                    teamFontSize: 12,
                    teamFontWeight: 700,
                    teamRankX: 32,
                    teamNameX: 43,
                    teamTextDy: 24,
                    teamLogoSize: 24,
                    teamLogoX: 4,
                    teamLogoY: 8,
                    teamLogoRadius: 9,
                    teamWinIndicatorWidth: 4,
                    topY: 32,
                    botY: 73,
                    seriesHeight: 20,
                    seriesY: 114,
                    seriesFontSize: 10,
                    seriesFontWeight: 900,
                    seriesDy: 13,
                    seriesDx: 4
                },
                J = a(59728),
                ee = a.n(J);

            function te(e) {
                var t = e.series,
                    a = $(void 0 === t ? {} : t),
                    r = "0 0 ".concat(Q.tileWidth, " ").concat(Q.tileHeight);
                if (!a.hasSeriesData) return (0, o.jsxs)("svg", {
                    viewBox: r,
                    height: Q.tileHeight,
                    width: Q.tileWidth,
                    children: [(0, o.jsx)("rect", {
                        height: Q.topHeight,
                        width: Q.tileWidth,
                        x: "0",
                        y: Q.topY,
                        className: ee().matchupCardBackground
                    }), (0, o.jsx)("rect", {
                        height: Q.botHeight,
                        width: Q.tileWidth,
                        x: "0",
                        y: Q.botY,
                        className: ee().matchupCardBackground
                    })]
                });
                var i = a.Tag,
                    c = (a.isSeriesLive || a.isSeriresUpcoming ? ee().blackBorder : ee().grayBorder, function() {
                        var e = Q.hatHeight,
                            t = Q.hatHeightNoBroadcaster,
                            r = Q.hatY,
                            s = Q.hatYNoBroadcaster,
                            n = Q.hatLiveRadius,
                            i = Q.hatLiveX,
                            c = Q.hatDx,
                            l = Q.hatDy,
                            d = Q.hatFontSize,
                            h = Q.tileWidth;
                        if (!a.showTuneIn) return null;
                        var x = a.hasNextGame ? "" : a.isGameLive ? (0, o.jsxs)("g", {
                            children: [(0, o.jsx)("circle", {
                                className: ee().statusLiveIndicator,
                                cx: c + i,
                                cy: l - 2 - n / 2,
                                r: n
                            }), (0, o.jsx)("text", {
                                className: ee().statusLiveText,
                                dy: l,
                                dx: c,
                                fontWeight: "bold",
                                transform: "translate(12, 0)",
                                children: "LIVE"
                            })]
                        }) : (0, o.jsx)("text", {
                            dy: l,
                            dx: c,
                            fontWeight: "bold",
                            children: a.nextGameStatusText
                        });
                        return (0, o.jsxs)("g", {
                            className: ee().broadcaster,
                            fontSize: d,
                            transform: "translate(0, ".concat(a.shouldHideBroadcasters ? s : r, ")"),
                            children: [(0, o.jsx)("rect", {
                                height: a.shouldHideBroadcasters ? t : e,
                                width: h
                            }), x, (0, o.jsx)("text", {
                                dy: 2 * l,
                                dx: c,
                                textAnchor: "start",
                                children: a.shouldHideBroadcasters ? "" : a.broadcaster
                            })]
                        })
                    }()),
                    l = function() {
                        var e = Q.seriesDx,
                            t = Q.seriesDy,
                            r = Q.seriesFontSize,
                            s = Q.seriesFontWeight,
                            n = Q.seriesHeight,
                            i = Q.seriesY,
                            c = Q.tileWidth;
                        return a.seriesRecords[0] ? (0, o.jsxs)("g", {
                            transform: "translate(0, ".concat(i, ")"),
                            children: [(0, o.jsx)("rect", {
                                height: n,
                                width: c,
                                className: ee().matchupCardBackground
                            }), (0, o.jsxs)("text", {
                                fontSize: r,
                                dy: t,
                                dx: e,
                                className: ee().matchupCardText,
                                children: [(0, o.jsxs)("tspan", {
                                    fontWeight: s,
                                    children: [a.seriesRecords[0], " "]
                                }), a.seriesRecords[1]]
                            })]
                        }) : (0, o.jsx)(o.Fragment, {})
                    }(),
                    d = function(e, t) {
                        var r = Q.teamHeight,
                            s = Q.teamLogoSize,
                            n = Q.teamLogoX,
                            i = Q.teamLogoY,
                            c = Q.teamRankX,
                            l = Q.teamNameX,
                            d = Q.teamTextDy,
                            h = Q.teamFontWeight,
                            x = Q.teamFontSize,
                            f = Q.teamWinIndicatorWidth,
                            u = Q.teamLogoRadius,
                            g = Q.tileWidth;
                        if (!e.exists) return (0, o.jsxs)("g", {
                            transform: "translate(0, ".concat(t, ")"),
                            children: [(0, o.jsx)("rect", {
                                height: r,
                                width: g,
                                className: ee().matchupCardBackground
                            }), (0, o.jsxs)("g", {
                                fontSize: x,
                                children: [(0, o.jsx)("circle", {
                                    transform: "translate(".concat(n + 3, ", ").concat(i + 3, ")"),
                                    cx: u,
                                    cy: u,
                                    r: u,
                                    className: ee().tbdLogo
                                }), (0, o.jsx)("text", {
                                    transform: "translate(".concat(c, ", 0)"),
                                    dy: d,
                                    className: ee().matchupCardText,
                                    fontWeight: h,
                                    children: e.name
                                })]
                            })]
                        });
                        var m = !a.isSeriesComplete || e.isSeriesWinner ? 1 : .5,
                            p = "right" === e.winIndicatorPosition ? "translate(".concat(g - f, ", 0)") : "translate(0, 0)";
                        return (0, o.jsxs)("g", {
                            transform: "translate(0, ".concat(t, ")"),
                            children: [(0, o.jsx)("rect", {
                                height: r,
                                width: g,
                                className: ee().matchupCardBackground
                            }), (0, o.jsxs)("g", {
                                opacity: m,
                                fontSize: x,
                                children: [e.isSeriesWinner && (0, o.jsx)("rect", {
                                    height: r,
                                    width: f,
                                    transform: p,
                                    className: ee().matchupCardText
                                }), (0, o.jsx)("image", {
                                    transform: "translate(".concat(n, ", ").concat(i, ")"),
                                    width: s,
                                    height: s,
                                    xlinkHref: e.teamLogoSrc
                                }), (0, o.jsx)("text", {
                                    transform: "translate(".concat(c, ", 0)"),
                                    dy: d,
                                    className: ee().matchupCardText,
                                    children: e.rank
                                }), (0, o.jsx)("text", {
                                    transform: "translate(".concat(l, ", 0)"),
                                    dy: d,
                                    className: ee().matchupCardText,
                                    fontWeight: h,
                                    children: e.name
                                })]
                            })]
                        })
                    };
                return (0, o.jsx)(i, (0, n.Z)((0, s.Z)({
                    href: a.href,
                    className: ee().bracketTile
                }, a.analytics), {
                    children: (0, o.jsxs)("svg", {
                        viewBox: r,
                        height: Q.tileHeight,
                        width: Q.tileWidth,
                        fontFamily: "Roboto",
                        children: [c, d(a.top, Q.topY), d(a.bot, Q.botY), l]
                    })
                }))
            }
            var ae = a(43887),
                re = a.n(ae);

            function se(e) {
                var t = e.bracket,
                    a = e.className,
                    r = e.logoSrc,
                    s = e.showFinalsLogo,
                    n = t;
                return (0, o.jsxs)("svg", {
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1025",
                    height: "593",
                    viewBox: "0 0 1025 593",
                    className: U()(re().main, a),
                    preserveAspectRatio: "xMidYMin slice",
                    children: [(0, o.jsx)("rect", {
                        className: re().bg,
                        width: "1025",
                        height: "593"
                    }), (0, o.jsxs)("g", {
                        className: re().connectors,
                        strokeWidth: "1",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        transform: "translate(0,11)",
                        children: [(0, o.jsx)("polyline", {
                            transform: "translate(128,61.5)",
                            points: "0,0 16,0 16,64 32,64 16,64 16,148, 0,148"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(128,357.5)",
                            points: "0,0 16,0 16,64 32,64 16,64 16,148, 0,148"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(865,61.5)",
                            points: "32,0 16,0 16,64 0,64 16,64 16,148, 32,148"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(865,357.5)",
                            points: "32,0 16,0 16,64 0,64 16,64 16,148, 32,148"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(288,125.5)",
                            points: "0,0 64,0 64,114"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(288,421.5)",
                            points: "0,0 64,0 64,-108"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(737,125.5)",
                            points: "0,0 -64,0 -64,114"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(737,421.5)",
                            points: "0,0 -64,0 -64,-108"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(417,271.5)",
                            points: "0,0 32,0"
                        }), (0, o.jsx)("polyline", {
                            transform: "translate(578,271.5)",
                            points: "0,0 32,0"
                        })]
                    }), (0, o.jsx)("g", {
                        children: s && (0, o.jsx)("image", {
                            transform: "translate(435, 110)",
                            width: 160,
                            xlinkHref: r
                        })
                    }), (0, o.jsxs)("g", {
                        className: "bracket__er1",
                        transform: "translate(897, 0)",
                        children: [(0, o.jsx)("g", {
                            transform: "translate(0,0)",
                            children: (0, o.jsx)(te, {
                                series: n.er1s1
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,148)",
                            children: (0, o.jsx)(te, {
                                series: n.er1s4
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,296)",
                            children: (0, o.jsx)(te, {
                                series: n.er1s3
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,444)",
                            children: (0, o.jsx)(te, {
                                series: n.er1s2
                            })
                        })]
                    }), (0, o.jsxs)("g", {
                        className: "bracket__er2",
                        transform: "translate(737, 0)",
                        children: [(0, o.jsx)("g", {
                            transform: "translate(0,64)",
                            children: (0, o.jsx)(te, {
                                series: n.er2s1
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,360)",
                            children: (0, o.jsx)(te, {
                                series: n.er2s2
                            })
                        })]
                    }), (0, o.jsx)("g", {
                        className: "bracket__er3",
                        transform: "translate(611, 0)",
                        children: (0, o.jsx)("g", {
                            transform: "translate(0,210)",
                            children: (0, o.jsx)(te, {
                                series: n.er3s1
                            })
                        })
                    }), (0, o.jsxs)("g", {
                        className: "bracket__wr1",
                        transform: "translate(0, 0)",
                        children: [(0, o.jsx)("g", {
                            transform: "translate(0,0)",
                            children: (0, o.jsx)(te, {
                                series: n.wr1s1
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,148)",
                            children: (0, o.jsx)(te, {
                                series: n.wr1s4
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,296)",
                            children: (0, o.jsx)(te, {
                                series: n.wr1s3
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,444)",
                            children: (0, o.jsx)(te, {
                                series: n.wr1s2
                            })
                        })]
                    }), (0, o.jsxs)("g", {
                        className: "bracket__wr2",
                        transform: "translate(160, 0)",
                        children: [(0, o.jsx)("g", {
                            transform: "translate(0,64)",
                            children: (0, o.jsx)(te, {
                                series: n.wr2s2
                            })
                        }), (0, o.jsx)("g", {
                            transform: "translate(0,360)",
                            children: (0, o.jsx)(te, {
                                series: n.wr2s1
                            })
                        })]
                    }), (0, o.jsx)("g", {
                        className: "bracket__wr3",
                        transform: "translate(289, 0)",
                        children: (0, o.jsx)("g", {
                            transform: "translate(0,210)",
                            children: (0, o.jsx)(te, {
                                series: n.wr3s1
                            })
                        })
                    }), (0, o.jsx)("g", {
                        className: "bracket__f",
                        transform: "translate(450, 0)",
                        children: (0, o.jsx)("g", {
                            transform: "translate(0,210)",
                            children: (0, o.jsx)(te, {
                                series: n.finals
                            })
                        })
                    })]
                })
            }
            var ne = a(59158),
                ie = a.n(ne),
                ce = a(30434);

            function oe(e) {
                var t = e.bracket,
                    a = e.showFinalsLogo,
                    r = e.bracketLogoUrl,
                    i = void 0 === r ? "" : r,
                    c = e.isWebview,
                    d = (0, F.Z)(),
                    h = (0, E.Z)(),
                    x = (0, l.useState)(!1),
                    u = x[0],
                    g = x[1],
                    m = (0, l.useRef)(!1),
                    p = (0, l.useRef)(null),
                    j = (0, l.useRef)(null),
                    k = (0, A.Z)(j, d).partiallyVisible;
                if (!t) return (0, o.jsx)(o.Fragment, {});
                var b = function(e) {
                    var t = (0, z.b1B)().key((function(e) {
                        return e.seriesConference
                    })).key((function(e) {
                        return e.roundNumber
                    })).key((function(e) {
                        return e.seriesNumber
                    })).object(e);
                    return {
                        er1s1: (0, f.XZ)(["East", 1, 0, 0], t),
                        er1s2: (0, f.XZ)(["East", 1, 1, 0], t),
                        er1s3: (0, f.XZ)(["East", 1, 2, 0], t),
                        er1s4: (0, f.XZ)(["East", 1, 3, 0], t),
                        er2s1: (0, f.XZ)(["East", 2, 0, 0], t),
                        er2s2: (0, f.XZ)(["East", 2, 1, 0], t),
                        er3s1: (0, f.XZ)(["East", 3, 0, 0], t),
                        wr1s1: (0, f.XZ)(["West", 1, 4, 0], t),
                        wr1s2: (0, f.XZ)(["West", 1, 5, 0], t),
                        wr1s3: (0, f.XZ)(["West", 1, 6, 0], t),
                        wr1s4: (0, f.XZ)(["West", 1, 7, 0], t),
                        wr2s1: (0, f.XZ)(["West", 2, 3, 0], t),
                        wr2s2: (0, f.XZ)(["West", 2, 2, 0], t),
                        wr3s1: (0, f.XZ)(["West", 3, 1, 0], t),
                        finals: (0, f.XZ)(["NBA Finals", 4, 0, 0], t)
                    }
                }(t);
                return (0, o.jsxs)("div", {
                    className: ie().bracket,
                    "data-is-webview": c,
                    children: [(0, o.jsx)("style", {
                        children: "\n        :root {\n          --fixed-nav-height: ".concat(d, "px;\n        }\n      ")
                    }), (0, o.jsx)("div", {
                        className: ie().nav,
                        "data-in-viewport": k,
                        children: (0, o.jsx)("div", {
                            className: ie().navInner,
                            ref: p,
                            onScroll: function(e) {
                                if (m.current) m.current = !1;
                                else {
                                    var t = e.target.scrollLeft;
                                    j.current && (m.current = !0, j.current.scrollLeft = t)
                                }
                            },
                            children: (0, o.jsx)(O, {
                                className: ie().navImage
                            })
                        })
                    }), (0, o.jsx)("div", {
                        className: ie().main,
                        children: (0, o.jsx)("div", {
                            className: ie().mainInner,
                            ref: j,
                            onScroll: function(e) {
                                if (m.current) m.current = !1;
                                else {
                                    var t = e.target.scrollLeft;
                                    p.current && (m.current = !0, p.current.scrollLeft = t)
                                }
                            },
                            children: (0, o.jsx)(se, {
                                className: ie().mainImage,
                                bracket: b,
                                logoSrc: i,
                                showFinalsLogo: a
                            })
                        })
                    }), !c && !h && (0, o.jsxs)(R.Z, (0, n.Z)((0, s.Z)({
                        className: ie().downloadButton,
                        as: "button",
                        variant: "default",
                        onClick: function(e) {
                            var t, a;
                            if (j.current && p.current) {
                                var r = null === (t = p.current.querySelector("svg")) || void 0 === t ? void 0 : t.cloneNode(!0),
                                    s = null === (a = j.current.querySelector("svg")) || void 0 === a ? void 0 : a.cloneNode(!0);
                                if (s && r) {
                                    g(!0);
                                    var n = document.createElementNS("http://www.w3.org/2000/svg", "svg"),
                                        i = document.createElementNS("http://www.w3.org/2000/svg", "g"),
                                        c = document.createElementNS("http://www.w3.org/2000/svg", "g"),
                                        o = document.createElementNS("http://www.w3.org/2000/svg/", "rect");
                                    n.setAttribute("width", "1041"), n.setAttribute("height", "657"), n.setAttribute("viewBox", "0 0 1041 657"), n.setAttribute("preserveAspectRatio", "xMidYMin slice"), o.setAttribute("width", "1041"), o.setAttribute("height", "657"), o.setAttribute("fill", "var(--canvas)"), i.setAttribute("transform", "translate(0,0)"), i.appendChild(r), c.setAttribute("transform", "translate(8,64)"), c.appendChild(s), n.append(o), n.appendChild(i), n.appendChild(c), setTimeout((function() {
                                        g(!1), (0, C.saveSvgAsPng)(n, "bracket.png")
                                    }), 500)
                                }
                            }
                        },
                        type: "button",
                        size: "xs"
                    }, (0, ce.$)({
                        dataTrack: "click",
                        dataType: "button",
                        dataId: "nba:tentpole-hub:download:button",
                        dataText: "Download Bracket"
                    })), {
                        children: ["Download Bracket", u ? (0, o.jsx)(M, {
                            className: ie().iconSpinner
                        }) : (0, o.jsx)(D.Z, {
                            className: ie().iconDownload
                        })]
                    }))]
                })
            }
            var le = a(12474),
                de = a(70858),
                he = a.n(de);

            function xe() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                    t = arguments.length > 1 ? arguments[1] : void 0,
                    a = arguments.length > 2 ? arguments[2] : void 0,
                    r = arguments.length > 3 ? arguments[3] : void 0;
                e.forEach((function(e) {
                    var s = (e.seriesId || "").charAt(11),
                        n = "".concat(1, "_").concat(s),
                        i = t[n];
                    if (i) {
                        if (Object.assign(e, i), r) return;
                        e.link = a ? e.appUrl : e.webUrl
                    }
                }))
            }

            function fe(e, t, a) {
                var r = {},
                    n = e.filter((function(e) {
                        return "First Round" === e.matchupType
                    }));
                n.sort((function(e, t) {
                    return e.highSeedRank - t.highSeedRank
                })), r.rd = n;
                var i = e.find((function(e) {
                        return "Play-In 7v8" === e.matchupType
                    })),
                    c = e.find((function(e) {
                        return "Play-In 9v10" === e.matchupType
                    })),
                    o = e.find((function(e) {
                        return !["First Round", "Play-In 7v8", "Play-In 9v10"].includes(e.matchupType)
                    })),
                    l = {
                        webUrl: "/games",
                        appUrl: "gametime://games"
                    };
                return i && (r.pi78 = (0, s.Z)({}, r.pi78, i, l), a || (r.pi78.link = t ? l.appUrl : l.webUrl)), c && (r.pi910 = (0, s.Z)({}, r.pi910, c, l), a || (r.pi910.link = t ? l.appUrl : l.webUrl)), o && (r.piLast = (0, s.Z)({}, r.piLast, o, l), a || (r.piLast.link = t ? l.appUrl : l.webUrl)), r
            }
            var ue = a(18173);

            function ge(e) {
                var t = e.season,
                    a = e.type,
                    i = e.isWebview,
                    g = e.hideLinks,
                    m = e.showFinalsLogo,
                    p = e.bracketLogoUrl,
                    j = e.bracketParagraph,
                    k = e.bracketTitle,
                    b = e.ctaLabel,
                    y = e.ctaLink,
                    v = e.description,
                    w = ((0, le.x)().constants || {}).bracket,
                    S = (void 0 === w ? {} : w).flatFileSupportYear,
                    _ = (0, l.useState)({
                        playin: null,
                        picture: null,
                        playoff: null,
                        hubs: null,
                        isLoaded: !1
                    }),
                    N = _[0],
                    L = _[1],
                    B = (0, f.V5)(t),
                    P = (0, l.useState)(null),
                    W = P[0],
                    I = P[1],
                    C = (0, l.useState)(null),
                    A = C[0],
                    F = C[1],
                    E = (0, d.a)({
                        queryKey: ["bracket", B],
                        queryFn: (0, r.Z)(c().mark((function e() {
                            var t;
                            return c().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, Promise.all([h.Z.get({
                                            SeasonYear: B,
                                            State: 0
                                        }, S), h.Z.get({
                                            SeasonYear: B,
                                            State: 1
                                        }, S), h.Z.get({
                                            SeasonYear: B,
                                            State: 2
                                        }, S), (0, x.sD)({
                                            seasonYear: B
                                        })]);
                                    case 2:
                                        return t = e.sent, e.abrupt("return", t);
                                    case 4:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        }))),
                        refetchInterval: ue.o
                    }),
                    R = E.data,
                    D = E.isError,
                    H = E.error;
                if ((0, l.useEffect)((function() {
                        R && L((function(e) {
                            return (0, n.Z)((0, s.Z)({}, e), {
                                isLoaded: !0,
                                picture: R[0].playoffPictureSeries,
                                playin: R[1].playInBracketSeries,
                                playoff: R[2].playoffBracketSeries,
                                hubs: (t = R[3], t && Object.keys(t).length ? t.reduce((function(e, t) {
                                    return e["".concat(t.seriesRound, "_").concat(t.seriesNumber)] = t, e
                                }), {}) : {})
                            });
                            var t
                        }))
                    }), [R]), (0, l.useEffect)((function() {
                        D && console.warn(H)
                    }), [D, H]), (0, l.useEffect)((function() {
                        if (N.isLoaded) {
                            var e = function(e, t, a, r, s) {
                                return [{
                                    type: "picture",
                                    data: e
                                }, {
                                    type: "playin",
                                    data: t
                                }].reduce((function(e, t) {
                                    if (!t.data || !t.data.length) return e;
                                    var n = t.data.filter((function(e) {
                                            return "East" === e.conference
                                        })),
                                        i = t.data.filter((function(e) {
                                            return "West" === e.conference
                                        }));
                                    return e[t.type] = {
                                        east: fe(n, r, s),
                                        west: fe(i, r, s)
                                    }, xe(e[t.type].west.rd, a, r, s), xe(e[t.type].east.rd, a, r, s), e
                                }), {})
                            }(N.picture, N.playin, N.hubs, i, g);
                            I(e);
                            var t = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                                    t = arguments.length > 1 ? arguments[1] : void 0,
                                    a = arguments.length > 2 ? arguments[2] : void 0,
                                    r = arguments.length > 3 ? arguments[3] : void 0;
                                return e.forEach((function(e) {
                                    e.isSet = !(!e.lowSeedId || !e.highSeedId), e.highSeedId || (e.highSeedId = 0, e.highSeedTricode = "", e.highSeedRank = ""), e.lowSeedId || (e.lowSeedId = 0, e.lowSeedTricode = "", e.lowSeedRank = ""), e.topSeedKey = e.displayTopTeam === e.highSeedId ? "highSeed" : "lowSeed", e.botSeedKey = e.displayBottomTeam === e.highSeedId ? "highSeed" : "lowSeed", e.top = {
                                        city: e["".concat(e.topSeedKey, "City")],
                                        id: e["".concat(e.topSeedKey, "Id")],
                                        name: e["".concat(e.topSeedKey, "Name")],
                                        rank: e["".concat(e.topSeedKey, "Rank")],
                                        regSeasonLosses: e["".concat(e.topSeedKey, "RegSeasonLosses")],
                                        regSeasonWins: e["".concat(e.topSeedKey, "RegSeasonWins")],
                                        seriesWins: e["".concat(e.topSeedKey, "SeriesWins")],
                                        tricode: e["".concat(e.topSeedKey, "Tricode")]
                                    }, e.bot = {
                                        city: e["".concat(e.botSeedKey, "City")],
                                        id: e["".concat(e.botSeedKey, "Id")],
                                        name: e["".concat(e.botSeedKey, "Name")],
                                        rank: e["".concat(e.botSeedKey, "Rank")],
                                        regSeasonLosses: e["".concat(e.botSeedKey, "RegSeasonLosses")],
                                        regSeasonWins: e["".concat(e.botSeedKey, "RegSeasonWins")],
                                        seriesWins: e["".concat(e.botSeedKey, "SeriesWins")],
                                        tricode: e["".concat(e.botSeedKey, "Tricode")]
                                    };
                                    var s = e.seriesId || "",
                                        n = s.charAt(9),
                                        i = s.charAt(11),
                                        c = "".concat(n, "_").concat(i),
                                        o = t[c];
                                    if (o) {
                                        if (Object.assign(e, o), r) return;
                                        e.link = a ? e.appUrl : e.webUrl
                                    }
                                })), e
                            }(N.playoff, N.hubs, i, g);
                            F(t)
                        }
                    }), [N.isLoaded]), null === a || "no-bracket" === a) return null;
                var M = function(e, t) {
                    var a = t && Number(t) ? t : null,
                        r = "".concat(u.$, "/logos/playoffs/").concat(null !== a && void 0 !== a ? a : "fallback", "/L");
                    switch (e) {
                        case "play-in-tournament":
                            return "".concat(r, "/playin.svg");
                        case "playoff-picture":
                            return "".concat(r, "/playoffs-picture.svg");
                        case "full-playoff-bracket":
                            return "".concat(r, "/finals.svg");
                        default:
                            return "".concat(r, "/playoffs.svg")
                    }
                }(a, B);
                return "playoff-picture" === a && W ? (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)("div", {
                        className: he().pibm,
                        children: (0, o.jsx)(Z, {
                            bracket: null === W || void 0 === W ? void 0 : W.picture,
                            hideLinks: g,
                            bracketParagraph: j,
                            bracketTitle: k,
                            bracketLogoUrl: M,
                            ctaLabel: b,
                            ctaLink: y,
                            description: v
                        })
                    }), (0, o.jsx)("div", {
                        className: he().pib,
                        children: (0, o.jsx)(T, {
                            bracket: null === W || void 0 === W ? void 0 : W.picture,
                            hideLinks: g,
                            bracketParagraph: j,
                            bracketTitle: k,
                            bracketLogoUrl: M,
                            ctaLabel: b,
                            ctaLink: y,
                            description: v
                        })
                    })]
                }) : "play-in-tournament" === a && W ? (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)("div", {
                        className: he().bracketPlayInBlock,
                        "data-screen": "mobile",
                        children: (0, o.jsx)(Z, {
                            bracket: null === W || void 0 === W ? void 0 : W.playin,
                            hideLinks: g,
                            bracketParagraph: j,
                            bracketTitle: k,
                            bracketLogoUrl: M,
                            ctaLabel: b,
                            ctaLink: y,
                            description: v,
                            enableAnchor: !0
                        })
                    }), (0, o.jsx)("div", {
                        className: he().bracketPlayInBlock,
                        "data-screen": "desktop",
                        children: (0, o.jsx)(T, {
                            bracket: null === W || void 0 === W ? void 0 : W.playin,
                            hideLinks: g,
                            bracketParagraph: j,
                            bracketTitle: k,
                            bracketLogoUrl: M,
                            ctaLabel: b,
                            ctaLink: y,
                            description: v,
                            enableAnchor: !0
                        })
                    })]
                }) : "full-playoff-bracket" === a && A ? (0, o.jsx)(oe, {
                    bracket: A,
                    showFinalsLogo: m,
                    bracketLogoUrl: p || M,
                    isWebview: i
                }) : null
            }
        },
        16978: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return d
                }
            });
            var r, s = a(26042),
                n = a(99534),
                i = a(85893),
                c = a(67294);

            function o() {
                return o = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var r in a)({}).hasOwnProperty.call(a, r) && (e[r] = a[r])
                    }
                    return e
                }, o.apply(null, arguments)
            }
            var l = e => c.createElement("svg", o({
                xmlns: "http://www.w3.org/2000/svg",
                height: 20,
                width: 20,
                viewBox: "0 0 20 20",
                fill: "currentColor"
            }, e), r || (r = c.createElement("path", {
                fillRule: "evenodd",
                d: "M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z",
                clipRule: "evenodd"
            })));

            function d(e) {
                var t = e.alt,
                    a = e.className,
                    r = e.role,
                    c = void 0 === r ? "presentation" : r,
                    o = e.style,
                    d = e.title,
                    h = (0, n.Z)(e, ["alt", "className", "role", "style", "title"]);
                return (0, i.jsx)(l, (0, s.Z)({
                    alt: t,
                    className: a,
                    "data-no-icon": !0,
                    role: c,
                    style: o,
                    title: d
                }, h))
            }
        },
        18173: function(e, t, a) {
            "use strict";
            a.d(t, {
                o: function() {
                    return r
                }
            });
            var r = 6e4
        },
        26085: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return s
                }
            });
            var r = a(67294);

            function s(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    a = (0, r.useState)({
                        partiallyVisible: !1,
                        fullyVisible: !1
                    }),
                    s = a[0],
                    n = a[1];
                return (0, r.useEffect)((function() {
                    var a = function(a) {
                        if (e && e.current) {
                            var r = window.innerHeight,
                                s = e.current.getBoundingClientRect(),
                                i = s.top,
                                c = s.bottom,
                                o = i - t,
                                l = o >= 0 && c <= r;
                            n({
                                partiallyVisible: i >= 0 && i <= r || i < 0 && c >= t && c <= r || o <= 0 && c >= r || l,
                                fullyVisible: l
                            })
                        }
                    };
                    return document.addEventListener("scroll", a), a(),
                        function() {
                            document.removeEventListener("scroll", a)
                        }
                }), [e, t]), s
            }
        },
        70858: function(e) {
            e.exports = {
                bracketBlock: "Bracket_bracketBlock__QTFPL",
                bracketPlayInBlock: "Bracket_bracketPlayInBlock__5H680",
                pibm: "Bracket_pibm___7ab7",
                pib: "Bracket_pib__oiVfD"
            }
        },
        81990: function(e) {
            e.exports = {
                background: "BracketPlayIn_background__DiA3A",
                bracketHeaderText: "BracketPlayIn_bracketHeaderText__bmfCC",
                bracketText: "BracketPlayIn_bracketText__PuCyh",
                bracketPlayinTile: "BracketPlayIn_bracketPlayinTile__eaJBb",
                bracketPlayinText: "BracketPlayIn_bracketPlayinText__CDsmH",
                matchupCardBackground: "BracketPlayIn_matchupCardBackground__LepH0",
                team: "BracketPlayIn_team__Xg9kk",
                bracketFooterText: "BracketPlayIn_bracketFooterText__Ivq1x",
                bracketParagraphContainer: "BracketPlayIn_bracketParagraphContainer__zoBfn",
                bracketParagraphTitle: "BracketPlayIn_bracketParagraphTitle__NKZ30",
                bracketParagraph: "BracketPlayIn_bracketParagraph__3RXuz",
                bracketParagraphFootnote: "BracketPlayIn_bracketParagraphFootnote__vx913",
                stroke: "BracketPlayIn_stroke__qYa7A",
                bracketLines: "BracketPlayIn_bracketLines__BpQL0"
            }
        },
        65843: function(e) {
            e.exports = {
                background: "BracketPlayinMobile_background__mUezu",
                bracketPlayinTile: "BracketPlayinMobile_bracketPlayinTile__TCkyL",
                bracketHeaderText: "BracketPlayinMobile_bracketHeaderText__lbxfu",
                bracketText: "BracketPlayinMobile_bracketText__mxCHO",
                bracketPlayinText: "BracketPlayinMobile_bracketPlayinText__tthZY",
                matchupCardBackground: "BracketPlayinMobile_matchupCardBackground__icWyy",
                team: "BracketPlayinMobile_team__Oqrtx",
                bracketDescription: "BracketPlayinMobile_bracketDescription__who0v",
                stroke: "BracketPlayinMobile_stroke__xLTaV",
                bracketLines: "BracketPlayinMobile_bracketLines__Y9oYk",
                bracketFooterText: "BracketPlayinMobile_bracketFooterText__Mm_qL",
                bracketParagraphContainer: "BracketPlayinMobile_bracketParagraphContainer__H_x_j",
                bracketParagraphTitle: "BracketPlayinMobile_bracketParagraphTitle__1Z48E",
                bracketParagraph: "BracketPlayinMobile_bracketParagraph__LGrVh",
                bracketParagraphFootnote: "BracketPlayinMobile_bracketParagraphFootnote__BwqEs"
            }
        },
        59158: function(e) {
            e.exports = {
                bracket: "BracketPlayoff_bracket__r5Oep",
                downloadButton: "BracketPlayoff_downloadButton__GyxBp",
                iconSpinner: "BracketPlayoff_iconSpinner__EHXXa",
                iconDownload: "BracketPlayoff_iconDownload__hkMNH",
                nav: "BracketPlayoff_nav__jZCS2",
                navInner: "BracketPlayoff_navInner__ZwU7z",
                main: "BracketPlayoff_main___xbX_",
                mainInner: "BracketPlayoff_mainInner__J4xr0"
            }
        },
        43887: function(e) {
            e.exports = {
                main: "BracketPlayoffMain_main__sEhkq",
                bg: "BracketPlayoffMain_bg__RNFl0",
                connectors: "BracketPlayoffMain_connectors__8Ql1l"
            }
        },
        91509: function(e) {
            e.exports = {
                nav: "BracketPlayoffNav_nav__Hc64d",
                bg: "BracketPlayoffNav_bg__FcCWB"
            }
        },
        59728: function(e) {
            e.exports = {
                matchupCardBackground: "BracketPlayoffTile_matchupCardBackground__1XvZU",
                matchupCardText: "BracketPlayoffTile_matchupCardText__DO7El",
                statusLiveIndicator: "BracketPlayoffTile_statusLiveIndicator__ILWLO",
                statusText: "BracketPlayoffTile_statusText__paLI_",
                tbdLogo: "BracketPlayoffTile_tbdLogo__jx_pG",
                bracketTile: "BracketPlayoffTile_bracketTile__b6l8c",
                broadcaster: "BracketPlayoffTile_broadcaster__L34mn",
                blackBorder: "BracketPlayoffTile_blackBorder___60FL",
                grayBorder: "BracketPlayoffTile_grayBorder__Eo3Pi"
            }
        }
    }
]);