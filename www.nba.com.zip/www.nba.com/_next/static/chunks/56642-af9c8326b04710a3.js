"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [56642], {
        54005: function(t, n, e) {
            e.d(n, {
                Nb1: function() {
                    return Ea
                },
                SOn: function() {
                    return Ta
                },
                LLu: function() {
                    return E
                },
                Khx: function() {
                    return k
                },
                _K_: function() {
                    return xr
                },
                $0Z: function() {
                    return ja
                },
                jsv: function() {
                    return Va
                },
                Wem: function() {
                    return u
                },
                Hh: function() {
                    return qr
                },
                A4v: function() {
                    return zr
                },
                RUJ: function() {
                    return Ir
                },
                Mrm: function() {
                    return jr
                },
                l49: function() {
                    return ro
                },
                sN9: function() {
                    return Ko
                },
                BT8: function() {
                    return Zo
                },
                jvg: function() {
                    return Pa
                },
                Fp7: function() {
                    return v
                },
                b1B: function() {
                    return tr
                },
                ve8: function() {
                    return Oa
                },
                tiA: function() {
                    return po
                },
                BYU: function() {
                    return $o
                },
                Ys: function() {
                    return Jo
                }
            });

            function r(t, n) {
                return t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
            }
            var i = function(t) {
                    var n;
                    return 1 === t.length && (n = t, t = function(t, e) {
                        return r(n(t), e)
                    }), {
                        left: function(n, e, r, i) {
                            for (null == r && (r = 0), null == i && (i = n.length); r < i;) {
                                var o = r + i >>> 1;
                                t(n[o], e) < 0 ? r = o + 1 : i = o
                            }
                            return r
                        },
                        right: function(n, e, r, i) {
                            for (null == r && (r = 0), null == i && (i = n.length); r < i;) {
                                var o = r + i >>> 1;
                                t(n[o], e) > 0 ? i = o : r = o + 1
                            }
                            return r
                        }
                    }
                }(r),
                o = i.right,
                a = (i.left, o);

            function u(t, n) {
                var e, r, i, o = t.length,
                    a = -1;
                if (null == n) {
                    for (; ++a < o;)
                        if (null != (e = t[a]) && e >= e)
                            for (r = i = e; ++a < o;) null != (e = t[a]) && (r > e && (r = e), i < e && (i = e))
                } else
                    for (; ++a < o;)
                        if (null != (e = n(t[a], a, t)) && e >= e)
                            for (r = i = e; ++a < o;) null != (e = n(t[a], a, t)) && (r > e && (r = e), i < e && (i = e));
                return [r, i]
            }
            var f = Array.prototype,
                c = (f.slice, f.map, Math.sqrt(50)),
                s = Math.sqrt(10),
                l = Math.sqrt(2);

            function h(t, n, e) {
                var r = (n - t) / Math.max(0, e),
                    i = Math.floor(Math.log(r) / Math.LN10),
                    o = r / Math.pow(10, i);
                return i >= 0 ? (o >= c ? 10 : o >= s ? 5 : o >= l ? 2 : 1) * Math.pow(10, i) : -Math.pow(10, -i) / (o >= c ? 10 : o >= s ? 5 : o >= l ? 2 : 1)
            }

            function d(t, n, e) {
                var r = Math.abs(n - t) / Math.max(0, e),
                    i = Math.pow(10, Math.floor(Math.log(r) / Math.LN10)),
                    o = r / i;
                return o >= c ? i *= 10 : o >= s ? i *= 5 : o >= l && (i *= 2), n < t ? -i : i
            }

            function p(t) {
                return Math.ceil(Math.log(t.length) / Math.LN2) + 1
            }

            function v(t, n) {
                var e, r, i = t.length,
                    o = -1;
                if (null == n) {
                    for (; ++o < i;)
                        if (null != (e = t[o]) && e >= e)
                            for (r = e; ++o < i;) null != (e = t[o]) && e > r && (r = e)
                } else
                    for (; ++o < i;)
                        if (null != (e = n(t[o], o, t)) && e >= e)
                            for (r = e; ++o < i;) null != (e = n(t[o], o, t)) && e > r && (r = e);
                return r
            }

            function g(t, n, e) {
                t = +t, n = +n, e = (i = arguments.length) < 2 ? (n = t, t = 0, 1) : i < 3 ? 1 : +e;
                for (var r = -1, i = 0 | Math.max(0, Math.ceil((n - t) / e)), o = new Array(i); ++r < i;) o[r] = t + r * e;
                return o
            }
            var y = Array.prototype.slice;

            function _(t) {
                return t
            }
            var b = 1e-6;

            function m(t) {
                return "translate(" + (t + .5) + ",0)"
            }

            function w(t) {
                return "translate(0," + (t + .5) + ")"
            }

            function x(t) {
                return function(n) {
                    return +t(n)
                }
            }

            function M(t) {
                var n = Math.max(0, t.bandwidth() - 1) / 2;
                return t.round() && (n = Math.round(n)),
                    function(e) {
                        return +t(e) + n
                    }
            }

            function N() {
                return !this.__axis
            }

            function A(t, n) {
                var e = [],
                    r = null,
                    i = null,
                    o = 6,
                    a = 6,
                    u = 3,
                    f = 1 === t || 4 === t ? -1 : 1,
                    c = 4 === t || 2 === t ? "x" : "y",
                    s = 1 === t || 3 === t ? m : w;

                function l(l) {
                    var h = null == r ? n.ticks ? n.ticks.apply(n, e) : n.domain() : r,
                        d = null == i ? n.tickFormat ? n.tickFormat.apply(n, e) : _ : i,
                        p = Math.max(o, 0) + u,
                        v = n.range(),
                        g = +v[0] + .5,
                        y = +v[v.length - 1] + .5,
                        m = (n.bandwidth ? M : x)(n.copy()),
                        w = l.selection ? l.selection() : l,
                        A = w.selectAll(".domain").data([null]),
                        k = w.selectAll(".tick").data(h, n).order(),
                        E = k.exit(),
                        S = k.enter().append("g").attr("class", "tick"),
                        C = k.select("line"),
                        L = k.select("text");
                    A = A.merge(A.enter().insert("path", ".tick").attr("class", "domain").attr("stroke", "currentColor")), k = k.merge(S), C = C.merge(S.append("line").attr("stroke", "currentColor").attr(c + "2", f * o)), L = L.merge(S.append("text").attr("fill", "currentColor").attr(c, f * p).attr("dy", 1 === t ? "0em" : 3 === t ? "0.71em" : "0.32em")), l !== w && (A = A.transition(l), k = k.transition(l), C = C.transition(l), L = L.transition(l), E = E.transition(l).attr("opacity", b).attr("transform", (function(t) {
                        return isFinite(t = m(t)) ? s(t) : this.getAttribute("transform")
                    })), S.attr("opacity", b).attr("transform", (function(t) {
                        var n = this.parentNode.__axis;
                        return s(n && isFinite(n = n(t)) ? n : m(t))
                    }))), E.remove(), A.attr("d", 4 === t || 2 == t ? a ? "M" + f * a + "," + g + "H0.5V" + y + "H" + f * a : "M0.5," + g + "V" + y : a ? "M" + g + "," + f * a + "V0.5H" + y + "V" + f * a : "M" + g + ",0.5H" + y), k.attr("opacity", 1).attr("transform", (function(t) {
                        return s(m(t))
                    })), C.attr(c + "2", f * o), L.attr(c, f * p).text(d), w.filter(N).attr("fill", "none").attr("font-size", 10).attr("font-family", "sans-serif").attr("text-anchor", 2 === t ? "start" : 4 === t ? "end" : "middle"), w.each((function() {
                        this.__axis = m
                    }))
                }
                return l.scale = function(t) {
                    return arguments.length ? (n = t, l) : n
                }, l.ticks = function() {
                    return e = y.call(arguments), l
                }, l.tickArguments = function(t) {
                    return arguments.length ? (e = null == t ? [] : y.call(t), l) : e.slice()
                }, l.tickValues = function(t) {
                    return arguments.length ? (r = null == t ? null : y.call(t), l) : r && r.slice()
                }, l.tickFormat = function(t) {
                    return arguments.length ? (i = t, l) : i
                }, l.tickSize = function(t) {
                    return arguments.length ? (o = a = +t, l) : o
                }, l.tickSizeInner = function(t) {
                    return arguments.length ? (o = +t, l) : o
                }, l.tickSizeOuter = function(t) {
                    return arguments.length ? (a = +t, l) : a
                }, l.tickPadding = function(t) {
                    return arguments.length ? (u = +t, l) : u
                }, l
            }

            function k(t) {
                return A(2, t)
            }

            function E(t) {
                return A(3, t)
            }

            function S() {}

            function C(t) {
                return null == t ? S : function() {
                    return this.querySelector(t)
                }
            }

            function L() {
                return []
            }

            function R(t) {
                return null == t ? L : function() {
                    return this.querySelectorAll(t)
                }
            }

            function P(t) {
                return function() {
                    return this.matches(t)
                }
            }

            function T(t) {
                return new Array(t.length)
            }

            function U(t, n) {
                this.ownerDocument = t.ownerDocument, this.namespaceURI = t.namespaceURI, this._next = null, this._parent = t, this.__data__ = n
            }
            U.prototype = {
                constructor: U,
                appendChild: function(t) {
                    return this._parent.insertBefore(t, this._next)
                },
                insertBefore: function(t, n) {
                    return this._parent.insertBefore(t, n)
                },
                querySelector: function(t) {
                    return this._parent.querySelector(t)
                },
                querySelectorAll: function(t) {
                    return this._parent.querySelectorAll(t)
                }
            };

            function q(t, n, e, r, i, o) {
                for (var a, u = 0, f = n.length, c = o.length; u < c; ++u)(a = n[u]) ? (a.__data__ = o[u], r[u] = a) : e[u] = new U(t, o[u]);
                for (; u < f; ++u)(a = n[u]) && (i[u] = a)
            }

            function O(t, n, e, r, i, o, a) {
                var u, f, c, s = {},
                    l = n.length,
                    h = o.length,
                    d = new Array(l);
                for (u = 0; u < l; ++u)(f = n[u]) && (d[u] = c = "$" + a.call(f, f.__data__, u, n), c in s ? i[u] = f : s[c] = f);
                for (u = 0; u < h; ++u)(f = s[c = "$" + a.call(t, o[u], u, o)]) ? (r[u] = f, f.__data__ = o[u], s[c] = null) : e[u] = new U(t, o[u]);
                for (u = 0; u < l; ++u)(f = n[u]) && s[d[u]] === f && (i[u] = f)
            }

            function z(t, n) {
                return t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
            }
            var I = "http://www.w3.org/1999/xhtml",
                j = {
                    svg: "http://www.w3.org/2000/svg",
                    xhtml: I,
                    xlink: "http://www.w3.org/1999/xlink",
                    xml: "http://www.w3.org/XML/1998/namespace",
                    xmlns: "http://www.w3.org/2000/xmlns/"
                };

            function B(t) {
                var n = t += "",
                    e = n.indexOf(":");
                return e >= 0 && "xmlns" !== (n = t.slice(0, e)) && (t = t.slice(e + 1)), j.hasOwnProperty(n) ? {
                    space: j[n],
                    local: t
                } : t
            }

            function V(t) {
                return function() {
                    this.removeAttribute(t)
                }
            }

            function D(t) {
                return function() {
                    this.removeAttributeNS(t.space, t.local)
                }
            }

            function X(t, n) {
                return function() {
                    this.setAttribute(t, n)
                }
            }

            function F(t, n) {
                return function() {
                    this.setAttributeNS(t.space, t.local, n)
                }
            }

            function H(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    null == e ? this.removeAttribute(t) : this.setAttribute(t, e)
                }
            }

            function Y(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    null == e ? this.removeAttributeNS(t.space, t.local) : this.setAttributeNS(t.space, t.local, e)
                }
            }

            function $(t) {
                return t.ownerDocument && t.ownerDocument.defaultView || t.document && t || t.defaultView
            }

            function G(t) {
                return function() {
                    this.style.removeProperty(t)
                }
            }

            function Z(t, n, e) {
                return function() {
                    this.style.setProperty(t, n, e)
                }
            }

            function W(t, n, e) {
                return function() {
                    var r = n.apply(this, arguments);
                    null == r ? this.style.removeProperty(t) : this.style.setProperty(t, r, e)
                }
            }

            function K(t, n) {
                return t.style.getPropertyValue(n) || $(t).getComputedStyle(t, null).getPropertyValue(n)
            }

            function J(t) {
                return function() {
                    delete this[t]
                }
            }

            function Q(t, n) {
                return function() {
                    this[t] = n
                }
            }

            function tt(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    null == e ? delete this[t] : this[t] = e
                }
            }

            function nt(t) {
                return t.trim().split(/^|\s+/)
            }

            function et(t) {
                return t.classList || new rt(t)
            }

            function rt(t) {
                this._node = t, this._names = nt(t.getAttribute("class") || "")
            }

            function it(t, n) {
                for (var e = et(t), r = -1, i = n.length; ++r < i;) e.add(n[r])
            }

            function ot(t, n) {
                for (var e = et(t), r = -1, i = n.length; ++r < i;) e.remove(n[r])
            }

            function at(t) {
                return function() {
                    it(this, t)
                }
            }

            function ut(t) {
                return function() {
                    ot(this, t)
                }
            }

            function ft(t, n) {
                return function() {
                    (n.apply(this, arguments) ? it : ot)(this, t)
                }
            }

            function ct() {
                this.textContent = ""
            }

            function st(t) {
                return function() {
                    this.textContent = t
                }
            }

            function lt(t) {
                return function() {
                    var n = t.apply(this, arguments);
                    this.textContent = null == n ? "" : n
                }
            }

            function ht() {
                this.innerHTML = ""
            }

            function dt(t) {
                return function() {
                    this.innerHTML = t
                }
            }

            function pt(t) {
                return function() {
                    var n = t.apply(this, arguments);
                    this.innerHTML = null == n ? "" : n
                }
            }

            function vt() {
                this.nextSibling && this.parentNode.appendChild(this)
            }

            function gt() {
                this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild)
            }

            function yt(t) {
                return function() {
                    var n = this.ownerDocument,
                        e = this.namespaceURI;
                    return e === I && n.documentElement.namespaceURI === I ? n.createElement(t) : n.createElementNS(e, t)
                }
            }

            function _t(t) {
                return function() {
                    return this.ownerDocument.createElementNS(t.space, t.local)
                }
            }

            function bt(t) {
                var n = B(t);
                return (n.local ? _t : yt)(n)
            }

            function mt() {
                return null
            }

            function wt() {
                var t = this.parentNode;
                t && t.removeChild(this)
            }

            function xt() {
                var t = this.cloneNode(!1),
                    n = this.parentNode;
                return n ? n.insertBefore(t, this.nextSibling) : t
            }

            function Mt() {
                var t = this.cloneNode(!0),
                    n = this.parentNode;
                return n ? n.insertBefore(t, this.nextSibling) : t
            }
            rt.prototype = {
                add: function(t) {
                    this._names.indexOf(t) < 0 && (this._names.push(t), this._node.setAttribute("class", this._names.join(" ")))
                },
                remove: function(t) {
                    var n = this._names.indexOf(t);
                    n >= 0 && (this._names.splice(n, 1), this._node.setAttribute("class", this._names.join(" ")))
                },
                contains: function(t) {
                    return this._names.indexOf(t) >= 0
                }
            };
            var Nt = {},
                At = null;
            "undefined" !== typeof document && ("onmouseenter" in document.documentElement || (Nt = {
                mouseenter: "mouseover",
                mouseleave: "mouseout"
            }));

            function kt(t, n, e) {
                return t = Et(t, n, e),
                    function(n) {
                        var e = n.relatedTarget;
                        e && (e === this || 8 & e.compareDocumentPosition(this)) || t.call(this, n)
                    }
            }

            function Et(t, n, e) {
                return function(r) {
                    var i = At;
                    At = r;
                    try {
                        t.call(this, this.__data__, n, e)
                    } finally {
                        At = i
                    }
                }
            }

            function St(t) {
                return t.trim().split(/^|\s+/).map((function(t) {
                    var n = "",
                        e = t.indexOf(".");
                    return e >= 0 && (n = t.slice(e + 1), t = t.slice(0, e)), {
                        type: t,
                        name: n
                    }
                }))
            }

            function Ct(t) {
                return function() {
                    var n = this.__on;
                    if (n) {
                        for (var e, r = 0, i = -1, o = n.length; r < o; ++r) e = n[r], t.type && e.type !== t.type || e.name !== t.name ? n[++i] = e : this.removeEventListener(e.type, e.listener, e.capture);
                        ++i ? n.length = i : delete this.__on
                    }
                }
            }

            function Lt(t, n, e) {
                var r = Nt.hasOwnProperty(t.type) ? kt : Et;
                return function(i, o, a) {
                    var u, f = this.__on,
                        c = r(n, o, a);
                    if (f)
                        for (var s = 0, l = f.length; s < l; ++s)
                            if ((u = f[s]).type === t.type && u.name === t.name) return this.removeEventListener(u.type, u.listener, u.capture), this.addEventListener(u.type, u.listener = c, u.capture = e), void(u.value = n);
                    this.addEventListener(t.type, c, e), u = {
                        type: t.type,
                        name: t.name,
                        value: n,
                        listener: c,
                        capture: e
                    }, f ? f.push(u) : this.__on = [u]
                }
            }

            function Rt(t, n, e) {
                var r = $(t),
                    i = r.CustomEvent;
                "function" === typeof i ? i = new i(n, e) : (i = r.document.createEvent("Event"), e ? (i.initEvent(n, e.bubbles, e.cancelable), i.detail = e.detail) : i.initEvent(n, !1, !1)), t.dispatchEvent(i)
            }

            function Pt(t, n) {
                return function() {
                    return Rt(this, t, n)
                }
            }

            function Tt(t, n) {
                return function() {
                    return Rt(this, t, n.apply(this, arguments))
                }
            }
            var Ut = [null];

            function qt(t, n) {
                this._groups = t, this._parents = n
            }

            function Ot() {
                return new qt([
                    [document.documentElement]
                ], Ut)
            }
            qt.prototype = Ot.prototype = {
                constructor: qt,
                select: function(t) {
                    "function" !== typeof t && (t = C(t));
                    for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                        for (var o, a, u = n[i], f = u.length, c = r[i] = new Array(f), s = 0; s < f; ++s)(o = u[s]) && (a = t.call(o, o.__data__, s, u)) && ("__data__" in o && (a.__data__ = o.__data__), c[s] = a);
                    return new qt(r, this._parents)
                },
                selectAll: function(t) {
                    "function" !== typeof t && (t = R(t));
                    for (var n = this._groups, e = n.length, r = [], i = [], o = 0; o < e; ++o)
                        for (var a, u = n[o], f = u.length, c = 0; c < f; ++c)(a = u[c]) && (r.push(t.call(a, a.__data__, c, u)), i.push(a));
                    return new qt(r, i)
                },
                filter: function(t) {
                    "function" !== typeof t && (t = P(t));
                    for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                        for (var o, a = n[i], u = a.length, f = r[i] = [], c = 0; c < u; ++c)(o = a[c]) && t.call(o, o.__data__, c, a) && f.push(o);
                    return new qt(r, this._parents)
                },
                data: function(t, n) {
                    if (!t) return d = new Array(this.size()), c = -1, this.each((function(t) {
                        d[++c] = t
                    })), d;
                    var e = n ? O : q,
                        r = this._parents,
                        i = this._groups;
                    "function" !== typeof t && (t = function(t) {
                        return function() {
                            return t
                        }
                    }(t));
                    for (var o = i.length, a = new Array(o), u = new Array(o), f = new Array(o), c = 0; c < o; ++c) {
                        var s = r[c],
                            l = i[c],
                            h = l.length,
                            d = t.call(s, s && s.__data__, c, r),
                            p = d.length,
                            v = u[c] = new Array(p),
                            g = a[c] = new Array(p);
                        e(s, l, v, g, f[c] = new Array(h), d, n);
                        for (var y, _, b = 0, m = 0; b < p; ++b)
                            if (y = v[b]) {
                                for (b >= m && (m = b + 1); !(_ = g[m]) && ++m < p;);
                                y._next = _ || null
                            }
                    }
                    return (a = new qt(a, r))._enter = u, a._exit = f, a
                },
                enter: function() {
                    return new qt(this._enter || this._groups.map(T), this._parents)
                },
                exit: function() {
                    return new qt(this._exit || this._groups.map(T), this._parents)
                },
                join: function(t, n, e) {
                    var r = this.enter(),
                        i = this,
                        o = this.exit();
                    return r = "function" === typeof t ? t(r) : r.append(t + ""), null != n && (i = n(i)), null == e ? o.remove() : e(o), r && i ? r.merge(i).order() : i
                },
                merge: function(t) {
                    for (var n = this._groups, e = t._groups, r = n.length, i = e.length, o = Math.min(r, i), a = new Array(r), u = 0; u < o; ++u)
                        for (var f, c = n[u], s = e[u], l = c.length, h = a[u] = new Array(l), d = 0; d < l; ++d)(f = c[d] || s[d]) && (h[d] = f);
                    for (; u < r; ++u) a[u] = n[u];
                    return new qt(a, this._parents)
                },
                order: function() {
                    for (var t = this._groups, n = -1, e = t.length; ++n < e;)
                        for (var r, i = t[n], o = i.length - 1, a = i[o]; --o >= 0;)(r = i[o]) && (a && 4 ^ r.compareDocumentPosition(a) && a.parentNode.insertBefore(r, a), a = r);
                    return this
                },
                sort: function(t) {
                    function n(n, e) {
                        return n && e ? t(n.__data__, e.__data__) : !n - !e
                    }
                    t || (t = z);
                    for (var e = this._groups, r = e.length, i = new Array(r), o = 0; o < r; ++o) {
                        for (var a, u = e[o], f = u.length, c = i[o] = new Array(f), s = 0; s < f; ++s)(a = u[s]) && (c[s] = a);
                        c.sort(n)
                    }
                    return new qt(i, this._parents).order()
                },
                call: function() {
                    var t = arguments[0];
                    return arguments[0] = this, t.apply(null, arguments), this
                },
                nodes: function() {
                    var t = new Array(this.size()),
                        n = -1;
                    return this.each((function() {
                        t[++n] = this
                    })), t
                },
                node: function() {
                    for (var t = this._groups, n = 0, e = t.length; n < e; ++n)
                        for (var r = t[n], i = 0, o = r.length; i < o; ++i) {
                            var a = r[i];
                            if (a) return a
                        }
                    return null
                },
                size: function() {
                    var t = 0;
                    return this.each((function() {
                        ++t
                    })), t
                },
                empty: function() {
                    return !this.node()
                },
                each: function(t) {
                    for (var n = this._groups, e = 0, r = n.length; e < r; ++e)
                        for (var i, o = n[e], a = 0, u = o.length; a < u; ++a)(i = o[a]) && t.call(i, i.__data__, a, o);
                    return this
                },
                attr: function(t, n) {
                    var e = B(t);
                    if (arguments.length < 2) {
                        var r = this.node();
                        return e.local ? r.getAttributeNS(e.space, e.local) : r.getAttribute(e)
                    }
                    return this.each((null == n ? e.local ? D : V : "function" === typeof n ? e.local ? Y : H : e.local ? F : X)(e, n))
                },
                style: function(t, n, e) {
                    return arguments.length > 1 ? this.each((null == n ? G : "function" === typeof n ? W : Z)(t, n, null == e ? "" : e)) : K(this.node(), t)
                },
                property: function(t, n) {
                    return arguments.length > 1 ? this.each((null == n ? J : "function" === typeof n ? tt : Q)(t, n)) : this.node()[t]
                },
                classed: function(t, n) {
                    var e = nt(t + "");
                    if (arguments.length < 2) {
                        for (var r = et(this.node()), i = -1, o = e.length; ++i < o;)
                            if (!r.contains(e[i])) return !1;
                        return !0
                    }
                    return this.each(("function" === typeof n ? ft : n ? at : ut)(e, n))
                },
                text: function(t) {
                    return arguments.length ? this.each(null == t ? ct : ("function" === typeof t ? lt : st)(t)) : this.node().textContent
                },
                html: function(t) {
                    return arguments.length ? this.each(null == t ? ht : ("function" === typeof t ? pt : dt)(t)) : this.node().innerHTML
                },
                raise: function() {
                    return this.each(vt)
                },
                lower: function() {
                    return this.each(gt)
                },
                append: function(t) {
                    var n = "function" === typeof t ? t : bt(t);
                    return this.select((function() {
                        return this.appendChild(n.apply(this, arguments))
                    }))
                },
                insert: function(t, n) {
                    var e = "function" === typeof t ? t : bt(t),
                        r = null == n ? mt : "function" === typeof n ? n : C(n);
                    return this.select((function() {
                        return this.insertBefore(e.apply(this, arguments), r.apply(this, arguments) || null)
                    }))
                },
                remove: function() {
                    return this.each(wt)
                },
                clone: function(t) {
                    return this.select(t ? Mt : xt)
                },
                datum: function(t) {
                    return arguments.length ? this.property("__data__", t) : this.node().__data__
                },
                on: function(t, n, e) {
                    var r, i, o = St(t + ""),
                        a = o.length;
                    if (!(arguments.length < 2)) {
                        for (u = n ? Lt : Ct, null == e && (e = !1), r = 0; r < a; ++r) this.each(u(o[r], n, e));
                        return this
                    }
                    var u = this.node().__on;
                    if (u)
                        for (var f, c = 0, s = u.length; c < s; ++c)
                            for (r = 0, f = u[c]; r < a; ++r)
                                if ((i = o[r]).type === f.type && i.name === f.name) return f.value
                },
                dispatch: function(t, n) {
                    return this.each(("function" === typeof n ? Tt : Pt)(t, n))
                }
            };
            var zt = Ot,
                It = {
                    value: function() {}
                };

            function jt() {
                for (var t, n = 0, e = arguments.length, r = {}; n < e; ++n) {
                    if (!(t = arguments[n] + "") || t in r || /[\s.]/.test(t)) throw new Error("illegal type: " + t);
                    r[t] = []
                }
                return new Bt(r)
            }

            function Bt(t) {
                this._ = t
            }

            function Vt(t, n) {
                return t.trim().split(/^|\s+/).map((function(t) {
                    var e = "",
                        r = t.indexOf(".");
                    if (r >= 0 && (e = t.slice(r + 1), t = t.slice(0, r)), t && !n.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                    return {
                        type: t,
                        name: e
                    }
                }))
            }

            function Dt(t, n) {
                for (var e, r = 0, i = t.length; r < i; ++r)
                    if ((e = t[r]).name === n) return e.value
            }

            function Xt(t, n, e) {
                for (var r = 0, i = t.length; r < i; ++r)
                    if (t[r].name === n) {
                        t[r] = It, t = t.slice(0, r).concat(t.slice(r + 1));
                        break
                    }
                return null != e && t.push({
                    name: n,
                    value: e
                }), t
            }
            Bt.prototype = jt.prototype = {
                constructor: Bt,
                on: function(t, n) {
                    var e, r = this._,
                        i = Vt(t + "", r),
                        o = -1,
                        a = i.length;
                    if (!(arguments.length < 2)) {
                        if (null != n && "function" !== typeof n) throw new Error("invalid callback: " + n);
                        for (; ++o < a;)
                            if (e = (t = i[o]).type) r[e] = Xt(r[e], t.name, n);
                            else if (null == n)
                            for (e in r) r[e] = Xt(r[e], t.name, null);
                        return this
                    }
                    for (; ++o < a;)
                        if ((e = (t = i[o]).type) && (e = Dt(r[e], t.name))) return e
                },
                copy: function() {
                    var t = {},
                        n = this._;
                    for (var e in n) t[e] = n[e].slice();
                    return new Bt(t)
                },
                call: function(t, n) {
                    if ((e = arguments.length - 2) > 0)
                        for (var e, r, i = new Array(e), o = 0; o < e; ++o) i[o] = arguments[o + 2];
                    if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                    for (o = 0, e = (r = this._[t]).length; o < e; ++o) r[o].value.apply(n, i)
                },
                apply: function(t, n, e) {
                    if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                    for (var r = this._[t], i = 0, o = r.length; i < o; ++i) r[i].value.apply(n, e)
                }
            };
            var Ft, Ht, Yt = jt,
                $t = 0,
                Gt = 0,
                Zt = 0,
                Wt = 0,
                Kt = 0,
                Jt = 0,
                Qt = "object" === typeof performance && performance.now ? performance : Date,
                tn = "object" === typeof window && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(t) {
                    setTimeout(t, 17)
                };

            function nn() {
                return Kt || (tn(en), Kt = Qt.now() + Jt)
            }

            function en() {
                Kt = 0
            }

            function rn() {
                this._call = this._time = this._next = null
            }

            function on(t, n, e) {
                var r = new rn;
                return r.restart(t, n, e), r
            }

            function an() {
                Kt = (Wt = Qt.now()) + Jt, $t = Gt = 0;
                try {
                    ! function() {
                        nn(), ++$t;
                        for (var t, n = Ft; n;)(t = Kt - n._time) >= 0 && n._call.call(null, t), n = n._next;
                        --$t
                    }()
                } finally {
                    $t = 0,
                        function() {
                            var t, n, e = Ft,
                                r = 1 / 0;
                            for (; e;) e._call ? (r > e._time && (r = e._time), t = e, e = e._next) : (n = e._next, e._next = null, e = t ? t._next = n : Ft = n);
                            Ht = t, fn(r)
                        }(), Kt = 0
                }
            }

            function un() {
                var t = Qt.now(),
                    n = t - Wt;
                n > 1e3 && (Jt -= n, Wt = t)
            }

            function fn(t) {
                $t || (Gt && (Gt = clearTimeout(Gt)), t - Kt > 24 ? (t < 1 / 0 && (Gt = setTimeout(an, t - Qt.now() - Jt)), Zt && (Zt = clearInterval(Zt))) : (Zt || (Wt = Qt.now(), Zt = setInterval(un, 1e3)), $t = 1, tn(an)))
            }

            function cn(t, n, e) {
                var r = new rn;
                return n = null == n ? 0 : +n, r.restart((function(e) {
                    r.stop(), t(e + n)
                }), n, e), r
            }
            rn.prototype = on.prototype = {
                constructor: rn,
                restart: function(t, n, e) {
                    if ("function" !== typeof t) throw new TypeError("callback is not a function");
                    e = (null == e ? nn() : +e) + (null == n ? 0 : +n), this._next || Ht === this || (Ht ? Ht._next = this : Ft = this, Ht = this), this._call = t, this._time = e, fn()
                },
                stop: function() {
                    this._call && (this._call = null, this._time = 1 / 0, fn())
                }
            };
            var sn = Yt("start", "end", "cancel", "interrupt"),
                ln = [];

            function hn(t, n, e, r, i, o) {
                var a = t.__transition;
                if (a) {
                    if (e in a) return
                } else t.__transition = {};
                ! function(t, n, e) {
                    var r, i = t.__transition;

                    function o(t) {
                        e.state = 1, e.timer.restart(a, e.delay, e.time), e.delay <= t && a(t - e.delay)
                    }

                    function a(o) {
                        var c, s, l, h;
                        if (1 !== e.state) return f();
                        for (c in i)
                            if ((h = i[c]).name === e.name) {
                                if (3 === h.state) return cn(a);
                                4 === h.state ? (h.state = 6, h.timer.stop(), h.on.call("interrupt", t, t.__data__, h.index, h.group), delete i[c]) : +c < n && (h.state = 6, h.timer.stop(), h.on.call("cancel", t, t.__data__, h.index, h.group), delete i[c])
                            }
                        if (cn((function() {
                                3 === e.state && (e.state = 4, e.timer.restart(u, e.delay, e.time), u(o))
                            })), e.state = 2, e.on.call("start", t, t.__data__, e.index, e.group), 2 === e.state) {
                            for (e.state = 3, r = new Array(l = e.tween.length), c = 0, s = -1; c < l; ++c)(h = e.tween[c].value.call(t, t.__data__, e.index, e.group)) && (r[++s] = h);
                            r.length = s + 1
                        }
                    }

                    function u(n) {
                        for (var i = n < e.duration ? e.ease.call(null, n / e.duration) : (e.timer.restart(f), e.state = 5, 1), o = -1, a = r.length; ++o < a;) r[o].call(t, i);
                        5 === e.state && (e.on.call("end", t, t.__data__, e.index, e.group), f())
                    }

                    function f() {
                        for (var r in e.state = 6, e.timer.stop(), delete i[n], i) return;
                        delete t.__transition
                    }
                    i[n] = e, e.timer = on(o, 0, e.time)
                }(t, e, {
                    name: n,
                    index: r,
                    group: i,
                    on: sn,
                    tween: ln,
                    time: o.time,
                    delay: o.delay,
                    duration: o.duration,
                    ease: o.ease,
                    timer: null,
                    state: 0
                })
            }

            function dn(t, n) {
                var e = vn(t, n);
                if (e.state > 0) throw new Error("too late; already scheduled");
                return e
            }

            function pn(t, n) {
                var e = vn(t, n);
                if (e.state > 3) throw new Error("too late; already running");
                return e
            }

            function vn(t, n) {
                var e = t.__transition;
                if (!e || !(e = e[n])) throw new Error("transition not found");
                return e
            }

            function gn(t, n) {
                return t = +t, n = +n,
                    function(e) {
                        return t * (1 - e) + n * e
                    }
            }
            var yn, _n, bn, mn, wn = 180 / Math.PI,
                xn = {
                    translateX: 0,
                    translateY: 0,
                    rotate: 0,
                    skewX: 0,
                    scaleX: 1,
                    scaleY: 1
                };

            function Mn(t, n, e, r, i, o) {
                var a, u, f;
                return (a = Math.sqrt(t * t + n * n)) && (t /= a, n /= a), (f = t * e + n * r) && (e -= t * f, r -= n * f), (u = Math.sqrt(e * e + r * r)) && (e /= u, r /= u, f /= u), t * r < n * e && (t = -t, n = -n, f = -f, a = -a), {
                    translateX: i,
                    translateY: o,
                    rotate: Math.atan2(n, t) * wn,
                    skewX: Math.atan(f) * wn,
                    scaleX: a,
                    scaleY: u
                }
            }

            function Nn(t, n, e, r) {
                function i(t) {
                    return t.length ? t.pop() + " " : ""
                }
                return function(o, a) {
                    var u = [],
                        f = [];
                    return o = t(o), a = t(a),
                        function(t, r, i, o, a, u) {
                            if (t !== i || r !== o) {
                                var f = a.push("translate(", null, n, null, e);
                                u.push({
                                    i: f - 4,
                                    x: gn(t, i)
                                }, {
                                    i: f - 2,
                                    x: gn(r, o)
                                })
                            } else(i || o) && a.push("translate(" + i + n + o + e)
                        }(o.translateX, o.translateY, a.translateX, a.translateY, u, f),
                        function(t, n, e, o) {
                            t !== n ? (t - n > 180 ? n += 360 : n - t > 180 && (t += 360), o.push({
                                i: e.push(i(e) + "rotate(", null, r) - 2,
                                x: gn(t, n)
                            })) : n && e.push(i(e) + "rotate(" + n + r)
                        }(o.rotate, a.rotate, u, f),
                        function(t, n, e, o) {
                            t !== n ? o.push({
                                i: e.push(i(e) + "skewX(", null, r) - 2,
                                x: gn(t, n)
                            }) : n && e.push(i(e) + "skewX(" + n + r)
                        }(o.skewX, a.skewX, u, f),
                        function(t, n, e, r, o, a) {
                            if (t !== e || n !== r) {
                                var u = o.push(i(o) + "scale(", null, ",", null, ")");
                                a.push({
                                    i: u - 4,
                                    x: gn(t, e)
                                }, {
                                    i: u - 2,
                                    x: gn(n, r)
                                })
                            } else 1 === e && 1 === r || o.push(i(o) + "scale(" + e + "," + r + ")")
                        }(o.scaleX, o.scaleY, a.scaleX, a.scaleY, u, f), o = a = null,
                        function(t) {
                            for (var n, e = -1, r = f.length; ++e < r;) u[(n = f[e]).i] = n.x(t);
                            return u.join("")
                        }
                }
            }
            var An = Nn((function(t) {
                    return "none" === t ? xn : (yn || (yn = document.createElement("DIV"), _n = document.documentElement, bn = document.defaultView), yn.style.transform = t, t = bn.getComputedStyle(_n.appendChild(yn), null).getPropertyValue("transform"), _n.removeChild(yn), Mn(+(t = t.slice(7, -1).split(","))[0], +t[1], +t[2], +t[3], +t[4], +t[5]))
                }), "px, ", "px)", "deg)"),
                kn = Nn((function(t) {
                    return null == t ? xn : (mn || (mn = document.createElementNS("http://www.w3.org/2000/svg", "g")), mn.setAttribute("transform", t), (t = mn.transform.baseVal.consolidate()) ? Mn((t = t.matrix).a, t.b, t.c, t.d, t.e, t.f) : xn)
                }), ", ", ")", ")");

            function En(t, n) {
                var e, r;
                return function() {
                    var i = pn(this, t),
                        o = i.tween;
                    if (o !== e)
                        for (var a = 0, u = (r = e = o).length; a < u; ++a)
                            if (r[a].name === n) {
                                (r = r.slice()).splice(a, 1);
                                break
                            }
                    i.tween = r
                }
            }

            function Sn(t, n, e) {
                var r, i;
                if ("function" !== typeof e) throw new Error;
                return function() {
                    var o = pn(this, t),
                        a = o.tween;
                    if (a !== r) {
                        i = (r = a).slice();
                        for (var u = {
                                name: n,
                                value: e
                            }, f = 0, c = i.length; f < c; ++f)
                            if (i[f].name === n) {
                                i[f] = u;
                                break
                            }
                        f === c && i.push(u)
                    }
                    o.tween = i
                }
            }

            function Cn(t, n, e) {
                var r = t._id;
                return t.each((function() {
                        var t = pn(this, r);
                        (t.value || (t.value = {}))[n] = e.apply(this, arguments)
                    })),
                    function(t) {
                        return vn(t, r).value[n]
                    }
            }

            function Ln(t, n, e) {
                t.prototype = n.prototype = e, e.constructor = t
            }

            function Rn(t, n) {
                var e = Object.create(t.prototype);
                for (var r in n) e[r] = n[r];
                return e
            }

            function Pn() {}
            var Tn = .7,
                Un = 1 / Tn,
                qn = "\\s*([+-]?\\d+)\\s*",
                On = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
                zn = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
                In = /^#([0-9a-f]{3,8})$/,
                jn = new RegExp("^rgb\\(" + [qn, qn, qn] + "\\)$"),
                Bn = new RegExp("^rgb\\(" + [zn, zn, zn] + "\\)$"),
                Vn = new RegExp("^rgba\\(" + [qn, qn, qn, On] + "\\)$"),
                Dn = new RegExp("^rgba\\(" + [zn, zn, zn, On] + "\\)$"),
                Xn = new RegExp("^hsl\\(" + [On, zn, zn] + "\\)$"),
                Fn = new RegExp("^hsla\\(" + [On, zn, zn, On] + "\\)$"),
                Hn = {
                    aliceblue: 15792383,
                    antiquewhite: 16444375,
                    aqua: 65535,
                    aquamarine: 8388564,
                    azure: 15794175,
                    beige: 16119260,
                    bisque: 16770244,
                    black: 0,
                    blanchedalmond: 16772045,
                    blue: 255,
                    blueviolet: 9055202,
                    brown: 10824234,
                    burlywood: 14596231,
                    cadetblue: 6266528,
                    chartreuse: 8388352,
                    chocolate: 13789470,
                    coral: 16744272,
                    cornflowerblue: 6591981,
                    cornsilk: 16775388,
                    crimson: 14423100,
                    cyan: 65535,
                    darkblue: 139,
                    darkcyan: 35723,
                    darkgoldenrod: 12092939,
                    darkgray: 11119017,
                    darkgreen: 25600,
                    darkgrey: 11119017,
                    darkkhaki: 12433259,
                    darkmagenta: 9109643,
                    darkolivegreen: 5597999,
                    darkorange: 16747520,
                    darkorchid: 10040012,
                    darkred: 9109504,
                    darksalmon: 15308410,
                    darkseagreen: 9419919,
                    darkslateblue: 4734347,
                    darkslategray: 3100495,
                    darkslategrey: 3100495,
                    darkturquoise: 52945,
                    darkviolet: 9699539,
                    deeppink: 16716947,
                    deepskyblue: 49151,
                    dimgray: 6908265,
                    dimgrey: 6908265,
                    dodgerblue: 2003199,
                    firebrick: 11674146,
                    floralwhite: 16775920,
                    forestgreen: 2263842,
                    fuchsia: 16711935,
                    gainsboro: 14474460,
                    ghostwhite: 16316671,
                    gold: 16766720,
                    goldenrod: 14329120,
                    gray: 8421504,
                    green: 32768,
                    greenyellow: 11403055,
                    grey: 8421504,
                    honeydew: 15794160,
                    hotpink: 16738740,
                    indianred: 13458524,
                    indigo: 4915330,
                    ivory: 16777200,
                    khaki: 15787660,
                    lavender: 15132410,
                    lavenderblush: 16773365,
                    lawngreen: 8190976,
                    lemonchiffon: 16775885,
                    lightblue: 11393254,
                    lightcoral: 15761536,
                    lightcyan: 14745599,
                    lightgoldenrodyellow: 16448210,
                    lightgray: 13882323,
                    lightgreen: 9498256,
                    lightgrey: 13882323,
                    lightpink: 16758465,
                    lightsalmon: 16752762,
                    lightseagreen: 2142890,
                    lightskyblue: 8900346,
                    lightslategray: 7833753,
                    lightslategrey: 7833753,
                    lightsteelblue: 11584734,
                    lightyellow: 16777184,
                    lime: 65280,
                    limegreen: 3329330,
                    linen: 16445670,
                    magenta: 16711935,
                    maroon: 8388608,
                    mediumaquamarine: 6737322,
                    mediumblue: 205,
                    mediumorchid: 12211667,
                    mediumpurple: 9662683,
                    mediumseagreen: 3978097,
                    mediumslateblue: 8087790,
                    mediumspringgreen: 64154,
                    mediumturquoise: 4772300,
                    mediumvioletred: 13047173,
                    midnightblue: 1644912,
                    mintcream: 16121850,
                    mistyrose: 16770273,
                    moccasin: 16770229,
                    navajowhite: 16768685,
                    navy: 128,
                    oldlace: 16643558,
                    olive: 8421376,
                    olivedrab: 7048739,
                    orange: 16753920,
                    orangered: 16729344,
                    orchid: 14315734,
                    palegoldenrod: 15657130,
                    palegreen: 10025880,
                    paleturquoise: 11529966,
                    palevioletred: 14381203,
                    papayawhip: 16773077,
                    peachpuff: 16767673,
                    peru: 13468991,
                    pink: 16761035,
                    plum: 14524637,
                    powderblue: 11591910,
                    purple: 8388736,
                    rebeccapurple: 6697881,
                    red: 16711680,
                    rosybrown: 12357519,
                    royalblue: 4286945,
                    saddlebrown: 9127187,
                    salmon: 16416882,
                    sandybrown: 16032864,
                    seagreen: 3050327,
                    seashell: 16774638,
                    sienna: 10506797,
                    silver: 12632256,
                    skyblue: 8900331,
                    slateblue: 6970061,
                    slategray: 7372944,
                    slategrey: 7372944,
                    snow: 16775930,
                    springgreen: 65407,
                    steelblue: 4620980,
                    tan: 13808780,
                    teal: 32896,
                    thistle: 14204888,
                    tomato: 16737095,
                    turquoise: 4251856,
                    violet: 15631086,
                    wheat: 16113331,
                    white: 16777215,
                    whitesmoke: 16119285,
                    yellow: 16776960,
                    yellowgreen: 10145074
                };

            function Yn() {
                return this.rgb().formatHex()
            }

            function $n() {
                return this.rgb().formatRgb()
            }

            function Gn(t) {
                var n, e;
                return t = (t + "").trim().toLowerCase(), (n = In.exec(t)) ? (e = n[1].length, n = parseInt(n[1], 16), 6 === e ? Zn(n) : 3 === e ? new Qn(n >> 8 & 15 | n >> 4 & 240, n >> 4 & 15 | 240 & n, (15 & n) << 4 | 15 & n, 1) : 8 === e ? Wn(n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, (255 & n) / 255) : 4 === e ? Wn(n >> 12 & 15 | n >> 8 & 240, n >> 8 & 15 | n >> 4 & 240, n >> 4 & 15 | 240 & n, ((15 & n) << 4 | 15 & n) / 255) : null) : (n = jn.exec(t)) ? new Qn(n[1], n[2], n[3], 1) : (n = Bn.exec(t)) ? new Qn(255 * n[1] / 100, 255 * n[2] / 100, 255 * n[3] / 100, 1) : (n = Vn.exec(t)) ? Wn(n[1], n[2], n[3], n[4]) : (n = Dn.exec(t)) ? Wn(255 * n[1] / 100, 255 * n[2] / 100, 255 * n[3] / 100, n[4]) : (n = Xn.exec(t)) ? re(n[1], n[2] / 100, n[3] / 100, 1) : (n = Fn.exec(t)) ? re(n[1], n[2] / 100, n[3] / 100, n[4]) : Hn.hasOwnProperty(t) ? Zn(Hn[t]) : "transparent" === t ? new Qn(NaN, NaN, NaN, 0) : null
            }

            function Zn(t) {
                return new Qn(t >> 16 & 255, t >> 8 & 255, 255 & t, 1)
            }

            function Wn(t, n, e, r) {
                return r <= 0 && (t = n = e = NaN), new Qn(t, n, e, r)
            }

            function Kn(t) {
                return t instanceof Pn || (t = Gn(t)), t ? new Qn((t = t.rgb()).r, t.g, t.b, t.opacity) : new Qn
            }

            function Jn(t, n, e, r) {
                return 1 === arguments.length ? Kn(t) : new Qn(t, n, e, null == r ? 1 : r)
            }

            function Qn(t, n, e, r) {
                this.r = +t, this.g = +n, this.b = +e, this.opacity = +r
            }

            function te() {
                return "#" + ee(this.r) + ee(this.g) + ee(this.b)
            }

            function ne() {
                var t = this.opacity;
                return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "rgb(" : "rgba(") + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.b) || 0)) + (1 === t ? ")" : ", " + t + ")")
            }

            function ee(t) {
                return ((t = Math.max(0, Math.min(255, Math.round(t) || 0))) < 16 ? "0" : "") + t.toString(16)
            }

            function re(t, n, e, r) {
                return r <= 0 ? t = n = e = NaN : e <= 0 || e >= 1 ? t = n = NaN : n <= 0 && (t = NaN), new oe(t, n, e, r)
            }

            function ie(t) {
                if (t instanceof oe) return new oe(t.h, t.s, t.l, t.opacity);
                if (t instanceof Pn || (t = Gn(t)), !t) return new oe;
                if (t instanceof oe) return t;
                var n = (t = t.rgb()).r / 255,
                    e = t.g / 255,
                    r = t.b / 255,
                    i = Math.min(n, e, r),
                    o = Math.max(n, e, r),
                    a = NaN,
                    u = o - i,
                    f = (o + i) / 2;
                return u ? (a = n === o ? (e - r) / u + 6 * (e < r) : e === o ? (r - n) / u + 2 : (n - e) / u + 4, u /= f < .5 ? o + i : 2 - o - i, a *= 60) : u = f > 0 && f < 1 ? 0 : a, new oe(a, u, f, t.opacity)
            }

            function oe(t, n, e, r) {
                this.h = +t, this.s = +n, this.l = +e, this.opacity = +r
            }

            function ae(t, n, e) {
                return 255 * (t < 60 ? n + (e - n) * t / 60 : t < 180 ? e : t < 240 ? n + (e - n) * (240 - t) / 60 : n)
            }

            function ue(t, n, e, r, i) {
                var o = t * t,
                    a = o * t;
                return ((1 - 3 * t + 3 * o - a) * n + (4 - 6 * o + 3 * a) * e + (1 + 3 * t + 3 * o - 3 * a) * r + a * i) / 6
            }

            function fe(t) {
                return function() {
                    return t
                }
            }

            function ce(t, n) {
                return function(e) {
                    return t + e * n
                }
            }

            function se(t) {
                return 1 === (t = +t) ? le : function(n, e) {
                    return e - n ? function(t, n, e) {
                        return t = Math.pow(t, e), n = Math.pow(n, e) - t, e = 1 / e,
                            function(r) {
                                return Math.pow(t + r * n, e)
                            }
                    }(n, e, t) : fe(isNaN(n) ? e : n)
                }
            }

            function le(t, n) {
                var e = n - t;
                return e ? ce(t, e) : fe(isNaN(t) ? n : t)
            }
            Ln(Pn, Gn, {
                copy: function(t) {
                    return Object.assign(new this.constructor, this, t)
                },
                displayable: function() {
                    return this.rgb().displayable()
                },
                hex: Yn,
                formatHex: Yn,
                formatHsl: function() {
                    return ie(this).formatHsl()
                },
                formatRgb: $n,
                toString: $n
            }), Ln(Qn, Jn, Rn(Pn, {
                brighter: function(t) {
                    return t = null == t ? Un : Math.pow(Un, t), new Qn(this.r * t, this.g * t, this.b * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? Tn : Math.pow(Tn, t), new Qn(this.r * t, this.g * t, this.b * t, this.opacity)
                },
                rgb: function() {
                    return this
                },
                displayable: function() {
                    return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1
                },
                hex: te,
                formatHex: te,
                formatRgb: ne,
                toString: ne
            })), Ln(oe, (function(t, n, e, r) {
                return 1 === arguments.length ? ie(t) : new oe(t, n, e, null == r ? 1 : r)
            }), Rn(Pn, {
                brighter: function(t) {
                    return t = null == t ? Un : Math.pow(Un, t), new oe(this.h, this.s, this.l * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? Tn : Math.pow(Tn, t), new oe(this.h, this.s, this.l * t, this.opacity)
                },
                rgb: function() {
                    var t = this.h % 360 + 360 * (this.h < 0),
                        n = isNaN(t) || isNaN(this.s) ? 0 : this.s,
                        e = this.l,
                        r = e + (e < .5 ? e : 1 - e) * n,
                        i = 2 * e - r;
                    return new Qn(ae(t >= 240 ? t - 240 : t + 120, i, r), ae(t, i, r), ae(t < 120 ? t + 240 : t - 120, i, r), this.opacity)
                },
                displayable: function() {
                    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
                },
                formatHsl: function() {
                    var t = this.opacity;
                    return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "hsl(" : "hsla(") + (this.h || 0) + ", " + 100 * (this.s || 0) + "%, " + 100 * (this.l || 0) + "%" + (1 === t ? ")" : ", " + t + ")")
                }
            }));
            var he = function t(n) {
                var e = se(n);

                function r(t, n) {
                    var r = e((t = Jn(t)).r, (n = Jn(n)).r),
                        i = e(t.g, n.g),
                        o = e(t.b, n.b),
                        a = le(t.opacity, n.opacity);
                    return function(n) {
                        return t.r = r(n), t.g = i(n), t.b = o(n), t.opacity = a(n), t + ""
                    }
                }
                return r.gamma = t, r
            }(1);

            function de(t) {
                return function(n) {
                    var e, r, i = n.length,
                        o = new Array(i),
                        a = new Array(i),
                        u = new Array(i);
                    for (e = 0; e < i; ++e) r = Jn(n[e]), o[e] = r.r || 0, a[e] = r.g || 0, u[e] = r.b || 0;
                    return o = t(o), a = t(a), u = t(u), r.opacity = 1,
                        function(t) {
                            return r.r = o(t), r.g = a(t), r.b = u(t), r + ""
                        }
                }
            }
            var pe = de((function(t) {
                    var n = t.length - 1;
                    return function(e) {
                        var r = e <= 0 ? e = 0 : e >= 1 ? (e = 1, n - 1) : Math.floor(e * n),
                            i = t[r],
                            o = t[r + 1],
                            a = r > 0 ? t[r - 1] : 2 * i - o,
                            u = r < n - 1 ? t[r + 2] : 2 * o - i;
                        return ue((e - r / n) * n, a, i, o, u)
                    }
                })),
                ve = (de((function(t) {
                    var n = t.length;
                    return function(e) {
                        var r = Math.floor(((e %= 1) < 0 ? ++e : e) * n),
                            i = t[(r + n - 1) % n],
                            o = t[r % n],
                            a = t[(r + 1) % n],
                            u = t[(r + 2) % n];
                        return ue((e - r / n) * n, i, o, a, u)
                    }
                })), /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g),
                ge = new RegExp(ve.source, "g");

            function ye(t, n) {
                var e, r, i, o = ve.lastIndex = ge.lastIndex = 0,
                    a = -1,
                    u = [],
                    f = [];
                for (t += "", n += "";
                    (e = ve.exec(t)) && (r = ge.exec(n));)(i = r.index) > o && (i = n.slice(o, i), u[a] ? u[a] += i : u[++a] = i), (e = e[0]) === (r = r[0]) ? u[a] ? u[a] += r : u[++a] = r : (u[++a] = null, f.push({
                    i: a,
                    x: gn(e, r)
                })), o = ge.lastIndex;
                return o < n.length && (i = n.slice(o), u[a] ? u[a] += i : u[++a] = i), u.length < 2 ? f[0] ? function(t) {
                    return function(n) {
                        return t(n) + ""
                    }
                }(f[0].x) : function(t) {
                    return function() {
                        return t
                    }
                }(n) : (n = f.length, function(t) {
                    for (var e, r = 0; r < n; ++r) u[(e = f[r]).i] = e.x(t);
                    return u.join("")
                })
            }

            function _e(t, n) {
                var e;
                return ("number" === typeof n ? gn : n instanceof Gn ? he : (e = Gn(n)) ? (n = e, he) : ye)(t, n)
            }

            function be(t) {
                return function() {
                    this.removeAttribute(t)
                }
            }

            function me(t) {
                return function() {
                    this.removeAttributeNS(t.space, t.local)
                }
            }

            function we(t, n, e) {
                var r, i, o = e + "";
                return function() {
                    var a = this.getAttribute(t);
                    return a === o ? null : a === r ? i : i = n(r = a, e)
                }
            }

            function xe(t, n, e) {
                var r, i, o = e + "";
                return function() {
                    var a = this.getAttributeNS(t.space, t.local);
                    return a === o ? null : a === r ? i : i = n(r = a, e)
                }
            }

            function Me(t, n, e) {
                var r, i, o;
                return function() {
                    var a, u, f = e(this);
                    if (null != f) return (a = this.getAttribute(t)) === (u = f + "") ? null : a === r && u === i ? o : (i = u, o = n(r = a, f));
                    this.removeAttribute(t)
                }
            }

            function Ne(t, n, e) {
                var r, i, o;
                return function() {
                    var a, u, f = e(this);
                    if (null != f) return (a = this.getAttributeNS(t.space, t.local)) === (u = f + "") ? null : a === r && u === i ? o : (i = u, o = n(r = a, f));
                    this.removeAttributeNS(t.space, t.local)
                }
            }

            function Ae(t, n) {
                return function(e) {
                    this.setAttribute(t, n.call(this, e))
                }
            }

            function ke(t, n) {
                return function(e) {
                    this.setAttributeNS(t.space, t.local, n.call(this, e))
                }
            }

            function Ee(t, n) {
                var e, r;

                function i() {
                    var i = n.apply(this, arguments);
                    return i !== r && (e = (r = i) && ke(t, i)), e
                }
                return i._value = n, i
            }

            function Se(t, n) {
                var e, r;

                function i() {
                    var i = n.apply(this, arguments);
                    return i !== r && (e = (r = i) && Ae(t, i)), e
                }
                return i._value = n, i
            }

            function Ce(t, n) {
                return function() {
                    dn(this, t).delay = +n.apply(this, arguments)
                }
            }

            function Le(t, n) {
                return n = +n,
                    function() {
                        dn(this, t).delay = n
                    }
            }

            function Re(t, n) {
                return function() {
                    pn(this, t).duration = +n.apply(this, arguments)
                }
            }

            function Pe(t, n) {
                return n = +n,
                    function() {
                        pn(this, t).duration = n
                    }
            }

            function Te(t, n) {
                if ("function" !== typeof n) throw new Error;
                return function() {
                    pn(this, t).ease = n
                }
            }

            function Ue(t, n, e) {
                var r, i, o = function(t) {
                    return (t + "").trim().split(/^|\s+/).every((function(t) {
                        var n = t.indexOf(".");
                        return n >= 0 && (t = t.slice(0, n)), !t || "start" === t
                    }))
                }(n) ? dn : pn;
                return function() {
                    var a = o(this, t),
                        u = a.on;
                    u !== r && (i = (r = u).copy()).on(n, e), a.on = i
                }
            }
            var qe = zt.prototype.constructor;

            function Oe(t) {
                return function() {
                    this.style.removeProperty(t)
                }
            }

            function ze(t, n, e) {
                return function(r) {
                    this.style.setProperty(t, n.call(this, r), e)
                }
            }

            function Ie(t, n, e) {
                var r, i;

                function o() {
                    var o = n.apply(this, arguments);
                    return o !== i && (r = (i = o) && ze(t, o, e)), r
                }
                return o._value = n, o
            }

            function je(t) {
                return function(n) {
                    this.textContent = t.call(this, n)
                }
            }

            function Be(t) {
                var n, e;

                function r() {
                    var r = t.apply(this, arguments);
                    return r !== e && (n = (e = r) && je(r)), n
                }
                return r._value = t, r
            }
            var Ve = 0;

            function De(t, n, e, r) {
                this._groups = t, this._parents = n, this._name = e, this._id = r
            }

            function Xe() {
                return ++Ve
            }
            var Fe = zt.prototype;
            De.prototype = function(t) {
                return zt().transition(t)
            }.prototype = {
                constructor: De,
                select: function(t) {
                    var n = this._name,
                        e = this._id;
                    "function" !== typeof t && (t = C(t));
                    for (var r = this._groups, i = r.length, o = new Array(i), a = 0; a < i; ++a)
                        for (var u, f, c = r[a], s = c.length, l = o[a] = new Array(s), h = 0; h < s; ++h)(u = c[h]) && (f = t.call(u, u.__data__, h, c)) && ("__data__" in u && (f.__data__ = u.__data__), l[h] = f, hn(l[h], n, e, h, l, vn(u, e)));
                    return new De(o, this._parents, n, e)
                },
                selectAll: function(t) {
                    var n = this._name,
                        e = this._id;
                    "function" !== typeof t && (t = R(t));
                    for (var r = this._groups, i = r.length, o = [], a = [], u = 0; u < i; ++u)
                        for (var f, c = r[u], s = c.length, l = 0; l < s; ++l)
                            if (f = c[l]) {
                                for (var h, d = t.call(f, f.__data__, l, c), p = vn(f, e), v = 0, g = d.length; v < g; ++v)(h = d[v]) && hn(h, n, e, v, d, p);
                                o.push(d), a.push(f)
                            }
                    return new De(o, a, n, e)
                },
                filter: function(t) {
                    "function" !== typeof t && (t = P(t));
                    for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                        for (var o, a = n[i], u = a.length, f = r[i] = [], c = 0; c < u; ++c)(o = a[c]) && t.call(o, o.__data__, c, a) && f.push(o);
                    return new De(r, this._parents, this._name, this._id)
                },
                merge: function(t) {
                    if (t._id !== this._id) throw new Error;
                    for (var n = this._groups, e = t._groups, r = n.length, i = e.length, o = Math.min(r, i), a = new Array(r), u = 0; u < o; ++u)
                        for (var f, c = n[u], s = e[u], l = c.length, h = a[u] = new Array(l), d = 0; d < l; ++d)(f = c[d] || s[d]) && (h[d] = f);
                    for (; u < r; ++u) a[u] = n[u];
                    return new De(a, this._parents, this._name, this._id)
                },
                selection: function() {
                    return new qe(this._groups, this._parents)
                },
                transition: function() {
                    for (var t = this._name, n = this._id, e = Xe(), r = this._groups, i = r.length, o = 0; o < i; ++o)
                        for (var a, u = r[o], f = u.length, c = 0; c < f; ++c)
                            if (a = u[c]) {
                                var s = vn(a, n);
                                hn(a, t, e, c, u, {
                                    time: s.time + s.delay + s.duration,
                                    delay: 0,
                                    duration: s.duration,
                                    ease: s.ease
                                })
                            }
                    return new De(r, this._parents, t, e)
                },
                call: Fe.call,
                nodes: Fe.nodes,
                node: Fe.node,
                size: Fe.size,
                empty: Fe.empty,
                each: Fe.each,
                on: function(t, n) {
                    var e = this._id;
                    return arguments.length < 2 ? vn(this.node(), e).on.on(t) : this.each(Ue(e, t, n))
                },
                attr: function(t, n) {
                    var e = B(t),
                        r = "transform" === e ? kn : _e;
                    return this.attrTween(t, "function" === typeof n ? (e.local ? Ne : Me)(e, r, Cn(this, "attr." + t, n)) : null == n ? (e.local ? me : be)(e) : (e.local ? xe : we)(e, r, n))
                },
                attrTween: function(t, n) {
                    var e = "attr." + t;
                    if (arguments.length < 2) return (e = this.tween(e)) && e._value;
                    if (null == n) return this.tween(e, null);
                    if ("function" !== typeof n) throw new Error;
                    var r = B(t);
                    return this.tween(e, (r.local ? Ee : Se)(r, n))
                },
                style: function(t, n, e) {
                    var r = "transform" === (t += "") ? An : _e;
                    return null == n ? this.styleTween(t, function(t, n) {
                        var e, r, i;
                        return function() {
                            var o = K(this, t),
                                a = (this.style.removeProperty(t), K(this, t));
                            return o === a ? null : o === e && a === r ? i : i = n(e = o, r = a)
                        }
                    }(t, r)).on("end.style." + t, Oe(t)) : "function" === typeof n ? this.styleTween(t, function(t, n, e) {
                        var r, i, o;
                        return function() {
                            var a = K(this, t),
                                u = e(this),
                                f = u + "";
                            return null == u && (this.style.removeProperty(t), f = u = K(this, t)), a === f ? null : a === r && f === i ? o : (i = f, o = n(r = a, u))
                        }
                    }(t, r, Cn(this, "style." + t, n))).each(function(t, n) {
                        var e, r, i, o, a = "style." + n,
                            u = "end." + a;
                        return function() {
                            var f = pn(this, t),
                                c = f.on,
                                s = null == f.value[a] ? o || (o = Oe(n)) : void 0;
                            c === e && i === s || (r = (e = c).copy()).on(u, i = s), f.on = r
                        }
                    }(this._id, t)) : this.styleTween(t, function(t, n, e) {
                        var r, i, o = e + "";
                        return function() {
                            var a = K(this, t);
                            return a === o ? null : a === r ? i : i = n(r = a, e)
                        }
                    }(t, r, n), e).on("end.style." + t, null)
                },
                styleTween: function(t, n, e) {
                    var r = "style." + (t += "");
                    if (arguments.length < 2) return (r = this.tween(r)) && r._value;
                    if (null == n) return this.tween(r, null);
                    if ("function" !== typeof n) throw new Error;
                    return this.tween(r, Ie(t, n, null == e ? "" : e))
                },
                text: function(t) {
                    return this.tween("text", "function" === typeof t ? function(t) {
                        return function() {
                            var n = t(this);
                            this.textContent = null == n ? "" : n
                        }
                    }(Cn(this, "text", t)) : function(t) {
                        return function() {
                            this.textContent = t
                        }
                    }(null == t ? "" : t + ""))
                },
                textTween: function(t) {
                    var n = "text";
                    if (arguments.length < 1) return (n = this.tween(n)) && n._value;
                    if (null == t) return this.tween(n, null);
                    if ("function" !== typeof t) throw new Error;
                    return this.tween(n, Be(t))
                },
                remove: function() {
                    return this.on("end.remove", function(t) {
                        return function() {
                            var n = this.parentNode;
                            for (var e in this.__transition)
                                if (+e !== t) return;
                            n && n.removeChild(this)
                        }
                    }(this._id))
                },
                tween: function(t, n) {
                    var e = this._id;
                    if (t += "", arguments.length < 2) {
                        for (var r, i = vn(this.node(), e).tween, o = 0, a = i.length; o < a; ++o)
                            if ((r = i[o]).name === t) return r.value;
                        return null
                    }
                    return this.each((null == n ? En : Sn)(e, t, n))
                },
                delay: function(t) {
                    var n = this._id;
                    return arguments.length ? this.each(("function" === typeof t ? Ce : Le)(n, t)) : vn(this.node(), n).delay
                },
                duration: function(t) {
                    var n = this._id;
                    return arguments.length ? this.each(("function" === typeof t ? Re : Pe)(n, t)) : vn(this.node(), n).duration
                },
                ease: function(t) {
                    var n = this._id;
                    return arguments.length ? this.each(Te(n, t)) : vn(this.node(), n).ease
                },
                end: function() {
                    var t, n, e = this,
                        r = e._id,
                        i = e.size();
                    return new Promise((function(o, a) {
                        var u = {
                                value: a
                            },
                            f = {
                                value: function() {
                                    0 === --i && o()
                                }
                            };
                        e.each((function() {
                            var e = pn(this, r),
                                i = e.on;
                            i !== t && ((n = (t = i).copy())._.cancel.push(u), n._.interrupt.push(u), n._.end.push(f)), e.on = n
                        }))
                    }))
                }
            };
            var He = {
                time: null,
                delay: 0,
                duration: 250,
                ease: function(t) {
                    return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2
                }
            };

            function Ye(t, n) {
                for (var e; !(e = t.__transition) || !(e = e[n]);)
                    if (!(t = t.parentNode)) return He.time = nn(), He;
                return e
            }
            zt.prototype.interrupt = function(t) {
                return this.each((function() {
                    ! function(t, n) {
                        var e, r, i, o = t.__transition,
                            a = !0;
                        if (o) {
                            for (i in n = null == n ? null : n + "", o)(e = o[i]).name === n ? (r = e.state > 2 && e.state < 5, e.state = 6, e.timer.stop(), e.on.call(r ? "interrupt" : "cancel", t, t.__data__, e.index, e.group), delete o[i]) : a = !1;
                            a && delete t.__transition
                        }
                    }(this, t)
                }))
            }, zt.prototype.transition = function(t) {
                var n, e;
                t instanceof De ? (n = t._id, t = t._name) : (n = Xe(), (e = He).time = nn(), t = null == t ? null : t + "");
                for (var r = this._groups, i = r.length, o = 0; o < i; ++o)
                    for (var a, u = r[o], f = u.length, c = 0; c < f; ++c)(a = u[c]) && hn(a, t, n, c, u, e || Ye(a, n));
                return new De(r, this._parents, t, n)
            };

            function $e(t) {
                return [+t[0], +t[1]]
            }

            function Ge(t) {
                return [$e(t[0]), $e(t[1])]
            }["w", "e"].map(Ze), ["n", "s"].map(Ze), ["n", "w", "e", "s", "nw", "ne", "sw", "se"].map(Ze);

            function Ze(t) {
                return {
                    type: t
                }
            }
            Math.cos, Math.sin, Math.PI, Math.max;
            Array.prototype.slice;
            var We = "$";

            function Ke() {}

            function Je(t, n) {
                var e = new Ke;
                if (t instanceof Ke) t.each((function(t, n) {
                    e.set(n, t)
                }));
                else if (Array.isArray(t)) {
                    var r, i = -1,
                        o = t.length;
                    if (null == n)
                        for (; ++i < o;) e.set(i, t[i]);
                    else
                        for (; ++i < o;) e.set(n(r = t[i], i, t), r)
                } else if (t)
                    for (var a in t) e.set(a, t[a]);
                return e
            }
            Ke.prototype = Je.prototype = {
                constructor: Ke,
                has: function(t) {
                    return We + t in this
                },
                get: function(t) {
                    return this[We + t]
                },
                set: function(t, n) {
                    return this[We + t] = n, this
                },
                remove: function(t) {
                    var n = We + t;
                    return n in this && delete this[n]
                },
                clear: function() {
                    for (var t in this) t[0] === We && delete this[t]
                },
                keys: function() {
                    var t = [];
                    for (var n in this) n[0] === We && t.push(n.slice(1));
                    return t
                },
                values: function() {
                    var t = [];
                    for (var n in this) n[0] === We && t.push(this[n]);
                    return t
                },
                entries: function() {
                    var t = [];
                    for (var n in this) n[0] === We && t.push({
                        key: n.slice(1),
                        value: this[n]
                    });
                    return t
                },
                size: function() {
                    var t = 0;
                    for (var n in this) n[0] === We && ++t;
                    return t
                },
                empty: function() {
                    for (var t in this)
                        if (t[0] === We) return !1;
                    return !0
                },
                each: function(t) {
                    for (var n in this) n[0] === We && t(this[n], n.slice(1), this)
                }
            };
            var Qe = Je;

            function tr() {
                var t, n, e, r = [],
                    i = [];

                function o(e, i, a, u) {
                    if (i >= r.length) return null != t && e.sort(t), null != n ? n(e) : e;
                    for (var f, c, s, l = -1, h = e.length, d = r[i++], p = Qe(), v = a(); ++l < h;)(s = p.get(f = d(c = e[l]) + "")) ? s.push(c) : p.set(f, [c]);
                    return p.each((function(t, n) {
                        u(v, n, o(t, i, a, u))
                    })), v
                }

                function a(t, e) {
                    if (++e > r.length) return t;
                    var o, u = i[e - 1];
                    return null != n && e >= r.length ? o = t.entries() : (o = [], t.each((function(t, n) {
                        o.push({
                            key: n,
                            values: a(t, e)
                        })
                    }))), null != u ? o.sort((function(t, n) {
                        return u(t.key, n.key)
                    })) : o
                }
                return e = {
                    object: function(t) {
                        return o(t, 0, nr, er)
                    },
                    map: function(t) {
                        return o(t, 0, rr, ir)
                    },
                    entries: function(t) {
                        return a(o(t, 0, rr, ir), 0)
                    },
                    key: function(t) {
                        return r.push(t), e
                    },
                    sortKeys: function(t) {
                        return i[r.length - 1] = t, e
                    },
                    sortValues: function(n) {
                        return t = n, e
                    },
                    rollup: function(t) {
                        return n = t, e
                    }
                }
            }

            function nr() {
                return {}
            }

            function er(t, n, e) {
                t[n] = e
            }

            function rr() {
                return Qe()
            }

            function ir(t, n, e) {
                t.set(n, e)
            }

            function or() {}
            var ar = Qe.prototype;

            function ur(t, n) {
                var e = new or;
                if (t instanceof or) t.each((function(t) {
                    e.add(t)
                }));
                else if (t) {
                    var r = -1,
                        i = t.length;
                    if (null == n)
                        for (; ++r < i;) e.add(t[r]);
                    else
                        for (; ++r < i;) e.add(n(t[r], r, t))
                }
                return e
            }
            or.prototype = ur.prototype = {
                constructor: or,
                has: ar.has,
                add: function(t) {
                    return this[We + (t += "")] = t, this
                },
                remove: ar.remove,
                clear: ar.clear,
                values: ar.keys,
                size: ar.size,
                empty: ar.empty,
                each: ar.each
            };
            var fr = Array.prototype.slice;

            function cr(t, n) {
                return t - n
            }

            function sr(t) {
                return function() {
                    return t
                }
            }

            function lr(t, n) {
                for (var e, r = -1, i = n.length; ++r < i;)
                    if (e = hr(t, n[r])) return e;
                return 0
            }

            function hr(t, n) {
                for (var e = n[0], r = n[1], i = -1, o = 0, a = t.length, u = a - 1; o < a; u = o++) {
                    var f = t[o],
                        c = f[0],
                        s = f[1],
                        l = t[u],
                        h = l[0],
                        d = l[1];
                    if (dr(f, l, n)) return 0;
                    s > r !== d > r && e < (h - c) * (r - s) / (d - s) + c && (i = -i)
                }
                return i
            }

            function dr(t, n, e) {
                var r, i, o, a;
                return function(t, n, e) {
                    return (n[0] - t[0]) * (e[1] - t[1]) === (e[0] - t[0]) * (n[1] - t[1])
                }(t, n, e) && (i = t[r = +(t[0] === n[0])], o = e[r], a = n[r], i <= o && o <= a || a <= o && o <= i)
            }

            function pr() {}
            var vr = [
                [],
                [
                    [
                        [1, 1.5],
                        [.5, 1]
                    ]
                ],
                [
                    [
                        [1.5, 1],
                        [1, 1.5]
                    ]
                ],
                [
                    [
                        [1.5, 1],
                        [.5, 1]
                    ]
                ],
                [
                    [
                        [1, .5],
                        [1.5, 1]
                    ]
                ],
                [
                    [
                        [1, 1.5],
                        [.5, 1]
                    ],
                    [
                        [1, .5],
                        [1.5, 1]
                    ]
                ],
                [
                    [
                        [1, .5],
                        [1, 1.5]
                    ]
                ],
                [
                    [
                        [1, .5],
                        [.5, 1]
                    ]
                ],
                [
                    [
                        [.5, 1],
                        [1, .5]
                    ]
                ],
                [
                    [
                        [1, 1.5],
                        [1, .5]
                    ]
                ],
                [
                    [
                        [.5, 1],
                        [1, .5]
                    ],
                    [
                        [1.5, 1],
                        [1, 1.5]
                    ]
                ],
                [
                    [
                        [1.5, 1],
                        [1, .5]
                    ]
                ],
                [
                    [
                        [.5, 1],
                        [1.5, 1]
                    ]
                ],
                [
                    [
                        [1, 1.5],
                        [1.5, 1]
                    ]
                ],
                [
                    [
                        [.5, 1],
                        [1, 1.5]
                    ]
                ],
                []
            ];

            function gr() {
                var t = 1,
                    n = 1,
                    e = p,
                    r = f;

                function i(t) {
                    var n = e(t);
                    if (Array.isArray(n)) n = n.slice().sort(cr);
                    else {
                        var r = u(t),
                            i = r[0],
                            a = r[1];
                        n = d(i, a, n), n = g(Math.floor(i / n) * n, Math.floor(a / n) * n, n)
                    }
                    return n.map((function(n) {
                        return o(t, n)
                    }))
                }

                function o(e, i) {
                    var o = [],
                        u = [];
                    return function(e, r, i) {
                        var o, u, f, c, s, l, h = new Array,
                            d = new Array;
                        o = u = -1, c = e[0] >= r, vr[c << 1].forEach(p);
                        for (; ++o < t - 1;) f = c, c = e[o + 1] >= r, vr[f | c << 1].forEach(p);
                        vr[c << 0].forEach(p);
                        for (; ++u < n - 1;) {
                            for (o = -1, c = e[u * t + t] >= r, s = e[u * t] >= r, vr[c << 1 | s << 2].forEach(p); ++o < t - 1;) f = c, c = e[u * t + t + o + 1] >= r, l = s, s = e[u * t + o + 1] >= r, vr[f | c << 1 | s << 2 | l << 3].forEach(p);
                            vr[c | s << 3].forEach(p)
                        }
                        o = -1, s = e[u * t] >= r, vr[s << 2].forEach(p);
                        for (; ++o < t - 1;) l = s, s = e[u * t + o + 1] >= r, vr[s << 2 | l << 3].forEach(p);

                        function p(t) {
                            var n, e, r = [t[0][0] + o, t[0][1] + u],
                                f = [t[1][0] + o, t[1][1] + u],
                                c = a(r),
                                s = a(f);
                            (n = d[c]) ? (e = h[s]) ? (delete d[n.end], delete h[e.start], n === e ? (n.ring.push(f), i(n.ring)) : h[n.start] = d[e.end] = {
                                start: n.start,
                                end: e.end,
                                ring: n.ring.concat(e.ring)
                            }) : (delete d[n.end], n.ring.push(f), d[n.end = s] = n) : (n = h[s]) ? (e = d[c]) ? (delete h[n.start], delete d[e.end], n === e ? (n.ring.push(f), i(n.ring)) : h[e.start] = d[n.end] = {
                                start: e.start,
                                end: n.end,
                                ring: e.ring.concat(n.ring)
                            }) : (delete h[n.start], n.ring.unshift(r), h[n.start = c] = n) : h[c] = d[s] = {
                                start: c,
                                end: s,
                                ring: [r, f]
                            }
                        }
                        vr[s << 3].forEach(p)
                    }(e, i, (function(t) {
                        r(t, e, i),
                            function(t) {
                                for (var n = 0, e = t.length, r = t[e - 1][1] * t[0][0] - t[e - 1][0] * t[0][1]; ++n < e;) r += t[n - 1][1] * t[n][0] - t[n - 1][0] * t[n][1];
                                return r
                            }(t) > 0 ? o.push([t]) : u.push(t)
                    })), u.forEach((function(t) {
                        for (var n, e = 0, r = o.length; e < r; ++e)
                            if (-1 !== lr((n = o[e])[0], t)) return void n.push(t)
                    })), {
                        type: "MultiPolygon",
                        value: i,
                        coordinates: o
                    }
                }

                function a(n) {
                    return 2 * n[0] + n[1] * (t + 1) * 4
                }

                function f(e, r, i) {
                    e.forEach((function(e) {
                        var o, a = e[0],
                            u = e[1],
                            f = 0 | a,
                            c = 0 | u,
                            s = r[c * t + f];
                        a > 0 && a < t && f === a && (o = r[c * t + f - 1], e[0] = a + (i - o) / (s - o) - .5), u > 0 && u < n && c === u && (o = r[(c - 1) * t + f], e[1] = u + (i - o) / (s - o) - .5)
                    }))
                }
                return i.contour = o, i.size = function(e) {
                    if (!arguments.length) return [t, n];
                    var r = Math.ceil(e[0]),
                        o = Math.ceil(e[1]);
                    if (!(r > 0) || !(o > 0)) throw new Error("invalid size");
                    return t = r, n = o, i
                }, i.thresholds = function(t) {
                    return arguments.length ? (e = "function" === typeof t ? t : Array.isArray(t) ? sr(fr.call(t)) : sr(t), i) : e
                }, i.smooth = function(t) {
                    return arguments.length ? (r = t ? f : pr, i) : r === f
                }, i
            }

            function yr(t, n, e) {
                for (var r = t.width, i = t.height, o = 1 + (e << 1), a = 0; a < i; ++a)
                    for (var u = 0, f = 0; u < r + e; ++u) u < r && (f += t.data[u + a * r]), u >= e && (u >= o && (f -= t.data[u - o + a * r]), n.data[u - e + a * r] = f / Math.min(u + 1, r - 1 + o - u, o))
            }

            function _r(t, n, e) {
                for (var r = t.width, i = t.height, o = 1 + (e << 1), a = 0; a < r; ++a)
                    for (var u = 0, f = 0; u < i + e; ++u) u < i && (f += t.data[a + u * r]), u >= e && (u >= o && (f -= t.data[a + (u - o) * r]), n.data[a + (u - e) * r] = f / Math.min(u + 1, i - 1 + o - u, o))
            }

            function br(t) {
                return t[0]
            }

            function mr(t) {
                return t[1]
            }

            function wr() {
                return 1
            }

            function xr() {
                var t = br,
                    n = mr,
                    e = wr,
                    r = 960,
                    i = 500,
                    o = 20,
                    a = 2,
                    u = 3 * o,
                    f = r + 2 * u >> a,
                    c = i + 2 * u >> a,
                    s = sr(20);

                function l(r) {
                    var i = new Float32Array(f * c),
                        l = new Float32Array(f * c);
                    r.forEach((function(r, o, s) {
                        var l = +t(r, o, s) + u >> a,
                            h = +n(r, o, s) + u >> a,
                            d = +e(r, o, s);
                        l >= 0 && l < f && h >= 0 && h < c && (i[l + h * f] += d)
                    })), yr({
                        width: f,
                        height: c,
                        data: i
                    }, {
                        width: f,
                        height: c,
                        data: l
                    }, o >> a), _r({
                        width: f,
                        height: c,
                        data: l
                    }, {
                        width: f,
                        height: c,
                        data: i
                    }, o >> a), yr({
                        width: f,
                        height: c,
                        data: i
                    }, {
                        width: f,
                        height: c,
                        data: l
                    }, o >> a), _r({
                        width: f,
                        height: c,
                        data: l
                    }, {
                        width: f,
                        height: c,
                        data: i
                    }, o >> a), yr({
                        width: f,
                        height: c,
                        data: i
                    }, {
                        width: f,
                        height: c,
                        data: l
                    }, o >> a), _r({
                        width: f,
                        height: c,
                        data: l
                    }, {
                        width: f,
                        height: c,
                        data: i
                    }, o >> a);
                    var p = s(i);
                    if (!Array.isArray(p)) {
                        var y = v(i);
                        p = d(0, y, p), (p = g(0, Math.floor(y / p) * p, p)).shift()
                    }
                    return gr().thresholds(p).size([f, c])(i).map(h)
                }

                function h(t) {
                    return t.value *= Math.pow(2, -2 * a), t.coordinates.forEach(p), t
                }

                function p(t) {
                    t.forEach(y)
                }

                function y(t) {
                    t.forEach(_)
                }

                function _(t) {
                    t[0] = t[0] * Math.pow(2, a) - u, t[1] = t[1] * Math.pow(2, a) - u
                }

                function b() {
                    return f = r + 2 * (u = 3 * o) >> a, c = i + 2 * u >> a, l
                }
                return l.x = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : sr(+n), l) : t
                }, l.y = function(t) {
                    return arguments.length ? (n = "function" === typeof t ? t : sr(+t), l) : n
                }, l.weight = function(t) {
                    return arguments.length ? (e = "function" === typeof t ? t : sr(+t), l) : e
                }, l.size = function(t) {
                    if (!arguments.length) return [r, i];
                    var n = Math.ceil(t[0]),
                        e = Math.ceil(t[1]);
                    if (!(n >= 0) && !(n >= 0)) throw new Error("invalid size");
                    return r = n, i = e, b()
                }, l.cellSize = function(t) {
                    if (!arguments.length) return 1 << a;
                    if (!((t = +t) >= 1)) throw new Error("invalid cell size");
                    return a = Math.floor(Math.log(t) / Math.LN2), b()
                }, l.thresholds = function(t) {
                    return arguments.length ? (s = "function" === typeof t ? t : Array.isArray(t) ? sr(fr.call(t)) : sr(t), l) : s
                }, l.bandwidth = function(t) {
                    if (!arguments.length) return Math.sqrt(o * (o + 1));
                    if (!((t = +t) >= 0)) throw new Error("invalid bandwidth");
                    return o = Math.round((Math.sqrt(4 * t * t + 1) - 1) / 2), b()
                }, l
            }

            function Mr(t) {
                return function() {
                    return t
                }
            }

            function Nr() {
                return 1e-6 * (Math.random() - .5)
            }

            function Ar(t, n, e, r) {
                if (isNaN(n) || isNaN(e)) return t;
                var i, o, a, u, f, c, s, l, h, d = t._root,
                    p = {
                        data: r
                    },
                    v = t._x0,
                    g = t._y0,
                    y = t._x1,
                    _ = t._y1;
                if (!d) return t._root = p, t;
                for (; d.length;)
                    if ((c = n >= (o = (v + y) / 2)) ? v = o : y = o, (s = e >= (a = (g + _) / 2)) ? g = a : _ = a, i = d, !(d = d[l = s << 1 | c])) return i[l] = p, t;
                if (u = +t._x.call(null, d.data), f = +t._y.call(null, d.data), n === u && e === f) return p.next = d, i ? i[l] = p : t._root = p, t;
                do {
                    i = i ? i[l] = new Array(4) : t._root = new Array(4), (c = n >= (o = (v + y) / 2)) ? v = o : y = o, (s = e >= (a = (g + _) / 2)) ? g = a : _ = a
                } while ((l = s << 1 | c) === (h = (f >= a) << 1 | u >= o));
                return i[h] = d, i[l] = p, t
            }

            function kr(t, n, e, r, i) {
                this.node = t, this.x0 = n, this.y0 = e, this.x1 = r, this.y1 = i
            }

            function Er(t) {
                return t[0]
            }

            function Sr(t) {
                return t[1]
            }

            function Cr(t, n, e) {
                var r = new Lr(null == n ? Er : n, null == e ? Sr : e, NaN, NaN, NaN, NaN);
                return null == t ? r : r.addAll(t)
            }

            function Lr(t, n, e, r, i, o) {
                this._x = t, this._y = n, this._x0 = e, this._y0 = r, this._x1 = i, this._y1 = o, this._root = void 0
            }

            function Rr(t) {
                for (var n = {
                        data: t.data
                    }, e = n; t = t.next;) e = e.next = {
                    data: t.data
                };
                return n
            }
            var Pr = Cr.prototype = Lr.prototype;

            function Tr(t) {
                return t.x + t.vx
            }

            function Ur(t) {
                return t.y + t.vy
            }

            function qr(t) {
                var n, e, r = 1,
                    i = 1;

                function o() {
                    for (var t, o, u, f, c, s, l, h = n.length, d = 0; d < i; ++d)
                        for (o = Cr(n, Tr, Ur).visitAfter(a), t = 0; t < h; ++t) u = n[t], s = e[u.index], l = s * s, f = u.x + u.vx, c = u.y + u.vy, o.visit(p);

                    function p(t, n, e, i, o) {
                        var a = t.data,
                            h = t.r,
                            d = s + h;
                        if (!a) return n > f + d || i < f - d || e > c + d || o < c - d;
                        if (a.index > u.index) {
                            var p = f - a.x - a.vx,
                                v = c - a.y - a.vy,
                                g = p * p + v * v;
                            g < d * d && (0 === p && (g += (p = Nr()) * p), 0 === v && (g += (v = Nr()) * v), g = (d - (g = Math.sqrt(g))) / g * r, u.vx += (p *= g) * (d = (h *= h) / (l + h)), u.vy += (v *= g) * d, a.vx -= p * (d = 1 - d), a.vy -= v * d)
                        }
                    }
                }

                function a(t) {
                    if (t.data) return t.r = e[t.data.index];
                    for (var n = t.r = 0; n < 4; ++n) t[n] && t[n].r > t.r && (t.r = t[n].r)
                }

                function u() {
                    if (n) {
                        var r, i, o = n.length;
                        for (e = new Array(o), r = 0; r < o; ++r) i = n[r], e[i.index] = +t(i, r, n)
                    }
                }
                return "function" !== typeof t && (t = Mr(null == t ? 1 : +t)), o.initialize = function(t) {
                    n = t, u()
                }, o.iterations = function(t) {
                    return arguments.length ? (i = +t, o) : i
                }, o.strength = function(t) {
                    return arguments.length ? (r = +t, o) : r
                }, o.radius = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : Mr(+n), u(), o) : t
                }, o
            }
            Pr.copy = function() {
                var t, n, e = new Lr(this._x, this._y, this._x0, this._y0, this._x1, this._y1),
                    r = this._root;
                if (!r) return e;
                if (!r.length) return e._root = Rr(r), e;
                for (t = [{
                        source: r,
                        target: e._root = new Array(4)
                    }]; r = t.pop();)
                    for (var i = 0; i < 4; ++i)(n = r.source[i]) && (n.length ? t.push({
                        source: n,
                        target: r.target[i] = new Array(4)
                    }) : r.target[i] = Rr(n));
                return e
            }, Pr.add = function(t) {
                var n = +this._x.call(null, t),
                    e = +this._y.call(null, t);
                return Ar(this.cover(n, e), n, e, t)
            }, Pr.addAll = function(t) {
                var n, e, r, i, o = t.length,
                    a = new Array(o),
                    u = new Array(o),
                    f = 1 / 0,
                    c = 1 / 0,
                    s = -1 / 0,
                    l = -1 / 0;
                for (e = 0; e < o; ++e) isNaN(r = +this._x.call(null, n = t[e])) || isNaN(i = +this._y.call(null, n)) || (a[e] = r, u[e] = i, r < f && (f = r), r > s && (s = r), i < c && (c = i), i > l && (l = i));
                if (f > s || c > l) return this;
                for (this.cover(f, c).cover(s, l), e = 0; e < o; ++e) Ar(this, a[e], u[e], t[e]);
                return this
            }, Pr.cover = function(t, n) {
                if (isNaN(t = +t) || isNaN(n = +n)) return this;
                var e = this._x0,
                    r = this._y0,
                    i = this._x1,
                    o = this._y1;
                if (isNaN(e)) i = (e = Math.floor(t)) + 1, o = (r = Math.floor(n)) + 1;
                else {
                    for (var a, u, f = i - e, c = this._root; e > t || t >= i || r > n || n >= o;) switch (u = (n < r) << 1 | t < e, (a = new Array(4))[u] = c, c = a, f *= 2, u) {
                        case 0:
                            i = e + f, o = r + f;
                            break;
                        case 1:
                            e = i - f, o = r + f;
                            break;
                        case 2:
                            i = e + f, r = o - f;
                            break;
                        case 3:
                            e = i - f, r = o - f
                    }
                    this._root && this._root.length && (this._root = c)
                }
                return this._x0 = e, this._y0 = r, this._x1 = i, this._y1 = o, this
            }, Pr.data = function() {
                var t = [];
                return this.visit((function(n) {
                    if (!n.length)
                        do {
                            t.push(n.data)
                        } while (n = n.next)
                })), t
            }, Pr.extent = function(t) {
                return arguments.length ? this.cover(+t[0][0], +t[0][1]).cover(+t[1][0], +t[1][1]) : isNaN(this._x0) ? void 0 : [
                    [this._x0, this._y0],
                    [this._x1, this._y1]
                ]
            }, Pr.find = function(t, n, e) {
                var r, i, o, a, u, f, c, s = this._x0,
                    l = this._y0,
                    h = this._x1,
                    d = this._y1,
                    p = [],
                    v = this._root;
                for (v && p.push(new kr(v, s, l, h, d)), null == e ? e = 1 / 0 : (s = t - e, l = n - e, h = t + e, d = n + e, e *= e); f = p.pop();)
                    if (!(!(v = f.node) || (i = f.x0) > h || (o = f.y0) > d || (a = f.x1) < s || (u = f.y1) < l))
                        if (v.length) {
                            var g = (i + a) / 2,
                                y = (o + u) / 2;
                            p.push(new kr(v[3], g, y, a, u), new kr(v[2], i, y, g, u), new kr(v[1], g, o, a, y), new kr(v[0], i, o, g, y)), (c = (n >= y) << 1 | t >= g) && (f = p[p.length - 1], p[p.length - 1] = p[p.length - 1 - c], p[p.length - 1 - c] = f)
                        } else {
                            var _ = t - +this._x.call(null, v.data),
                                b = n - +this._y.call(null, v.data),
                                m = _ * _ + b * b;
                            if (m < e) {
                                var w = Math.sqrt(e = m);
                                s = t - w, l = n - w, h = t + w, d = n + w, r = v.data
                            }
                        }
                return r
            }, Pr.remove = function(t) {
                if (isNaN(o = +this._x.call(null, t)) || isNaN(a = +this._y.call(null, t))) return this;
                var n, e, r, i, o, a, u, f, c, s, l, h, d = this._root,
                    p = this._x0,
                    v = this._y0,
                    g = this._x1,
                    y = this._y1;
                if (!d) return this;
                if (d.length)
                    for (;;) {
                        if ((c = o >= (u = (p + g) / 2)) ? p = u : g = u, (s = a >= (f = (v + y) / 2)) ? v = f : y = f, n = d, !(d = d[l = s << 1 | c])) return this;
                        if (!d.length) break;
                        (n[l + 1 & 3] || n[l + 2 & 3] || n[l + 3 & 3]) && (e = n, h = l)
                    }
                for (; d.data !== t;)
                    if (r = d, !(d = d.next)) return this;
                return (i = d.next) && delete d.next, r ? (i ? r.next = i : delete r.next, this) : n ? (i ? n[l] = i : delete n[l], (d = n[0] || n[1] || n[2] || n[3]) && d === (n[3] || n[2] || n[1] || n[0]) && !d.length && (e ? e[h] = d : this._root = d), this) : (this._root = i, this)
            }, Pr.removeAll = function(t) {
                for (var n = 0, e = t.length; n < e; ++n) this.remove(t[n]);
                return this
            }, Pr.root = function() {
                return this._root
            }, Pr.size = function() {
                var t = 0;
                return this.visit((function(n) {
                    if (!n.length)
                        do {
                            ++t
                        } while (n = n.next)
                })), t
            }, Pr.visit = function(t) {
                var n, e, r, i, o, a, u = [],
                    f = this._root;
                for (f && u.push(new kr(f, this._x0, this._y0, this._x1, this._y1)); n = u.pop();)
                    if (!t(f = n.node, r = n.x0, i = n.y0, o = n.x1, a = n.y1) && f.length) {
                        var c = (r + o) / 2,
                            s = (i + a) / 2;
                        (e = f[3]) && u.push(new kr(e, c, s, o, a)), (e = f[2]) && u.push(new kr(e, r, s, c, a)), (e = f[1]) && u.push(new kr(e, c, i, o, s)), (e = f[0]) && u.push(new kr(e, r, i, c, s))
                    }
                return this
            }, Pr.visitAfter = function(t) {
                var n, e = [],
                    r = [];
                for (this._root && e.push(new kr(this._root, this._x0, this._y0, this._x1, this._y1)); n = e.pop();) {
                    var i = n.node;
                    if (i.length) {
                        var o, a = n.x0,
                            u = n.y0,
                            f = n.x1,
                            c = n.y1,
                            s = (a + f) / 2,
                            l = (u + c) / 2;
                        (o = i[0]) && e.push(new kr(o, a, u, s, l)), (o = i[1]) && e.push(new kr(o, s, u, f, l)), (o = i[2]) && e.push(new kr(o, a, l, s, c)), (o = i[3]) && e.push(new kr(o, s, l, f, c))
                    }
                    r.push(n)
                }
                for (; n = r.pop();) t(n.node, n.x0, n.y0, n.x1, n.y1);
                return this
            }, Pr.x = function(t) {
                return arguments.length ? (this._x = t, this) : this._x
            }, Pr.y = function(t) {
                return arguments.length ? (this._y = t, this) : this._y
            };
            var Or = Math.PI * (3 - Math.sqrt(5));

            function zr(t) {
                var n, e = 1,
                    r = .001,
                    i = 1 - Math.pow(r, 1 / 300),
                    o = 0,
                    a = .6,
                    u = Qe(),
                    f = on(s),
                    c = Yt("tick", "end");

                function s() {
                    l(), c.call("tick", n), e < r && (f.stop(), c.call("end", n))
                }

                function l(r) {
                    var f, c, s = t.length;
                    void 0 === r && (r = 1);
                    for (var l = 0; l < r; ++l)
                        for (e += (o - e) * i, u.each((function(t) {
                                t(e)
                            })), f = 0; f < s; ++f) null == (c = t[f]).fx ? c.x += c.vx *= a : (c.x = c.fx, c.vx = 0), null == c.fy ? c.y += c.vy *= a : (c.y = c.fy, c.vy = 0);
                    return n
                }

                function h() {
                    for (var n, e = 0, r = t.length; e < r; ++e) {
                        if ((n = t[e]).index = e, null != n.fx && (n.x = n.fx), null != n.fy && (n.y = n.fy), isNaN(n.x) || isNaN(n.y)) {
                            var i = 10 * Math.sqrt(e),
                                o = e * Or;
                            n.x = i * Math.cos(o), n.y = i * Math.sin(o)
                        }(isNaN(n.vx) || isNaN(n.vy)) && (n.vx = n.vy = 0)
                    }
                }

                function d(n) {
                    return n.initialize && n.initialize(t), n
                }
                return null == t && (t = []), h(), n = {
                    tick: l,
                    restart: function() {
                        return f.restart(s), n
                    },
                    stop: function() {
                        return f.stop(), n
                    },
                    nodes: function(e) {
                        return arguments.length ? (t = e, h(), u.each(d), n) : t
                    },
                    alpha: function(t) {
                        return arguments.length ? (e = +t, n) : e
                    },
                    alphaMin: function(t) {
                        return arguments.length ? (r = +t, n) : r
                    },
                    alphaDecay: function(t) {
                        return arguments.length ? (i = +t, n) : +i
                    },
                    alphaTarget: function(t) {
                        return arguments.length ? (o = +t, n) : o
                    },
                    velocityDecay: function(t) {
                        return arguments.length ? (a = 1 - t, n) : 1 - a
                    },
                    force: function(t, e) {
                        return arguments.length > 1 ? (null == e ? u.remove(t) : u.set(t, d(e)), n) : u.get(t)
                    },
                    find: function(n, e, r) {
                        var i, o, a, u, f, c = 0,
                            s = t.length;
                        for (null == r ? r = 1 / 0 : r *= r, c = 0; c < s; ++c)(a = (i = n - (u = t[c]).x) * i + (o = e - u.y) * o) < r && (f = u, r = a);
                        return f
                    },
                    on: function(t, e) {
                        return arguments.length > 1 ? (c.on(t, e), n) : c.on(t)
                    }
                }
            }

            function Ir(t) {
                var n, e, r, i = Mr(.1);

                function o(t) {
                    for (var i, o = 0, a = n.length; o < a; ++o)(i = n[o]).vx += (r[o] - i.x) * e[o] * t
                }

                function a() {
                    if (n) {
                        var o, a = n.length;
                        for (e = new Array(a), r = new Array(a), o = 0; o < a; ++o) e[o] = isNaN(r[o] = +t(n[o], o, n)) ? 0 : +i(n[o], o, n)
                    }
                }
                return "function" !== typeof t && (t = Mr(null == t ? 0 : +t)), o.initialize = function(t) {
                    n = t, a()
                }, o.strength = function(t) {
                    return arguments.length ? (i = "function" === typeof t ? t : Mr(+t), a(), o) : i
                }, o.x = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : Mr(+n), a(), o) : t
                }, o
            }

            function jr(t) {
                var n, e, r, i = Mr(.1);

                function o(t) {
                    for (var i, o = 0, a = n.length; o < a; ++o)(i = n[o]).vy += (r[o] - i.y) * e[o] * t
                }

                function a() {
                    if (n) {
                        var o, a = n.length;
                        for (e = new Array(a), r = new Array(a), o = 0; o < a; ++o) e[o] = isNaN(r[o] = +t(n[o], o, n)) ? 0 : +i(n[o], o, n)
                    }
                }
                return "function" !== typeof t && (t = Mr(null == t ? 0 : +t)), o.initialize = function(t) {
                    n = t, a()
                }, o.strength = function(t) {
                    return arguments.length ? (i = "function" === typeof t ? t : Mr(+t), a(), o) : i
                }, o.y = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : Mr(+n), a(), o) : t
                }, o
            }

            function Br(t) {
                return t
            }

            function Vr(t, n) {
                t && Xr.hasOwnProperty(t.type) && Xr[t.type](t, n)
            }
            var Dr = {
                    Feature: function(t, n) {
                        Vr(t.geometry, n)
                    },
                    FeatureCollection: function(t, n) {
                        for (var e = t.features, r = -1, i = e.length; ++r < i;) Vr(e[r].geometry, n)
                    }
                },
                Xr = {
                    Sphere: function(t, n) {
                        n.sphere()
                    },
                    Point: function(t, n) {
                        t = t.coordinates, n.point(t[0], t[1], t[2])
                    },
                    MultiPoint: function(t, n) {
                        for (var e = t.coordinates, r = -1, i = e.length; ++r < i;) t = e[r], n.point(t[0], t[1], t[2])
                    },
                    LineString: function(t, n) {
                        Fr(t.coordinates, n, 0)
                    },
                    MultiLineString: function(t, n) {
                        for (var e = t.coordinates, r = -1, i = e.length; ++r < i;) Fr(e[r], n, 0)
                    },
                    Polygon: function(t, n) {
                        Hr(t.coordinates, n)
                    },
                    MultiPolygon: function(t, n) {
                        for (var e = t.coordinates, r = -1, i = e.length; ++r < i;) Hr(e[r], n)
                    },
                    GeometryCollection: function(t, n) {
                        for (var e = t.geometries, r = -1, i = e.length; ++r < i;) Vr(e[r], n)
                    }
                };

            function Fr(t, n, e) {
                var r, i = -1,
                    o = t.length - e;
                for (n.lineStart(); ++i < o;) r = t[i], n.point(r[0], r[1], r[2]);
                n.lineEnd()
            }

            function Hr(t, n) {
                var e = -1,
                    r = t.length;
                for (n.polygonStart(); ++e < r;) Fr(t[e], n, 1);
                n.polygonEnd()
            }

            function Yr(t, n) {
                t && Dr.hasOwnProperty(t.type) ? Dr[t.type](t, n) : Vr(t, n)
            }

            function $r() {
                return new Gr
            }

            function Gr() {
                this.reset()
            }
            Gr.prototype = {
                constructor: Gr,
                reset: function() {
                    this.s = this.t = 0
                },
                add: function(t) {
                    Wr(Zr, t, this.t), Wr(this, Zr.s, this.s), this.s ? this.t += Zr.t : this.s = Zr.t
                },
                valueOf: function() {
                    return this.s
                }
            };
            var Zr = new Gr;

            function Wr(t, n, e) {
                var r = t.s = n + e,
                    i = r - n,
                    o = r - i;
                t.t = n - o + (e - i)
            }
            var Kr = Math.PI,
                Jr = 2 * Kr,
                Qr = Math.abs,
                ti = (Math.atan, Math.atan2, Math.cos, Math.ceil, Math.exp, Math.floor, Math.log, Math.pow, Math.sin, Math.sign, Math.sqrt);
            Math.tan;

            function ni() {}
            var ei, ri, ii, oi, ai = $r(),
                ui = $r(),
                fi = {
                    point: ni,
                    lineStart: ni,
                    lineEnd: ni,
                    polygonStart: function() {
                        fi.lineStart = ci, fi.lineEnd = hi
                    },
                    polygonEnd: function() {
                        fi.lineStart = fi.lineEnd = fi.point = ni, ai.add(Qr(ui)), ui.reset()
                    },
                    result: function() {
                        var t = ai / 2;
                        return ai.reset(), t
                    }
                };

            function ci() {
                fi.point = si
            }

            function si(t, n) {
                fi.point = li, ei = ii = t, ri = oi = n
            }

            function li(t, n) {
                ui.add(oi * t - ii * n), ii = t, oi = n
            }

            function hi() {
                li(ei, ri)
            }
            var di = fi,
                pi = 1 / 0,
                vi = pi,
                gi = -pi,
                yi = gi,
                _i = {
                    point: function(t, n) {
                        t < pi && (pi = t);
                        t > gi && (gi = t);
                        n < vi && (vi = n);
                        n > yi && (yi = n)
                    },
                    lineStart: ni,
                    lineEnd: ni,
                    polygonStart: ni,
                    polygonEnd: ni,
                    result: function() {
                        var t = [
                            [pi, vi],
                            [gi, yi]
                        ];
                        return gi = yi = -(vi = pi = 1 / 0), t
                    }
                };
            var bi, mi, wi, xi, Mi = _i,
                Ni = 0,
                Ai = 0,
                ki = 0,
                Ei = 0,
                Si = 0,
                Ci = 0,
                Li = 0,
                Ri = 0,
                Pi = 0,
                Ti = {
                    point: Ui,
                    lineStart: qi,
                    lineEnd: Ii,
                    polygonStart: function() {
                        Ti.lineStart = ji, Ti.lineEnd = Bi
                    },
                    polygonEnd: function() {
                        Ti.point = Ui, Ti.lineStart = qi, Ti.lineEnd = Ii
                    },
                    result: function() {
                        var t = Pi ? [Li / Pi, Ri / Pi] : Ci ? [Ei / Ci, Si / Ci] : ki ? [Ni / ki, Ai / ki] : [NaN, NaN];
                        return Ni = Ai = ki = Ei = Si = Ci = Li = Ri = Pi = 0, t
                    }
                };

            function Ui(t, n) {
                Ni += t, Ai += n, ++ki
            }

            function qi() {
                Ti.point = Oi
            }

            function Oi(t, n) {
                Ti.point = zi, Ui(wi = t, xi = n)
            }

            function zi(t, n) {
                var e = t - wi,
                    r = n - xi,
                    i = ti(e * e + r * r);
                Ei += i * (wi + t) / 2, Si += i * (xi + n) / 2, Ci += i, Ui(wi = t, xi = n)
            }

            function Ii() {
                Ti.point = Ui
            }

            function ji() {
                Ti.point = Vi
            }

            function Bi() {
                Di(bi, mi)
            }

            function Vi(t, n) {
                Ti.point = Di, Ui(bi = wi = t, mi = xi = n)
            }

            function Di(t, n) {
                var e = t - wi,
                    r = n - xi,
                    i = ti(e * e + r * r);
                Ei += i * (wi + t) / 2, Si += i * (xi + n) / 2, Ci += i, Li += (i = xi * t - wi * n) * (wi + t), Ri += i * (xi + n), Pi += 3 * i, Ui(wi = t, xi = n)
            }
            var Xi = Ti;

            function Fi(t) {
                this._context = t
            }
            Fi.prototype = {
                _radius: 4.5,
                pointRadius: function(t) {
                    return this._radius = t, this
                },
                polygonStart: function() {
                    this._line = 0
                },
                polygonEnd: function() {
                    this._line = NaN
                },
                lineStart: function() {
                    this._point = 0
                },
                lineEnd: function() {
                    0 === this._line && this._context.closePath(), this._point = NaN
                },
                point: function(t, n) {
                    switch (this._point) {
                        case 0:
                            this._context.moveTo(t, n), this._point = 1;
                            break;
                        case 1:
                            this._context.lineTo(t, n);
                            break;
                        default:
                            this._context.moveTo(t + this._radius, n), this._context.arc(t, n, this._radius, 0, Jr)
                    }
                },
                result: ni
            };
            var Hi, Yi, $i, Gi, Zi, Wi = $r(),
                Ki = {
                    point: ni,
                    lineStart: function() {
                        Ki.point = Ji
                    },
                    lineEnd: function() {
                        Hi && Qi(Yi, $i), Ki.point = ni
                    },
                    polygonStart: function() {
                        Hi = !0
                    },
                    polygonEnd: function() {
                        Hi = null
                    },
                    result: function() {
                        var t = +Wi;
                        return Wi.reset(), t
                    }
                };

            function Ji(t, n) {
                Ki.point = Qi, Yi = Gi = t, $i = Zi = n
            }

            function Qi(t, n) {
                Gi -= t, Zi -= n, Wi.add(ti(Gi * Gi + Zi * Zi)), Gi = t, Zi = n
            }
            var to = Ki;

            function no() {
                this._string = []
            }

            function eo(t) {
                return "m0," + t + "a" + t + "," + t + " 0 1,1 0," + -2 * t + "a" + t + "," + t + " 0 1,1 0," + 2 * t + "z"
            }

            function ro(t, n) {
                var e, r, i = 4.5;

                function o(t) {
                    return t && ("function" === typeof i && r.pointRadius(+i.apply(this, arguments)), Yr(t, e(r))), r.result()
                }
                return o.area = function(t) {
                    return Yr(t, e(di)), di.result()
                }, o.measure = function(t) {
                    return Yr(t, e(to)), to.result()
                }, o.bounds = function(t) {
                    return Yr(t, e(Mi)), Mi.result()
                }, o.centroid = function(t) {
                    return Yr(t, e(Xi)), Xi.result()
                }, o.projection = function(n) {
                    return arguments.length ? (e = null == n ? (t = null, Br) : (t = n).stream, o) : t
                }, o.context = function(t) {
                    return arguments.length ? (r = null == t ? (n = null, new no) : new Fi(n = t), "function" !== typeof i && r.pointRadius(i), o) : n
                }, o.pointRadius = function(t) {
                    return arguments.length ? (i = "function" === typeof t ? t : (r.pointRadius(+t), +t), o) : i
                }, o.projection(t).context(n)
            }

            function io() {
                return Math.random()
            }
            no.prototype = {
                _radius: 4.5,
                _circle: eo(4.5),
                pointRadius: function(t) {
                    return (t = +t) !== this._radius && (this._radius = t, this._circle = null), this
                },
                polygonStart: function() {
                    this._line = 0
                },
                polygonEnd: function() {
                    this._line = NaN
                },
                lineStart: function() {
                    this._point = 0
                },
                lineEnd: function() {
                    0 === this._line && this._string.push("Z"), this._point = NaN
                },
                point: function(t, n) {
                    switch (this._point) {
                        case 0:
                            this._string.push("M", t, ",", n), this._point = 1;
                            break;
                        case 1:
                            this._string.push("L", t, ",", n);
                            break;
                        default:
                            null == this._circle && (this._circle = eo(this._radius)), this._string.push("M", t, ",", n, this._circle)
                    }
                },
                result: function() {
                    if (this._string.length) {
                        var t = this._string.join("");
                        return this._string = [], t
                    }
                    return null
                }
            };
            (function t(n) {
                function e(t, e) {
                    return t = null == t ? 0 : +t, e = null == e ? 1 : +e, 1 === arguments.length ? (e = t, t = 0) : e -= t,
                        function() {
                            return n() * e + t
                        }
                }
                return e.source = t, e
            })(io);
            var oo = function t(n) {
                    function e(t, e) {
                        var r, i;
                        return t = null == t ? 0 : +t, e = null == e ? 1 : +e,
                            function() {
                                var o;
                                if (null != r) o = r, r = null;
                                else
                                    do {
                                        r = 2 * n() - 1, o = 2 * n() - 1, i = r * r + o * o
                                    } while (!i || i > 1);
                                return t + e * o * Math.sqrt(-2 * Math.log(i) / i)
                            }
                    }
                    return e.source = t, e
                }(io),
                ao = (function t(n) {
                    function e() {
                        var t = oo.source(n).apply(this, arguments);
                        return function() {
                            return Math.exp(t())
                        }
                    }
                    return e.source = t, e
                }(io), function t(n) {
                    function e(t) {
                        return function() {
                            for (var e = 0, r = 0; r < t; ++r) e += n();
                            return e
                        }
                    }
                    return e.source = t, e
                }(io));
            (function t(n) {
                function e(t) {
                    var e = ao.source(n)(t);
                    return function() {
                        return e() / t
                    }
                }
                return e.source = t, e
            })(io),
            function t(n) {
                function e(t) {
                    return function() {
                        return -Math.log(1 - n()) / t
                    }
                }
                return e.source = t, e
            }(io);

            function uo(t, n) {
                switch (arguments.length) {
                    case 0:
                        break;
                    case 1:
                        this.range(t);
                        break;
                    default:
                        this.range(n).domain(t)
                }
                return this
            }
            var fo = Array.prototype,
                co = fo.map,
                so = fo.slice,
                lo = {
                    name: "implicit"
                };

            function ho() {
                var t = Qe(),
                    n = [],
                    e = [],
                    r = lo;

                function i(i) {
                    var o = i + "",
                        a = t.get(o);
                    if (!a) {
                        if (r !== lo) return r;
                        t.set(o, a = n.push(i))
                    }
                    return e[(a - 1) % e.length]
                }
                return i.domain = function(e) {
                    if (!arguments.length) return n.slice();
                    n = [], t = Qe();
                    for (var r, o, a = -1, u = e.length; ++a < u;) t.has(o = (r = e[a]) + "") || t.set(o, n.push(r));
                    return i
                }, i.range = function(t) {
                    return arguments.length ? (e = so.call(t), i) : e.slice()
                }, i.unknown = function(t) {
                    return arguments.length ? (r = t, i) : r
                }, i.copy = function() {
                    return ho(n, e).unknown(r)
                }, uo.apply(i, arguments), i
            }

            function po() {
                var t, n, e = ho().unknown(void 0),
                    r = e.domain,
                    i = e.range,
                    o = [0, 1],
                    a = !1,
                    u = 0,
                    f = 0,
                    c = .5;

                function s() {
                    var e = r().length,
                        s = o[1] < o[0],
                        l = o[s - 0],
                        h = o[1 - s];
                    t = (h - l) / Math.max(1, e - u + 2 * f), a && (t = Math.floor(t)), l += (h - l - t * (e - u)) * c, n = t * (1 - u), a && (l = Math.round(l), n = Math.round(n));
                    var d = g(e).map((function(n) {
                        return l + t * n
                    }));
                    return i(s ? d.reverse() : d)
                }
                return delete e.unknown, e.domain = function(t) {
                    return arguments.length ? (r(t), s()) : r()
                }, e.range = function(t) {
                    return arguments.length ? (o = [+t[0], +t[1]], s()) : o.slice()
                }, e.rangeRound = function(t) {
                    return o = [+t[0], +t[1]], a = !0, s()
                }, e.bandwidth = function() {
                    return n
                }, e.step = function() {
                    return t
                }, e.round = function(t) {
                    return arguments.length ? (a = !!t, s()) : a
                }, e.padding = function(t) {
                    return arguments.length ? (u = Math.min(1, f = +t), s()) : u
                }, e.paddingInner = function(t) {
                    return arguments.length ? (u = Math.min(1, t), s()) : u
                }, e.paddingOuter = function(t) {
                    return arguments.length ? (f = +t, s()) : f
                }, e.align = function(t) {
                    return arguments.length ? (c = Math.max(0, Math.min(1, t)), s()) : c
                }, e.copy = function() {
                    return po(r(), o).round(a).paddingInner(u).paddingOuter(f).align(c)
                }, uo.apply(s(), arguments)
            }

            function vo(t, n) {
                var e, r = n ? n.length : 0,
                    i = t ? Math.min(r, t.length) : 0,
                    o = new Array(i),
                    a = new Array(r);
                for (e = 0; e < i; ++e) o[e] = bo(t[e], n[e]);
                for (; e < r; ++e) a[e] = n[e];
                return function(t) {
                    for (e = 0; e < i; ++e) a[e] = o[e](t);
                    return a
                }
            }

            function go(t, n) {
                var e = new Date;
                return t = +t, n = +n,
                    function(r) {
                        return e.setTime(t * (1 - r) + n * r), e
                    }
            }

            function yo(t, n) {
                var e, r = {},
                    i = {};
                for (e in null !== t && "object" === typeof t || (t = {}), null !== n && "object" === typeof n || (n = {}), n) e in t ? r[e] = bo(t[e], n[e]) : i[e] = n[e];
                return function(t) {
                    for (e in r) i[e] = r[e](t);
                    return i
                }
            }

            function _o(t, n) {
                n || (n = []);
                var e, r = t ? Math.min(n.length, t.length) : 0,
                    i = n.slice();
                return function(o) {
                    for (e = 0; e < r; ++e) i[e] = t[e] * (1 - o) + n[e] * o;
                    return i
                }
            }

            function bo(t, n) {
                var e, r = typeof n;
                return null == n || "boolean" === r ? fe(n) : ("number" === r ? gn : "string" === r ? (e = Gn(n)) ? (n = e, he) : ye : n instanceof Gn ? he : n instanceof Date ? go : function(t) {
                    return ArrayBuffer.isView(t) && !(t instanceof DataView)
                }(n) ? _o : Array.isArray(n) ? vo : "function" !== typeof n.valueOf && "function" !== typeof n.toString || isNaN(n) ? yo : gn)(t, n)
            }

            function mo(t, n) {
                return t = +t, n = +n,
                    function(e) {
                        return Math.round(t * (1 - e) + n * e)
                    }
            }

            function wo(t) {
                return +t
            }
            var xo = [0, 1];

            function Mo(t) {
                return t
            }

            function No(t, n) {
                return (n -= t = +t) ? function(e) {
                    return (e - t) / n
                } : function(t) {
                    return function() {
                        return t
                    }
                }(isNaN(n) ? NaN : .5)
            }

            function Ao(t) {
                var n, e = t[0],
                    r = t[t.length - 1];
                return e > r && (n = e, e = r, r = n),
                    function(t) {
                        return Math.max(e, Math.min(r, t))
                    }
            }

            function ko(t, n, e) {
                var r = t[0],
                    i = t[1],
                    o = n[0],
                    a = n[1];
                return i < r ? (r = No(i, r), o = e(a, o)) : (r = No(r, i), o = e(o, a)),
                    function(t) {
                        return o(r(t))
                    }
            }

            function Eo(t, n, e) {
                var r = Math.min(t.length, n.length) - 1,
                    i = new Array(r),
                    o = new Array(r),
                    u = -1;
                for (t[r] < t[0] && (t = t.slice().reverse(), n = n.slice().reverse()); ++u < r;) i[u] = No(t[u], t[u + 1]), o[u] = e(n[u], n[u + 1]);
                return function(n) {
                    var e = a(t, n, 1, r) - 1;
                    return o[e](i[e](n))
                }
            }

            function So(t, n) {
                return n.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())
            }

            function Co(t, n) {
                return function() {
                    var t, n, e, r, i, o, a = xo,
                        u = xo,
                        f = bo,
                        c = Mo;

                    function s() {
                        return r = Math.min(a.length, u.length) > 2 ? Eo : ko, i = o = null, l
                    }

                    function l(n) {
                        return isNaN(n = +n) ? e : (i || (i = r(a.map(t), u, f)))(t(c(n)))
                    }
                    return l.invert = function(e) {
                            return c(n((o || (o = r(u, a.map(t), gn)))(e)))
                        }, l.domain = function(t) {
                            return arguments.length ? (a = co.call(t, wo), c === Mo || (c = Ao(a)), s()) : a.slice()
                        }, l.range = function(t) {
                            return arguments.length ? (u = so.call(t), s()) : u.slice()
                        }, l.rangeRound = function(t) {
                            return u = so.call(t), f = mo, s()
                        }, l.clamp = function(t) {
                            return arguments.length ? (c = t ? Ao(a) : Mo, l) : c !== Mo
                        }, l.interpolate = function(t) {
                            return arguments.length ? (f = t, s()) : f
                        }, l.unknown = function(t) {
                            return arguments.length ? (e = t, l) : e
                        },
                        function(e, r) {
                            return t = e, n = r, s()
                        }
                }()(t, n)
            }
            var Lo, Ro = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;

            function Po(t) {
                if (!(n = Ro.exec(t))) throw new Error("invalid format: " + t);
                var n;
                return new To({
                    fill: n[1],
                    align: n[2],
                    sign: n[3],
                    symbol: n[4],
                    zero: n[5],
                    width: n[6],
                    comma: n[7],
                    precision: n[8] && n[8].slice(1),
                    trim: n[9],
                    type: n[10]
                })
            }

            function To(t) {
                this.fill = void 0 === t.fill ? " " : t.fill + "", this.align = void 0 === t.align ? ">" : t.align + "", this.sign = void 0 === t.sign ? "-" : t.sign + "", this.symbol = void 0 === t.symbol ? "" : t.symbol + "", this.zero = !!t.zero, this.width = void 0 === t.width ? void 0 : +t.width, this.comma = !!t.comma, this.precision = void 0 === t.precision ? void 0 : +t.precision, this.trim = !!t.trim, this.type = void 0 === t.type ? "" : t.type + ""
            }

            function Uo(t, n) {
                if ((e = (t = n ? t.toExponential(n - 1) : t.toExponential()).indexOf("e")) < 0) return null;
                var e, r = t.slice(0, e);
                return [r.length > 1 ? r[0] + r.slice(2) : r, +t.slice(e + 1)]
            }

            function qo(t) {
                return (t = Uo(Math.abs(t))) ? t[1] : NaN
            }

            function Oo(t, n) {
                var e = Uo(t, n);
                if (!e) return t + "";
                var r = e[0],
                    i = e[1];
                return i < 0 ? "0." + new Array(-i).join("0") + r : r.length > i + 1 ? r.slice(0, i + 1) + "." + r.slice(i + 1) : r + new Array(i - r.length + 2).join("0")
            }
            Po.prototype = To.prototype, To.prototype.toString = function() {
                return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (void 0 === this.width ? "" : Math.max(1, 0 | this.width)) + (this.comma ? "," : "") + (void 0 === this.precision ? "" : "." + Math.max(0, 0 | this.precision)) + (this.trim ? "~" : "") + this.type
            };
            var zo = {
                "%": function(t, n) {
                    return (100 * t).toFixed(n)
                },
                b: function(t) {
                    return Math.round(t).toString(2)
                },
                c: function(t) {
                    return t + ""
                },
                d: function(t) {
                    return Math.abs(t = Math.round(t)) >= 1e21 ? t.toLocaleString("en").replace(/,/g, "") : t.toString(10)
                },
                e: function(t, n) {
                    return t.toExponential(n)
                },
                f: function(t, n) {
                    return t.toFixed(n)
                },
                g: function(t, n) {
                    return t.toPrecision(n)
                },
                o: function(t) {
                    return Math.round(t).toString(8)
                },
                p: function(t, n) {
                    return Oo(100 * t, n)
                },
                r: Oo,
                s: function(t, n) {
                    var e = Uo(t, n);
                    if (!e) return t + "";
                    var r = e[0],
                        i = e[1],
                        o = i - (Lo = 3 * Math.max(-8, Math.min(8, Math.floor(i / 3)))) + 1,
                        a = r.length;
                    return o === a ? r : o > a ? r + new Array(o - a + 1).join("0") : o > 0 ? r.slice(0, o) + "." + r.slice(o) : "0." + new Array(1 - o).join("0") + Uo(t, Math.max(0, n + o - 1))[0]
                },
                X: function(t) {
                    return Math.round(t).toString(16).toUpperCase()
                },
                x: function(t) {
                    return Math.round(t).toString(16)
                }
            };

            function Io(t) {
                return t
            }
            var jo, Bo, Vo, Do = Array.prototype.map,
                Xo = ["y", "z", "a", "f", "p", "n", "\xb5", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];

            function Fo(t) {
                var n, e, r = void 0 === t.grouping || void 0 === t.thousands ? Io : (n = Do.call(t.grouping, Number), e = t.thousands + "", function(t, r) {
                        for (var i = t.length, o = [], a = 0, u = n[0], f = 0; i > 0 && u > 0 && (f + u + 1 > r && (u = Math.max(1, r - f)), o.push(t.substring(i -= u, i + u)), !((f += u + 1) > r));) u = n[a = (a + 1) % n.length];
                        return o.reverse().join(e)
                    }),
                    i = void 0 === t.currency ? "" : t.currency[0] + "",
                    o = void 0 === t.currency ? "" : t.currency[1] + "",
                    a = void 0 === t.decimal ? "." : t.decimal + "",
                    u = void 0 === t.numerals ? Io : function(t) {
                        return function(n) {
                            return n.replace(/[0-9]/g, (function(n) {
                                return t[+n]
                            }))
                        }
                    }(Do.call(t.numerals, String)),
                    f = void 0 === t.percent ? "%" : t.percent + "",
                    c = void 0 === t.minus ? "-" : t.minus + "",
                    s = void 0 === t.nan ? "NaN" : t.nan + "";

                function l(t) {
                    var n = (t = Po(t)).fill,
                        e = t.align,
                        l = t.sign,
                        h = t.symbol,
                        d = t.zero,
                        p = t.width,
                        v = t.comma,
                        g = t.precision,
                        y = t.trim,
                        _ = t.type;
                    "n" === _ ? (v = !0, _ = "g") : zo[_] || (void 0 === g && (g = 12), y = !0, _ = "g"), (d || "0" === n && "=" === e) && (d = !0, n = "0", e = "=");
                    var b = "$" === h ? i : "#" === h && /[boxX]/.test(_) ? "0" + _.toLowerCase() : "",
                        m = "$" === h ? o : /[%p]/.test(_) ? f : "",
                        w = zo[_],
                        x = /[defgprs%]/.test(_);

                    function M(t) {
                        var i, o, f, h = b,
                            M = m;
                        if ("c" === _) M = w(t) + M, t = "";
                        else {
                            var N = (t = +t) < 0 || 1 / t < 0;
                            if (t = isNaN(t) ? s : w(Math.abs(t), g), y && (t = function(t) {
                                    t: for (var n, e = t.length, r = 1, i = -1; r < e; ++r) switch (t[r]) {
                                        case ".":
                                            i = n = r;
                                            break;
                                        case "0":
                                            0 === i && (i = r), n = r;
                                            break;
                                        default:
                                            if (!+t[r]) break t;
                                            i > 0 && (i = 0)
                                    }
                                    return i > 0 ? t.slice(0, i) + t.slice(n + 1) : t
                                }(t)), N && 0 === +t && "+" !== l && (N = !1), h = (N ? "(" === l ? l : c : "-" === l || "(" === l ? "" : l) + h, M = ("s" === _ ? Xo[8 + Lo / 3] : "") + M + (N && "(" === l ? ")" : ""), x)
                                for (i = -1, o = t.length; ++i < o;)
                                    if (48 > (f = t.charCodeAt(i)) || f > 57) {
                                        M = (46 === f ? a + t.slice(i + 1) : t.slice(i)) + M, t = t.slice(0, i);
                                        break
                                    }
                        }
                        v && !d && (t = r(t, 1 / 0));
                        var A = h.length + t.length + M.length,
                            k = A < p ? new Array(p - A + 1).join(n) : "";
                        switch (v && d && (t = r(k + t, k.length ? p - M.length : 1 / 0), k = ""), e) {
                            case "<":
                                t = h + t + M + k;
                                break;
                            case "=":
                                t = h + k + t + M;
                                break;
                            case "^":
                                t = k.slice(0, A = k.length >> 1) + h + t + M + k.slice(A);
                                break;
                            default:
                                t = k + h + t + M
                        }
                        return u(t)
                    }
                    return g = void 0 === g ? 6 : /[gprs]/.test(_) ? Math.max(1, Math.min(21, g)) : Math.max(0, Math.min(20, g)), M.toString = function() {
                        return t + ""
                    }, M
                }
                return {
                    format: l,
                    formatPrefix: function(t, n) {
                        var e = l(((t = Po(t)).type = "f", t)),
                            r = 3 * Math.max(-8, Math.min(8, Math.floor(qo(n) / 3))),
                            i = Math.pow(10, -r),
                            o = Xo[8 + r / 3];
                        return function(t) {
                            return e(i * t) + o
                        }
                    }
                }
            }

            function Ho(t, n, e, r) {
                var i, o = d(t, n, e);
                switch ((r = Po(null == r ? ",f" : r)).type) {
                    case "s":
                        var a = Math.max(Math.abs(t), Math.abs(n));
                        return null != r.precision || isNaN(i = function(t, n) {
                            return Math.max(0, 3 * Math.max(-8, Math.min(8, Math.floor(qo(n) / 3))) - qo(Math.abs(t)))
                        }(o, a)) || (r.precision = i), Vo(r, a);
                    case "":
                    case "e":
                    case "g":
                    case "p":
                    case "r":
                        null != r.precision || isNaN(i = function(t, n) {
                            return t = Math.abs(t), n = Math.abs(n) - t, Math.max(0, qo(n) - qo(t)) + 1
                        }(o, Math.max(Math.abs(t), Math.abs(n)))) || (r.precision = i - ("e" === r.type));
                        break;
                    case "f":
                    case "%":
                        null != r.precision || isNaN(i = function(t) {
                            return Math.max(0, -qo(Math.abs(t)))
                        }(o)) || (r.precision = i - 2 * ("%" === r.type))
                }
                return Bo(r)
            }

            function Yo(t) {
                var n = t.domain;
                return t.ticks = function(t) {
                    var e = n();
                    return function(t, n, e) {
                        var r, i, o, a, u = -1;
                        if (e = +e, (t = +t) === (n = +n) && e > 0) return [t];
                        if ((r = n < t) && (i = t, t = n, n = i), 0 === (a = h(t, n, e)) || !isFinite(a)) return [];
                        if (a > 0)
                            for (t = Math.ceil(t / a), n = Math.floor(n / a), o = new Array(i = Math.ceil(n - t + 1)); ++u < i;) o[u] = (t + u) * a;
                        else
                            for (t = Math.floor(t * a), n = Math.ceil(n * a), o = new Array(i = Math.ceil(t - n + 1)); ++u < i;) o[u] = (t - u) / a;
                        return r && o.reverse(), o
                    }(e[0], e[e.length - 1], null == t ? 10 : t)
                }, t.tickFormat = function(t, e) {
                    var r = n();
                    return Ho(r[0], r[r.length - 1], null == t ? 10 : t, e)
                }, t.nice = function(e) {
                    null == e && (e = 10);
                    var r, i = n(),
                        o = 0,
                        a = i.length - 1,
                        u = i[o],
                        f = i[a];
                    return f < u && (r = u, u = f, f = r, r = o, o = a, a = r), (r = h(u, f, e)) > 0 ? r = h(u = Math.floor(u / r) * r, f = Math.ceil(f / r) * r, e) : r < 0 && (r = h(u = Math.ceil(u * r) / r, f = Math.floor(f * r) / r, e)), r > 0 ? (i[o] = Math.floor(u / r) * r, i[a] = Math.ceil(f / r) * r, n(i)) : r < 0 && (i[o] = Math.ceil(u * r) / r, i[a] = Math.floor(f * r) / r, n(i)), t
                }, t
            }

            function $o() {
                var t = Co(Mo, Mo);
                return t.copy = function() {
                    return So(t, $o())
                }, uo.apply(t, arguments), Yo(t)
            }
            jo = Fo({
                decimal: ".",
                thousands: ",",
                grouping: [3],
                currency: ["$", ""],
                minus: "-"
            }), Bo = jo.format, Vo = jo.formatPrefix;

            function Go(t) {
                for (var n = t.length / 6 | 0, e = new Array(n), r = 0; r < n;) e[r] = "#" + t.slice(6 * r, 6 * ++r);
                return e
            }
            var Zo = function(t) {
                return pe(t[t.length - 1])
            }(new Array(3).concat("fc8d59ffffbf91cf60", "d7191cfdae61a6d96a1a9641", "d7191cfdae61ffffbfa6d96a1a9641", "d73027fc8d59fee08bd9ef8b91cf601a9850", "d73027fc8d59fee08bffffbfd9ef8b91cf601a9850", "d73027f46d43fdae61fee08bd9ef8ba6d96a66bd631a9850", "d73027f46d43fdae61fee08bffffbfd9ef8ba6d96a66bd631a9850", "a50026d73027f46d43fdae61fee08bd9ef8ba6d96a66bd631a9850006837", "a50026d73027f46d43fdae61fee08bffffbfd9ef8ba6d96a66bd631a9850006837").map(Go));

            function Wo(t) {
                var n = t.length;
                return function(e) {
                    return t[Math.max(0, Math.min(n - 1, Math.floor(e * n)))]
                }
            }
            Wo(Go("44015444025645045745055946075a46085c460a5d460b5e470d60470e6147106347116447136548146748166848176948186a481a6c481b6d481c6e481d6f481f70482071482173482374482475482576482677482878482979472a7a472c7a472d7b472e7c472f7d46307e46327e46337f463480453581453781453882443983443a83443b84433d84433e85423f854240864241864142874144874045884046883f47883f48893e49893e4a893e4c8a3d4d8a3d4e8a3c4f8a3c508b3b518b3b528b3a538b3a548c39558c39568c38588c38598c375a8c375b8d365c8d365d8d355e8d355f8d34608d34618d33628d33638d32648e32658e31668e31678e31688e30698e306a8e2f6b8e2f6c8e2e6d8e2e6e8e2e6f8e2d708e2d718e2c718e2c728e2c738e2b748e2b758e2a768e2a778e2a788e29798e297a8e297b8e287c8e287d8e277e8e277f8e27808e26818e26828e26828e25838e25848e25858e24868e24878e23888e23898e238a8d228b8d228c8d228d8d218e8d218f8d21908d21918c20928c20928c20938c1f948c1f958b1f968b1f978b1f988b1f998a1f9a8a1e9b8a1e9c891e9d891f9e891f9f881fa0881fa1881fa1871fa28720a38620a48621a58521a68522a78522a88423a98324aa8325ab8225ac8226ad8127ad8128ae8029af7f2ab07f2cb17e2db27d2eb37c2fb47c31b57b32b67a34b67935b77937b87838b9773aba763bbb753dbc743fbc7340bd7242be7144bf7046c06f48c16e4ac16d4cc26c4ec36b50c46a52c56954c56856c66758c7655ac8645cc8635ec96260ca6063cb5f65cb5e67cc5c69cd5b6ccd5a6ece5870cf5773d05675d05477d1537ad1517cd2507fd34e81d34d84d44b86d54989d5488bd6468ed64590d74393d74195d84098d83e9bd93c9dd93ba0da39a2da37a5db36a8db34aadc32addc30b0dd2fb2dd2db5de2bb8de29bade28bddf26c0df25c2df23c5e021c8e020cae11fcde11dd0e11cd2e21bd5e21ad8e219dae319dde318dfe318e2e418e5e419e7e419eae51aece51befe51cf1e51df4e61ef6e620f8e621fbe723fde725")), Wo(Go("00000401000501010601010802010902020b02020d03030f03031204041405041606051806051a07061c08071e0907200a08220b09240c09260d0a290e0b2b100b2d110c2f120d31130d34140e36150e38160f3b180f3d19103f1a10421c10441d11471e114920114b21114e22115024125325125527125829115a2a115c2c115f2d11612f116331116533106734106936106b38106c390f6e3b0f703d0f713f0f72400f74420f75440f764510774710784910784a10794c117a4e117b4f127b51127c52137c54137d56147d57157e59157e5a167e5c167f5d177f5f187f601880621980641a80651a80671b80681c816a1c816b1d816d1d816e1e81701f81721f817320817521817621817822817922827b23827c23827e24828025828125818326818426818627818827818928818b29818c29818e2a81902a81912b81932b80942c80962c80982d80992d809b2e7f9c2e7f9e2f7fa02f7fa1307ea3307ea5317ea6317da8327daa337dab337cad347cae347bb0357bb2357bb3367ab5367ab73779b83779ba3878bc3978bd3977bf3a77c03a76c23b75c43c75c53c74c73d73c83e73ca3e72cc3f71cd4071cf4070d0416fd2426fd3436ed5446dd6456cd8456cd9466bdb476adc4869de4968df4a68e04c67e24d66e34e65e44f64e55064e75263e85362e95462ea5661eb5760ec5860ed5a5fee5b5eef5d5ef05f5ef1605df2625df2645cf3655cf4675cf4695cf56b5cf66c5cf66e5cf7705cf7725cf8745cf8765cf9785df9795df97b5dfa7d5efa7f5efa815ffb835ffb8560fb8761fc8961fc8a62fc8c63fc8e64fc9065fd9266fd9467fd9668fd9869fd9a6afd9b6bfe9d6cfe9f6dfea16efea36ffea571fea772fea973feaa74feac76feae77feb078feb27afeb47bfeb67cfeb77efeb97ffebb81febd82febf84fec185fec287fec488fec68afec88cfeca8dfecc8ffecd90fecf92fed194fed395fed597fed799fed89afdda9cfddc9efddea0fde0a1fde2a3fde3a5fde5a7fde7a9fde9aafdebacfcecaefceeb0fcf0b2fcf2b4fcf4b6fcf6b8fcf7b9fcf9bbfcfbbdfcfdbf"));
            var Ko = Wo(Go("00000401000501010601010802010a02020c02020e03021004031204031405041706041907051b08051d09061f0a07220b07240c08260d08290e092b10092d110a30120a32140b34150b37160b39180c3c190c3e1b0c411c0c431e0c451f0c48210c4a230c4c240c4f260c51280b53290b552b0b572d0b592f0a5b310a5c320a5e340a5f3609613809623909633b09643d09653e0966400a67420a68440a68450a69470b6a490b6a4a0c6b4c0c6b4d0d6c4f0d6c510e6c520e6d540f6d550f6d57106e59106e5a116e5c126e5d126e5f136e61136e62146e64156e65156e67166e69166e6a176e6c186e6d186e6f196e71196e721a6e741a6e751b6e771c6d781c6d7a1d6d7c1d6d7d1e6d7f1e6c801f6c82206c84206b85216b87216b88226a8a226a8c23698d23698f24699025689225689326679526679727669827669a28659b29649d29649f2a63a02a63a22b62a32c61a52c60a62d60a82e5fa92e5eab2f5ead305dae305cb0315bb1325ab3325ab43359b63458b73557b93556ba3655bc3754bd3853bf3952c03a51c13a50c33b4fc43c4ec63d4dc73e4cc83f4bca404acb4149cc4248ce4347cf4446d04545d24644d34743d44842d54a41d74b3fd84c3ed94d3dda4e3cdb503bdd513ade5238df5337e05536e15635e25734e35933e45a31e55c30e65d2fe75e2ee8602de9612bea632aeb6429eb6628ec6726ed6925ee6a24ef6c23ef6e21f06f20f1711ff1731df2741cf3761bf37819f47918f57b17f57d15f67e14f68013f78212f78410f8850ff8870ef8890cf98b0bf98c0af98e09fa9008fa9207fa9407fb9606fb9706fb9906fb9b06fb9d07fc9f07fca108fca309fca50afca60cfca80dfcaa0ffcac11fcae12fcb014fcb216fcb418fbb61afbb81dfbba1ffbbc21fbbe23fac026fac228fac42afac62df9c72ff9c932f9cb35f8cd37f8cf3af7d13df7d340f6d543f6d746f5d949f5db4cf4dd4ff4df53f4e156f3e35af3e55df2e661f2e865f2ea69f1ec6df1ed71f1ef75f1f179f2f27df2f482f3f586f3f68af4f88ef5f992f6fa96f8fb9af9fc9dfafda1fcffa4"));
            Wo(Go("0d088710078813078916078a19068c1b068d1d068e20068f2206902406912605912805922a05932c05942e05952f059631059733059735049837049938049a3a049a3c049b3e049c3f049c41049d43039e44039e46039f48039f4903a04b03a14c02a14e02a25002a25102a35302a35502a45601a45801a45901a55b01a55c01a65e01a66001a66100a76300a76400a76600a76700a86900a86a00a86c00a86e00a86f00a87100a87201a87401a87501a87701a87801a87a02a87b02a87d03a87e03a88004a88104a78305a78405a78606a68707a68808a68a09a58b0aa58d0ba58e0ca48f0da4910ea3920fa39410a29511a19613a19814a099159f9a169f9c179e9d189d9e199da01a9ca11b9ba21d9aa31e9aa51f99a62098a72197a82296aa2395ab2494ac2694ad2793ae2892b02991b12a90b22b8fb32c8eb42e8db52f8cb6308bb7318ab83289ba3388bb3488bc3587bd3786be3885bf3984c03a83c13b82c23c81c33d80c43e7fc5407ec6417dc7427cc8437bc9447aca457acb4679cc4778cc4977cd4a76ce4b75cf4c74d04d73d14e72d24f71d35171d45270d5536fd5546ed6556dd7566cd8576bd9586ada5a6ada5b69db5c68dc5d67dd5e66de5f65de6164df6263e06363e16462e26561e26660e3685fe4695ee56a5de56b5de66c5ce76e5be76f5ae87059e97158e97257ea7457eb7556eb7655ec7754ed7953ed7a52ee7b51ef7c51ef7e50f07f4ff0804ef1814df1834cf2844bf3854bf3874af48849f48948f58b47f58c46f68d45f68f44f79044f79143f79342f89441f89540f9973ff9983ef99a3efa9b3dfa9c3cfa9e3bfb9f3afba139fba238fca338fca537fca636fca835fca934fdab33fdac33fdae32fdaf31fdb130fdb22ffdb42ffdb52efeb72dfeb82cfeba2cfebb2bfebd2afebe2afec029fdc229fdc328fdc527fdc627fdc827fdca26fdcb26fccd25fcce25fcd025fcd225fbd324fbd524fbd724fad824fada24f9dc24f9dd25f8df25f8e125f7e225f7e425f6e626f6e826f5e926f5eb27f4ed27f3ee27f3f027f2f227f1f426f1f525f0f724f0f921"));

            function Jo(t) {
                return "string" === typeof t ? new qt([
                    [document.querySelector(t)]
                ], [document.documentElement]) : new qt([
                    [t]
                ], Ut)
            }
            var Qo = Math.PI,
                ta = 2 * Qo,
                na = 1e-6,
                ea = ta - na;

            function ra() {
                this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = ""
            }

            function ia() {
                return new ra
            }
            ra.prototype = ia.prototype = {
                constructor: ra,
                moveTo: function(t, n) {
                    this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +n)
                },
                closePath: function() {
                    null !== this._x1 && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z")
                },
                lineTo: function(t, n) {
                    this._ += "L" + (this._x1 = +t) + "," + (this._y1 = +n)
                },
                quadraticCurveTo: function(t, n, e, r) {
                    this._ += "Q" + +t + "," + +n + "," + (this._x1 = +e) + "," + (this._y1 = +r)
                },
                bezierCurveTo: function(t, n, e, r, i, o) {
                    this._ += "C" + +t + "," + +n + "," + +e + "," + +r + "," + (this._x1 = +i) + "," + (this._y1 = +o)
                },
                arcTo: function(t, n, e, r, i) {
                    t = +t, n = +n, e = +e, r = +r, i = +i;
                    var o = this._x1,
                        a = this._y1,
                        u = e - t,
                        f = r - n,
                        c = o - t,
                        s = a - n,
                        l = c * c + s * s;
                    if (i < 0) throw new Error("negative radius: " + i);
                    if (null === this._x1) this._ += "M" + (this._x1 = t) + "," + (this._y1 = n);
                    else if (l > na)
                        if (Math.abs(s * u - f * c) > na && i) {
                            var h = e - o,
                                d = r - a,
                                p = u * u + f * f,
                                v = h * h + d * d,
                                g = Math.sqrt(p),
                                y = Math.sqrt(l),
                                _ = i * Math.tan((Qo - Math.acos((p + l - v) / (2 * g * y))) / 2),
                                b = _ / y,
                                m = _ / g;
                            Math.abs(b - 1) > na && (this._ += "L" + (t + b * c) + "," + (n + b * s)), this._ += "A" + i + "," + i + ",0,0," + +(s * h > c * d) + "," + (this._x1 = t + m * u) + "," + (this._y1 = n + m * f)
                        } else this._ += "L" + (this._x1 = t) + "," + (this._y1 = n);
                    else;
                },
                arc: function(t, n, e, r, i, o) {
                    t = +t, n = +n, o = !!o;
                    var a = (e = +e) * Math.cos(r),
                        u = e * Math.sin(r),
                        f = t + a,
                        c = n + u,
                        s = 1 ^ o,
                        l = o ? r - i : i - r;
                    if (e < 0) throw new Error("negative radius: " + e);
                    null === this._x1 ? this._ += "M" + f + "," + c : (Math.abs(this._x1 - f) > na || Math.abs(this._y1 - c) > na) && (this._ += "L" + f + "," + c), e && (l < 0 && (l = l % ta + ta), l > ea ? this._ += "A" + e + "," + e + ",0,1," + s + "," + (t - a) + "," + (n - u) + "A" + e + "," + e + ",0,1," + s + "," + (this._x1 = f) + "," + (this._y1 = c) : l > na && (this._ += "A" + e + "," + e + ",0," + +(l >= Qo) + "," + s + "," + (this._x1 = t + e * Math.cos(i)) + "," + (this._y1 = n + e * Math.sin(i))))
                },
                rect: function(t, n, e, r) {
                    this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +n) + "h" + +e + "v" + +r + "h" + -e + "Z"
                },
                toString: function() {
                    return this._
                }
            };
            var oa = ia;

            function aa(t) {
                return function() {
                    return t
                }
            }
            var ua = Math.abs,
                fa = Math.atan2,
                ca = Math.cos,
                sa = Math.max,
                la = Math.min,
                ha = Math.sin,
                da = Math.sqrt,
                pa = 1e-12,
                va = Math.PI,
                ga = va / 2,
                ya = 2 * va;

            function _a(t) {
                return t > 1 ? 0 : t < -1 ? va : Math.acos(t)
            }

            function ba(t) {
                return t >= 1 ? ga : t <= -1 ? -ga : Math.asin(t)
            }

            function ma(t) {
                return t.innerRadius
            }

            function wa(t) {
                return t.outerRadius
            }

            function xa(t) {
                return t.startAngle
            }

            function Ma(t) {
                return t.endAngle
            }

            function Na(t) {
                return t && t.padAngle
            }

            function Aa(t, n, e, r, i, o, a, u) {
                var f = e - t,
                    c = r - n,
                    s = a - i,
                    l = u - o,
                    h = l * f - s * c;
                if (!(h * h < pa)) return [t + (h = (s * (n - o) - l * (t - i)) / h) * f, n + h * c]
            }

            function ka(t, n, e, r, i, o, a) {
                var u = t - e,
                    f = n - r,
                    c = (a ? o : -o) / da(u * u + f * f),
                    s = c * f,
                    l = -c * u,
                    h = t + s,
                    d = n + l,
                    p = e + s,
                    v = r + l,
                    g = (h + p) / 2,
                    y = (d + v) / 2,
                    _ = p - h,
                    b = v - d,
                    m = _ * _ + b * b,
                    w = i - o,
                    x = h * v - p * d,
                    M = (b < 0 ? -1 : 1) * da(sa(0, w * w * m - x * x)),
                    N = (x * b - _ * M) / m,
                    A = (-x * _ - b * M) / m,
                    k = (x * b + _ * M) / m,
                    E = (-x * _ + b * M) / m,
                    S = N - g,
                    C = A - y,
                    L = k - g,
                    R = E - y;
                return S * S + C * C > L * L + R * R && (N = k, A = E), {
                    cx: N,
                    cy: A,
                    x01: -s,
                    y01: -l,
                    x11: N * (i / w - 1),
                    y11: A * (i / w - 1)
                }
            }

            function Ea() {
                var t = ma,
                    n = wa,
                    e = aa(0),
                    r = null,
                    i = xa,
                    o = Ma,
                    a = Na,
                    u = null;

                function f() {
                    var f, c, s = +t.apply(this, arguments),
                        l = +n.apply(this, arguments),
                        h = i.apply(this, arguments) - ga,
                        d = o.apply(this, arguments) - ga,
                        p = ua(d - h),
                        v = d > h;
                    if (u || (u = f = oa()), l < s && (c = l, l = s, s = c), l > pa)
                        if (p > ya - pa) u.moveTo(l * ca(h), l * ha(h)), u.arc(0, 0, l, h, d, !v), s > pa && (u.moveTo(s * ca(d), s * ha(d)), u.arc(0, 0, s, d, h, v));
                        else {
                            var g, y, _ = h,
                                b = d,
                                m = h,
                                w = d,
                                x = p,
                                M = p,
                                N = a.apply(this, arguments) / 2,
                                A = N > pa && (r ? +r.apply(this, arguments) : da(s * s + l * l)),
                                k = la(ua(l - s) / 2, +e.apply(this, arguments)),
                                E = k,
                                S = k;
                            if (A > pa) {
                                var C = ba(A / s * ha(N)),
                                    L = ba(A / l * ha(N));
                                (x -= 2 * C) > pa ? (m += C *= v ? 1 : -1, w -= C) : (x = 0, m = w = (h + d) / 2), (M -= 2 * L) > pa ? (_ += L *= v ? 1 : -1, b -= L) : (M = 0, _ = b = (h + d) / 2)
                            }
                            var R = l * ca(_),
                                P = l * ha(_),
                                T = s * ca(w),
                                U = s * ha(w);
                            if (k > pa) {
                                var q, O = l * ca(b),
                                    z = l * ha(b),
                                    I = s * ca(m),
                                    j = s * ha(m);
                                if (p < va && (q = Aa(R, P, I, j, O, z, T, U))) {
                                    var B = R - q[0],
                                        V = P - q[1],
                                        D = O - q[0],
                                        X = z - q[1],
                                        F = 1 / ha(_a((B * D + V * X) / (da(B * B + V * V) * da(D * D + X * X))) / 2),
                                        H = da(q[0] * q[0] + q[1] * q[1]);
                                    E = la(k, (s - H) / (F - 1)), S = la(k, (l - H) / (F + 1))
                                }
                            }
                            M > pa ? S > pa ? (g = ka(I, j, R, P, l, S, v), y = ka(O, z, T, U, l, S, v), u.moveTo(g.cx + g.x01, g.cy + g.y01), S < k ? u.arc(g.cx, g.cy, S, fa(g.y01, g.x01), fa(y.y01, y.x01), !v) : (u.arc(g.cx, g.cy, S, fa(g.y01, g.x01), fa(g.y11, g.x11), !v), u.arc(0, 0, l, fa(g.cy + g.y11, g.cx + g.x11), fa(y.cy + y.y11, y.cx + y.x11), !v), u.arc(y.cx, y.cy, S, fa(y.y11, y.x11), fa(y.y01, y.x01), !v))) : (u.moveTo(R, P), u.arc(0, 0, l, _, b, !v)) : u.moveTo(R, P), s > pa && x > pa ? E > pa ? (g = ka(T, U, O, z, s, -E, v), y = ka(R, P, I, j, s, -E, v), u.lineTo(g.cx + g.x01, g.cy + g.y01), E < k ? u.arc(g.cx, g.cy, E, fa(g.y01, g.x01), fa(y.y01, y.x01), !v) : (u.arc(g.cx, g.cy, E, fa(g.y01, g.x01), fa(g.y11, g.x11), !v), u.arc(0, 0, s, fa(g.cy + g.y11, g.cx + g.x11), fa(y.cy + y.y11, y.cx + y.x11), v), u.arc(y.cx, y.cy, E, fa(y.y11, y.x11), fa(y.y01, y.x01), !v))) : u.arc(0, 0, s, w, m, v) : u.lineTo(T, U)
                        }
                    else u.moveTo(0, 0);
                    if (u.closePath(), f) return u = null, f + "" || null
                }
                return f.centroid = function() {
                    var e = (+t.apply(this, arguments) + +n.apply(this, arguments)) / 2,
                        r = (+i.apply(this, arguments) + +o.apply(this, arguments)) / 2 - va / 2;
                    return [ca(r) * e, ha(r) * e]
                }, f.innerRadius = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : aa(+n), f) : t
                }, f.outerRadius = function(t) {
                    return arguments.length ? (n = "function" === typeof t ? t : aa(+t), f) : n
                }, f.cornerRadius = function(t) {
                    return arguments.length ? (e = "function" === typeof t ? t : aa(+t), f) : e
                }, f.padRadius = function(t) {
                    return arguments.length ? (r = null == t ? null : "function" === typeof t ? t : aa(+t), f) : r
                }, f.startAngle = function(t) {
                    return arguments.length ? (i = "function" === typeof t ? t : aa(+t), f) : i
                }, f.endAngle = function(t) {
                    return arguments.length ? (o = "function" === typeof t ? t : aa(+t), f) : o
                }, f.padAngle = function(t) {
                    return arguments.length ? (a = "function" === typeof t ? t : aa(+t), f) : a
                }, f.context = function(t) {
                    return arguments.length ? (u = null == t ? null : t, f) : u
                }, f
            }

            function Sa(t) {
                this._context = t
            }

            function Ca(t) {
                return new Sa(t)
            }

            function La(t) {
                return t[0]
            }

            function Ra(t) {
                return t[1]
            }

            function Pa() {
                var t = La,
                    n = Ra,
                    e = aa(!0),
                    r = null,
                    i = Ca,
                    o = null;

                function a(a) {
                    var u, f, c, s = a.length,
                        l = !1;
                    for (null == r && (o = i(c = oa())), u = 0; u <= s; ++u) !(u < s && e(f = a[u], u, a)) === l && ((l = !l) ? o.lineStart() : o.lineEnd()), l && o.point(+t(f, u, a), +n(f, u, a));
                    if (c) return o = null, c + "" || null
                }
                return a.x = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : aa(+n), a) : t
                }, a.y = function(t) {
                    return arguments.length ? (n = "function" === typeof t ? t : aa(+t), a) : n
                }, a.defined = function(t) {
                    return arguments.length ? (e = "function" === typeof t ? t : aa(!!t), a) : e
                }, a.curve = function(t) {
                    return arguments.length ? (i = t, null != r && (o = i(r)), a) : i
                }, a.context = function(t) {
                    return arguments.length ? (null == t ? r = o = null : o = i(r = t), a) : r
                }, a
            }

            function Ta() {
                var t = La,
                    n = null,
                    e = aa(0),
                    r = Ra,
                    i = aa(!0),
                    o = null,
                    a = Ca,
                    u = null;

                function f(f) {
                    var c, s, l, h, d, p = f.length,
                        v = !1,
                        g = new Array(p),
                        y = new Array(p);
                    for (null == o && (u = a(d = oa())), c = 0; c <= p; ++c) {
                        if (!(c < p && i(h = f[c], c, f)) === v)
                            if (v = !v) s = c, u.areaStart(), u.lineStart();
                            else {
                                for (u.lineEnd(), u.lineStart(), l = c - 1; l >= s; --l) u.point(g[l], y[l]);
                                u.lineEnd(), u.areaEnd()
                            }
                        v && (g[c] = +t(h, c, f), y[c] = +e(h, c, f), u.point(n ? +n(h, c, f) : g[c], r ? +r(h, c, f) : y[c]))
                    }
                    if (d) return u = null, d + "" || null
                }

                function c() {
                    return Pa().defined(i).curve(a).context(o)
                }
                return f.x = function(e) {
                    return arguments.length ? (t = "function" === typeof e ? e : aa(+e), n = null, f) : t
                }, f.x0 = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : aa(+n), f) : t
                }, f.x1 = function(t) {
                    return arguments.length ? (n = null == t ? null : "function" === typeof t ? t : aa(+t), f) : n
                }, f.y = function(t) {
                    return arguments.length ? (e = "function" === typeof t ? t : aa(+t), r = null, f) : e
                }, f.y0 = function(t) {
                    return arguments.length ? (e = "function" === typeof t ? t : aa(+t), f) : e
                }, f.y1 = function(t) {
                    return arguments.length ? (r = null == t ? null : "function" === typeof t ? t : aa(+t), f) : r
                }, f.lineX0 = f.lineY0 = function() {
                    return c().x(t).y(e)
                }, f.lineY1 = function() {
                    return c().x(t).y(r)
                }, f.lineX1 = function() {
                    return c().x(n).y(e)
                }, f.defined = function(t) {
                    return arguments.length ? (i = "function" === typeof t ? t : aa(!!t), f) : i
                }, f.curve = function(t) {
                    return arguments.length ? (a = t, null != o && (u = a(o)), f) : a
                }, f.context = function(t) {
                    return arguments.length ? (null == t ? o = u = null : u = a(o = t), f) : o
                }, f
            }

            function Ua(t, n) {
                return n < t ? -1 : n > t ? 1 : n >= t ? 0 : NaN
            }

            function qa(t) {
                return t
            }

            function Oa() {
                var t = qa,
                    n = Ua,
                    e = null,
                    r = aa(0),
                    i = aa(ya),
                    o = aa(0);

                function a(a) {
                    var u, f, c, s, l, h = a.length,
                        d = 0,
                        p = new Array(h),
                        v = new Array(h),
                        g = +r.apply(this, arguments),
                        y = Math.min(ya, Math.max(-ya, i.apply(this, arguments) - g)),
                        _ = Math.min(Math.abs(y) / h, o.apply(this, arguments)),
                        b = _ * (y < 0 ? -1 : 1);
                    for (u = 0; u < h; ++u)(l = v[p[u] = u] = +t(a[u], u, a)) > 0 && (d += l);
                    for (null != n ? p.sort((function(t, e) {
                            return n(v[t], v[e])
                        })) : null != e && p.sort((function(t, n) {
                            return e(a[t], a[n])
                        })), u = 0, c = d ? (y - h * b) / d : 0; u < h; ++u, g = s) f = p[u], s = g + ((l = v[f]) > 0 ? l * c : 0) + b, v[f] = {
                        data: a[f],
                        index: u,
                        value: l,
                        startAngle: g,
                        endAngle: s,
                        padAngle: _
                    };
                    return v
                }
                return a.value = function(n) {
                    return arguments.length ? (t = "function" === typeof n ? n : aa(+n), a) : t
                }, a.sortValues = function(t) {
                    return arguments.length ? (n = t, e = null, a) : n
                }, a.sort = function(t) {
                    return arguments.length ? (e = t, n = null, a) : e
                }, a.startAngle = function(t) {
                    return arguments.length ? (r = "function" === typeof t ? t : aa(+t), a) : r
                }, a.endAngle = function(t) {
                    return arguments.length ? (i = "function" === typeof t ? t : aa(+t), a) : i
                }, a.padAngle = function(t) {
                    return arguments.length ? (o = "function" === typeof t ? t : aa(+t), a) : o
                }, a
            }

            function za(t, n, e) {
                t._context.bezierCurveTo((2 * t._x0 + t._x1) / 3, (2 * t._y0 + t._y1) / 3, (t._x0 + 2 * t._x1) / 3, (t._y0 + 2 * t._y1) / 3, (t._x0 + 4 * t._x1 + n) / 6, (t._y0 + 4 * t._y1 + e) / 6)
            }

            function Ia(t) {
                this._context = t
            }

            function ja(t) {
                return new Ia(t)
            }

            function Ba(t, n) {
                this._context = t, this._t = n
            }

            function Va(t) {
                return new Ba(t, 1)
            }

            function Da() {
                this._ = null
            }

            function Xa(t) {
                t.U = t.C = t.L = t.R = t.P = t.N = null
            }

            function Fa(t, n) {
                var e = n,
                    r = n.R,
                    i = e.U;
                i ? i.L === e ? i.L = r : i.R = r : t._ = r, r.U = i, e.U = r, e.R = r.L, e.R && (e.R.U = e), r.L = e
            }

            function Ha(t, n) {
                var e = n,
                    r = n.L,
                    i = e.U;
                i ? i.L === e ? i.L = r : i.R = r : t._ = r, r.U = i, e.U = r, e.L = r.R, e.L && (e.L.U = e), r.R = e
            }

            function Ya(t) {
                for (; t.L;) t = t.L;
                return t
            }
            Sa.prototype = {
                areaStart: function() {
                    this._line = 0
                },
                areaEnd: function() {
                    this._line = NaN
                },
                lineStart: function() {
                    this._point = 0
                },
                lineEnd: function() {
                    (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                },
                point: function(t, n) {
                    switch (t = +t, n = +n, this._point) {
                        case 0:
                            this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                            break;
                        case 1:
                            this._point = 2;
                        default:
                            this._context.lineTo(t, n)
                    }
                }
            }, Ia.prototype = {
                areaStart: function() {
                    this._line = 0
                },
                areaEnd: function() {
                    this._line = NaN
                },
                lineStart: function() {
                    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
                },
                lineEnd: function() {
                    switch (this._point) {
                        case 3:
                            za(this, this._x1, this._y1);
                        case 2:
                            this._context.lineTo(this._x1, this._y1)
                    }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                },
                point: function(t, n) {
                    switch (t = +t, n = +n, this._point) {
                        case 0:
                            this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                            break;
                        case 1:
                            this._point = 2;
                            break;
                        case 2:
                            this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
                        default:
                            za(this, t, n)
                    }
                    this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = n
                }
            }, Ba.prototype = {
                areaStart: function() {
                    this._line = 0
                },
                areaEnd: function() {
                    this._line = NaN
                },
                lineStart: function() {
                    this._x = this._y = NaN, this._point = 0
                },
                lineEnd: function() {
                    0 < this._t && this._t < 1 && 2 === this._point && this._context.lineTo(this._x, this._y), (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line)
                },
                point: function(t, n) {
                    switch (t = +t, n = +n, this._point) {
                        case 0:
                            this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                            break;
                        case 1:
                            this._point = 2;
                        default:
                            if (this._t <= 0) this._context.lineTo(this._x, n), this._context.lineTo(t, n);
                            else {
                                var e = this._x * (1 - this._t) + t * this._t;
                                this._context.lineTo(e, this._y), this._context.lineTo(e, n)
                            }
                    }
                    this._x = t, this._y = n
                }
            }, Da.prototype = {
                constructor: Da,
                insert: function(t, n) {
                    var e, r, i;
                    if (t) {
                        if (n.P = t, n.N = t.N, t.N && (t.N.P = n), t.N = n, t.R) {
                            for (t = t.R; t.L;) t = t.L;
                            t.L = n
                        } else t.R = n;
                        e = t
                    } else this._ ? (t = Ya(this._), n.P = null, n.N = t, t.P = t.L = n, e = t) : (n.P = n.N = null, this._ = n, e = null);
                    for (n.L = n.R = null, n.U = e, n.C = !0, t = n; e && e.C;) e === (r = e.U).L ? (i = r.R) && i.C ? (e.C = i.C = !1, r.C = !0, t = r) : (t === e.R && (Fa(this, e), e = (t = e).U), e.C = !1, r.C = !0, Ha(this, r)) : (i = r.L) && i.C ? (e.C = i.C = !1, r.C = !0, t = r) : (t === e.L && (Ha(this, e), e = (t = e).U), e.C = !1, r.C = !0, Fa(this, r)), e = t.U;
                    this._.C = !1
                },
                remove: function(t) {
                    t.N && (t.N.P = t.P), t.P && (t.P.N = t.N), t.N = t.P = null;
                    var n, e, r, i = t.U,
                        o = t.L,
                        a = t.R;
                    if (e = o ? a ? Ya(a) : o : a, i ? i.L === t ? i.L = e : i.R = e : this._ = e, o && a ? (r = e.C, e.C = t.C, e.L = o, o.U = e, e !== a ? (i = e.U, e.U = t.U, t = e.R, i.L = t, e.R = a, a.U = e) : (e.U = i, i = e, t = e.R)) : (r = t.C, t = e), t && (t.U = i), !r)
                        if (t && t.C) t.C = !1;
                        else {
                            do {
                                if (t === this._) break;
                                if (t === i.L) {
                                    if ((n = i.R).C && (n.C = !1, i.C = !0, Fa(this, i), n = i.R), n.L && n.L.C || n.R && n.R.C) {
                                        n.R && n.R.C || (n.L.C = !1, n.C = !0, Ha(this, n), n = i.R), n.C = i.C, i.C = n.R.C = !1, Fa(this, i), t = this._;
                                        break
                                    }
                                } else if ((n = i.L).C && (n.C = !1, i.C = !0, Ha(this, i), n = i.L), n.L && n.L.C || n.R && n.R.C) {
                                    n.L && n.L.C || (n.R.C = !1, n.C = !0, Fa(this, n), n = i.L), n.C = i.C, i.C = n.L.C = !1, Ha(this, i), t = this._;
                                    break
                                }
                                n.C = !0, t = i, i = i.U
                            } while (!t.C);
                            t && (t.C = !1)
                        }
                }
            };
            var $a = Da;

            function Ga(t, n, e, r) {
                var i = [null, null],
                    o = _u.push(i) - 1;
                return i.left = t, i.right = n, e && Wa(i, t, n, e), r && Wa(i, n, t, r), gu[t.index].halfedges.push(o), gu[n.index].halfedges.push(o), i
            }

            function Za(t, n, e) {
                var r = [n, e];
                return r.left = t, r
            }

            function Wa(t, n, e, r) {
                t[0] || t[1] ? t.left === e ? t[1] = r : t[0] = r : (t[0] = r, t.left = n, t.right = e)
            }

            function Ka(t, n, e, r, i) {
                var o, a = t[0],
                    u = t[1],
                    f = a[0],
                    c = a[1],
                    s = 0,
                    l = 1,
                    h = u[0] - f,
                    d = u[1] - c;
                if (o = n - f, h || !(o > 0)) {
                    if (o /= h, h < 0) {
                        if (o < s) return;
                        o < l && (l = o)
                    } else if (h > 0) {
                        if (o > l) return;
                        o > s && (s = o)
                    }
                    if (o = r - f, h || !(o < 0)) {
                        if (o /= h, h < 0) {
                            if (o > l) return;
                            o > s && (s = o)
                        } else if (h > 0) {
                            if (o < s) return;
                            o < l && (l = o)
                        }
                        if (o = e - c, d || !(o > 0)) {
                            if (o /= d, d < 0) {
                                if (o < s) return;
                                o < l && (l = o)
                            } else if (d > 0) {
                                if (o > l) return;
                                o > s && (s = o)
                            }
                            if (o = i - c, d || !(o < 0)) {
                                if (o /= d, d < 0) {
                                    if (o > l) return;
                                    o > s && (s = o)
                                } else if (d > 0) {
                                    if (o < s) return;
                                    o < l && (l = o)
                                }
                                return !(s > 0 || l < 1) || (s > 0 && (t[0] = [f + s * h, c + s * d]), l < 1 && (t[1] = [f + l * h, c + l * d]), !0)
                            }
                        }
                    }
                }
            }

            function Ja(t, n, e, r, i) {
                var o = t[1];
                if (o) return !0;
                var a, u, f = t[0],
                    c = t.left,
                    s = t.right,
                    l = c[0],
                    h = c[1],
                    d = s[0],
                    p = s[1],
                    v = (l + d) / 2,
                    g = (h + p) / 2;
                if (p === h) {
                    if (v < n || v >= r) return;
                    if (l > d) {
                        if (f) {
                            if (f[1] >= i) return
                        } else f = [v, e];
                        o = [v, i]
                    } else {
                        if (f) {
                            if (f[1] < e) return
                        } else f = [v, i];
                        o = [v, e]
                    }
                } else if (u = g - (a = (l - d) / (p - h)) * v, a < -1 || a > 1)
                    if (l > d) {
                        if (f) {
                            if (f[1] >= i) return
                        } else f = [(e - u) / a, e];
                        o = [(i - u) / a, i]
                    } else {
                        if (f) {
                            if (f[1] < e) return
                        } else f = [(i - u) / a, i];
                        o = [(e - u) / a, e]
                    }
                else if (h < p) {
                    if (f) {
                        if (f[0] >= r) return
                    } else f = [n, a * n + u];
                    o = [r, a * r + u]
                } else {
                    if (f) {
                        if (f[0] < n) return
                    } else f = [r, a * r + u];
                    o = [n, a * n + u]
                }
                return t[0] = f, t[1] = o, !0
            }

            function Qa(t, n) {
                var e = t.site,
                    r = n.left,
                    i = n.right;
                return e === i && (i = r, r = e), i ? Math.atan2(i[1] - r[1], i[0] - r[0]) : (e === r ? (r = n[1], i = n[0]) : (r = n[0], i = n[1]), Math.atan2(r[0] - i[0], i[1] - r[1]))
            }

            function tu(t, n) {
                return n[+(n.left !== t.site)]
            }

            function nu(t, n) {
                return n[+(n.left === t.site)]
            }
            var eu, ru = [];

            function iu() {
                Xa(this), this.x = this.y = this.arc = this.site = this.cy = null
            }

            function ou(t) {
                var n = t.P,
                    e = t.N;
                if (n && e) {
                    var r = n.site,
                        i = t.site,
                        o = e.site;
                    if (r !== o) {
                        var a = i[0],
                            u = i[1],
                            f = r[0] - a,
                            c = r[1] - u,
                            s = o[0] - a,
                            l = o[1] - u,
                            h = 2 * (f * l - c * s);
                        if (!(h >= -mu)) {
                            var d = f * f + c * c,
                                p = s * s + l * l,
                                v = (l * d - c * p) / h,
                                g = (f * p - s * d) / h,
                                y = ru.pop() || new iu;
                            y.arc = t, y.site = i, y.x = v + a, y.y = (y.cy = g + u) + Math.sqrt(v * v + g * g), t.circle = y;
                            for (var _ = null, b = yu._; b;)
                                if (y.y < b.y || y.y === b.y && y.x <= b.x) {
                                    if (!b.L) {
                                        _ = b.P;
                                        break
                                    }
                                    b = b.L
                                } else {
                                    if (!b.R) {
                                        _ = b;
                                        break
                                    }
                                    b = b.R
                                }
                            yu.insert(_, y), _ || (eu = y)
                        }
                    }
                }
            }

            function au(t) {
                var n = t.circle;
                n && (n.P || (eu = n.N), yu.remove(n), ru.push(n), Xa(n), t.circle = null)
            }
            var uu = [];

            function fu() {
                Xa(this), this.edge = this.site = this.circle = null
            }

            function cu(t) {
                var n = uu.pop() || new fu;
                return n.site = t, n
            }

            function su(t) {
                au(t), vu.remove(t), uu.push(t), Xa(t)
            }

            function lu(t) {
                var n = t.circle,
                    e = n.x,
                    r = n.cy,
                    i = [e, r],
                    o = t.P,
                    a = t.N,
                    u = [t];
                su(t);
                for (var f = o; f.circle && Math.abs(e - f.circle.x) < bu && Math.abs(r - f.circle.cy) < bu;) o = f.P, u.unshift(f), su(f), f = o;
                u.unshift(f), au(f);
                for (var c = a; c.circle && Math.abs(e - c.circle.x) < bu && Math.abs(r - c.circle.cy) < bu;) a = c.N, u.push(c), su(c), c = a;
                u.push(c), au(c);
                var s, l = u.length;
                for (s = 1; s < l; ++s) c = u[s], f = u[s - 1], Wa(c.edge, f.site, c.site, i);
                f = u[0], (c = u[l - 1]).edge = Ga(f.site, c.site, null, i), ou(f), ou(c)
            }

            function hu(t) {
                for (var n, e, r, i, o = t[0], a = t[1], u = vu._; u;)
                    if ((r = du(u, a) - o) > bu) u = u.L;
                    else {
                        if (!((i = o - pu(u, a)) > bu)) {
                            r > -bu ? (n = u.P, e = u) : i > -bu ? (n = u, e = u.N) : n = e = u;
                            break
                        }
                        if (!u.R) {
                            n = u;
                            break
                        }
                        u = u.R
                    }! function(t) {
                    gu[t.index] = {
                        site: t,
                        halfedges: []
                    }
                }(t);
                var f = cu(t);
                if (vu.insert(n, f), n || e) {
                    if (n === e) return au(n), e = cu(n.site), vu.insert(f, e), f.edge = e.edge = Ga(n.site, f.site), ou(n), void ou(e);
                    if (e) {
                        au(n), au(e);
                        var c = n.site,
                            s = c[0],
                            l = c[1],
                            h = t[0] - s,
                            d = t[1] - l,
                            p = e.site,
                            v = p[0] - s,
                            g = p[1] - l,
                            y = 2 * (h * g - d * v),
                            _ = h * h + d * d,
                            b = v * v + g * g,
                            m = [(g * _ - d * b) / y + s, (h * b - v * _) / y + l];
                        Wa(e.edge, c, p, m), f.edge = Ga(c, t, null, m), e.edge = Ga(t, p, null, m), ou(n), ou(e)
                    } else f.edge = Ga(n.site, f.site)
                }
            }

            function du(t, n) {
                var e = t.site,
                    r = e[0],
                    i = e[1],
                    o = i - n;
                if (!o) return r;
                var a = t.P;
                if (!a) return -1 / 0;
                var u = (e = a.site)[0],
                    f = e[1],
                    c = f - n;
                if (!c) return u;
                var s = u - r,
                    l = 1 / o - 1 / c,
                    h = s / c;
                return l ? (-h + Math.sqrt(h * h - 2 * l * (s * s / (-2 * c) - f + c / 2 + i - o / 2))) / l + r : (r + u) / 2
            }

            function pu(t, n) {
                var e = t.N;
                if (e) return du(e, n);
                var r = t.site;
                return r[1] === n ? r[0] : 1 / 0
            }
            var vu, gu, yu, _u, bu = 1e-6,
                mu = 1e-12;

            function wu(t, n) {
                return n[1] - t[1] || n[0] - t[0]
            }

            function xu(t, n) {
                var e, r, i, o = t.sort(wu).pop();
                for (_u = [], gu = new Array(t.length), vu = new $a, yu = new $a;;)
                    if (i = eu, o && (!i || o[1] < i.y || o[1] === i.y && o[0] < i.x)) o[0] === e && o[1] === r || (hu(o), e = o[0], r = o[1]), o = t.pop();
                    else {
                        if (!i) break;
                        lu(i.arc)
                    }
                if (function() {
                        for (var t, n, e, r, i = 0, o = gu.length; i < o; ++i)
                            if ((t = gu[i]) && (r = (n = t.halfedges).length)) {
                                var a = new Array(r),
                                    u = new Array(r);
                                for (e = 0; e < r; ++e) a[e] = e, u[e] = Qa(t, _u[n[e]]);
                                for (a.sort((function(t, n) {
                                        return u[n] - u[t]
                                    })), e = 0; e < r; ++e) u[e] = n[a[e]];
                                for (e = 0; e < r; ++e) n[e] = u[e]
                            }
                    }(), n) {
                    var a = +n[0][0],
                        u = +n[0][1],
                        f = +n[1][0],
                        c = +n[1][1];
                    ! function(t, n, e, r) {
                        for (var i, o = _u.length; o--;) Ja(i = _u[o], t, n, e, r) && Ka(i, t, n, e, r) && (Math.abs(i[0][0] - i[1][0]) > bu || Math.abs(i[0][1] - i[1][1]) > bu) || delete _u[o]
                    }(a, u, f, c),
                    function(t, n, e, r) {
                        var i, o, a, u, f, c, s, l, h, d, p, v, g = gu.length,
                            y = !0;
                        for (i = 0; i < g; ++i)
                            if (o = gu[i]) {
                                for (a = o.site, u = (f = o.halfedges).length; u--;) _u[f[u]] || f.splice(u, 1);
                                for (u = 0, c = f.length; u < c;) p = (d = nu(o, _u[f[u]]))[0], v = d[1], l = (s = tu(o, _u[f[++u % c]]))[0], h = s[1], (Math.abs(p - l) > bu || Math.abs(v - h) > bu) && (f.splice(u, 0, _u.push(Za(a, d, Math.abs(p - t) < bu && r - v > bu ? [t, Math.abs(l - t) < bu ? h : r] : Math.abs(v - r) < bu && e - p > bu ? [Math.abs(h - r) < bu ? l : e, r] : Math.abs(p - e) < bu && v - n > bu ? [e, Math.abs(l - e) < bu ? h : n] : Math.abs(v - n) < bu && p - t > bu ? [Math.abs(h - n) < bu ? l : t, n] : null)) - 1), ++c);
                                c && (y = !1)
                            }
                        if (y) {
                            var _, b, m, w = 1 / 0;
                            for (i = 0, y = null; i < g; ++i)(o = gu[i]) && (m = (_ = (a = o.site)[0] - t) * _ + (b = a[1] - n) * b) < w && (w = m, y = o);
                            if (y) {
                                var x = [t, n],
                                    M = [t, r],
                                    N = [e, r],
                                    A = [e, n];
                                y.halfedges.push(_u.push(Za(a = y.site, x, M)) - 1, _u.push(Za(a, M, N)) - 1, _u.push(Za(a, N, A)) - 1, _u.push(Za(a, A, x)) - 1)
                            }
                        }
                        for (i = 0; i < g; ++i)(o = gu[i]) && (o.halfedges.length || delete gu[i])
                    }(a, u, f, c)
                }
                this.edges = _u, this.cells = gu, vu = yu = _u = gu = null
            }

            function Mu(t, n, e) {
                this.k = t, this.x = n, this.y = e
            }
            xu.prototype = {
                constructor: xu,
                polygons: function() {
                    var t = this.edges;
                    return this.cells.map((function(n) {
                        var e = n.halfedges.map((function(e) {
                            return tu(n, t[e])
                        }));
                        return e.data = n.site.data, e
                    }))
                },
                triangles: function() {
                    var t = [],
                        n = this.edges;
                    return this.cells.forEach((function(e, r) {
                        if (o = (i = e.halfedges).length)
                            for (var i, o, a, u, f, c, s = e.site, l = -1, h = n[i[o - 1]], d = h.left === s ? h.right : h.left; ++l < o;) a = d, d = (h = n[i[l]]).left === s ? h.right : h.left, a && d && r < a.index && r < d.index && (f = a, c = d, ((u = s)[0] - c[0]) * (f[1] - u[1]) - (u[0] - f[0]) * (c[1] - u[1]) < 0) && t.push([s.data, a.data, d.data])
                    })), t
                },
                links: function() {
                    return this.edges.filter((function(t) {
                        return t.right
                    })).map((function(t) {
                        return {
                            source: t.left.data,
                            target: t.right.data
                        }
                    }))
                },
                find: function(t, n, e) {
                    for (var r, i, o = this, a = o._found || 0, u = o.cells.length; !(i = o.cells[a]);)
                        if (++a >= u) return null;
                    var f = t - i.site[0],
                        c = n - i.site[1],
                        s = f * f + c * c;
                    do {
                        i = o.cells[r = a], a = null, i.halfedges.forEach((function(e) {
                            var r = o.edges[e],
                                u = r.left;
                            if (u !== i.site && u || (u = r.right)) {
                                var f = t - u[0],
                                    c = n - u[1],
                                    l = f * f + c * c;
                                l < s && (s = l, a = u.index)
                            }
                        }))
                    } while (null !== a);
                    return o._found = r, null == e || s <= e * e ? i.site : null
                }
            }, Mu.prototype = {
                constructor: Mu,
                scale: function(t) {
                    return 1 === t ? this : new Mu(this.k * t, this.x, this.y)
                },
                translate: function(t, n) {
                    return 0 === t & 0 === n ? this : new Mu(this.k, this.x + this.k * t, this.y + this.k * n)
                },
                apply: function(t) {
                    return [t[0] * this.k + this.x, t[1] * this.k + this.y]
                },
                applyX: function(t) {
                    return t * this.k + this.x
                },
                applyY: function(t) {
                    return t * this.k + this.y
                },
                invert: function(t) {
                    return [(t[0] - this.x) / this.k, (t[1] - this.y) / this.k]
                },
                invertX: function(t) {
                    return (t - this.x) / this.k
                },
                invertY: function(t) {
                    return (t - this.y) / this.k
                },
                rescaleX: function(t) {
                    return t.copy().domain(t.range().map(this.invertX, this).map(t.invert, t))
                },
                rescaleY: function(t) {
                    return t.copy().domain(t.range().map(this.invertY, this).map(t.invert, t))
                },
                toString: function() {
                    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")"
                }
            };
            new Mu(1, 0, 0);
            Mu.prototype
        },
        81803: function(t, n) {
            var e;
            ! function() {
                var r = n || {} || this || window;
                void 0 === (e = function() {
                    return r
                }.apply(n, [])) || (t.exports = e), r.default = r;
                var i = "http://www.w3.org/2000/xmlns/",
                    o = "http://www.w3.org/2000/svg",
                    a = /url\(["']?(.+?)["']?\)/,
                    u = {
                        woff2: "font/woff2",
                        woff: "font/woff",
                        otf: "application/x-font-opentype",
                        ttf: "application/x-font-ttf",
                        eot: "application/vnd.ms-fontobject",
                        sfnt: "application/font-sfnt",
                        svg: "image/svg+xml"
                    },
                    f = function(t) {
                        return t instanceof HTMLElement || t instanceof SVGElement
                    },
                    c = function(t) {
                        if (!f(t)) throw new Error("an HTMLElement or SVGElement is required; got " + t)
                    },
                    s = function(t) {
                        return new Promise((function(n, e) {
                            f(t) ? n(t) : e(new Error("an HTMLElement or SVGElement is required; got " + t))
                        }))
                    },
                    l = function(t) {
                        var n = Object.keys(u).filter((function(n) {
                            return t.indexOf("." + n) > 0
                        })).map((function(t) {
                            return u[t]
                        }));
                        return n ? n[0] : (console.error("Unknown font format for " + t + ". Fonts may not be working correctly."), "application/octet-stream")
                    },
                    h = function(t, n, e) {
                        var r = t.viewBox && t.viewBox.baseVal && t.viewBox.baseVal[e] || null !== n.getAttribute(e) && !n.getAttribute(e).match(/%$/) && parseInt(n.getAttribute(e)) || t.getBoundingClientRect()[e] || parseInt(n.style[e]) || parseInt(window.getComputedStyle(t).getPropertyValue(e));
                        return "undefined" === typeof r || null === r || isNaN(parseFloat(r)) ? 0 : r
                    },
                    d = function(t) {
                        for (var n = window.atob(t.split(",")[1]), e = t.split(",")[0].split(":")[1].split(";")[0], r = new ArrayBuffer(n.length), i = new Uint8Array(r), o = 0; o < n.length; o++) i[o] = n.charCodeAt(o);
                        return new Blob([r], {
                            type: e
                        })
                    },
                    p = function(t) {
                        return Promise.all(Array.from(t.querySelectorAll("image")).map((function(t) {
                            var n, e = t.getAttributeNS("http://www.w3.org/1999/xlink", "href") || t.getAttribute("href");
                            return e ? ((n = e) && 0 === n.lastIndexOf("http", 0) && -1 === n.lastIndexOf(window.location.host) && (e += (-1 === e.indexOf("?") ? "?" : "&") + "t=" + (new Date).valueOf()), new Promise((function(n, r) {
                                var i = document.createElement("canvas"),
                                    o = new Image;
                                o.crossOrigin = "anonymous", o.src = e, o.onerror = function() {
                                    return r(new Error("Could not load " + e))
                                }, o.onload = function() {
                                    i.width = o.width, i.height = o.height, i.getContext("2d").drawImage(o, 0, 0), t.setAttributeNS("http://www.w3.org/1999/xlink", "href", i.toDataURL("image/png")), n(!0)
                                }
                            }))) : Promise.resolve(null)
                        })))
                    },
                    v = {},
                    g = function(t) {
                        return Promise.all(t.map((function(t) {
                            return new Promise((function(n, e) {
                                if (v[t.url]) return n(v[t.url]);
                                var r = new XMLHttpRequest;
                                r.addEventListener("load", (function() {
                                    var e = function(t) {
                                            for (var n = "", e = new Uint8Array(t), r = 0; r < e.byteLength; r++) n += String.fromCharCode(e[r]);
                                            return window.btoa(n)
                                        }(r.response),
                                        i = t.text.replace(a, 'url("data:' + t.format + ";base64," + e + '")') + "\n";
                                    v[t.url] = i, n(i)
                                })), r.addEventListener("error", (function(e) {
                                    console.warn("Failed to load font from: " + t.url, e), v[t.url] = null, n(null)
                                })), r.addEventListener("abort", (function(e) {
                                    console.warn("Aborted loading font from: " + t.url, e), n(null)
                                })), r.open("GET", t.url), r.responseType = "arraybuffer", r.send()
                            }))
                        }))).then((function(t) {
                            return t.filter((function(t) {
                                return t
                            })).join("")
                        }))
                    },
                    y = null,
                    _ = function(t, n) {
                        var e = n || {},
                            r = e.selectorRemap,
                            i = e.modifyStyle,
                            o = e.modifyCss,
                            u = e.fonts,
                            f = e.excludeUnusedCss,
                            c = o || function(t, n) {
                                return (r ? r(t) : t) + "{" + (i ? i(n) : n) + "}\n"
                            },
                            s = [],
                            h = "undefined" === typeof u,
                            d = u || [];
                        return (y || (y = Array.from(document.styleSheets).map((function(t) {
                            try {
                                return {
                                    rules: t.cssRules,
                                    href: t.href
                                }
                            } catch (n) {
                                return console.warn("Stylesheet could not be loaded: " + t.href, n), {}
                            }
                        })))).forEach((function(n) {
                            var e = n.rules,
                                r = n.href;
                            e && Array.from(e).forEach((function(n) {
                                if ("undefined" != typeof n.style)
                                    if (function(t, n) {
                                            if (n) try {
                                                return t.querySelector(n) || t.parentNode && t.parentNode.querySelector(n)
                                            } catch (e) {
                                                console.warn('Invalid CSS selector "' + n + '"', e)
                                            }
                                        }(t, n.selectorText)) s.push(c(n.selectorText, n.style.cssText));
                                    else if (h && n.cssText.match(/^@font-face/)) {
                                    var e = function(t, n) {
                                        var e = t.cssText.match(a),
                                            r = e && e[1] || "";
                                        if (r && !r.match(/^data:/) && "about:blank" !== r) {
                                            var i = r.startsWith("../") ? n + "/../" + r : r.startsWith("./") ? n + "/." + r : r;
                                            return {
                                                text: t.cssText,
                                                format: l(i),
                                                url: i
                                            }
                                        }
                                    }(n, r);
                                    e && d.push(e)
                                } else f || s.push(n.cssText)
                            }))
                        })), g(d).then((function(t) {
                            return s.join("\n") + t
                        }))
                    },
                    b = function() {
                        if (!navigator.msSaveOrOpenBlob && !("download" in document.createElement("a"))) return {
                            popup: window.open()
                        }
                    };
                r.prepareSvg = function(t, n, e) {
                    c(t);
                    var r = n || {},
                        a = r.left,
                        u = void 0 === a ? 0 : a,
                        f = r.top,
                        s = void 0 === f ? 0 : f,
                        l = r.width,
                        d = r.height,
                        v = r.scale,
                        g = void 0 === v ? 1 : v,
                        y = r.responsive,
                        b = void 0 !== y && y,
                        m = r.excludeCss,
                        w = void 0 !== m && m;
                    return p(t).then((function() {
                        var r = t.cloneNode(!0);
                        r.style.backgroundColor = (n || {}).backgroundColor || t.style.backgroundColor;
                        var a = function(t, n, e, r) {
                                if ("svg" === t.tagName) return {
                                    width: e || h(t, n, "width"),
                                    height: r || h(t, n, "height")
                                };
                                if (t.getBBox) {
                                    var i = t.getBBox(),
                                        o = i.x,
                                        a = i.y;
                                    return {
                                        width: o + i.width,
                                        height: a + i.height
                                    }
                                }
                            }(t, r, l, d),
                            f = a.width,
                            c = a.height;
                        if ("svg" !== t.tagName) {
                            if (!t.getBBox) return void console.error("Attempted to render non-SVG element", t);
                            null != r.getAttribute("transform") && r.setAttribute("transform", r.getAttribute("transform").replace(/translate\(.*?\)/, ""));
                            var p = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                            p.appendChild(r), r = p
                        }
                        if (r.setAttribute("version", "1.1"), r.setAttribute("viewBox", [u, s, f, c].join(" ")), r.getAttribute("xmlns") || r.setAttributeNS(i, "xmlns", o), r.getAttribute("xmlns:xlink") || r.setAttributeNS(i, "xmlns:xlink", "http://www.w3.org/1999/xlink"), b ? (r.removeAttribute("width"), r.removeAttribute("height"), r.setAttribute("preserveAspectRatio", "xMinYMin meet")) : (r.setAttribute("width", f * g), r.setAttribute("height", c * g)), Array.from(r.querySelectorAll("foreignObject > *")).forEach((function(t) {
                                t.setAttributeNS(i, "xmlns", "svg" === t.tagName ? o : "http://www.w3.org/1999/xhtml")
                            })), !w) return _(t, n).then((function(t) {
                            var n = document.createElement("style");
                            n.setAttribute("type", "text/css"), n.innerHTML = "<![CDATA[\n" + t + "\n]]>";
                            var i = document.createElement("defs");
                            i.appendChild(n), r.insertBefore(i, r.firstChild);
                            var o = document.createElement("div");
                            o.appendChild(r);
                            var a = o.innerHTML.replace(/NS\d+:href/gi, 'xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href');
                            if ("function" !== typeof e) return {
                                src: a,
                                width: f,
                                height: c
                            };
                            e(a, f, c)
                        }));
                        var v = document.createElement("div");
                        v.appendChild(r);
                        var y = v.innerHTML;
                        if ("function" !== typeof e) return {
                            src: y,
                            width: f,
                            height: c
                        };
                        e(y, f, c)
                    }))
                }, r.svgAsDataUri = function(t, n, e) {
                    return c(t), r.prepareSvg(t, n).then((function(t) {
                        var n = t.src,
                            r = t.width,
                            i = t.height,
                            o = "data:image/svg+xml;base64," + window.btoa(decodeURIComponent(encodeURIComponent('<?xml version="1.0" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [<!ENTITY nbsp "&#160;">]>' + n).replace(/%([0-9A-F]{2})/g, (function(t, n) {
                                var e = String.fromCharCode("0x" + n);
                                return "%" === e ? "%25" : e
                            }))));
                        return "function" === typeof e && e(o, r, i), o
                    }))
                }, r.svgAsPngUri = function(t, n, e) {
                    c(t);
                    var i = n || {},
                        o = i.encoderType,
                        a = void 0 === o ? "image/png" : o,
                        u = i.encoderOptions,
                        f = void 0 === u ? .8 : u,
                        s = i.canvg,
                        l = function(t) {
                            var n = t.src,
                                r = t.width,
                                i = t.height,
                                o = document.createElement("canvas"),
                                u = o.getContext("2d"),
                                c = window.devicePixelRatio || 1;
                            o.width = r * c, o.height = i * c, o.style.width = o.width + "px", o.style.height = o.height + "px", u.setTransform(c, 0, 0, c, 0, 0), s ? s(o, n) : u.drawImage(n, 0, 0);
                            var l = void 0;
                            try {
                                l = o.toDataURL(a, f)
                            } catch (h) {
                                if ("undefined" !== typeof SecurityError && h instanceof SecurityError || "SecurityError" === h.name) return void console.error("Rendered SVG images cannot be downloaded in this browser.");
                                throw h
                            }
                            return "function" === typeof e && e(l, o.width, o.height), Promise.resolve(l)
                        };
                    return s ? r.prepareSvg(t, n).then(l) : r.svgAsDataUri(t, n).then((function(t) {
                        return new Promise((function(n, e) {
                            var r = new Image;
                            r.onload = function() {
                                return n(l({
                                    src: r,
                                    width: r.width,
                                    height: r.height
                                }))
                            }, r.onerror = function() {
                                e("There was an error loading the data URI as an image on the following SVG\n" + window.atob(t.slice(26)) + "Open the following link to see browser's diagnosis\n" + t)
                            }, r.src = t
                        }))
                    }))
                }, r.download = function(t, n, e) {
                    if (navigator.msSaveOrOpenBlob) navigator.msSaveOrOpenBlob(d(n), t);
                    else {
                        var r = document.createElement("a");
                        if ("download" in r) {
                            r.download = t, r.style.display = "none", document.body.appendChild(r);
                            try {
                                var i = d(n),
                                    o = URL.createObjectURL(i);
                                r.href = o, r.onclick = function() {
                                    return requestAnimationFrame((function() {
                                        return URL.revokeObjectURL(o)
                                    }))
                                }
                            } catch (a) {
                                console.error(a), console.warn("Error while getting object URL. Falling back to string URL."), r.href = n
                            }
                            r.click(), document.body.removeChild(r)
                        } else e && e.popup && (e.popup.document.title = t, e.popup.location.replace(n))
                    }
                }, r.saveSvg = function(t, n, e) {
                    var i = b();
                    return s(t).then((function(t) {
                        return r.svgAsDataUri(t, e || {})
                    })).then((function(t) {
                        return r.download(n, t, i)
                    }))
                }, r.saveSvgAsPng = function(t, n, e) {
                    var i = b();
                    return s(t).then((function(t) {
                        return r.svgAsPngUri(t, e || {})
                    })).then((function(t) {
                        return r.download(n, t, i)
                    }))
                }
            }()
        }
    }
]);