(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [84934], {
        89845: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return S
                }
            });
            var r = s(29815),
                t = s(85893),
                n = s(67294),
                o = s(93967),
                i = s.n(o),
                c = s(67724),
                d = s(9197),
                l = s(99295),
                m = s(61050),
                u = s(34405),
                g = s(42623),
                h = s(21059),
                _ = s(91567),
                p = s(43002),
                v = s(32171),
                x = s(9110),
                b = s(92033);

            function y(e, a, s, t, n) {
                var o, i, c = (0, r.Z)(e);
                t && (o = c).push.apply(o, (0, r.Z)(a));
                n && (i = c).push.apply(i, (0, r.Z)(s));
                return c
            }
            var B = s(28867),
                N = s(99170),
                f = s.n(N);
            var T = s(73398);

            function S(e) {
                var a = e.className,
                    s = e.broadcasters,
                    o = e.gameStatusText,
                    N = e.horizontal,
                    S = void 0 !== N && N,
                    j = e.isDark,
                    Z = void 0 !== j && j,
                    k = e.hideNationalLabel,
                    I = void 0 !== k && k,
                    D = e.analytics,
                    w = void 0 === D ? p.m_ : D,
                    P = e.gameId,
                    L = void 0 === P ? "" : P,
                    O = e.isBlackedOut,
                    G = e.isLoggedIn,
                    M = e.awayTeamId,
                    C = e.isGameDetailsPage,
                    R = void 0 !== C && C,
                    A = e.homeTeamId,
                    V = e.isStandAlone,
                    F = e.hideIntlBroadcasters,
                    E = e.showNationalBroadcastersFallBackText,
                    U = e.isScheduleView,
                    H = void 0 !== U && U,
                    W = e.homeTeamSlug,
                    q = e.awayTeamSlug,
                    z = function(e) {
                        return (null === e || void 0 === e ? void 0 : e.broadcasterDisplayName) || (null === e || void 0 === e ? void 0 : e.broadcasterDisplay) || (null === e || void 0 === e ? void 0 : e.broadcastDisplay)
                    },
                    J = (0, n.useContext)(h.aR).ESI,
                    X = (void 0 === J ? {} : J).isDomestic,
                    K = (0, n.useContext)(_.N).games,
                    Q = void 0 === K ? {} : K,
                    Y = s.nationalBroadcasters,
                    $ = void 0 === Y ? [] : Y,
                    ee = s.intlTvBroadcasters,
                    ae = void 0 === ee ? [] : ee,
                    se = s.intlOttBroadcasters,
                    re = void 0 === se ? [] : se,
                    te = s.homeTvBroadcasters,
                    ne = void 0 === te ? [] : te,
                    oe = s.awayTvBroadcasters,
                    ie = void 0 === oe ? [] : oe,
                    ce = s.nationalRadioBroadcasters,
                    de = void 0 === ce ? [] : ce,
                    le = s.homeRadioBroadcasters,
                    me = void 0 === le ? [] : le,
                    ue = s.awayRadioBroadcasters,
                    ge = void 0 === ue ? [] : ue,
                    he = (0, v.Z)({
                        awayTeamId: M,
                        homeTeamId: A,
                        broadcasters: s
                    }),
                    _e = he.hasLocalAccessBroadcasters,
                    pe = he.localAccessBroadcasters,
                    ve = (0, x.T)(),
                    xe = ve.userLocalBlackoutTeams,
                    be = ve.userLocalizationRegion,
                    ye = (0, n.useMemo)((function() {
                        return $.filter((function(e) {
                            return (0, T.Z)(e, be)
                        }))
                    }), [$, be]),
                    Be = (0, n.useMemo)((function() {
                        return (0, r.Z)(ae).concat((0, r.Z)(re))
                    }), [ae, re]),
                    Ne = (0, n.useMemo)((function() {
                        return H ? ye.slice(0, 2) : ye
                    }), [H, ye]),
                    fe = (0, n.useMemo)((function() {
                        return H ? ye.slice(2) : []
                    }), [H, ye]),
                    Te = (0, n.useMemo)((function() {
                        return H ? "TV" : "Local TV"
                    }), [H]),
                    Se = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                            a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                            s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
                            r = (0, n.useMemo)((function() {
                                var r = !1,
                                    t = !1;
                                return e && e.length ? (e.forEach((function(e) {
                                    "".concat(e.name) === a && (r = !0), "".concat(e.name) === s && (t = !0)
                                })), {
                                    isUserHome: r,
                                    isUserAway: t
                                }) : {
                                    isUserHome: r,
                                    isUserAway: t
                                }
                            }), [e, a, s]);
                        return r
                    }(xe, W, q),
                    je = Se.isUserHome,
                    Ze = Se.isUserAway;
                if (!s || 0 === Object.keys(s).length) return null;
                var ke = (!X || X && "TBD" !== o && "PPD" !== o) && !1 === c.A_.includes(L),
                    Ie = $.length > 0,
                    De = !F && Be.length > 0,
                    we = H ? y(fe, ne, ie, je, Ze) : (0, r.Z)(fe).concat((0, r.Z)(ne), (0, r.Z)(ie)),
                    Pe = H ? y(de, me, ge, je, Ze) : (0, r.Z)(de).concat((0, r.Z)(me), (0, r.Z)(ge)),
                    Le = S ? f().horizontal : f().vertical,
                    Oe = (0, b.Z)(["banner"], Q, {}),
                    Ge = R && (null === Q || void 0 === Q ? void 0 : Q.showPromoBanner) && Oe && !O,
                    Me = (0, b.Z)(["header"], Oe, ""),
                    Ce = (0, b.Z)(["subHeader"], Oe, ""),
                    Re = (0, b.Z)(["cta"], Oe, {}),
                    Ae = _e && (null === pe || void 0 === pe ? void 0 : pe.length) > 1,
                    Ve = R ? f().gameDetailsTitle : f().title,
                    Fe = we.length > 0 && we.map((function(e) {
                        var a = (0, b.Z)(["broadcasterVideoLink"], e, ""),
                            s = (0, b.Z)(["broadcasterDisplayName"], e, "") || (0, b.Z)(["broadcasterDisplay"], e, "") || (0, b.Z)(["broadcastDisplay"], e, ""),
                            r = (0, b.Z)(["broadcasterId"], e);
                        return (0, t.jsxs)(u.Z, {
                            className: f().tv,
                            disabled: !a,
                            href: a,
                            showExternalIcon: !a,
                            children: [s, !H && a && (0, t.jsx)(B.Z, {
                                className: f().externalVideoLinkIcon
                            })]
                        }, r)
                    }));
                return (0, t.jsxs)("div", {
                    className: i()(f().base, V, a, Le),
                    tabIndex: "0",
                    "data-has-multiple-la-broadcasters": Ae,
                    children: [Ie && !V && (0, t.jsxs)("div", {
                        className: i()(f().section, Ge && f().smallerSection),
                        children: [!I && (0, t.jsx)("p", {
                            className: Ve,
                            children: "NATIONAL"
                        }), (0, t.jsx)("div", {
                            className: f().bBlock,
                            children: Ne.map((function(e) {
                                return (0, t.jsxs)(l.Z, {
                                    broadcasterName: z(e),
                                    analytics: w,
                                    analyticsType: "logo",
                                    broadcasterLink: e.broadcasterVideoLink,
                                    children: [(0, t.jsx)(d.Z, {
                                        fallBackTextClassName: f().BroadcasterFallbackText,
                                        showFallbackText: E,
                                        broadcaster: z(e),
                                        isDark: Z,
                                        className: f().icon
                                    }), !H && e.broadcasterVideoLink && (0, t.jsx)(B.Z, {
                                        className: f().externalIcon
                                    })]
                                }, e.broadcasterId)
                            }))
                        })]
                    }), _e && !V && (0, t.jsxs)("div", {
                        className: i()(f().section, Ge && f().smallerSection),
                        children: [(Ae || Ie) && (0, t.jsx)("p", {
                            className: Ve,
                            children: "Streaming Options"
                        }), (0, t.jsx)("div", {
                            className: f().bBlock,
                            children: null === pe || void 0 === pe ? void 0 : pe.map((function(e) {
                                return (0, t.jsx)(l.Z, {
                                    broadcasterName: z(e),
                                    analytics: w,
                                    analyticsType: "logo",
                                    children: Ae || Ie ? (0, t.jsxs)("span", {
                                        className: f().broadcasterName,
                                        children: [z(e), (0, t.jsx)("span", {
                                            children: ","
                                        }), "\xa0 "]
                                    }) : (0, t.jsx)(d.Z, {
                                        broadcasterTeamId: e.broadcasterTeamId,
                                        broadcaster: z(e),
                                        isDark: Z,
                                        className: f().icon
                                    })
                                }, e.broadcasterId)
                            }))
                        })]
                    }), De && !V && (0, t.jsxs)("div", {
                        className: i()(f().section, Ge && f().smallerSection),
                        children: [!I && (0, t.jsx)("p", {
                            className: Ve,
                            children: "NATIONAL"
                        }), (0, t.jsx)("div", {
                            className: f().bBlock,
                            children: Be.map((function(e) {
                                return (0, t.jsxs)(l.Z, {
                                    broadcasterName: z(e),
                                    analytics: w,
                                    analyticsType: "logo",
                                    broadcasterLink: e.broadcasterVideoLink,
                                    children: [(0, t.jsx)(d.Z, {
                                        fallBackTextClassName: f().intl,
                                        showFallbackText: E,
                                        broadcaster: z(e),
                                        isDark: Z,
                                        className: f().icon
                                    }), !H && e.broadcasterVideoLink && (0, t.jsx)(B.Z, {
                                        className: f().externalIcon
                                    })]
                                }, e.broadcasterId)
                            }))
                        })]
                    }), ke && !_e && !Ie && !De && !V && (0, t.jsx)("div", {
                        className: i()(f().section, Ge && f().smallerSection),
                        children: (0, t.jsx)(l.Z, {
                            broadcasterName: "LEAGUE PASS",
                            analytics: w,
                            analyticsType: "logo",
                            children: (0, t.jsx)(d.Z, {
                                broadcaster: "LEAGUE PASS",
                                isDark: Z,
                                className: i()(f().icon, f().lpIcon)
                            })
                        })
                    }), Ge && !V && (0, t.jsxs)("div", {
                        className: i()(Ge ? f().smallerSection : f().section),
                        children: [Fe && (0, t.jsxs)("p", {
                            children: [(0, t.jsx)("span", {
                                className: Ve,
                                children: Te
                            }), " ", Fe]
                        }), !!Pe.length && (0, t.jsxs)("p", {
                            children: [(0, t.jsx)("span", {
                                className: Ve,
                                children: "Listen on: "
                            }), Pe.map((function(e) {
                                return (0, t.jsx)(m.Z, {
                                    radioBroadcaster: e
                                }, e.broadcasterId)
                            }))]
                        })]
                    }), Fe && !Ge && !V && (0, t.jsxs)("div", {
                        className: f().section,
                        children: [(0, t.jsx)("p", {
                            className: Ve,
                            children: Te
                        }), (0, t.jsx)("p", {
                            children: Fe
                        })]
                    }), !!Pe.length && !Ge && !V && (0, t.jsxs)("div", {
                        className: f().section,
                        children: [(0, t.jsx)("p", {
                            className: Ve,
                            children: "RADIO"
                        }), (0, t.jsx)("p", {
                            children: Pe.map((function(e) {
                                return (0, t.jsx)(m.Z, {
                                    radioBroadcaster: e
                                }, e.broadcasterId)
                            }))
                        })]
                    }), Ge && (0, t.jsx)("div", {
                        className: V ? f().standAloneBorder : f().border
                    }), Ge && (0, t.jsxs)("div", {
                        className: i()(!V && f().promoBanner, V && f().standAloneMobile, !G && f().promoBannerLoggedOut),
                        children: [(0, t.jsx)("p", {
                            className: f().header,
                            children: Me
                        }), (0, t.jsx)("p", {
                            className: f().subHeader,
                            children: Ce
                        })]
                    }), !G && Ge && Re && (0, t.jsx)("div", {
                        className: i()(f().section, f().promoButton, V && f().standAlonePromoButton),
                        children: (0, t.jsx)(g.Z, {
                            buttonAttributes: {
                                fullWidth: !0
                            },
                            size: "xs",
                            href: Re.link,
                            text: Re.label,
                            analyticAttributes: {
                                "data-track": "sign-up",
                                "data-type": "cta",
                                "data-id": "nba:games:game-details:registration:cta",
                                "data-text": "".concat(Re.label),
                                "data-section": "Promo Banner"
                            }
                        })
                    })]
                })
            }
        },
        33: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return X
                }
            });
            var r = s(85893),
                t = s(26042),
                n = s(69396),
                o = s(67294),
                i = s(77226),
                c = s(67724),
                d = s(91567),
                l = s(54141),
                m = s(34575),
                u = s(86972),
                g = s(93967),
                h = s.n(g),
                _ = s(18377),
                p = s(9083),
                v = s(49507),
                x = s(45697),
                b = s.n(x),
                y = {
                    propTypes: {
                        status: b().number.isRequired,
                        statusText: b().string.isRequired,
                        className: b().string,
                        hideScores: b().bool
                    },
                    defaultProps: {
                        className: null,
                        hideScores: !1
                    }
                },
                B = s(86984),
                N = s.n(B),
                f = s(67806);

            function T(e) {
                var a = e.status,
                    s = e.statusText,
                    t = e.className,
                    n = e.hideScores,
                    o = e.gameTimeUTC,
                    i = (0, p.Z)(o),
                    c = i.localizedTime,
                    d = i.timeZoneShort,
                    l = i.localizedDay,
                    m = c && d ? "".concat(c, " ").concat(d).concat(l ? " (".concat(l, ")") : "") : "";
                return a ? "TBD" === s || "PPD" === s || s === f.Z.Cancelled ? (0, r.jsx)("span", {
                    className: h()(N().base, t),
                    children: s
                }) : a === v.Z.Upcoming ? (0, r.jsx)("span", {
                    className: h()(N().base, t),
                    children: m || s
                }) : 2 === a ? (0, r.jsxs)("div", {
                    className: h()(N().base, t),
                    "data-is-live": !0,
                    children: [(0, r.jsx)(_.Z, {
                        className: N().icon
                    }), " ", s]
                }) : (0, r.jsx)("span", {
                    className: h()(N().base, t),
                    children: n ? "FINAL" : s
                }) : (0, r.jsx)("span", {
                    children: " "
                })
            }
            T.propTypes = y.propTypes, T.defaultProps = y.defaultProps;
            var S = s(89845),
                j = s(34405),
                Z = s(53174),
                k = s(47347),
                I = s(63087),
                D = s(48517),
                w = s(43002),
                P = s(43368),
                L = {
                    game: P.ZP.isRequired
                },
                O = s(66917),
                G = s.n(O),
                M = s(59342),
                C = function(e) {
                    return (0, n.Z)((0, t.Z)({}, e), {
                        broadcastDisplay: e.broadcasterDisplay
                    })
                };

            function R(e) {
                var a = e.nationalTvBroadcasters,
                    s = void 0 === a ? [] : a,
                    r = e.nationalRadioBroadcasters,
                    t = void 0 === r ? [] : r,
                    n = e.intlTvBroadcasters,
                    o = void 0 === n ? [] : n,
                    i = e.intlOttBroadcasters,
                    c = void 0 === i ? [] : i,
                    d = e.homeTvBroadcasters,
                    l = void 0 === d ? [] : d,
                    m = e.awayTvBroadcasters,
                    u = void 0 === m ? [] : m,
                    g = e.homeRadioBroadcasters,
                    h = void 0 === g ? [] : g,
                    _ = e.awayRadioBroadcasters,
                    p = void 0 === _ ? [] : _,
                    v = e.nationalOttBroadcasters,
                    x = void 0 === v ? [] : v,
                    b = e.homeOttBroadcasters,
                    y = void 0 === b ? [] : b,
                    B = e.awayOttBroadcasters,
                    N = void 0 === B ? [] : B;
                return {
                    nationalBroadcasters: (0, M.Z)(s.map(C)),
                    nationalRadioBroadcasters: t.map(C),
                    intlTvBroadcasters: o.map(C),
                    intlOttBroadcasters: c.map(C),
                    homeTvBroadcasters: l.map(C),
                    homeRadioBroadcasters: h.map(C),
                    awayTvBroadcasters: u.map(C),
                    awayRadioBroadcasters: p.map(C),
                    nationalOttBroadcasters: x.map(C),
                    homeOttBroadcasters: y.map(C),
                    awayOttBroadcasters: N.map(C)
                }
            }

            function A(e) {
                var a = e.game,
                    s = e.hideIntlBroadcasters,
                    g = void 0 !== s && s,
                    h = (0, o.useContext)(d.N),
                    _ = h.hideScores,
                    p = h.themeName,
                    v = h.isSummerLeague,
                    x = a.gameId,
                    b = a.gameStatus,
                    y = a.gameStatusText,
                    B = a.gameSubtype,
                    N = a.gameLabel,
                    f = void 0 === N ? "" : N,
                    P = a.gameSubLabel,
                    L = void 0 === P ? "" : P,
                    O = a.arenaName,
                    M = a.arenaCity,
                    C = a.arenaState,
                    A = a.homeTeam,
                    V = void 0 === A ? {} : A,
                    F = a.awayTeam,
                    E = void 0 === F ? {} : F,
                    U = a.broadcasters,
                    H = a.seriesText,
                    W = a.seriesGameNumber,
                    q = a.ifNecessary,
                    z = a.gameDateTimeUTC,
                    J = (0, o.useMemo)((function() {
                        return +b
                    }), [b]),
                    X = V || {},
                    K = X.score,
                    Q = X.teamId,
                    Y = X.teamCity,
                    $ = X.teamName,
                    ee = X.teamTricode,
                    ae = X.teamSlug,
                    se = E || {},
                    re = se.score,
                    te = se.teamId,
                    ne = se.teamCity,
                    oe = se.teamName,
                    ie = se.teamTricode,
                    ce = se.teamSlug,
                    de = "".concat(Y, " ").concat($),
                    le = "".concat(ne, " ").concat(oe),
                    me = 3 === J && +K > +re,
                    ue = 3 === J && +re > +K,
                    ge = (1 === J || 2 === J) && "PPD" !== y,
                    he = "TBD" !== y && "PPD" !== y,
                    _e = (0, l.f)(a),
                    pe = !(!te || !ce),
                    ve = !(!Q || !ae),
                    xe = !(0, i.B_)(Q),
                    be = !(0, i.B_)(te),
                    ye = (0, o.useMemo)((function() {
                        return (0, w.ZP)({
                            component: S.Z,
                            primaryCategory: v ? "summer-league" : "schedule",
                            secondaryCategory: "subscribe",
                            section: "schedule:broadcasters",
                            extraProps: {
                                "data-content": _e,
                                "data-content-id": x
                            }
                        })
                    }), [x, _e, v]),
                    Be = (0, o.useMemo)((function() {
                        return (0, w.ZP)({
                            component: Z.Z,
                            primaryCategory: v ? "summer-league" : "schedule",
                            secondaryCategory: v ? "schedule" : "main"
                        })
                    }), [v]),
                    Ne = (0, o.useMemo)((function() {
                        return (0, u.Z)(B)
                    }), [B]),
                    fe = (!Ne || Ne && 2 !== J) && 1 !== J && !_,
                    Te = {
                        "data-track": "click",
                        "data-type": "link",
                        "data-id": v ? "nba:summer-league:schedule:team:link" : "nba:schedule:main:team:link"
                    };
                return (0, r.jsxs)("div", {
                    className: G().sg,
                    children: [(0, r.jsxs)("div", {
                        className: G().sgContent,
                        children: [(0, r.jsxs)("div", {
                            className: G().sgStatus,
                            children: [(0, r.jsx)(T, {
                                status: J,
                                statusText: y,
                                hideScores: _,
                                gameTimeUTC: z
                            }), ge && (0, r.jsx)(ye, {
                                broadcasters: R(U),
                                gameStatusText: y,
                                gameId: x,
                                hideNationalLabel: !0,
                                className: G().sgBroadcasters,
                                isDark: "dark" === p,
                                awayTeamId: te,
                                homeTeamId: Q,
                                hideIntlBroadcasters: g,
                                showNationalBroadcastersFallBackText: !0,
                                isScheduleView: !0,
                                homeTeamSlug: ae,
                                awayTeamSlug: ce
                            })]
                        }), (0, r.jsxs)("div", {
                            className: G().sgMatchup,
                            children: [f && (0, r.jsx)("p", {
                                className: G().sgLabel,
                                children: f
                            }), (0, r.jsxs)("div", {
                                className: G().sgTeam,
                                children: [pe ? (0, r.jsx)(j.Z, (0, n.Z)((0, t.Z)({
                                    disabled: be,
                                    href: (0, m.HB)(te, ce)
                                }, Te), {
                                    "data-text": le,
                                    "data-content-id": te,
                                    styled: !0,
                                    children: le
                                })) : (0, r.jsx)("p", {
                                    className: G().sgFigtext,
                                    children: "TBD"
                                }), fe && (0, r.jsxs)("div", {
                                    className: G().sgScore,
                                    "data-did-win": ue,
                                    children: [ue && (0, r.jsx)(k.Z, {
                                        className: G().sgWin,
                                        dir: "right"
                                    }), (0, r.jsx)("span", {
                                        className: G().sgScoreVal,
                                        children: re
                                    })]
                                })]
                            }), (0, r.jsxs)("div", {
                                className: G().sgTeam,
                                children: [ve ? (0, r.jsx)(j.Z, (0, n.Z)((0, t.Z)({
                                    disabled: xe,
                                    href: (0, m.HB)(Q, ae)
                                }, Te), {
                                    "data-text": de,
                                    "data-content-id": Q,
                                    styled: !0,
                                    children: de
                                })) : (0, r.jsx)("p", {
                                    className: G().sgFigtext,
                                    children: "TBD"
                                }), fe && (0, r.jsxs)("div", {
                                    className: G().sgScore,
                                    "data-did-win": me,
                                    children: [me && (0, r.jsx)(k.Z, {
                                        className: G().sgWin,
                                        dir: "right"
                                    }), (0, r.jsx)("span", {
                                        className: G().sgScoreVal,
                                        children: K
                                    })]
                                })]
                            }), (H || L) && (0, r.jsx)(D.Z, {
                                hideScores: _,
                                seriesText: H,
                                seriesGameNumber: W,
                                ifNecessary: q,
                                className: G().sgFigtext,
                                gameSubLabel: L
                            })]
                        })]
                    }), (0, r.jsxs)("div", {
                        className: G().sgLocation,
                        children: [(0, r.jsxs)("div", {
                            className: G().sgLocationInner,
                            children: [(0, r.jsx)("div", {
                                children: O
                            }), (0, r.jsxs)("div", {
                                children: [M, M && C ? ", " : "", " ", C]
                            })]
                        }), (0, r.jsxs)("div", {
                            className: G().sgOptions,
                            children: [he && (0, r.jsx)("div", {
                                className: G().tab,
                                children: (0, r.jsx)(Be, {
                                    game: a,
                                    placement: c.FL.schedule
                                })
                            }), he && !v && (0, r.jsx)("div", {
                                className: G().gameOdds,
                                children: (0, r.jsx)(I.Z, {
                                    gameId: x,
                                    gameStatus: J,
                                    homeTeamTricode: ee,
                                    awayTeamTricode: ie,
                                    pageName: "schedule:main",
                                    contentFor: _e
                                })
                            })]
                        })]
                    })]
                })
            }
            A.propTypes = L;
            var V = {
                    propTypes: {
                        week: b().number,
                        day: b().string,
                        games: b().arrayOf(P.ZP),
                        isPreseason: b().bool
                    },
                    defaultProps: {
                        week: 0,
                        day: "",
                        games: [],
                        isPreseason: !1
                    }
                },
                F = s(95461),
                E = s.n(F);

            function U(e) {
                e.week;
                var a = e.day,
                    s = e.games,
                    t = e.isPreseason,
                    n = e.hideIntlBroadcasters,
                    o = void 0 !== n && n;
                if (!s || !s.length) return null;
                (0, i.Uc)(s, "day", "gameSequence", "day");
                var c = s.length > 1 ? "Games" : "Game";
                return (0, r.jsxs)("div", {
                    className: E().sd,
                    children: [(0, r.jsxs)("div", {
                        className: E().sdTop,
                        children: [(0, r.jsxs)("h4", {
                            className: E().sdDay,
                            children: [a, t && (0, r.jsx)("span", {
                                className: E().sdPreseason,
                                children: " (Preseason)"
                            })]
                        }), (0, r.jsxs)("h6", {
                            className: E().sdWeek,
                            children: [s.length, " ", c]
                        })]
                    }), (0, r.jsx)("div", {
                        className: E().sdGames,
                        children: s.map((function(e) {
                            return (0, r.jsx)(A, {
                                className: E().sdGame,
                                game: e,
                                hideIntlBroadcasters: o
                            }, e.gameId)
                        }))
                    })]
                })
            }
            U.propTypes = V.propTypes, U.defaultProps = V.defaultProps;
            var H = s(88723),
                W = s.n(H),
                q = {
                    week: b().number,
                    from: b().string,
                    to: b().string,
                    gamesByDay: b().arrayOf(b().shape({
                        key: b().string,
                        day: b().string,
                        games: b().arrayOf(P.ZP),
                        isPreseason: b().bool
                    }))
                };

            function z(e) {
                var a = e.week,
                    s = void 0 === a ? 0 : a,
                    t = e.from,
                    n = void 0 === t ? "" : t,
                    o = e.to,
                    i = void 0 === o ? "" : o,
                    c = e.gamesByDay,
                    d = void 0 === c ? [] : c,
                    l = e.hideIntlBroadcasters,
                    m = void 0 !== l && l;
                if (!d || !d.length) return null;
                var u = n && i;
                return (0, r.jsxs)("div", {
                    className: W().swBase,
                    children: [u && (0, r.jsxs)("h2", {
                        className: W().swHeader,
                        children: ["Week ", s, " (", n, " - ", i, ")"]
                    }), d.map((function(e) {
                        var a = e.key,
                            t = e.day,
                            n = e.games,
                            o = e.isPreseason;
                        return (0, r.jsx)(U, {
                            isPreseason: o,
                            week: s,
                            day: t,
                            games: n,
                            hideIntlBroadcasters: m
                        }, a)
                    }))]
                })
            }
            z.propTypes = q;
            var J = {
                gamesSchedule: b().arrayOf(b().shape({
                    week: b().number.isRequired,
                    from: b().string.isRequired,
                    to: b().string.isRequired,
                    gamesByDay: b().arrayOf(b().shape({
                        day: b().string,
                        key: b().string,
                        games: b().arrayOf(P.ZP)
                    }))
                }))
            };

            function X(e) {
                var a = e.gamesSchedule,
                    s = void 0 === a ? [] : a,
                    t = e.hideIntlBroadcasters,
                    n = void 0 !== t && t;
                return (0, r.jsx)("div", {
                    children: s.map((function(e) {
                        var a = e.week,
                            s = e.from,
                            t = e.to,
                            o = e.gamesByDay;
                        return (0, r.jsx)(z, {
                            week: a,
                            from: s,
                            to: t,
                            gamesByDay: o,
                            hideIntlBroadcasters: n
                        }, "week-".concat(a))
                    }))
                })
            }
            X.propTypes = J
        },
        67806: function(e, a) {
            "use strict";
            a.Z = {
                Unknown: "Unknown",
                Scheduled: "Scheduled",
                Live: "Live",
                PostGame: "PostGame",
                Cancelled: "Cancelled",
                Forfeited: "Forfeit",
                TimeTBD: "TimeTBD",
                OpponentTBD: "OpponentTBD",
                PreGame: "PreGame",
                Postponed: "PPD"
            }
        },
        43368: function(e, a, s) {
            "use strict";
            s.d(a, {
                JJ: function() {
                    return d
                },
                R8: function() {
                    return l
                },
                T6: function() {
                    return o
                },
                cG: function() {
                    return m
                }
            });
            var r = s(45697),
                t = s.n(r),
                n = s(38799),
                o = t().shape({
                    broadcasterAbbreviation: t().string,
                    broadcasterDisplay: t().string,
                    broadcasterId: t().number,
                    broadcasterMedia: t().string,
                    broadcasterScope: t().string
                }),
                i = t().shape({
                    losses: t().number,
                    score: t().number,
                    teamCity: t().string,
                    teamId: t().oneOfType([t().string, t().number]),
                    teamName: t().string,
                    teamSlug: t().string,
                    teamTricode: t().string,
                    wins: t().number
                }),
                c = t().shape({
                    arenaCity: t().string,
                    arenaName: t().string,
                    arenaState: t().string,
                    day: t().string,
                    gMonth: t().string,
                    gameClock: t().string,
                    gameCode: t().string,
                    gameDateEst: t().string,
                    gameDateUTC: t().string,
                    gameId: t().oneOfType([t().string, t().number]),
                    gameSequence: t().number,
                    gameStatus: t().number,
                    gameStatusText: t().string,
                    gdte: t().oneOfType([t().string, t().number]),
                    monthNum: t().number,
                    postponedStatus: t().string,
                    seriesText: t().string,
                    homeTeam: i,
                    visitorTeam: i,
                    broadcasters: t().shape({
                        awayRadioBroadcasters: t().arrayOf(o),
                        awayTvBroadcasters: t().arrayOf(o),
                        homeRadioBroadcasters: t().arrayOf(o),
                        homeTvBroadcasters: t().arrayOf(o),
                        nationalBroadcasters: t().arrayOf(o)
                    }),
                    weekName: t().string,
                    weekNumber: t().number,
                    period: t().number,
                    pbOdds: t().shape({
                        team: t().string,
                        odds: t().number,
                        suspended: t().number
                    })
                }),
                d = t().shape({
                    season: t().string,
                    cal: t().oneOfType([t().string, t().number]),
                    team: t().string,
                    bc: t().string,
                    pd: t().bool
                }),
                l = {
                    propTypes: {
                        layout: n.x0.isRequired,
                        teamName: t().string,
                        region: t().string,
                        scheduleSettings: t().shape({
                            month: t().string
                        }).isRequired
                    },
                    defaultProps: {
                        teamName: "all",
                        region: ""
                    }
                },
                m = {
                    teamName: t().string,
                    scheduleSettings: t().shape({
                        month: t().string
                    }).isRequired
                };
            a.ZP = c
        },
        77715: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return n
                }
            });
            var r = s(41470),
                t = s(42298);

            function n(e, a, s) {
                try {
                    var n = (0, r.Z)(e, a, Date.now());
                    return (0, t.Z)(n, s)
                } catch (o) {
                    return ""
                }
            }
        },
        73398: function(e, a, s) {
            "use strict";

            function r(e) {
                var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return !e.localizationRegion || "National" === e.localizationRegion || e.localizationRegion === a
            }
            s.d(a, {
                Z: function() {
                    return r
                }
            })
        },
        59342: function(e, a, s) {
            "use strict";

            function r() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                if (!Array.isArray(e) || !e.length) return [];
                var a = function(e) {
                    return "number" === typeof e.broadcasterRanking && 0 !== e.broadcasterRanking ? e.broadcasterRanking : 1 / 0
                };
                return e.sort((function(e, s) {
                    return a(e) - a(s)
                }))
            }
            s.d(a, {
                Z: function() {
                    return r
                }
            })
        },
        13208: function(e, a, s) {
            "use strict";
            s.d(a, {
                Z: function() {
                    return l
                }
            });
            var r = s(77226),
                t = s(77715),
                n = s(42298),
                o = s(23855),
                i = s(72378),
                c = s.n(i);

            function d(e, a) {
                e.length && e.forEach((function(e) {
                    var s = a.find((function(a) {
                        return +e.gameId === +a.gameId
                    }));
                    s && 3 !== +s.gameStatus && c()(s, e)
                }))
            }

            function l(e, a) {
                var s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                s.length > 0 && d(s, e);
                var i = (0, r.vM)(e, "weekNumber", !1, 0).map((function(e) {
                    var s = e.key,
                        i = e.items,
                        c = (0, r.vM)(i, "gdte").map((function(e) {
                            return {
                                key: e.key,
                                isPreseason: e.items.some((function(e) {
                                    return (0, r.rT)(e.gameId).isPre
                                })),
                                day: (0, t.Z)(e.key, "yyyyMMdd", "EEEE, MMMM d"),
                                games: e.items
                            }
                        })),
                        d = a[+s - 1] || {},
                        l = d.startDate,
                        m = d.endDate;
                    return {
                        week: s,
                        from: l ? (0, n.Z)((0, o.Z)(l.slice(0, 10)), "MMM d") : "",
                        to: m ? (0, n.Z)((0, o.Z)(m.slice(0, 10)), "MMM d") : "",
                        gamesByDay: c
                    }
                }));
                return i
            }
        },
        99170: function(e) {
            e.exports = {
                base: "Broadcasters_base__Wet1u",
                tv: "Broadcasters_tv__AIeZb",
                title: "Broadcasters_title__B1dGd",
                vertical: "Broadcasters_vertical__cOo2a",
                section: "Broadcasters_section__ISlyP",
                horizontal: "Broadcasters_horizontal__FE44_",
                icon: "Broadcasters_icon__82MTV",
                lpIcon: "Broadcasters_lpIcon__RML_G",
                externalIcon: "Broadcasters_externalIcon__cDctx",
                externalVideoLinkIcon: "Broadcasters_externalVideoLinkIcon__IxPW_",
                bBlock: "Broadcasters_bBlock__MHsqE",
                intl: "Broadcasters_intl__IhxNw",
                smallerSection: "Broadcasters_smallerSection__90ynT",
                promoBanner: "Broadcasters_promoBanner__D_h9L",
                promoBannerLoggedOut: "Broadcasters_promoBannerLoggedOut__I51d2",
                promoBannerStandAlone: "Broadcasters_promoBannerStandAlone__X_Oh7",
                promoButton: "Broadcasters_promoButton__Indew",
                header: "Broadcasters_header__xITNj",
                subHeader: "Broadcasters_subHeader__hcDjg",
                border: "Broadcasters_border__CN_ON",
                standAloneBorder: "Broadcasters_standAloneBorder__Sumx8",
                standAloneMobile: "Broadcasters_standAloneMobile__1L4LK",
                gameDetailsTitle: "Broadcasters_gameDetailsTitle__460fm",
                broadcasterName: "Broadcasters_broadcasterName__uCp5J",
                BroadcasterFallbackText: "Broadcasters_BroadcasterFallbackText__nRVU4"
            }
        },
        95461: function(e) {
            e.exports = {
                sd: "ScheduleDay_sd__GFE_w",
                sdTop: "ScheduleDay_sdTop__TqiPn",
                sdPreseason: "ScheduleDay_sdPreseason__Hd3_d",
                sdDay: "ScheduleDay_sdDay__3s2Xt",
                sdWeek: "ScheduleDay_sdWeek__iiTmo",
                sdContent: "ScheduleDay_sdContent__U6c_v",
                sdGames: "ScheduleDay_sdGames__NGdO5"
            }
        },
        66917: function(e) {
            e.exports = {
                sg: "ScheduleGame_sg__RmD9I",
                sgContent: "ScheduleGame_sgContent__lHCIC",
                sgBroadcasters: "ScheduleGame_sgBroadcasters__O2nwT",
                sgFigtext: "ScheduleGame_sgFigtext__gYud6",
                sgLabel: "ScheduleGame_sgLabel__wkprj",
                sgStatus: "ScheduleGame_sgStatus__NqtTI",
                sgTeam: "ScheduleGame_sgTeam__TEPZa",
                sgWinProb: "ScheduleGame_sgWinProb__zXtf_",
                teamName: "ScheduleGame_teamName__vmJm6",
                gameOdds: "ScheduleGame_gameOdds__xgiNL",
                sgMatchup: "ScheduleGame_sgMatchup__SK1PV",
                sgScore: "ScheduleGame_sgScore__H8jxR",
                sgScoreVal: "ScheduleGame_sgScoreVal__L4KZO",
                sgWin: "ScheduleGame_sgWin__Db9mV",
                sgLocation: "ScheduleGame_sgLocation__9FrcS",
                sgLocationInner: "ScheduleGame_sgLocationInner__xxr0Z",
                sgOptions: "ScheduleGame_sgOptions__lLzuQ",
                tab: "ScheduleGame_tab__mVhtV"
            }
        },
        86984: function(e) {
            e.exports = {
                base: "ScheduleStatusText_base__Jgvjb",
                icon: "ScheduleStatusText_icon__BVhJX"
            }
        },
        88723: function(e) {
            e.exports = {
                swBase: "ScheduleWeek_swBase__6wxQ7",
                swHeader: "ScheduleWeek_swHeader__2THvJ"
            }
        }
    }
]);