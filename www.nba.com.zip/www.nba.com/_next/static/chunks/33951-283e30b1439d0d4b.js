(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [33951], {
        54665: function(e, a, t) {
            "use strict";
            var s, r = t(67294);

            function n() {
                return n = Object.assign ? Object.assign.bind() : function(e) {
                    for (var a = 1; a < arguments.length; a++) {
                        var t = arguments[a];
                        for (var s in t)({}).hasOwnProperty.call(t, s) && (e[s] = t[s])
                    }
                    return e
                }, n.apply(null, arguments)
            }
            a.Z = e => r.createElement("svg", n({
                width: 20,
                height: 17,
                viewBox: "0 0 20 17",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
            }, e), s || (s = r.createElement("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M19.2593 1.53303L6.5565 16.3529L0.792908 10.5893L2.20712 9.17513L6.44353 13.4115L17.7408 0.231445L19.2593 1.53303Z",
                fill: "black"
            })))
        },
        39633: function(e, a, t) {
            "use strict";
            var s = t(47568),
                r = t(26042),
                n = t(34051),
                i = t.n(n),
                c = t(14648),
                o = t(67724),
                d = "shotchartleaguewide",
                l = {
                    LeagueID: o.i8
                },
                u = function(e) {
                    return {
                        averages: e.find((function(e) {
                            return "League_Wide" === e.name
                        })).rows
                    }
                },
                m = function() {
                    return {
                        averages: []
                    }
                },
                h = function() {
                    var e = (0, s.Z)(i().mark((function e(a) {
                        var t;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return t = {
                                        resource: d,
                                        transform: u,
                                        params: (0, r.Z)({}, l, a),
                                        fail: m
                                    }, e.abrupt("return", c.Z.get(t));
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(a) {
                        return e.apply(this, arguments)
                    }
                }();
            a.Z = {
                resource: d,
                params: l,
                transform: u,
                get: h,
                fail: m
            }
        },
        24945: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return x
                }
            });
            var s = t(85893),
                r = t(45697),
                n = t.n(r),
                i = t(54005),
                c = {
                    vtm: n().shape({
                        name: n().string.isRequired,
                        color: n().string.isRequired
                    }).isRequired,
                    htm: n().shape({
                        name: n().string.isRequired,
                        color: n().string.isRequired
                    }).isRequired,
                    stats: n().arrayOf(n().shape({
                        label: n().string.isRequired,
                        vtm: n().oneOfType([n().number, n().string]).isRequired,
                        htm: n().oneOfType([n().number, n().string]).isRequired
                    })).isRequired
                },
                o = t(33350),
                d = t.n(o),
                l = 30,
                u = 20,
                m = 22,
                h = 290;

            function S(e) {
                var a = e.x,
                    t = e.y,
                    r = e.stat,
                    n = e.vtmColor,
                    i = e.htmColor,
                    c = r.label,
                    o = r.vtm,
                    d = r.htm;
                return (0, s.jsxs)("g", {
                    className: "row",
                    transform: "translate(0, ".concat(t(c), ")"),
                    children: [(0, s.jsx)("text", {
                        transform: "translate(".concat(290, ", 0)"),
                        textAnchor: "middle",
                        fill: "#545454",
                        fontSize: "14",
                        dy: t.bandwidth() / 2 + 4,
                        children: c
                    }), (0, s.jsxs)("g", {
                        transform: "translate(".concat(h - m, ", 0)"),
                        children: [(0, s.jsx)("rect", {
                            fill: n,
                            x: -a(o),
                            y: "0",
                            height: t.bandwidth(),
                            width: a(o)
                        }), (0, s.jsx)("text", {
                            x: -a(o) - 5,
                            dy: t.bandwidth() / 2 + 4,
                            textAnchor: "end",
                            fontWeight: "800",
                            fill: n,
                            children: o
                        })]
                    }), (0, s.jsxs)("g", {
                        transform: "translate(".concat(h + m, ", 0)"),
                        children: [(0, s.jsx)("rect", {
                            fill: i,
                            x: "0",
                            y: "0",
                            height: t.bandwidth(),
                            width: a(d)
                        }), (0, s.jsx)("text", {
                            transform: "translate(".concat(a(d) + 5, ", 0)"),
                            dy: t.bandwidth() / 2 + 4,
                            textAnchor: "start",
                            fontWeight: "800",
                            fill: i,
                            children: d
                        })]
                    })]
                })
            }

            function p(e) {
                var a = e.vtm,
                    t = e.htm,
                    r = e.stats,
                    n = (0, i.Fp7)(r, (function(e) {
                        return Math.max(+e.vtm, +e.htm)
                    })),
                    c = (0, i.tiA)().domain(r.map((function(e) {
                        return e.label
                    }))).range([l, 500 - u]).padding(.3),
                    o = (0, i.BYU)().domain([0, n + 5]).range([0, 228]);
                return (0, s.jsx)("div", {
                    className: d().chart,
                    children: (0, s.jsxs)("svg", {
                        viewBox: "0 0 ".concat(580, " ").concat(500),
                        style: {
                            fill: "#000",
                            fontFamily: "Roboto"
                        },
                        children: [(0, s.jsx)("text", {
                            transform: "translate(".concat(h - m, ", 25)"),
                            textAnchor: "end",
                            fontSize: "20",
                            fill: a.color,
                            fontWeight: "800",
                            children: a.name
                        }), (0, s.jsx)("text", {
                            transform: "translate(".concat(h + m, ", 25)"),
                            textAnchor: "start",
                            fontSize: "20",
                            fill: t.color,
                            fontWeight: "800",
                            children: t.name
                        }), (0, s.jsx)("g", {
                            children: r.map((function(e) {
                                return (0, s.jsx)(S, {
                                    x: o,
                                    y: c,
                                    stat: e,
                                    vtmColor: a.color,
                                    htmColor: t.color
                                }, e.label)
                            }))
                        })]
                    })
                })
            }
            S.propTypes = {
                x: n().func.isRequired,
                y: n().func.isRequired,
                stat: n().shape({
                    label: n().string,
                    vtm: n().oneOfType([n().number, n().string]).isRequired,
                    htm: n().oneOfType([n().number, n().string]).isRequired
                }).isRequired,
                vtmColor: n().string.isRequired,
                htmColor: n().string.isRequired
            }, p.propTypes = c;
            var x = p
        },
        29277: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return x
                }
            });
            var s = t(29815),
                r = t(85893),
                n = t(67294),
                i = t(45697),
                c = t.n(i),
                o = t(54005),
                d = {
                    vtm: c().shape({
                        name: c().string.isRequired,
                        color: c().string.isRequired
                    }).isRequired,
                    htm: c().shape({
                        name: c().string.isRequired,
                        color: c().string.isRequired
                    }).isRequired,
                    stats: c().arrayOf(c().shape({
                        label: c().string.isRequired,
                        team: c().string.isRequired,
                        value: c().oneOfType([c().number, c().string]).isRequired,
                        playerId: c().oneOfType([c().number, c().string]).isRequired,
                        playerFn: c().string,
                        playerLn: c().string
                    })).isRequired
                },
                l = t(35645),
                u = t.n(l);

            function m(e) {
                var a = e.player,
                    t = e.index,
                    s = a.label,
                    i = a.value,
                    c = a.playerId,
                    d = a.playerFn,
                    l = a.playerLn,
                    u = a.color,
                    m = a.theta,
                    h = a.labelX,
                    S = a.labelY,
                    p = a.dX,
                    x = a.dY,
                    f = a.pX,
                    _ = a.pY,
                    b = a.r,
                    v = 0 !== c,
                    g = (0, n.useState)(!0),
                    y = g[0],
                    j = g[1];
                return (0, r.jsxs)("g", {
                    className: "player",
                    "data-stat": s,
                    "data-value": i,
                    children: [v && (0, r.jsx)("g", {
                        transform: "rotate(".concat(m, ")"),
                        children: (0, r.jsx)("path", {
                            stroke: u,
                            strokeWidth: "2",
                            d: (0, o.jvg)()([
                                [0, 0],
                                [250, 0]
                            ])
                        })
                    }), (0, r.jsx)("g", {
                        transform: "rotate(".concat(m - 22.5, ")"),
                        children: (0, r.jsx)("path", {
                            fill: u,
                            d: "m0,0 l".concat(b, ",0 A").concat(b, ",").concat(b, " 1 0 1 ").concat(p, ", ").concat(x, " Z")
                        })
                    }), (0, r.jsxs)("g", {
                        transform: "translate(".concat(h, ", ").concat(S, ")"),
                        children: [(0, r.jsx)("circle", {
                            stroke: u,
                            strokeWidth: "2",
                            fill: "#fff",
                            r: "20"
                        }), (0, r.jsx)("text", {
                            textAnchor: "middle",
                            dy: "6",
                            children: i
                        })]
                    }), v && (0, r.jsxs)("g", {
                        transform: "translate(".concat(t > 3 ? f - 100 : f, ", ").concat(_, ")"),
                        children: [(0, r.jsx)("path", {
                            stroke: u,
                            strokeWidth: "2",
                            d: (0, o.jvg)()([
                                [0, 0],
                                [100, 0]
                            ])
                        }), (0, r.jsx)("text", {
                            textAnchor: "middle",
                            fill: "#000",
                            dx: "50",
                            dy: "-21",
                            fontFamily: "Roboto Condensed",
                            children: d
                        }), (0, r.jsx)("text", {
                            textAnchor: "middle",
                            fill: "#000",
                            dx: "50",
                            dy: "-6",
                            fontFamily: "Roboto Condensed",
                            children: l
                        }), y && (0, r.jsx)("circle", {
                            cx: "50",
                            cy: "-80",
                            r: "40",
                            stroke: u,
                            strokeWidth: "2",
                            fill: "#fff"
                        }), y && (0, r.jsx)("image", {
                            xlinkHref: "".concat("https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/").concat(c, ".png"),
                            y: "-136",
                            width: "100",
                            height: "136",
                            clipPath: "url(#circle-mask)",
                            onError: function() {
                                return j(!1)
                            }
                        })]
                    })]
                })
            }

            function h(e) {
                var a = e.label,
                    t = e.index;
                return (0, r.jsx)("g", {
                    transform: "rotate(".concat(90 * t + 225, ") translate(0, 35)"),
                    children: (0, r.jsx)("text", {
                        textAnchor: "middle",
                        fontWeight: "bold",
                        dy: "5",
                        transform: "rotate(".concat(3 === t || 0 === t ? 180 : 0, ")"),
                        children: a
                    })
                })
            }
            m.propTypes = {
                player: c().shape({
                    color: c().string,
                    dX: c().number,
                    dY: c().number,
                    label: c().string,
                    labelX: c().number,
                    labelY: c().number,
                    pX: c().number,
                    pY: c().number,
                    playerFn: c().string,
                    playerId: c().number,
                    playerLn: c().string,
                    r: c().number,
                    team: c().string,
                    theta: c().number,
                    value: c().number
                }).isRequired,
                index: c().number.isRequired
            }, h.propTypes = {
                label: c().string.isRequired,
                index: c().number.isRequired
            };
            var S = Math.PI / 180;

            function p(e) {
                var a = e.vtm,
                    t = e.htm,
                    i = e.stats,
                    c = (0, s.Z)(new Set(i.map((function(e) {
                        return e.label
                    })))),
                    d = (0, o.Fp7)(i, (function(e) {
                        return +e.value
                    })),
                    l = (0, o.BYU)().domain([0, d]).range([80, 200]),
                    p = (0, n.useMemo)((function() {
                        return i.map((function(e, s) {
                            return e.color = "vtm" === e.team ? a.color : t.color, e.theta = 45 * s - 67.5, e.r = l(+e.value), e.labelX = Math.cos(e.theta * S) * Math.max(e.r), e.labelY = Math.sin(e.theta * S) * Math.max(e.r), e.dX = Math.cos(45 * S) * Math.max(e.r), e.dY = Math.sin(45 * S) * Math.max(e.r), e.pX = 250 * Math.cos(e.theta * S), e.pY = 250 * Math.sin(e.theta * S), e
                        }))
                    }), [i, a, t, l]);
                return (0, r.jsx)("div", {
                    className: u().chart,
                    children: (0, r.jsxs)("svg", {
                        viewBox: "0 0 ".concat(750, " ").concat(750),
                        style: {
                            fill: "#000",
                            fontFamily: "Roboto Condensed"
                        },
                        children: [(0, r.jsx)("defs", {
                            children: (0, r.jsx)("clipPath", {
                                id: "circle-mask",
                                children: (0, r.jsx)("circle", {
                                    cx: "50",
                                    cy: "-80",
                                    r: "40"
                                })
                            })
                        }), (0, r.jsxs)("g", {
                            className: "rosechart",
                            transform: "translate(".concat(375, ", ").concat(375, ")"),
                            children: [p.map((function(e, a) {
                                return (0, r.jsx)(m, {
                                    player: e,
                                    index: a
                                }, e.team + e.label)
                            })), (0, r.jsx)("circle", {
                                fill: "#fff",
                                r: 50
                            }), c.map((function(e, a) {
                                return (0, r.jsx)(h, {
                                    label: e,
                                    index: a
                                }, e)
                            }))]
                        })]
                    })
                })
            }
            p.propTypes = d;
            var x = p
        },
        60421: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return S
                }
            });
            var s = t(26042),
                r = t(69396),
                n = t(99534),
                i = t(85893),
                c = t(81803),
                o = t(85121),
                d = t(28876),
                l = t.n(d),
                u = t(45697),
                m = t.n(u),
                h = {
                    propTypes: {
                        chartRef: m().oneOfType([m().object, m().any, m().shape(m().any)]),
                        filename: m().string
                    },
                    defaultProps: {
                        chartRef: {},
                        filename: "shotchart.png"
                    }
                };

            function S(e) {
                var a = e.chartRef,
                    t = e.filename,
                    d = (0, n.Z)(e, ["chartRef", "filename"]);
                return (0, i.jsx)(o.Z, (0, r.Z)((0, s.Z)({
                    as: "button",
                    variant: "primary",
                    onClick: function() {
                        try {
                            (0, c.saveSvgAsPng)(a.current, t)
                        } catch (e) {
                            console.warn(e)
                        }
                    },
                    className: l().saveSvgButton,
                    "data-track": "click",
                    "data-type": "button",
                    "data-text": "DOWNLOAD"
                }, d), {
                    children: "DOWNLOAD"
                }))
            }
            S.propTypes = h.propTypes, S.defaultProps = h.defaultProps
        },
        73254: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return d
                }
            });
            var s = t(85893),
                r = t(85121),
                n = t(81291),
                i = t.n(n),
                c = t(45697),
                o = {
                    onClick: t.n(c)().func.isRequired
                };

            function d(e) {
                var a = e.onClick;
                return (0, s.jsxs)("div", {
                    className: i().hideScores,
                    children: [(0, s.jsx)("p", {
                        className: i().hideScoresLabel,
                        children: "Hide Scores Mode"
                    }), (0, s.jsx)("p", {
                        className: i().hideScoresSmall,
                        children: "Content is hidden to prevent spoilers according to your settings."
                    }), (0, s.jsx)("p", {
                        className: i().hideScoresSmall,
                        children: "Tap below to show scores for this game only"
                    }), (0, s.jsx)(r.Z, {
                        as: "button",
                        variant: "primary",
                        className: i().hideScoresButton,
                        onClick: a,
                        children: "SHOW SCORES FOR THIS GAME"
                    })]
                })
            }
            d.propTypes = o
        },
        6612: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return c
                }
            });
            var s = t(26042),
                r = t(99534),
                n = t(85893),
                i = t(54665);

            function c(e) {
                var a = e.alt,
                    t = e.className,
                    c = e.role,
                    o = void 0 === c ? "presentation" : c,
                    d = e.style,
                    l = e.title,
                    u = (0, r.Z)(e, ["alt", "className", "role", "style", "title"]);
                return (0, n.jsx)(i.Z, (0, s.Z)({
                    alt: a,
                    className: t,
                    "data-no-icon": !0,
                    role: o,
                    style: d,
                    title: l
                }, u))
            }
        },
        54191: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return S
                }
            });
            var s = t(26042),
                r = t(99534),
                n = t(85893),
                i = t(93967),
                c = t.n(i),
                o = t(6612),
                d = t(71352),
                l = t.n(d),
                u = t(45697),
                m = t.n(u),
                h = {
                    checked: m().bool.isRequired,
                    onChange: m().func.isRequired,
                    className: m().string,
                    name: m().string.isRequired,
                    variant: m().oneOf(["default", "allstar"])
                };

            function S(e) {
                var a = e.checked,
                    t = e.onChange,
                    i = e.className,
                    d = e.outlineEnabled,
                    u = e.name,
                    m = e.variant,
                    h = void 0 === m ? "default" : m,
                    S = (0, r.Z)(e, ["checked", "onChange", "className", "outlineEnabled", "name", "variant"]);
                return (0, n.jsxs)("label", {
                    htmlFor: u,
                    children: [(0, n.jsx)("div", {
                        className: l().checkbox,
                        children: (0, n.jsx)("div", {
                            className: c()(d ? l().iconWrapper : null, a ? l().icon : null, "allstar" === h ? l().allstarIcon : null),
                            children: a ? (0, n.jsx)("div", {
                                children: (0, n.jsx)(o.Z, {})
                            }) : null
                        })
                    }), (0, n.jsx)("input", (0, s.Z)({
                        type: "checkbox",
                        name: u,
                        id: u,
                        checked: a,
                        onChange: t,
                        className: c()(l().inputCheckbox, i)
                    }, S))]
                })
            }
            S.propTypes = h
        },
        91914: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return p
                }
            });
            var s = t(26042),
                r = t(85893),
                n = t(67294),
                i = t(92875),
                c = t(92033),
                o = t(37346),
                d = t(41684),
                l = t(44762),
                u = t(84938),
                m = t.n(u),
                h = {
                    series: "View Series",
                    standings: "View Standings",
                    default: "View Bracket"
                },
                S = {
                    series: "nba:games:game-details:summary:view-series:cta",
                    standings: "nba:games:game-details:summary:view-standings:cta",
                    default: "nba:playoffs:series-hub:main:view-bracket:cta"
                };

            function p(e) {
                var a = e.awayTeamId,
                    t = e.homeTeamId,
                    u = e.awayTeamRank,
                    p = e.homeTeamRank,
                    x = e.conferenceText,
                    f = e.seriesText,
                    _ = e.actionLink,
                    b = e.linkTo,
                    v = e.seriesTitle,
                    g = e.hideScores,
                    y = e.actionCtaText,
                    j = void 0 === y ? "" : y,
                    T = e.awayTeamRecord,
                    N = e.homeTeamRecord,
                    H = e.upcomingGameText,
                    M = e.broadcasterText,
                    L = e.fullCardLink,
                    k = void 0 === L ? "" : L,
                    Z = (0, n.useContext)(i.Z).teams,
                    C = Z.find((function(e) {
                        return e[0] === t
                    })),
                    R = Z.find((function(e) {
                        return e[0] === a
                    })),
                    w = (0, c.Z)(["10", "2"], R, "#191c23"),
                    A = (0, c.Z)(["10", "2"], C, "#191c23"),
                    I = (0, c.Z)(["1"], C, ""),
                    P = (0, c.Z)(["1"], R, ""),
                    O = (0, c.Z)(["4"], C, "TBD"),
                    G = (0, c.Z)(["4"], R, "TBD"),
                    E = "TBD" === O,
                    B = "TBD" === G,
                    z = j || h[b] || h.default,
                    D = {
                        "data-track": "click",
                        "data-type": "cta",
                        "data-id": S[b] || S.default,
                        "data-text": z,
                        "data-section": "summary-module",
                        "data-content": v
                    },
                    q = (0, r.jsxs)("div", {
                        className: m().container,
                        children: [(0, r.jsx)("div", {
                            className: m().seriesTheme,
                            children: (0, r.jsxs)("svg", {
                                width: "100%",
                                height: "100%",
                                viewBox: "0 0 100 100",
                                preserveAspectRatio: "none",
                                children: [(0, r.jsx)("polygon", {
                                    points: "0,0 60,0 40,100 0,100 0,0",
                                    fill: w,
                                    fillOpacity: "0.95"
                                }), (0, r.jsx)("polygon", {
                                    points: "60,0 40,100 100,100 100,0 60,0",
                                    fill: A,
                                    fillOpacity: "0.95"
                                })]
                            })
                        }), (0, r.jsx)("div", {
                            className: m().seriesHubStatusContainer,
                            children: (0, r.jsxs)("div", {
                                className: m().seriesHubStatus,
                                children: [(0, r.jsxs)("div", {
                                    className: m().mobileSeriesText,
                                    children: [(0, r.jsx)(o.Z, {
                                        className: m().confText,
                                        text: x
                                    }), !g && (0, r.jsx)(o.Z, {
                                        text: f,
                                        className: m().seriesText
                                    })]
                                }), (0, r.jsxs)("div", {
                                    className: m().seriesHubStatusContent,
                                    children: [(0, r.jsxs)("div", {
                                        className: m().team,
                                        children: [(0, r.jsx)("div", {
                                            className: m().teamLogo,
                                            children: B ? (0, r.jsx)("div", {
                                                className: m().teamLogoPlaceholder
                                            }) : (0, r.jsx)(l.Z, {
                                                tid: a,
                                                name: P,
                                                logoType: "dark"
                                            })
                                        }), (0, r.jsxs)("div", {
                                            className: m().teamRankWrapper,
                                            children: [!B && (0, r.jsx)("p", {
                                                className: m().teamRank,
                                                children: u
                                            }), (0, r.jsx)("p", {
                                                className: m().teamName,
                                                children: G
                                            })]
                                        }), !g && T && (0, r.jsx)(o.Z, {
                                            className: m().teamRecord,
                                            text: T
                                        })]
                                    }), (0, r.jsxs)("div", {
                                        className: m().series,
                                        children: [(0, r.jsx)(o.Z, {
                                            className: m().confText,
                                            text: x
                                        }), !g && (0, r.jsx)(o.Z, {
                                            text: f,
                                            className: m().seriesText
                                        }), H && (0, r.jsx)(o.Z, {
                                            text: H,
                                            className: m().upcomingGameText
                                        }), M && (0, r.jsx)(o.Z, {
                                            text: M,
                                            className: m().upcomingGameText
                                        }), (0, r.jsx)(d.Z, (0, s.Z)({
                                            href: _,
                                            text: z,
                                            className: m().actionLink
                                        }, D))]
                                    }), (0, r.jsxs)("div", {
                                        className: m().team,
                                        children: [(0, r.jsx)("div", {
                                            className: m().teamLogo,
                                            children: E ? (0, r.jsx)("div", {
                                                className: m().teamLogoPlaceholder
                                            }) : (0, r.jsx)(l.Z, {
                                                tid: t,
                                                name: I,
                                                logoType: "dark"
                                            })
                                        }), (0, r.jsxs)("div", {
                                            className: m().teamRankWrapper,
                                            children: [!E && (0, r.jsx)("p", {
                                                className: m().teamRank,
                                                children: p
                                            }), (0, r.jsx)("p", {
                                                className: m().teamName,
                                                children: O
                                            })]
                                        }), !g && N && (0, r.jsx)(o.Z, {
                                            className: m().teamRecord,
                                            text: N
                                        })]
                                    })]
                                }), !k && (0, r.jsx)("div", {
                                    className: m().mobileSeriesText,
                                    children: (0, r.jsx)(d.Z, (0, s.Z)({
                                        href: _,
                                        text: z,
                                        className: m().actionLink
                                    }, D))
                                })]
                            })
                        })]
                    });
                return k ? (0, r.jsx)(d.Z, {
                    href: k,
                    children: q
                }) : q
            }
        },
        90375: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return ne
                }
            });
            var s = t(85893),
                r = t(67294),
                n = t(92875),
                i = t(91567),
                c = t(77226),
                o = t(2504),
                d = t(91914),
                l = t(29815),
                u = t(72378),
                m = t.n(u),
                h = t(26042),
                S = t(69396),
                p = t(36617),
                x = t(41684),
                f = t(72592),
                _ = t(49507),
                b = t(86075),
                v = t.n(b);

            function g(e) {
                var a = e.gameId,
                    t = e.gameStatus,
                    r = e.awayTeamTricode,
                    n = e.homeTeamTricode,
                    i = e.forAnalytics,
                    c = void 0 === i ? {} : i,
                    o = t === _.Z.Final ? "Game Recap" : "Game Detail",
                    d = (0, p.Z)(a, r, n);
                return (0, s.jsx)("div", {
                    className: v().broadcast,
                    children: (0, s.jsxs)(x.Z, (0, S.Z)((0, h.Z)({
                        href: d,
                        className: v().broadcastLink,
                        "data-track": "click",
                        "data-type": "cta",
                        "data-id": "nba:playoffs:series-hub:main:game-details:cta",
                        "data-text": o.toLocaleUpperCase(),
                        "data-section": "summary-module"
                    }, c), {
                        children: [(0, s.jsx)("p", {
                            className: v().tunein,
                            children: o
                        }), (0, s.jsx)("div", {
                            className: v().mobileGameLinkIndicator,
                            children: (0, s.jsx)(f.Z, {
                                dir: "right"
                            })
                        })]
                    }))
                })
            }
            var y = t(44762),
                j = t(18377),
                T = t(47347),
                N = t(71678),
                H = t(16209),
                M = t.n(H);

            function L(e) {
                var a = e.gameStatus,
                    t = e.gameEt,
                    r = e.gameWeekday,
                    n = e.gameStatusText,
                    i = e.homeTeamScore,
                    c = e.awayTeamScore,
                    o = e.hideScores;
                switch (a) {
                    case _.Z.Upcoming:
                        var d = (0, N.Z)(t, "MMMM d, yyyy"),
                            l = d ? "".concat(r, " \u2022 ").concat(d) : "TBD";
                        return (0, s.jsxs)("div", {
                            className: M().gameStartInfo,
                            children: [(0, s.jsx)("p", {
                                className: M().gameTime,
                                children: n
                            }), (0, s.jsx)("p", {
                                className: M().gameDate,
                                children: l
                            })]
                        });
                    case _.Z.Live:
                        return (0, s.jsx)("div", {
                            children: (0, s.jsx)(j.Z, {
                                className: M().liveBadge,
                                large: !0
                            })
                        });
                    case _.Z.Final:
                        var u = +i > +c,
                            m = +c > +i;
                        return (0, s.jsx)("div", {
                            className: M().gameOutcomeContainer,
                            children: o ? (0, s.jsx)("div", {
                                className: M().gameOutcomeText,
                                children: (0, s.jsx)("p", {
                                    className: M().gameStatusText,
                                    children: n.toUpperCase() || "FINAL"
                                })
                            }) : (0, s.jsxs)(s.Fragment, {
                                children: [(0, s.jsx)("div", {
                                    className: M().score,
                                    children: (0, s.jsx)("p", {
                                        className: M().awayTeamScore,
                                        children: c
                                    })
                                }), (0, s.jsxs)("div", {
                                    className: M().gameOutcomeText,
                                    children: [(0, s.jsx)("div", {
                                        className: M().winnerIndicatorLeft,
                                        children: m && (0, s.jsx)(T.Z, {
                                            className: M().winnerIndicatorLeft,
                                            dir: "left"
                                        })
                                    }), (0, s.jsx)("p", {
                                        className: M().gameStatusText,
                                        children: n.toUpperCase() || "FINAL"
                                    }), (0, s.jsx)("div", {
                                        className: M().winnerIndicatorRight,
                                        children: u && (0, s.jsx)(T.Z, {
                                            className: M().winnerIndicatorRight,
                                            dir: "right"
                                        })
                                    })]
                                }), (0, s.jsx)("div", {
                                    className: M().score,
                                    children: (0, s.jsx)("p", {
                                        className: M().homeTeamScore,
                                        children: i
                                    })
                                })]
                            })
                        });
                    default:
                        return null
                }
            }
            var k = t(68897),
                Z = t.n(k);

            function C(e) {
                var a = e.gameId,
                    t = e.gameStatus,
                    r = e.gameStatusText,
                    n = e.gameEt,
                    i = e.gameWeekday,
                    c = e.awayTeamId,
                    o = e.homeTeamId,
                    d = e.hideScores,
                    l = e.awayTeamTricode,
                    u = e.homeTeamTricode,
                    m = e.awayTeamScore,
                    f = e.homeTeamScore,
                    b = e.forAnalytics,
                    v = void 0 === b ? {} : b,
                    g = (0, p.Z)(a, l, u);
                return (0, s.jsx)(x.Z, (0, S.Z)((0, h.Z)({
                    href: g,
                    className: Z().summary,
                    "data-track": "click",
                    "data-type": "cta",
                    "data-id": "nba:playoffs:series-hub:main:game-details:cta",
                    "data-text": t === _.Z.Final ? "Game Recap" : "Game Detail",
                    "data-section": "summary-module"
                }, v), {
                    children: (0, s.jsxs)("div", {
                        className: Z().gameStatus,
                        children: [(0, s.jsx)("div", {
                            className: Z().teamLogo,
                            children: (0, s.jsx)(y.Z, {
                                tid: c,
                                name: l
                            })
                        }), (0, s.jsx)("div", {
                            className: Z().gameStatusContainer,
                            children: (0, s.jsx)(L, {
                                gameStatus: t,
                                gameEt: n,
                                gameWeekday: i,
                                gameStatusText: r,
                                homeTeamScore: f,
                                awayTeamScore: m,
                                hideScores: d
                            })
                        }), (0, s.jsx)("div", {
                            className: Z().teamLogo,
                            children: (0, s.jsx)(y.Z, {
                                tid: o,
                                name: u
                            })
                        })]
                    })
                }))
            }
            var R = t(12324),
                w = t(54141),
                A = t(12446),
                I = t.n(A);

            function P(e) {
                var a = e.games,
                    t = e.hideScores,
                    n = (0, r.useContext)(R.M).liveGames,
                    i = void 0 === n ? [] : n,
                    c = (0, l.Z)(a);
                return i.length && c.forEach((function(e, a) {
                    var t = i.find((function(a) {
                        return a.gameId === e.gameId
                    }));
                    t && (c[a] = m()(e, t))
                })), c.map((function(e, a) {
                    var r = e.gameId,
                        n = e.seriesGameNumber,
                        i = e.seriesText,
                        c = e.gameWeekday,
                        o = e.gameStatus,
                        d = e.gameStatusText,
                        l = e.gameEt,
                        u = e.homeTeam,
                        m = e.awayTeam,
                        h = u.teamId,
                        S = u.teamTricode,
                        p = u.score,
                        x = m.teamId,
                        f = m.teamTricode,
                        _ = m.score,
                        b = (0, w.f)(e);
                    return (0, s.jsxs)("div", {
                        className: I().seriesMatchup,
                        children: [(0, s.jsx)("div", {
                            className: I().gameInfo,
                            children: (0, s.jsxs)("p", {
                                className: I().seriesRecordStatus,
                                children: [(0, s.jsx)("span", {
                                    className: I().seriesGameNumber,
                                    children: n
                                }), !t && (0, s.jsx)("span", {
                                    children: i
                                })]
                            })
                        }), (0, s.jsx)(C, {
                            gameId: r,
                            gameStatus: o,
                            gameStatusText: d,
                            gameEt: l,
                            gameWeekday: (null === c || void 0 === c ? void 0 : c.slice(0, 3)) || "TBD",
                            awayTeamId: x,
                            homeTeamId: h,
                            awayTeamTricode: f,
                            homeTeamTricode: S,
                            hideScores: t,
                            awayTeamScore: _,
                            homeTeamScore: p,
                            forAnalytics: {
                                "data-content": b,
                                "data-pos": a + 1
                            }
                        }), (0, s.jsx)(g, {
                            gameId: r,
                            gameStatus: o,
                            awayTeamTricode: f,
                            homeTeamTricode: S,
                            forAnalytics: {
                                "data-content": b,
                                "data-pos": a + 1
                            }
                        })]
                    }, r)
                }))
            }
            var O = t(92033),
                G = t(30960),
                E = t.n(G);

            function B(e) {
                var a = e.awayStat,
                    t = e.homeStat,
                    r = e.title,
                    n = e.awayTeamColor,
                    i = e.homeTeamColor,
                    o = (0, c.OK)(a + t),
                    d = +o > 0,
                    l = d ? (0, c.OK)(99 * a / +o) : 0,
                    u = d ? (0, c.OK)(99 * t / +o) : 0;
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsxs)("div", {
                        className: E().seriesHubStats,
                        children: [(0, s.jsx)("p", {
                            className: E().seriesHubStatHome,
                            children: (0, c.OK)(a, 1)
                        }), (0, s.jsx)("p", {
                            className: E().seriesHubStatsCategory,
                            children: r
                        }), (0, s.jsx)("p", {
                            className: E().seriesHubStatAway,
                            children: (0, c.OK)(t, 1)
                        })]
                    }), d && (0, s.jsxs)("div", {
                        className: E().seriesHubChart,
                        children: [(0, s.jsx)("div", {
                            className: E().seriesHubChartAway,
                            style: {
                                width: "".concat(l, "%"),
                                background: n
                            }
                        }), (0, s.jsx)("div", {
                            className: E().seriesHubChartHome,
                            style: {
                                width: "".concat(u, "%"),
                                background: i
                            }
                        })]
                    })]
                })
            }
            var z = t(61765),
                D = t.n(z);

            function q(e) {
                var a = e.highSeedStats,
                    t = e.lowSeedStats,
                    i = (0, r.useContext)(n.Z).teams,
                    c = a.teamId,
                    o = a.teamPPG,
                    d = a.teamRPG,
                    l = a.teamAPG,
                    u = t.teamId,
                    m = t.teamPPG,
                    h = t.teamRPG,
                    S = t.teamAPG,
                    p = i.find((function(e) {
                        return e[0] === "".concat(c)
                    })) || [],
                    x = i.find((function(e) {
                        return e[0] === "".concat(u)
                    })) || [],
                    f = (0, O.Z)(["10", "1"], p, "#006bb6"),
                    _ = (0, O.Z)(["10", "1"], x, "#006bb6");
                return (0, s.jsxs)("div", {
                    className: D().seriesHubAverages,
                    children: [(0, s.jsx)("p", {
                        className: D().seriesAverages,
                        children: "Series Averages"
                    }), (0, s.jsx)(B, {
                        awayTeamColor: f,
                        homeTeamColor: _,
                        awayStat: o,
                        homeStat: m,
                        title: "PTS"
                    }), (0, s.jsx)(B, {
                        awayTeamColor: f,
                        homeTeamColor: _,
                        awayStat: d,
                        homeStat: h,
                        title: "REB"
                    }), (0, s.jsx)(B, {
                        awayTeamColor: f,
                        homeTeamColor: _,
                        awayStat: l,
                        homeStat: S,
                        title: "AST"
                    })]
                })
            }
            var W = t(11163),
                F = t(95385),
                Y = t(92826),
                V = t(27423),
                U = t.n(V);

            function K(e) {
                var a = e.teamCode,
                    t = e.pid,
                    r = e.fname,
                    n = e.lname,
                    i = e.jersey,
                    o = e.pos,
                    d = e.ppg,
                    l = e.rpg,
                    u = e.apg,
                    m = "".concat(r, " ").concat(n),
                    h = (0, Y.xA)(t, "");
                return (0, s.jsxs)("div", {
                    className: U().seriesHubLeader,
                    children: [(0, s.jsx)(x.Z, {
                        className: U().playerImage,
                        href: h,
                        children: (0, s.jsx)(F.Z, {
                            pid: t,
                            name: m
                        })
                    }), (0, s.jsxs)("div", {
                        className: U().playerDetails,
                        children: [(0, s.jsxs)("div", {
                            className: U().playerInfoRow,
                            children: [(0, s.jsx)("p", {
                                className: U().playerInfoText,
                                children: a
                            }), (0, s.jsx)("p", {
                                className: U().divider,
                                children: "|"
                            }), (0, s.jsx)("p", {
                                className: U().playerInfoText,
                                children: "#".concat(i)
                            }), (0, s.jsx)("p", {
                                className: U().divider,
                                children: "|"
                            }), (0, s.jsx)("p", {
                                className: U().playerInfoText,
                                children: o
                            })]
                        }), (0, s.jsx)("p", {
                            className: U().playerNameFull,
                            children: m
                        }), (0, s.jsxs)("div", {
                            className: U().statsContainer,
                            children: [(0, s.jsxs)("div", {
                                className: U().stats,
                                children: [(0, s.jsx)("p", {
                                    className: U().statNumber,
                                    children: (0, c.OK)(d, 1)
                                }), (0, s.jsx)("p", {
                                    className: U().statLabel,
                                    children: "PPG"
                                })]
                            }), (0, s.jsxs)("div", {
                                className: U().stats,
                                children: [(0, s.jsx)("p", {
                                    className: U().statNumber,
                                    children: (0, c.OK)(l, 1)
                                }), (0, s.jsx)("p", {
                                    className: U().statLabel,
                                    children: "RPG"
                                })]
                            }), (0, s.jsxs)("div", {
                                className: U().stats,
                                children: [(0, s.jsx)("p", {
                                    className: U().statNumber,
                                    children: (0, c.OK)(u, 1)
                                }), (0, s.jsx)("p", {
                                    className: U().statLabel,
                                    children: "APG"
                                })]
                            })]
                        })]
                    })]
                })
            }
            var X = t(15202),
                J = t.n(X);

            function Q(e) {
                var a = e.highSeedStats,
                    t = e.lowSeedStats,
                    i = e.forAnalytics,
                    c = void 0 === i ? {} : i,
                    o = (0, r.useContext)(n.Z).teams,
                    d = (0, W.useRouter)(),
                    l = a.teamId,
                    u = a.leaderPersonId,
                    m = a.leaderJerseyNum,
                    p = a.leaderPosition,
                    _ = a.leaderFirstName,
                    b = a.leaderLastName,
                    v = a.leaderPPG,
                    g = a.leaderRPG,
                    y = a.leaderAPG,
                    j = t.teamId,
                    T = t.leaderPersonId,
                    N = t.leaderJerseyNum,
                    H = t.leaderPosition,
                    M = t.leaderFirstName,
                    L = t.leaderLastName,
                    k = t.leaderPPG,
                    Z = t.leaderRPG,
                    C = t.leaderAPG,
                    R = o.find((function(e) {
                        return e[0] === "".concat(l)
                    })) || [],
                    w = o.find((function(e) {
                        return e[0] === "".concat(j)
                    })) || [];
                return (0, s.jsxs)("div", {
                    className: J().seriesHubLeaders,
                    children: [(0, s.jsxs)("div", {
                        className: J().title,
                        children: [(0, s.jsx)("p", {
                            className: J().seriesLeaderTitle,
                            children: "Series Leaders"
                        }), (0, s.jsxs)("div", {
                            className: J().moreStatsLink,
                            children: [(0, s.jsx)(x.Z, (0, S.Z)((0, h.Z)({
                                href: "".concat(d.asPath, "/stats"),
                                className: J().seriesLeaderLink,
                                "data-track": "click",
                                "data-type": "link",
                                "data-id": "nba:playoffs:series-hub:main:more-stats:link",
                                "data-text": "More Stats",
                                "data-section": "summary-module"
                            }, c), {
                                children: "More Stats"
                            })), (0, s.jsx)(f.Z, {
                                dir: "right"
                            })]
                        })]
                    }), (0, s.jsxs)("div", {
                        className: J().leaders,
                        children: [(0, s.jsx)(K, {
                            teamCode: R[1],
                            pid: u,
                            fname: _,
                            lname: b,
                            jersey: m,
                            pos: p,
                            ppg: v,
                            rpg: g,
                            apg: y
                        }), (0, s.jsx)(K, {
                            teamCode: w[1],
                            pid: T,
                            fname: M,
                            lname: L,
                            jersey: N,
                            pos: H,
                            ppg: k,
                            rpg: Z,
                            apg: C
                        })]
                    })]
                })
            }
            var $ = t(23855),
                ee = t(42298),
                ae = t(93967),
                te = t.n(ae),
                se = t(92888),
                re = t.n(se);

            function ne(e) {
                var a, t, l, u = e.seriesHubInfo,
                    m = e.gameId,
                    h = e.isGameDetails,
                    S = (0, r.useContext)(n.Z).teams,
                    p = (0, r.useContext)(i.N),
                    x = p.hideScores,
                    f = p.isHideScoresLoading || x,
                    b = u.season,
                    v = u.summary,
                    g = void 0 === v ? {} : v,
                    y = g.highSeedId,
                    j = g.highSeedRank,
                    T = g.highSeedTricode,
                    N = g.lowSeedId,
                    H = g.lowSeedRank,
                    M = g.lowSeedTricode,
                    L = g.roundNumber,
                    k = g.seriesConference,
                    Z = g.poRoundDesc,
                    C = g.seriesText,
                    R = void 0 === C ? "" : C,
                    w = g.games,
                    A = void 0 === w ? [] : w,
                    I = g.highSeedStats,
                    O = g.lowSeedStats,
                    G = [k, Z].filter(Boolean).join(" - "),
                    E = "4".concat(b, " ").concat(k, " ").concat(L, ": [").concat(j, "] ").concat(T, " vs [").concat(H, "] ").concat(M),
                    B = (0, r.useMemo)((function() {
                        return A.find((function(e) {
                            return e.gameStatus === _.Z.Upcoming
                        }))
                    }), [A]),
                    z = (0, r.useMemo)((function() {
                        if (!B) return "";
                        try {
                            var e = (0, $.Z)(B.gameEt.split("Z")[0]);
                            return "".concat((0, ee.Z)(e, "MMM d, h:mmaaa"), " ET")
                        } catch (a) {
                            return ""
                        }
                    }), [B]),
                    D = null === B || void 0 === B || null === (a = B.broadcasters) || void 0 === a || null === (t = a.nationalBroadcasters) || void 0 === t || null === (l = t[0]) || void 0 === l ? void 0 : l.broadcastDisplay,
                    W = B ? [B.seriesGameNumber, z].filter(Boolean).join(": ") : "",
                    F = S.find((function(e) {
                        return e[0] === "".concat(y)
                    })),
                    Y = S.find((function(e) {
                        return e[0] === "".concat(N)
                    }));
                if (!F || !Y) return null;
                var V = (0, c.rT)(m),
                    U = !(!V || !V.isPlayoffs),
                    K = U ? (0, o.Z)(V) : null,
                    X = !x && !U && I && O,
                    J = U ? "series" : "bracket",
                    ae = U ? K : "/playoffs/".concat(+b + 1, "/bracket");
                return (0, s.jsxs)("div", {
                    className: te()(re().summaryContainer, h && re().summaryContainerPadding),
                    children: [(0, s.jsxs)("div", {
                        className: re().seriesHubSummary,
                        children: [(0, s.jsx)("div", {
                            className: re().seriesHubStatus,
                            children: (0, s.jsx)(d.Z, {
                                awayTeamId: "".concat(y),
                                homeTeamId: "".concat(N),
                                awayTeamRank: j,
                                homeTeamRank: H,
                                awayTeamRecord: "".concat((null === g || void 0 === g ? void 0 : g.highSeedSeriesWins) || "0", "-").concat((null === g || void 0 === g ? void 0 : g.lowSeedSeriesWins) || "0"),
                                homeTeamRecord: "".concat((null === g || void 0 === g ? void 0 : g.lowSeedSeriesWins) || "0", "-").concat((null === g || void 0 === g ? void 0 : g.highSeedSeriesWins) || "0"),
                                conferenceText: G,
                                seriesText: R,
                                upcomingGameText: W,
                                broadcasterText: D,
                                actionLink: ae,
                                linkTo: J,
                                seriesTitle: E,
                                hideScores: f
                            })
                        }), (0, s.jsx)("div", {
                            className: re().seriesHubMatchups,
                            children: (0, s.jsx)(P, {
                                games: A,
                                hideScores: f
                            })
                        })]
                    }), X && (0, s.jsxs)("div", {
                        className: re().seriesHubSummary,
                        children: [(0, s.jsx)("div", {
                            className: re().seriesHubAverages,
                            children: (0, s.jsx)(q, {
                                highSeedStats: I,
                                lowSeedStats: O
                            })
                        }), (0, s.jsx)("div", {
                            className: re().seriesHubLeaders,
                            children: (0, s.jsx)(Q, {
                                highSeedStats: I,
                                lowSeedStats: O,
                                forAnalytics: {
                                    "data-content": E
                                }
                            })
                        })]
                    })]
                })
            }
        },
        2129: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return s.ZP
                }
            });
            var s = t(43002)
        },
        25066: function(e, a) {
            "use strict";
            a.Z = {
                markings: [{
                    d: "M470,0v140",
                    style: "stroke-linecap:round"
                }, {
                    d: "M30,0v140",
                    style: "stroke-linecap:round"
                }, {
                    d: "M330,0v190",
                    style: "stroke-linecap:round"
                }, {
                    d: "M170,0v190",
                    style: "stroke-linecap:round"
                }, {
                    d: "M310,0v190",
                    style: "stroke-linecap:round"
                }, {
                    d: "M190,0v190",
                    style: "stroke-linecap:round"
                }, {
                    d: "M330,190H170",
                    style: "stroke-linecap:round"
                }, {
                    d: "M280,40h-60",
                    style: "stroke-linecap:round"
                }, {
                    d: "M250,40v2.5",
                    style: "stroke-linecap:round"
                }, {
                    d: "M290,40v10",
                    style: "stroke-linecap:round"
                }, {
                    d: "M210,40v10",
                    style: "stroke-linecap:round"
                }, {
                    d: "M250,42.5c4.1,0,7.5,3.4,7.5,7.5s-3.4,7.5-7.5,7.5s-7.5-3.4-7.5-7.5S245.9,42.5,250,42.5z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M0,0v470h190c0-33.1,26.9-60,60-60s60,26.9,60,60h190V0H0z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M250,410c-33.1,0-60,26.9-60,60h40c0-11,9-20,20-20s20,9,20,20h40C310,436.9,283.1,410,250,410z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M250,450c-11,0-20,9-20,20h40C270,459,261,450,250,450z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M310,190c0,33.1-26.9,60-60,60s-60-26.9-60-60c0,33.1,26.9,60,60,60S310,223.1,310,190z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M310,190c0-33.1-26.9-60-60-60s-60,26.9-60,60c0-33.1,26.9-60,60-60S310,156.9,310,190z",
                    style: "stroke-dasharray:5,10"
                }, {
                    d: "M290,50c0,22.1-17.9,40-40,40s-40-17.9-40-40c0,22.1,17.9,40,40,40S290,72.1,290,50z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M469.8,139.9c-49.7,121.4-188.3,179.6-309.7,129.9c-59-24.1-105.8-70.9-129.9-129.9 c49.7,121.4,188.3,179.6,309.7,129.9C398.9,245.7,445.7,198.9,469.8,139.9z",
                    style: "stroke-linecap:round"
                }, {
                    d: "M140,0v5",
                    style: "stroke-linecap:round"
                }, {
                    d: "M359.9,0v5",
                    style: "stroke-linecap:round"
                }, {
                    d: "M470,281.6h30",
                    style: "stroke-linecap:round"
                }, {
                    d: "M0,286.7h30",
                    style: "stroke-linecap:round"
                }, {
                    d: "M170,69.8h-10",
                    style: ""
                }, {
                    d: "M170,79.9h-10",
                    style: ""
                }, {
                    d: "M170,109.9h-10",
                    style: ""
                }, {
                    d: "M170,140h-10",
                    style: ""
                }, {
                    d: "M340,69.8h-10",
                    style: ""
                }, {
                    d: "M340,79.9h-10",
                    style: ""
                }, {
                    d: "M340,109.9h-10",
                    style: ""
                }, {
                    d: "M0,140h30"
                }, {
                    d: "M470,139.9h30"
                }],
                zones: [{
                    zone: "Mid-Range",
                    d: "M30,140c32.8,82.8,119.6,148.5,219.8,147.7h0.4c100.2,0.8,187-64.8,219.8-147.7v-0.1v0V0H330v139.9v0V190H170v-50v0V0H30V140L30,140z"
                }, {
                    zone: "In The Paint (Non-RA)",
                    d: "M170,140v50h160v-50.1v0V0H170V140L170,140z M210,40h80v10c0,22.1-17.9,40-40,40s-40-17.9-40-40V40z"
                }, {
                    zone: "Restricted Area",
                    d: "M250,90c22.1,0,40-17.9,40-40V40h-80v10C210,72.1,227.9,90,250,90z"
                }, {
                    zone: "Above the Break 3",
                    d: "M250.2,287.7h-0.4C149.6,288.5,62.8,222.8,30,140H0v330h500V140h-30 C437.2,222.8,350.4,288.5,250.2,287.7z"
                }, {
                    zone: "Right Corner 3",
                    d: "M470,0L470 140 470 140 470 140 500 140 500 140 500 0z"
                }, {
                    zone: "Left Corner 3",
                    d: "M30,140L30 0 0 0 0 140 30 140z"
                }],
                advancedMarkings: [{
                    d: "M220,4A96,96,0,1,0,380,4"
                }, {
                    d: "M117,0A192,192,0,1,0,483,0"
                }, {
                    d: "M250,140L203,224"
                }, {
                    d: "M350,140L394,224"
                }, {
                    d: "M147,173L68,226"
                }, {
                    d: "M241,240L214,333"
                }, {
                    d: "M359,240L386,333"
                }, {
                    d: "M453,173L532,226"
                }, {
                    d: "M210,332L150,564"
                }, {
                    d: "M390,332L450,564"
                }],
                advancedZones: [{
                    zone: "Left Side(L) | 8-16 ft.",
                    d: "M117,0H220A96,96,0,0,0,250,140L203,224A192,192,0,0,1,117,0Z"
                }, {
                    zone: "Left Side(L) | 16-24 ft.",
                    d: "M36,0V168A285,285,0,0,0,68,226L147,173A192,192,0,0,1,117,0Z"
                }, {
                    zone: "Left Side(L) | 24+ ft.",
                    d: "M0,0H36V168H0Z"
                }, {
                    zone: "Left Side Center(LC) | 16-24 ft.",
                    d: "M147,173A192,192,0,0,0,241,240L214,333A285,285,0,0,1,68,226Z"
                }, {
                    zone: "Left Side Center(LC) | 24+ ft.",
                    d: "M0,168H36A285,285,0,0,0,210,332L150,564H0Z"
                }, {
                    zone: "Center(C) | Less Than 8 ft.",
                    d: "M220,3A96,96,0,1,0,380,3Z"
                }, {
                    zone: "Center(C) | 8-16 ft.",
                    d: "M250,140A96,96,0,0,0,350,140L394,224A192,192,0,0,1,203,224Z"
                }, {
                    zone: "Center(C) | 16-24 ft.",
                    d: "M241,240A192,192,0,0,0,359,240L386,333A285,285,0,0,1,214,333Z"
                }, {
                    zone: "Center(C) | 24+ ft.",
                    d: "M210,332A285,285,0,0,0,390,332L450,564H150Z"
                }, {
                    zone: "Right Side Center(RC) | 16-24 ft.",
                    d: "M359,240A192,192,0,0,0,453,173L532,226A285,285,0,0,1,386,333Z"
                }, {
                    zone: "Right Side Center(RC) | 24+ ft.",
                    d: "M564,168A285,285,0,0,1,390,332L450,564H600V168Z"
                }, {
                    zone: "Right Side(R) | 8-16 ft.",
                    d: "M483,0H380A96,96,0,0,1,350,140L397,224A192,192,0,0,0,483,0Z"
                }, {
                    zone: "Right Side(R) | 16-24 ft.",
                    d: "M564,0V168A285,285,0,0,1,532,226L453,173A192,192,0,0,0,483,0Z"
                }, {
                    zone: "Right Side(R) | 24+ ft.",
                    d: "M564,0H600V168H564Z"
                }, {
                    zone: "Back Court(BC) | Back Court Shot",
                    d: "M0,0"
                }],
                icons: {
                    made: {
                        d: "M -5, 0 a 5,5 0 1,0 10,0 a 5,5 0 1,0 -10,0",
                        fill: "rgba(255,255,255, 0.1)",
                        stroke: "rgba(56, 100, 251, 0.9)",
                        "stroke-width": 2
                    },
                    missed: {
                        d: "M -5,-5 L 5,5 M 5,-5 L -5,5",
                        fill: "rgba(255,255,255, 0.1)",
                        stroke: "rgba(187, 0, 0, 0.8)",
                        "stroke-width": 2
                    }
                }
            }
        },
        83030: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return n
                }
            });
            var s = t(91567),
                r = t(67294);

            function n() {
                var e = (0, r.useContext)(s.N),
                    a = e.hideScores,
                    t = e.isHideScoresLoading,
                    n = (0, r.useState)(void 0),
                    i = n[0],
                    c = n[1],
                    o = void 0 === i,
                    d = o || !0 === i;
                return (0, r.useEffect)((function() {
                    t || c(a)
                }), [t, a]), [o, d, c]
            }
        },
        71678: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return i
                }
            });
            var s = t(23855),
                r = t(61436),
                n = t(42298);

            function i(e, a) {
                if (!e || 0 === e.length || "TBD" === e || "0001" === e.slice(0, 4)) return "TBD";
                var t = e.slice(0, 10),
                    i = (0, s.Z)(t);
                return (0, r.Z)(i) ? a ? (0, n.Z)(i, a) : t : "TBD"
            }
        },
        7220: function(e, a, t) {
            "use strict";

            function s(e, a) {
                var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "#ec003d",
                    s = e.find((function(e) {
                        return +e[0] === +a
                    }));
                return s ? s[10][0] : t
            }
            t.d(a, {
                Z: function() {
                    return s
                }
            })
        },
        97519: function(e, a, t) {
            "use strict";
            t.d(a, {
                B: function() {
                    return s
                },
                Z: function() {
                    return r
                }
            });
            var s = function(e, a) {
                var t = 0,
                    s = Math.min(e, 4),
                    r = Math.max(e - 4, 0);
                if (a.trim()) {
                    var n = a.replace("PT", "").split("M"),
                        i = parseInt(n[0], 10),
                        c = parseFloat(n[1], 10);
                    e <= 4 ? t = 7200 * (e - 1) + (7200 - (600 * i + 10 * c)) : (t = 3e3 * (r - 1) + (3e3 - (600 * i + 10 * c)), t += 28800)
                } else t = 7200 * s + 3e3 * r;
                return t
            };

            function r(e) {
                if (!e) return "00:00";
                var a = (e = e.trim()).match(/(\d+)M/),
                    t = a && a.length ? +a[1] : 0,
                    s = e.match(/([\d\.]+)S/),
                    r = (s && s.length ? +s[1] : 0).toFixed(0).padStart(2, "0");
                return "".concat(t.toString().padStart(2, "0"), ":").concat(r)
            }
        },
        82266: function(e, a, t) {
            "use strict";
            t.d(a, {
                Z: function() {
                    return l
                }
            });
            var s = t(26042),
                r = t(77226),
                n = t(97519),
                i = (0, r.zy)([0, 100], [25, -25], !1),
                c = (0, r.zy)([0, 50], [-5, 42], !0),
                o = (0, r.zy)([-250, 250], [-25, 25], !0),
                d = (0, r.zy)([-50, 420], [-5, 42], !0);

            function l(e, a) {
                switch (e) {
                    case "hana":
                        return function(e) {
                            return e.map((function(e) {
                                var a, t = (0, s.Z)({}, e);
                                t.data = {
                                    eid: e.GAME_EVENT_ID,
                                    x: o(e.LOC_X),
                                    y: d(e.LOC_Y),
                                    p: (0, r.Z3)(e.PERIOD),
                                    cl: "".concat(e.MINUTES_REMAINING, ":").concat(e.SECONDS_REMAINING),
                                    made: 1 === +e.SHOT_MADE_FLAG,
                                    type: /3/i.test(e.SHOT_TYPE) ? 3 : 2
                                };
                                var n = (null === (a = e.PLAYER_NAME) || void 0 === a ? void 0 : a.split(" ")) || ["", ""],
                                    i = n.slice(1).join(" "),
                                    c = "".concat(i, ", ").concat(n[0]);
                                return t.data.desc = "".concat(c, " - ").concat(t.data.p, " ").concat(t.data.cl), t
                            }))
                        }(a);
                    case "hanaV3":
                        return function(e) {
                            return e.map((function(e) {
                                var a = (0, s.Z)({}, e);
                                return a.data = {
                                    eid: e.actionNumber,
                                    x: o(e.xLegacy),
                                    y: d(e.yLegacy),
                                    p: (0, r.Z3)(e.period),
                                    cl: (0, n.Z)(e.clock),
                                    made: /made/i.test(e.shotResult),
                                    type: /3pt/i.test(e.description) ? 3 : 2
                                }, a.data.desc = "".concat(e.description, "\n").concat(a.data.p, " - ").concat(a.data.cl), a
                            }))
                        }(a);
                    case "ngss":
                        return function(e) {
                            return e.map((function(e) {
                                var a = (0, s.Z)({}, e);
                                return a.data = {
                                    eid: e.actionNumber,
                                    x: "left" === e.side ? i(e.y) : i(100 - e.y),
                                    y: "left" === e.side ? c(e.x) : c(100 - e.x),
                                    p: (0, r.Z3)(e.period),
                                    cl: (0, n.Z)(e.clock),
                                    made: /made/i.test(e.shotResult),
                                    type: /3/i.test(e.actionType) ? 3 : 2
                                }, a.data.desc = "".concat(e.description, "\n").concat(a.data.p, " - ").concat(a.data.cl), a
                            }))
                        }(a);
                    case "mobile":
                        return function(e) {
                            return e.map((function(e) {
                                return (0, s.Z)({}, e)
                            }))
                        }(a);
                    case "homepage":
                        return function(e) {
                            return e.map((function(e) {
                                var a = (0, s.Z)({}, e);
                                a.data = {
                                    eid: e.GAME_EVENT_ID,
                                    x: o(e.LOC_X),
                                    y: d(e.LOC_Y),
                                    p: (0, r.Z3)(e.PERIOD),
                                    cl: "".concat(e.MINUTES_REMAINING, ":").concat(e.SECONDS_REMAINING),
                                    made: 1 === +e.SHOT_MADE_FLAG,
                                    type: /3/i.test(e.SHOT_TYPE) ? 3 : 2
                                };
                                var t = "[".concat(e.TEAM_NAME, "] ").concat(e.PLAYER_FIRST_NAME, " ").concat(e.PLAYER_LAST_NAME, "\n"),
                                    n = "".concat(e.ACTION_TYPE, ":").concat(a.data.made ? "Made" : "Missed", "\n"),
                                    i = "".concat(a.data.p, " - ").concat(a.data.cl, "\n");
                                return a.data.desc = "".concat(t).concat(n).concat(i), a
                            }))
                        }(a);
                    case "btb":
                        return function(e) {
                            return e && e.length ? e.map((function(e) {
                                if (!e) return null;
                                var a = (0, s.Z)({}, e);
                                return a.data = {
                                    eid: e.eventNum,
                                    x: o(e.locX),
                                    y: d(e.locY),
                                    p: (0, r.Z3)(e.period),
                                    cl: e.gameClock,
                                    made: 1 === +e.success,
                                    type: /3/i.test(e.shotType) ? 3 : 2
                                }, a.data.desc = "".concat(a.data.p, " ").concat(a.data.cl), a
                            })).filter(Boolean) : []
                        }(a);
                    default:
                        return []
                }
            }
        },
        33350: function(e) {
            e.exports = {
                chart: "MatchupBarChart_chart__AWZPP"
            }
        },
        35645: function(e) {
            e.exports = {
                chart: "MatchupRoseChart_chart__hKT5C"
            }
        },
        28876: function(e) {
            e.exports = {
                saveSvgButton: "SaveSvgButton_saveSvgButton__vqekw",
                saveSvgButtonText: "SaveSvgButton_saveSvgButtonText__ynZeR"
            }
        },
        81291: function(e) {
            e.exports = {
                hideScores: "HideScoresModeNotice_hideScores__1z32y",
                hideScoresLabel: "HideScoresModeNotice_hideScoresLabel__3sPrx",
                hideScoresSmall: "HideScoresModeNotice_hideScoresSmall__e9rMM",
                hideScoresButton: "HideScoresModeNotice_hideScoresButton__tZtUT"
            }
        },
        71352: function(e) {
            e.exports = {
                inputCheckbox: "Checkbox_inputCheckbox__xUe8Q",
                checkbox: "Checkbox_checkbox__9_afI",
                iconWrapper: "Checkbox_iconWrapper__2k_0O",
                icon: "Checkbox_icon__lFy9h",
                allstarIcon: "Checkbox_allstarIcon__w5Imc"
            }
        },
        61765: function(e) {
            e.exports = {
                seriesHubAverages: "SeriesHubAverages_seriesHubAverages__EkoB2",
                seriesAverages: "SeriesHubAverages_seriesAverages__QvG9O"
            }
        },
        86075: function(e) {
            e.exports = {
                broadcast: "SeriesHubBroadcast_broadcast__hySdL",
                tunein: "SeriesHubBroadcast_tunein__CB_pN",
                broadcastLink: "SeriesHubBroadcast_broadcastLink__dVJ_C",
                mobileGameLinkIndicator: "SeriesHubBroadcast_mobileGameLinkIndicator__Ra0yA"
            }
        },
        16209: function(e) {
            e.exports = {
                gameStartInfo: "SeriesHubGameStatus_gameStartInfo__lcgHp",
                gameTime: "SeriesHubGameStatus_gameTime__KCpwW",
                gameDate: "SeriesHubGameStatus_gameDate__GU9SR",
                score: "SeriesHubGameStatus_score__7VP2T",
                gameOutcomeContainer: "SeriesHubGameStatus_gameOutcomeContainer__ZEFtD",
                gameOutcomeText: "SeriesHubGameStatus_gameOutcomeText__kATD_",
                gameStatusText: "SeriesHubGameStatus_gameStatusText__5gBXc",
                winnerIndicatorRight: "SeriesHubGameStatus_winnerIndicatorRight__glRI_",
                winnerIndicatorLeft: "SeriesHubGameStatus_winnerIndicatorLeft__YMMwn"
            }
        },
        15202: function(e) {
            e.exports = {
                seriesHubLeaders: "SeriesHubLeaders_seriesHubLeaders__P1KEg",
                leaders: "SeriesHubLeaders_leaders__5P5Kf",
                title: "SeriesHubLeaders_title__a96DZ",
                moreStatsLink: "SeriesHubLeaders_moreStatsLink__0eWw0",
                moreStatsLinkWrapper: "SeriesHubLeaders_moreStatsLinkWrapper__A5yMP",
                seriesLeaderTitle: "SeriesHubLeaders_seriesLeaderTitle__uvch8",
                seriesLeaderLink: "SeriesHubLeaders_seriesLeaderLink__g2v6j"
            }
        },
        30960: function(e) {
            e.exports = {
                seriesHubStats: "SeriesHubMatchupStat_seriesHubStats__bvKl_",
                seriesHubStatHome: "SeriesHubMatchupStat_seriesHubStatHome__6J_dp",
                seriesHubStatAway: "SeriesHubMatchupStat_seriesHubStatAway__lhN4l",
                seriesHubChart: "SeriesHubMatchupStat_seriesHubChart__lrFlJ",
                seriesHubChartAway: "SeriesHubMatchupStat_seriesHubChartAway__o9pBj",
                seriesHubChartHome: "SeriesHubMatchupStat_seriesHubChartHome___fqOA",
                seriesHubStatsCategory: "SeriesHubMatchupStat_seriesHubStatsCategory__BGNcq"
            }
        },
        68897: function(e) {
            e.exports = {
                summary: "SeriesHubMatchupStatus_summary__033x5",
                gameStatusContainer: "SeriesHubMatchupStatus_gameStatusContainer__OHg2E",
                gameStatus: "SeriesHubMatchupStatus_gameStatus__v_85a",
                mobileBroadcaster: "SeriesHubMatchupStatus_mobileBroadcaster__baG2i",
                teamLogo: "SeriesHubMatchupStatus_teamLogo__8eOLQ"
            }
        },
        12446: function(e) {
            e.exports = {
                seriesMatchup: "SeriesHubMatchups_seriesMatchup__CfB7M",
                gameInfo: "SeriesHubMatchups_gameInfo__uJyDp",
                seriesRecordStatus: "SeriesHubMatchups_seriesRecordStatus__sy2TL",
                seriesGameNumber: "SeriesHubMatchups_seriesGameNumber__EEluM"
            }
        },
        27423: function(e) {
            e.exports = {
                seriesHubLeader: "SeriesHubPlayer_seriesHubLeader__kRdSa",
                playerImage: "SeriesHubPlayer_playerImage__bOme4",
                playerDetails: "SeriesHubPlayer_playerDetails__O_fxy",
                statsContainer: "SeriesHubPlayer_statsContainer__2Ssdi",
                stats: "SeriesHubPlayer_stats__SGeU8",
                playerInfoRow: "SeriesHubPlayer_playerInfoRow__iSsL_",
                playerInfoText: "SeriesHubPlayer_playerInfoText__M_Ige",
                divider: "SeriesHubPlayer_divider__3jle_",
                statLabel: "SeriesHubPlayer_statLabel__YB0PP",
                statNumber: "SeriesHubPlayer_statNumber__hBfmu",
                playerNameFull: "SeriesHubPlayer_playerNameFull__cZzsl"
            }
        },
        84938: function(e) {
            e.exports = {
                container: "SeriesHubStatus_container__sCoaD",
                seriesTheme: "SeriesHubStatus_seriesTheme__49It4",
                seriesThemeTeams: "SeriesHubStatus_seriesThemeTeams__DTCwi",
                awaySeriesTheme: "SeriesHubStatus_awaySeriesTheme__ufof6",
                homeSeriesTheme: "SeriesHubStatus_homeSeriesTheme__yWkWy",
                seriesThemeShadow: "SeriesHubStatus_seriesThemeShadow__O5e4b",
                seriesHubStatusContainer: "SeriesHubStatus_seriesHubStatusContainer__CJMe0",
                seriesHubStatus: "SeriesHubStatus_seriesHubStatus__DD0Qj",
                mobileSeriesText: "SeriesHubStatus_mobileSeriesText__4MvJ2",
                mobileSeriesTextUppercase: "SeriesHubStatus_mobileSeriesTextUppercase__0brCU",
                seriesHubStatusContent: "SeriesHubStatus_seriesHubStatusContent__UsXX5",
                team: "SeriesHubStatus_team__UqpOh",
                teamLogo: "SeriesHubStatus_teamLogo__yBG4Y",
                teamLogoPlaceholder: "SeriesHubStatus_teamLogoPlaceholder__FZwYH",
                teamRankWrapper: "SeriesHubStatus_teamRankWrapper__b_RMD",
                teamRank: "SeriesHubStatus_teamRank__XYjfv",
                teamName: "SeriesHubStatus_teamName__52mC8",
                series: "SeriesHubStatus_series__HEatO",
                seriesText: "SeriesHubStatus_seriesText__BKl9l",
                actionLink: "SeriesHubStatus_actionLink___0_9z",
                confText: "SeriesHubStatus_confText__RclFS",
                teamRecord: "SeriesHubStatus_teamRecord__I5i97",
                upcomingGameText: "SeriesHubStatus_upcomingGameText__aourL"
            }
        },
        92888: function(e) {
            e.exports = {
                summaryContainer: "SeriesHubSummary_summaryContainer__xz6I8",
                summaryContainerPadding: "SeriesHubSummary_summaryContainerPadding__OaLZT",
                seriesHubSummary: "SeriesHubSummary_seriesHubSummary__67omZ",
                seriesHubStatus: "SeriesHubSummary_seriesHubStatus__dhQG9",
                seriesHubMatchups: "SeriesHubSummary_seriesHubMatchups__K7Kea",
                seriesHubAverages: "SeriesHubSummary_seriesHubAverages__hWNwv",
                seriesHubLeaders: "SeriesHubSummary_seriesHubLeaders__P1j9t"
            }
        }
    }
]);