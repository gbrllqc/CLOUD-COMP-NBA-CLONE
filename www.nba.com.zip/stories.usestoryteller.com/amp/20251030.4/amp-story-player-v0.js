;
! function() {
    function t(t, i, n) {
        return i in t ? Object.defineProperty(t, i, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[i] = n, t
    }
    var i = Array.isArray;

    function n(t, i) {
        for (var n = [], r = 0, e = 0; e < t.length; e++) {
            var s = t[e];
            i(s, e, t) ? n.push(s) : (r < e && (t[r] = s), r++)
        }
        return r < t.length && (t.length = r), n
    }

    function r(t, i) {
        for (var n = 0; n < t.length; n++)
            if (i(t[n], n, t)) return n;
        return -1
    }

    function e(t) {
        return "string" == typeof t
    }

    function s(t, i) {
        (null == i || i > t.length) && (i = t.length);
        for (var n = 0, r = new Array(i); n < i; n++) r[n] = t[n];
        return r
    }

    function o(t, i) {
        var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
        if (n) return (n = n.call(t)).next.bind(n);
        if (Array.isArray(t) || (n = function(t, i) {
                if (t) {
                    if ("string" == typeof t) return s(t, i);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? s(t, i) : void 0
                }
            }(t)) || i && t && "number" == typeof t.length) {
            n && (t = n);
            var r = 0;
            return function() {
                return r >= t.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: t[r++]
                }
            }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }

    function a(t) {
        return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }
    var h = Object.prototype;

    function u(t) {
        var i = Object.create(null);
        return t && Object.assign(i, t), i
    }

    function f(t) {
        return 1 == (null == t ? void 0 : t.nodeType)
    }
    h.hasOwnProperty, h.toString;
    var c = "​​​";

    function l(t) {
        return f(t) ? t.tagName.toLowerCase() + (t.id ? "#".concat(t.id) : "") : t
    }

    function p(t, i) {
        var r, e, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "Assertion failed";
        if (i) return i;
        t && -1 == s.indexOf(t) && (s += t);
        for (var o = 3, a = s.split("%s"), h = a.shift(), u = [h]; a.length;) {
            var f = arguments[o++],
                c = a.shift();
            h += l(f) + c, u.push(f, c.trim())
        }
        var p = new Error(h);
        throw p.messageArray = n(u, (function(t) {
            return "" !== t
        })), null === (r = (e = self).__AMP_REPORT_ERROR) || void 0 === r || r.call(e, p), p
    }

    function v(t, n, r, e, s) {
        return i(s) ? t(r, s.concat([n])) : t(r, "".concat(s || e, ": %s"), n), n
    }

    function m(t) {
        var i = Object.getOwnPropertyDescriptor(t, "message");
        if (null != i && i.writable) return t;
        var n = t.message,
            r = t.stack,
            e = new Error(n);
        for (var s in t) e[s] = t[s];
        return e.stack = r, e
    }

    function d(t) {
        for (var i, n = null, r = "", e = o(arguments, !0); !(i = e()).done;) {
            var s = i.value;
            s instanceof Error && !n ? n = m(s) : (r && (r += " "), r += s)
        }
        return n ? r && (n.message = r + ": " + n.message) : n = new Error(r), n
    }

    function y(t) {
        var i = d.apply(null, arguments);
        return i.expected = !0, i
    }

    function g(t) {
        var i = !1,
            n = null,
            r = t;
        return function() {
            if (!i) {
                for (var t = arguments.length, e = new Array(t), s = 0; s < t; s++) e[s] = arguments[s];
                n = r.apply(self, e), i = !0, r = null
            }
            return n
        }
    }

    function b(t, i, n) {
        var r = 0,
            e = null;

        function s(s) {
            e = null, r = t.setTimeout(o, n), i.apply(null, s)
        }

        function o() {
            r = 0, e && s(e)
        }
        return function() {
            for (var t = arguments.length, i = new Array(t), n = 0; n < t; n++) i[n] = arguments[n];
            r ? e = i : s(i)
        }
    }
    var w = /(?:^[#?]?|&)([^=&]+)(?:=([^&]*))?/g;

    function x(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        try {
            return decodeURIComponent(t)
        } catch (t) {
            return i
        }
    }

    function A(t) {
        var i, n = u();
        if (!t) return n;
        for (; i = w.exec(t);) {
            var r = x(i[1], i[1]),
                e = i[2] ? x(i[2].replace(/\+/g, " "), i[2]) : "";
            n[r] = e
        }
        return n
    }

    function S(t) {
        var i = (t || self).location;
        return A(i.originalHash || i.hash)
    }
    var k = function(t) {
            return self.AMP_CONFIG ? self.AMP_CONFIG[t] : null
        },
        P = ("string" == typeof k("cdnProxyRegex") ? new RegExp(k("cdnProxyRegex")) : k("cdnProxyRegex")) || /^https:\/\/([a-zA-Z0-9_-]+\.)?cdn\.ampproject\.org$/;

    function I(t) {
        if (!self.document || !self.document.head) return null;
        if (self.location && P.test(self.location.origin)) return null;
        var i = self.document.head.querySelector('meta[name="'.concat(t, '"]'));
        return i && i.getAttribute("content") || null
    }
    var E = k("cdnUrl") || I("runtime-host") || "https://cdn.ampproject.org",
        j = "";

    function R(t) {
        var i = t || self;
        return i.__AMP_MODE ? i.__AMP_MODE : i.__AMP_MODE = function(t) {
            return {
                localDev: !1,
                development: M(t, S(t)),
                esm: !1,
                test: !1,
                rtvVersion: C(t),
                ssrReady: !1
            }
        }(i)
    }

    function C(t) {
        var i;
        return j || (j = (null === (i = t.AMP_CONFIG) || void 0 === i ? void 0 : i.v) || "01".concat("2510301759000")), j
    }

    function M(t, i) {
        var n = i || S(t);
        return ["1", "actions", "amp", "amp4ads", "amp4email"].includes(n.development) || !!t.AMP_DEV_MODE
    }
    var O = function() {},
        T = function() {
            return "01".concat("2510301759000")
        },
        U = function(t, i) {
            return i.reduce((function(t, i) {
                return "".concat(t, "&s[]=").concat(D(i))
            }), "https://log.amp.dev/?v=".concat(T(), "&id=").concat(encodeURIComponent(t)))
        },
        z = function() {
            return "".concat(E, "/rtv/").concat(T(), "/log-messages.simple.json")
        },
        D = function(t) {
            return encodeURIComponent(String(l(t)))
        },
        N = function(t) {
            return parseInt(S(t).log, 10)
        },
        q = function() {
            function n(t, i) {
                var n = this,
                    r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                this.win = t, this.tt = i, this.nt = this.rt(), this.it = r, this.et = null, this.ft = g((function() {
                    t.fetch(z()).then((function(t) {
                        return t.json()
                    }), O).then((function(t) {
                        t && (n.et = t)
                    }))
                })), this.ot = this.assert.bind(this)
            }
            var r = n.prototype;
            return r.rt = function() {
                var t, i = this.win;
                return null !== (t = i.console) && void 0 !== t && t.log && 0 != N(i) ? this.ut() : 0
            }, r.ut = function(t) {
                return this.tt(N(t), R().development)
            }, r.st = function(i, n, r) {
                var s, o;
                if (n > this.nt) return !1;
                var a = this.win.console,
                    h = null !== (s = (o = {}, t(o, 1, a.error), t(o, 3, a.info), t(o, 2, a.warn), o)[n]) && void 0 !== s ? s : a.log,
                    u = this.ct(r),
                    f = "[".concat(i, "]");
                return e(u[0]) ? u[0] = f + " " + u[0] : u.unshift(f), h.apply(a, u), !0
            }, r.fine = function(t) {
                for (var i = arguments.length, n = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) n[r - 1] = arguments[r];
                this.st(t, 4, n)
            }, r.info = function(t) {
                for (var i = arguments.length, n = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) n[r - 1] = arguments[r];
                this.st(t, 3, n)
            }, r.warn = function(t) {
                for (var i = arguments.length, n = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) n[r - 1] = arguments[r];
                this.st(t, 2, n)
            }, r.error = function(t) {
                for (var i = arguments.length, n = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) n[r - 1] = arguments[r];
                if (!this.st(t, 1, n)) {
                    var e, s, o = this.createError.apply(this, n);
                    o.name = t || o.name, null === (e = (s = self).__AMP_REPORT_ERROR) || void 0 === e || e.call(s, o)
                }
            }, r.expectedError = function(t) {
                for (var i = arguments.length, n = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) n[r - 1] = arguments[r];
                var e, s;
                this.st(t, 1, n) || null === (e = (s = self).__AMP_REPORT_ERROR) || void 0 === e || e.call(s, this.createExpectedError.apply(this, n))
            }, r.createError = function(t) {
                return this.ht(d.apply(null, arguments))
            }, r.createExpectedError = function(t) {
                return this.ht(y.apply(null, arguments))
            }, r.ht = function(t) {
                return t = m(t), this.it ? t.message ? -1 == t.message.indexOf(this.it) && (t.message += this.it) : t.message = this.it : t.message.indexOf(c) >= 0 && (t.message = t.message.replace(c, "")), t
            }, r.ct = function(t) {
                return i(t[0]) ? this.lt(t[0]) : t
            }, r.lt = function(t) {
                var i, n = t.shift();
                return R(this.win).development && this.ft(), null !== (i = this.et) && void 0 !== i && i[n] ? [this.et[n]].concat(t) : ["More info at ".concat(U(n, t))]
            }, r.assert = function(t, n, r) {
                return i(n) ? this.assert.apply(this, [t].concat(this.lt(n))) : p.apply(null, [this.it].concat(Array.prototype.slice.call(arguments)))
            }, r.assertElement = function(t, i) {
                return function(t, i, n) {
                    return v(t, i, f(i), "Element expected", n)
                }(this.ot, t, i)
            }, r.assertString = function(t, i) {
                return function(t, i, n) {
                    return v(t, i, e(i), "String expected", n)
                }(this.ot, t, i)
            }, r.assertNumber = function(t, i) {
                return function(t, i, n) {
                    return v(t, i, "number" == typeof i, "Number expected", n)
                }(this.ot, t, i)
            }, r.assertArray = function(t, n) {
                return function(t, n, r) {
                    return v(t, n, i(n), "Array expected", r)
                }(this.ot, t, n)
            }, r.assertBoolean = function(t, i) {
                return function(t, i, n) {
                    return v(t, i, !!i === i, "Boolean expected", n)
                }(this.ot, t, i)
            }, n
        }();
    self.__AMP_LOG = self.__AMP_LOG || {
        user: null,
        dev: null,
        userForEmbed: null
    };
    var L = self.__AMP_LOG,
        _ = null;

    function F() {
        _ = q, B(),
            function(t) {
                if (L.user || (L.user = H(c)), void L.user.win) return L.userForEmbed || (L.userForEmbed = H("​​​​"));
                L.user
            }()
    }

    function Y(t, i) {
        if (!_) throw new Error("failed to call initLogConstructor");
        return new _(self, t, i)
    }

    function H(t) {
        return Y((function(t, i) {
            return i || t >= 1 ? 4 : 2
        }), t)
    }

    function B() {
        return L.dev || (L.dev = Y((function(t) {
            return t >= 3 ? 4 : t >= 2 ? 3 : 0
        })))
    }
    var V, $ = function() {
        function t(t, i) {
            this.t = t, this.el = i, this.Xc = this.t.document, this.tp = !1, this.ip = !1, this.np = null
        }
        var i = t.prototype;
        return i.buildCallback = function() {
            this.tp || (this.rp(), this.tp = !0)
        }, i.layoutCallback = function() {
            this.ip || (this.ip = !0)
        }, i.rp = function() {
            this.np = this.Xc.createElement("main");
            var t = this.el.attachShadow({
                    mode: "open"
                }),
                i = this.Xc.createElement("style");
            i.textContent = "amp-story-entry-point{position:relative;display:block}\n/*# sourceURL=/css/amp-story-entry-point.css*/", t.appendChild(i), t.appendChild(this.np)
        }, i.getElement = function() {
            return this.el
        }, t
    }();

    function X() {
        return V || (V = Promise.resolve(void 0))
    }
    var Z = function() {
        var t = this;
        this.promise = new Promise((function(i, n) {
            t.resolve = i, t.reject = n
        }))
    };

    function J(t, i) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var r = Object.getOwnPropertySymbols(t);
            i && (r = r.filter((function(i) {
                return Object.getOwnPropertyDescriptor(t, i).enumerable
            }))), n.push.apply(n, r)
        }
        return n
    }

    function G(i) {
        for (var n = 1; n < arguments.length; n++) {
            var r = null != arguments[n] ? arguments[n] : {};
            n % 2 ? J(Object(r), !0).forEach((function(n) {
                t(i, n, r[n])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : J(Object(r)).forEach((function(t) {
                Object.defineProperty(i, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return i
    }
    var K = "ase art bmp blp cd5 cit cpt cr2 cut dds dib djvu egt exif gif gpl grf icns ico iff jng jpeg jpg jfif jp2 jps lbm max miff mng msp nitf ota pbm pc1 pc2 pc3 pcf pcx pdn pgm PI1 PI2 PI3 pict pct pnm pns ppm psb psd pdd psp px pxm pxr qfx raw rle sct sgi rgb int bw tga tiff tif vtf xbm xcf xpm 3dv amf ai awg cgm cdr cmx dxf e2d egt eps fs gbr odg svg stl vrml x3d sxd v2d vnd wmf emf art xar png webp jxr hdp wdp cur ecw iff lbm liff nrrd pam pcx pgf sgi rgb rgba bw int inta sid ras sun tga".split(" "),
        Q = function(t) {
            return K.some((function(i) {
                return !!t.endsWith(".".concat(i))
            }))
        },
        W = "### #gf $on $tf 0b 8m 8u 12u 15u 64c 075 75 085 85 91 091 096 96 abf acfm acs afm afn afs all amfm apf asf aspf atm auf b30 bco bdf bepf bez bfn bmap bmf bx bzr cbtf cct cef cff cfn cga ch4 cha chm chr chx claf collection compositefont dfont dus dzk eft eot etx euf f00 f06 f08 f09 f3f f10 f11 f12 f13 f16 fd fdb ff ffil flf fli fn3 fnb fnn fnt fnta fo1 fo2 fog fon font fonts fot frf frs ftm fxr fyi gdr gf gft glf glif glyphs gsf gxf hbf ice intellifont lepf lft lwfn mcf mcf mfd mfm mft mgf mmm mrf mtf mvec nlq ntf odttf ofm okf otf pcf pcf pfa pfb pfm pft phf pk pkt prs pss qbf qfn r8? scr sfd sff sfi sfl sfn sfo sfp sfs sif snf spd spritefont sui suit svg sxs t1c t2 tb1 tb2 tdf tfm tmf tpf ttc tte ttf type ufm ufo usl usp us? vf vf1 vf3 vfb vfm vfont vlw vmf vnf w30 wfn wnf woff woff2 xfc xfn xfr xft zfi zsu _v".split(" "),
        tt = function(t) {
            return W.some((function(i) {
                return !!t.endsWith(".".concat(i))
            }))
        },
        it = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function nt(t, i) {
        if (i = i.split(":")[0], !(t = +t)) return !1;
        switch (i) {
            case "http":
            case "ws":
                return 80 !== t;
            case "https":
            case "wss":
                return 443 !== t;
            case "ftp":
                return 21 !== t;
            case "gopher":
                return 70 !== t;
            case "file":
                return !1
        }
        return 0 !== t
    }
    var rt = Object.prototype.hasOwnProperty;

    function et(t) {
        try {
            return decodeURIComponent(t.replace(/\+/g, " "))
        } catch (t) {
            return null
        }
    }
    var st = {
            stringify: function(t, i) {
                i = i || "";
                var n, r = [];
                for (e in "string" != typeof i && (i = "?"), t)
                    if (rt.call(t, e)) {
                        (n = t[e]) || null != n && !isNaN(n) || (n = "");
                        var e = encodeURIComponent(e);
                        n = encodeURIComponent(n), null !== e && null !== n && r.push(e + "=" + n)
                    }
                return r.length ? i + r.join("&") : ""
            },
            parse: function(t) {
                for (var i, n = /([^=?&]+)=?([^&]*)/g, r = {}; i = n.exec(t);) {
                    var e = et(i[1]);
                    i = et(i[2]), null === e || null === i || e in r || (r[e] = i)
                }
                return r
            }
        },
        ot = /^[\x00-\x20\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/,
        at = /[\n\r\t]/g,
        ht = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
        ut = /:\d+$/,
        ft = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i,
        ct = /^[a-zA-Z]:/;

    function lt(t) {
        return (t || "").toString().replace(ot, "")
    }
    var pt = [
            ["#", "hash"],
            ["?", "query"],
            function(t, i) {
                return dt(i.protocol) ? t.replace(/\\/g, "/") : t
            },
            ["/", "pathname"],
            ["@", "auth", 1],
            [NaN, "host", void 0, 1, 1],
            [/:(\d*)$/, "port", void 0, 1],
            [NaN, "hostname", void 0, 1, 1]
        ],
        vt = {
            hash: 1,
            query: 1
        };

    function mt(t) {
        var i = ("undefined" != typeof window ? window : void 0 !== it ? it : "undefined" != typeof self ? self : {}).location || {};
        t = t || i, i = {};
        var n, r = a(t);
        if ("blob:" === t.protocol) i = new gt(unescape(t.pathname), {});
        else if ("string" === r)
            for (n in i = new gt(t, {}), vt) delete i[n];
        else if ("object" === r) {
            for (n in t) n in vt || (i[n] = t[n]);
            void 0 === i.slashes && (i.slashes = ht.test(t.href))
        }
        return i
    }

    function dt(t) {
        return "file:" === t || "ftp:" === t || "http:" === t || "https:" === t || "ws:" === t || "wss:" === t
    }

    function yt(t, i) {
        t = (t = lt(t)).replace(at, ""), i = i || {};
        var n = (t = ft.exec(t))[1] ? t[1].toLowerCase() : "",
            r = !!t[2],
            e = !!t[3],
            s = 0;
        return r ? e ? (e = t[2] + t[3] + t[4], s = t[2].length + t[3].length) : (e = t[2] + t[4], s = t[2].length) : e ? (e = t[3] + t[4], s = t[3].length) : e = t[4], "file:" === n ? 2 <= s && (e = e.slice(2)) : dt(n) ? e = t[4] : n ? r && (e = e.slice(2)) : 2 <= s && dt(i.protocol) && (e = t[4]), {
            protocol: n,
            slashes: r || dt(n),
            slashesCount: s,
            rest: e
        }
    }

    function gt(t, i, n) {
        if (t = (t = lt(t)).replace(at, ""), !(this instanceof gt)) return new gt(t, i, n);
        var r = pt.slice(),
            e = a(i),
            s = 0;
        "object" !== e && "string" !== e && (n = i, i = null), n && "function" != typeof n && (n = st.parse);
        var o = yt(t || "", i = mt(i));
        for (e = !o.protocol && !o.slashes, this.slashes = o.slashes || e && i.slashes, this.protocol = o.protocol || i.protocol || "", t = o.rest, ("file:" === o.protocol && (2 !== o.slashesCount || ct.test(t)) || !o.slashes && (o.protocol || 2 > o.slashesCount || !dt(this.protocol))) && (r[3] = [/(.*)/, "pathname"]); s < r.length; s++)
            if ("function" == typeof(o = r[s])) t = o(t, this);
            else {
                var h = o[0],
                    u = o[1];
                h != h ? this[u] = t : "string" == typeof h ? ~(h = "@" === h ? t.lastIndexOf(h) : t.indexOf(h)) && ("number" == typeof o[2] ? (this[u] = t.slice(0, h), t = t.slice(h + o[2])) : (this[u] = t.slice(h), t = t.slice(0, h))) : (h = h.exec(t)) && (this[u] = h[1], t = t.slice(0, h.index)), this[u] = this[u] || e && o[3] && i[u] || "", o[4] && (this[u] = this[u].toLowerCase())
            }
        if (n && (this.query = n(this.query)), e && i.slashes && "/" !== this.pathname.charAt(0) && ("" !== this.pathname || "" !== i.pathname)) {
            if (t = this.pathname, i = i.pathname, "" !== t) {
                for (n = (i = (i || "/").split("/").slice(0, -1).concat(t.split("/")))[(t = i.length) - 1], r = !1, s = 0; t--;) "." === i[t] ? i.splice(t, 1) : ".." === i[t] ? (i.splice(t, 1), s++) : s && (0 === t && (r = !0), i.splice(t, 1), s--);
                r && i.unshift(""), "." !== n && ".." !== n || i.push(""), i = i.join("/")
            }
            this.pathname = i
        }
        "/" !== this.pathname.charAt(0) && dt(this.protocol) && (this.pathname = "/" + this.pathname), nt(this.port, this.protocol) || (this.host = this.hostname, this.port = ""), this.username = this.password = "", this.auth && (~(h = this.auth.indexOf(":")) ? (this.username = this.auth.slice(0, h), this.username = encodeURIComponent(decodeURIComponent(this.username)), this.password = this.auth.slice(h + 1), this.password = encodeURIComponent(decodeURIComponent(this.password))) : this.username = encodeURIComponent(decodeURIComponent(this.auth)), this.auth = this.password ? this.username + ":" + this.password : this.username), this.origin = "file:" !== this.protocol && dt(this.protocol) && this.host ? this.protocol + "//" + this.host : "null", this.href = this.toString()
    }
    gt.prototype = {
        set: function(t, i, n) {
            switch (t) {
                case "query":
                    "string" == typeof i && i.length && (i = (n || st.parse)(i)), this[t] = i;
                    break;
                case "port":
                    this[t] = i, nt(i, this.protocol) ? i && (this.host = this.hostname + ":" + i) : (this.host = this.hostname, this[t] = "");
                    break;
                case "hostname":
                    this[t] = i, this.port && (i += ":" + this.port), this.host = i;
                    break;
                case "host":
                    this[t] = i, ut.test(i) ? (i = i.split(":"), this.port = i.pop(), this.hostname = i.join(":")) : (this.hostname = i, this.port = "");
                    break;
                case "protocol":
                    this.protocol = i.toLowerCase(), this.slashes = !n;
                    break;
                case "pathname":
                case "hash":
                    i ? (n = "pathname" === t ? "/" : "#", this[t] = i.charAt(0) !== n ? n + i : i) : this[t] = i;
                    break;
                case "username":
                case "password":
                    this[t] = encodeURIComponent(i);
                    break;
                case "auth":
                    ~(t = i.indexOf(":")) ? (this.username = i.slice(0, t), this.username = encodeURIComponent(decodeURIComponent(this.username)), this.password = i.slice(t + 1), this.password = encodeURIComponent(decodeURIComponent(this.password))) : this.username = encodeURIComponent(decodeURIComponent(i))
            }
            for (i = 0; i < pt.length; i++)(t = pt[i])[4] && (this[t[1]] = this[t[1]].toLowerCase());
            return this.auth = this.password ? this.username + ":" + this.password : this.username, this.origin = "file:" !== this.protocol && dt(this.protocol) && this.host ? this.protocol + "//" + this.host : "null", this.href = this.toString(), this
        },
        toString: function(t) {
            t && "function" == typeof t || (t = st.stringify);
            var i = this.host,
                n = this.protocol;
            return n && ":" !== n.charAt(n.length - 1) && (n += ":"), n += this.protocol && this.slashes || dt(this.protocol) ? "//" : "", this.username ? (n += this.username, this.password && (n += ":" + this.password), n += "@") : this.password ? (n += ":" + this.password, n += "@") : "file:" !== this.protocol && dt(this.protocol) && !i && "/" !== this.pathname && (n += "@"), (":" === i[i.length - 1] || ut.test(this.hostname) && !this.port) && (i += ":"), n += i + this.pathname, (t = "object" === a(this.query) ? t(this.query) : this.query) && (n += "?" !== t.charAt(0) ? "?" + t : t), this.hash && (n += this.hash), n
        }
    }, gt.extractProtocol = yt, gt.location = mt, gt.trimLeft = lt, gt.qs = st;
    var bt = gt,
        wt = /^xn--/,
        xt = /[^\0-\x7E]/,
        At = /[\x2E\u3002\uFF0E\uFF61]/g,
        St = {
            overflow: "Overflow: input needs wider integers to process",
            "not-basic": "Illegal input >= 0x80 (not a basic code point)",
            "invalid-input": "Invalid input"
        },
        kt = Math.floor,
        Pt = String.fromCharCode;

    function It(t) {
        throw new RangeError(St[t])
    }

    function Et(t, i) {
        var n = t.split("@"),
            r = "";
        1 < n.length && (r = n[0] + "@", t = n[1]), n = [];
        for (var e = (t = (t = t.replace(At, ".")).split(".")).length; e--;) n[e] = i(t[e]);
        return r + n.join(".")
    }

    function jt(t, i, n) {
        var r = 0;
        for (t = n ? kt(t / 700) : t >> 1, t += kt(t / i); 455 < t; r += 36) t = kt(t / 35);
        return kt(r + 36 * t / (t + 38))
    }
    var Rt = function(t) {
            return Et(t, (function(t) {
                return wt.test(t) ? function(t) {
                    var i = [],
                        n = t.length,
                        r = 0,
                        e = 128,
                        s = 72,
                        o = t.lastIndexOf("-");
                    0 > o && (o = 0);
                    for (var a = 0; a < o; ++a) 128 <= t.charCodeAt(a) && It("not-basic"), i.push(t.charCodeAt(a));
                    for (o = 0 < o ? o + 1 : 0; o < n;) {
                        a = r;
                        for (var h = 1, u = 36;; u += 36) {
                            o >= n && It("invalid-input");
                            var f = t.charCodeAt(o++);
                            (36 <= (f = 10 > f - 48 ? f - 22 : 26 > f - 65 ? f - 65 : 26 > f - 97 ? f - 97 : 36) || f > kt((2147483647 - r) / h)) && It("overflow"), r += f * h;
                            var c = u <= s ? 1 : u >= s + 26 ? 26 : u - s;
                            if (f < c) break;
                            h > kt(2147483647 / (f = 36 - c)) && It("overflow"), h *= f
                        }
                        s = jt(r - a, f = i.length + 1, 0 == a), kt(r / f) > 2147483647 - e && It("overflow"), e += kt(r / f), r %= f, i.splice(r++, 0, e)
                    }
                    return String.fromCodePoint.apply(String, i)
                }(t.slice(4).toLowerCase()) : t
            }))
        },
        Ct = /[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0800-\u1fff\u200e\u2c00-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]/,
        Mt = /[\u0591-\u06ef\u06fa-\u07ff\u200f\ufb1d-\ufdff\ufe70-\ufefc]/;

    function Ot(t) {
        if (Ut(t = new bt(t).hostname)) var i = !1;
        else i = Rt(t), i = 63 >= t.length && !(Ct.test(i) && Mt.test(i)) && -1 != t.indexOf(".");
        return i ? 63 < (i = function(t) {
            return Et(t, (function(t) {
                return xt.test(t) ? "xn--" + function(t) {
                    for (var i, n = [], r = (t = function(t) {
                            for (var i = [], n = 0, r = t.length; n < r;) {
                                var e = t.charCodeAt(n++);
                                if (55296 <= e && 56319 >= e && n < r) {
                                    var s = t.charCodeAt(n++);
                                    56320 == (64512 & s) ? i.push(((1023 & e) << 10) + (1023 & s) + 65536) : (i.push(e), n--)
                                } else i.push(e)
                            }
                            return i
                        }(t)).length, e = 128, s = 0, a = 72, h = o(t, !0); !(i = h()).done;) {
                        var u = i.value;
                        128 > u && n.push(Pt(u))
                    }
                    var f = u = n.length;
                    for (u && n.push("-"); f < r;) {
                        for (var c, l = 2147483647, p = o(t, !0); !(c = p()).done;) {
                            var v = c.value;
                            v >= e && v < l && (l = v)
                        }
                        var m = f + 1;
                        l - e > kt((2147483647 - s) / m) && It("overflow"), s += (l - e) * m, e = l;
                        for (var d, y = o(t, !0); !(d = y()).done;) {
                            var g = d.value;
                            if (g < e && 2147483647 < ++s && It("overflow"), g == e) {
                                var b = s;
                                for (l = 36;; l += 36) {
                                    var w = l <= a ? 1 : l >= a + 26 ? 26 : l - a;
                                    if (b < w) break;
                                    var x = b - w,
                                        A = 36 - w;
                                    w += x % A, (b = n).push.call(b, Pt(w + 22 + 75 * (26 > w) - 0)), b = kt(x / A)
                                }
                                n.push(Pt(b + 22 + 75 * (26 > b) - 0)), a = jt(s, m, f == u), s = 0, ++f
                            }
                        }++s, ++e
                    }
                    return n.join("")
                }(t) : t
            }))
        }(i = (i = (i = Rt(t)).split("-").join("--")).split(".").join("-")).toLowerCase()).length ? Tt(t) : (Ut(i) && (i = "0-".concat(i, "-0")), Promise.resolve(i)) : Tt(t)
    }

    function Tt(t) {
        return (t = "undefined" != typeof window ? function(t) {
            return t = new TextEncoder("utf-8").encode(t), window.crypto.subtle.digest("SHA-256", t).then((function(t) {
                var i = [];
                t = new DataView(t);
                for (var n = 0; n < t.byteLength; n += 4) {
                    var r = ("00000000" + t.getUint32(n).toString(16)).slice(-8);
                    i.push(r)
                }
                return i.join("")
            }))
        }(t) : void 0).then((function(t) {
            return function(t) {
                var i = [];
                t.match(/.{1,2}/g).forEach((function(t, n) {
                    i[n] = parseInt(t, 16)
                }));
                var n = i.length % 5,
                    r = Math.floor(i.length / 5);
                if (t = [], 0 != n) {
                    for (var e = 0; e < 5 - n; e++) i += "\0";
                    r += 1
                }
                for (e = 0; e < r; e++) t.push("abcdefghijklmnopqrstuvwxyz234567".charAt(i[5 * e] >> 3)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt((7 & i[5 * e]) << 2 | i[5 * e + 1] >> 6)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt((63 & i[5 * e + 1]) >> 1)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt((1 & i[5 * e + 1]) << 4 | i[5 * e + 2] >> 4)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt((15 & i[5 * e + 2]) << 1 | i[5 * e + 3] >> 7)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt((127 & i[5 * e + 3]) >> 2)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt((3 & i[5 * e + 3]) << 3 | i[5 * e + 4] >> 5)), t.push("abcdefghijklmnopqrstuvwxyz234567".charAt(31 & i[5 * e + 4]));
                for (r = 0, 1 == n ? r = 6 : 2 == n ? r = 4 : 3 == n ? r = 3 : 4 == n && (r = 1), n = 0; n < r; n++) t.pop();
                for (n = 0; n < r; n++) t.push("=");
                return t.join("")
            }("ffffffffff" + t + "000000").substr(8, Math.ceil(4 * t.length / 5))
        }))
    }

    function Ut(t) {
        return "--" == t.slice(2, 4) && "xn" != t.slice(0, 2)
    }
    var zt = "viewer";

    function Dt(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        return Q(t) ? "/i" : tt(t) ? "/r" : i === zt ? "/v" : "/c"
    }
    var Nt = "amp-viewer-messaging",
        qt = "channelOpen",
        Lt = "__AMPHTML__";

    function _t(t) {
        if ("string" != typeof t) return t;
        if ("{" != t.charAt(0)) return null;
        try {
            return JSON.parse(t)
        } catch (t) {
            return null
        }
    }
    var Ft = function() {
            function t(t, i, n) {
                this.win_ = t, this.origin_ = i, this.target_ = n
            }
            var i = t.prototype;
            return i.addEventListener = function(t, i) {
                var n = this;
                this.win_.addEventListener("message", (function(t) {
                    t.origin == n.origin_ && t.source == n.target_ && i(t)
                }))
            }, i.postMessage = function(t) {
                var i = "null" === this.origin_ ? "*" : this.origin_;
                this.target_.postMessage(t, i)
            }, i.start = function() {}, t
        }(),
        Yt = function() {
            function t(t, i, n, r, e) {
                this.win_ = t, this.port_ = i, this.isWebview_ = !!n, this.token_ = r || null, this.verifyToken_ = !!e, this.requestIdCounter_ = 0, this.waitingForResponse_ = {}, this.messageHandlers_ = {}, this.defaultHandler_ = null, this.port_.addEventListener("message", this.handleMessage_.bind(this)), this.port_.start()
            }
            t.initiateHandshakeWithDocument = function(i, n) {
                return new Promise((function(r) {
                    var e = setInterval((function() {
                        var s = new MessageChannel,
                            o = {
                                app: Lt,
                                name: "handshake-poll"
                            };
                        i.postMessage(o, "*", [s.port2]);
                        var a = s.port1;
                        a.addEventListener("message", (function i(s) {
                            var o = _t(s.data);
                            if (o && o.app === Lt && o.name === qt) {
                                clearInterval(e), a.removeEventListener("message", i);
                                var h = new t(null, a, !1, n, !0);
                                h.sendResponse_(o.requestid, qt, null), r(h)
                            }
                        })), a.start()
                    }), 1e3)
                }))
            }, t.waitForHandshakeFromDocument = function(i, n, r, e, s) {
                return new Promise((function(o) {
                    i.addEventListener("message", (function a(h) {
                        var u = _t(h.data);
                        if (u && (h.origin == r || s && s.test(h.origin)) && (!h.source || h.source == n) && u.app === Lt && u.name === qt) {
                            i.removeEventListener("message", a);
                            var f = new t(null, new Ft(i, h.origin, n), !1, e, !0);
                            f.sendResponse_(u.requestid, qt, null), o(f)
                        }
                    }))
                }))
            };
            var i = t.prototype;
            return i.registerHandler = function(t, i) {
                this.messageHandlers_[t] = i
            }, i.unregisterHandler = function(t) {
                delete this.messageHandlers_[t]
            }, i.setDefaultHandler = function(t) {
                this.defaultHandler_ = t
            }, i.handleMessage_ = function(t) {
                var i = _t(t.data);
                i && i.app === Lt && (this.token_ && this.verifyToken_ && i.messagingToken !== this.token_ ? this.logError_(Nt + ": handleMessage_ error: ", "invalid token") : "q" === i.type ? this.handleRequest_(i) : "s" === i.type && this.handleResponse_(i))
            }, i.sendRequest = function(t, i, n) {
                var r = this,
                    e = ++this.requestIdCounter_,
                    s = void 0;
                return n && (s = new Promise((function(t, i) {
                    r.waitingForResponse_[e] = {
                        resolve: t,
                        reject: i
                    }
                }))), this.sendMessage_({
                    app: Lt,
                    requestid: e,
                    type: "q",
                    name: t,
                    data: i,
                    rsvp: n
                }), s
            }, i.sendResponse_ = function(t, i, n) {
                this.sendMessage_({
                    app: Lt,
                    requestid: t,
                    type: "s",
                    name: i,
                    data: n
                })
            }, i.sendResponseError_ = function(t, i, n) {
                var r = this.errorToString_(n);
                this.logError_(Nt + ": sendResponseError_, message name: " + i, r), this.sendMessage_({
                    app: Lt,
                    requestid: t,
                    type: "s",
                    name: i,
                    data: null,
                    error: r
                })
            }, i.sendMessage_ = function(t) {
                var i = Object.assign(t, {});
                this.token_ && !this.verifyToken_ && (i.messagingToken = this.token_), this.port_.postMessage(this.isWebview_ ? JSON.stringify(i) : i)
            }, i.handleRequest_ = function(t) {
                var i = this,
                    n = this.messageHandlers_[t.name];
                if (n || (n = this.defaultHandler_), !n) {
                    var r = new Error("Cannot handle request because no default handler is set!");
                    throw r.args = t.name, r
                }
                var e = n(t.name, t.data, !!t.rsvp);
                if (t.rsvp) {
                    var s = t.requestid;
                    if (!e) throw this.sendResponseError_(s, t.name, new Error("no response")), new Error("expected response but none given: " + t.name);
                    e.then((function(n) {
                        i.sendResponse_(s, t.name, n)
                    }), (function(n) {
                        i.sendResponseError_(s, t.name, n)
                    }))
                }
            }, i.handleResponse_ = function(t) {
                var i = t.requestid,
                    n = this.waitingForResponse_[i];
                n && (delete this.waitingForResponse_[i], t.error ? (this.logError_(Nt + ": handleResponse_ error: ", t.error), n.reject(new Error("Request ".concat(t.name, " failed: ").concat(t.error)))) : n.resolve(t.data))
            }, i.logError_ = function(t, i) {
                if (this.win_) {
                    var n = "amp-messaging-error-logger: " + t;
                    n += " data: " + this.errorToString_(i), this.win_.viewerState = n
                }
            }, i.errorToString_ = function(t) {
                return t ? t.message ? t.message : String(t) : "unknown error"
            }, t
        }();

    function Ht(t, i) {
        return t
    }
    var Bt, Vt = {
            VISIBLE: "visible",
            INACTIVE: "inactive"
        },
        $t = G(G({}, Vt), {}, {
            PRERENDER: "prerender",
            PREVIEW: "preview",
            HIDDEN: "hidden",
            PAUSED: "paused"
        });

    function Xt(t, n) {
        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5;
        if (!isFinite(r) || r < 0) throw new Error("Invalid depth: " + r);
        if (t === n) return !0;
        for (var e = [{
                a: t,
                b: n,
                depth: r
            }]; e.length > 0;) {
            var s = e.shift(),
                o = s.a,
                h = s.b,
                u = s.depth;
            if (u > 0) {
                if (a(o) !== a(h)) return !1;
                if (i(o) && i(h)) {
                    if (o.length !== h.length) return !1;
                    for (var f = 0; f < o.length; f++) e.push({
                        a: o[f],
                        b: h[f],
                        depth: u - 1
                    });
                    continue
                }
                if (o && h && "object" === a(o) && "object" === a(h)) {
                    var c = Object.keys(o),
                        l = Object.keys(h);
                    if (c.length !== l.length) return !1;
                    for (var p = 0, v = c; p < v.length; p++) {
                        var m = v[p];
                        e.push({
                            a: o[m],
                            b: h[m],
                            depth: u - 1
                        })
                    }
                    continue
                }
            }
            if (o !== h) return !1
        }
        return !0
    }

    function Zt(t, i, n) {
        var r = t.hasAttribute(i),
            e = void 0 !== n ? n : !r;
        return e !== r && (e ? t.setAttribute(i, "") : t.removeAttribute(i)), e
    }
    var Jt, Gt = ["Webkit", "webkit", "Moz", "moz", "ms", "O", "o"];

    function Kt(t, i, n, r, e) {
        var s = function(t, i, n) {
            if (i.startsWith("--")) return i;
            Bt || (Bt = u());
            var r = Bt[i];
            if (!r || n) {
                if (r = i, void 0 === t[i]) {
                    var e = function(t) {
                            return t.charAt(0).toUpperCase() + t.slice(1)
                        }(i),
                        s = function(t, i) {
                            for (var n = 0; n < Gt.length; n++) {
                                var r = Gt[n] + i;
                                if (void 0 !== t[r]) return r
                            }
                            return ""
                        }(t, e);
                    void 0 !== t[s] && (r = s)
                }
                n || (Bt[i] = r)
            }
            return r
        }(t.style, i, e);
        if (s) {
            var o, a = r ? n + r : n;
            t.style.setProperty((o = s.replace(/[A-Z]/g, (function(t) {
                return "-" + t.toLowerCase()
            })), Gt.some((function(t) {
                return o.startsWith(t + "-")
            })) ? "-".concat(o) : o), a)
        }
    }

    function Qt(t, i) {
        for (var n in i) Kt(t, n, i[n])
    }

    function Wt(t, i) {
        for (var n = 0; n < i.length; n++) Kt(t, i[n], null)
    }

    function ti(t, i, n, r) {
        var e = {
            detail: n
        };
        if (Object.assign(e, r), "function" == typeof t.CustomEvent) return new t.CustomEvent(i, e);
        var s = t.document.createEvent("CustomEvent");
        return s.initCustomEvent(i, !!e.bubbles, !!e.cancelable, n), s
    }

    function ii(t, i, n, r) {
        var e = n,
            s = function(t, i, n, r) {
                var e = t,
                    s = n,
                    o = function(t) {
                        try {
                            return s(t)
                        } catch (t) {
                            var i, n;
                            throw null === (i = (n = self).__AMP_REPORT_ERROR) || void 0 === i || i.call(n, t), t
                        }
                    },
                    a = function() {
                        if (void 0 !== Jt) return Jt;
                        Jt = !1;
                        try {
                            var t = {
                                get capture() {
                                    return Jt = !0, !1
                                }
                            };
                            self.addEventListener("test-options", null, t), self.removeEventListener("test-options", null, t)
                        } catch (t) {}
                        return Jt
                    }(),
                    h = !(null == r || !r.capture);
                return e.addEventListener(i, o, a ? r : h),
                    function() {
                        null == e || e.removeEventListener(i, o, a ? r : h), s = null, e = null, o = null
                    }
            }(t, i, (function(t) {
                try {
                    e(t)
                } finally {
                    e = null, s()
                }
            }), r);
        return s
    }
    var ni, ri, ei = function() {
            function t(t, i, n) {
                this.t = t, this.el = i, this.ep = n, this.sp = null, this.op()
            }
            var i = t.prototype;
            return i.op = function() {
                this.t.IntersectionObserver && this.t === this.t.parent ? this.ap() : this.hp()
            }, i.ap = function() {
                var t = this,
                    i = new this.t.IntersectionObserver((function(n) {
                        n.forEach((function(n) {
                            n.isIntersecting && (t.ep(), i.unobserve(t.el))
                        }))
                    }));
                i.observe(this.el)
            }, i.hp = function() {
                this.sp = b(this.t, this.up.bind(this), 500), this.t.addEventListener("scroll", this.sp), this.up(this.el)
            }, i.up = function() {
                var t = this.el.getBoundingClientRect().top;
                this.t.innerHeight > t && (this.ep(), this.t.removeEventListener("scroll", this.sp))
            }, t
        }(),
        si = "amp-story-player-close",
        oi = function() {
            function t(t) {
                this.t = t, this.fp = {
                    startY: 0,
                    lastDelta: 0,
                    touchStartTimeMs: null,
                    touchEndTimeMs: null,
                    touchMoveTimeMs: null
                }, this.cp = {
                    startY: 0,
                    isRunning: !1,
                    acceleration: 1,
                    speedLimit: .3,
                    startTimeMs: null,
                    maxTimeBetweenSwipesMs: 250,
                    moveTimeThresholdMs: 100,
                    durationMs: null,
                    meetsDeltaYThreshold: !1,
                    deltaYThresholdPx: 5,
                    deltaY: null,
                    offsetThresholdPx: 30,
                    offsetPx: null,
                    multiplier: 1
                }
            }
            var i = t.prototype;
            return i.onTouchStart = function(t, i) {
                this.fp.startY = i, this.fp.touchStartTimeMs = t, this.cp.startY = this.t.scrollY, this.cp.isRunning && this.fp.touchEndTimeMs - this.fp.touchStartTimeMs < this.cp.maxTimeBetweenSwipesMs ? this.cp.multiplier += this.cp.acceleration : this.cp.multiplier = 1, this.cp.isRunning = !1
            }, i.onTouchMove = function(t, i) {
                this.cp.acceleration = Math.abs(this.cp.deltaY / (t - this.fp.touchMoveTimeMs)), this.fp.touchMoveTimeMs = t, b(this.t, this.lp.bind(this, i), 50)()
            }, i.lp = function(t) {
                this.cp.deltaY = t - this.fp.startY, this.cp.meetsDeltaYThreshold = Math.abs(this.cp.deltaY) > this.cp.deltaYThresholdPx, this.cp.meetsDeltaYThreshold && this.t.scrollBy(0, -this.cp.deltaY)
            }, i.onTouchEnd = function(t) {
                var i = this;
                if (this.fp.touchEndTimeMs = t, this.cp.meetsDeltaYThreshold) {
                    var n = this.fp.touchEndTimeMs - this.fp.touchMoveTimeMs;
                    this.cp.offsetPx = this.pp(), n < this.cp.moveTimeThresholdMs && Math.abs(this.cp.offsetPx) > this.cp.offsetThresholdPx && (this.cp.durationMs = 1.2 * this.t.innerHeight, this.cp.isRunning = !0, requestAnimationFrame((function(t) {
                        i.cp.startTimeMs = t, i.cp.startY = i.t.scrollY, i.vp(t)
                    }))), this.cp.multiplier = 1, this.fp.startY = 0, this.cp.deltaY = 0
                }
            }, i.pp = function() {
                var t = this.t.innerHeight * this.cp.speedLimit,
                    i = Math.pow(this.cp.acceleration, 2) * this.t.innerHeight;
                return (i = Math.min(t, i)) * (this.cp.deltaY > 0 ? -this.cp.multiplier : this.cp.multiplier)
            }, i.vp = function(t) {
                var i = t - this.cp.startTimeMs;
                if (!(i > this.cp.durationMs)) {
                    var n = this.mp(i / this.cp.durationMs) * this.cp.offsetPx,
                        r = this.cp.startY + n;
                    this.cp.isRunning ? (this.t.scroll(0, r), requestAnimationFrame(this.vp.bind(this))) : cancelAnimationFrame(requestAnimationFrame(this.vp.bind(this)))
                }
            }, i.mp = function(t) {
                return 1 - --t * t * t * t
            }, t
        }(),
        ai = function() {
            function t(t) {
                this.zt = t, this.It = 0, this.Ct = 0, this.Ot = u()
            }
            var i = t.prototype;
            return i.has = function(t) {
                return !!this.Ot[t]
            }, i.get = function(t) {
                var i = this.Ot[t];
                if (i) return i.access = ++this.Ct, i.payload
            }, i.put = function(t, i) {
                this.has(t) || this.It++, this.Ot[t] = {
                    payload: i,
                    access: this.Ct
                }, this.qt()
            }, i.qt = function() {
                if (!(this.It <= this.zt)) {
                    var t, i = this.Ot,
                        n = this.Ct + 1;
                    for (var r in i) {
                        var e = i[r].access;
                        e < n && (n = e, t = r)
                    }
                    void 0 !== t && (delete i[t], this.It--)
                }
            }, t
        }();

    function hi(t, i) {
        return ni || (ni = self.document.createElement("a"), ri = self.__AMP_URL_CACHE || (self.__AMP_URL_CACHE = new ai(100))), ui(ni, t, i ? null : ri)
    }

    function ui(t, i, n) {
        if (n && n.has(i)) return n.get(i);
        t.href = i, t.protocol || (t.href = t.href);
        var r, e = {
            href: t.href,
            protocol: t.protocol,
            host: t.host,
            hostname: t.hostname,
            port: "0" == t.port ? "" : t.port,
            pathname: t.pathname,
            search: t.search,
            hash: t.hash,
            origin: null
        };
        "/" !== e.pathname[0] && (e.pathname = "/" + e.pathname), ("http:" == e.protocol && 80 == e.port || "https:" == e.protocol && 443 == e.port) && (e.port = "", e.host = e.hostname), r = t.origin && "null" != t.origin ? t.origin : "data:" != e.protocol && e.host ? e.protocol + "//" + e.host : e.href, e.origin = r;
        var s = e;
        return n && n.put(i, s), s
    }

    function fi(t, i) {
        return function(t, i, n) {
            if (!i) return t;
            var r = t.split("#", 2),
                e = r[0].split("?", 2);
            return e[0] + (e[1] ? "?".concat(e[1], "&").concat(i) : "?".concat(i)) + (r[1] ? "#".concat(r[1]) : "")
        }(t, ci(i))
    }

    function ci(t) {
        var n, r, e, s = [];
        for (var o in t) {
            var a = t[o];
            if (null != a) {
                a = i(e = a) ? e : [e];
                for (var h = 0; h < a.length; h++) s.push((n = o, r = a[h], "".concat(encodeURIComponent(n), "=").concat(encodeURIComponent(r))))
            }
        }
        return s.join("&")
    }

    function li(t) {
        var i = t.indexOf("#");
        return -1 == i ? t : t.substring(0, i)
    }

    function pi(t) {
        var i = t.indexOf("#");
        return -1 == i ? "" : t.substring(i)
    }

    function vi(t) {
        return P.test(function(t) {
            return "string" == typeof t ? hi(t) : t
        }(t).origin)
    }

    function mi(t) {
        var i = t.indexOf("?");
        if (-1 == i) return t;
        var n = pi(t);
        return t.substring(0, i) + n
    }
    var di, yi, gi, bi, wi, xi = ["cdn.ampproject.org", "www.bing-amp.com"],
        Ai = (t(di = {}, 45, (function(t, i) {
            return t.length !== i.length
        })), t(di, 18, (function(t, i) {
            return t.element !== i.element || t.state !== i.state
        })), t(di, 51, (function(t, i) {
            return t.length !== i.length
        })), t(di, 53, (function(t, i) {
            return t.length !== i.length
        })), t(di, 54, (function(t, i) {
            return null === t || null === i || t.width !== i.width || t.height !== i.height
        })), t(di, 32, (function(t, i) {
            return null === t || null === i || !Xt(t, i, 2)
        })), t(di, 38, (function(t, i) {
            return null === t || null === i || !Xt(t, i, 2)
        })), t(di, 25, (function(t, i) {
            return !Xt(t, i, 3)
        })), "manualAdvance"),
        Si = "closeButtonTapped",
        ki = "i-amphtml-story-player-loading",
        Pi = "i-amphtml-story-player-loaded",
        Ii = "i-amphtml-story-player-error",
        Ei = ["allow-top-navigation"],
        ji = "amp-story-player-hide-button",
        Ri = "PAGE_ATTACHMENT_STATE",
        Ci = "UI_STATE",
        Mi = "MUTED_STATE",
        Oi = "CURRENT_PAGE_ID",
        Ti = "i-amphtml-story-player-no-navigation-transition",
        Ui = "amp-story-player",
        zi = "amp-story-player-dev",
        Di = 500,
        Ni = function() {
            function t(t, i) {
                return this.t = t, this.el = i, this.Xc = t.document, this.dp = this.Xc.createElement("a"), this.yp = [], this.np = null, this.gp = 0, this.bp = Date.now(), this.wp = !1, this.xp = 0, this.Ap = null, this.Sp = null, this.kp = null, this.fp = {
                    startX: 0,
                    startY: 0,
                    lastX: 0,
                    isSwipeX: null
                }, this.Pp = null, this.Ip = new Z, this.Ep(), this.jp = new oi(t), this.Rp = null, this.Cp = !0, this.Mp = !0, this.Op = null, this.Tp = null, this.Up = null, this.zp = !1, this.Dp = !1, this.Np = 0, this.qp = null, this.Lp = 0, this._p = null, this.Fp = !1, this.Yp = Ai, this.el
            }
            var i = t.prototype;
            return i.Ep = function() {
                this.el.buildPlayer = this.buildPlayer.bind(this), this.el.disablePlayback = this.disablePlayback.bind(this), this.el.enablePlayback = this.enablePlayback.bind(this), this.el.disablePage = this.disablePage.bind(this), this.el.enablePage = this.enablePage.bind(this), this.el.layoutPlayer = this.layoutPlayer.bind(this), this.el.getElement = this.getElement.bind(this), this.el.getStories = this.getStories.bind(this), this.el.load = this.load.bind(this), this.el.show = this.show.bind(this), this.el.add = this.add.bind(this), this.el.play = this.play.bind(this), this.el.pause = this.pause.bind(this), this.el.go = this.go.bind(this), this.el.mute = this.mute.bind(this), this.el.unmute = this.unmute.bind(this), this.el.getStoryState = this.getStoryState.bind(this), this.el.rewind = this.rewind.bind(this), this.el.resetCurrentPage = this.resetCurrentPage.bind(this), this.el.setInAppActionsHaveCustomBehaviour = this.setInAppActionsHaveCustomBehaviour.bind(this), this.el.updateStoryAdConfig = this.updateStoryAdConfig.bind(this), this.el.updateStoryInitialPageId = this.updateStoryInitialPageId.bind(this)
            }, i.load = function() {
                if (!this.el.isConnected) throw new Error("[".concat(Ui, "] element must be connected to the DOM before calling load()."));
                if (this.el.tp) throw new Error("[".concat(Ui, "] calling load() on an already loaded element."));
                this.buildPlayer(), this.layoutPlayer(), this.Mp = !0
            }, i.Hp = function(t) {
                t.idx = this.yp.length, t.distance = t.idx - this.gp, t.pages = null, t.connectedDeferred = new Z, this.yp.push(t)
            }, i.add = function(t) {
                if (!(t.length <= 0)) {
                    if (!Array.isArray(t) || !t.every((function(t) {
                            return t && t.href
                        }))) throw new Error('"stories" parameter has the wrong structure');
                    for (var i = this.yp.length, n = 0; n < t.length; n++) {
                        var r = t[n];
                        this.Hp(r), this.Bp(r)
                    }
                    this.fa(i)
                }
            }, i.play = function() {
                this.el.ip || this.layoutPlayer(), this.Mp = !0, this.Ii($t.VISIBLE, Vt.VISIBLE)
            }, i.pause = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                    i = t ? $t.INACTIVE : $t.PAUSED,
                    n = t ? Vt.INACTIVE : Vt.VISIBLE;
                this.Ii(i, n), t && this.Vp()
            }, i.disablePlayback = function() {
                this.yp[this.gp].messagingPromise.then((function(t) {
                    return t.sendRequest("disablePlayback")
                }))
            }, i.enablePlayback = function() {
                this.yp[this.gp].messagingPromise.then((function(t) {
                    return t.sendRequest("enablePlayback")
                }))
            }, i.setInAppActionsHaveCustomBehaviour = function(t) {
                this.Rp = t, this.yp.filter((function(t) {
                    return !!t.messagingPromise
                })).forEach((function(i) {
                    i.messagingPromise.then((function(i) {
                        i.sendRequest("setInAppActionsHaveCustomBehaviour", t)
                    }))
                }))
            }, i.Ii = function(t, i) {
                this.Cp = t == $t.VISIBLE;
                var n = this.yp[this.gp];
                this.$p(n, t, i)
            }, i.getElement = function() {
                return this.el
            }, i.Xp = function(t) {
                return this.yp.findIndex((function(i) {
                    return new URL(i.href).pathname.includes(t)
                }))
            }, i.disablePage = function(t, i) {
                var n = this.Xp(t);
                if (!(n < 0)) {
                    var r = this.yp[n];
                    this.Zp(r).then((function() {
                        return r.messagingPromise
                    })).then((function(t) {
                        return t.sendRequest("disablePage", i)
                    }))
                }
            }, i.enablePage = function(t, i) {
                var n = this.Xp(t);
                if (!(n < 0)) {
                    var r = this.yp[n];
                    this.Zp(r).then((function() {
                        return r.messagingPromise
                    })).then((function(t) {
                        return t.sendRequest("enablePage", i)
                    }))
                }
            }, i.updateStoryAdConfig = function(t, i) {
                var n = this.Xp(t);
                if (!(n < 0)) {
                    var r = this.yp[n];
                    r.overrideAdConfig = i, this.Zp(r).then((function() {
                        return r.messagingPromise
                    })).then((function(t) {
                        return t.sendRequest("updateStoryAdConfig", i)
                    }))
                }
            }, i.updateStoryInitialPageId = function(t, i) {
                var n = this.Xp(t);
                if (!(n < 0)) {
                    var r = this.yp[n];
                    r.initialPageId = i, this.Zp(r).then((function() {
                        return r.messagingPromise
                    })).then((function(t) {
                        return t.sendRequest("updateStoryInitialPageId", i)
                    }))
                }
            }, i.getStories = function() {
                return this.yp
            }, i.buildPlayer = function() {
                this.el.tp || (this.Jp(), this.rp(), this.Gp(), this.Kp(), this.Qp(), this.Wp(this.yp.length - this.gp - 1), this.ev(), this.tm(), this.im(), this.nm(), this.rm(), this.sm(), this.el.tp = !0, this.om())
            }, i.om = function() {
                var t = this;
                this.t.document.addEventListener("keydown", (function(i) {
                    t.dh(i.key, "player")
                }), !0)
            }, i.Jp = function() {
                var t, i = this;
                ((t = this.el.querySelectorAll("a")) ? Array.prototype.slice.call(t) : []).forEach((function(t) {
                    var n = t.querySelector("img[data-amp-story-player-poster-img]"),
                        r = n && n.getAttribute("src"),
                        e = {
                            href: t.href,
                            title: t.textContent && t.textContent.trim() || t.getAttribute("story-title") || "Story Player iframe",
                            posterImage: t.getAttribute("data-poster-portrait-src") || r
                        };
                    i.Hp(e)
                }))
            }, i.sm = function() {
                this.el.dispatchEvent(ti(this.t, "ready", {})), this.el.isReady = !0
            }, i.Gp = function() {
                var t = this;
                this.yp.forEach((function(i) {
                    t.Bp(i)
                }))
            }, i.rp = function() {
                this.np = this.Xc.createElement("div"), this.np.classList.add("i-amphtml-story-player-main-container");
                var t = this.Xc.createElement("div");
                t.classList.add("i-amphtml-fill-content", "i-amphtml-story-player-shadow-root-intermediary"), this.el.appendChild(t);
                var i = this.el.attachShadow ? t.attachShadow({
                        mode: "open"
                    }) : t,
                    n = this.Xc.createElement("style");
                n.textContent = ':host{all:initial;color:initial}.story-player-iframe{background-color:#000;height:100%;width:100%;-ms-flex:0 0 100%;flex:0 0 100%;border:0;opacity:0;transition:opacity 500ms ease;position:absolute}.i-amphtml-story-player-main-container{height:100%;position:relative;overflow:hidden;transform-style:preserve-3d}.i-amphtml-story-player-loaded .story-player-iframe[content-loaded]{opacity:1;transition:transform 200ms cubic-bezier(0.4,0,0.2,1)}.i-amphtml-story-player-no-navigation-transition .story-player-iframe{transition-duration:0.01s}.i-amphtml-story-player-main-container .story-player-iframe[i-amphtml-iframe-position="0"],.i-amphtml-story-player-main-container iframe:first-of-type{transform:translateZ(0)}.i-amphtml-story-player-main-container .story-player-iframe[i-amphtml-iframe-position="1"],.i-amphtml-story-player-main-container iframe:nth-of-type(2),.i-amphtml-story-player-main-container iframe:nth-of-type(3){transform:translate3d(100%,0,0)}.i-amphtml-story-player-main-container .story-player-iframe[i-amphtml-iframe-position="-1"]{transform:translate3d(-100%,0,0)}.amp-story-player-exit-control-button{position:absolute;height:48px;width:48px;background-repeat:no-repeat;background-position:50%;margin-top:7px;background-size:28px;border:0px;background-color:transparent;outline:transparent;cursor:pointer;z-index:1}.amp-story-player-close-button{background-image:url(\'data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="%23FFF"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>\')}.amp-story-player-back-button{background-image:url(\'data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="%23FFF"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>\')}.amp-story-player-hide-button{display:none}.i-amphtml-story-player-panel{--i-amphtml-story-player-panel-ratio:9/16;--i-amphtml-story-player-panel-responsive-margin:max(74px,calc(var(--i-amphtml-story-player-height)*0.0825));--i-amphtml-story-player-panel-height:calc(var(--i-amphtml-story-player-height) - var(--i-amphtml-story-player-panel-responsive-margin)*2);--i-amphtml-story-player-panel-width:calc(var(--i-amphtml-story-player-panel-height)*var(--i-amphtml-story-player-panel-ratio));--i-amphtml-story-player-panel-button-margin:max(10px,calc(50vw - 145px - var(--i-amphtml-story-player-panel-width)/2))}.i-amphtml-story-player-panel.i-amphtml-story-player-panel-medium{--i-amphtml-story-player-panel-responsive-margin:0px;--i-amphtml-story-player-panel-width:calc(var(--i-amphtml-story-player-height)*var(--i-amphtml-story-player-panel-ratio))}.i-amphtml-story-player-panel.i-amphtml-story-player-panel-small{--i-amphtml-story-player-panel-ratio:9/16}.i-amphtml-story-player-panel-next,.i-amphtml-story-player-panel-prev{position:absolute;top:50%;transform:translateY(-50%);width:48px;height:48px;z-index:1;background-color:transparent;border:none;border-radius:50%;background-position:50%;background-repeat:no-repeat;cursor:pointer;transition:opacity 150ms}.i-amphtml-story-player-panel-next[disabled],.i-amphtml-story-player-panel-prev[disabled]{opacity:.1;cursor:initial}.i-amphtml-story-player-panel-next.hide-focus,.i-amphtml-story-player-panel-prev.hide-focus{outline:none}.i-amphtml-story-player-full-bleed-story .i-amphtml-story-player-panel-next,.i-amphtml-story-player-full-bleed-story .i-amphtml-story-player-panel-prev,.i-amphtml-story-player-panel-narrow .i-amphtml-story-player-panel-next,.i-amphtml-story-player-panel-narrow .i-amphtml-story-player-panel-prev,:not(.i-amphtml-story-player-panel)>.i-amphtml-story-player-panel-next,:not(.i-amphtml-story-player-panel)>.i-amphtml-story-player-panel-prev{opacity:0;pointer-events:none}.i-amphtml-story-player-panel-next,.i-amphtml-story-player-panel-prev{background-image:url(\'data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="none"><path stroke="%23fff" stroke-linecap="round" stroke-width="1.9" d="M17 29.2V18.8c0-1.2 1.4-2 2.5-1.3l7.5 5.2c1 .6 1 2 0 2.6l-7.5 5.2c-1 .7-2.5 0-2.5-1.3z"/><rect width="1.8" height="15.6" x="30.2" y="16.2" fill="%23fff" rx=".9"/></svg>\')!important}.i-amphtml-story-player-panel-prev{margin-inline-start:calc(var(--i-amphtml-story-player-panel-button-margin));transform:translateY(-50%) rotate(180deg)}.i-amphtml-story-player-panel-next{margin-inline-end:var(--i-amphtml-story-player-panel-button-margin);right:0}[dir=rtl].i-amphtml-story-player-panel-prev{right:0}[dir=rtl].i-amphtml-story-player-panel-next{left:0;transform:translateY(-50%) rotate(180deg)}\n/*# sourceURL=/css/amp-story-player-shadow.css*/', i.appendChild(n), i.insertBefore(this.np, i.firstElementChild)
            }, i.Kp = function() {
                var t = this,
                    i = this.el.getAttribute("exit-control");
                if ("back-button" === (n = i) || "close-button" === n) {
                    var n, r = this.Xc.createElement("button");
                    this.np.appendChild(r);
                    var e = "back-button" === i;
                    r.classList.add(e ? "amp-story-player-back-button" : "amp-story-player-close-button"), r.classList.add("amp-story-player-exit-control-button"), r.addEventListener("click", (function() {
                        t.el.dispatchEvent(ti(t.t, e ? "amp-story-player-back" : si, {
                            isAd: t.Fp,
                            trigger: Si
                        }))
                    }))
                }
            }, i.Qp = function() {
                return this.Ap || (this.Ap = function(t) {
                    var i = {},
                        n = t.getAttribute("amp-cache");
                    n && !xi.includes(n) && console.error("[".concat(t.tagName, "]"), "Unsupported cache specified, use one of following: ".concat(xi));
                    var r, e = t.querySelector("script");
                    if (!e) return null;
                    if (! function(t) {
                            var i;
                            return "SCRIPT" == t.tagName && "APPLICATION/JSON" == (null === (i = t.getAttribute("type")) || void 0 === i ? void 0 : i.toUpperCase())
                        }(e)) throw new Error('<script> child must have type="application/json"');
                    try {
                        r = e.textContent, i = JSON.parse(r)
                    } catch (i) {
                        console.error("[".concat(t.tagName, "] "), i)
                    }
                    return i
                }(this.el)), this.Ap
            }, i.Bp = function(t) {
                var i = this.Xc.createElement("iframe");
                Kt(i, "backgroundColor", "#000"), t.posterImage && Kt(i, "backgroundImage", t.posterImage), i.classList.add("story-player-iframe"), i.setAttribute("allow", "autoplay; web-share"), i.setAttribute("data-uc-allowed", "true"),
                    function(t) {
                        if (t.sandbox && t.sandbox.supports) {
                            for (var i = ["allow-top-navigation-by-user-activation", "allow-popups-to-escape-sandbox"], n = 0; n < i.length; n++) {
                                var r = i[n];
                                if (!t.sandbox.supports(r)) return void B().info("3p-frame", "Iframe doesn't support %s", r)
                            }
                            t.sandbox = i.join(" ") + " " + ["allow-forms", "allow-modals", "allow-pointer-lock", "allow-popups", "allow-same-origin", "allow-scripts"].join(" ")
                        }
                    }(i), this.am(i), this.hm(i), t.iframe = i
            }, i.am = function(t) {
                if (t.sandbox && t.sandbox.supports && !(t.sandbox.length <= 0))
                    for (var i = 0; i < Ei.length; i++) {
                        var n = Ei[i];
                        if (!t.sandbox.supports(n)) throw new Error("Iframe doesn't support: ".concat(n));
                        t.sandbox.add(n)
                    }
            }, i.um = function(t) {
                var i = this,
                    n = t.iframe;
                t.messagingPromise = new Promise((function(r) {
                    i.fm(t, n).then((function(n) {
                        n.setDefaultHandler((function() {
                            return X()
                        })), t.overrideAdConfig && n.sendRequest("updateStoryAdConfig", t.overrideAdConfig), t.initialPageId && n.sendRequest("updateStoryInitialPageId", t.initialPageId), null !== i.Rp && n.sendRequest("setInAppActionsHaveCustomBehaviour", i.Rp), n.registerHandler("updatePlayerAdvancementModeExcludingAds", (function(t, n) {
                            i.Yp = n
                        })), n.sendRequest("updateIsUserNavigatingQuickly", i.wp), n.registerHandler("touchstart", (function(t, n) {
                            i.lm(n)
                        })), n.registerHandler("touchmove", (function(t, n) {
                            i.pm(n)
                        })), n.registerHandler("touchend", (function(t, n) {
                            i.vm(n)
                        })), n.registerHandler("selectDocument", (function(t, n) {
                            i.dm(n)
                        })), n.registerHandler("storyPagesAppended", (function(n, r) {
                            var e = r.pages;
                            t.pages = e, i.el.dispatchEvent(ti(i.t, "storyPagesAppended", {
                                story: t
                            }))
                        })), n.registerHandler("storyContentLoaded", (function() {
                            t.storyContentLoaded = !0, i.ym(t.iframe, !0), i.gm(t)
                        })), n.registerHandler("storyContentLoading", (function() {
                            i.ym(t.iframe, !0)
                        })), n.registerHandler("onKeyDown", (function(t, n, r) {
                            i.dh(n, "story", r)
                        })), n.registerHandler("onClick", (function(t) {
                            i.bm(!0)
                        })), n.registerHandler("updateAdState", (function(t, n) {
                            i.Fp = n
                        })), n.registerHandler("closePlayer", (function(t, n) {
                            i.el.dispatchEvent(ti(i.t, si, {
                                isAd: i.Fp,
                                trigger: n
                            }))
                        })), n.registerHandler("updateHasUserSeenAnAd", (function(t, n) {
                            n !== i.Dp && i.wm(n)
                        })), n.registerHandler("updateNewPagesSinceLastAd", (function(t, n) {
                            n !== i.Np && i.xm(n)
                        })), n.registerHandler("updateNewPagesSinceLastStoryAd", (function(t, n) {
                            n !== i.Lp && i.Am(n)
                        })), n.registerHandler("story-page-visible", (function(t, n) {
                            var r = ti(i.t, t, G(G({}, n), {}, {
                                playerAdvancementModeExcludingAds: i.Yp
                            }));
                            i.el.dispatchEvent(r)
                        })), n.registerHandler("story-page-attachment-tap", (function(t, n) {
                            var r = ti(i.t, t, n);
                            i.el.dispatchEvent(r)
                        })), n.registerHandler("onStoryAdEvent", (function(t, n) {
                            var r = n.data,
                                e = n.eventType;
                            i.el.dispatchEvent(ti(i.t, e, r))
                        })), n.sendRequest("onDocumentState", {
                            "state": Ri
                        }, !1), n.sendRequest("onDocumentState", {
                            "state": Oi
                        }, !1), n.sendRequest("onDocumentState", {
                            "state": Mi
                        }), n.sendRequest("onDocumentState", {
                            "state": Ci
                        }), n.registerHandler("documentStateUpdate", (function(t, r) {
                            i.Sm(r, n)
                        })), i.Ap && i.Ap.controls && (i.km(t.idx), n.sendRequest("customDocumentUI", {
                            "controls": i.Ap.controls,
                            "actionButtonVisibility": i.Ap.display.actionButtonVisibility || "desktop",
                            "actionButtonPosition": i.Ap.display.actionButtonPosition || "right"
                        }, !1)), r(n)
                    }), (function(t) {
                        console.error("[".concat(Ui, "]"), t)
                    }))
                }))
            }, i.km = function(t) {
                if (t === this.yp.length - 1) {
                    var i = r(this.Ap.controls, (function(t) {
                        return "skip-next" === t.name || "skip-to-next" === t.name
                    }));
                    i >= 0 && (this.Ap.controls[i].state = "disabled")
                }
            }, i.ym = function(t, i) {
                i ? t.setAttribute("content-loaded", "") : t.removeAttribute("content-loaded")
            }, i.fm = function(t, i) {
                var n = this;
                return this.Pm(t.href).then((function(t) {
                    return Yt.waitForHandshakeFromDocument(n.t, i.contentWindow, n.Im(t).origin, null, P)
                }))
            }, i.hm = function(t) {
                var i = this;
                this.np.classList.add(ki), t.onload = function() {
                    i.np.classList.remove(ki), i.np.classList.add(Pi), i.el.classList.add(Pi)
                }, t.onerror = function() {
                    i.np.classList.remove(ki), i.np.classList.add(Ii), i.el.classList.add(Ii)
                }
            }, i.layoutPlayer = function() {
                var t = this;
                if (!this.el.ip) {
                    if (new ei(this.t, this.el, (function() {
                            return t.Ip.resolve()
                        })), this.t.ResizeObserver) new this.t.ResizeObserver((function(i) {
                        var n = i[0].contentRect,
                            r = n.height,
                            e = n.width;
                        t.Em(r, e)
                    })).observe(this.el);
                    else {
                        var i = this.el.getBoundingClientRect(),
                            n = i.height,
                            r = i.width;
                        this.Em(n, r)
                    }
                    this.fa(), this.el.ip = !0
                }
            }, i.rm = function() {
                var t = this;
                this.Tp = this.Xc.createElement("button"), this.Tp.classList.add("i-amphtml-story-player-panel-prev"), this.Tp.addEventListener("click", (function() {
                    t.Yp = Ai, t.bm(!1), t.jm()
                })), this.Tp.setAttribute("aria-label", "previous story"), this.np.appendChild(this.Tp), this.Up = this.Xc.createElement("button"), this.Up.classList.add("i-amphtml-story-player-panel-next"), this.Up.addEventListener("click", (function() {
                    t.Yp = Ai, t.bm(!1), t.vo()
                })), this.Up.setAttribute("aria-label", "next story"), this.np.appendChild(this.Up), this.Rm()
            }, i.bm = function(t) {
                var i = "hide-focus";
                this.Tp.classList.toggle(i, !t), this.Up.classList.toggle(i, !t)
            }, i.Rm = function() {
                Zt(this.Tp, "disabled", this.Cm(this.gp - 1) && !this.kp);
                var t = this.Cm(this.gp + 1) || !this.Mm(this.gp + 1);
                Zt(this.Up, "disabled", t && !this.kp)
            }, i.Em = function(t, i) {
                var n = i / t > .775;
                this.np.classList.toggle("i-amphtml-story-player-panel", n), n && (Qt(this.np, {
                    "--i-amphtml-story-player-height": "".concat(t, "px")
                }), this.np.classList.toggle("i-amphtml-story-player-panel-narrow", i < 700), this.np.classList.toggle("i-amphtml-story-player-panel-medium", t < 757), this.np.classList.toggle("i-amphtml-story-player-panel-small", t < 538))
            }, i.Om = function() {
                var t = this.Ap.behavior.endpoint;
                return t ? (t = t.replace(/\${offset}/, this.yp.length.toString()), fetch(t, {
                    method: "GET",
                    headers: {
                        Accept: "application/json"
                    }
                }).then((function(t) {
                    return t.json()
                })).catch((function(t) {
                    console.error("[".concat(Ui, "]"), t)
                }))) : (this.Sp = !1, X())
            }, i.show = function(t) {
                var i = this,
                    n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                    r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    e = this.Tm(t),
                    s = X(),
                    o = !0;
                return e.idx === this.gp && null != n ? s.then((function() {
                    return i.Um(n, o)
                })) : (e.idx !== this.gp && (this.gp = e.idx, s = this.fa(e.idx, n, o), !1 === r.animate && (this.np.classList.toggle(Ti, !0), ii(e.iframe, "transitionend", (function() {
                    i.np.classList.remove(Ti)
                })))), this.zm(), s)
            }, i.resetCurrentPage = function() {
                this.yp[this.gp].messagingPromise.then((function(t) {
                    return t.sendRequest("resetCurrentPage")
                }))
            }, i.mute = function() {
                var t = this.yp[this.gp];
                this.Dm(t, !0)
            }, i.unmute = function() {
                var t = this.yp[this.gp];
                this.Dm(t, !1)
            }, i.getStoryState = function(t) {
                "page-attachment" === t && this.Nm()
            }, i.qm = function(t) {
                var i = ti(this.t, "navigation", G(G({}, t), {}, {
                    playerAdvancementModeExcludingAds: this.Yp
                }));
                this.el.dispatchEvent(i)
            }, i.zm = function() {
                var t = this,
                    i = this.gp,
                    n = this.yp.length - this.gp - 1,
                    r = {
                        "index": i,
                        "remaining": n
                    };
                this.Rm(), this.Lm().then((function(i) {
                    return t._m(i)
                })), this.qm(r), this.Wp(n), this.Fm()
            }, i.Lm = function() {
                var t = this.yp[this.gp];
                return new Promise((function(i) {
                    t.messagingPromise.then((function(t) {
                        t.sendRequest("getDocumentState", {
                            state: Ci
                        }, !0).then((function(t) {
                            return i(t.value)
                        }))
                    }))
                }))
            }, i._m = function(t) {
                var i = 2 === t || 0 === t;
                this.np.classList.toggle("i-amphtml-story-player-full-bleed-story", i)
            }, i.Wp = function(t) {
                var i = this;
                this.Ap && this.Ap.behavior && this.Ym() && t <= 2 && this.Om().then((function(t) {
                    t && i.add(t)
                })).catch((function(t) {
                    console.error("[".concat(Ui, "]"), t)
                }))
            }, i.Hm = function() {
                var t = Date.now(),
                    i = t - this.bp;
                this.Bm(i < 500), this.bp = t
            }, i.Bm = function(t) {
                var i = this;
                this.wp = t, this.Vm(t), t && setTimeout((function() {
                    i.wp && Date.now() - i.bp >= 500 && (i.wp = !1, i.Vm(!1))
                }), 501)
            }, i.Vm = function(t) {
                this.yp.filter((function(t) {
                    return !!t.messagingPromise
                })).forEach((function(i) {
                    i.messagingPromise.then((function(i) {
                        i.sendRequest("updateIsUserNavigatingQuickly", t)
                    }))
                }))
            }, i.$m = function(t) {
                return t && t.on && t.action
            }, i.Ym = function() {
                if (null !== this.Sp) return this.Sp;
                var t, i = this.Ap.behavior;
                return this.Sp = this.$m(i) && "end" === (t = i).on && "fetch" === t.action && t.endpoint, this.Sp
            }, i.vo = function() {
                !this.kp && this.Cm(this.gp + 1) || (this.kp && this.Cm(this.gp + 1) ? this.go(1) : (this.gp++, this.fa(), this.zm()))
            }, i.jm = function() {
                !this.kp && this.Cm(this.gp - 1) || (this.kp && this.Cm(this.gp - 1) ? this.go(-1) : (this.gp--, this.fa(), this.zm()))
            }, i.go = function(t) {
                var i, n, r = this,
                    e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                if ("string" == typeof t ? n = (i = this.Xp(t)) - this.gp : (n = t, i = this.gp + n), 0 !== n || 0 !== e) {
                    if (!this.kp && this.Cm(i)) throw new Error("Out of Story range.");
                    var o = n > 0 ? this.yp[i % this.yp.length] : this.yp[(i % this.yp.length + this.yp.length) % this.yp.length],
                        a = X();
                    this.gp !== o.idx && (a = this.show(o.href, null, s)), a.then((function() {
                        r.Xm(e)
                    }))
                }
            }, i.Zm = function(t) {
                var i = 0 === t.distance ? 0 : t.idx > this.gp ? 1 : -1;
                requestAnimationFrame((function() {
                    var n = t.iframe;
                    Wt(n, ["transform", "transition"]), n.setAttribute("i-amphtml-iframe-position", i)
                }))
            }, i.Vp = function() {
                if (this.Mp) {
                    this.Mp = !1;
                    var t = this.yp.filter((function(t) {
                            return !!t.messagingPromise
                        })),
                        i = this.Jm();
                    t.forEach((function(t) {
                        var n = i.some((function(i) {
                            return t.href.includes(i)
                        }));
                        t.messagingPromise.then((function(t) {
                            t.sendRequest("playerClose", n)
                        }))
                    }))
                }
            }, i.Jm = function() {
                var t = {};
                if (this.t.localStorage.getItem("Storyteller.storiesReadMap")) try {
                    t = JSON.parse(this.t.localStorage.getItem("Storyteller.storiesReadMap"))
                } catch (t) {}
                return Object.keys(t).filter((function(i) {
                    return "read" === t[i].status
                })) || []
            }, i.gm = function(t) {
                var i = this;
                t.messagingPromise.then((function(n) {
                    n.sendRequest("getDocumentState", {
                        state: "DESKTOP_ASPECT_RATIO"
                    }, !0).then((function(n) {
                        t.desktopAspectRatio = n.value, i.Gm()
                    }))
                }))
            }, i.Gm = function() {
                this.yp[this.gp].desktopAspectRatio && Qt(this.np, {
                    "--i-amphtml-story-player-panel-ratio": this.yp[this.gp].desktopAspectRatio
                })
            }, i.Km = function(t) {
                var i, n = this;
                return this.yp[this.gp].storyContentLoaded ? (this.ym(t.iframe, !0), this.Gm(), X()) : 0 !== t.distance ? this.Pp.promise : (null === (i = this.Pp) || void 0 === i || i.reject("[".concat(zi, "] Cancelling previous story load promise.")), this.Pp = new Z, t.messagingPromise.then((function(i) {
                    return i.registerHandler("storyContentLoaded", (function() {
                        t.storyContentLoaded = !0, n.Pp.resolve(), n.ym(t.iframe, !0), n.gm(t)
                    }))
                })), X())
            }, i.fa = function() {
                for (var t = this, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.gp, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, r = arguments.length > 2 ? arguments[2] : void 0, e = [], s = function(s) {
                        var o = t.yp[(s + i) % t.yp.length],
                            a = o.distance;
                        o.distance = Math.abs(t.gp - o.idx), a <= 1 && o.distance > 1 && t.Qm(o);
                        var h = i === o.idx && o.iframe.isConnected && !o.iframe.hasAttribute("content-loaded") && !o.storyContentLoaded;
                        if ((o.distance <= 1 && !o.iframe.isConnected || h) && t.Wm(o), o.distance > 1) return "continue";
                        1 !== o.distance || t.yp[i].storyContentLoaded || (t.Zm(o), 0 === a && t.$p(o, $t.INACTIVE)), e.push(t.Km(o).then((function() {
                            return t.Pm(o.href)
                        })).then((function(i) {
                            t.Yd(i, o.iframe.src) || t.$d(o, i)
                        })).then((function() {
                            return t.Ip.promise
                        })).then((function() {
                            null != n && t.Um(n, r), 0 === o.distance && t.Cp && t.$p(o, $t.VISIBLE), 1 === o.distance && 0 === a && t.$p(o, $t.INACTIVE)
                        })).then((function() {
                            t.Zm(o), o.messagingPromise.then((function(t) {
                                return t.sendRequest("syncIsActivePlayerStory", 0 === o.distance, !1)
                            }))
                        })).catch((function(t) {
                            t.includes(zi) || console.error("[".concat(Ui, "]"), t)
                        })))
                    }, o = 0; o < this.yp.length; o++) s(o);
                return Promise.all(e)
            }, i.Wm = function(t) {
                this.np.appendChild(t.iframe), this.um(t), t.connectedDeferred.resolve()
            }, i.dh = function(t, i) {
                var n = this.yp[this.gp],
                    r = "manualAdvance",
                    e = Ai;
                switch (t) {
                    case "Escape":
                        this.el.dispatchEvent(ti(this.t, "amp-story-player-keypress", {
                            key: t,
                            source: i
                        }));
                        break;
                    case "ArrowLeft":
                        this.Yp = e, n.messagingPromise.then((function(t) {
                            return t.sendRequest("selectPage", {
                                advancementMode: r,
                                previous: !0
                            })
                        }));
                        break;
                    case "ArrowRight":
                        this.Yp = e, n.messagingPromise.then((function(t) {
                            return t.sendRequest("selectPage", {
                                advancementMode: r,
                                next: !0
                            })
                        }));
                        break;
                    default:
                        this.bm(!0)
                }
            }, i.Qm = function(t) {
                t.storyContentLoaded = !1, t.connectedDeferred = new Z, t.iframe.setAttribute("src", ""), t.iframe.remove(), this.ym(t.iframe, !1)
            }, i.$d = function(t, i) {
                var n = t.iframe,
                    r = this.Im(i, $t.PRERENDER).href;
                n.setAttribute("src", r), t.title && n.setAttribute("title", t.title)
            }, i.Yd = function(t, i) {
                return !(!i || i.length <= 0) && li(mi(i)) === li(mi(t))
            }, i.Pm = function(t) {
                var i = this.el.getAttribute("amp-cache");
                if (!i || !xi.includes(i)) return Promise.resolve(t);
                if (vi(t)) {
                    var n = hi(t);
                    return n.pathname.startsWith("/c/") && (n.pathname = "/v/" + n.pathname.substr(3)), Promise.resolve(n.toString())
                }
                return function(t, i) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                        r = new bt(i),
                        e = Dt(r.pathname, n);
                    return e += "https:" === r.protocol ? "/s/" : "/", i.endsWith("/") || (r.pathname = r.pathname.replace(/\/$/, "")), Ot(r.toString()).then((function(n) {
                        var s = new bt(i);
                        return s.protocol = "https", n = n + "." + t, s.host = n, s.hostname = n, s.pathname = e + r.hostname + r.pathname, s.toString()
                    }))
                }(i, t, "viewer").then((function(t) {
                    return t
                }))
            }, i.Im = function(t) {
                var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : $t.INACTIVE,
                    n = {
                        "visibilityState": i,
                        "origin": this.t.origin,
                        "showStoryUrlInfo": "0",
                        "storyPlayer": "v0",
                        "cap": "swipe"
                    };
                "visible" === this.Op && (n.icon = "visible");
                var r = pi(t),
                    e = A(r),
                    s = G(G({}, e), n),
                    o = li(t);
                if (vi(t)) {
                    var a = {
                        "amp_js_v": "0.1"
                    };
                    o = fi(o, a)
                }
                var h = o + "#" + ci(s);
                return ui(this.dp, h)
            }, i.$p = function(t, i, n) {
                t.messagingPromise.then((function(t) {
                    return t.sendRequest("visibilitychange", {
                        state: i,
                        lightboxState: n
                    }, !0)
                }))
            }, i.Xd = function(t, i, n) {
                t.messagingPromise.then((function(t) {
                    t.sendRequest("setDocumentState", {
                        state: i,
                        value: n
                    })
                }))
            }, i.Fm = function() {
                var t = this;
                this.yp[this.gp].messagingPromise.then((function(i) {
                    i.sendRequest("setInitialPagesSinceLastAdAndLastStoryAd", {
                        newPagesSinceLastAd: t.Np,
                        newPagesSinceLastStoryAd: t.Lp
                    }, !1)
                }))
            }, i.Dm = function(t, i) {
                this.Xd(t, Mi, i)
            }, i.Nm = function() {
                var t = this;
                this.yp[this.gp].messagingPromise.then((function(i) {
                    i.sendRequest("getDocumentState", {
                        state: Ri
                    }, !0).then((function(i) {
                        return t.Zd(i.value)
                    }))
                }))
            }, i.Um = function(t) {
                var i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = this.yp[this.gp];
                n.messagingPromise.then((function(n) {
                    return n.sendRequest("selectPage", {
                        id: t,
                        logsDisabled: i
                    })
                }))
            }, i.Tm = function(t) {
                var i = t ? r(this.yp, (function(i) {
                    return i.href === t
                })) : this.gp;
                if (!this.yp[i]) throw new Error("Story URL not found in the player: ".concat(t));
                return this.yp[i]
            }, i.rewind = function(t) {
                var i = this.Tm(t);
                this.Zp(i).then((function() {
                    return i.messagingPromise
                })).then((function(t) {
                    return t.sendRequest("rewind", {})
                }))
            }, i.Zp = function(t) {
                return t.iframe.isConnected ? X() : t.connectedDeferred.promise
            }, i.Xm = function(t) {
                0 !== t && this.Jd(t)
            }, i.Jd = function(t) {
                this.yp[this.gp].messagingPromise.then((function(i) {
                    return i.sendRequest("selectPage", {
                        delta: t
                    })
                }))
            }, i.Sm = function(t, i) {
                switch (t.state) {
                    case Ri:
                        this.Kd(t.value);
                        break;
                    case Oi:
                        this.Qd(t.value, i);
                        break;
                    case Mi:
                        this.Wd(t.value);
                        break;
                    case Ci:
                        this._m(t.value);
                        break;
                    case "AMP_STORY_PLAYER_EVENT":
                        this.ty(t.value);
                        break;
                    case "AMP_STORY_COPY_URL":
                        this.iy(t.value, i)
                }
            }, i.ty = function(t) {
                switch (t) {
                    case "amp-story-player-skip-next":
                    case "amp-story-player-skip-to-next":
                        this.vo();
                        break;
                    case si:
                        this.el.dispatchEvent(ti(this.t, t, {
                            isAd: this.Fp,
                            trigger: Si
                        }));
                        break;
                    default:
                        this.el.dispatchEvent(ti(this.t, t, {}))
                }
            }, i.iy = function(t, i) {
                var n, r, e, s, o;
                n = this.t, r = t, e = function() {
                    i.sendRequest("copyComplete", {
                        "success": !0,
                        "url": t
                    }, !1)
                }, s = function() {
                    i.sendRequest("copyComplete", {
                        "success": !1
                    }, !1)
                }, null !== (o = n.navigator) && void 0 !== o && o.clipboard ? n.navigator.clipboard.writeText(r).then(e, s) : n.document.queryCommandSupported("copy") && function(t, i) {
                    var n, r, e, s = !1,
                        o = t.document,
                        a = o.createElement("textarea");
                    Qt(a, {
                        "position": "fixed",
                        "top": 0,
                        "left": 0,
                        "width": "50px",
                        "height": "50px",
                        "padding": 0,
                        "border": "none",
                        "outline": "none",
                        "background": "transparent"
                    }), a.value = i, a.readOnly = !0, a.contentEditable = "true", o.body.appendChild(a), null === (n = t.getSelection()) || void 0 === n || n.removeAllRanges(), a.focus(), a.setSelectionRange(0, i.length);
                    try {
                        s = o.execCommand("copy")
                    } catch (t) {}
                    return null === (e = (r = a).parentElement) || void 0 === e || e.removeChild(r), s
                }(n, r) ? e() : s()
            }, i.Wd = function(t) {
                this.el.dispatchEvent(ti(this.t, "amp-story-muted-state", {
                    muted: t
                }))
            }, i.Qd = function(t, i) {
                var n = this;
                t && this.Hm(), i.sendRequest("getDocumentState", {
                    "state": "STORY_PROGRESS"
                }, !0).then((function(i) {
                    n.el.dispatchEvent(ti(n.t, "storyNavigation", {
                        "pageId": t,
                        "progress": i.value,
                        playerAdvancementModeExcludingAds: n.Yp
                    }))
                }))
            }, i.Kd = function(t) {
                this.ny(!t), this.zp = t, this.Zd(t)
            }, i.ny = function(t) {
                var i = this.np.querySelector("button.amp-story-player-exit-control-button");
                i && (t ? i.classList.remove(ji) : i.classList.add(ji))
            }, i.Zd = function(t) {
                this.el.dispatchEvent(ti(this.t, t ? "page-attachment-open" : "page-attachment-close", {}))
            }, i.dm = function(t) {
                this.ey(t), t.next ? this.vo() : t.previous && this.jm()
            }, i.ey = function(t) {
                var i, n;
                this.kp || !t.next && !t.previous || (t.next ? (i = this.gp + 1 === this.yp.length, n = "noNextStory") : (i = 0 === this.gp, n = "noPreviousStory"), i && this.el.dispatchEvent(ti(this.t, n, {
                    playerAdvancementModeExcludingAds: this.Yp
                })))
            }, i.lm = function(t) {
                var i = this.sy(t);
                i && (this.fp.startX = i.screenX, this.fp.startY = i.screenY, this.jp && this.jp.onTouchStart(t.timeStamp, i.clientY), this.el.dispatchEvent(ti(this.t, "amp-story-player-touchstart", {
                    "touches": t.touches
                })))
            }, i.pm = function(t) {
                var i = this.sy(t);
                if (i)
                    if (this.el.dispatchEvent(ti(this.t, "amp-story-player-touchmove", {
                            "touches": t.touches,
                            "isNavigationalSwipe": this.fp.isSwipeX
                        })), !1 !== this.fp.isSwipeX) {
                        var n = i.screenX,
                            r = i.screenY;
                        this.fp.lastX = n, (null !== this.fp.isSwipeX || (this.fp.isSwipeX = Math.abs(this.fp.startX - n) > Math.abs(this.fp.startY - r), this.fp.isSwipeX)) && this.oy({
                            deltaX: n - this.fp.startX,
                            last: !1
                        })
                    } else this.jp && this.jp.onTouchMove(t.timeStamp, i.clientY)
            }, i.vm = function(t) {
                this.el.dispatchEvent(ti(this.t, "amp-story-player-touchend", {
                    "touches": t.touches,
                    "isNavigationalSwipe": this.fp.isSwipeX
                })), !0 === this.fp.isSwipeX ? this.oy({
                    deltaX: this.fp.lastX - this.fp.startX,
                    last: !0
                }) : this.jp && this.jp.onTouchEnd(t.timeStamp), this.fp.startX = 0, this.fp.startY = 0, this.fp.lastX = 0, this.fp.isSwipeX = null, this.xp = 0
            }, i.oy = function(t) {
                if (!(this.yp.length <= 1 || this.zp)) {
                    var i = t.deltaX;
                    if (!0 === t.last) {
                        var n = Math.abs(i);
                        return 1 === this.xp && (n > 50 && (this.hy() || this.kp) ? this.vo() : this.uy()), void(2 === this.xp && (n > 50 && (this.hy() || this.kp) ? this.jm() : this.uy()))
                    }
                    this.ly(i)
                }
            }, i.uy = function() {
                var t = this.yp[this.gp].iframe;
                requestAnimationFrame((function() {
                    Wt(Ht(t), ["transform", "transition"])
                }));
                var i = this.hy();
                i && requestAnimationFrame((function() {
                    Wt(Ht(i.iframe), ["transform", "transition"])
                }))
            }, i.hy = function() {
                var t = 1 === this.xp ? this.gp + 1 : this.gp - 1;
                return this.Cm(t) ? null : this.yp[t]
            }, i.Cm = function(t) {
                return t >= this.yp.length || t < 0
            }, i.Mm = function(t) {
                var i;
                if (null === (i = this.Ap.behavior.playAllStories) || void 0 === i || i) return !0;
                var n = this.yp[this.gp],
                    r = this.yp[t];
                if (!n || !r) return !0;
                var e = this.Jm();
                return e.some((function(t) {
                    return n.href.includes(t)
                })) === e.some((function(t) {
                    return r.href.includes(t)
                }))
            }, i.ev = function() {
                if (this.Ap) {
                    var t = this.Ap.behavior;
                    t && "boolean" == typeof t.autoplay && (this.Cp = t.autoplay)
                }
            }, i.tm = function() {
                if (this.Ap) {
                    var t = this.Ap.display;
                    t && "visible" === t.icon && (this.Op = "visible")
                }
            }, i.im = function() {
                if (this.Ap) {
                    var t = this.Ap.behavior;
                    t && !1 === t.pageScroll && (this.jp = null)
                }
            }, i.nm = function() {
                if (null !== this.kp) return this.kp;
                if (!this.Ap) return this.kp = !1, !1;
                var t, i = this.Ap.behavior;
                return this.kp = this.$m(i) && "end" === (t = i).on && "circular-wrapping" === t.action, this.kp
            }, i.ly = function(t) {
                var i;
                t < 0 ? (this.xp = 1, i = "translate3d(calc(100% + ".concat(t, "px), 0, 0)")) : (this.xp = 2, i = "translate3d(calc(".concat(t, "px - 100%), 0, 0)"));
                var n = this.yp[this.gp].iframe,
                    r = "translate3d(".concat(t, "px, 0, 0)");
                requestAnimationFrame((function() {
                    Qt(Ht(n), {
                        transform: r,
                        transition: "none"
                    })
                }));
                var e = this.hy();
                e && requestAnimationFrame((function() {
                    Qt(Ht(e.iframe), {
                        transform: i,
                        transition: "none"
                    })
                }))
            }, i.sy = function(t) {
                var i = t.touches;
                if (!i || i.length < 1) return null;
                var n = i[0],
                    r = n.clientX,
                    e = n.clientY;
                return {
                    screenX: n.screenX,
                    screenY: n.screenY,
                    clientX: r,
                    clientY: e
                }
            }, i.wm = function(t) {
                this.Dp = t;
                for (var i, n = o(this.yp.filter((function(t) {
                        return !!t.messagingPromise
                    })), !0); !(i = n()).done;) i.value.messagingPromise.then((function(i) {
                    i.sendRequest("updateHasUserSeenAnAd", t, !1)
                }))
            }, i.xm = function(t) {
                var i = this,
                    n = Date.now() - this.qp >= Di || t < this.Np;
                this.Np = t, this.qp = Date.now(), n ? this.yp.filter((function(t) {
                    return !!t.messagingPromise
                })).forEach((function(i) {
                    i.messagingPromise.then((function(i) {
                        i.sendRequest("syncNewPagesSinceLastAd", t, !1)
                    }))
                })) : setTimeout((function() {
                    i.Np === t && i.yp.filter((function(t) {
                        return !!t.messagingPromise
                    })).forEach((function(i) {
                        i.messagingPromise.then((function(i) {
                            i.sendRequest("syncNewPagesSinceLastAd", t, !1)
                        }))
                    }))
                }), Di)
            }, i.Am = function(t) {
                var i = this,
                    n = Date.now() - this._p >= Di || t < this.Lp;
                this.Lp = t, this._p = Date.now(), n ? this.yp.filter((function(t) {
                    return !!t.messagingPromise
                })).forEach((function(i) {
                    i.messagingPromise.then((function(i) {
                        i.sendRequest("syncNewPagesSinceLastStoryAd", t, !1)
                    }))
                })) : setTimeout((function() {
                    i.Lp === t && i.yp.filter((function(t) {
                        return !!t.messagingPromise
                    })).forEach((function(i) {
                        i.messagingPromise.then((function(i) {
                            i.sendRequest("syncNewPagesSinceLastStoryAd", t, !1)
                        }))
                    }))
                }), Di)
            }, t
        }(),
        qi = function() {
            function t(t) {
                this.t = t
            }
            var i = t.prototype;
            return i.py = function(t) {
                var i = this;
                new ei(this.t, t, (function() {
                    return t.layoutPlayer()
                })), this.t.addEventListener("scroll", (function n() {
                    t.layoutPlayer(), i.t.removeEventListener("scroll", n)
                }))
            }, i.loadPlayers = function() {
                var t = this.t.document.getElementsByTagName("amp-story-player");
                F();
                for (var i = 0; i < t.length; i++) {
                    var n = t[i],
                        r = new Ni(this.t, n);
                    r.buildPlayer(), this.py(r)
                }
            }, i.loadEntryPoints = function() {
                var t = this.t.document.getElementsByTagName("amp-story-entry-point");
                F();
                for (var i = 0; i < t.length; i++) {
                    var n = t[i],
                        r = new $(this.t, n);
                    r.buildCallback(), this.py(r)
                }
            }, t
        }();
    yi = self.document, gi = function(t) {
        return "loading" != t.readyState && "uninitialized" != t.readyState
    }, bi = function() {
        new qi(self).loadPlayers()
    }, (wi = gi(yi)) ? bi() : yi.addEventListener("readystatechange", (function t() {
        gi(yi) && (wi || (wi = !0, bi()), yi.removeEventListener("readystatechange", t))
    })), globalThis.AmpStoryPlayer = Ni
}();
/*! https://mths.be/cssescape v1.5.1 by @mathias | MIT license */
//# sourceMappingURL=amp-story-player-v0.js.map