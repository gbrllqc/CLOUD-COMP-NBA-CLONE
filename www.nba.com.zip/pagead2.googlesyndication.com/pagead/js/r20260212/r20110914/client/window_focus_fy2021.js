(function() {
    'use strict';

    function f(a = document) {
        return a.createElement("img")
    };

    function g(a, b, e) {
        typeof a.addEventListener === "function" && a.addEventListener(b, e, !1)
    };
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    function l(a, b, e = null, c = !1) {
        m(a, b, e, c)
    }

    function m(a, b, e, c) {
        a.google_image_requests || (a.google_image_requests = []);
        const d = f(a.document);
        if (e || c) {
            const k = h => {
                e && e(h);
                if (c) {
                    h = a.google_image_requests;
                    const u = Array.prototype.indexOf.call(h, d, void 0);
                    u >= 0 && Array.prototype.splice.call(h, u, 1)
                }
                typeof d.removeEventListener === "function" && d.removeEventListener("load", k, !1);
                typeof d.removeEventListener === "function" && d.removeEventListener("error", k, !1)
            };
            g(d, "load", k);
            g(d, "error", k)
        }
        d.src = b;
        a.google_image_requests.push(d)
    };

    function n(a = null) {
        return a && a.getAttribute("data-jc") === "22" ? a : document.querySelector('[data-jc="22"]')
    };
    var p = document,
        q = window;

    function r(a, b, e) {
        if (Array.isArray(b))
            for (let c = 0; c < b.length; c++) r(a, String(b[c]), e);
        else b != null && e.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    };

    function t(a) {
        return typeof a !== "undefined"
    }

    function v(a) {
        g(p, a.h, () => {
            if (p[a.g]) a.i && (a.i = !1, a.j = Date.now(), w(a, 0));
            else {
                if (a.j !== -1) {
                    const b = Date.now() - a.j;
                    b > 0 && (a.j = -1, w(a, 1, b))
                }
                w(a, 3)
            }
        })
    }

    function x(a) {
        g(q, "click", b => {
            a.handleClick(b)
        })
    }

    function w(a, b, e = 0) {
        var c = {
            gqid: a.m,
            qqid: a.o
        };
        b === 0 && (c["return"] = 0);
        b === 1 && (c["return"] = 1, c.timeDelta = e);
        b === 2 && (c.bgload = 1);
        b === 3 && (c.fg = 1);
        b = [];
        for (var d in c) r(d, c[d], b);
        l(q, a.l + "&label=window_focus&" + b.join("&"));
        if (!(Math.random() > .01)) {
            a = (a = n(document.currentScript)) && a.getAttribute("data-jc-rcd") === "true" ? "pagead2.googlesyndication-cn.com" : "pagead2.googlesyndication.com";
            c = (c = n(document.currentScript)) && c.getAttribute("data-jc-version") || "unknown";
            a = `https://${a}/pagead/gen_204?id=jca&jc=${22}&version=${c}&sample=${.01}`;
            c = window;
            if (d = c.navigator) d = c.navigator.userAgent, d = /Chrome/.test(d) && !/Edge/.test(d) ? !0 : !1;
            d && typeof c.navigator.sendBeacon === "function" ? c.navigator.sendBeacon(a) : l(c, a, void 0, !1)
        }
    }
    var z = class {
        constructor() {
            var a = y["gws-id"],
                b = y["qem-id"];
            this.l = y.url;
            this.m = a;
            this.o = b;
            this.i = !1;
            a = t(p.hidden) ? {
                g: "hidden",
                h: "visibilitychange"
            } : t(p.mozHidden) ? {
                g: "mozHidden",
                h: "mozvisibilitychange"
            } : t(p.msHidden) ? {
                g: "msHidden",
                h: "msvisibilitychange"
            } : t(p.webkitHidden) ? {
                g: "webkitHidden",
                h: "webkitvisibilitychange"
            } : {
                g: "hidden",
                h: "visibilitychange"
            };
            this.g = a.g;
            this.h = a.h;
            this.j = -1;
            p[this.g] && w(this, 2);
            v(this);
            x(this)
        }
        handleClick() {
            this.i = !0;
            q.setTimeout(() => {
                this.i = !1
            }, 5E3)
        }
    };
    const A = n(document.currentScript);
    if (A == null) throw Error("JSC not found 22");
    var y;
    const B = {},
        C = A.attributes;
    for (let a = C.length - 1; a >= 0; a--) {
        const b = C[a].name;
        b.indexOf("data-jcp-") === 0 && (B[b.substring(9)] = C[a].value)
    }
    y = B;
    window.window_focus_for_click = new z;
}).call(this);