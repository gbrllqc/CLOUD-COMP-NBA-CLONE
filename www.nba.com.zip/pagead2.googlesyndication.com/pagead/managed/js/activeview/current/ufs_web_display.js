(function() {
    var n, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        },
        da = ca(this),
        ea = "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(" ");
    da.BigInt64Array && (ea.push("BigInt64"), ea.push("BigUint64"));
    var ia = function(a, b) {
            if (b)
                for (var c = 0; c < ea.length; c++) ha(ea[c] + "Array.prototype." + a, b)
        },
        p = function(a, b) {
            b && ha(a, b)
        },
        ha = function(a, b) {
            var c = da;
            a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) return;
                c = c[e]
            }
            a = a[a.length - 1];
            d = c[a];
            b = b(d);
            b != d && b != null && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        },
        ja;
    if (typeof Object.setPrototypeOf == "function") ja = Object.setPrototypeOf;
    else {
        var ka;
        a: {
            var la = {
                    a: !0
                },
                na = {};
            try {
                na.__proto__ = la;
                ka = na.a;
                break a
            } catch (a) {}
            ka = !1
        }
        ja = ka ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError("b`" + a);
            return a
        } : null
    }
    var oa = ja,
        q = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (oa) oa(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.ij = b.prototype
        },
        pa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        x = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: pa(a)
            };
            throw Error("c`" + String(a));
        },
        y = function(a) {
            if (!(a instanceof Array)) {
                a = x(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ra = function(a) {
            return qa(a, a)
        },
        qa = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        sa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ta = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("d");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) sa(d,
                        e) && (a[e] = d[e])
            }
            return a
        };
    p("Object.assign", function(a) {
        return a || ta
    });
    var ua = function(a) {
            if (!(a instanceof Object)) throw new TypeError("e`" + a);
        },
        A = function() {
            this.Cc = !1;
            this.Pa = null;
            this.V = void 0;
            this.u = 1;
            this.Ja = this.gb = 0;
            this.se = this.ea = null
        };
    A.prototype.Na = function() {
        if (this.Cc) throw new TypeError("f");
        this.Cc = !0
    };
    A.prototype.Lc = function(a) {
        this.V = a
    };
    A.prototype.Wc = function(a) {
        this.ea = {
            Rf: a,
            og: !0
        };
        this.u = this.gb || this.Ja
    };
    A.prototype.getNextAddressJsc = function() {
        return this.u
    };
    A.prototype.getYieldResultJsc = function() {
        return this.V
    };
    A.prototype.return = function(a) {
        this.ea = {
            return: a
        };
        this.u = this.Ja
    };
    A.prototype["return"] = A.prototype.return;
    A.prototype.ki = function(a) {
        this.ea = {
            na: a
        };
        this.u = this.Ja
    };
    A.prototype.jumpThroughFinallyBlocks = A.prototype.ki;
    A.prototype.A = function(a, b) {
        this.u = b;
        return {
            value: a
        }
    };
    A.prototype.yield = A.prototype.A;
    A.prototype.tj = function(a, b) {
        a = x(a);
        var c = a.next();
        ua(c);
        if (c.done) this.V = c.value, this.u = b;
        else return this.Pa = a, this.A(c.value, b)
    };
    A.prototype.yieldAll = A.prototype.tj;
    A.prototype.na = function(a) {
        this.u = a
    };
    A.prototype.jumpTo = A.prototype.na;
    A.prototype.Tb = function() {
        this.u = 0
    };
    A.prototype.jumpToEnd = A.prototype.Tb;
    A.prototype.Ab = function(a, b) {
        this.gb = a;
        b != void 0 && (this.Ja = b)
    };
    A.prototype.setCatchFinallyBlocks = A.prototype.Ab;
    A.prototype.bf = function(a) {
        this.gb = 0;
        this.Ja = a || 0
    };
    A.prototype.setFinallyBlock = A.prototype.bf;
    A.prototype.Dc = function(a, b) {
        this.u = a;
        this.gb = b || 0
    };
    A.prototype.leaveTryBlock = A.prototype.Dc;
    A.prototype.kb = function(a) {
        this.gb = a || 0;
        a = this.ea.Rf;
        this.ea = null;
        return a
    };
    A.prototype.enterCatchBlock = A.prototype.kb;
    A.prototype.pd = function(a, b, c) {
        c ? this.se[c] = this.ea : this.se = [this.ea];
        this.gb = a || 0;
        this.Ja = b || 0
    };
    A.prototype.enterFinallyBlock = A.prototype.pd;
    A.prototype.Bd = function(a, b) {
        b = this.se.splice(b || 0)[0];
        (b = this.ea = this.ea || b) ? b.og ? this.u = this.gb || this.Ja : b.na != void 0 && this.Ja < b.na ? (this.u = b.na, this.ea = null) : this.u = this.Ja: this.u = a
    };
    A.prototype.leaveFinallyBlock = A.prototype.Bd;
    A.prototype.forIn = function(a) {
        return new va(a)
    };
    A.prototype.forIn = A.prototype.forIn;
    var va = function(a) {
        this.Di = a;
        this.Hd = [];
        for (var b in a) this.Hd.push(b);
        this.Hd.reverse()
    };
    va.prototype.Oh = function() {
        for (; this.Hd.length > 0;) {
            var a = this.Hd.pop();
            if (a in this.Di) return a
        }
        return null
    };
    va.prototype.getNext = va.prototype.Oh;
    var wa = function(a) {
        this.B = new A;
        this.Li = a
    };
    wa.prototype.Lc = function(a) {
        this.B.Na();
        if (this.B.Pa) return xa(this, this.B.Pa.next, a, this.B.Lc);
        this.B.Lc(a);
        return ya(this)
    };
    var za = function(a, b) {
        a.B.Na();
        var c = a.B.Pa;
        if (c) return xa(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.B.return);
        a.B.return(b);
        return ya(a)
    };
    wa.prototype.Wc = function(a) {
        this.B.Na();
        if (this.B.Pa) return xa(this, this.B.Pa["throw"], a, this.B.Lc);
        this.B.Wc(a);
        return ya(this)
    };
    var xa = function(a, b, c, d) {
            try {
                var e = b.call(a.B.Pa, c);
                ua(e);
                if (!e.done) return a.B.Cc = !1, e;
                var f = e.value
            } catch (g) {
                return a.B.Pa = null, a.B.Wc(g), ya(a)
            }
            a.B.Pa = null;
            d.call(a.B, f);
            return ya(a)
        },
        ya = function(a) {
            for (; a.B.u;) try {
                var b = a.Li(a.B);
                if (b) return a.B.Cc = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.B.V = void 0, a.B.Wc(c)
            }
            a.B.Cc = !1;
            if (a.B.ea) {
                b = a.B.ea;
                a.B.ea = null;
                if (b.og) throw b.Rf;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        Aa = function(a) {
            this.next = function(b) {
                return a.Lc(b)
            };
            this.throw = function(b) {
                return a.Wc(b)
            };
            this.return = function(b) {
                return za(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Ba = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        },
        Ca = function(a) {
            return Ba(new Aa(new wa(a)))
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.eh = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.eh
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("g");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return Da(pa(this))
            }
        });
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });
    var Da = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        Ea = function(a) {
            this[Symbol.asyncIterator] = function() {
                return this
            };
            this[Symbol.iterator] = function() {
                return a
            };
            this.next = function(b) {
                return Promise.resolve(a.next(b))
            };
            this["throw"] = function(b) {
                return new Promise(function(c, d) {
                    var e = a["throw"];
                    e !== void 0 ? c(e.call(a, b)) : (c = a["return"], c !== void 0 && c.call(a), d(new TypeError("h")))
                })
            };
            a["return"] !== void 0 && (this["return"] = function(b) {
                return Promise.resolve(a["return"](b))
            })
        },
        E = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("globalThis", function(a) {
        return a || da
    });
    p("Reflect.setPrototypeOf", function(a) {
        return a ? a : oa ? function(b, c) {
            try {
                return oa(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    });
    p("Promise", function(a) {
        function b() {
            this.Qa = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.Df = function(g) {
            if (this.Qa == null) {
                this.Qa = [];
                var h = this;
                this.Ef(function() {
                    h.Ih()
                })
            }
            this.Qa.push(g)
        };
        var d = da.setTimeout;
        b.prototype.Ef = function(g) {
            d(g, 0)
        };
        b.prototype.Ih = function() {
            for (; this.Qa && this.Qa.length;) {
                var g = this.Qa;
                this.Qa = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.nh(l)
                    }
                }
            }
            this.Qa = null
        };
        b.prototype.nh = function(g) {
            this.Ef(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.hc = 0;
            this.Sc = void 0;
            this.Yb = [];
            this.tg = !1;
            var h = this.je();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.je = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.Xi),
                reject: g(this.Ve)
            }
        };
        e.prototype.Xi = function(g) {
            if (g === this) this.Ve(new TypeError("i"));
            else if (g instanceof e) this.cj(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.Wi(g) : this.Uf(g)
            }
        };
        e.prototype.Wi = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.Ve(k);
                return
            }
            typeof h == "function" ? this.dj(h, g) : this.Uf(g)
        };
        e.prototype.Ve = function(g) {
            this.Lg(2, g)
        };
        e.prototype.Uf = function(g) {
            this.Lg(1, g)
        };
        e.prototype.Lg = function(g, h) {
            if (this.hc != 0) throw Error("j`" + g + "`" + h + "`" + this.hc);
            this.hc = g;
            this.Sc = h;
            this.hc === 2 && this.Zi();
            this.Jh()
        };
        e.prototype.Zi = function() {
            var g = this;
            d(function() {
                if (g.Bi()) {
                    var h = da.console;
                    typeof h !== "undefined" && h.error(g.Sc)
                }
            }, 1)
        };
        e.prototype.Bi = function() {
            if (this.tg) return !1;
            var g = da.CustomEvent,
                h = da.Event,
                k = da.dispatchEvent;
            if (typeof k === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.Sc;
            return k(g)
        };
        e.prototype.Jh = function() {
            if (this.Yb != null) {
                for (var g = 0; g < this.Yb.length; ++g) f.Df(this.Yb[g]);
                this.Yb = null
            }
        };
        var f = new b;
        e.prototype.cj = function(g) {
            var h =
                this.je();
            g.gd(h.resolve, h.reject)
        };
        e.prototype.dj = function(g, h) {
            var k = this.je();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(t, r) {
                return typeof t == "function" ? function(w) {
                    try {
                        l(t(w))
                    } catch (v) {
                        m(v)
                    }
                } : r
            }
            var l, m, u = new e(function(t, r) {
                l = t;
                m = r
            });
            this.gd(k(g, l), k(h, m));
            return u
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.gd = function(g, h) {
            function k() {
                switch (l.hc) {
                    case 1:
                        g(l.Sc);
                        break;
                    case 2:
                        h(l.Sc);
                        break;
                    default:
                        throw Error("k`" +
                            l.hc);
                }
            }
            var l = this;
            this.Yb == null ? f.Df(k) : this.Yb.push(k);
            this.tg = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = x(g), m = l.next(); !m.done; m = l.next()) c(m.value).gd(h, k)
            })
        };
        e.all = function(g) {
            var h = x(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function u(w) {
                    return function(v) {
                        t[w] = v;
                        r--;
                        r == 0 && l(t)
                    }
                }
                var t = [],
                    r = 0;
                do t.push(void 0), r++, c(k.value).gd(u(t.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    });
    p("Object.setPrototypeOf", function(a) {
        return a || oa
    });
    p("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push(b[d]);
            return c
        }
    });
    var Fa = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Fa(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function d(k) {
            if (!sa(k, f)) {
                var l = new b;
                ba(k, f, {
                    value: l
                })
            }
        }

        function e(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (m.get(k) != 2 || m.get(l) != 3) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && m.get(l) == 4
                } catch (u) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            h = function(k) {
                this.Bc = (g += Math.random() + 1).toString();
                if (k) {
                    k = x(k);
                    for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        h.prototype.set = function(k, l) {
            if (!c(k)) throw Error("l");
            d(k);
            if (!sa(k, f)) throw Error("m`" + k);
            k[f][this.Bc] = l;
            return this
        };
        h.prototype.get = function(k) {
            return c(k) && sa(k, f) ? k[f][this.Bc] : void 0
        };
        h.prototype.has = function(k) {
            return c(k) && sa(k, f) && sa(k[f], this.Bc)
        };
        h.prototype.delete = function(k) {
            return c(k) &&
                sa(k, f) && sa(k[f], this.Bc) ? delete k[f][this.Bc] : !1
        };
        return h
    });
    p("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(x([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (u) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (h) {
                    h = x(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                Ma: this[1].Ma,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].Ma.next = l.entry, this[1].Ma = l.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.Ma.next =
                h.entry.next, h.entry.next.Ma = h.entry.Ma, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Ma = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach =
            function(h, k) {
                for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && sa(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var u = m[h];
                        if (k !== k && u.key !== u.key || k === u.key) return {
                            id: l,
                            list: m,
                            index: h,
                            entry: u
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return Da(function() {
                    if (l) {
                        for (; l.head !=
                            h[1];) l = l.Ma;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Ma = h.next = h.head = h
            },
            g = 0;
        return c
    });
    p("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(x([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.Ca = new Map;
            if (c) {
                c =
                    x(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.Ca.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.Ca.set(c, c);
            this.size = this.Ca.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.Ca.delete(c);
            this.size = this.Ca.size;
            return c
        };
        b.prototype.clear = function() {
            this.Ca.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.Ca.has(c)
        };
        b.prototype.entries = function() {
            return this.Ca.entries()
        };
        b.prototype.values = function() {
            return this.Ca.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.Ca.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Fa(this, function(b, c) {
                return [b, c]
            })
        }
    });
    var Ga = function(a, b, c) {
        if (a == null) throw new TypeError("n`" + c);
        if (b instanceof RegExp) throw new TypeError("o`" + c);
        return a + ""
    };
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    p("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Ga(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return Ga(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    });
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Fa(this, function(b, c) {
                return c
            })
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            c < 0 && (c = Math.max(0, e + c));
            if (d == null || d > e) d = e;
            d = Number(d);
            d < 0 && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    ia("fill", function(a) {
        return a ? a : Array.prototype.fill
    });
    p("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = b === void 0 ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && b > 0 ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Ha = this || self,
        Ia = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = Ha, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        },
        Ja = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Ka = function(a) {
            var b = Ja(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        La = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        Ma = function(a) {
            return a
        },
        Na = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.ij = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.ak = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Oa = function() {
        this.hf = 0
    };
    Oa.prototype.kc = function(a, b) {
        var c = this;
        return function() {
            var d = E.apply(0, arguments);
            c.hf = a;
            return b.apply(null, y(d))
        }
    };
    var Pa = function() {
            var a = {};
            this.Da = (a[3] = [], a[2] = [], a[1] = [], a);
            this.Ie = !1
        },
        Ta = function(a, b, c) {
            var d = Sa(a, c);
            a.Da[c].push(b);
            d && a.Da[c].length === 1 && a.flush()
        },
        Sa = function(a, b) {
            return Object.keys(a.Da).map(function(c) {
                return Number(c)
            }).filter(function(c) {
                return !isNaN(c) && c > b
            }).every(function(c) {
                return a.Da[c].length === 0
            })
        };
    Pa.prototype.flush = function() {
        if (!this.Ie) {
            this.Ie = !0;
            try {
                for (; Object.values(this.Da).some(function(a) {
                        return a.length > 0
                    });) Ua(this, 3), Ua(this, 2), Ua(this, 1)
            } catch (a) {
                throw Object.values(this.Da).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.Ie = !1
            }
        }
    };
    var Ua = function(a, b) {
        for (; Sa(a, b) && a.Da[b].length > 0;) a.Da[b][0](), a.Da[b].shift()
    };
    da.Object.defineProperties(Pa.prototype, {
        Eg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.Da).some(function(a) {
                    return a.length > 0
                })
            }
        }
    });

    function Va(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Wa = {};
    var Xa = globalThis.trustedTypes,
        $a;

    function ab() {
        var a = null;
        if (!Xa) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Xa.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {
            throw c;
        }
        return a
    };
    var bb = function(a) {
        if (Wa !== Wa) throw Error("p");
        this.Cg = a
    };
    bb.prototype.toString = function() {
        return this.Cg + ""
    };

    function cb(a) {
        var b;
        $a === void 0 && ($a = ab());
        a = (b = $a) ? b.createScriptURL(a) : a;
        return new bb(a)
    };
    var db = ra([""]),
        eb = qa(["\x00"], ["\\0"]),
        gb = qa(["\n"], ["\\n"]),
        hb = qa(["\x00"], ["\\u0000"]),
        ib = ra([""]),
        jb = qa(["\x00"], ["\\0"]),
        kb = qa(["\n"], ["\\n"]),
        lb = qa(["\x00"], ["\\u0000"]);

    function mb(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function nb(a) {
        return a.toString().indexOf("`") === -1
    }
    var ob = nb(function(a) {
            return a(db)
        }) || nb(function(a) {
            return a(eb)
        }) || nb(function(a) {
            return a(gb)
        }) || nb(function(a) {
            return a(hb)
        }),
        pb = mb(ib) && mb(jb) && mb(kb) && mb(lb);
    var qb = function(a) {
        if (Wa !== Wa) throw Error("p");
        this.Ki = a
    };
    qb.prototype.toString = function() {
        return this.Ki
    };
    new qb("about:blank");
    new qb("about:invalid#zClosurez");
    var rb = [],
        sb = function(a) {
            console.warn("r`" + a)
        };
    rb.indexOf(sb) === -1 && rb.push(sb);

    function tb(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, tb);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    Na(tb, Error);
    tb.prototype.name = "CustomError";
    var ub;

    function vb(a, b) {
        var c = tb.call;
        a = a.split("%s");
        for (var d = "", e = a.length - 1, f = 0; f < e; f++) d += a[f] + (f < b.length ? b[f] : "%s");
        c.call(tb, this, d + a[e])
    }
    Na(vb, tb);
    vb.prototype.name = "AssertionError";

    function wb(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new vb("" + e, f || []);
    }
    var F = function(a, b, c) {
            a || wb("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        G = function(a, b, c) {
            a == null && wb("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        xb = function(a, b) {
            throw new vb("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        zb = function(a, b, c) {
            typeof a !== "number" && wb("Expected number but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Ab = function(a, b, c) {
            typeof a !== "string" && wb("Expected string but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Bb = function(a, b, c) {
            typeof a !== "function" && wb("Expected function but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Cb = function(a, b, c) {
            La(a) || wb("Expected object but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        I = function(a, b, c) {
            Array.isArray(a) || wb("Expected array but got %s: %s.", [Ja(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Eb = function(a, b, c, d) {
            a instanceof b || wb("Expected instanceof %s but got %s.", [Db(b), Db(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function Db(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : a === null ? "null" : typeof a
    };
    var Fb = Array.prototype.forEach ? function(a, b) {
            F(a.length != null);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        Gb = Array.prototype.map ? function(a, b) {
            F(a.length != null);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        Hb = Array.prototype.some ? function(a, b) {
            F(a.length !=
                null);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function Ib(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Jb(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Kb(a, b, c) {
        if (!Ka(a) || !Ka(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || Lb;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function Lb(a, b) {
        return a === b
    }

    function Mb(a, b) {
        return Ib.apply([], Gb(a, b))
    };

    function Nb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Ob = function(a, b) {
        this.name = a;
        this.value = b
    };
    Ob.prototype.toString = function() {
        return this.name
    };
    var Pb = new Ob("OFF", Infinity),
        Qb = new Ob("WARNING", 900),
        Rb = new Ob("INFO", 800),
        Sb = new Ob("CONFIG", 700),
        Tb = function() {
            this.hd = 0;
            this.clear()
        },
        Ub;
    Tb.prototype.clear = function() {
        this.I = Array(this.hd);
        this.Lf = -1;
        this.pg = !1
    };
    var Vb = function(a, b, c) {
        this.reset(a || Pb, b, c, void 0, void 0)
    };
    Vb.prototype.reset = function(a, b, c, d) {
        d || Date.now();
        this.zi = b
    };
    Vb.prototype.getMessage = function() {
        return this.zi
    };
    var Wb = function(a, b) {
            this.level = null;
            this.Sh = [];
            this.parent = (b === void 0 ? null : b) || null;
            this.children = [];
            this.oi = {
                getName: function() {
                    return a
                }
            }
        },
        Xb = function(a) {
            if (a.level) return a.level;
            if (a.parent) return Xb(a.parent);
            xb("Root logger has no level set.");
            return Pb
        },
        Yb = function(a, b) {
            for (; a;) a.Sh.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        Zb = function() {
            this.entries = {};
            var a = new Wb("");
            a.level = Sb;
            this.entries[""] = a
        },
        $b, ac = function(a, b, c) {
            var d = a.entries[b];
            if (d) return c !== void 0 && (d.level = c), d;
            d = b.lastIndexOf(".");
            d = b.slice(0, Math.max(d, 0));
            d = ac(a, d);
            var e = new Wb(b, d);
            a.entries[b] = e;
            d.children.push(e);
            c !== void 0 && (e.level = c);
            return e
        },
        bc = function() {
            $b || ($b = new Zb);
            return $b
        },
        dc = function(a) {
            var b = cc;
            if (b) {
                var c = a,
                    d = Qb;
                if (a = b)
                    if (a = b && d) {
                        a = d.value;
                        var e = b ? Xb(ac(bc(), b.getName())) : Pb;
                        a = a >= e.value
                    }
                if (a) {
                    d = d || Pb;
                    a = ac(bc(), b.getName());
                    typeof c === "function" && (c = c());
                    Ub || (Ub = new Tb);
                    e = Ub;
                    b = b.getName();
                    if (e.hd > 0) {
                        var f = (e.Lf + 1) % e.hd;
                        e.Lf = f;
                        e.pg ? (e = e.I[f], e.reset(d, c, b), b = e) : (e.pg = f == e.hd - 1, b = e.I[f] = new Vb(d, c, b))
                    } else b =
                        new Vb(d, c, b);
                    Yb(a, b)
                }
            }
        };
    var ec = function() {
        this.names = new Map
    };
    ec.prototype.getName = function(a) {
        var b = this.names.get(a);
        if (b) return b;
        var c;
        b = (c = a.description) != null ? c : Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36);
        this.names.set(a, b);
        return b
    };
    /*


     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors
     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at
         http://www.apache.org/licenses/LICENSE-2.0
     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var fc = function(a) {
        var b = Error.call(this, a ? a.length + " errors occurred during unsubscription:\n" + a.map(function(c, d) {
            return d + 1 + ") " + c.toString()
        }).join("\n  ") : "");
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.errors = a;
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "UnsubscriptionError"
    };
    q(fc, Error);

    function hc(a, b) {
        a && (b = a.indexOf(b), 0 <= b && a.splice(b, 1))
    };

    function J(a) {
        return typeof a === "function"
    };
    var jc = function(a) {
        this.Yh = a;
        this.closed = !1;
        this.nc = this.Jb = null
    };
    n = jc.prototype;
    n.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.Jb;
            if (Array.isArray(a))
                for (var b = x(a), c = b.next(); !c.done; c = b.next()) c.value.remove(this);
            else a == null || a.remove(this);
            b = this.Yh;
            if (J(b)) try {
                b()
            } catch (f) {
                var d = f instanceof fc ? f.errors : [f]
            }
            var e = this.nc;
            if (e)
                for (this.nc = null, b = x(e), c = b.next(); !c.done; c = b.next()) {
                    c = c.value;
                    try {
                        J(c) ? c() : c.unsubscribe()
                    } catch (f) {
                        c = void 0, d = (c = d) != null ? c : [], f instanceof fc ? d = [].concat(y(d), y(f.errors)) : d.push(f)
                    }
                }
            if (d) throw new fc(d);
        }
    };
    n.add = function(a) {
        if (a && a !== this)
            if (this.closed) J(a) ? a() : a.unsubscribe();
            else {
                if (a instanceof jc) {
                    if (a.closed || a.gh(this)) return;
                    a.fh(this)
                }
                var b;
                (this.nc = (b = this.nc) != null ? b : []).push(a)
            }
    };
    n.gh = function(a) {
        var b = this.Jb;
        return b === a || Array.isArray(b) && b.includes(a)
    };
    n.fh = function(a) {
        var b = this.Jb;
        this.Jb = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a
    };
    n.hh = function(a) {
        var b = this.Jb;
        b === a ? this.Jb = null : Array.isArray(b) && hc(b, a)
    };
    n.remove = function(a) {
        var b = this.nc;
        b && hc(b, a);
        a instanceof jc && a.hh(this)
    };
    var kc = new jc;
    kc.closed = !0;
    jc.EMPTY = kc;

    function lc(a) {
        return a instanceof jc || a && "closed" in a && J(a.remove) && J(a.add) && J(a.unsubscribe)
    };
    var mc = function() {
        setTimeout.apply(null, y(E.apply(0, arguments)))
    };

    function nc() {};

    function oc(a) {
        mc(function() {
            throw a;
        })
    };
    var pc = function(a) {
        jc.call(this);
        this.T = !1;
        this.destination = a instanceof pc ? a : new qc(!a || J(a) ? {
            next: a != null ? a : void 0
        } : a);
        lc(a) && a.add(this)
    };
    q(pc, jc);
    pc.EMPTY = jc.EMPTY;
    pc.create = function(a, b, c) {
        return new rc(a, b, c)
    };
    n = pc.prototype;
    n.next = function(a) {
        this.T || this.Wd(a)
    };
    n.error = function(a) {
        this.T || (this.T = !0, this.xf(a))
    };
    n.complete = function() {
        this.T || (this.T = !0, this.ad())
    };
    n.unsubscribe = function() {
        this.closed || (this.T = !0, jc.prototype.unsubscribe.call(this))
    };
    n.Wd = function(a) {
        this.destination.next(a)
    };
    n.xf = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.ad = function() {
        this.destination.complete();
        this.unsubscribe()
    };
    var qc = function(a) {
        this.Qe = a
    };
    qc.prototype.next = function(a) {
        var b = this.Qe;
        if (b.next) try {
            b.next(a)
        } catch (c) {
            oc(c)
        }
    };
    qc.prototype.error = function(a) {
        var b = this.Qe;
        if (b.error) try {
            b.error(a)
        } catch (c) {
            oc(c)
        } else oc(a)
    };
    qc.prototype.complete = function() {
        var a = this.Qe;
        if (a.complete) try {
            a.complete()
        } catch (b) {
            oc(b)
        }
    };
    var rc = function(a, b, c) {
        pc.call(this);
        this.destination = new qc(J(a) || !a ? {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0
        } : a)
    };
    q(rc, pc);
    rc.EMPTY = pc.EMPTY;
    rc.create = pc.create;
    var sc = typeof Symbol === "function" && Symbol.observable || "@@observable";

    function tc(a) {
        return a
    };

    function K() {
        return uc(E.apply(0, arguments))
    }

    function uc(a) {
        return a.length === 0 ? tc : a.length === 1 ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };
    var L = function(a) {
        a && (this.Fa = a)
    };
    n = L.prototype;
    n.ub = function(a) {
        var b = new L;
        b.source = this;
        b.operator = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        a = a && a instanceof pc || a && J(a.next) && J(a.error) && J(a.complete) && lc(a) ? a : new rc(a, b, c);
        b = this.operator;
        c = this.source;
        a.add(b ? b.call(a, c) : c ? this.Fa(a) : this.Yd(a));
        return a
    };
    n.Yd = function(a) {
        try {
            return this.Fa(a)
        } catch (b) {
            a.error(b)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = vc(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (h) {
                    e(h), f == null || f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.Fa = function(a) {
        var b;
        return (b = this.source) == null ? void 0 : b.subscribe(a)
    };
    L.prototype[sc] = function() {
        return this
    };
    L.prototype.g = function() {
        var a = E.apply(0, arguments);
        return a.length ? uc(a)(this) : this
    };
    L.create = function(a) {
        return new L(a)
    };

    function vc(a) {
        var b;
        return (b = a != null ? a : void 0) != null ? b : Promise
    };
    var wc = function() {
        var a = Error.call(this, "object unsubscribed");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "ObjectUnsubscribedError"
    };
    q(wc, Error);
    var xc = function() {
        this.Xb = [];
        this.ud = this.T = this.closed = !1;
        this.gf = null
    };
    q(xc, L);
    n = xc.prototype;
    n.ub = function(a) {
        var b = new yc(this, this);
        b.operator = a;
        return b
    };
    n.bb = function() {
        if (this.closed) throw new wc;
    };
    n.next = function(a) {
        this.bb();
        if (!this.T) {
            var b = this.Xb.slice();
            b = x(b);
            for (var c = b.next(); !c.done; c = b.next()) c.value.next(a)
        }
    };
    n.error = function(a) {
        this.bb();
        if (!this.T) {
            this.ud = this.T = !0;
            this.gf = a;
            for (var b = this.Xb; b.length;) b.shift().error(a)
        }
    };
    n.complete = function() {
        this.bb();
        if (!this.T) {
            this.T = !0;
            for (var a = this.Xb; a.length;) a.shift().complete()
        }
    };
    n.unsubscribe = function() {
        this.T = this.closed = !0;
        this.Xb = null
    };
    n.Yd = function(a) {
        this.bb();
        return L.prototype.Yd.call(this, a)
    };
    n.Fa = function(a) {
        this.bb();
        this.wf(a);
        return this.zf(a)
    };
    n.zf = function(a) {
        var b = this,
            c = this.T,
            d = this.Xb;
        return this.ud || c ? jc.EMPTY : (d.push(a), new jc(function() {
            return hc(b.Xb, a)
        }))
    };
    n.wf = function(a) {
        var b = this.gf,
            c = this.T;
        this.ud ? a.error(b) : c && a.complete()
    };
    n.W = function() {
        var a = new L;
        a.source = this;
        return a
    };
    xc.create = function(a, b) {
        return new yc(a, b)
    };
    var yc = function(a, b) {
        xc.call(this);
        this.destination = a;
        this.source = b
    };
    q(yc, xc);
    yc.create = xc.create;
    yc.prototype.next = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.next) == null || c.call(b, a)
    };
    yc.prototype.error = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.error) == null || c.call(b, a)
    };
    yc.prototype.complete = function() {
        var a, b;
        (a = this.destination) == null || (b = a.complete) == null || b.call(a)
    };
    yc.prototype.Fa = function(a) {
        var b, c;
        return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null ? c : jc.EMPTY
    };
    var zc = function(a) {
        xc.call(this);
        this.Zd = a
    };
    q(zc, xc);
    zc.create = xc.create;
    zc.prototype.Fa = function(a) {
        var b = xc.prototype.Fa.call(this, a);
        !b.closed && a.next(this.Zd);
        return b
    };
    zc.prototype.getValue = function() {
        var a = this.gf,
            b = this.Zd;
        if (this.ud) throw a;
        this.bb();
        return b
    };
    zc.prototype.next = function(a) {
        xc.prototype.next.call(this, this.Zd = a)
    };
    da.Object.defineProperties(zc.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.getValue()
            }
        }
    });
    var Ac = new L(function(a) {
        return a.complete()
    });

    function Bc(a, b) {
        return new L(function(c) {
            var d = 0;
            return b.K(function() {
                d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.K())
            })
        })
    };

    function Dc(a, b) {
        if (!a) throw Error("s");
        return new L(function(c) {
            var d = new jc;
            d.add(b.K(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.K(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.K())
                    })
                }))
            }));
            return d
        })
    };
    var Ec = typeof Symbol === "function" && Symbol.iterator ? Symbol.iterator : "@@iterator";

    function Fc(a, b, c) {
        b = b.K(function() {
            try {
                c.call(this)
            } catch (d) {
                a.error(d)
            }
        }, 0);
        a.add(b)
    };

    function Ic(a, b) {
        return new L(function(c) {
            var d;
            c.add(b.K(function() {
                d = a[Ec]();
                Fc(c, b, function() {
                    var e = d.next(),
                        f = e.value;
                    e.done ? c.complete() : (c.next(f), this.K())
                })
            }));
            return function() {
                var e;
                return J((e = d) == null ? void 0 : e.return) && d.return()
            }
        })
    };

    function Jc(a, b) {
        return new L(function(c) {
            var d = new jc;
            d.add(b.K(function() {
                var e = a[sc]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.K(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.K(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.K(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function Kc(a, b) {
        return new L(function(c) {
            return b.K(function() {
                return a.then(function(d) {
                    c.add(b.K(function() {
                        c.next(d);
                        c.add(b.K(function() {
                            return c.complete()
                        }))
                    }))
                }, function(d) {
                    c.add(b.K(function() {
                        return c.error(d)
                    }))
                })
            })
        })
    };
    var Lc = function(a) {
        return a && typeof a.length === "number" && typeof a !== "function"
    };

    function Mc(a) {
        return new TypeError("t`" + (a !== null && typeof a === "object" ? "an invalid object" : "'" + a + "'"))
    };

    function Nc(a, b) {
        if (a != null) {
            if (J(a[sc])) return Jc(a, b);
            if (Lc(a)) return Bc(a, b);
            if (J(a == null ? void 0 : a.then)) return Kc(a, b);
            if (Symbol.asyncIterator && J(a == null ? void 0 : a[Symbol.asyncIterator])) return Dc(a, b);
            if (J(a == null ? void 0 : a[Ec])) return Ic(a, b)
        }
        throw Mc(a);
    };

    function Oc(a, b) {
        return b ? Nc(a, b) : Pc(a)
    }

    function Pc(a) {
        if (a instanceof L) return a;
        if (a != null) {
            if (J(a[sc])) return Qc(a);
            if (Lc(a)) return Rc(a);
            if (J(a == null ? void 0 : a.then)) return Sc(a);
            if (Symbol.asyncIterator && J(a == null ? void 0 : a[Symbol.asyncIterator])) return Tc(a);
            if (J(a == null ? void 0 : a[Ec])) return Uc(a)
        }
        throw Mc(a);
    }

    function Qc(a) {
        return new L(function(b) {
            var c = a[sc]();
            if (J(c.subscribe)) return c.subscribe(b);
            throw new TypeError("u");
        })
    }

    function Rc(a) {
        return new L(function(b) {
            for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
            b.complete()
        })
    }

    function Sc(a) {
        return new L(function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, oc)
        })
    }

    function Uc(a) {
        return new L(function(b) {
            for (var c = a[Ec](); !b.closed;) {
                var d = c.next(),
                    e = d.value;
                d.done ? b.complete() : b.next(e)
            }
            return function() {
                return J(c == null ? void 0 : c.return) && c.return()
            }
        })
    }

    function Tc(a) {
        return new L(function(b) {
            Vc(a, b).catch(function(c) {
                return b.error(c)
            })
        })
    }

    function Vc(a, b) {
        var c, d, e, f, g, h;
        return Ca(function(k) {
            switch (k.u) {
                case 1:
                    k.Ab(2, 3);
                    var l = a[Symbol.asyncIterator];
                    f = l !== void 0 ? l.call(a) : new Ea(x(a));
                case 5:
                    return k.A(f.next(), 8);
                case 8:
                    d = k.V;
                    if (d.done) {
                        k.na(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    k.na(5);
                    break;
                case 3:
                    k.pd();
                    k.bf(9);
                    if (!d || d.done || !(e = f.return)) {
                        k.na(9);
                        break
                    }
                    return k.A(e.call(f), 9);
                case 9:
                    k.pd(0, 0, 1);
                    if (c) throw c.error;
                    k.Bd(10, 1);
                    break;
                case 10:
                    k.Bd(4);
                    break;
                case 2:
                    h = k.kb();
                    c = {
                        error: h
                    };
                    k.na(3);
                    break;
                case 4:
                    b.complete(), k.Tb()
            }
        })
    };

    function Wc(a, b) {
        return b ? Bc(a, b) : Rc(a)
    };

    function Xc(a) {
        return J(a[a.length - 1]) ? a.pop() : void 0
    }

    function Yc(a) {
        var b = a[a.length - 1];
        return b && J(b.K) ? a.pop() : void 0
    };

    function Zc() {
        var a = E.apply(0, arguments),
            b = Yc(a);
        return b ? Bc(a, b) : Wc(a)
    };

    function $c(a) {
        var b = J(a) ? a : function() {
            return a
        };
        return new L(function(c) {
            return c.error(b())
        })
    };
    var ad = {
        now: function() {
            return (ad.Ch || Date).now()
        },
        Ch: void 0
    };
    var bd = function(a, b, c) {
        a = a === void 0 ? Infinity : a;
        b = b === void 0 ? Infinity : b;
        c = c === void 0 ? ad : c;
        xc.call(this);
        this.bufferSize = a;
        this.Yg = b;
        this.Sg = c;
        this.buffer = [];
        this.Ce = b === Infinity;
        this.bufferSize = Math.max(1, a);
        this.Yg = Math.max(1, b)
    };
    q(bd, xc);
    bd.create = xc.create;
    bd.prototype.next = function(a) {
        var b = this.buffer,
            c = this.Ce,
            d = this.Sg,
            e = this.Yg;
        this.T || (b.push(a), !c && b.push(d.now() + e));
        cd(this);
        xc.prototype.next.call(this, a)
    };
    bd.prototype.Fa = function(a) {
        this.bb();
        cd(this);
        for (var b = this.zf(a), c = this.Ce, d = this.buffer.slice(), e = 0; e < d.length && !a.closed; e += c ? 1 : 2) a.next(d[e]);
        this.wf(a);
        return b
    };
    var cd = function(a) {
        var b = a.bufferSize,
            c = a.Sg,
            d = a.buffer;
        a = a.Ce;
        var e = (a ? 1 : 2) * b;
        b < Infinity && e < d.length && d.splice(0, d.length - e);
        if (!a) {
            b = c.now();
            c = 0;
            for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
            c && d.splice(0, c + 1)
        }
    };
    var ed = function(a, b) {
        b = b === void 0 ? dd : b;
        this.aj = a;
        this.now = b
    };
    ed.prototype.K = function(a, b, c) {
        b = b === void 0 ? 0 : b;
        return (new this.aj(this, a)).K(c, b)
    };
    var dd = ad.now;
    var fd = function() {
        var a = Error.call(this, "no elements in sequence");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "EmptyError"
    };
    q(fd, Error);

    function gd(a) {
        return new Promise(function(b, c) {
            var d = new rc({
                next: function(e) {
                    b(e);
                    d.unsubscribe()
                },
                error: c,
                complete: function() {
                    c(new fd)
                }
            });
            a.subscribe(d)
        })
    };
    var M = function(a, b, c, d, e) {
        pc.call(this, a);
        this.Hi = e;
        b && (this.Wd = function(f) {
            try {
                b(f)
            } catch (g) {
                this.destination.error(g)
            }
        });
        c && (this.xf = function(f) {
            try {
                c(f)
            } catch (g) {
                this.destination.error(g)
            }
            this.unsubscribe()
        });
        d && (this.ad = function() {
            try {
                d()
            } catch (f) {
                this.destination.error(f)
            }
            this.unsubscribe()
        })
    };
    q(M, pc);
    M.EMPTY = pc.EMPTY;
    M.create = pc.create;
    M.prototype.unsubscribe = function() {
        var a;
        this.closed || (a = this.Hi) != null && a.call(this);
        pc.prototype.unsubscribe.call(this)
    };

    function hd(a) {
        return function(b) {
            if (J(b == null ? void 0 : b.ub)) return b.ub(function(c) {
                try {
                    return a(c, this)
                } catch (d) {
                    this.error(d)
                }
            });
            throw new TypeError("v");
        }
    };

    function id() {
        return hd(function(a, b) {
            var c = null;
            a.bd++;
            var d = new M(b, void 0, void 0, void 0, function() {
                if (!a || a.bd <= 0 || 0 < --a.bd) c = null;
                else {
                    var e = a.Ib,
                        f = c;
                    c = null;
                    !e || f && e !== f || e.unsubscribe();
                    b.unsubscribe()
                }
            });
            a.subscribe(d);
            d.closed || (c = a.connect())
        })
    };
    var jd = function(a, b) {
        this.source = a;
        this.Ng = b;
        this.cd = null;
        this.bd = 0;
        this.Ib = null
    };
    q(jd, L);
    jd.create = L.create;
    jd.prototype.Fa = function(a) {
        return kd(this).subscribe(a)
    };
    var kd = function(a) {
        var b = a.cd;
        if (!b || b.T) a.cd = a.Ng();
        return a.cd
    };
    jd.prototype.Xd = function() {
        this.bd = 0;
        var a = this.Ib;
        this.cd = this.Ib = null;
        a == null || a.unsubscribe()
    };
    jd.prototype.connect = function() {
        var a = this,
            b = this.Ib;
        if (!b) {
            b = this.Ib = new jc;
            var c = kd(this);
            b.add(this.source.subscribe(new M(c, void 0, function(d) {
                a.Xd();
                c.error(d)
            }, function() {
                a.Xd();
                c.complete()
            }, function() {
                return a.Xd()
            })));
            b.closed && (this.Ib = null, b = jc.EMPTY)
        }
        return b
    };

    function ld() {
        var a = md;
        var b = b === void 0 ? 0 : b;
        return hd(function(c, d) {
            d.add(a.K(function() {
                return c.subscribe(d)
            }, b))
        })
    };

    function N(a) {
        return hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                c.next(a.call(void 0, e, d++))
            }))
        })
    };
    var nd = Array.isArray;

    function od(a) {
        return N(function(b) {
            return nd(b) ? a.apply(null, y(b)) : a(b)
        })
    };
    var pd = Array.isArray,
        rd = Object,
        sd = rd.getPrototypeOf,
        td = rd.prototype,
        ud = rd.keys;

    function vd(a) {
        if (a.length === 1) {
            var b = a[0];
            if (pd(b)) return {
                args: b,
                keys: null
            };
            if (b && typeof b === "object" && sd(b) === td) return a = ud(b), {
                args: a.map(function(c) {
                    return b[c]
                }),
                keys: a
            }
        }
        return {
            args: a,
            keys: null
        }
    };

    function wd() {
        var a = E.apply(0, arguments),
            b = Yc(a),
            c = Xc(a);
        a = vd(a);
        var d = a.args,
            e = a.keys;
        if (d.length === 0) return Oc([], b);
        b = new L(xd(d, b, e ? function(f) {
            for (var g = {}, h = 0; h < f.length; h++) g[e[h]] = f[h];
            return g
        } : tc));
        return c ? b.g(od(c)) : b
    }
    var yd = function(a, b, c) {
        pc.call(this, a);
        this.Wd = b;
        this.fj = c
    };
    q(yd, pc);
    yd.EMPTY = pc.EMPTY;
    yd.create = pc.create;
    yd.prototype.ad = function() {
        this.fj() ? pc.prototype.ad.call(this) : this.unsubscribe()
    };

    function xd(a, b, c) {
        c = c === void 0 ? tc : c;
        return function(d) {
            zd(b, function() {
                for (var e = a.length, f = Array(e), g = e, h = a.map(function() {
                        return !1
                    }), k = !0, l = {
                        ob: 0
                    }; l.ob < e; l = {
                        ob: l.ob
                    }, l.ob++) zd(b, function(m) {
                    return function() {
                        Oc(a[m.ob], b).subscribe(new yd(d, function(u) {
                            f[m.ob] = u;
                            k && (h[m.ob] = !0, k = !h.every(tc));
                            k || d.next(c(f.slice()))
                        }, function() {
                            return --g === 0
                        }))
                    }
                }(l), d)
            }, d)
        }
    }

    function zd(a, b, c) {
        a ? c.add(a.K(b)) : b()
    };

    function Ad(a, b, c, d) {
        var e = [],
            f = 0,
            g = 0,
            h = !1,
            k = function(l) {
                f++;
                Pc(c(l, g++)).subscribe(new M(b, function(m) {
                    b.next(m)
                }, void 0, function() {
                    f--;
                    for (var m = {}; e.length && f < d; m = {
                            Gf: void 0
                        }) m.Gf = e.shift(), k(m.Gf);
                    !h || e.length || f || b.complete()
                }))
            };
        a.subscribe(new M(b, function(l) {
            return f < d ? k(l) : e.push(l)
        }, void 0, function() {
            h = !0;
            !h || e.length || f || b.complete()
        }));
        return function() {
            e = null
        }
    };

    function Bd(a, b) {
        var c = c === void 0 ? Infinity : c;
        if (J(b)) return Bd(function(d, e) {
            return N(function(f, g) {
                return b(d, f, e, g)
            })(Pc(a(d, e)))
        }, c);
        typeof b === "number" && (c = b);
        return hd(function(d, e) {
            return Ad(d, e, a, c)
        })
    };

    function Cd(a) {
        a = a === void 0 ? Infinity : a;
        return Bd(tc, a)
    };

    function Dd() {
        var a = E.apply(0, arguments);
        return Cd(1)(Wc(a, Yc(a)))
    };

    function Ed(a) {
        return new L(function(b) {
            Pc(a()).subscribe(b)
        })
    };
    var Fd = ["addListener", "removeListener"],
        Gd = ["addEventListener", "removeEventListener"],
        Hd = ["on", "off"];

    function Id(a, b, c) {
        if (J(c)) {
            var d = c;
            c = void 0
        }
        if (d) return Id(a, b, c).g(od(d));
        d = x(J(a.addEventListener) && J(a.removeEventListener) ? Gd.map(function(g) {
            return function(h) {
                return a[g](b, h, c)
            }
        }) : J(a.addListener) && J(a.removeListener) ? Fd.map(Jd(a, b)) : J(a.xk) && J(a.jk) ? Hd.map(Jd(a, b)) : []);
        var e = d.next().value,
            f = d.next().value;
        return !e && Lc(a) ? Bd(function(g) {
            return Id(g, b, c)
        })(Wc(a)) : new L(function(g) {
            if (!e) throw new TypeError("w");
            var h = function() {
                var k = E.apply(0, arguments);
                return g.next(1 < k.length ? k : k[0])
            };
            e(h);
            return function() {
                return f(h)
            }
        })
    }

    function Jd(a, b) {
        return function(c) {
            return function(d) {
                return a[c](b, d)
            }
        }
    };
    var Kd = function() {
        jc.call(this)
    };
    q(Kd, jc);
    Kd.EMPTY = jc.EMPTY;
    Kd.prototype.K = function() {
        return this
    };
    var Ld = function(a, b) {
        return setInterval.apply(null, [a, b].concat(y(E.apply(2, arguments))))
    };
    var Md = function(a, b) {
        jc.call(this);
        this.scheduler = a;
        this.qf = b;
        this.pending = !1
    };
    q(Md, Kd);
    Md.EMPTY = Kd.EMPTY;
    Md.prototype.K = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.scheduler;
        a != null && (this.id = Nd(this, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.Xe(c, this.id, b);
        return this
    };
    Md.prototype.Xe = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return Ld(a.flush.bind(a, this), c)
    };
    var Nd = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        if (c != null && a.delay === c && a.pending === !1) return b;
        clearInterval(b)
    };
    Md.prototype.execute = function(a, b) {
        if (this.closed) return Error("x");
        this.pending = !1;
        if (a = this.yf(a, b)) return a;
        this.pending === !1 && this.id != null && (this.id = Nd(this, this.id, null))
    };
    Md.prototype.yf = function(a) {
        var b = !1;
        try {
            this.qf(a)
        } catch (d) {
            b = !0;
            var c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    Md.prototype.unsubscribe = function() {
        if (!this.closed) {
            var a = this.id,
                b = this.scheduler.actions;
            this.qf = this.state = this.scheduler = null;
            this.pending = !1;
            hc(b, this);
            a != null && (this.id = Nd(this, a, null));
            this.delay = null;
            Kd.prototype.unsubscribe.call(this)
        }
    };
    var Od = function(a, b) {
        b = b === void 0 ? dd : b;
        ed.call(this, a, b);
        this.actions = [];
        this.active = !1
    };
    q(Od, ed);
    Od.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function Pd() {
        var a = E.apply(0, arguments),
            b = Yc(a);
        var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
        return a.length ? a.length === 1 ? Pc(a[0]) : Cd(c)(Wc(a, b)) : Ac
    };
    var Qd = new L(nc);
    var Rd = Array.isArray;

    function Sd(a) {
        return a.length === 1 && Rd(a[0]) ? a[0] : a
    };

    function Td() {
        var a = Sd(E.apply(0, arguments));
        return hd(function(b, c) {
            var d = [b].concat(y(a)),
                e = function() {
                    if (!c.closed)
                        if (d.length > 0) {
                            try {
                                var f = Pc(d.shift())
                            } catch (h) {
                                e();
                                return
                            }
                            var g = new M(c, void 0, nc, nc);
                            c.add(f.subscribe(g));
                            g.add(e)
                        } else c.complete()
                };
            e()
        })
    };

    function O(a) {
        return hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                return a.call(void 0, e, d++) && c.next(e)
            }))
        })
    };

    function Ud() {
        var a = E.apply(0, arguments);
        a = Sd(a);
        return a.length === 1 ? Pc(a[0]) : new L(Vd(a))
    }

    function Vd(a) {
        return function(b) {
            for (var c = [], d = {
                    Nb: 0
                }; c && !b.closed && d.Nb < a.length; d = {
                    Nb: d.Nb
                }, d.Nb++) c.push(Pc(a[d.Nb]).subscribe(new M(b, function(e) {
                return function(f) {
                    if (c) {
                        for (var g = 0; g < c.length; g++) g !== e.Nb && c[g].unsubscribe();
                        c = null
                    }
                    b.next(f)
                }
            }(d))))
        }
    };

    function Wd() {
        var a = E.apply(0, arguments),
            b = Xc(a),
            c = Sd(a);
        return c.length ? new L(function(d) {
            var e = c.map(function() {
                    return []
                }),
                f = c.map(function() {
                    return !1
                });
            d.add(function() {
                e = f = null
            });
            for (var g = {
                    Za: 0
                }; !d.closed && g.Za < c.length; g = {
                    Za: g.Za
                }, g.Za++) Pc(c[g.Za]).subscribe(new M(d, function(h) {
                    return function(k) {
                        e[h.Za].push(k);
                        e.every(function(l) {
                            return l.length
                        }) && (k = e.map(function(l) {
                            return l.shift()
                        }), d.next(b ? b.apply(null, y(k)) : k), e.some(function(l, m) {
                            return !l.length && f[m]
                        }) && d.complete())
                    }
                }(g), void 0,
                function(h) {
                    return function() {
                        f[h.Za] = !0;
                        !e[h.Za].length && d.complete()
                    }
                }(g)));
            return function() {
                e = f = null
            }
        }) : Ac
    };
    var Xd = function(a, b) {
        Md.call(this, a, b);
        this.scheduler = a;
        this.qf = b
    };
    q(Xd, Md);
    Xd.EMPTY = Md.EMPTY;
    Xd.prototype.K = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (b > 0) return Md.prototype.K.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.scheduler.flush(this);
        return this
    };
    Xd.prototype.execute = function(a, b) {
        return b > 0 || this.closed ? Md.prototype.execute.call(this, a, b) : this.yf(a, b)
    };
    Xd.prototype.Xe = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return c != null && c > 0 || c == null && this.delay > 0 ? Md.prototype.Xe.call(this, a, b, c) : a.flush(this)
    };
    var Yd = function() {
        Od.apply(this, arguments)
    };
    q(Yd, Od);
    var md = new Yd(Xd);
    var Zd = function() {
        this.J = new Oa;
        this.i = new Pa;
        this.di = Symbol();
        this.wc = new ec
    };
    Zd.prototype.ve = function() {
        return Qd
    };
    var $d = function(a, b) {
            a.Ha !== null && a.Ha.next(b)
        },
        ae = function(a) {
            if ((typeof a === "bigint" || typeof a === "number" || typeof a === "string") && typeof BigInt === "function") return BigInt(a)
        };
    da.Object.defineProperties(Zd.prototype, {
        Eb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.di
            }
        }
    });
    var be = function(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = be.prototype;
        this.name = String(a)
    };
    q(be, Error);
    var ce = function(a) {
        be.call(this, 1E3, 'sfr:"' + a + '"');
        this.ti = a;
        this.__proto__ = ce.prototype
    };
    q(ce, be);
    var de = function() {
        be.call(this, 1003);
        this.__proto__ = de.prototype
    };
    q(de, be);
    var ee = function() {
        be.call(this, 1009);
        this.__proto__ = ee.prototype
    };
    q(ee, be);
    var fe = function() {
        be.call(this, 1011);
        this.__proto__ = fe.prototype
    };
    q(fe, be);
    var ge = function() {
        be.call(this, 1007);
        this.__proto__ = de.prototype
    };
    q(ge, be);
    var he = function() {
        be.call(this, 1008);
        this.__proto__ = de.prototype
    };
    q(he, be);
    var ie = function() {
        be.call(this, 1001);
        this.__proto__ = ie.prototype
    };
    q(ie, be);
    var je = function(a) {
        be.call(this, 1004, String(a));
        this.Zh = a;
        this.__proto__ = je.prototype
    };
    q(je, be);
    var le = function(a) {
        be.call(this, 1010, a);
        this.__proto__ = ke.prototype
    };
    q(le, be);
    var ke = function(a) {
        be.call(this, 1005, a);
        this.__proto__ = ke.prototype
    };
    q(ke, be);
    var me = function(a) {
        var b = E.apply(1, arguments),
            c = this;
        this.Zb = [];
        this.Zb.push(a);
        b.forEach(function(d) {
            c.Zb.push(d)
        })
    };
    me.prototype.O = function(a) {
        return this.Zb.some(function(b) {
            return b.O(a)
        })
    };
    me.prototype.M = function(a, b) {
        for (var c = 0; c < this.Zb.length; c++)
            if (this.Zb[c].O(b)) return this.Zb[c].M(a, b);
        throw new ee;
    };

    function ne(a) {
        var b, c, d;
        return !!a && typeof a.active === "boolean" && typeof((b = a.clock) == null ? void 0 : b.now) === "function" && ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 && !((d = a.H) == null || !d.timestamp) && typeof a.ba === "function" && typeof a.ca === "function" && typeof a.va === "function" && typeof a.map === "function" && typeof a.xa === "function"
    };
    var oe = Symbol("time-origin"),
        pe = Symbol("date"),
        qe = function(a, b) {
            this.value = a;
            this.timeline = b
        },
        re = function(a, b) {
            if (b.timeline !== a.timeline) throw new ge;
        },
        se = function(a, b) {
            re(a, b);
            return a.value - b.value
        };
    n = qe.prototype;
    n.equals = function(a) {
        return se(this, a) === 0
    };
    n.maximum = function(a) {
        re(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new qe(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new qe(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function te(a) {
        function b(c) {
            return typeof c === "boolean" || typeof c === "string" || typeof c === "number" || c === void 0 || c === null
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : typeof a === "object" ? Object.keys(a).every(function(c) {
            return typeof c === "string"
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function ue(a) {
        if (te(a)) return a;
        if (ne(a)) return {
            H: {
                value: ue(a.H.value),
                timestamp: se(a.H.timestamp, new qe(0, a.H.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };
    var ve = {
        xj: "app",
        Wj: "web"
    };
    var we = ["sessionStart", "sessionError", "sessionFinish"],
        xe = function(a, b) {
            this.ia = a;
            this.Rd = b;
            this.ready = !1;
            this.wb = [];
            this.Gg = function() {};
            this.Wg = function() {};
            this.Vf = function() {};
            this.gg = function() {};
            this.Id = function() {}
        },
        ye = function(a, b) {
            a.Gg = b
        },
        ze = function(a, b) {
            a.Wg = b
        },
        Ae = function(a, b) {
            a.Vf = b
        },
        De = function(a, b) {
            a.gg = b
        },
        Ee = function(a, b) {
            a.Id = b;
            a.Id(a.wb.length)
        },
        Je = function(a) {
            for (var b = x("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")),
                    c = b.next(); !c.done; c = b.next()) a.ia.addEventListener(c.value, function(d) {
                Fe(a, d)
            });
            Ge(a.ia, function(d) {
                d.type !== "sessionStart" && Fe(a, d)
            }, a.Rd);
            Ge(a.ia, function(d) {
                d.type === "sessionStart" && (Fe(a, d), He(a), Ie(a))
            }, a.Rd)
        },
        Fe = function(a, b) {
            a.wb.push(b);
            a.Id(a.wb.length);
            Ie(a)
        },
        Ie = function(a) {
            if (a.ready)
                for (; a.wb.length > 0;) {
                    var b = a.wb.pop();
                    b !== void 0 && (b.type === "geometryChange" ? a.Vf(b) : b.type === "impression" ? a.gg(b) : we.includes(b.type) ? a.Gg(b) : a.Wg(b));
                    a.Id(a.wb.length)
                }
        },
        He = function(a) {
            a.ready || (a.ready = !0, a.wb.sort(function(b, c) {
                return c.timestamp - b.timestamp
            }))
        };

    function Ke(a) {
        return hd(function(b, c) {
            var d = null,
                e = !1,
                f;
            d = b.subscribe(new M(c, void 0, function(g) {
                f = Pc(a(g, Ke(a)(b)));
                d ? (d.unsubscribe(), d = null, f.subscribe(c)) : e = !0
            }));
            e && (d.unsubscribe(), d = null, f.subscribe(c))
        })
    };

    function Le(a, b, c) {
        return function(d, e) {
            var f = c,
                g = b,
                h = 0;
            d.subscribe(new M(e, function(k) {
                var l = h++;
                g = f ? a(g, k, l) : (f = !0, k);
                e.next(g)
            }, void 0, void 0))
        }
    };

    function Me() {
        var a = E.apply(0, arguments),
            b = Xc(a);
        return b ? K(Me.apply(null, y(a)), od(b)) : hd(function(c, d) {
            xd([c].concat(y(Sd(a))))(d)
        })
    }

    function Ne() {
        return Me.apply(null, y(E.apply(0, arguments)))
    };

    function Oe(a) {
        a = a === void 0 ? null : a;
        return hd(function(b, c) {
            var d = !1;
            b.subscribe(new M(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                d || c.next(a);
                c.complete()
            }))
        })
    };

    function Pe() {
        return hd(function(a, b) {
            a.subscribe(new M(b, nc))
        })
    };

    function Qe(a) {
        return hd(function(b, c) {
            b.subscribe(new M(c, function() {
                return c.next(a)
            }))
        })
    };

    function Re(a) {
        return a <= 0 ? function() {
            return Ac
        } : hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                ++d <= a && (c.next(e), a <= d && c.complete())
            }))
        })
    };

    function Se(a) {
        return Bd(function(b, c) {
            return a(b, c).g(Re(1), Qe(b))
        })
    };

    function Te(a) {
        return hd(function(b, c) {
            var d = new Set;
            b.subscribe(new M(c, function(e) {
                var f = a ? a(e) : e;
                d.has(f) || (d.add(f), c.next(e))
            }))
        })
    };

    function P(a) {
        var b = b === void 0 ? tc : b;
        var c;
        a = (c = a) != null ? c : Ue;
        return hd(function(d, e) {
            var f, g = !0;
            d.subscribe(new M(e, function(h) {
                var k = b(h);
                if (g || !a(f, k)) g = !1, f = k, e.next(h)
            }))
        })
    }

    function Ue(a, b) {
        return a === b
    };

    function Ve(a) {
        a = a === void 0 ? We : a;
        return hd(function(b, c) {
            var d = !1;
            b.subscribe(new M(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                return d ? c.complete() : c.error(a())
            }))
        })
    }

    function We() {
        return new fd
    };

    function Xe() {
        var a = E.apply(0, arguments);
        return function(b) {
            return Dd(b, Zc.apply(null, y(a)))
        }
    };

    function Ye(a) {
        return hd(function(b, c) {
            var d = 0;
            b.subscribe(new M(c, function(e) {
                a.call(void 0, e, d++, b) || (c.next(!1), c.complete())
            }, void 0, function() {
                c.next(!0);
                c.complete()
            }))
        })
    };

    function Ze() {
        return hd(function(a, b) {
            var c = [];
            a.subscribe(new M(b, function(d) {
                c.push(d);
                1 < c.length && c.shift()
            }, void 0, function() {
                for (var d = x(c), e = d.next(); !e.done; e = d.next()) b.next(e.value);
                b.complete()
            }, function() {
                c = null
            }))
        })
    };

    function $e(a, b) {
        var c = arguments.length >= 2;
        return function(d) {
            return d.g(a ? O(function(e, f) {
                return a(e, f, d)
            }) : tc, Ze(), c ? Oe(b) : Ve(function() {
                return new fd
            }))
        }
    };

    function af(a) {
        var b = J(a) ? a : function() {
            return a
        };
        return J() ? hd(function(c, d) {
            var e = b();
            (void 0)(e).subscribe(d).add(c.subscribe(e))
        }) : function(c) {
            var d = new jd(c, b);
            J(c == null ? void 0 : c.ub) && (d.ub = c.ub);
            d.source = c;
            d.Ng = b;
            return d
        }
    };

    function bf() {
        return hd(function(a, b) {
            var c, d = !1;
            a.subscribe(new M(b, function(e) {
                var f = c;
                c = e;
                d && b.next([f, e]);
                d = !0
            }))
        })
    };

    function cf(a) {
        var b = new bd(a, void 0, void 0);
        return function(c) {
            return af(function() {
                return b
            })(c)
        }
    };

    function df() {
        var a = a === void 0 ? Infinity : a;
        return a <= 0 ? function() {
            return Ac
        } : hd(function(b, c) {
            var d = 0,
                e, f = function() {
                    var g = !1;
                    e = b.subscribe(new M(c, void 0, void 0, function() {
                        ++d < a ? e ? (e.unsubscribe(), e = null, f()) : g = !0 : c.complete()
                    }));
                    g && (e.unsubscribe(), e = null, f())
                };
            f()
        })
    };

    function ef(a, b) {
        return hd(Le(a, b, arguments.length >= 2))
    };

    function ff() {
        var a = a || {};
        var b = a.uh === void 0 ? function() {
                return new xc
            } : a.uh,
            c = a.Ti === void 0 ? !0 : a.Ti,
            d = a.Ui === void 0 ? !0 : a.Ui,
            e = a.Vi === void 0 ? !0 : a.Vi;
        return function(f) {
            var g = null,
                h = null,
                k = 0,
                l = !1,
                m = !1,
                u = function() {
                    g = h = null;
                    l = m = !1
                };
            return hd(function(t, r) {
                k++;
                var w;
                h = (w = h) != null ? w : b();
                r.add(function() {
                    k--;
                    if (e && !k && !m && !l) {
                        var v = g;
                        u();
                        v == null || v.unsubscribe()
                    }
                });
                h.subscribe(r);
                !g && k > 0 && (g = new rc({
                    next: function(v) {
                        return h.next(v)
                    },
                    error: function(v) {
                        m = !0;
                        var z = h;
                        d && u();
                        z.error(v)
                    },
                    complete: function() {
                        l = !0;
                        var v = h;
                        c && u();
                        v.complete()
                    }
                }), Oc(t).subscribe(g))
            })(f)
        }
    };

    function gf(a) {
        return hd(function(b, c) {
            var d = !1,
                e = 0;
            b.subscribe(new M(c, function(f) {
                return (d || (d = !a(f, e++))) && c.next(f)
            }))
        })
    };

    function R() {
        var a = E.apply(0, arguments),
            b = Yc(a);
        return hd(function(c, d) {
            (b ? Dd(a, c, b) : Dd(a, c)).subscribe(d)
        })
    };

    function S(a) {
        return hd(function(b, c) {
            var d = null,
                e = 0,
                f = !1;
            b.subscribe(new M(c, function(g) {
                var h;
                (h = d) == null || h.unsubscribe();
                h = e++;
                Pc(a(g, h)).subscribe(d = new M(c, function(k) {
                    return c.next(k)
                }, void 0, function() {
                    d = null;
                    f && !d && c.complete()
                }))
            }, void 0, function() {
                (f = !0, !d) && c.complete()
            }))
        })
    };

    function hf(a, b) {
        b = b === void 0 ? !1 : b;
        return hd(function(c, d) {
            var e = 0;
            c.subscribe(new M(d, function(f) {
                var g = a(f, e++);
                (g || b) && d.next(f);
                !g && d.complete()
            }))
        })
    };

    function jf(a, b, c) {
        var d = J(a) || b || c ? {
            next: a,
            error: b,
            complete: c
        } : a;
        return d ? hd(function(e, f) {
            e.subscribe(new M(f, function(g) {
                var h;
                (h = d.next) == null || h.call(d, g);
                f.next(g)
            }, function(g) {
                var h;
                (h = d.error) == null || h.call(d, g);
                f.error(g)
            }, function() {
                var g;
                (g = d.complete) == null || g.call(d);
                f.complete()
            }))
        }) : tc
    };

    function kf() {
        var a = E.apply(0, arguments),
            b = Xc(a);
        return hd(function(c, d) {
            for (var e = a.length, f = Array(e), g = a.map(function() {
                    return !1
                }), h = !1, k = {
                    Ua: 0
                }; k.Ua < e; k = {
                    Ua: k.Ua
                }, k.Ua++) Pc(a[k.Ua]).subscribe(new M(d, function(l) {
                return function(m) {
                    f[l.Ua] = m;
                    h || g[l.Ua] || (g[l.Ua] = !0, (h = g.every(tc)) && (g = null))
                }
            }(k), void 0, nc));
            c.subscribe(new M(d, function(l) {
                h && (l = [l].concat(y(f)), d.next(b ? b.apply(null, y(l)) : l))
            }))
        })
    };
    var lf = function(a) {
        this.ia = a
    };
    lf.prototype.O = function(a) {
        return (a == null ? 0 : a.oc) ? !0 : (a == null ? void 0 : a.fa) === "POST" || (a == null ? 0 : a.jb) || (a == null ? 0 : a.nd) ? !1 : this.ia.O()
    };
    lf.prototype.ping = function() {
        var a = this,
            b = Zc.apply(null, y(E.apply(0, arguments))).g(Bd(function(c) {
                return mf(a, c)
            }), Ye(function(c) {
                return c
            }), cf(1));
        b.connect();
        return b
    };
    var mf = function(a, b) {
        var c = new bd(1);
        nf(a.ia, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    };
    lf.prototype.Gd = function(a, b, c) {
        this.ping.apply(this, y(E.apply(3, arguments)))
    };

    function of (a, b) {
        var c = !1;
        return new L(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };
    var pf = function(a) {
        this.ia = a;
        this.timeline = pe
    };
    n = pf.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.ia.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.ia.clearTimeout(a)
    };
    n.now = function() {
        return new qe(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Ba(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ba = function(a) {
        return of(this, a).g(df(), ef(function(b) {
            return b + 1
        }, -1))
    };
    n.ka = function() {
        return !0
    };
    var qf = function(a, b) {
        this.context = a;
        this.ac = b
    };
    qf.prototype.O = function(a) {
        return this.ac.O(a)
    };
    qf.prototype.M = function(a, b) {
        if (!this.O(b)) throw new ee;
        return new rf(this.context, this.ac, b != null ? b : void 0, a)
    };
    var rf = function(a, b, c, d) {
        var e = this;
        this.ac = b;
        this.properties = c;
        this.url = d;
        this.xd = !0;
        this.jb = new Map;
        this.body = void 0;
        var f;
        this.method = (f = c == null ? void 0 : c.fa) != null ? f : "GET";
        this.oh = a.ve().subscribe(function() {
            e.sendNow()
        })
    };
    rf.prototype.deactivate = function() {
        this.xd = !1
    };
    rf.prototype.sendNow = function() {
        if (this.xd)
            if (this.oh.unsubscribe(), this.ac.O(this.properties)) try {
                if (this.jb.size > 0 || this.body !== void 0) {
                    var a, b;
                    this.ac.Gd((a = this.properties) != null ? a : {}, this.jb, (b = this.body) != null ? b : "", this.url)
                } else this.ac.ping(this.url);
                this.xd = !1
            } catch (c) {} else this.xd = !1
    };
    var tf = function(a, b, c, d, e, f) {
            this.mode = a;
            this.m = b;
            this.setTime = c;
            this.Rc = d;
            this.lj = e;
            this.th = f;
            this.completed = !1;
            this.id = this.mode === 0 ? sf(this) : 0
        },
        sf = function(a) {
            return a.m.setTimeout(function() {
                uf(a)
            }, a.Rc)
        },
        vf = function(a, b) {
            var c = se(b, a.setTime);
            c >= a.Rc ? uf(a) : (a.setTime = b, a.Rc -= c)
        },
        uf = function(a) {
            try {
                a.lj(a.setTime.add(a.Rc))
            } finally {
                a.completed = !0, a.th()
            }
        };
    tf.prototype.mf = function(a, b) {
        this.completed || (this.mode === 1 && a === 1 ? vf(this, b) : this.mode === 1 && a === 0 ? (this.mode = a, vf(this, this.m.now()), this.completed || (this.id = sf(this))) : this.mode === 0 && a === 1 && (this.mode = a, this.clear(), vf(this, b)))
    };
    tf.prototype.clear = function() {
        this.completed || this.m.clearTimeout(this.id)
    };
    var wf = function(a) {
        this.od = a;
        this.bi = this.mode = 0;
        this.Sb = {};
        this.timeline = a.timeline;
        this.tb = a.now()
    };
    n = wf.prototype;
    n.mf = function(a, b) {
        this.mode = a;
        re(this.tb, b);
        this.tb = b;
        Object.values(this.Sb).forEach(function(c) {
            return void c.mf(a, b)
        })
    };
    n.now = function() {
        return this.mode === 1 ? this.tb : this.od.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.bi,
            e = this.mode === 1 ? this.tb : this.od.now();
        this.Sb[d] = new tf(this.mode, this.od, e, b, function(f) {
            var g = c.tb;
            c.mode === 1 && (c.tb = f);
            a();
            c.tb = g
        }, function() {
            delete c.Sb[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.Sb[a] && (this.Sb[a].clear(), delete this.Sb[a])
    };
    n.interval = function() {
        throw Error("y");
    };
    n.Ba = function() {
        throw Error("z");
    };
    n.ka = function() {
        return this.od.ka()
    };

    function xf(a, b) {
        var c = new wf(a);
        a = b.subscribe(function(d) {
            c.mf(d.value ? 1 : 0, d.timestamp)
        });
        return {
            m: c,
            ik: a
        }
    };

    function yf(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new qe(a.timestamp, pe),
            value: b
        }
    };

    function zf(a) {
        return a !== void 0 && typeof a.x === "number" && typeof a.y === "number" && typeof a.width === "number" && typeof a.height === "number"
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function Af(a) {
        var b = E.apply(1, arguments),
            c = b.length;
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !ob && a === a.raw || !(ob && !pb || mb(a)) || c + 1 !== a.length) throw new TypeError("q");
        if (b.length === 0) return cb(a[0]);
        c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("G");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("A");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("B");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("C");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("D");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if (c === "/" || c.length > 1 && c[1] !== "/" && c[1] !== "\\") d = !0;
                else throw Error("F");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if (c !== "about:blank" && !/^about:blank#/.test(c)) throw Error("E");
                d = !0
            } else d = !1;
        if (!d) throw Error("H");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return cb(c)
    };
    var Bf = ra(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Cf = ra(["./reach_worklet.js"]),
        Df = ra(["./reach_worklet.js"]),
        Ef = ra(["./reach_worklet.html"]),
        Ff = ra(["./reach_worklet.js"]),
        Gf = ra(["./reach_worklet.js"]);

    function Hf(a) {
        var b = {};
        return b[0] = Af(Bf, a), b[1] = Af(Cf), b[2] = Af(Df), b
    }
    Af(Ef);
    Af(Ff);
    Af(Gf);
    var Jf = function(a, b, c, d) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? Hf("current") : d;
        Zd.call(this);
        this.ia = a;
        this.Rd = b;
        this.Ha = c;
        this.ef = d;
        this.Wa = null;
        this.af = new bd(3);
        this.af.g(O(function(e) {
            return e.value.type === "sessionStart"
        }));
        this.bj = this.af.g(O(function(e) {
            return e.value.type === "sessionFinish"
        }));
        this.hg = new bd(1);
        this.pj = new bd;
        this.Wf = new bd(10);
        this.L = new qf(this, new lf(a));
        this.ii = this.ia.O();
        this.m = If(this, new pf(this.ia))
    };
    q(Jf, Zd);
    var Kf = function(a) {
        a.Wa !== null && Je(a.Wa)
    };
    Jf.prototype.validate = function() {
        return this.ii
    };
    var If = function(a, b) {
        a.Wa = new xe(a.ia, a.Rd);
        var c = new bd;
        ye(a.Wa, function(f) {
            f = yf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.af.next(f)
        });
        Ae(a.Wa, function(f) {
            if (f === void 0) var g = !1;
            else {
                g = f.data;
                var h;
                (h = g === void 0) || (h = g.viewport, h = h === void 0 || h !== void 0 && typeof h.width === "number" && typeof h.height === "number");
                h ? (g = g.adView, g = g !== void 0 && typeof g.percentageInView === "number" && (g.geometry === void 0 || zf(g.geometry)) && (g.onScreenGeometry === void 0 || zf(g.onScreenGeometry))) : g = !1
            }
            g ? (f = yf(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.Wf.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.L.M(f).sendNow())
        });
        ze(a.Wa, function(f) {
            f = yf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.pj.next(f)
        });
        De(a.Wa, function(f) {
            f = yf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.hg.next(f)
        });
        var d = 0;
        Ee(a.Wa, function(f) {
            d += f;
            d > 0 && f === 0 && c.next({
                timestamp: a.m.now(),
                value: !1
            })
        });
        var e = c.g(hf(function(f) {
            return f.value
        }, !0));
        return xf(b,
            e).m
    };
    da.Object.defineProperties(Jf.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Lf
            }
        }
    });
    var Lf = {};

    function Mf(a, b) {
        if (!b) throw Error("I`" + a);
        if (typeof b !== "string" && !(b instanceof String)) throw Error("J`" + a);
        if (b.trim() === "") throw Error("K`" + a);
    }

    function Nf(a) {
        if (!a) throw Error("N`functionToExecute");
    }

    function Of(a, b) {
        if (b == null) throw Error("L`" + a);
        if (typeof b !== "number" || isNaN(b)) throw Error("M`" + a);
        if (b < 0) throw Error("O`" + a);
    };

    function Pf() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.6.1-google_20251208")
    }

    function Qf() {
        for (var a = ["1", "6", "1"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var Rf = function(a, b, c, d) {
            this.fg = a;
            this.method = b;
            this.version = c;
            this.args = d
        },
        Sf = function(a) {
            return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
        },
        Tf = function(a) {
            return new Rf(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
        };
    Rf.prototype.Ya = function() {
        var a = {};
        a = (a.omid_message_guid = this.fg, a.omid_message_method = this.method, a.omid_message_version = this.version, a);
        this.args !== void 0 && (a.omid_message_args = this.args);
        return a
    };
    var Uf = function(a) {
        this.to = a
    };
    Uf.prototype.Ya = function() {
        return JSON.stringify(void 0)
    };

    function Vf(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }
    var Wf = function(a) {
            return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
                return Vf(a, b)
            })
        },
        Xf = function(a) {
            for (var b = x(Object.values(ve)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = {};
                d = (d.app = "omid_v1_present_app", d.web = "omid_v1_present_web", d)[c];
                if (Vf(a, d)) return c
            }
            return null
        };

    function Yf(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function Zf() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function $f() {
        var a = E.apply(0, arguments);
        ag(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(y(a))));
        }, function() {
            return console.error.apply(console, y(a))
        })
    }

    function ag(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var bg = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("P");
    }();
    var cg = function(a) {
        this.to = a;
        this.handleExportedMessage = cg.prototype.Qh.bind(this)
    };
    q(cg, Uf);
    cg.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("Q");
        b.handleExportedMessage(a.Ya(), this)
    };
    cg.prototype.Qh = function(a, b) {
        if (Sf(a) && this.onMessage) this.onMessage(Tf(a), b)
    };

    function dg(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function eg(a) {
        if (a === bg) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function fg() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return dg(a) ? a : bg
    };
    var gg = function(a, b) {
        this.to = b = b === void 0 ? bg : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if (typeof d.data === "object") {
                var e = d.data;
                if (Sf(e) && d.source && c.onMessage) c.onMessage(Tf(e), d.source)
            }
        })
    };
    q(gg, Uf);
    gg.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("Q");
        b.postMessage(a.Ya(), "*")
    };
    var hg = ["omid", "v1_VerificationServiceCommunication"],
        ig = ["omidVerificationProperties", "serviceWindow"];

    function jg(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };
    var kg = function(a) {
        if (!a) {
            a = fg();
            var b = b === void 0 ? Wf : b;
            var c = [],
                d = jg(a, ig);
            d && c.push(d);
            c.push(dg(a) ? a.top : bg);
            a: {
                c = x(c);
                for (var e = c.next(); !e.done; e = c.next()) {
                    b: {
                        d = a;e = e.value;
                        var f = b;
                        if (!eg(e)) try {
                            var g = jg(e, hg);
                            if (g) {
                                var h = new cg(g);
                                break b
                            }
                        } catch (k) {}
                        h = f(e) ? new gg(d, e) : null
                    }
                    if (d = h) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.tc = a) this.tc.onMessage = this.Rh.bind(this);
        else if (b = (b = bg.omid3p) && typeof b.registerSessionObserver === "function" && typeof b.addEventListener === "function" ? b : null) this.Mc = b;
        this.Pi = this.Qi =
            0;
        this.de = {};
        this.ze = [];
        (this.Rb = (b = bg.omidVerificationProperties) ? b.injectionId : void 0) || Zf()
    };
    kg.prototype.O = function() {
        var a = fg();
        var b = (b = bg.omidVerificationProperties) && b.injectionSource ? b.injectionSource : void 0;
        return (b || Xf(a) || Xf(dg(a) ? a.top : bg)) !== "web" || this.Rb ? !(!this.tc && !this.Mc) : !1
    };
    var Ge = function(a, b, c) {
        Nf(b);
        a.Mc ? a.Mc.registerSessionObserver(b, c, a.Rb) : a.dc("addSessionListener", b, c, a.Rb)
    };
    kg.prototype.addEventListener = function(a, b) {
        Mf("eventType", a);
        Nf(b);
        this.Mc ? this.Mc.addEventListener(a, b, this.Rb) : this.dc("addEventListener", b, a, this.Rb)
    };
    var nf = function(a, b, c, d) {
            Mf("url", b);
            bg.document && bg.document.createElement ? lg(a, b, c, d) : a.dc("sendUrl", function(e) {
                e && c ? c() : !e && d && d()
            }, b)
        },
        lg = function(a, b, c, d) {
            var e = bg.document.createElement("img");
            a.ze.push(e);
            var f = function(g) {
                var h = a.ze.indexOf(e);
                h >= 0 && a.ze.splice(h, 1);
                g && g()
            };
            e.addEventListener("load", f.bind(a, c));
            e.addEventListener("error", f.bind(a, d));
            e.src = b
        };
    kg.prototype.setTimeout = function(a, b) {
        Nf(a);
        Of("timeInMillis", b);
        if (mg()) return bg.setTimeout(a, b);
        var c = this.Qi++;
        this.dc("setTimeout", a, c, b);
        return c
    };
    kg.prototype.clearTimeout = function(a) {
        Of("timeoutId", a);
        mg() ? bg.clearTimeout(a) : this.Fg("clearTimeout", a)
    };
    kg.prototype.setInterval = function(a, b) {
        Nf(a);
        Of("timeInMillis", b);
        if (ng()) return bg.setInterval(a, b);
        var c = this.Pi++;
        this.dc("setInterval", a, c, b);
        return c
    };
    kg.prototype.clearInterval = function(a) {
        Of("intervalId", a);
        ng() ? bg.clearInterval(a) : this.Fg("clearInterval", a)
    };
    var mg = function() {
            return typeof bg.setTimeout === "function" && typeof bg.clearTimeout === "function"
        },
        ng = function() {
            return typeof bg.setInterval === "function" && typeof bg.clearInterval === "function"
        };
    kg.prototype.Rh = function(a) {
        var b = a.method,
            c = a.fg;
        a = a.args;
        if (b === "response" && this.de[c]) {
            var d = Pf() && Qf() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
            this.de[c].apply(this, d)
        }
        b === "error" && window.console && $f(a)
    };
    kg.prototype.Fg = function(a) {
        this.dc.apply(this, [a, null].concat(y(E.apply(1, arguments))))
    };
    kg.prototype.dc = function(a, b) {
        var c = E.apply(2, arguments);
        if (this.tc) {
            var d = Zf();
            b && (this.de[d] = b);
            var e = "VerificationService." + a;
            c = Pf() && Qf() ? c : JSON.stringify(c);
            this.tc.sendMessage(new Rf(d, e, "1.6.1-google_20251208", c))
        }
    };
    var og = void 0;
    if (og = og === void 0 ? typeof omidExports === "undefined" ? null : omidExports : og) {
        var pg = ["OmidVerificationClient"];
        pg.slice(0, pg.length - 1).reduce(Yf, og)[pg[pg.length - 1]] = kg
    };

    function qg(a, b) {
        return function(c) {
            return new L(function(d) {
                return c.subscribe(function(e) {
                    a.kc(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.kc(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.kc(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };
    var sg = function() {
        for (var a = x(E.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.ka()) {
                this.m = b;
                return
            }
        this.m = new rg
    };
    n = sg.prototype;
    n.ka = function() {
        return this.m.ka()
    };
    n.now = function() {
        return this.m.now()
    };
    n.setTimeout = function(a, b) {
        return this.m.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.m.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ba(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ba = function(a) {
        return this.m.Ba(a)
    };
    da.Object.defineProperties(sg.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.m.timeline
            }
        }
    });
    var rg = function() {
        this.timeline = Symbol()
    };
    n = rg.prototype;
    n.ka = function() {
        return !1
    };
    n.now = function() {
        return new qe(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Ba = function() {
        return Qd
    };
    var tg = function(a, b) {
        this.R = a;
        this.J = b
    };
    n = tg.prototype;
    n.setTimeout = function(a, b) {
        return this.R.setTimeout(this.J.kc(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.R.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ba(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ba = function(a) {
        var b = this;
        return new L(function(c) {
            var d = 0,
                e = b.R.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.R.clearInterval(e)
            }
        })
    };
    n.ka = function() {
        return !!this.R.clearTimeout && "setTimeout" in this.R && "setInterval" in this.R && !!this.R.clearInterval
    };
    var ug = function(a, b) {
        tg.call(this, a, b);
        this.timeline = pe
    };
    q(ug, tg);
    ug.prototype.now = function() {
        return new qe(this.R.Date.now(), this.timeline)
    };
    ug.prototype.ka = function() {
        return !!this.R.Date && !!this.R.Date.now && tg.prototype.ka.call(this)
    };
    var yg = function(a, b) {
        tg.call(this, a, b);
        this.timeline = oe
    };
    q(yg, tg);
    yg.prototype.now = function() {
        return new qe(this.R.performance.now(), this.timeline)
    };
    yg.prototype.ka = function() {
        return !!this.R.performance && !!this.R.performance.now && tg.prototype.ka.call(this)
    };

    function zg(a) {
        a = a.global;
        if (a.fetchLater) return a.fetchLater.bind(a)
    }

    function Ag(a) {
        var b, c, d = (b = a.global) == null ? void 0 : (c = b.document) == null ? void 0 : c.createElement("meta");
        if (d) try {
            return d.httpEquiv = "origin-trial", d.content = "AxjhRadLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9", a.global.document.head.append(d), d
        } catch (e) {}
    }
    var Cg = function(a) {
            this.context = a;
            Bg === void 0 && (Bg = Ag(a))
        },
        Bg;
    Cg.prototype.O = function(a) {
        return zg(this.context) !== void 0 && !(a == null || !a.Of) && !Dg(this.context) && !(a == null ? 0 : a.oc) && !(a == null ? 0 : a.jb) && !(a == null ? 0 : a.nd)
    };
    Cg.prototype.M = function(a, b) {
        if (!this.O(b)) throw new ee;
        return new Eg(this.context, a, b)
    };
    var Eg = function(a, b, c) {
            this.context = a;
            this.properties = c;
            this.Hb = b;
            var d;
            this.fa = (d = c == null ? void 0 : c.fa) != null ? d : "GET";
            a = zg(this.context);
            if (a === void 0) throw Error();
            this.fetchLater = a;
            Fg(this, this.Gc())
        },
        Fg = function(a, b) {
            a.Ra && a.Ra.activated || (a.qc = new AbortController, a.Ra = a.fetchLater(b, {
                method: a.fa,
                cache: "no-cache",
                mode: "no-cors",
                signal: a.qc.signal,
                activateAfter: 96E4
            }))
        };
    Eg.prototype.Gc = function() {
        var a = this.Hb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "flapi=1"
    };
    Eg.prototype.deactivate = function() {
        this.Ra && !this.Ra.activated && this.qc && (this.qc.abort(), this.Ra = void 0)
    };
    Eg.prototype.sendNow = function() {};
    da.Object.defineProperties(Eg.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Hb
            },
            set: function(a) {
                this.Hb = a;
                a = this.Gc();
                this.Ra && this.Ra.activated || !this.qc || (this.qc.abort(), this.Ra = void 0);
                Fg(this, a)
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.fa
            }
        }
    });
    var Gg = function(a) {
        this.context = a
    };
    Gg.prototype.O = function() {
        return !Dg(this.context) && !!this.context.global.fetch
    };
    Gg.prototype.ping = function() {
        var a = this;
        return Pd.apply(null, y(E.apply(0, arguments).map(function(b) {
            return Oc(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).g(N(function(c) {
                return c.status === 200
            }))
        }))).g(Ye(function(b) {
            return b
        }), $e())
    };
    Gg.prototype.Gd = function(a, b, c) {
        for (var d = E.apply(3, arguments), e = this, f = new Headers, g = x(b.entries()), h = g.next(); !h.done; h = g.next()) {
            var k = x(h.value);
            h = k.next().value;
            k = k.next().value;
            f.set(h, k)
        }
        var l, m = (l = a.keepAlive) != null ? l : !1;
        Pd.apply(null, y(d.map(function(u) {
            return Oc(e.context.global.fetch(u, Object.assign({}, {
                method: String(a.fa),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).g(N(function(t) {
                return t.status === 200
            }))
        }))).g(Ye(function(u) {
            return u
        }), $e())
    };
    var Hg = function(a) {
        Hg[" "](a);
        return a
    };
    Hg[" "] = function() {};
    var Ig = function(a, b) {
        try {
            return Hg(a[b]), !0
        } catch (c) {}
        return !1
    };

    function Jg(a) {
        try {
            return !!a && a.location.href != null && Ig(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var Kg = Ia(1, !0),
        Lg = Ia(610401301, !1);
    Ia(899588437, !1);
    Ia(772657768, !0);
    Ia(513659523, !0);
    Ia(568333945, !0);
    Ia(1331761403, !1);
    Ia(651175828, !0);
    Ia(722764542, !0);
    Ia(748402145, !0);
    Ia(748402146, !0);
    var Mg = Ia(748402147, !0),
        Ng = Ia(824648567, !0);
    Ia(824656860, Kg);
    Ia(333098724, !1);
    Ia(861377723, !0);
    Ia(861377724, !0);
    Ia(2147483644, !1);
    Ia(2147483645, !0);
    Ia(2147483646, Kg);
    Ia(2147483647, !0);

    function Og() {
        var a = Ha.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Pg, Qg = Ha.navigator;
    Pg = Qg ? Qg.userAgentData || null : null;

    function Rg(a) {
        if (!Lg || !Pg) return !1;
        for (var b = 0; b < Pg.brands.length; b++) {
            var c = Pg.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function U(a) {
        return Og().indexOf(a) != -1
    };

    function Sg() {
        return Lg ? !!Pg && Pg.brands.length > 0 : !1
    }

    function Tg() {
        return Sg() ? !1 : U("Opera")
    }

    function Ug() {
        return U("Firefox") || U("FxiOS")
    }

    function Vg() {
        return U("Safari") && !(Wg() || (Sg() ? 0 : U("Coast")) || Tg() || (Sg() ? 0 : U("Edge")) || (Sg() ? Rg("Microsoft Edge") : U("Edg/")) || (Sg() ? Rg("Opera") : U("OPR")) || Ug() || U("Silk") || U("Android"))
    }

    function Wg() {
        return Sg() ? Rg("Chromium") : (U("Chrome") || U("CriOS")) && !(Sg() ? 0 : U("Edge")) || U("Silk")
    }

    function Xg() {
        return U("Android") && !(Wg() || Ug() || Tg() || U("Silk"))
    };

    function Yg() {
        return Lg && Pg ? Pg.mobile : !Zg() && (U("iPod") || U("iPhone") || U("Android") || U("IEMobile"))
    }

    function Zg() {
        return Lg && Pg ? !Pg.mobile && (U("iPad") || U("Android") || U("Silk")) : U("iPad") || U("Android") && !U("Mobile") || U("Silk")
    };

    function $g() {
        return Lg ? !!Pg && !!Pg.platform : !1
    }

    function ah() {
        return U("iPhone") && !U("iPod") && !U("iPad")
    }

    function bh() {
        ah() || U("iPad") || U("iPod")
    };
    Tg();
    var ch = Sg() ? !1 : U("Trident") || U("MSIE");
    U("Edge");
    var dh = U("Gecko") && !(Va(Og(), "WebKit") && !U("Edge")) && !(U("Trident") || U("MSIE")) && !U("Edge"),
        eh = Va(Og(), "WebKit") && !U("Edge");
    eh && U("Mobile");
    $g() || U("Macintosh");
    $g() || U("Windows");
    ($g() ? Pg.platform === "Linux" : U("Linux")) || $g() || U("CrOS");
    $g() || U("Android");
    ah();
    U("iPad");
    U("iPod");
    bh();
    Va(Og(), "KaiOS");

    function fh(a, b) {
        b = b === void 0 ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return fh(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = gh(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = x(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + fh(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = gh(c.constructor)), typeof a.toString === "function" && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + gh(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function gh(a) {
        var b = a.displayName;
        return b && typeof b === "string" || (b = a.name) && typeof b === "string" ? b : (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)"
    };

    function hh(a, b) {
        var c = ih,
            d = [];
        jh(b, a, d) || kh.apply(null, [void 0, c, "Guard " + b.xe().trim() + " failed:"].concat(y(d.reverse())))
    }

    function lh(a, b) {
        a.dk = !0;
        a.xe = typeof b === "function" ? b : function() {
            return b
        };
        return a
    }

    function jh(a, b, c) {
        var d = a(b, c);
        d || mh(c, function() {
            var e = "";
            e.length > 0 && (e += ": ");
            return e + "Expected " + a.xe().trim() + ", got " + fh(b)
        });
        return d
    }

    function mh(a, b) {
        a == null || a.push((typeof b === "function" ? b() : b).trim())
    }
    var ih = void 0;

    function nh(a) {
        return typeof a === "function" ? a() : a
    }

    function kh() {
        throw Error(E.apply(0, arguments).map(nh).filter(Boolean).join("\n").trim().replace(/:$/, ""));
    };
    var oh = lh(function(a) {
            return typeof a === "number"
        }, "number"),
        ph = lh(function(a) {
            return typeof a === "string"
        }, "string"),
        qh = lh(function(a) {
            return typeof a === "boolean"
        }, "boolean"),
        rh = lh(function(a) {
            return typeof a === "bigint"
        }, "bigint");

    function sh() {
        var a = Error;
        return lh(function(b) {
            return b instanceof a
        }, function() {
            return gh(a)
        })
    }

    function th() {
        var a = E.apply(0, arguments);
        return lh(function(b) {
            return a.some(function(c) {
                return c(b)
            })
        }, function() {
            return "" + a.map(function(b) {
                return b.xe().trim()
            }).join(" | ")
        })
    };

    function uh(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    n = uh.prototype;
    n.clone = function() {
        return new uh(this.x, this.y)
    };
    n.toString = function() {
        return "(" + this.x + ", " + this.y + ")"
    };
    n.equals = function(a) {
        return a instanceof uh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    n.translate = function(a, b) {
        a instanceof uh ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), typeof b === "number" && (this.y += b));
        return this
    };
    n.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function vh(a, b) {
        this.width = a;
        this.height = b
    }
    n = vh.prototype;
    n.clone = function() {
        return new vh(this.width, this.height)
    };
    n.toString = function() {
        return "(" + this.width + " x " + this.height + ")"
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.isEmpty = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    n.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };
    var yh = function(a) {
            return a ? new wh(xh(a)) : ub || (ub = new wh)
        },
        zh = function(a) {
            var b = a.scrollingElement ? a.scrollingElement : eh || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
            a = a.defaultView;
            return new uh((a == null ? void 0 : a.pageXOffset) || b.scrollLeft, (a == null ? void 0 : a.pageYOffset) || b.scrollTop)
        },
        Ah = function(a, b, c) {
            function d(h) {
                h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!Ka(f) || La(f) && f.nodeType > 0) d(f);
                else {
                    a: {
                        if (f && typeof f.length ==
                            "number") {
                            if (La(f)) {
                                var g = typeof f.item == "function" || typeof f.item == "string";
                                break a
                            }
                            if (typeof f === "function") {
                                g = typeof f.item == "function";
                                break a
                            }
                        }
                        g = !1
                    }
                    Fb(g ? Jb(f) : f, d)
                }
            }
        },
        xh = function(a) {
            F(a, "Node cannot be null or undefined.");
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        Bh = function(a, b) {
            a && (a = a.parentNode);
            for (var c = 0; a;) {
                F(a.name != "parentNode");
                if (b(a)) return a;
                a = a.parentNode;
                c++
            }
            return null
        },
        wh = function(a) {
            this.xc = a || Ha.document || document
        };
    n = wh.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.xc).getElementsByTagName(String(a))
    };
    n.createElement = function(a) {
        var b = this.xc;
        a = String(a);
        b.contentType === "application/xhtml+xml" && (a = a.toLowerCase());
        return b.createElement(a)
    };
    n.createTextNode = function(a) {
        return this.xc.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        F(a != null && b != null, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        Ah(xh(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.isElement = function(a) {
        return La(a) && a.nodeType == 1
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Ch(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    n = Ch.prototype;
    n.eg = function() {
        return this.right - this.left
    };
    n.bg = function() {
        return this.bottom - this.top
    };
    n.clone = function() {
        return new Ch(this.top, this.right, this.bottom, this.left)
    };
    n.toString = function() {
        return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
    };
    n.contains = function(a) {
        return this && a ? a instanceof Ch ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    n.expand = function(a, b, c, d) {
        La(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    n.translate = function(a, b) {
        a instanceof uh ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (zb(a), this.left += a, this.right += a, typeof b === "number" && (this.top += b, this.bottom += b));
        return this
    };
    n.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };
    var Dh = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };

    function Eh(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    };
    var Fh = function(a) {
        this.context = a
    };
    Fh.prototype.O = function(a) {
        return (a == null ? 0 : a.oc) || (a == null ? void 0 : a.fa) === "POST" || (a == null ? 0 : a.jb) || (a == null ? 0 : a.nd) || (a == null ? 0 : a.keepAlive) ? !1 : !Dg(this.context)
    };
    Fh.prototype.ping = function() {
        var a = this;
        return Zc(E.apply(0, arguments).map(function(b) {
            try {
                var c = a.context.global;
                c.google_image_requests || (c.google_image_requests = []);
                var d = c.document;
                d = d === void 0 ? document : d;
                var e = d.createElement("img");
                e.src = b;
                c.google_image_requests.push(e);
                return !0
            } catch (f) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    Fh.prototype.Gd = function(a, b, c) {
        this.ping.apply(this, y(E.apply(3, arguments)))
    };

    function Gh(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }
    var Hh = function(a) {
        this.context = a
    };
    Hh.prototype.O = function(a) {
        return Ih && !Dg(this.context) && Gh(this.context) !== void 0 && !(a == null ? 0 : a.oc) && (a == null ? void 0 : a.fa) !== "POST" && !(a == null ? 0 : a.jb) && !(a == null ? 0 : a.nd)
    };
    Hh.prototype.M = function(a, b) {
        if (!this.O(b)) throw new ee;
        return new Jh(this.context, a)
    };
    var Ih = !1,
        Jh = function(a, b) {
            this.context = a;
            this.Hb = b;
            a = Gh(this.context);
            if (a === void 0) throw Error();
            this.rf = new a(this.Gc(), {})
        };
    Jh.prototype.Gc = function() {
        var a = this.Hb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "pbapi=1"
    };
    Jh.prototype.deactivate = function() {
        this.rf.deactivate()
    };
    Jh.prototype.sendNow = function() {
        this.rf.sendNow()
    };
    da.Object.defineProperties(Jh.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Hb
            },
            set: function(a) {
                this.Hb = a;
                this.rf.setURL(this.Gc())
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if (a !== "GET") throw new ee;
            }
        }
    });
    var Kh = function(a) {
        this.context = a
    };
    Kh.prototype.O = function(a) {
        if ((a == null ? 0 : a.oc) || (a == null ? void 0 : a.fa) === "GET" || (a == null ? 0 : a.jb) || (a == null ? 0 : a.nd) || (a == null ? 0 : a.keepAlive)) return !1;
        var b;
        return !Dg(this.context) && ((b = this.context.global.navigator) == null ? void 0 : b.sendBeacon) !== void 0
    };
    Kh.prototype.ping = function() {
        var a = this;
        return Zc(E.apply(0, arguments).map(function(b) {
            var c;
            return (c = a.context.global.navigator) == null ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    Kh.prototype.Gd = function(a, b, c) {
        this.ping.apply(this, y(E.apply(3, arguments)))
    };

    function Lh(a) {
        return function(b) {
            return b.g(Mh(a, af(new xc)))
        }
    }

    function V(a, b) {
        return function(c) {
            return c.g(Mh(a, cf(b)))
        }
    }

    function Mh(a, b) {
        function c(d) {
            return new L(function(e) {
                return d.subscribe(function(f) {
                    Ta(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    Ta(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    Ta(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return K(c, ld(), b, id(), c)
    };
    var W = function(a) {
        this.value = a
    };
    W.prototype.W = function(a) {
        return Zc(this.value).g(V(a, 1))
    };
    var Nh = new W(!1);

    function Oh(a) {
        Ha.setTimeout(function() {
            throw a;
        }, 0)
    };
    Ug();
    ah() || U("iPod");
    U("iPad");
    Xg();
    Wg();
    Vg() && bh();
    var Ph = {},
        Qh = null,
        Rh = dh || eh || typeof Ha.btoa == "function";

    function Sh(a) {
        var b;
        F(Ka(a), "encodeByteArray takes an array as a parameter");
        b === void 0 && (b = 0);
        Th();
        b = Ph[b];
        for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = "" + l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Uh(a) {
        var b = a.length,
            c = b * 3 / 4;
        c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
        var d = new Uint8Array(c),
            e = 0;
        Vh(a, function(f) {
            d[e++] = f
        });
        return e !== c ? d.subarray(0, e) : d
    }

    function Vh(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = Qh[l];
                if (m != null) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("S`" + l);
            }
            return k
        }
        Th();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Th() {
        if (!Qh) {
            Qh = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                var d = a.concat(b[c].split(""));
                Ph[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e],
                        g = Qh[f];
                    g === void 0 ? Qh[f] = e : F(g === e)
                }
            }
        }
    };

    function Wh(a) {
        var b = Xh(a);
        return b === null ? new W(null) : b.g(N(function(c) {
            c = c.Ya();
            if (Rh) c = Ha.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    if (g > 255) throw Error("R");
                    d[e++] = g
                }
                c = Sh(d)
            }
            return c
        }), Re(1), V(a.i, 1))
    };

    function Yh(a) {
        var b = b === void 0 ? {} : b;
        if (typeof Event === "function") return new Event(a, b);
        if (typeof document !== "undefined") {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };
    var Zh = function(a) {
        this.value = a;
        this.We = new xc
    };
    Zh.prototype.release = function() {
        this.We.next();
        this.We.complete();
        this.value = void 0
    };
    da.Object.defineProperties(Zh.prototype, {
        l: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        released: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.We
            }
        }
    });
    var $h = ["FRAME", "IMG", "IFRAME"],
        ai = /^[01](px)?$/,
        bi = function() {
            this.li = this.Bf = this.Bg = this.Kf = !1
        },
        ci = function() {
            var a = new bi;
            a.Kf = !0;
            a.Bg = !0;
            return a
        };

    function di(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }

    function ei(a, b) {
        b = b === void 0 ? !1 : b;
        if (a.tagName === "IMG") {
            if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
            var c;
            if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
        }
        var d, e;
        return ai.test((d = a.getAttribute("width")) != null ? d : "") && ai.test((e = a.getAttribute("height")) != null ? e : "")
    }

    function fi(a, b) {
        if (a.tagName === "IMG") return a.naturalWidth && a.naturalHeight ? !0 : !1;
        try {
            if (a.readyState) var c = a.readyState;
            else {
                var d, e;
                c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
            }
            return c === "complete"
        } catch (f) {
            return b === void 0 ? !1 : b
        }
    }

    function gi(a) {
        a || (a = function(b, c, d) {
            b.addEventListener(c, d)
        });
        return a
    }

    function hi(a, b) {
        var c = ci();
        c = c === void 0 ? new bi : c;
        if (a = di(a)) {
            var d = gi(d);
            for (var e = !1, f = function(z) {
                    e || (e = !0, b(z))
                }, g, h = 2, k = 0; k < $h.length; ++k)
                if ($h[k] === a.tagName) {
                    h = 3;
                    g = [a];
                    break
                }
            g || (g = a.querySelectorAll($h.join(",")));
            var l = 0,
                m = 0,
                u = !c.Bf,
                t = a = !1;
            k = {};
            for (var r = 0; r < g.length; k = {
                    yd: void 0
                }, r++) {
                var w = g[r];
                if (!ei(w, c.Bf))
                    if (k.yd = w.tagName === "IMG", fi(w, c.Kf)) a = !0, k.yd && (u = !0);
                    else {
                        l++;
                        var v = function(z) {
                            return function(C) {
                                l--;
                                !l && u && f(h);
                                z.yd && (C = C && C.type === "error", m--, C || (u = !0), !m && t && u && f(h))
                            }
                        }(k);
                        d(w, "load", v);
                        k.yd && (m++, d(w, "error", v))
                    }
            }
            m === 0 && (u = !0);
            g = null;
            g = Ha.document.readyState === "complete";
            if (c.li && g) {
                if (m > 0) {
                    t = !0;
                    return
                }
                h = 5
            } else if (l === 0 && !a && g) h = 5;
            else if (l || !a) {
                d(Ha, "load", function() {
                    !c.Bg || !m && u ? f(4) : t = !0
                });
                return
            }
            f(h)
        }
    };

    function ii(a, b, c) {
        if (a)
            for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
    }

    function ji(a, b) {
        ii(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function ki(a, b) {
        if (a.tagName == "IFRAME") b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function li(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function mi(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if (typeof d === "object" && d && d.type === "creativeLoad") {
            var e = li(a);
            if (c.source && e) {
                var f;
                ji(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (h) {}
                });
                f && ki(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function ni(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }
    var oi = function(a, b) {
        var c = ni(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (h) {}
                        d = {
                            push: function(h) {
                                h(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Ha.addEventListener("message", function(f) {
                    mi(c, e, f)
                })
            }
    };
    var pi = function(a, b) {
            var c = this;
            this.global = a;
            this.Fd = b;
            this.Ii = this.document ? Pd(Zc(!0), Id(this.document, "visibilitychange")).g(qg(this.Fd.J, 748), N(function() {
                return c.document ? c.document.visibilityState : "visible"
            }), P()) : Zc("visible");
            this.Fi = this.document ? Id(this.document, "DOMContentLoaded").g(qg(this.Fd.J, 739), Re(1)) : Zc(Yh("DOMContentLoaded"))
        },
        qi = function(a) {
            return a.document ? a.document.readyState : "complete"
        },
        ri = function(a) {
            return a.document !== null && a.document.visibilityState !== void 0
        };
    pi.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    pi.prototype.querySelectorAll = function(a) {
        return this.document ? Jb(this.document.querySelectorAll(a)) : []
    };
    pi.prototype.elementFromPoint = function(a, b) {
        if (!this.document || this.document === null || typeof this.document.elementFromPoint !== "function") return null;
        a = this.document.elementFromPoint(a, b);
        return a === null ? null : new Zh(a)
    };
    var si = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            if (b.l === void 0 || !a.document) return Zc(b).g(qg(a.Fd.J, 749));
            var d = new bd(1),
                e = function() {
                    d.next(b)
                };
            c || oi(b.l, e);
            hi(b.l, e);
            return d.g(qg(a.Fd.J, 749), Re(1))
        },
        ti = function(a, b) {
            a = a.document;
            if (!a) return Zc(!1);
            var c = Pd(Zc(null), Id(a, "DOMContentLoaded", {
                    once: !0
                }), Id(a, "load", {
                    once: !0
                })),
                d = new Zh({
                    document: a,
                    element: b
                });
            return c.g(N(function() {
                if (!d.l) return !1;
                var e = d.l,
                    f = e.document;
                e = e.element;
                var g, h, k = (h = (g = f.body) != null ? g : f.children[0]) != null ? h : f;
                try {
                    k.appendChild(e),
                        d.release()
                } catch (l) {}
                return !d.l
            }), O(function(e) {
                return e
            }), Re(1), Oe(!1), jf({
                complete: function() {
                    return void d.release()
                }
            }))
        },
        ui = function(a, b, c) {
            var d, e, f;
            return Ca(function(g) {
                if (g.u == 1) {
                    d = a.global.document.createElement("iframe");
                    e = new Promise(function(k) {
                        d.onload = k;
                        d.onerror = k
                    });
                    if (b instanceof bb) var h = b.Cg;
                    else throw Error("Unexpected type when unwrapping TrustedResourceUrl");
                    d.src = h.toString();
                    return g.A(gd(ti(a, d)), 2)
                }
                if (g.u != 3) {
                    if (!g.V) return g.return();
                    d.style.display = "none";
                    return g.A(e,
                        3)
                }
                f = d.contentWindow;
                if (!f) return g.return();
                f.postMessage(c, "*");
                return g.return(d)
            })
        };
    da.Object.defineProperties(pi.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Ig(this.global, "document") ? this.global.document || null : null
            }
        }
    });
    var vi = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function wi(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function xi(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function yi(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };

    function zi(a, b) {
        var c = Zg() || Yg();
        try {
            if (a) {
                if (!b.top) return new Ch(-12245933, -12245933, -12245933, -12245933);
                b = b.top
            }
            a: {
                var d = b;
                if (a && d !== null && d != d.top) {
                    if (!d.top) {
                        var e = new vh(-12245933, -12245933);
                        break a
                    }
                    d = d.top
                }
                try {
                    if (c === void 0 ? 0 : c) var f = (new vh(d.innerWidth, d.innerHeight)).round();
                    else {
                        var g = (d || window).document,
                            h = g.compatMode == "CSS1Compat" ? g.documentElement : g.body;
                        f = (new vh(h.clientWidth, h.clientHeight)).round()
                    }
                    e = f
                } catch (w) {
                    e = new vh(-12245933, -12245933)
                }
            }
            a = e;
            var k = a.height,
                l = a.width;
            if (l ===
                -12245933) return new Ch(l, l, l, l);
            var m = yh(b.document);
            var u = zh(m.xc);
            var t = u.x,
                r = u.y;
            return new Ch(r, t + l, r + k, t)
        } catch (w) {
            return new Ch(-12245933, -12245933, -12245933, -12245933)
        }
    };

    function Ai(a, b) {
        if (a) throw Error("T");
        b.push(65533)
    }

    function Bi(a, b) {
        b = String.fromCharCode.apply(null, b);
        return a == null ? b : a + b
    }
    var Ci = void 0,
        Di, Ei, Fi = typeof TextDecoder !== "undefined",
        Gi, Hi = typeof String.prototype.isWellFormed === "function",
        Ii = typeof TextEncoder !== "undefined";
    var Ji = typeof Uint8Array !== "undefined",
        Ki = !ch && typeof btoa === "function",
        Li = /[-_.]/g,
        Mi = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Ni(a) {
        return Mi[a] || ""
    }

    function Pi(a) {
        if (!Ki) return Uh(a);
        var b = Li.test(a) ? a.replace(Li, Ni) : a;
        try {
            var c = atob(b)
        } catch (d) {
            throw Error("V`" + a + "`" + d);
        }
        a = new Uint8Array(c.length);
        for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
        return a
    }
    var Qi = {};
    var Si = function(a, b) {
        if (b !== Qi) throw Error("X");
        this.Yc = a;
        if (a != null && a.length === 0) throw Error("W");
        this.dontPassByteStringToStructuredClone = Ri
    };
    Si.prototype.isEmpty = function() {
        return this.Yc == null
    };
    var Ti;

    function Ri() {};

    function Ui(a) {
        Eb(a, Si);
        if (Qi !== Qi) throw Error("X");
        var b = a.Yc;
        b == null || Ji && b != null && b instanceof Uint8Array || (typeof b === "string" ? b = Pi(b) : (xb("Cannot coerce to Uint8Array: " + Ja(b)), b = null));
        return (b == null ? b : a.Yc = b) || new Uint8Array(0)
    };
    var Vi = function(a, b, c) {
        this.buffer = a;
        if (c && !b) throw Error("fa");
        this.qg = b
    };

    function Wi(a, b) {
        if (typeof a === "string") return new Vi(Pi(a), b);
        if (Array.isArray(a)) return new Vi(new Uint8Array(a), b);
        if (a.constructor === Uint8Array) return new Vi(a, !1);
        if (a.constructor === ArrayBuffer) return a = new Uint8Array(a), new Vi(a, !1);
        if (a.constructor === Si) return b = Ui(a), new Vi(b, !0, a);
        if (a instanceof Uint8Array) return a = a.constructor === Uint8Array ? a : new Uint8Array(a.buffer, a.byteOffset, a.byteLength), new Vi(a, !1);
        throw Error("ga");
    };

    function Xi() {
        return typeof BigInt === "function"
    };
    var Yi = typeof Ha.BigInt === "function" && typeof Ha.BigInt(0) === "bigint";

    function Zi(a) {
        var b = a;
        if (ph(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error("ha`" + b);
        } else if (oh(b) && !Number.isSafeInteger(b)) throw Error("ia`" + b);
        if (Yi) {
            rh(a) || (hh(a, th(ph, qh, oh)), a = BigInt(a));
            b = a % BigInt(2);
            var c = BigInt,
                d = typeof Window === "function" && globalThis.top instanceof Window ? globalThis.top : globalThis;
            d.gbigintUseStrInDebugToggleVal == null && Object.defineProperties(d, {
                gbigintUseStrInDebugToggleVal: {
                    value: Math.round(Math.random())
                }
            });
            return b === c(d.gbigintUseStrInDebugToggleVal) ? a.toString() :
                a
        }
        return a = qh(a) ? a ? "1" : "0" : ph(a) ? a.trim() || "0" : String(a)
    }
    var ej = lh(function(a) {
            if (Yi) return hh($i, rh), hh(aj, rh), a = BigInt(a), a >= $i && a <= aj;
            hh(a, ph);
            return a[0] === "-" ? bj(a, cj) : bj(a, dj)
        }, "isSafeInt52"),
        cj = Number.MIN_SAFE_INTEGER.toString(),
        $i = Yi ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        dj = Number.MAX_SAFE_INTEGER.toString(),
        aj = Yi ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function bj(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
        c = ih;
        kh("Assertion fail:", "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." || c)
    };
    var fj = typeof Uint8Array.prototype.slice === "function",
        gj = 0,
        hj = 0,
        ij;

    function jj(a) {
        var b = a >>> 0;
        gj = b;
        hj = (a - b) / 4294967296 >>> 0
    }

    function kj(a) {
        if (a < 0) {
            jj(0 - a);
            var b = x(lj(gj, hj));
            a = b.next().value;
            b = b.next().value;
            gj = a >>> 0;
            hj = b >>> 0
        } else jj(a)
    }

    function mj(a) {
        F(a <= 8);
        return ij || (ij = new DataView(new ArrayBuffer(8)))
    }

    function nj(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : oj(a, b)
    }

    function pj(a, b) {
        return Zi(Xi() ? BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0)) : oj(a, b))
    }

    function qj(a, b) {
        var c = b & 2147483648;
        c && (a = ~a + 1 >>> 0, b = ~b >>> 0, a == 0 && (b = b + 1 >>> 0));
        a = nj(a, b);
        return typeof a === "number" ? c ? -a : a : c ? "-" + a : a
    }

    function rj(a, b) {
        return Xi() ? Zi(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) + BigInt.asUintN(32, BigInt(a)))) : Zi(sj(a, b))
    }

    function oj(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else Xi() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), F(b), c = b + tj(c) + tj(a));
        return c
    }

    function tj(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function sj(a, b) {
        b & 2147483648 ? Xi() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = x(lj(a, b)), a = b.next().value, b = b.next().value, a = "-" + oj(a, b)) : a = oj(a, b);
        return a
    }

    function uj(a) {
        F(a.length > 0);
        if (a.length < 16) kj(Number(a));
        else if (Xi()) a = BigInt(a), gj = Number(a & BigInt(4294967295)) >>> 0, hj = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            F(a.length > 0);
            var b = +(a[0] === "-");
            hj = gj = 0;
            for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), hj *= 1E6, gj = gj * 1E6 + d, gj >= 4294967296 && (hj += Math.trunc(gj / 4294967296), hj >>>= 0, gj >>>= 0);
            b && (b = x(lj(gj, hj)), a = b.next().value, b = b.next().value, gj = a, hj = b)
        }
    }

    function lj(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    var vj = function(a, b, c, d) {
        this.I = this.za = null;
        this.ce = !1;
        this.S = this.Ia = this.Na = 0;
        this.init(a, b, c, d)
    };
    n = vj.prototype;
    n.init = function(a, b, c, d) {
        var e = d === void 0 ? {} : d;
        d = e.fd === void 0 ? !1 : e.fd;
        e = e.Pd === void 0 ? !1 : e.Pd;
        this.fd = d;
        this.Pd = e;
        a && (this.I = a = Wi(a, this.Pd), this.za = a.buffer, this.ce = a.qg, this.Na = b || 0, this.Ia = c !== void 0 ? this.Na + c : this.za.length, this.S = this.Na)
    };
    n.te = function() {
        this.clear();
        wj.length < 100 && wj.push(this)
    };
    n.clear = function() {
        this.I = this.za = null;
        this.ce = !1;
        this.S = this.Ia = this.Na = 0;
        this.fd = !1
    };
    n.setEnd = function(a) {
        this.Ia = a
    };
    n.reset = function() {
        this.S = this.Na
    };
    n.da = function() {
        return this.S
    };
    n.advance = function(a) {
        xj(this, this.S + a)
    };
    var yj = function(a, b) {
            var c = 0,
                d = 0,
                e = 0,
                f = a.za,
                g = a.S;
            do {
                var h = f[g++];
                c |= (h & 127) << e;
                e += 7
            } while (e < 32 && h & 128);
            if (e > 32)
                for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7) h = f[g++], d |= (h & 127) << e;
            xj(a, g);
            if (!(h & 128)) return b(c >>> 0, d >>> 0);
            throw Error("ca");
        },
        xj = function(a, b) {
            a.S = b;
            if (b > a.Ia) throw Error("da`" + b + "`" + a.Ia);
        },
        zj = function(a) {
            var b = a.za,
                c = a.S,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 && b[c++] & 128 &&
                    b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error("ca");
            xj(a, c);
            return e
        },
        Aj = function(a) {
            return zj(a) >>> 0
        },
        Bj = function(a) {
            return yj(a, nj)
        },
        Cj = function(a) {
            return yj(a, pj)
        },
        Dj = function(a) {
            var b = a.za,
                c = a.S,
                d = b[c + 0],
                e = b[c + 1],
                f = b[c + 2];
            b = b[c + 3];
            a.advance(4);
            return (d << 0 | e << 8 | f << 16 | b << 24) >>> 0
        },
        Ej = function(a) {
            for (var b = 0, c = a.S, d = c + 10, e = a.za; c < d;) {
                var f = e[c++];
                b |= f;
                if ((f & 128) === 0) return xj(a, c), !!(b & 127)
            }
            throw Error("ca");
        },
        Fj = function(a) {
            return zj(a)
        },
        Gj = function(a, b) {
            if (b < 0) throw Error("ea`" + b);
            var c = a.S,
                d = c + b;
            if (d > a.Ia) throw Error("da`" + (a.Ia - c) + "`" + b);
            a.S = d;
            return c
        };
    vj.prototype.Dg = function(a, b) {
        var c = Gj(this, a),
            d = F(this.za);
        if (Fi) {
            var e;
            b ? (e = Di) || (e = Di = new TextDecoder("utf-8", {
                fatal: !0
            })) : (e = Ei) || (e = Ei = new TextDecoder("utf-8", {
                fatal: !1
            }));
            var f = c + a;
            d = c === 0 && f === d.length ? d : d.subarray(c, f);
            try {
                var g = e.decode(d)
            } catch (m) {
                if (b) {
                    if (Ci === void 0) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (u) {}
                        try {
                            e.decode(new Uint8Array([97])), Ci = !0
                        } catch (u) {
                            Ci = !1
                        }
                    }
                    b = !Ci
                }
                b && (Di = void 0);
                throw m;
            }
        } else {
            a = c + a;
            g = [];
            for (var h = null, k, l; c < a;) k = d[c++], k < 128 ? g.push(k) : k < 224 ? c >= a ? Ai(b, g) : (l =
                d[c++], k < 194 || (l & 192) !== 128 ? (c--, Ai(b, g)) : (k = (k & 31) << 6 | l & 63, F(k >= 128 && k <= 2047), g.push(k))) : k < 240 ? c >= a - 1 ? Ai(b, g) : (l = d[c++], (l & 192) !== 128 || k === 224 && l < 160 || k === 237 && l >= 160 || ((e = d[c++]) & 192) !== 128 ? (c--, Ai(b, g)) : (k = (k & 15) << 12 | (l & 63) << 6 | e & 63, F(k >= 2048 && k <= 65535), F(k < 55296 || k > 57343), g.push(k))) : k <= 244 ? c >= a - 2 ? Ai(b, g) : (l = d[c++], (l & 192) !== 128 || (k << 28) + (l - 144) >> 30 !== 0 || ((e = d[c++]) & 192) !== 128 || ((f = d[c++]) & 192) !== 128 ? (c--, Ai(b, g)) : (k = (k & 7) << 18 | (l & 63) << 12 | (e & 63) << 6 | f & 63, F(k >= 65536 && k <= 1114111), k -= 65536, g.push((k >>
                10 & 1023) + 55296, (k & 1023) + 56320))) : Ai(b, g), g.length >= 8192 && (h = Bi(h, g), g.length = 0);
            F(c === a, "expected " + c + " === " + a);
            g = Bi(h, g)
        }
        return g
    };
    vj.prototype.Ue = function(a) {
        if (a == 0) return Ti || (Ti = new Si(null, Qi));
        var b = Gj(this, a);
        if (this.fd && this.ce) b = this.za.subarray(b, b + a);
        else {
            var c = F(this.za);
            a = b + a;
            b = b === a ? new Uint8Array(0) : fj ? c.slice(b, a) : new Uint8Array(c.subarray(b, a))
        }
        Eb(b, Uint8Array);
        return b.length == 0 ? Ti || (Ti = new Si(null, Qi)) : new Si(b, Qi)
    };
    var wj = [];
    F(!0);
    var Ij = function(a, b, c, d) {
            if (wj.length) {
                var e = wj.pop();
                e.init(a, b, c, d);
                a = e
            } else a = new vj(a, b, c, d);
            this.o = a;
            this.lb = this.o.da();
            this.j = this.Ed = this.Wb = -1;
            Hj(this, d)
        },
        Hj = function(a, b) {
            b = b === void 0 ? {} : b;
            a.me = b.me === void 0 ? !1 : b.me
        },
        Kj = function(a, b, c, d) {
            if (Jj.length) {
                var e = Jj.pop();
                Hj(e, d);
                e.o.init(a, b, c, d);
                return e
            }
            return new Ij(a, b, c, d)
        };
    Ij.prototype.te = function() {
        this.o.clear();
        this.j = this.Wb = this.Ed = -1;
        Jj.length < 100 && Jj.push(this)
    };
    Ij.prototype.da = function() {
        return this.o.da()
    };
    Ij.prototype.reset = function() {
        this.o.reset();
        this.lb = this.o.da();
        this.j = this.Wb = this.Ed = -1
    };
    Ij.prototype.advance = function(a) {
        this.o.advance(a)
    };
    var Lj = function(a) {
            var b = a.o;
            if (b.S == b.Ia) return !1;
            a.Ed !== -1 && (b = a.o.da(), a.o.S = a.lb, Aj(a.o), a.j === 4 || a.j === 3 ? F(b === a.o.da(), "Expected to not advance the cursor.  Group tags do not have values.") : F(b > a.o.da(), "Expected to read the field, did you forget to call a read or skip method?"), a.o.S = b);
            a.lb = a.o.da();
            b = Aj(a.o);
            var c = b >>> 3,
                d = b & 7;
            if (!(d >= 0 && d <= 5)) throw Error("Z`" + d + "`" + a.lb);
            if (c < 1) throw Error("$`" + c + "`" + a.lb);
            a.Ed = b;
            a.Wb = c;
            a.j = d;
            return !0
        },
        Mj = function(a) {
            switch (a.j) {
                case 0:
                    a.j != 0 ? (xb("Invalid wire type for skipVarintField"),
                        Mj(a)) : Ej(a.o);
                    break;
                case 1:
                    F(a.j === 1);
                    a.o.advance(8);
                    break;
                case 2:
                    if (a.j != 2) xb("Invalid wire type for skipDelimitedField"), Mj(a);
                    else {
                        var b = Aj(a.o);
                        a.o.advance(b)
                    }
                    break;
                case 5:
                    F(a.j === 5);
                    a.o.advance(4);
                    break;
                case 3:
                    b = a.Wb;
                    do {
                        if (!Lj(a)) throw Error("aa");
                        if (a.j == 4) {
                            if (a.Wb != b) throw Error("ba");
                            break
                        }
                        Mj(a)
                    } while (1);
                    break;
                default:
                    throw Error("Z`" + a.j + "`" + a.lb);
            }
        },
        Nj = function(a, b, c) {
            F(a.j == 2);
            var d = a.o.Ia,
                e = Aj(a.o),
                f = a.o.da() + e,
                g = f - d;
            g <= 0 && (a.o.setEnd(f), c(b, a, void 0, void 0, void 0), g = f - a.o.da());
            if (g) throw Error("Y`" +
                e + "`" + (e - g));
            a.o.S = f;
            a.o.setEnd(d)
        },
        Oj = function(a) {
            F(a.j == 0);
            return zj(a.o)
        },
        Pj = function(a) {
            F(a.j == 0);
            return Aj(a.o)
        },
        Qj = function(a) {
            F(a.j == 0);
            return Bj(a.o)
        },
        Rj = function(a) {
            F(a.j == 0);
            return Cj(a.o)
        },
        Sj = function(a) {
            F(a.j == 0);
            return zj(a.o)
        };
    Ij.prototype.Dg = function() {
        return Tj(this)
    };
    var Tj = function(a) {
        F(a.j == 2);
        var b = Aj(a.o);
        return a.o.Dg(b, !0)
    };
    Ij.prototype.Ue = function() {
        F(this.j == 2);
        var a = Aj(this.o);
        return this.o.Ue(a)
    };
    var Uj = function(a, b, c) {
            F(a.j == 2);
            var d = Aj(a.o);
            for (d = a.o.da() + d; a.o.da() < d;) c.push(b(a.o))
        },
        Jj = [];
    var Vj = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function Wj(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Xj = Wj("jas", void 0, !0),
        Yj = Wj("defaultInstance", "0di"),
        Zj = Wj("unknownBinaryFields", Symbol()),
        ak = Wj("unknownBinaryThrottleKey", "0ub"),
        bk = Wj("unknownBinaryThrottleKey", "0ubs"),
        ck = Wj("unknownBinarySerializeBinaryThrottleKey", "0ubsb"),
        dk = Wj("m_m", "gk", !0),
        ek = Wj("validPivotSelector", "vps"),
        fk = Wj("lazilyParseLateLoadedExtensions");
    F(Math.round(Math.log2(Math.max.apply(Math, y(Object.values({
        Mj: 1,
        Lj: 2,
        Kj: 4,
        Rj: 8,
        Uj: 16,
        Pj: 32,
        yj: 64,
        Ij: 128,
        Cj: 256,
        Tj: 512,
        Dj: 1024,
        Jj: 2048,
        Qj: 4096,
        Oj: 8192
    }))))) === 13);
    var gk = {
            ai: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        hk = Object.defineProperties,
        X = Vj ? G(Xj) : "ai",
        ik, jk = [];
    kk(jk, 7);
    ik = Object.freeze(jk);

    function lk(a) {
        return I(a, "state is only maintained on arrays.")[X] | 0
    }

    function mk(a, b) {
        F((b & 16777215) === b);
        I(a, "state is only maintained on arrays.");
        Vj || X in a || hk(a, gk);
        a[X] |= b
    }

    function kk(a, b) {
        F((b & 16777215) === b);
        I(a, "state is only maintained on arrays.");
        Vj || X in a || hk(a, gk);
        a[X] = b
    }

    function Y(a, b, c) {
        (c === void 0 || !c || b & 2048) && F(b & 64, "state for messages must be constructed");
        F((b & 5) === 0, "state for messages should not contain repeated field state");
        F((b & 8192) === 0, "state for messages should not contain map field state");
        if (b & 64) {
            F(b & 64);
            c = b >> 14 & 1023 || 536870912;
            var d = a.length;
            F(b & 64);
            F(c + (b & 128 ? 0 : -1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
            b & 128 && F(typeof a[0] === "string", "arrays with a message_id bit must have a string in the first position, got: %s",
                a[0])
        }
    }

    function nk(a) {
        var b = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        return b
    }

    function ok(a) {
        var b = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        return b
    }

    function pk(a) {
        return !!((I(a, "state is only maintained on arrays.")[X] | 0) & 2)
    }

    function qk(a, b) {
        zb(b);
        F(b > 0 && b <= 1023 || 536870912 === b, "pivot must be in the range [1, 1024) or NO_PIVOT got %s", b);
        return a & -16760833 | (b & 1023) << 14
    }

    function rk(a) {
        F(a & 64);
        return a & 128 ? 0 : -1
    }
    var sk = Object.getOwnPropertyDescriptor(Array.prototype, "ji");
    Object.defineProperties(Array.prototype, {
        ji: {
            get: function() {
                var a = tk(this);
                return sk ? sk.get.call(this) + "|" + a : a
            },
            configurable: !0,
            enumerable: !1
        }
    });

    function tk(a) {
        function b(e, f) {
            e & c && d.push(f)
        }
        var c = I(a, "state is only maintained on arrays.")[X] | 0,
            d = [];
        b(1, "IS_REPEATED_FIELD");
        b(2, "IS_IMMUTABLE_ARRAY");
        b(4, "IS_API_FORMATTED");
        b(512, "STRING_FORMATTED");
        b(1024, "GBIGINT_FORMATTED");
        b(1024, "BINARY");
        b(8, "ONLY_MUTABLE_VALUES");
        b(16, "UNFROZEN_SHARED");
        b(32, "MUTABLE_REFERENCES_ARE_OWNED");
        b(64, "CONSTRUCTED");
        b(128, "HAS_MESSAGE_ID");
        b(256, "FROZEN_ARRAY");
        b(2048, "HAS_WRAPPER");
        b(4096, "MUTABLE_SUBSTRUCTURES");
        b(8192, "KNOWN_MAP_ARRAY");
        c & 64 && (F(c & 64), a =
            c >> 14 & 1023 || 536870912, a !== 536870912 && d.push("pivot: " + a));
        return d.join(",")
    };
    var uk = Vj && Math.random() < .5,
        vk = uk ? Symbol() : void 0;

    function wk(a) {
        F(Z(a));
        return uk ? a[G(vk)] : a.C
    }
    var xk, yk = typeof dk === "symbol",
        zk = {};

    function Z(a) {
        var b = a[dk],
            c = b === zk;
        F(!xk || c === a instanceof xk);
        if (yk && b && !c) throw Error("ja");
        return c
    }

    function Ak(a) {
        return a != null && Z(a)
    }

    function Bk(a, b) {
        zb(a);
        F(a > 0);
        F(b === 0 || b === -1);
        return a + b
    }

    function Ck(a, b) {
        F(b === Dk || b === void 0);
        return a + (b ? 0 : -1)
    }

    function Ek(a, b) {
        zb(a);
        F(a >= 0);
        F(b === 0 || b === -1);
        return a - b
    }

    function Fk(a, b) {
        if (b === void 0) {
            if (b = !Gk(a)) F(Z(a)), a = uk ? a[G(vk)] : a.C, b = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, b), b = !!(2 & b);
            return b
        }
        F(Z(a));
        var c = uk ? a[G(vk)] : a.C;
        var d = I(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        F(b === d);
        return !!(2 & b) && !Gk(a)
    }
    var Hk = {};

    function Gk(a) {
        var b = a.xh,
            c;
        (c = !b) || (F(Z(a)), a = uk ? a[G(vk)] : a.C, c = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, c), c = !!(2 & c));
        F(c);
        F(b === void 0 || b === Hk);
        return b === Hk
    }

    function Ik(a, b) {
        F(Z(a));
        var c = uk ? a[G(vk)] : a.C;
        var d = I(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        F(b === !!(2 & d));
        a.xh = b ? Hk : void 0
    }
    var Jk = Symbol("exempted jspb subclass"),
        Kk = typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";

    function Lk() {}

    function Mk(a, b) {
        var c = lk(I(a));
        b || F(!(c & 2 && c & 4 || c & 256) || Object.isFrozen(a));
        Nk(a)
    }

    function Nk(a) {
        a = I(a, "state is only maintained on arrays.")[X] | 0;
        var b = a & 4,
            c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
        F(b && c <= 1 || !b && c === 0, "Expected at most 1 type-specific formatting bit, but got " + c + " with state: " + a)
    }
    var Ok = Object.freeze({}),
        Pk = Symbol("debugExtensions");

    function Qk(a, b, c) {
        F(b & 64);
        F(b & 64);
        var d = b & 128 ? 0 : -1;
        var e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        var g = e + (f ? -1 : 0),
            h = a[e - 1];
        F(!!f === (h != null && typeof h === "object" && h.constructor === Object));
        for (b = b & 128 ? 1 : 0; b < g; b++) h = a[b], c(Ek(b, d), h);
        if (f) {
            a = a[e - 1];
            for (var k in a) !isNaN(k) && c(+k, a[k])
        }
    }
    var Dk = {};

    function Rk(a, b) {
        a = I(a, "state is only maintained on arrays.")[X] | 0;
        F(a & 64);
        a & 128 ? F(b === Dk) : F(b === void 0)
    }

    function Sk(a) {
        F(a & 64);
        return a & 128 ? Dk : void 0
    };
    var Tk = {};

    function Uk(a) {
        a = Error(a);
        Nb(a, "warning");
        return a
    }

    function Vk(a, b, c) {
        if (a != null) {
            var d;
            var e = (d = Tk) != null ? d : Tk = {};
            d = e[a] || 0;
            d >= b || (e[a] = d + 1, a = Error(c), Nb(a, "incident"), Oh(a))
        }
    };

    function Wk(a) {
        return Array.prototype.slice.call(a)
    };
    var Xk = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Yk = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        Zk = Number.isSafeInteger,
        $k = Number.isFinite,
        al = Math.trunc,
        bl = Number.MAX_SAFE_INTEGER;

    function cl(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function dl(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function el(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    var fl = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function gl(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return $k(a);
            case "string":
                return fl.test(a);
            default:
                return !1
        }
    }

    function hl(a) {
        if (!$k(a)) throw a = "Expected enum as finite number but got " + Ja(a) + ": " + a, Uk(a);
        return a | 0
    }

    function il(a) {
        return a == null ? a : $k(a) ? a | 0 : void 0
    }

    function jl(a) {
        return "Expected int32 as finite number but got " + Ja(a) + ": " + a
    }

    function kl(a) {
        if (typeof a !== "number") throw Uk(jl(a));
        if (!$k(a)) throw Uk(jl(a));
        return a | 0
    }

    function ll(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return $k(a) ? a | 0 : void 0
    }

    function ml(a) {
        return "Expected uint32 as finite number but got " + Ja(a) + ": " + a
    }

    function nl(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return $k(a) ? a >>> 0 : void 0
    }

    function ol(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Xk(64, a));
        if (gl(a)) {
            if (b === "string") return F(gl(a)), F(!0), b = al(Number(a)), Zk(b) ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), F(a.indexOf(".") === -1), b = a.length, (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") || (uj(a), a = sj(gj, hj))), a;
            if (b === "number") return F(gl(a)), F(!0), a = al(a), Zk(a) || (F(!Zk(a)), F(Number.isInteger(a)), kj(a), a = qj(gj, hj)), a
        }
    }

    function pl(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Yk(64, a));
        if (gl(a)) {
            if (b === "string") return F(gl(a)), F(!0), b = al(Number(a)), Zk(b) && b >= 0 ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), F(a.indexOf(".") === -1), a[0] === "-" ? b = !1 : (b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615"), b || (uj(a), a = oj(gj, hj))), a;
            if (b === "number") return F(gl(a)), F(!0), a = al(a), a >= 0 && Zk(a) || (F(a < 0 || a > bl), F(Number.isInteger(a)), kj(a), a = nj(gj, hj)), a
        }
    }

    function ql(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function rl(a, b) {
        if (!(a instanceof b)) throw Error("oa`" + dl(b) + "`" + (a && dl(a.constructor)));
    }

    function sl(a, b, c) {
        if (Ak(a)) return a;
        if (Array.isArray(a)) {
            var d = lk(a);
            c = d | c & 32 | c & 2;
            c !== d && kk(a, c);
            return new b(a)
        }
    };
    var tl = function(a, b) {
            this.Ec = a >>> 0;
            this.Ac = b >>> 0
        },
        vl = function(a) {
            if (!a) return ul || (ul = new tl(0, 0));
            if (!/^\d+$/.test(a)) return null;
            uj(a);
            return new tl(gj, hj)
        },
        ul, wl = function(a, b) {
            this.Ec = a >>> 0;
            this.Ac = b >>> 0
        },
        yl = function(a) {
            if (!a) return xl || (xl = new wl(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            uj(a);
            return new wl(gj, hj)
        },
        xl;
    var zl = function() {
        this.I = []
    };
    zl.prototype.length = function() {
        return this.I.length
    };
    zl.prototype.end = function() {
        var a = this.I;
        this.I = [];
        return a
    };
    zl.prototype.ab = function(a, b) {
        F(a == Math.floor(a));
        F(b == Math.floor(b));
        F(a >= 0 && a < 4294967296);
        for (F(b >= 0 && b < 4294967296); b > 0 || a > 127;) this.I.push(a & 127 | 128), a = (a >>> 7 | b << 25) >>> 0, b >>>= 7;
        this.I.push(a)
    };
    zl.prototype.vf = function(a, b) {
        F(a == Math.floor(a));
        F(b == Math.floor(b));
        F(a >= 0 && a < 4294967296);
        F(b >= 0 && b < 4294967296);
        this.Ea(a);
        this.Ea(b)
    };
    var Al = function(a, b) {
            F(b == Math.floor(b));
            for (F(b >= 0 && b < 4294967296); b > 127;) a.I.push(b & 127 | 128), b >>>= 7;
            a.I.push(b)
        },
        Bl = function(a, b) {
            F(b == Math.floor(b));
            F(b >= -2147483648 && b < 2147483648);
            if (b >= 0) Al(a, b);
            else {
                for (var c = 0; c < 9; c++) a.I.push(b & 127 | 128), b >>= 7;
                a.I.push(1)
            }
        };
    n = zl.prototype;
    n.Ea = function(a) {
        F(a == Math.floor(a));
        F(a >= 0 && a < 4294967296);
        this.I.push(a >>> 0 & 255);
        this.I.push(a >>> 8 & 255);
        this.I.push(a >>> 16 & 255);
        this.I.push(a >>> 24 & 255)
    };
    n.bh = function(a) {
        F(a == Math.floor(a));
        F(a >= 0 && a < 1.8446744073709552E19);
        jj(a);
        this.Ea(gj);
        this.Ea(hj)
    };
    n.Zg = function(a) {
        F(a == Math.floor(a));
        F(a >= -2147483648 && a < 2147483648);
        this.I.push(a >>> 0 & 255);
        this.I.push(a >>> 8 & 255);
        this.I.push(a >>> 16 & 255);
        this.I.push(a >>> 24 & 255)
    };
    n.ah = function(a) {
        F(a == Math.floor(a));
        F(a >= -0x7fffffffffffffff && a < 0x7fffffffffffffff);
        kj(a);
        this.vf(gj, hj)
    };
    n.uf = function(a) {
        F(a == Infinity || a == -Infinity || isNaN(a) || typeof a === "number" && a >= -3.4028234663852886E38 && a <= 3.4028234663852886E38);
        var b = mj(4);
        b.setFloat32(0, +a, !0);
        hj = 0;
        gj = b.getUint32(0, !0);
        this.Ea(gj)
    };
    n.tf = function(a) {
        F(typeof a === "number" || a === "Infinity" || a === "-Infinity" || a === "NaN");
        var b = mj(8);
        b.setFloat64(0, +a, !0);
        gj = b.getUint32(0, !0);
        hj = b.getUint32(4, !0);
        this.Ea(gj);
        this.Ea(hj)
    };
    n.sf = function(a) {
        F(typeof a === "boolean" || typeof a === "number");
        this.I.push(a ? 1 : 0)
    };
    n.Td = function(a) {
        F(a == Math.floor(a));
        F(a >= -2147483648 && a < 2147483648);
        Bl(this, a)
    };
    var Cl = function() {
            this.be = [];
            this.Fb = 0;
            this.G = new zl
        },
        Dl = function(a, b) {
            b.length !== 0 && (a.be.push(b), a.Fb += b.length)
        },
        Fl = function(a, b) {
            El(a, b, 2);
            b = a.G.end();
            Dl(a, b);
            b.push(a.Fb);
            return b
        },
        Gl = function(a, b) {
            var c = b.pop();
            c = a.Fb + a.G.length() - c;
            for (F(c >= 0); c > 127;) b.push(c & 127 | 128), c >>>= 7, a.Fb++;
            b.push(c);
            a.Fb++
        },
        El = function(a, b, c) {
            F(b >= 1 && b == Math.floor(b));
            Al(a.G, b * 8 + c)
        },
        Hl = function(a, b, c) {
            if (c != null) switch (El(a, b, 0), typeof c) {
                case "number":
                    a = a.G;
                    F(c == Math.floor(c));
                    F(c >= 0 && c < 1.8446744073709552E19);
                    kj(c);
                    a.ab(gj, hj);
                    break;
                case "bigint":
                    c = BigInt.asUintN(64, c);
                    c = new tl(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                    a.G.ab(c.Ec, c.Ac);
                    break;
                default:
                    c = vl(c), a.G.ab(c.Ec, c.Ac)
            }
        };
    n = Cl.prototype;
    n.Zg = function(a, b) {
        b != null && (Il(a, b, b >= -2147483648 && b < 2147483648), b != null && (Jl(a, b), El(this, a, 0), Bl(this.G, b)))
    };
    n.ah = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Il(a, b, yl(b));
                    break;
                case "number":
                    Il(a, b, b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    break;
                default:
                    Il(a, b, b >= BigInt(-0x7fffffffffffffff) && b < BigInt(0x7fffffffffffffff))
            }
            if (b != null) switch (El(this, a, 0), typeof b) {
                case "number":
                    a = this.G;
                    F(b == Math.floor(b));
                    F(b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    kj(b);
                    a.ab(gj, hj);
                    break;
                case "bigint":
                    b = BigInt.asUintN(64, b);
                    b = new wl(Number(b & BigInt(4294967295)), Number(b >> BigInt(32)));
                    this.G.ab(b.Ec,
                        b.Ac);
                    break;
                default:
                    b = yl(b), this.G.ab(b.Ec, b.Ac)
            }
        }
    };
    n.Ea = function(a, b) {
        b != null && (Il(a, b, b >= 0 && b < 4294967296), b != null && (El(this, a, 0), Al(this.G, b)))
    };
    n.bh = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Il(a, b, vl(b));
                    break;
                case "number":
                    Il(a, b, b >= 0 && b < 1.8446744073709552E19);
                    break;
                default:
                    Il(a, b, b >= BigInt(0) && b < BigInt(1.8446744073709552E19))
            }
            Hl(this, a, b)
        }
    };
    n.uf = function(a, b) {
        b != null && (El(this, a, 5), this.G.uf(b))
    };
    n.tf = function(a, b) {
        b != null && (El(this, a, 1), this.G.tf(b))
    };
    n.sf = function(a, b) {
        b != null && (Il(a, b, typeof b === "boolean" || typeof b === "number"), El(this, a, 0), this.G.sf(b))
    };
    n.Td = function(a, b) {
        b != null && (b = parseInt(b, 10), Jl(a, b), El(this, a, 0), Bl(this.G, b))
    };
    n.vf = function(a, b) {
        El(this, a, 1);
        this.G.vf(b)
    };
    n.ab = function(a, b) {
        El(this, a, 0);
        this.G.ab(b)
    };

    function Jl(a, b) {
        Il(a, b, b === Math.floor(b));
        Il(a, b, b >= -2147483648 && b < 2147483648)
    }

    function Il(a, b, c) {
        c || xb("for [" + b + "] at [" + a + "]")
    };

    function Kl() {
        var a = function() {
            throw Error("pa");
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var Ll = Kl(),
        Ml = Kl(),
        Nl = Kl(),
        Ol = Kl(),
        Pl = Kl(),
        Ql = Kl(),
        Rl = Kl(),
        Sl = Kl(),
        Tl = Kl(),
        Ul = Kl(),
        Vl = Kl(),
        Wl = Kl();

    function Xl(a) {
        return a
    }
    Xl[ek] = {};

    function Yl(a) {
        return a
    };
    var Zl = function() {
        throw Error("qa");
    };
    if (Kk) {
        var $l = function() {
                throw Error("ra");
            },
            am = {};
        Object.defineProperties(Zl, (am[Symbol.hasInstance] = {
            value: $l,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, am));
        F(Zl[Symbol.hasInstance] === $l, "defineProperties did not work: was it monkey-patched?")
    };

    function bm(a) {
        var b = Ma(Zj);
        return b ? I(a)[b] : void 0
    }
    var cm = function() {},
        dm = function(a, b) {
            for (var c in a) !isNaN(c) && b(a, +c, I(a[c]))
        },
        em = function(a) {
            var b = new cm;
            dm(a, function(c, d, e) {
                b[d] = Wk(e)
            });
            b.Ze = a.Ze;
            return b
        },
        fm = {
            Yi: !0
        };

    function gm(a, b, c) {
        var d = d === void 0 ? !1 : d;
        if (Ma(fk) && Ma(Zj) && c === fk) {
            F(Z(a));
            c = uk ? a[G(vk)] : a.C;
            var e = c[Zj];
            if (!e) return;
            if (e = e.Ze) try {
                e(c, b, fm);
                return
            } catch (f) {
                throw Error("sa`" + b);
            }
        }
        d && (F(Z(a)), a = wk(a), I(a), (d = Ma(Zj)) && d in a && (a = a[d]) && delete a[b])
    }

    function hm(a, b) {
        F(Z(a));
        F(Z(a));
        a = uk ? a[G(vk)] : a.C;
        I(a);
        var c = Ma(Zj),
            d;
        Vj && c && ((d = a[c]) == null ? void 0 : d[b]) != null && Vk(ak, 3, "0ub:" + b)
    }

    function im(a, b) {
        b < 100 || Vk(bk, 1, "0ubs:" + b)
    };

    function jm(a, b, c, d, e) {
        var f = d !== void 0;
        d = !!d;
        var g = Ma(Zj),
            h;
        !f && Vj && g && (h = a[g]) && dm(h, im);
        g = [];
        var k = a.length;
        h = 4294967295;
        var l = !1,
            m = !!(b & 64);
        if (m) {
            F(b & 64);
            var u = b & 128 ? 0 : -1
        } else u = void 0;
        if (!(b & 1)) {
            var t = k && a[k - 1];
            t != null && typeof t === "object" && t.constructor === Object ? (k--, h = k) : t = void 0;
            if (m && !(b & 128) && !f) {
                l = !0;
                var r;
                b = (r = km) != null ? r : Xl;
                h = Bk(b(Ek(h, G(u)), G(u), a, t, e), G(u))
            }
        }
        e = void 0;
        for (r = 0; r < k; r++)
            if (b = a[r], b != null && (b = c(b, d)) != null)
                if (m && r >= h) {
                    lm();
                    var w = Ek(r, G(u)),
                        v = void 0;
                    ((v = e) != null ? v : e = {})[w] =
                    b
                } else g[r] = b;
        if (t)
            for (var z in t) k = t[z], k != null && (k = c(k, d)) != null && (r = +z, b = void 0, m && !Number.isNaN(r) && (b = Bk(r, G(u))) < h ? (lm(), g[G(b)] = k) : (r = void 0, ((r = e) != null ? r : e = {})[z] = k));
        e && (l ? g.push(e) : (F(h < 4294967295), g[h] = e));
        f && Ma(Zj) && (I(g), I(a), F(g[Zj] === void 0), (a = bm(a)) && a instanceof cm && (g[Zj] = em(a)));
        return g
    }

    function mm(a) {
        G(a);
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return ej(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    Mk(a);
                    var b = I(a, "state is only maintained on arrays.")[X] | 0;
                    return a.length === 0 && b & 1 ? void 0 : jm(a, b, mm)
                }
                if (Ak(a)) return nm(a);
                if (a instanceof Si) {
                    b = a.Yc;
                    if (b == null) a = "";
                    else if (typeof b === "string") a = b;
                    else {
                        if (Ki) {
                            for (var c = "", d = 0, e = b.length - 10240; d < e;) c += String.fromCharCode.apply(null, b.subarray(d, d += 10240));
                            c +=
                                String.fromCharCode.apply(null, d ? b.subarray(d) : b);
                            b = btoa(c)
                        } else b = Sh(b);
                        a = a.Yc = b
                    }
                    return a
                }
                F(!(a instanceof Uint8Array));
                return
        }
        return a
    }
    var km;

    function om(a) {
        F(!km);
        return nm(a)
    }

    function nm(a) {
        F(Z(a));
        var b = uk ? a[G(vk)] : a.C;
        var c = I(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, c);
        return jm(b, c, mm, void 0, a.constructor)
    }

    function lm() {
        var a, b = (a = km) != null ? a : Xl;
        F(b !== Yl)
    };
    if (typeof Proxy !== "undefined") {
        var qm = pm;
        new Proxy({}, {
            getPrototypeOf: qm,
            setPrototypeOf: qm,
            isExtensible: qm,
            preventExtensions: qm,
            getOwnPropertyDescriptor: qm,
            defineProperty: qm,
            has: qm,
            get: qm,
            set: qm,
            deleteProperty: qm,
            apply: qm,
            construct: qm
        })
    }

    function pm() {
        throw Error("xa");
    };
    var rm, sm;

    function tm(a) {
        switch (typeof a) {
            case "boolean":
                return rm || (rm = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? sm || (sm = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return I(a), F(a.length === 2 || a.length === 3 && a[2] === !0), F(a[0] == null || typeof a[0] === "number" && a[0] >= 0), F(a[1] == null || typeof a[1] === "string"), a
        }
    }

    function um(a, b) {
        I(b);
        return vm(a, b[0], b[1])
    }

    function vm(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a != null)
            for (var e = 0; e < a.length; e++) {
                var f = a[e];
                Array.isArray(f) && Mk(f)
            }
        if (a == null) e = 32, c ? (a = [c], e |= 128) : a = [], b && (e = qk(e, b));
        else {
            if (!Array.isArray(a)) throw Error("ya`" + JSON.stringify(a) + "`" + Ja(a));
            e = I(a, "state is only maintained on arrays.")[X] | 0;
            if (Mg && 1 & e) throw Error("za");
            2048 & e && !(2 & e) && wm();
            if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a)) throw Error("Aa");
            if (e & 256) throw Error("Ba");
            if (e & 64) return (e | d) !== e && kk(a, e |= d), Y(a, e), a;
            if (c &&
                (e |= 128, c !== a[0])) throw Error("Ca`" + c + "`" + JSON.stringify(a[0]) + "`" + Ja(a[0]));
            a: {
                c = a;e |= 64;
                var g = c.length;
                if (g) {
                    var h = g - 1;
                    f = c[h];
                    if (f != null && typeof f === "object" && f.constructor === Object) {
                        b = rk(e);
                        g = Ek(h, b);
                        if (g >= 1024) throw Error("Ea`" + g);
                        for (var k in f) h = +k, h < g && (h = Bk(h, b), F(c[h] == null), c[h] = f[k], delete f[k]);
                        e = qk(e, g);
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, Ek(g, rk(e)));
                    if (k > 1024) throw Error("Fa`" + g);
                    e = qk(e, k)
                }
            }
        }
        kk(a, e | 64 | d);
        return a
    }

    function wm() {
        if (Mg) throw Error("Da");
    };

    function xm(a) {
        F(!(2 & a));
        F(!(2048 & a));
        return !(4096 & a) && !(16 & a)
    }

    function ym(a, b) {
        G(a);
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            Mk(a);
            var c = I(a, "state is only maintained on arrays.")[X] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (b && xm(c) ? (mk(a, 34), c & 4 && Object.freeze(a)) : a = zm(a, c, !1, b && !(c & 16)));
            return a
        }
        if (Ak(a)) return F(Ak(a)), b = wk(a), c = ok(b), Fk(a, c) ? a : Am(a, b, c) ? Bm(a, b) : zm(b, c);
        if (a instanceof Si) return a;
        F(!(a instanceof Uint8Array))
    }

    function Bm(a, b, c) {
        a = new a.constructor(b);
        c && Ik(a, !0);
        a.Ai = Hk;
        return a
    }

    function zm(a, b, c, d) {
        F(b === (I(a, "state is only maintained on arrays.")[X] | 0));
        d != null || (d = !!(34 & b));
        a = jm(a, b, ym, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        kk(a, b);
        return a
    }

    function Cm(a) {
        if (!Gk(a)) return !1;
        var b;
        F(Z(a));
        var c = b = uk ? a[G(vk)] : a.C,
            d = I(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        F(d & 2);
        b = zm(b, d);
        mk(b, 2048);
        F(Z(a));
        I(b);
        uk ? a[G(vk)] = b : a.C = b;
        Ik(a, !1);
        a.Ai = void 0;
        return !0
    }

    function Dm(a) {
        var b;
        if (b = !Cm(a)) {
            F(Z(a));
            b = uk ? a[G(vk)] : a.C;
            var c = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, c);
            b = Fk(a, c)
        }
        if (b) throw Error("ka");
    }

    function Em(a, b) {
        if (b === void 0) b = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, b, !0);
        else {
            var c = I(a, "state is only maintained on arrays.")[X] | 0;
            Y(a, c, !0);
            F(b === c)
        }
        F(!(b & 2));
        b & 32 && !(b & 4096) && kk(a, b | 4096)
    }

    function Am(a, b, c) {
        return Jk && a[Jk] ? !1 : c & 2 ? !0 : c & 32 && !(c & 4096) ? (kk(b, c | 2), Ik(a, !0), !0) : !1
    };
    var Gm = function(a, b) {
            F(Object.isExtensible(a));
            F(Z(a));
            a = uk ? a[G(vk)] : a.C;
            b = Fm(a, b);
            (a = b !== null) || (a = void 0);
            if (a) return b
        },
        Fm = function(a, b, c, d) {
            Rk(a, c);
            if (b === -1) return null;
            var e = Ck(b, c);
            F(e === Bk(b, rk(I(a, "state is only maintained on arrays.")[X] | 0)));
            F(e >= 0);
            var f = a.length - 1;
            if (!(f < Ck(1, c))) {
                if (e >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        c = g[b];
                        var h = !0
                    } else if (e === f) c = g;
                    else return
                } else c = a[e];
                if (d && c != null) {
                    d = d(c);
                    if (d == null) return d;
                    if (!Object.is(d, c)) return h ? g[b] =
                        d : a[e] = d, d
                }
                return c
            }
        },
        Im = function(a, b, c) {
            Dm(a);
            F(Z(a));
            var d = uk ? a[G(vk)] : a.C;
            var e = I(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, e);
            Hm(d, e, b, c);
            return a
        };

    function Hm(a, b, c, d, e) {
        Rk(a, e);
        var f = Ck(c, e);
        F(f === Bk(c, rk(I(a, "state is only maintained on arrays.")[X] | 0)));
        F(f >= 0);
        var g = a.length - 1;
        if (g >= Ck(1, e) && f >= g) {
            var h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && ((g = b) == null && (b = I(a, "state is only maintained on arrays.")[X] | 0, Y(a, b), g = b), F(g & 64), g = g >> 14 & 1023 || 536870912, c >= g ? (F(g !== 536870912), d != null && (f = {}, a[Ck(g, e)] = (f[c] = d, f))) : a[f] = d);
        return b
    }
    var Km = function(a, b, c, d) {
        F(Z(a));
        a = uk ? a[G(vk)] : a.C;
        var e = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, e);
        return Jm(a, e, b, c, d) !== void 0
    };

    function Lm(a, b) {
        if (!a) return a;
        F(pk(b) ? Fk(a) : !0);
        return a
    }

    function Mm(a, b, c) {
        c = c === void 0 ? !1 : c;
        Mk(a, c);
        var d = I(a, "state is only maintained on arrays.")[X] | 0;
        F(d & 1);
        c || (F(Object.isFrozen(a) || d & 16), F(pk(b) ? Object.isFrozen(a) : !0))
    }

    function Nm(a, b, c, d, e) {
        F(Z(a));
        var f = uk ? a[G(vk)] : a.C;
        var g = I(f, "state is only maintained on arrays.")[X] | 0;
        Y(f, g);
        d = Fk(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && Cm(a) && (F(Z(a)), f = uk ? a[G(vk)] : a.C, g = I(f, "state is only maintained on arrays.")[X] | 0, Y(f, g));
        a = Om(f, b);
        var h = a === ik ? 7 : I(a, "state is only maintained on arrays.")[X] | 0,
            k = Pm(h, g);
        Nk(a);
        var l = 4 & k ? !1 : !0;
        if (l) {
            4 & k && (a = Wk(a), h = 0, k = Qm(k, g), g = G(Hm(f, g, b, a)));
            for (var m = 0, u = 0; m < a.length; m++) {
                var t = c(a[m]);
                t != null && (a[u++] = t)
            }
            u < m && (a.length = u);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (kk(a, k), 2 & k && Object.freeze(a));
        a = Rm(a, k, f, g, b, d, l, e);
        Nk(a);
        e || Mm(a, f);
        return a
    }

    function Rm(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Sm(b) || (e = !a.length || g && !(4096 & b) || !!(32 & d) && xm(b), b |= e ? 2 : 256, b !== k && kk(a, b), Object.freeze(a)) : (f === 2 && Sm(b) && (a = Wk(a), k = 0, b = Qm(b, d), d = G(Hm(c, d, e, a))), Sm(b) || (h || (b |= 16), b !== k && kk(a, b)));
        2 & b || xm(b) || Em(c, d);
        return a
    }

    function Om(a, b, c) {
        a = Fm(a, b, c);
        return Array.isArray(a) ? a : ik
    }

    function Pm(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Sm(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Tm(a, b, c) {
        if (b & 2) throw Error("ka");
        var d = Sk(b),
            e = Om(a, c, d),
            f = e === ik ? 7 : I(e, "state is only maintained on arrays.")[X] | 0,
            g = Pm(f, b);
        if (2 & g || Sm(g) || 16 & g) g === f || Sm(g) || kk(e, g), e = Wk(e), f = 0, g = Qm(g, b), G(Hm(a, b, c, e, d));
        g &= -13;
        g !== f && kk(e, g);
        return e
    }
    var Um = function(a, b, c) {
        var d = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, d, !0);
        var e = Sk(d),
            f = Fm(a, c, e);
        if (Ak(f)) {
            if (!Fk(f)) return Cm(f), F(Z(f)), uk ? f[G(vk)] : f.C;
            F(Z(f));
            var g = uk ? f[G(vk)] : f.C;
            F((I(g, "state is only maintained on arrays.")[X] | 0) & 2)
        } else Array.isArray(f) && (g = f);
        if (g) {
            var h = I(g, "state is only maintained on arrays.")[X] | 0;
            h & 2 && (g = zm(g, h))
        }
        g = um(g, b);
        g !== f && Hm(a, d, c, g, e);
        return g
    };

    function Jm(a, b, c, d, e) {
        var f = !1;
        d = Fm(a, d, e, function(g) {
            var h = sl(g, c, b);
            f = h !== g && h != null;
            return h
        });
        if (d != null) return f && !Fk(d) && Em(a, b), Lm(d, a)
    }
    var Wm = function(a) {
            var b = Vm;
            F(Z(a));
            a = uk ? a[G(vk)] : a.C;
            var c = I(a, "state is only maintained on arrays.")[X] | 0;
            Y(a, c);
            (a = Jm(a, c, b, 2)) || (a = b[Yj]) || (a = new b, F(Z(a)), c = uk ? a[G(vk)] : a.C, mk(c, 34), a = b[Yj] = a);
            return a
        },
        Xm = function(a, b, c, d) {
            F(Z(a));
            var e = uk ? a[G(vk)] : a.C;
            var f = I(e, "state is only maintained on arrays.")[X] | 0;
            Y(e, f);
            b = Jm(e, f, b, c, d);
            if (b == null) return b;
            f = I(e, "state is only maintained on arrays.")[X] | 0;
            Y(e, f);
            if (!Fk(a, f)) {
                var g = b;
                F(Z(g));
                var h = uk ? g[G(vk)] : g.C;
                var k = I(h, "state is only maintained on arrays.")[X] |
                    0;
                Y(h, k);
                g = Fk(g, k) ? Am(g, h, k) ? Bm(g, h, !0) : new g.constructor(zm(h, k, !1)) : g;
                g !== b && (Cm(a) && (F(Z(a)), e = uk ? a[G(vk)] : a.C, a = I(e, "state is only maintained on arrays.")[X] | 0, Y(e, a), f = a), b = g, f = Hm(e, f, c, b, d), Em(e, f))
            }
            return Lm(b, e)
        },
        Zm = function(a) {
            var b = Ym;
            F(Z(a));
            var c = uk ? a[G(vk)] : a.C;
            var d = I(c, "state is only maintained on arrays.")[X] | 0;
            Y(c, d);
            Fk(a, d);
            var e = !!e || !1;
            a = Om(c, 10);
            var f = a === ik ? 7 : I(a, "state is only maintained on arrays.")[X] | 0,
                g = Pm(f, d),
                h = !(4 & g);
            if (h) {
                var k = a,
                    l = d,
                    m = !!(2 & g);
                m && (l |= 2);
                for (var u = !m,
                        t = !0, r = 0, w = 0; r < k.length; r++) {
                    var v = sl(k[r], b, l);
                    if (v instanceof b) {
                        if (!m) {
                            var z = Fk(v);
                            u && (u = !z);
                            t && (t = z)
                        }
                        k[w++] = v
                    }
                }
                w < r && (k.length = w);
                g |= 4;
                g = t ? g & -4097 : g | 4096;
                g = u ? g | 8 : g & -9
            }
            g !== f && (kk(a, g), 2 & g && Object.freeze(a));
            a = Rm(a, g, c, d, 10, 1, h, e);
            if (!e) {
                b = a;
                d = !1;
                d = d === void 0 ? !1 : d;
                e = pk(c);
                f = pk(b);
                h = Object.isFrozen(b) && f;
                Mm(b, c, d);
                if (e || f) d ? F(f) : F(h);
                F(!!((I(b, "state is only maintained on arrays.")[X] | 0) & 4));
                if (f && b.length)
                    for (d = 0; d < 1; d++) Lm(b[d], c)
            }
            return a
        },
        $m = function(a, b, c, d) {
            d != null ? rl(d, G(b)) : d = void 0;
            Im(a,
                c, d);
            d && !Fk(d) && (F(Z(a)), b = uk ? a[G(vk)] : a.C, Em(b));
            return a
        };

    function Qm(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }
    var an = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            var d;
            return (d = el(Gm(a, b))) != null ? d : c
        },
        bn = function(a, b) {
            var c = c === void 0 ? 0 : c;
            var d;
            return (d = ll(Gm(a, b))) != null ? d : c
        },
        cn = function(a, b) {
            var c = c === void 0 ? "" : c;
            a = ql(Gm(a, b));
            return a != null ? a : c
        },
        dn = function(a, b, c) {
            if (c != null && typeof c !== "boolean") throw Error("ma`" + Ja(c) + "`" + c);
            return Im(a, b, c)
        },
        en = function(a, b, c) {
            if (c != null) {
                if (typeof c !== "number") throw Uk(ml(c));
                if (!$k(c)) throw Uk(ml(c));
                c >>>= 0
            }
            return Im(a, b, c)
        },
        fn = function(a, b, c) {
            if (c != null && typeof c !== "string") throw Error("na`" +
                c + "`" + Ja(c));
            return Im(a, b, c)
        },
        gn = function(a, b, c) {
            return Im(a, b, c == null ? c : hl(c))
        },
        hn = function(a, b, c) {
            Dm(a);
            b = Nm(a, b, il, 2, !0);
            b === ik || I(b, "state is only maintained on arrays.");
            if (Array.isArray(c))
                for (var d = c.length, e = 0; e < d; e++) b.push(hl(c[e]));
            else
                for (c = x(c), d = c.next(); !d.done; d = c.next()) b.push(hl(d.value));
            Nk(b);
            return a
        };
    var jn = function(a, b, c) {
        this.preventPassingToStructuredClone = Lk;
        Eb(this, jn, "The message constructor should only be used by subclasses");
        F(this.constructor !== jn, "Message is an abstract class and cannot be directly constructed");
        a = vm(a, b, c, 2048);
        F(Z(this));
        I(a);
        uk ? this[G(vk)] = a : this.C = a;
        F(Z(this));
        a = uk ? this[G(vk)] : this.C;
        b = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        F(b & 64);
        F(b & 2048)
    };
    n = jn.prototype;
    n.toJSON = function() {
        return om(this)
    };
    n.Ya = function() {
        return JSON.stringify(om(this))
    };
    n.getExtension = function(a) {
        Eb(this, a.Sf);
        var b = Eb(this, jn);
        hm(b, a.ga);
        gm(b, a.ga, a.Me);
        return a.ib ? a.zd ? a.Lb(b, a.ib, a.ga, void 0 === Ok ? 2 : 4, a.nb) : a.Lb(b, a.ib, a.ga, a.nb) : a.zd ? a.Lb(b, a.ga, void 0 === Ok ? 2 : 4, a.nb) : a.Lb(b, a.ga, a.defaultValue, a.nb)
    };
    n.hasExtension = function(a) {
        F(!a.zd, "repeated extensions don't support hasExtension");
        var b = Eb(this, jn);
        hm(b, a.ga);
        gm(b, a.ga, a.Me);
        a.ib ? a = Km(b, a.ib, a.ga, a.nb) : (F(!a.zd, "repeated extensions don't support getExtensionOrUndefined"), Eb(b, a.Sf), b = Eb(b, jn), hm(b, a.ga), gm(b, a.ga, a.Me), a = a.ib ? a.Lb(b, a.ib, a.ga, a.nb) : a.Lb(b, a.ga, null, a.nb), a = (a === null ? void 0 : a) !== void 0);
        return a
    };
    n.clone = function() {
        var a = Eb(this, jn);
        F(Ak(a));
        var b = wk(a),
            c = ok(b);
        return Am(a, b, c) ? Bm(a, b, !0) : new a.constructor(zm(b, c, !1))
    };
    n.qg = function() {
        return Fk(this)
    };
    xk = jn;
    jn.prototype[dk] = zk;
    jn.prototype.toString = function() {
        F(Z(this));
        return (uk ? this[G(vk)] : this.C).toString()
    };
    var kn = function(a, b, c, d) {
        this.Ud = a;
        this.Vd = b;
        a = Ma(Ml);
        this.dh = !!a && d === a || !1
    };

    function ln(a) {
        var b = mn;
        var c = c === void 0 ? Ml : c;
        return new kn(a, b, !1, c)
    }

    function mn(a, b, c, d, e) {
        b = nn(b, d);
        b != null && (c = Fl(a, c), e(b, a), Gl(a, c))
    }
    var on = ln(function(a, b, c, d, e) {
            if (a.j !== 2) return !1;
            Nj(a, Um(b, d, c), e);
            return !0
        }),
        pn = ln(function(a, b, c, d, e) {
            if (a.j !== 2) return !1;
            Nj(a, Um(b, d, c), e);
            return !0
        }),
        qn = Symbol(),
        rn = Symbol(),
        sn = Symbol(),
        tn = Symbol(),
        un = Symbol(),
        An, Bn;

    function Cn(a, b, c, d) {
        var e = d[a];
        if (e) return e;
        e = {};
        e.ph = d;
        e.Kc = F(tm(d[0]));
        var f = d[1],
            g = 1;
        f && f.constructor === Object && (e.re = f, f = d[++g], typeof f === "function" && (An != null && (F(An === f), F(Bn === d[1 + g])), e.sg = !0, An != null || (An = f), Bn != null || (Bn = Bb(d[g + 1])), f = d[g += 2]));
        for (var h = {}; f && Dn(f);) {
            for (var k = 0; k < f.length; k++) h[f[k]] = f;
            f = d[++g]
        }
        for (k = 1; f !== void 0;) {
            typeof f === "number" && (F(f > 0), k += f, f = d[++g]);
            var l = void 0;
            if (f instanceof kn) var m = f;
            else m = on, g--;
            f = void 0;
            if ((f = m) == null ? 0 : f.dh) {
                f = d[++g];
                l = d;
                var u = g;
                typeof f ===
                    "function" && (F(f.length === 0), f = f(), l[u] = f);
                En(f);
                l = f
            }
            f = d[++g];
            u = k + 1;
            typeof f === "number" && f < 0 && (u -= f, f = d[++g]);
            for (; k < u; k++) {
                var t = h[k];
                l ? c(e, k, F(m), l, t) : b(e, k, F(m), t)
            }
        }
        return d[a] = e
    }

    function Dn(a) {
        return Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    }

    function En(a) {
        if (Array.isArray(a) && a.length) {
            var b = a[0];
            var c = tm(b);
            c != null && c !== b && (a[0] = c);
            b = c != null
        } else b = !1;
        F(b);
        return a
    }

    function Fn(a) {
        return Array.isArray(a) ? a[0] instanceof kn ? (F(a.length === 2), En(a[1]), a) : [pn, En(a)] : [Eb(a, kn), void 0]
    }

    function nn(a, b) {
        if (a instanceof jn) return F(Z(a)), uk ? a[G(vk)] : a.C;
        if (Array.isArray(a)) return um(a, b)
    };

    function Gn(a) {
        return Cn(rn, Hn, In, a)
    }

    function Hn(a, b, c, d) {
        var e = c.Ud;
        a[b] = d ? function(f, g, h) {
            return e(f, g, h, d)
        } : e
    }

    function In(a, b, c, d, e) {
        var f = c.Ud,
            g, h;
        a[b] = function(k, l, m) {
            return f(k, l, m, h || (h = Gn(d).Kc), g || (g = Jn(d)), e)
        }
    }

    function Jn(a) {
        var b = a[sn];
        if (b != null) return b;
        var c = Gn(a);
        b = c.sg ? function(d, e) {
            return F(An)(d, e, c)
        } : function(d, e) {
            var f = I(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, f, !0);
            for (F(!(f & 2)); Lj(e) && e.j != 4;) {
                f = e.Wb;
                var g = c[f];
                if (g == null) {
                    var h = c.re;
                    h && (h = h[f]) && (h = Kn(h), h != null && (g = c[f] = h))
                }
                if (g == null || !g(e, d, f)) {
                    h = e;
                    g = h.lb;
                    Mj(h);
                    if (h.me) var k = void 0;
                    else {
                        var l = h.o.da(),
                            m = l - g;
                        h.o.S = g;
                        g = h.o.Ue(m);
                        F(l == h.o.da());
                        k = g
                    }
                    l = h = g = void 0;
                    m = d;
                    I(m);
                    k && ((g = (h = (l = m[Zj]) != null ? l : m[Zj] = new cm)[f]) != null ? g : h[f] = []).push(k)
                }
            }
            if (d =
                bm(d)) d.Ze = G(c.ph[un]);
            return !0
        };
        a[sn] = b;
        a[un] = Ln.bind(a);
        return b
    }

    function Ln(a, b, c, d) {
        var e = this[rn],
            f = this[sn],
            g = um(void 0, e.Kc),
            h = bm(a);
        if (h) {
            var k = !1,
                l = e.re;
            if (l) {
                e = function(w, v, z) {
                    if (z.length !== 0)
                        if (l[v])
                            for (w = x(z), v = w.next(); !v.done; v = w.next()) {
                                v = Kj(v.value);
                                try {
                                    k = !0, f(g, v)
                                } finally {
                                    v.te()
                                }
                            } else d == null || d(a, v, z)
                };
                if (b == null) dm(h, e);
                else if (h != null) {
                    var m = h[b];
                    m && e(h, b, m)
                }
                if (k) {
                    var u = nk(a);
                    if (u & 2 && u & 2048 && (c == null || !c.Yi)) throw Error("Ha");
                    var t = Sk(u),
                        r = function(w, v) {
                            if (Fm(a, w, t) != null) switch (c == null ? void 0 : c.Ck) {
                                case 1:
                                    return;
                                default:
                                    throw Error("Ia`" + w);
                            }
                            v != null && (u = G(Hm(a, u, w, v, t)));
                            delete h[w]
                        };
                    b == null ? Qk(g, nk(g), function(w, v) {
                        r(w, v)
                    }) : r(b, Fm(g, b, t))
                }
            }
        }
    }

    function Kn(a) {
        a = Fn(a);
        var b = Eb(a[0], kn).Ud;
        if (a = a[1]) {
            var c = Jn(En(a)),
                d = Gn(En(a)).Kc;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    };

    function Mn(a, b, c) {
        a[b] = c.Vd
    }

    function Nn(a, b, c, d) {
        var e, f, g = c.Vd;
        a[b] = function(h, k, l) {
            return g(h, k, l, f || (f = Cn(qn, Mn, Nn, d).Kc), e || (e = On(d)))
        }
    }

    function On(a) {
        var b = a[tn];
        if (!b) {
            var c = Cn(qn, Mn, Nn, a);
            b = function(d, e) {
                return Pn(d, e, c)
            };
            a[tn] = b
        }
        return b
    }

    function Pn(a, b, c) {
        Qk(a, I(a, "state is only maintained on arrays.")[X] | 0, function(e, f) {
            if (f != null) {
                var g = Qn(c, e);
                g ? g(b, f, e) : (I(a), e < 500 || Vk(ck, 3, "0ubsb:" + e))
            }
        });
        var d = bm(a);
        d && dm(d, function(e, f, g) {
            Dl(b, b.G.end());
            for (e = 0; e < g.length; e++) Dl(b, Ui(g[e]))
        })
    }

    function Qn(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.re)
            if (c = c[b]) {
                c = Fn(c);
                var d = Eb(c[0], kn).Vd;
                if (c = c[1]) {
                    c = En(c);
                    var e = On(c),
                        f = Cn(qn, Mn, Nn, c).Kc;
                    c = a.sg ? F(Bn)(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };

    function Rn(a, b, c) {
        if (Array.isArray(b)) {
            var d = I(b, "state is only maintained on arrays.")[X] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                g != null && (F(typeof g !== "object" || g instanceof Si), b[f++] = g)
            }
            f < e && (b.length = f);
            a = d | 1;
            c && (a = (a | 4) & -1537);
            a !== d && kk(b, a);
            c && a & 2 && Object.freeze(b);
            return b
        }
    }
    var Sn = function(a, b) {
        var c = new Cl;
        Pn(wk(Eb(a, jn)), c, Cn(qn, Mn, Nn, b));
        Dl(c, c.G.end());
        a = new Uint8Array(c.Fb);
        b = c.be;
        for (var d = b.length, e = 0, f = 0; f < d; f++) {
            var g = b[f];
            a.set(g, e);
            e += g.length
        }
        F(e == a.length);
        c.be = [a];
        return a
    };

    function Tn(a, b, c) {
        return new kn(a, b, !1, c)
    }

    function Un(a, b, c) {
        return new kn(a, b, Ll, c)
    }

    function Vn(a, b, c) {
        var d = I(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, d, !0);
        Hm(a, d, b, c, Sk(I(a, "state is only maintained on arrays.")[X] | 0))
    }

    function Wn(a, b, c) {
        if (a.j !== 0 && a.j !== 2) return !1;
        var d = I(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, d, !0);
        b = Tm(b, d, c);
        a.j == 2 ? Uj(a, Fj, b) : b.push(Sj(a));
        return !0
    }
    var Xn = Tn(function(a, b, c) {
            if (a.j !== 1) return !1;
            F(a.j == 1);
            var d = a.o;
            a = Dj(d);
            var e = Dj(d);
            d = (e >> 31) * 2 + 1;
            var f = e >>> 20 & 2047;
            a = 4294967296 * (e & 1048575) + a;
            Vn(b, c, f == 2047 ? a ? NaN : d * Infinity : f == 0 ? d * 4.9E-324 * a : d * Math.pow(2, f - 1075) * (a + 4503599627370496));
            return !0
        }, function(a, b, c) {
            a.tf(c, cl(b))
        }, Vl),
        Yn = Tn(function(a, b, c) {
            if (a.j !== 5) return !1;
            F(a.j == 5);
            var d = Dj(a.o);
            a = (d >> 31) * 2 + 1;
            var e = d >>> 23 & 255;
            d &= 8388607;
            Vn(b, c, e == 255 ? d ? NaN : a * Infinity : e == 0 ? a * 1.401298464324817E-45 * d : a * Math.pow(2, e - 150) * (d + 8388608));
            return !0
        }, function(a,
            b, c) {
            a.uf(c, cl(b))
        }, Ul),
        Zn = Tn(function(a, b, c) {
            if (Ng) return a.j !== 0 ? b = !1 : (F(a.j == 0), a = yj(a.o, rj), Vn(b, c, a), b = !0), b;
            if (a.j !== 0) return !1;
            F(a.j == 0);
            a = yj(a.o, qj);
            Vn(b, c, a);
            return !0
        }, function(a, b, c) {
            a.ah(c, ol(b))
        }, Sl),
        $n = Tn(function(a, b, c) {
            if (Ng) return a.j !== 0 ? a = !1 : (Vn(b, c, Rj(a)), a = !0), a;
            if (a.j !== 0) return !1;
            Vn(b, c, Qj(a));
            return !0
        }, function(a, b, c) {
            a.bh(c, pl(b))
        }, Tl),
        ao = Un(function(a, b, c) {
            if (Ng) {
                if (a.j !== 0 && a.j !== 2) a = !1;
                else {
                    var d = I(b, "state is only maintained on arrays.")[X] | 0;
                    Y(b, d, !0);
                    b = Tm(b, d, c);
                    a.j ==
                        2 ? Uj(a, Cj, b) : b.push(Rj(a));
                    a = !0
                }
                return a
            }
            if (a.j !== 0 && a.j !== 2) return !1;
            d = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Tm(b, d, c);
            a.j == 2 ? Uj(a, Bj, b) : b.push(Qj(a));
            return !0
        }, function(a, b, c) {
            b = Rn(pl, b, !1);
            if (b != null)
                for (var d = 0; d < b.length; d++) Hl(a, c, b[d])
        }, Tl),
        bo = Tn(function(a, b, c) {
            if (a.j !== 0) return !1;
            Vn(b, c, Oj(a));
            return !0
        }, function(a, b, c) {
            a.Zg(c, ll(b))
        }, Pl),
        co = Un(function(a, b, c) {
            if (a.j !== 0 && a.j !== 2) return !1;
            var d = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Tm(b, d, c);
            a.j ==
                2 ? Uj(a, zj, b) : b.push(Oj(a));
            return !0
        }, function(a, b, c) {
            b = Rn(ll, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) {
                    var e = a,
                        f = c,
                        g = b[d];
                    g != null && (Jl(f, g), El(e, f, 0), Bl(e.G, g))
                }
        }, Pl),
        eo = Tn(function(a, b, c) {
            if (a.j !== 5) return !1;
            F(a.j == 5);
            a = Dj(a.o);
            Vn(b, c, a);
            return !0
        }, function(a, b, c) {
            b = nl(b);
            b != null && (Il(c, b, b >= 0 && b < 4294967296), El(a, c, 5), a.G.Ea(b))
        }, Rl),
        fo = Tn(function(a, b, c) {
            if (a.j !== 0) return !1;
            F(a.j == 0);
            a = Ej(a.o);
            Vn(b, c, a);
            return !0
        }, function(a, b, c) {
            a.sf(c, el(b))
        }, Nl),
        go = Tn(function(a, b, c) {
            if (a.j !== 2) return !1;
            Vn(b,
                c, Tj(a));
            return !0
        }, function(a, b, c) {
            b = ql(b);
            if (b != null) {
                var d = !0;
                d = d === void 0 ? !1 : d;
                Ab(b);
                if (Ii) {
                    if (d && (Hi ? !b.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(b))) throw Error("U");
                    b = (Gi || (Gi = new TextEncoder)).encode(b)
                } else {
                    for (var e = 0, f = new Uint8Array(3 * b.length), g = 0; g < b.length; g++) {
                        var h = b.charCodeAt(g);
                        if (h < 128) f[e++] = h;
                        else {
                            if (h < 2048) f[e++] = h >> 6 | 192;
                            else {
                                F(h < 65536);
                                if (h >= 55296 && h <= 57343) {
                                    if (h <= 56319 && g < b.length) {
                                        var k = b.charCodeAt(++g);
                                        if (k >= 56320 &&
                                            k <= 57343) {
                                            h = (h - 55296) * 1024 + k - 56320 + 65536;
                                            f[e++] = h >> 18 | 240;
                                            f[e++] = h >> 12 & 63 | 128;
                                            f[e++] = h >> 6 & 63 | 128;
                                            f[e++] = h & 63 | 128;
                                            continue
                                        } else g--
                                    }
                                    if (d) throw Error("U");
                                    h = 65533
                                }
                                f[e++] = h >> 12 | 224;
                                f[e++] = h >> 6 & 63 | 128
                            }
                            f[e++] = h & 63 | 128
                        }
                    }
                    b = e === f.length ? f : f.subarray(0, e)
                }
                El(a, c, 2);
                Al(a.G, b.length);
                Dl(a, a.G.end());
                Dl(a, b)
            }
        }, Ol),
        ho, io = void 0;
    io = io === void 0 ? Ml : io;
    ho = new kn(function(a, b, c, d, e) {
        if (a.j !== 2) return !1;
        d = um(void 0, d);
        var f = I(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, f, !0);
        Tm(b, f, c).push(d);
        Nj(a, d, e);
        return !0
    }, function(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) {
                var g = a,
                    h = c,
                    k = e,
                    l = nn(b[f], d);
                l != null && (h = Fl(g, h), k(l, g), Gl(g, h))
            }
            a = lk(b);
            a & 1 || kk(b, a | 1)
        }
    }, Ll, io);
    var jo = Tn(function(a, b, c) {
            if (a.j !== 0) return !1;
            Vn(b, c, Pj(a));
            return !0
        }, function(a, b, c) {
            a.Ea(c, nl(b))
        }, Ql),
        ko = Un(function(a, b, c) {
            if (a.j !== 0 && a.j !== 2) return !1;
            var d = I(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Tm(b, d, c);
            a.j == 2 ? Uj(a, Aj, b) : b.push(Pj(a));
            return !0
        }, function(a, b, c) {
            b = Rn(nl, b, !0);
            if (b != null && b.length) {
                c = Fl(a, c);
                for (var d = 0; d < b.length; d++) Al(a.G, b[d]);
                Gl(a, c)
            }
        }, Ql),
        lo = Tn(function(a, b, c) {
            if (a.j !== 0) return !1;
            Vn(b, c, Sj(a));
            return !0
        }, function(a, b, c) {
            a.Td(c, ll(b))
        }, Wl),
        mo = Un(Wn, function(a,
            b, c) {
            b = Rn(ll, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) a.Td(c, b[d])
        }, Wl),
        no = Un(Wn, function(a, b, c) {
            b = Rn(ll, b, !0);
            if (b != null && b.length) {
                c = Fl(a, c);
                for (var d = 0; d < b.length; d++) a.G.Td(b[d]);
                Gl(a, c)
            }
        }, Wl);
    var qo = function() {
        var a = oo,
            b = po;
        F(!0);
        this.ga = 4156379;
        this.Sf = a;
        this.ib = b;
        this.zd = 0;
        this.Lb = Xm;
        this.defaultValue = void 0;
        this.nb = a.fk != null ? Dk : void 0;
        this.Me = void 0;
        F(!0, "lazyParse must be undefined or LAZILY_PARSE_LATE_LOADED_EXTENSIONS_SYMBOL")
    };
    qo.prototype.register = function() {
        Hg(this)
    };

    function ro(a) {
        if (a instanceof jn) return a.constructor.U
    };
    (function() {
        var a = Ha.jspbGetTypeName;
        Ha.jspbGetTypeName = a ? function(b) {
            return a(b) || ro(b)
        } : ro
    })();
    var so = jn;

    function to(a, b) {
        return function(c, d) {
            var e = {
                Pd: !0
            };
            d && Object.assign(e, d);
            c = Kj(c, void 0, void 0, e);
            try {
                var f = new a,
                    g = wk(f);
                Jn(b)(g, c);
                var h = f
            } finally {
                c.te()
            }
            return h
        }
    }

    function uo(a) {
        return function() {
            return Sn(this, a)
        }
    }

    function vo(a) {
        return function(b) {
            Bb(a);
            if (b == null || b == "") b = Eb(new a, jn);
            else {
                Ab(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Ga`" + Ja(b) + "`" + b);
                mk(b, 32);
                b = new a(b)
            }
            return b
        }
    };
    var Ym = function(a) {
        so.call(this, a)
    };
    q(Ym, so);
    Ym.prototype.dg = function() {
        return cn(this, 2)
    };
    Ym.U = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var wo = [0, go, -1];
    Ym.prototype.P = uo(wo);
    var xo = function(a) {
        so.call(this, a)
    };
    q(xo, so);
    var yo = function(a, b) {
            return fn(a, 2, b)
        },
        zo = function(a, b) {
            return fn(a, 3, b)
        },
        Ao = function(a, b) {
            return fn(a, 4, b)
        },
        Bo = function(a, b) {
            return fn(a, 5, b)
        },
        Co = function(a, b) {
            return fn(a, 9, b)
        },
        Do = function(a, b) {
            var c = Ym;
            Dm(a);
            F(Z(a));
            var d = uk ? a[G(vk)] : a.C;
            var e = I(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, e);
            if (b == null) Hm(d, e, 10);
            else {
                var f = b;
                if (!Array.isArray(f)) throw a = "Expected array but got " + Ja(f) + ": " + f, Uk(a);
                for (var g = f = b === ik ? 7 : I(b, "state is only maintained on arrays.")[X] | 0, h = Sm(f), k = h || Object.isFrozen(b),
                        l = !0, m = !0, u = 0; u < b.length; u++) {
                    var t = b[u];
                    rl(t, G(c));
                    h || (t = Fk(t), l && (l = !t), m && (m = t))
                }
                h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
                k && f === g || (b = Wk(b), g = 0, f = Qm(f, e));
                f !== g && kk(b, f);
                Mk(b);
                e = Hm(d, e, 10, b);
                2 & f || xm(f) || Em(d, e)
            }
            return a
        },
        Eo = function(a, b) {
            return dn(a, 11, b)
        },
        Fo = function(a, b) {
            return fn(a, 1, b)
        },
        Go = function(a, b) {
            return dn(a, 7, b)
        };
    xo.U = "wireless.mdl.UserAgentClientHints";
    xo.prototype.P = uo([0, go, -4, ho, wo, fo, lo, go, ho, wo, fo]);
    var Ho = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Io(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function Jo(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function Ko(a) {
        if (!Jo(a)) return null;
        var b = Io(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Ho).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Lo(a) {
        var b;
        return Eo(Do(Bo(yo(Fo(Ao(Go(Co(zo(new xo, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new Ym;
            d = fn(d, 1, c.brand);
            return fn(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function Mo(a) {
        var b, c;
        return (c = (b = Ko(a)) == null ? void 0 : b.then(function(d) {
            return Lo(d)
        })) != null ? c : null
    };
    var No = function(a, b, c, d) {
        a = a === void 0 ? window : a;
        b = b === void 0 ? null : b;
        c = c === void 0 ? new Oa : c;
        d = d === void 0 ? Hf("current") : d;
        Zd.call(this);
        var e = this;
        this.global = a;
        this.Ha = b;
        this.J = c;
        this.ef = d;
        this.Ag = Ed(function() {
            return Id(e.global, "pagehide")
        }).g(qg(this.J, 941));
        this.zg = Ed(function() {
            return Id(e.global, "load")
        }).g(qg(this.J, 738), Re(1));
        this.Gi = Ed(function() {
            return Id(e.global, "resize")
        }).g(qg(this.J, 741));
        this.onMessage = Ed(function() {
            return Id(e.global, "message")
        }).g(qg(this.J, 740));
        this.document = new pi(this.global,
            this);
        this.m = new sg(new yg(this.R, this.J), new ug(this.R, this.J));
        this.L = new me(new Cg(this), new Hh(this), new qf(this, new Gg(this)), new qf(this, new Kh(this)), new qf(this, new Fh(this)))
    };
    q(No, Zd);
    var Oo = function(a) {
            try {
                return !!a.global.sharedStorage
            } catch (b) {
                return b
            }
        },
        Po = function(a, b) {
            try {
                return !!a.global.localStorage
            } catch (c) {
                return (b === void 0 ? function() {} : b)(c), !1
            }
        };
    No.prototype.zc = function() {
        var a;
        return !((a = this.global.navigator) == null || !a.locks)
    };
    No.prototype.Ye = function(a, b) {
        var c = this;
        return Ca(function(d) {
            return c.zc() ? d.A(c.global.navigator.locks.request(a, b), 0) : d.return()
        })
    };
    var Dg = function(a) {
        var b = a.global;
        return !!a.global.HTMLFencedFrameElement && !!b.fence && typeof b.fence.reportEvent === "function"
    };
    No.prototype.bc = function(a) {
        Dg(this) && this.global.fence.reportEvent(a)
    };
    No.prototype.ve = function() {
        return this.Ag.g(qg(this.J, 942), V(this.i, 1), N(function() {}))
    };
    var Qo = function(a) {
            var b = new No(a.global.top, a.Ha);
            b.L = a.L;
            return b
        },
        Ro = function(a, b) {
            b.start();
            return Id(b, "message").g(qg(a.J, 740))
        };
    No.prototype.postMessage = function(a, b, c) {
        c = c === void 0 ? [] : c;
        this.global.postMessage(a, b, c)
    };
    No.prototype.eg = function() {
        return Jg(this.global) ? this.global.width : 0
    };
    No.prototype.bg = function() {
        return Jg(this.global) ? this.global.height : 0
    };
    var So = function(a, b) {
        try {
            var c = zi(b, a.global);
            return {
                left: c.left,
                top: c.top,
                width: c.eg(),
                height: c.bg()
            }
        } catch (d) {
            return vi
        }
    };
    No.prototype.validate = function() {
        var a = this.L.O() || Dg(this);
        return this.global && this.m.ka() && a
    };
    var Xh = function(a) {
        return (a = Mo(a.global)) ? Oc(a) : null
    };
    da.Object.defineProperties(No.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.sharedStorage
                } catch (a) {}
            }
        },
        localStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.localStorage
                } catch (a) {}
            }
        },
        R: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        rb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !Jg(this.global.top)
            }
        },
        Be: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.rb || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.R.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.R.ResizeObserver
            }
        },
        rh: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });
    var To = !ch && !Vg();

    function Uo(a, b) {
        if (/-[a-z]/.test(b)) return null;
        if (To && a.dataset) {
            if (Xg() && !(b in a.dataset)) return null;
            a = a.dataset[b];
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + String(b).replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var Vo = {},
        Wo = (Vo["data-google-av-cxn"] = "_avicxn_", Vo["data-google-av-cpmav"] = "_cvu_", Vo["data-google-av-metadata"] = "_avm_", Vo["data-google-av-adk"] = "_adk_", Vo["data-google-av-btr"] = void 0, Vo["data-google-av-override"] = void 0, Vo["data-google-av-dm"] = void 0, Vo["data-google-av-immediate"] = void 0, Vo["data-google-av-aid"] = void 0, Vo["data-google-av-naid"] = void 0, Vo["data-google-av-inapp"] = void 0, Vo["data-google-av-slift"] = void 0, Vo["data-google-av-itpl"] = void 0, Vo["data-google-av-ext-cxn"] = void 0, Vo["data-google-av-rs"] =
            void 0, Vo["data-google-av-flags"] = void 0, Vo["data-google-av-turtlex"] = void 0, Vo["data-google-av-ufs-integrator-metadata"] = void 0, Vo["data-google-av-vattr"] = void 0, Vo["data-google-av-vrus"] = void 0, Vo),
        Xo = {},
        Yo = (Xo["data-google-av-adk"] = "googleAvAdk", Xo["data-google-av-btr"] = "googleAvBtr", Xo["data-google-av-cpmav"] = "googleAvCpmav", Xo["data-google-av-dm"] = "googleAvDm", Xo["data-google-av-ext-cxn"] = "googleAvExtCxn", Xo["data-google-av-immediate"] = "googleAvImmediate", Xo["data-google-av-inapp"] = "googleAvInapp",
            Xo["data-google-av-itpl"] = "googleAvItpl", Xo["data-google-av-metadata"] = "googleAvMetadata", Xo["data-google-av-naid"] = "googleAvNaid", Xo["data-google-av-override"] = "googleAvOverride", Xo["data-google-av-rs"] = "googleAvRs", Xo["data-google-av-slift"] = "googleAvSlift", Xo["data-google-av-cxn"] = "googleAvCxn", Xo["data-google-av-aid"] = void 0, Xo["data-google-av-flags"] = "googleAvFlags", Xo["data-google-av-turtlex"] = "googleAvTurtlex", Xo["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", Xo["data-google-av-vattr"] =
            "googleAvVattr", Xo["data-google-av-vrus"] = "googleAvVurs", Xo);

    function Zo(a, b) {
        if (a.l === void 0) return null;
        try {
            var c;
            var d = (c = a.l.getAttribute(b)) != null ? c : null;
            if (d !== null) return d
        } catch (g) {}
        try {
            var e = Wo[b];
            if (e && (d = a.l[e], d !== void 0)) return d
        } catch (g) {}
        try {
            var f = Yo[b];
            if (f) return Uo(a.l, f)
        } catch (g) {}
        return null
    }

    function $o(a) {
        return N(function(b) {
            return Zo(b, a)
        })
    };
    var ap = K(function(a) {
        return N(function(b) {
            return a.map(function(c) {
                return Zo(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), N(function(a) {
        var b = x(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (b !== null) return [];
            throw new ie;
        }
        return a.split("|")
    }));
    var bp = function() {
        return K(Bd(function(a) {
            return a.element.g(ap, Ke(function() {
                return Zc([""])
            })).g(N(function(b) {
                return {
                    qa: b,
                    ld: a
                }
            }))
        }), Te(function(a) {
            return a.qa.sort().join(";")
        }), N(function(a) {
            return a.ld
        }))
    };

    function cp() {
        return Bd(function(a) {
            return Oc(dp(a)).g(Lh(a.i))
        })
    }

    function dp(a) {
        return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
            return new Zh(b)
        })
    };

    function ep(a) {
        var b = a.zg,
            c = a.document.Fi;
        return Pd(Zc({}), c, b).g(N(function() {
            return a
        }))
    };
    var gp = N(fp);

    function fp(a) {
        var b = Number(Zo(a, "data-google-av-rs"));
        if (!isNaN(b) && b !== 0) return b;
        var c;
        return (a = (c = a.l) == null ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function hp() {
        return K(O(function(a) {
            return a !== void 0
        }), N(function(a) {
            return a
        }))
    };

    function ip() {
        return function(a) {
            var b = [];
            return a.g(O(function(c) {
                if (c.l === void 0 || b.some(function(d) {
                        return d.l === c.l
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function jp(a, b) {
        b = b === void 0 ? Ac : b;
        return Pd(ep(a), b).g(cp(), ip(), hp(), V(a.i, 1))
    };

    function kp(a, b) {
        return new L(function(c) {
            var d = !1,
                e = Array(b.length);
            e.fill(void 0);
            var f = new Set,
                g = new Set,
                h = function(u, t) {
                    a.Eg ? (e[t] = u, f.add(t), d || (d = !0, Ta(a, function() {
                        d = !1;
                        c.next(Jb(e))
                    }, 1))) : c.error(new je(t))
                },
                k = function(u, t) {
                    g.add(t);
                    f.add(t);
                    Ta(a, function() {
                        c.error(u)
                    }, 1)
                },
                l = function(u) {
                    g.add(u);
                    Ta(a, function() {
                        g.size === b.length && c.complete()
                    }, 1)
                },
                m = b.map(function(u, t) {
                    return u.subscribe(function(r) {
                        return void h(r, t)
                    }, function(r) {
                        return void k(r, t)
                    }, function() {
                        return void l(t)
                    })
                });
            return function() {
                m.forEach(function(u) {
                    return void u.unsubscribe()
                })
            }
        })
    };

    function lp(a, b, c) {
        function d() {
            if (b.Ha) {
                var z = b.Ha,
                    C = z.next;
                var Q = {
                    creativeId: b.wc.getName(c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: h,
                    erroredSignalKey: k
                };
                Q = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: se(b.m.now(), new qe(0, b.m.timeline)),
                    instanceId: b.wc.getName(b.Eb),
                    creativeState: Q
                };
                C.call(z, Q)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, h = null, k = null, l = {}, m = new Set, u = [], t = [], r = x(e), w = r.next(), v = {}; !w.done; v = {
                oa: void 0
            }, w = r.next()) v.oa = w.value, w = a[v.oa],
            w instanceof W ? (l[v.oa] = w.value, m.add(v.oa), b.Ha && (f[String(v.oa)] = ue(w.value))) : (w = w.g(P(function(z, C) {
                    return ne(z) || ne(C) ? !1 : z === C
                }), N(function(z) {
                    return function(C) {
                        b.Ha && (f[String(z.oa)] = ue(C), d());
                        var Q = {};
                        return Q[z.oa] = C, Q
                    }
                }(v)), Ke(function(z) {
                    return function(C) {
                        if (C instanceof je) throw new le(String(z.oa));
                        throw C;
                    }
                }(v)), jf(function(z) {
                    return function() {
                        m.add(z.oa)
                    }
                }(v), function(z) {
                    return function(C) {
                        k = String(z.oa);
                        h = String(C);
                        d()
                    }
                }(v), function(z) {
                    return function() {
                        m.has(z.oa) || (g = !0, d())
                    }
                }(v))),
                t.push(v.oa), u.push(w));
        (a = Object.keys(f).length > 0) && d();
        r = kp(b.i, u).g(Ke(function(z) {
            if (z instanceof je) throw new ke(String(t[z.Zh]));
            throw z;
        }), N(function(z) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(y(z))))
        }));
        return (u = u.length > 0) && a ? Pd(Zc(Object.freeze(l)), r) : u ? r : Zc(Object.freeze(l))
    };

    function mp(a, b, c, d, e) {
        return a.J.kc.bind(a.J)(733, function() {
            var f = {};
            try {
                return b.g(Ke(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Ac
                }), Bd(function(g) {
                    try {
                        var h = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), Ac
                    }
                    var k = {};
                    return lp(h, a, g.Eb).g(jf(function(l) {
                        k = l
                    }), cf(1), id()).g(e, Ke(function(l) {
                        d(Object.assign({}, k, {
                            error: l
                        }));
                        return Ac
                    }), Xe(void 0), N(function() {
                        return !0
                    }))
                })).g(ef(function(g) {
                    return g + 1
                }, 0), Ke(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Ac
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), Ac
            }
        })()
    };

    function np(a, b) {
        return K(S(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new L(function(g) {
                e(d, f, function(h) {
                    g.next(Object.assign({}, c, {
                        fb: h
                    }));
                    g.complete()
                });
                return function() {}
            }) : Qd
        }), O(function(c) {
            return c.fb
        }))
    };
    var op = K(O(function(a) {
        var b = a.L;
        var c = a.sc;
        var d = a.lc;
        var e = a.bc;
        var f = a.sb;
        var g = a.Ta;
        a = a.rc;
        return g !== void 0 && a !== void 0 && b !== void 0 && c !== void 0 && d !== void 0 && (!f || e !== void 0)
    }), hf(function(a) {
        return !(a.ng === !1 && a.pe !== void 0)
    }, !1), O(function(a) {
        var b = a.ng;
        var c = a.yc;
        var d = a.rj;
        a = a.sc;
        return d ? !!c && a !== void 0 && (a == null ? void 0 : a.length) > 0 : !!b
    }), np(function(a) {
        return a.rc
    }, function(a) {
        return a.Ta
    }), N(function(a) {
        a.sb || a.lc(a.sc, a).forEach(function(b) {
            a.L.M(b).sendNow()
        })
    }), Re(1), Pe());
    var pp = function(a) {
            var b = b === void 0 ? {} : b;
            this.La = a;
            this.config = {
                maxAdKeys: b.maxAdKeys || 50,
                maxHourlyEvents: b.maxHourlyEvents || 2,
                maxDailyEvents: b.maxDailyEvents || 2,
                maxWeeklyEvents: b.maxWeeklyEvents || 2
            };
            this.ta = new Map
        },
        qp = function(a) {
            try {
                var b = JSON.stringify(Array.from(a.ta.entries()));
                a.La.setItem("adStatsCache", b)
            } catch (c) {
                a.La.reportError(c)
            }
        },
        sp = function(a, b, c) {
            return Ca(function(d) {
                return d.A(a.La.performExclusiveLockedOperation("avOmakaseLock", function() {
                    a: {
                        var e = a.La.getItem("adStatsCache");
                        if (e) try {
                            var f = new Map(JSON.parse(e));
                            break a
                        } catch (h) {
                            a.La.reportError(h)
                        }
                        f = new Map
                    }
                    a.ta = f;f = a.ta.get(b) || {
                        h: {},
                        d: {},
                        w: {}
                    };e = f.h;
                    var g = new Date;g.setMinutes(0, 0, 0);rp(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxHourlyEvents);e = f.d;g = new Date;g.setHours(0, 0, 0, 0);rp(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxDailyEvents);e = f.w;g = new Date;g = new Date(g.setDate(g.getDate() - g.getDay()));g.setHours(0, 0, 0, 0);rp(e, Math.floor(g.getTime() / 1E3).toString(), c, a.config.maxWeeklyEvents);a.ta.has(b) ?
                    a.ta.delete(b) : a.ta.size >= a.config.maxAdKeys && a.ta.size >= a.config.maxAdKeys && (e = a.ta.keys().next().value, a.ta.delete(e));f.ts = Date.now();a.ta.set(b, f);qp(a)
                }), 0)
            })
        },
        tp = function(a, b) {
            var c = c === void 0 ? 1 : c;
            Ca(function(d) {
                return d.A(sp(a, b, {
                    c: c,
                    v: 0,
                    cTos: 0
                }), 0)
            })
        },
        up = function(a, b) {
            var c = c === void 0 ? 1 : c;
            Ca(function(d) {
                return d.A(sp(a, b, {
                    c: 0,
                    v: c,
                    cTos: 0
                }), 0)
            })
        },
        vp = function(a, b, c) {
            Ca(function(d) {
                return d.A(sp(a, b, {
                    c: 0,
                    v: 0,
                    cTos: c
                }), 0)
            })
        },
        rp = function(a, b, c, d) {
            a[b] ? (a[b].c += c.c, a[b].cTos += c.cTos, a[b].v += c.v) :
                a[b] = {
                    c: c.c,
                    cTos: c.cTos,
                    v: c.v
                };
            b = Object.keys(a);
            b.length > d && delete a[b[0]]
        },
        wp = function(a, b) {
            Ca(function(c) {
                return a.La.hasLocalStorageAccess() ? c.A(a.La.performExclusiveLockedOperation("avOmakaseLock", function() {
                    var d = a.La.getItem("adStatsReset");
                    b > Number(d || "0") && (d !== null && (a.ta.clear(), qp(a)), a.La.setItem("adStatsReset", b.toString()))
                }), 0) : c.return()
            })
        };

    function xp(a) {
        a = a.ca().value.slice(0, 3).reduce(function(b, c) {
            return b + c
        }, 0);
        return Math.min(a, 61500)
    }

    function yp(a) {
        var b;
        return function(c) {
            var d = c.g(hf(function(g) {
                return g.pe === void 0
            }), gf(function(g) {
                return g.cf === void 0
            }), jf(function(g) {
                g.cf && b === void 0 && (b = new pp(a))
            }), hf(function(g) {
                return !!g.cf
            }), cf(1), id());
            c = d.g(N(function(g) {
                return g.Si
            }), O(function(g) {
                return g !== void 0
            }), Re(1), jf(function(g) {
                var h;
                (h = b) == null || wp(h, g)
            }));
            var e = d.g(O(function(g) {
                    return !!g.yc
                }), Re(1), jf(function(g) {
                    if (g = g.sa) {
                        var h;
                        (h = b) == null || tp(h, g)
                    }
                })),
                f = d.g(O(function(g) {
                    g = g.Sd;
                    return !!g && g.ca().value
                }), Re(1), jf(function(g) {
                    if (g =
                        g.sa) {
                        var h;
                        (h = b) == null || up(h, g)
                    }
                }));
            d = d.g(N(function(g) {
                return g.wi
            }), P(), kf(d.g(N(function(g) {
                return {
                    Oa: g.Oa,
                    sa: g.sa
                }
            }))), O(function(g) {
                g = x(g);
                g.next();
                return !!g.next().value.Oa
            }), N(function(g) {
                g = x(g);
                g.next();
                var h = g.next().value;
                g = h.Oa;
                h = h.sa;
                return {
                    jc: xp(g),
                    sa: h
                }
            }), hf(function(g) {
                return g.jc < 61500
            }, !0), P(function(g, h) {
                return g.jc === h.jc
            }), R({
                jc: 0,
                sa: null
            }), bf(), jf(function(g) {
                var h = x(g);
                g = h.next().value.jc;
                var k = h.next().value;
                h = k.jc;
                if ((k = k.sa) && h) {
                    var l;
                    (l = b) == null || vp(l, k, h - g)
                }
            }));
            return Pd(c,
                e, f, d).g(Pe())
        }
    };

    function zp(a) {
        var b = new Map;
        if (typeof a !== "object" || a === null) return b;
        Object.values(a).forEach(function(c) {
            c && typeof c.ca === "function" && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function Ap(a, b, c) {
        var d = Bp,
            e = Cp;
        c = c === void 0 ? .01 : c;
        return function(f) {
            c > 0 && Math.random() <= c && (a.global.HTMLFencedFrameElement && a.global.fence && typeof a.global.fence.reportEvent === "function" && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                Pf: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                Fh: f.error instanceof Error && f.error.name ?
                    String(f.error.name) : null,
                Dh: String(a.J.hf),
                Eh: f.escapedQueryId
            }), d(Object.assign({}, f, {
                Z: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (h) {
                            return {}
                        }
                    }
                }(),
                qa: [b]
            }), zp(f)).forEach(function(g) {
                a.L.M(g).sendNow()
            }))
        }
    };
    var Dp = K(N(function(a) {
        var b = a.L;
        var c = a.Lh;
        if (b === void 0 || c === void 0) return !1;
        if (a.pe !== void 0) return !0;
        if (c === null) return !1;
        for (a = 0; a < c; a++) b.M("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(Math.random() * 1E7)).sendNow();
        return !0
    }), hf(function(a) {
        return !a
    }), Pe());
    var Ep = K(O(function(a) {
        return !!a.yc
    }), O(function(a) {
        var b = a.shouldSendExplicitDisplayMeasurablePing;
        a = a.pb;
        var c, d;
        return (d = b && ((c = a == null ? void 0 : a.length) != null ? c : 0) > 0) != null ? d : !1
    }), O(function(a) {
        return a.Z !== void 0 && a.pb !== void 0 && a.Gb !== void 0 && a.Qb !== void 0 && a.L !== void 0
    }), N(function(a) {
        return Object.assign({}, a, {
            Ld: zp(a)
        })
    }), N(function(a) {
        a.Gb(Object.assign({}, a, {
            qa: a.pb,
            Z: a.Z,
            Oc: a.Qb,
            Zc: 3,
            Qc: "m"
        }), a.Ld).forEach(function(b) {
            a.L.M(b).sendNow()
        });
        return !0
    }), hf(function(a) {
        return !a
    }), Pe());
    var Cp = function(a) {
        return {
            id: a.Oc,
            mcvt: a.Ic,
            p: a.md,
            asp: a.Xj,
            tm: a.Md,
            tu: a.Nd,
            mtos: a.Jc,
            tos: a.Oa,
            v: a.qh,
            bin: a.ae,
            avms: a.xg,
            bs: a.Ff,
            mc: a.vg,
            "if": a.zh,
            vu: a.Bh,
            app: a.qb,
            mse: a.Oe,
            mtop: a.Pe,
            itpl: a.De,
            adk: a.sa,
            exk: a.Zj,
            rs: a.Xa,
            la: a.rg,
            cr: a.He,
            uach: a.Xc,
            vs: a.Zc,
            r: a.Qc,
            pay: a.Th,
            co: a.sh,
            rst: a.jh,
            rpt: a.ih,
            isd: a.Xh,
            lsd: a.ni,
            context: a.Dh,
            msg: a.errorMessage,
            stack: a.Pf,
            name: a.Fh,
            ec: a.Uh,
            sfr: a.ff,
            met: a.uc,
            wmsd: a.pf,
            pv: a.yk,
            epv: a.bk,
            pbe: a.lg,
            fle: a.Vh,
            vae: a.Wh,
            spb: a.Pg,
            sfl: a.Og,
            ffslot: a.gi,
            reach: a.ej,
            io2: a.Qd,
            rxdbg: a.Dk,
            omida: a.lk,
            omidp: a.tk,
            omidpv: a.uk,
            omidor: a.sk,
            omidv: a.wk,
            omids: a.vk,
            omidam: a.kk,
            omidct: a.mk,
            omidia: a.qk,
            omiddc: a.nk,
            omidlat: a.rk,
            omiddit: a.pk,
            qid: a.Eh
        }
    };

    function Fp() {
        var a = E.apply(0, arguments);
        return function(b) {
            var c = b.g(cf(1), id());
            b = a.map(function(d) {
                return c.g(d, Xe(!0))
            });
            return wd(b).g(Re(1), Pe())
        }
    };

    function Gp() {
        var a = E.apply(0, arguments);
        return function(b) {
            var c = b.g(cf(1), id());
            b = a.map(function(d) {
                return c.g(d, Xe(!0))
            });
            return Pd.apply(null, y(b)).g(Re(1), Pe())
        }
    };

    function Hp() {
        var a = Fp(Ep, Ip),
            b = Jp;
        return function(c) {
            var d = c.g(cf(1), id());
            c = d.g(a, Xe(!0));
            d = d.g(K(b, cf(), id()), Xe(!0));
            c = wd([c, d]);
            return Ud(c, d).g(Re(1), Pe())
        }
    };
    var Jp = function(a) {
        var b = [];
        return a.g(N(function(c) {
            var d = c.L,
                e = c.Mh,
                f = c.Oa,
                g = c.kj,
                h = c.Z,
                k = c.jj,
                l = c.Qg,
                m = c.Gb,
                u = c.Sd,
                t = c.yc,
                r = c.lg,
                w = c.Pg,
                v = c.Og,
                z = c.lf;
            if (!c.Xf || !t || c.Jc === void 0 || f === void 0 || g === void 0 || h === void 0 || k === void 0 || m === void 0 || d === void 0) return !1;
            if (c.sb) {
                if (l === void 0) return !1;
                g = c.bc;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: z != null ? z : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!(r || v || l)) return !1;
            z = zp(c);
            var C;
            u = (C = u == null ? void 0 : u.wa(z).value) != null ? C : !1;
            C = m(Object.assign({},
                c, {
                    Oc: k,
                    Zc: u ? 4 : 3,
                    Qc: l != null ? l : "u",
                    Z: h,
                    qa: g
                }), z);
            if (r) {
                for (; b.length > g.length;) c = void 0, (c = b.shift()) == null || c.deactivate();
                C.forEach(function(T, ma) {
                    ma >= b.length ? b.push(d.M(T)) : b[ma].url = T
                });
                return w && e && l !== void 0 ? (C.forEach(function(T) {
                    e.M(T).sendNow()
                }), !0) : l !== void 0
            }
            if (w && e && l !== void 0) return C.forEach(function(T) {
                e.M(T).sendNow()
            }), !0;
            if (v && e) {
                for (; b.length > g.length;) w = void 0, (w = b.shift()) == null || w.deactivate();
                var Q = m(Object.assign({}, c, {
                        Oc: k,
                        Zc: u ? 4 : 3,
                        Qc: l != null ? l : "u",
                        Z: h,
                        qa: ["https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&lidartos"]
                    }),
                    z)[0];
                C.forEach(function(T, ma) {
                    ma >= b.length ? b.push(d.M(Q, {
                        Of: !0
                    })) : b[ma].url = Q
                });
                return l !== void 0 ? (C.forEach(function(T) {
                    e.M(T).sendNow()
                }), !0) : l !== void 0
            }
            return l !== void 0 ? (C.forEach(function(T) {
                d.M(T).sendNow()
            }), !0) : !1
        }), hf(function(c) {
            return !c
        }), Pe())
    };

    function Kp(a) {
        return function(b) {
            return b.g(N(function(c) {
                a.Eg || xb("Assertion on queued Observable output failed");
                return c
            }))
        }
    };

    function Lp(a) {
        return function(b) {
            return new L(function(c) {
                var d = !1,
                    e = b.g(Kp(a)).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                Ta(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function Mp(a, b) {
        return function(c) {
            return c.g(S(function(d) {
                return new L(function(e) {
                    function f() {
                        h.disconnect();
                        k.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && d.l !== void 0) {
                        var h = new g(function(l) {
                            e.next(l)
                        });
                        h.observe(d.l, b);
                        var k = d.released.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var Np = {
        Vj: 0,
        zj: 1,
        Bj: 2,
        Aj: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function Op(a, b) {
        var c = b.g(Mp(a, {
            attributes: !0
        }), V(a.i, 1));
        return wd([b, c.g(V(a.i, 1), Lp(a.i))]).g(N(function(d) {
            return x(d).next().value
        }), $o("data-google-av-dm"), N(Pp))
    }

    function Pp(a) {
        return a && a in Np ? Number(a) : 2
    };

    function Qp(a) {
        if (a.si === 3) return null;
        if (a.Qg !== void 0) {
            var b = a.yh === !1 ? "n" : null;
            if (b !== null) return b
        }
        return a.rd instanceof ce ? "msf" : a.ge instanceof de ? "c" : a.wh === !1 ? "pv" : a.rd || a.ge ? "x" : null
    }
    var Rp = K(O(function(a) {
        return a.pb !== void 0 && a.Z !== void 0 && a.Gb !== void 0 && a.Qb !== void 0 && a.L !== void 0
    }), O(function(a) {
        return Qp(a) !== null
    }), np(function(a) {
        return a.dd
    }, function(a) {
        return a.Ta
    }), N(function(a) {
        if (a.sb) {
            var b = a.bc;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: (c = a.lf) != null ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = Qp(a);
            if (d === "x") {
                var e, f = (e = a.rd) != null ? e : a.ge;
                f && (b = f.stack, c = f.message)
            }
            a.Gb(Object.assign({}, a, {
                qa: a.pb,
                Z: a.Z,
                Oc: a.Qb,
                Zc: 2,
                Qc: d,
                errorMessage: c,
                Pf: b
            }), zp(a)).forEach(function(g) {
                a.L.M(g).sendNow()
            })
        }
    }), Re(1), Pe());
    var Sp = function() {
            this.startTime = Math.floor(Date.now() / 1E3 - 1704067200);
            this.sequenceNumber = 0
        },
        Tp = function(a) {
            var b = a.sequenceNumber.toString(10).padStart(2, "0");
            b = "" + a.startTime + b;
            a.sequenceNumber < 99 && a.sequenceNumber++;
            return b
        };

    function Up(a, b) {
        return typeof a === "string" ? encodeURIComponent(a) : typeof a === "number" ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return Up(c, b)
        }).join(",") : a instanceof qe ? a.toString() : a && typeof a.ca === "function" ? Up(a.wa(b).value, b) : a === !0 ? "1" : a === !1 ? "0" : a === void 0 || a === null ? null : a instanceof Sp ? Tp(a) : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function Vp(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = x(c);
            c = d.next().value;
            d = d.next().value;
            d = Up(d, b);
            return d === null ? "" : c + "=" + d
        }).filter(function(c) {
            return c !== ""
        });
        return a.length ? a.join("&") : ""
    };
    var Wp = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
        cc = ac(bc(), "google3.javascript.ads.common.url_macros_substitutor", Rb).oi;

    function Xp(a, b) {
        return a.replace(Wp, function(c, d) {
            try {
                var e = b !== null && d in b ? b[d] : void 0;
                if (e == null) return dc("No value supplied for unsupported macro: " + d), c;
                if (e.toString() == null) return dc("The toString method of value returns null for macro: " + d), c;
                e = e.toString();
                if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",");
                dc("Null value supplied for macro: " + d)
            } catch (f) {
                dc("Failed to set macro: " + d)
            }
            return c
        })
    };

    function Yp(a, b) {
        var c = Object.assign({}, a),
            d = a.Xc;
        c = (delete c.Xc, c);
        c = a.Z(c);
        var e = Vp(c, b);
        return Gb(a.qa, function(f) {
            var g = "";
            typeof d === "string" && (g = "&" + Vp({
                uach: d
            }, b));
            var h = {};
            return Xp(f, (h.VIEWABILITY = e, h)) + g
        })
    };

    function Bp(a, b) {
        var c = a.Z(a),
            d = Vp(c, b);
        return d ? Gb(a.qa, function(e) {
            e = e.indexOf("?") >= 0 ? e : e + "?";
            e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
            return e + d
        }) : a.qa
    };

    function Zp(a, b) {
        return Gb(a, function(c) {
            if (typeof b.Xc === "string") {
                var d = "&" + Vp({
                    uach: b.Xc
                }, new Map);
                return c.substring(c.length - 7) == "&adurl=" ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var Ip = K(O(function(a) {
        return a.Z !== void 0 && a.pb !== void 0 && a.Gb !== void 0 && a.Qb !== void 0 && a.L !== void 0
    }), N(function(a) {
        return Object.assign({}, a, {
            Ld: zp(a)
        })
    }), O(function(a) {
        var b = a.Sd;
        var c = a.yc;
        a = a.Ld;
        var d;
        return !!c && ((d = b == null ? void 0 : b.wa(a).value) != null ? d : !1)
    }), np(function(a) {
        return a.ed
    }, function(a) {
        return a.Ta
    }), N(function(a) {
        var b = a.L,
            c = a.lf;
        if (a.sb) {
            var d = a.bc;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: c != null ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.Gb(Object.assign({},
            a, {
                qa: a.pb,
                Z: a.Z,
                Oc: a.Qb,
                Zc: 4,
                Qc: "v"
            }), a.Ld);
        (d = a.ie) && d.length > 0 && a.lc && a.lc(d, a).forEach(function(e) {
            b.M(e).sendNow()
        });
        (d = a.nf) && d.length > 0 && a.lc && a.lc(d, a).forEach(function(e) {
            b.M(e).sendNow()
        });
        c.forEach(function(e) {
            b.M(e, {
                oc: a.Ke
            }).sendNow()
        });
        return !0
    }), hf(function(a) {
        return !a
    }), Pe());

    function $p(a, b, c, d) {
        var e = Object.keys(c).map(function(h) {
                return h
            }),
            f = e.filter(function(h) {
                var k = c[h];
                h = d[h];
                return k instanceof W && h instanceof W && k.value === h.value
            }),
            g = f.reduce(function(h, k) {
                var l = {};
                return Object.assign({}, h, (l[k] = c[k], l))
            }, {});
        return e.reduce(function(h, k) {
            if (f.indexOf(k) >= 0) return h;
            var l = {};
            return Object.assign({}, h, (l[k] = b.g(S(function(m) {
                return (m = m ? c[k] : d[k]) && (m instanceof L || J(m.ub) && J(m.subscribe)) ? m : m.W(a)
            })), l))
        }, g)
    };

    function aq(a) {
        return K(N(function() {
            return !0
        }), R(!1), V(a, 1))
    };

    function bq(a) {
        return a.length <= 0 ? Ac : wd(a.map(function(b) {
            var c = 0;
            return b.g(N(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).g(O(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), N(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function cq(a, b) {
        a.Ga && (a.yb = a.Ga);
        a.Ga = b;
        a.yb && a.yb.value ? (b = Math.max(0, se(b.timestamp, a.yb.timestamp)), a.totalTime += b, a.ua += b) : a.ua = 0;
        return a
    }

    function dq() {
        return K(ef(cq, {
            totalTime: 0,
            ua: 0
        }), N(function(a) {
            return a.totalTime
        }))
    }

    function eq() {
        return K(ef(cq, {
            totalTime: 0,
            ua: 0
        }), N(function(a) {
            return a.ua
        }))
    };

    function fq(a, b) {
        return K($o("data-google-av-metadata"), N(function(c) {
            if (c === null) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            if (c.length === 0) return b(void 0);
            c = c[0].slice(1).join("=");
            return b(c)
        }))
    };
    var gq = {
        vj: "asmreq",
        wj: "asmres"
    };
    var hq = function(a) {
        so.call(this, a)
    };
    q(hq, so);
    hq.prototype.Hg = function(a) {
        en(this, 1, a)
    };
    hq.U = "tagging.common.osd.AdSpeedMetricsRequest";
    hq.prototype.P = uo([0, jo]);
    var iq = function(a) {
        so.call(this, a)
    };
    q(iq, so);
    iq.U = "tagging.common.osd.AdSpeedMetricsResponse.Box";
    var jq = [0, bo, -3];
    iq.prototype.P = uo(jq);
    var kq = function(a) {
        so.call(this, a)
    };
    q(kq, so);
    kq.prototype.Hg = function(a) {
        en(this, 1, a)
    };
    var lq = vo(kq);
    kq.U = "tagging.common.osd.AdSpeedMetricsResponse";
    kq.prototype.P = uo([0, jo, fo, jq, bo, -1]);

    function mq(a, b) {
        var c = c === void 0 ? Qo(a) : c;
        var d = new MessageChannel;
        b = b.g(N(function(f) {
            return Number(f)
        }), O(function(f) {
            return !isNaN(f) && f !== 0
        }), jf(function(f) {
            var g = new hq;
            g.Hg(f);
            f = {
                type: "asmreq",
                payload: g.Ya()
            };
            c.postMessage(f, "*", [d.port2])
        }), Re(1));
        var e = Ro(a, d.port1).g(O(function(f) {
                return typeof f.data === "object"
            }), N(function(f) {
                var g = f.data,
                    h = Object.values(gq).includes(g.type);
                g = typeof g.payload === "string";
                if (!h || !g || f.data.type !== "asmres") return null;
                try {
                    return lq(f.data.payload)
                } catch (k) {
                    return null
                }
            }),
            O(function(f) {
                return f !== null
            }), N(function(f) {
                return f
            }));
        return b.g(S(function(f) {
            return Zc(f).g(Ne(e))
        }), O(function(f) {
            var g = x(f);
            f = g.next().value;
            g = g.next().value;
            if (nl(Gm(g, 1)) != null) {
                var h = h === void 0 ? 0 : h;
                var k;
                g = ((k = nl(Gm(g, 1))) != null ? k : h) === f
            } else g = !1;
            return g
        }), N(function(f) {
            f = x(f);
            f.next();
            return f.next().value
        }), Lh(a.i))
    };

    function nq(a, b, c) {
        var d = b.Fc.g(Re(1), S(function() {
            return mq(a, c)
        }), O(function(f) {
            return an(f, 2) && Km(f, iq, 3) && ll(Gm(f, 4)) != null && ll(Gm(f, 5)) != null
        }), Re(1), Lh(a.i));
        b = d.g(N(function(f) {
            var g = Xm(f, iq, 3);
            g = bn(g, 2);
            f = Xm(f, iq, 3);
            f = bn(f, 1);
            return {
                x: g,
                y: f
            }
        }), P(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), V(a.i, 1));
        var e = d.g(N(function(f) {
            return bn(f, 4)
        }), V(a.i, 1));
        d = d.g(N(function(f) {
            return bn(f, 5)
        }), V(a.i, 1));
        return {
            Xh: e,
            mh: b,
            ni: d
        }
    };

    function oq(a, b) {
        return b.Fc.g(Re(1), N(function() {
            return a.m.now().round()
        }))
    };
    var pq = N(function(a) {
        return [a.value.aa.width, a.value.aa.height]
    });

    function qq(a, b) {
        return function(c) {
            return bq(b.map(function(d) {
                return c.g(a(d))
            }))
        }
    };

    function rq() {
        var a;
        return K(jf(function(b) {
            return void(a = b.timestamp)
        }), eq(), N(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };
    var sq = function(a, b) {
            this.Hf = a;
            this.options = b;
            this.Fe = this.Ee = null
        },
        tq = function(a, b) {
            b ? a.Fe || (b = Object.assign({}, a.options, {
                delay: 100,
                trackVisibility: !0
            }), a.Fe = new IntersectionObserver(a.Hf, b)) : a.Ee || (a.Ee = new IntersectionObserver(a.Hf, a.options))
        },
        uq = function(a, b) {
            a = b ? a.Fe : a.Ee;
            if (!a) throw new fe;
            return a
        };
    sq.prototype.observe = function(a, b) {
        uq(this, a).observe(b)
    };
    sq.prototype.unobserve = function(a, b) {
        uq(this, a).unobserve(b)
    };
    sq.prototype.disconnect = function(a) {
        uq(this, a).disconnect()
    };
    sq.prototype.takeRecords = function(a) {
        return uq(this, a).takeRecords()
    };
    var vq = {
        ja: "ns",
        ma: vi,
        aa: vi,
        ha: new xc,
        X: "ns",
        N: vi,
        Y: vi,
        ra: {
            x: 0,
            y: 0
        }
    };

    function wq(a, b) {
        return wi(a.aa, b.aa) && wi(a.N, b.N) && wi(a.ma, b.ma) && wi(a.Y, b.Y) && a.X === b.X && a.ha === b.ha && a.ja === b.ja && a.ra.x === b.ra.x && a.ra.y === b.ra.y
    };

    function xq(a, b) {
        return function(c) {
            return function(d) {
                var e = d.g(af(new xc), id());
                d = c.element.g(P());
                e = e.g(N(function(f) {
                    return f.value
                }));
                return wd([d, e, b]).g(N(function(f) {
                    var g = x(f);
                    f = g.next().value;
                    var h = g.next().value;
                    g = g.next().value;
                    if (f.l === void 0) var k = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        k = f.l.getBoundingClientRect();
                        var l = f.l,
                            m = a.global,
                            u = new uh(0, 0);
                        var t = (t = xh(l)) ? t.defaultView : window;
                        if (Ig(t, "parent")) {
                            do {
                                if (t == m) {
                                    var r = l,
                                        w = xh(r);
                                    Cb(r, "Parameter is required");
                                    var v = new uh(0, 0);
                                    var z =
                                        (w ? xh(w) : document).documentElement;
                                    r != z && (r = Dh(r), w = yh(w), w = zh(w.xc), v.x = r.left + w.x, v.y = r.top + w.y)
                                } else v = F(l), v = Dh(v), v = new uh(v.left, v.top);
                                u.x += v.x;
                                u.y += v.y
                            } while (t && t != m && t != t.parent && (l = t.frameElement) && (t = t.parent))
                        }
                        k = {
                            top: u.y,
                            left: u.x,
                            width: k.width,
                            height: k.height
                        }
                    }
                    k = yi(k, h.ra);
                    m = xi(k, h.ma);
                    u = a.m.now();
                    t = Object;
                    l = t.assign;
                    if (g !== 2 || a.rb || m.width <= 0 || m.height <= 0) var C = !1;
                    else try {
                        var Q = a.document.elementFromPoint(m.left + m.width / 2, m.top + m.height / 2);
                        C = Q ? !yq(Q, f) : !1
                    } catch (T) {
                        C = !1
                    }
                    return {
                        timestamp: u,
                        value: l.call(t, {}, h, {
                            X: "geo",
                            Y: C ? vq.Y : m,
                            N: k
                        })
                    }
                }), Lh(a.i))
            }
        }
    }

    function yq(a, b, c) {
        c = c === void 0 ? 0 : c;
        return a.l === void 0 || b.l === void 0 ? !1 : a.l === b.l || Bh(b.l, function(d) {
            return d === a.l
        }) ? !0 : b.l.ownerDocument && b.l.ownerDocument.defaultView && b.l.ownerDocument.defaultView === b.l.ownerDocument.defaultView.top ? !1 : c < 10 && b.l.ownerDocument && b.l.ownerDocument.defaultView && b.l.ownerDocument.defaultView.frameElement ? yq(a, new Zh(b.l.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function zq(a) {
        return function(b) {
            return b.g(a.ResizeObserver ? Aq(a) : Bq(a), cf(1), id())
        }
    }

    function Aq(a) {
        return function(b) {
            return b.g(S(function(c) {
                var d = a.ResizeObserver;
                if (!d || c.l === void 0) return Zc(vq.N);
                var e = (new L(function(f) {
                    function g() {
                        c.l !== void 0 && h.unobserve(c.l);
                        h.disconnect();
                        k.unsubscribe()
                    }
                    if (c.l === void 0) return f.complete(),
                        function() {};
                    var h = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    h.observe(c.l);
                    var k = c.released.subscribe(g);
                    return g
                })).g(qg(a.J, 736), N(function(f) {
                    return f.contentRect
                }));
                return Pd(Zc(c.l.getBoundingClientRect()), e)
            }), P(wi))
        }
    }

    function Bq(a) {
        return function(b) {
            var c = b.g(Mp(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.Gi;
            c = Pd(b.g(N(function() {
                return Yh("resize")
            })), c, d);
            return wd(b, c).g(qg(a.J, 737), N(function(e) {
                e = x(e).next().value;
                return e.l === void 0 ? void 0 : e.l.getBoundingClientRect()
            }), hp(), P(wi))
        }
    };

    function Cq(a, b) {
        var c = Dq(a, b).g(cf(1), id());
        return function(d) {
            return function(e) {
                e = e.g(S(function(f) {
                    return f.element
                }), P());
                return wd([c, e]).g(S(function(f) {
                    var g = x(f);
                    f = g.next().value;
                    g = g.next().value;
                    return Eq(a, f.ei, zq(a), f.Ei, d, f.Nh, g)
                }), Lh(a.i))
            }
        }
    }

    function Fq(a, b, c) {
        var d = Cq(a, c)(b);
        return function(e) {
            var f = d(Zc(e));
            return function(g) {
                return wd([g, f]).g(N(function(h) {
                    var k = x(h);
                    h = k.next().value;
                    k = k.next().value;
                    var l = yi(k.value.N, h.value.ra),
                        m = xi(yi(k.value.Y, h.value.ra), h.value.ma);
                    return {
                        timestamp: h.timestamp.maximum(k.timestamp),
                        value: Object.assign({}, h.value, {
                            X: "nio",
                            Y: m,
                            N: l
                        })
                    }
                }))
            }
        }
    }

    function Gq(a) {
        return N(function(b) {
            return b.value.ja !== "nio" ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    ma: So(a, !0),
                    aa: So(a, !0)
                })
            })
        })
    }

    function Hq(a, b) {
        return Zc(b).g(a, N(function() {
            return b
        }))
    }

    function Dq(a, b) {
        return a.m.timeline !== oe ? $c(new ce(2)) : a.MutationObserver ? typeof IntersectionObserver === "undefined" ? $c(new ce(0)) : (new L(function(c) {
            var d = new xc,
                e = new sq(d.next.bind(d), {
                    threshold: [].concat(y(b))
                });
            c.next({
                Ei: d.g(qg(a.J, 735)),
                ei: e,
                Nh: function(f) {
                    f = e.takeRecords(f);
                    f.length > 0 && d.next(f)
                }
            })
        })).g(Re(1), cf(1), id()) : $c(new ce(1))
    }

    function Iq(a) {
        return Nc(a.sort(function(b, c) {
            return b.time - c.time
        }), md)
    }

    function Eq(a, b, c, d, e, f, g) {
        return new L(function(h) {
            function k() {
                w || (w = !0, g.l !== void 0 && b.unobserve(e, g.l), m.unsubscribe(), r.unsubscribe(), t.unsubscribe(), v.unsubscribe())
            }
            if (g.l !== void 0) {
                tq(b, e);
                b.observe(e, g.l);
                var l = new zc({
                        timestamp: a.m.now(),
                        value: Object.assign({}, vq, {
                            ja: "nio",
                            X: "nio"
                        })
                    }),
                    m = d.g(Bd(function(z) {
                        return Iq(z)
                    }), O(function(z) {
                        return z.target === g.l
                    }), N(function(z) {
                        return {
                            timestamp: new qe(z.time, oe),
                            value: {
                                ja: "nio",
                                ma: z.rootBounds || vi,
                                aa: z.rootBounds || So(a, !0),
                                ha: u,
                                X: "nio",
                                Y: z.intersectionRect,
                                N: z.boundingClientRect,
                                ra: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: z.isIntersecting,
                                ug: z.isVisible
                            }
                        }
                    }), af(l), id()).subscribe(h),
                    u = new xc,
                    t = u.subscribe(function() {
                        f(e);
                        h.next({
                            timestamp: a.m.now(),
                            value: l.value.value
                        });
                        g.l !== void 0 && (b.unobserve(e, g.l), b.observe(e, g.l))
                    }),
                    r = Hq(c, g).subscribe(function() {
                        u.next()
                    }),
                    w = !1,
                    v = g.released.subscribe(function() {
                        return k()
                    });
                return k
            }
        })
    };

    function Jq(a, b) {
        var c = a.ve().g(N(function() {
            return "b"
        }));
        return Ud(b, c).g(Re(1), V(a.i, 1))
    };

    function Kq(a) {
        return function(b) {
            var c;
            return b.g(jf(function(d) {
                return void(c = d.timestamp)
            }), N(function(d) {
                return d.value
            }), a, N(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };

    function Lq(a) {
        return a.Y.width * a.Y.height / (a.N.width * a.N.height)
    }
    var Mq = Kq(K(N(function(a) {
            var b;
            return (b = a.qd) != null ? b : Lq(a)
        }), N(function(a) {
            return isFinite(a) ? a : 0
        }))),
        Nq = Kq(K(N(function(a) {
            var b;
            return (b = a.qd) != null ? b : Lq(a)
        }), N(function(a) {
            return isFinite(a) ? a : -1
        })));
    var Oq = function(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    };
    Oq.prototype.ba = function(a) {
        return a instanceof Oq ? this.a.ba(a.a) && this.b.ba(a.b) : !1
    };
    Oq.prototype.va = function(a) {
        var b = this.a.va(a).value,
            c = this.b.va(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    da.Object.defineProperties(Oq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        H: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.H.timestamp.maximum(this.b.H.timestamp),
                    b = this.a.H.timestamp.equals(a) ? this.a.H.value : this.a.va(a).value,
                    c = this.b.H.timestamp.equals(a) ? this.b.H.value : this.b.va(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });
    var Pq = function(a, b) {
        this.input = a;
        this.Cd = b;
        this.H = {
            timestamp: this.input.H.timestamp,
            value: this.Cd(this.input.H.value)
        }
    };
    Pq.prototype.ba = function(a) {
        return a instanceof Pq ? this.input.ba(a.input) && this.Cd === a.Cd : !1
    };
    Pq.prototype.va = function(a) {
        a = this.input.va(a);
        return {
            timestamp: a.timestamp,
            value: this.Cd(a.value)
        }
    };
    da.Object.defineProperties(Pq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function Qq(a, b, c) {
        c = c === void 0 ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };
    var Rq = function(a, b, c) {
        this.clock = a;
        this.H = b;
        this.active = c
    };
    Rq.prototype.ba = function(a) {
        return a instanceof Rq ? this.active === a.active && this.clock.timeline === a.clock.timeline && Qq(this.H, a.H) : !1
    };
    Rq.prototype.va = function(a) {
        return {
            timestamp: a,
            value: this.H.value + (this.active ? Math.max(0, se(a, this.H.timestamp)) : 0)
        }
    };
    var Sq = function() {};
    Sq.prototype.ca = function() {
        return this.va(this.clock.now())
    };
    Sq.prototype.wa = function(a) {
        var b = this.clock.timeline,
            c, d = (c = a.get(b)) != null ? c : this.clock.now();
        a.set(b, d);
        return this.va(d)
    };
    Sq.prototype.map = function(a) {
        return new Tq(this, a)
    };
    Sq.prototype.xa = function(a) {
        return new Uq(this, a)
    };
    var Uq = function() {
        Oq.apply(this, arguments);
        this.map = Sq.prototype.map;
        this.xa = Sq.prototype.xa;
        this.ca = Sq.prototype.ca;
        this.wa = Sq.prototype.wa
    };
    q(Uq, Oq);
    var Vq = function() {
        Rq.apply(this, arguments);
        this.map = Sq.prototype.map;
        this.xa = Sq.prototype.xa;
        this.ca = Sq.prototype.ca;
        this.wa = Sq.prototype.wa
    };
    q(Vq, Rq);
    var Tq = function() {
        Pq.apply(this, arguments);
        this.map = Sq.prototype.map;
        this.xa = Sq.prototype.xa;
        this.ca = Sq.prototype.ca;
        this.wa = Sq.prototype.wa
    };
    q(Tq, Pq);

    function Wq(a, b) {
        a.Ga && (a.yb = a.Ga);
        a.Ga = b;
        a.yb && a.yb.value ? (b = Math.max(0, se(b.timestamp, a.yb.timestamp)), a.totalTime += b, a.ua += b) : a.ua = 0;
        return a
    }

    function Xq(a) {
        return K(ef(Wq, {
            totalTime: 0,
            ua: 0
        }), N(function(b) {
            return new Vq(a, {
                timestamp: b.Ga.timestamp,
                value: b.totalTime
            }, b.Ga.value)
        }))
    }

    function Yq(a) {
        return K(ef(Wq, {
            totalTime: 0,
            ua: 0
        }), N(function(b) {
            return new Vq(a, {
                timestamp: b.Ga.timestamp,
                value: b.ua
            }, b.Ga.value)
        }))
    };

    function Zq(a) {
        return K(Yq(a), N(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };
    var $q = function(a, b) {
        this.H = b;
        this.ca = Sq.prototype.ca;
        this.wa = Sq.prototype.wa;
        this.map = Sq.prototype.map;
        this.xa = Sq.prototype.xa;
        this.clock = a
    };
    $q.prototype.ba = function(a) {
        return a.active
    };
    $q.prototype.va = function() {
        return this.H
    };
    da.Object.defineProperties($q.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function ar(a, b) {
        return b.g(N(function(c) {
            return new $q(a.m, {
                timestamp: a.m.now(),
                value: c
            })
        }))
    };

    function br(a, b) {
        return a >= 1 ? !0 : a <= 0 ? !1 : a >= b
    };

    function cr(a) {
        return function(b) {
            return b.g(kf(a), N(function(c) {
                var d = x(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: br(c.value, d)
                }
            }))
        }
    };
    var dr = N(function(a) {
        if (a.value.ja === "omid") {
            if (a.value.X === "nio") return "omio";
            if (a.value.X === "geo") return "omgeo"
        }
        return a.value.X === "geo" || a.value.X === "nio" ? a.value.ja : a.value.X
    });

    function er() {
        return K(O(function(a, b) {
            return b > 0
        }), fr, R(-1), P())
    }
    var fr = K(O(function(a) {
        return !isNaN(a)
    }), ef(function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), P());
    var gr = Kq(K(N(function(a) {
        return a.Y.width * a.Y.height / (a.ma.width * a.ma.height)
    }), N(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function hr(a, b, c) {
        return a ? wd([b, c]).g(O(function(d) {
            var e = x(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), N(function(d) {
            var e = x(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function ir(a) {
        return function(b) {
            var c = b.g(Mq),
                d = b.g(gr);
            return a instanceof L ? a.g(S(function(e) {
                return hr(e, c, d)
            })) : hr(a.value, c, d)
        }
    };
    var jr = K(Kq(N(function(a) {
        a = a.qd ? a.N.width * a.N.height * a.qd / (a.aa.width * a.aa.height) : a.Y.width * a.Y.height / (a.aa.width * a.aa.height);
        return isFinite(a) ? a : 0
    })));

    function kr(a, b, c, d) {
        var e = d.sd,
            f = d.qe,
            g = d.Xg,
            h = d.Cf,
            k = d.Le,
            l = d.wg,
            m = d.vd;
        d = d.Ug;
        b = lr(a, c, b);
        c = mr(a, c);
        d = nr(b, d);
        var u = or(a, e, l, b),
            t = u.g(N(function(D) {
                return D.value
            }), P(), V(a, 1), ef(function(D, fa) {
                return Math.max(D, fa)
            }, 0)),
            r = u.g(N(function(D) {
                return D.value
            }), er(), V(a, 1)),
            w = b.g(Nq, N(function(D) {
                return D.value
            }), Re(2), P(), V(a, 1));
        g = pr(a, b, g, h);
        var v = g.g(R(!1), P(), N(function(D) {
            return D ? k : f
        }));
        h = u.g(cr(v), P(), V(a, 1));
        var z = wd([h, b]).g(O(function(D) {
            var fa = x(D);
            D = fa.next().value;
            fa = fa.next().value;
            return D.timestamp.equals(fa.timestamp)
        }), N(function(D) {
            var fa = x(D);
            D = fa.next().value;
            fa = fa.next().value;
            return {
                visible: D.value,
                geometry: fa.value.N
            }
        }), ef(function(D, fa) {
            return !fa.visible && D.visible ? D : fa
        }, {
            visible: !1,
            geometry: vi
        }), N(function(D) {
            return D.geometry
        }), R(vi), V(a, 1), P(wi));
        l = l instanceof L ? l.g(P(), Qe()) : Qd;
        v = wd([l, v]).g(Qe());
        var C = b.g(O(function(D) {
                return D.value.ja !== "ns" && D.value.X !== "ns"
            }), ef(function(D) {
                return D + 1
            }, 0), R(0), V(a, 1)),
            Q = c.g(Qe(!0), R(!1), V(a, 1));
        Q = wd([m, Q]).g(N(function(D) {
            var fa =
                x(D);
            D = fa.next().value;
            fa = fa.next().value;
            return D && !fa
        }), V(a, 1));
        var T = b.g(jr, P()),
            ma = T.g(N(function(D) {
                return D.value
            }), ef(function(D, fa) {
                return Math.max(D, fa)
            }, 0), P(), V(a, 1)),
            H = T.g(N(function(D) {
                return D.value
            }), er(), V(a, 1));
        return {
            df: l,
            Vc: v,
            Aa: {
                Ni: b,
                xg: b.g(dr),
                md: z.g(P(wi)),
                visible: h.g(P(Qq)),
                jf: u.g(P(Qq)),
                vg: t,
                yi: r,
                Ff: b.g(pq, P(Kb)),
                mj: T,
                pi: ma,
                xi: H,
                rd: c,
                ha: (new W(new xc)).W(a),
                rg: g,
                sd: e,
                vd: m,
                Xf: Q,
                nj: C,
                mi: w,
                Qd: d
            }
        }
    }

    function mr(a, b) {
        return b.g(O(function() {
            return !1
        }), N(function(c) {
            return c
        }), Ke(function(c) {
            return (new W(c)).W(a)
        }))
    }

    function nr(a, b) {
        a = wd([a, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.ug
        }), P());
        var c = a.g(N(function(e) {
                return e === void 0 ? !0 : e
            }), ef(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(ef(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), N(function(e) {
                return !!e
            }));
        return wd([b, Wd(a, c, d)]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            var g = x(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    }

    function lr(a, b, c) {
        return b.g(Td(Qd), V(a, 1)).g(P(function(d, e) {
            return Qq(d, e, wq)
        }), R({
            timestamp: c.now(),
            value: vq
        }), V(a, 1))
    }

    function or(a, b, c, d) {
        c = d.g(ir(c), Kq(N(function(e) {
            return Math.round(e * 100) / 100
        })), V(a, 1));
        return b instanceof W ? c : wd([c, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), P(Qq), V(a, 10))
    }

    function pr(a, b, c, d) {
        b = [b.g(N(function(e) {
            return e.value.N.width * e.value.N.height >= 242500
        }))];
        c instanceof L && b.push(c.g(N(function(e) {
            return !!e
        })));
        c = wd(b);
        return d ? c.g(N(function(e) {
            return e.some(function(f) {
                return f
            })
        }), R(!1), P(), V(a, 1)) : (new W(!1)).W(a)
    };
    var qr = function(a) {
            this.m = a;
            this.Kd = null;
            this.timeout = new xc
        },
        sr = function(a, b) {
            rr(a);
            a.Kd = a.m.setTimeout(function() {
                return void a.timeout.next()
            }, b)
        },
        rr = function(a) {
            a.Kd !== null && (a.m.clearTimeout(a.Kd), a.Kd = null)
        };

    function tr(a, b, c, d) {
        var e = ur.Rg,
            f = new qr(b);
        c = c.g(R(void 0), S(function() {
            rr(f);
            return d
        })).g(N(function(g) {
            rr(f);
            var h = g.H,
                k = g.active;
            h.value >= e || !k || (k = b.now(), k = Math.max(0, se(k, h.timestamp)), sr(f, Math.max(0, e - h.value - k)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return wd([c, Pd(f.timeout, Zc(void 0))]).g(N(function(g) {
            return x(g).next().value
        }), hf(function(g) {
            return !g.ca().value
        }, !0), V(a, 1))
    };

    function vr(a) {
        var b = new Vq(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return K(Yq(a), ef(function(c, d) {
            return c.H.value > d.H.value ? new Vq(a, c.H, !1) : d
        }, b), N(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function wr(a) {
        return function(b) {
            return K(cr(Zc(b)), vr(a))
        }
    };

    function xr(a) {
        return function(b) {
            return K(Kq(N(function(c) {
                return br(c, b)
            })), Xq(a), N(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function yr(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.xa(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function zr(a, b) {
        return a.xa(b).map(function(c) {
            var d = x(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function Ar(a, b, c, d, e, f) {
        var g = Br;
        if (g.length > 1)
            for (var h = 0; h < g.length - 1; h++)
                if (g[h] < g[h + 1]) throw Error();
        h = f.g(R(void 0), S(function() {
            return d.g(Zq(a))
        }), P(function(k, l) {
            return k.ba(l)
        }), V(b, 1));
        f = f.g(R(void 0), S(function() {
            return d.g(vr(a))
        }), P(function(k, l) {
            return k.ba(l)
        }), V(b, 1));
        return {
            Md: e.g(R(void 0), S(function() {
                return c.g(N(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: !0
                    }
                }), Xq(a))
            }), P(function(k, l) {
                return k.ba(l)
            }), V(b, 1)),
            Nd: e.g(R(void 0), S(function() {
                return c.g(N(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: k.value === 0
                    }
                }), Xq(a))
            }), P(function(k, l) {
                return k.ba(l)
            }), V(b, 1)),
            Jc: e.g(R(void 0), S(function() {
                return c.g(qq(wr(a), g))
            }), N(yr), P(function(k, l) {
                return k.ba(l)
            }), V(b, 1)),
            Oa: e.g(R(void 0), S(function() {
                return c.g(qq(xr(a), g), N(function(k) {
                    return k.map(function(l, m) {
                        return m > 0 ? zr(l, k[m - 1]) : l
                    })
                }))
            }), N(yr), P(function(k, l) {
                return k.ba(l)
            }), V(b, 1)),
            Ic: f,
            hb: h.g(P(function(k, l) {
                return k.ba(l)
            }), V(b, 1))
        }
    };

    function Cr(a) {
        var b;
        if (b = Dr(a)) b = !Er(a, "abgcp") && !Er(a, "abgc") && !(typeof a.id === "string" && a.id === "abgb") && !(typeof a.id === "string" && a.id === "mys-abgc") && !Er(a, "cbb");
        return b
    }

    function Er(a, b) {
        return a.classList ? a.classList.contains(b) : (" " + a.className + " ").indexOf(" " + b + " ") > -1
    }

    function Dr(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && b.height >= 30 && b.width >= 30
        } catch (c) {
            return !1
        }
    }

    function Fr(a, b) {
        if (a.l === void 0 || !a.l.children) return a;
        for (var c = Jb(a.l.children); c.length;) {
            var d = b ? c.filter(Cr) : c.filter(Dr);
            if (d.length === 1) return new Zh(d[0]);
            if (d.length > 1) break;
            c = Mb(c, function(e) {
                return Jb(e.children)
            })
        }
        return a
    }

    function Gr(a, b, c, d, e) {
        if (c) return {
            ld: b,
            zb: Zc(null)
        };
        c = b.element.g(N(function(f) {
            a: if (f.l === void 0 || Dr(f.l)) f = {
                    Dd: f,
                    zb: "mue"
                };
                else {
                    var g = Fr(f, e);
                    if (g.l !== void 0 && Dr(g.l)) f = {
                        Dd: g,
                        zb: "ie"
                    };
                    else {
                        if (d || a.Be)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    Dd: new Zh(g),
                                    zb: "ce"
                                };
                                break a
                            }
                        f = {
                            Dd: f,
                            zb: "mue"
                        }
                    }
                }return f
        }), ff());
        return {
            ld: {
                Eb: b.Eb,
                element: c.g(N(function(f) {
                    return f.Dd
                }))
            },
            zb: c.g(N(function(f) {
                return f.zb
            }))
        }
    };

    function Hr(a, b, c, d) {
        var e = d.sd,
            f = d.qe,
            g = d.Xg,
            h = d.Cf,
            k = d.Le,
            l = d.wg,
            m = d.vd;
        d = d.Ug;
        b = Ir(a, c, b);
        c = Jr(a, c);
        d = Kr(b, d);
        var u = Lr(a, e, l, b),
            t = u.g(N(function(H) {
                return H.value
            }), P(), V(a, 1), ef(function(H, D) {
                return Math.max(H, D)
            }, 0)),
            r = u.g(N(function(H) {
                return H.value
            }), er(), V(a, 1)),
            w = b.g(Nq, N(function(H) {
                return H.value
            }), Re(2), P(), V(a, 1));
        g = Mr(a, b, g, h);
        var v = g.g(R(!1), P(), N(function(H) {
            return H ? k : f
        }));
        h = u.g(cr(v), P(), V(a, 1));
        var z = wd([h, b]).g(O(function(H) {
                var D = x(H);
                H = D.next().value;
                D = D.next().value;
                return H.timestamp.equals(D.timestamp)
            }),
            N(function(H) {
                var D = x(H);
                H = D.next().value;
                D = D.next().value;
                return {
                    visible: H.value,
                    geometry: D.value.N
                }
            }), ef(function(H, D) {
                return !D.visible && H.visible ? H : D
            }, {
                visible: !1,
                geometry: vi
            }), N(function(H) {
                return H.geometry
            }), R(vi), V(a, 1), P(wi));
        l = l instanceof L ? l.g(P(), Qe()) : Qd;
        v = wd([l, v]).g(Qe());
        var C = b.g(O(function(H) {
                return H.value.ja !== "ns" && H.value.X !== "ns"
            }), ef(function(H) {
                return H + 1
            }, 0), R(0), V(a, 1)),
            Q = c.g(Qe(!0), R(!1), V(a, 1));
        Q = wd([m, Q]).g(N(function(H) {
            var D = x(H);
            H = D.next().value;
            D = D.next().value;
            return H &&
                !D
        }), V(a, 1));
        var T = b.g(jr, P()),
            ma = T.g(N(function(H) {
                return H.value
            }), ef(function(H, D) {
                return Math.max(H, D)
            }, 0), P(), V(a, 1));
        a = T.g(N(function(H) {
            return H.value
        }), er(), V(a, 1));
        return {
            df: l,
            Vc: v,
            Aa: {
                Ni: b,
                xg: b.g(dr),
                md: z.g(P(wi)),
                visible: h.g(P(Qq)),
                jf: u.g(P(Qq)),
                vg: t,
                yi: r,
                Ff: b.g(pq, P(Kb)),
                mj: T,
                pi: ma,
                xi: a,
                rd: c,
                ha: b.g(N(function(H) {
                    return H.value.ha
                })),
                rg: g,
                sd: e,
                vd: m,
                Xf: Q,
                nj: C,
                mi: w,
                Qd: d
            }
        }
    }

    function Jr(a, b) {
        return b.g(O(function() {
            return !1
        }), N(function(c) {
            return c
        }), Ke(function(c) {
            return (new W(c)).W(a)
        }))
    }

    function Ir(a, b, c) {
        return b.g(Td(Qd), V(a, 1)).g(P(function(d, e) {
            return Qq(d, e, wq)
        }), R({
            timestamp: c.now(),
            value: vq
        }), V(a, 1))
    }

    function Lr(a, b, c, d) {
        c = d.g(ir(c), Kq(N(function(e) {
            return Math.round(e * 100) / 100
        })), V(a, 1));
        return b instanceof W ? c : wd([c, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), P(Qq), V(a, 1))
    }

    function Mr(a, b, c, d) {
        b = [b.g(N(function(e) {
            return e.value.N.width * e.value.N.height >= 242500
        }))];
        c instanceof L && b.push(c.g(N(function(e) {
            return !!e
        })));
        c = wd(b);
        return d ? c.g(N(function(e) {
            return e.some(function(f) {
                return f
            })
        }), R(!1), P(), V(a, 1)) : (new W(!1)).W(a)
    }

    function Kr(a, b) {
        a = wd([a, b]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.ug
        }), P());
        var c = a.g(N(function(e) {
                return e === void 0 ? !0 : e
            }), ef(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(ef(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), N(function(e) {
                return !!e
            }));
        return wd([b, Wd(a, c, d)]).g(N(function(e) {
            var f = x(e);
            e = f.next().value;
            var g = x(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    };
    var Nr = K($o("data-google-av-itpl"), N(function(a) {
        return Number(a)
    }), N(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var Or = {
            uj: "addEventListener",
            Ej: "getMaxSize",
            Fj: "getScreenSize",
            Gj: "getState",
            Hj: "getVersion",
            Sj: "removeEventListener",
            Nj: "isViewable"
        },
        Pr = function(a, b) {
            this.ya = null;
            this.ci = new xc;
            b = b || this.oj;
            var c = a.Be,
                d = !a.rb;
            if (c && d) {
                var e = a.global.top.mraid;
                if (e) {
                    this.kd = b(e);
                    this.ya = e;
                    this.Db = 3;
                    return
                }
            }(a = a.global.mraid) ? (this.kd = b(a), this.ya = a, this.Db = c ? d ? 2 : 1 : 0) : (this.Db = -1, this.kd = 2)
        };
    Pr.prototype.addEventListener = function(a, b) {
        return this.cc("addEventListener", a, b)
    };
    Pr.prototype.removeEventListener = function(a, b) {
        return this.cc("removeEventListener", a, b)
    };
    Pr.prototype.dg = function() {
        var a = this.cc("getVersion");
        return typeof a === "string" ? a : ""
    };
    Pr.prototype.getState = function() {
        var a = this.cc("getState");
        return typeof a === "string" ? a : ""
    };
    var Qr = function(a) {
            a = a.cc("isViewable");
            return typeof a === "boolean" ? a : !1
        },
        Rr = function(a) {
            if (a.ya) return a = a.ya.AFMA_LIDAR, typeof a === "string" ? a : void 0
        };
    Pr.prototype.oj = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(Or).every(function(b) {
            return typeof a[b] === "function"
        }) ? 0 : 1 : 2 : 1
    };
    Pr.prototype.cc = function(a) {
        var b = E.apply(1, arguments);
        if (this.ya) try {
            return this.ya[a].apply(this.ya, y(b))
        } catch (c) {
            this.ci.next(a)
        }
    };
    da.Object.defineProperties(Pr.prototype, {
        Nf: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.ya) {
                    var a = this.ya.AFMA_LIDAR_EXP_1;
                    return a === void 0 ? void 0 : !!a
                }
            },
            set: function(a) {
                this.ya && (this.ya.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function Sr(a, b) {
        return (new Pr(a)).Db !== -1 ? (new W(!0)).W(a.i) : b.g($o("data-google-av-inapp"), N(function(c) {
            return c !== null
        }), V(a.i, 1))
    };
    var Ur = function(a, b) {
            var c = this;
            this.m = a;
            this.Ne = this.Ad = null;
            this.Ri = b.g(P()).subscribe(function(d) {
                Tr(c);
                c.Ne = d
            })
        },
        Vr = function(a, b) {
            Tr(a);
            a.Ad = a.m.setTimeout(function() {
                var c;
                return void((c = a.Ne) == null ? void 0 : c.next())
            }, b)
        },
        Tr = function(a) {
            a.Ad !== null && a.m.clearTimeout(a.Ad);
            a.Ad = null
        };
    Ur.prototype.dispose = function() {
        Tr(this);
        this.Ri.unsubscribe();
        this.Ne = null
    };

    function Wr(a, b, c, d, e) {
        var f = ur.Rg;
        var g = g === void 0 ? new Ur(b, d) : g;
        return (new L(function(h) {
            var k = c.g(R(void 0), S(function() {
                return Xr(e)
            })).g(N(function(l) {
                var m = l.value;
                l = l.timestamp;
                var u = m.visible;
                m = m.hb;
                var t = m >= f;
                t || !u ? Tr(g) : (l = Math.max(0, se(b.now(), l)), Vr(g, Math.max(0, f - m - l)));
                return t
            }), ef(function(l, m) {
                return m || l
            }, !1), P()).subscribe(h);
            return function() {
                g.dispose();
                k.unsubscribe()
            }
        })).g(hf(function(h) {
            return !h
        }, !0), V(a, 1))
    }

    function Xr(a) {
        return bq([a, a.g(rq())]).g(N(function(b) {
            var c = x(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    hb: c.value
                }
            }
        }), P(function(b, c) {
            return Qq(b, c, function(d, e) {
                return d.hb === e.hb && d.visible === e.visible
            })
        }))
    };

    function Yr(a, b) {
        return {
            sa: b.g($o("data-google-av-adk")),
            sc: b.g($o("data-google-av-btr"), P(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            ie: b.g($o("data-google-av-cpmav"), P(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            nf: b.g($o("data-google-av-vrus"), P(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Ah: Op(a, b),
            flags: b.g($o("data-google-av-flags"), P()),
            qb: Sr(a, b),
            He: b.g(fq("cr", function(c) {
                return c ===
                    "1"
            }), P()),
            hi: b.g(fq("omid", function(c) {
                return c === "1"
            }), P()),
            De: b.g(Nr),
            metadata: b.g($o("data-google-av-metadata")),
            Xa: b.g(gp),
            qa: b.g(ap),
            sj: b.g(fq("la", function(c) {
                return c === "1"
            }), P()),
            sb: b.g($o("data-google-av-turtlex"), N(function(c) {
                return c !== null
            }), P()),
            Ke: b.g($o("data-google-av-vattr"), N(function(c) {
                return c !== null
            }), P())
        }
    };

    function Zr() {
        return K(eq(), ef(function(a, b) {
            return Math.max(a, b)
        }, 0), N(function(a) {
            return Math.round(a)
        }))
    };

    function $r(a) {
        return K(cr(Zc(a)), Zr())
    };

    function as(a, b, c, d, e) {
        c = c.g(N(function() {
            return !1
        }));
        d = wd([e, d]).g(S(function(f) {
            f = x(f).next().value;
            return bs(b, f)
        }));
        return Pd(Zc(!1), c, d).g(P(), V(a.i, 1))
    }

    function bs(a, b) {
        return a.g(N(function(c) {
            return b || c === 0 || c === 2
        }))
    };
    var cs = [33, 32],
        ds = K(Nr, N(function(a) {
            return cs.indexOf(a) >= 0
        }), P());

    function es(a, b, c, d, e, f) {
        var g = c.g(N(function(k) {
                return k === 9
            })),
            h = b.element.g(ds);
        c = e.g(O(function(k) {
            return k
        }), S(function() {
            return wd([g, h])
        }), N(function(k) {
            var l = x(k);
            k = l.next().value;
            return !l.next().value || k
        }), P());
        f = wd([c, d.g(P()), f]).g(N(function(k) {
            var l = x(k);
            k = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return Gr(a, b, !k, m, l)
        }), cf(1), id());
        d = f.g(N(function(k) {
            return k.ld
        }));
        f = f.g(S(function(k) {
            return k.zb
        }), R(null), P(), V(a.i, 1));
        return {
            Va: d,
            uc: f
        }
    };

    function fs(a) {
        var b = b === void 0 ? !1 : b;
        return K(S(function(c) {
            return si(a.document, c, b)
        }), V(a.i, 1))
    };
    var gs = function(a, b, c, d, e, f) {
        this.Fc = b.element.g(fs(a), V(a.i, 1));
        this.Mg = as(a, c, b.element, this.Fc, d);
        c = es(a, b, e, d, this.Mg, f);
        d = c.uc;
        this.Va = c.Va;
        this.uc = d;
        this.pf = Pd((new W(1)).W(a.i), b.element.g(Re(1), N(function() {
            return 2
        }), V(a.i, 1)), this.Fc.g(Re(1), N(function() {
            return 3
        }), V(a.i, 1)), this.Mg.g(O(Boolean), Re(1), N(function() {
            return 0
        }), V(a.i, 1))).g(hf(function(g) {
            return g !== 0
        }, !0), V(a.i, 0))
    };

    function hs(a, b) {
        return a && b === 0 ? 15 : a || b !== 1 ? null : 14
    }

    function is(a, b, c) {
        return b instanceof L ? b.g(S(function(d) {
            return (d = hs(d, c)) ? $c(new ce(d)) : a
        })) : (b = hs(b.value, c)) ? $c(new ce(b)) : a
    };

    function js(a) {
        var b = new ce(13);
        if (a.length < 1) return {
            chain: Ac,
            ee: Ac
        };
        var c = new xc,
            d = a[0];
        return {
            chain: a.slice(1).reduce(function(e, f) {
                return e.g(Ke(function(g) {
                    c.next(g);
                    return f
                }))
            }, d).g(Ke(function(e) {
                c.next(e);
                return $c(b)
            }), af(new xc), id()),
            ee: c
        }
    };
    var ks = function() {};
    var ls = function(a, b) {
        this.context = a;
        this.hj = b
    };
    q(ls, ks);
    ls.prototype.eb = function(a, b) {
        var c = this.hj.map(function(f) {
                return f.eb(a, b)
            }),
            d = js(c.map(function(f) {
                return f.mb
            })),
            e = d.ee.g(ms());
        return {
            mb: d.chain.g(V(this.context.i, 1)),
            cb: Object.assign.apply(Object, [{
                ff: e,
                Fk: d.ee
            }].concat(y(c.map(function(f) {
                return f.cb
            }))))
        }
    };
    var ms = function() {
        return ef(function(a, b) {
            b instanceof ce ? a.push(b.ti) : a.push(-1);
            return a
        }, [])
    };

    function ns(a, b) {
        var c = a.g(af(new xc), id());
        return S(function(d) {
            return c.g(b(d))
        })
    };

    function os(a, b) {
        if (a.rb) return $c(new ce(6));
        var c = new xc;
        return Pd(Zc({}), b, c).g(N(function() {
            return {
                timestamp: a.m.now(),
                value: {
                    ja: "geo",
                    ma: ps(a),
                    aa: So(a, !0),
                    ha: c,
                    ra: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Lh(a.i))
    }

    function ps(a) {
        var b = So(a, !1);
        if (!a.Be || !Jg(a.global.parent) || a.global.parent === a.global) return b;
        var c = new No(a.global.parent, a.Ha);
        c.L = a.L;
        c = ps(c);
        a = a.global.frameElement.getBoundingClientRect();
        return xi(yi(xi(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };
    var qs = function(a, b) {
        this.context = a;
        this.xb = b
    };
    q(qs, ks);
    qs.prototype.eb = function(a, b) {
        var c = ns(os(this.context, this.xb), xq(this.context, b.Xa));
        return {
            mb: is(a.Va.g(c), b.qb, 0),
            cb: {}
        }
    };
    var rs = function(a, b, c) {
        c = c === void 0 ? Cq(a, b) : c;
        this.context = a;
        this.fi = c
    };
    q(rs, ks);
    rs.prototype.eb = function(a, b) {
        var c = this.fi(b.Vg);
        return {
            mb: is(a.Va.g(c, Gq(this.context)), b.qb, 0),
            cb: {}
        }
    };

    function ss(a, b, c, d, e) {
        var f = f === void 0 ? new Pr(a) : f;
        var g = g === void 0 ? of (a.m, 500) : g;
        var h = h === void 0 ? of (a.m, 100) : h;
        e = Zc(f).g(ts(c), jf(function(k) {
            d.next(k.Db)
        }), us(a, h), vs(a), ws(a, e), cf(1), id());
        f = new xc;
        b = Pd(Zc({}), b, f);
        return e.g(xs(a, f, b, g, c), V(a.i, 1))
    }

    function ws(a, b) {
        return K(function(c) {
            return wd([c, b])
        }, Se(function(c) {
            var d = x(c);
            c = d.next().value;
            return d.next().value !== 9 || Qr(c) ? Zc(!0) : ys(a, c, "viewableChange").g(O(function(e) {
                return x(e).next().value
            }), Re(1))
        }), N(function(c) {
            return x(c).next().value
        }))
    }

    function ts(a) {
        return S(function(b) {
            if (b.Db === -1) return a.next("if"), $c(new ce(7));
            if (b.kd !== 0) switch (b.kd) {
                case 1:
                    return a.next("mm"), $c(new ce(18));
                case 2:
                    return a.next("ng"), $c(new ce(17));
                default:
                    return a.next("i"), $c(new ce(8))
            }
            return Zc(b)
        })
    }

    function us(a, b) {
        return Se(function() {
            var c = a.zg;
            return qi(a.document) === "complete" ? Zc(!0) : c.g(Se(function() {
                return b
            }))
        })
    }

    function vs(a) {
        return S(function(b) {
            return b.getState() !== "loading" ? Zc(b) : ys(a, b, "ready").g(N(function() {
                return b
            }))
        })
    }

    function xs(a, b, c, d, e) {
        return S(function(f) {
            var g = Rr(f);
            if (typeof g !== "string") return e.next("nc"), $c(new ce(9));
            f.Nf !== void 0 && (f.Nf = !0);
            g = ys(a, f, g, zs);
            var h = {
                version: f.dg(),
                Db: f.Db
            };
            g = g.g(N(function(l) {
                return As.apply(null, [a, b, f, h].concat(y(l)))
            }));
            var k = d.g(jf(function() {
                e.next("mt")
            }), S(function() {
                return $c(new ce(10))
            }));
            g = Ud(g, k);
            return wd([g, c]).g(N(function(l) {
                l = x(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.m.now()
                })
            }))
        })
    }

    function zs(a, b) {
        return (b === null || typeof b === "number") && (a === null || !!a && typeof a.height === "number" && typeof a.width === "number" && typeof a.x === "number" && typeof a.y === "number")
    }

    function As(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : vi;
        c = c.cc("getMaxSize");
        var g = c != null && typeof c.width === "number" && typeof c.height === "number" ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var h = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(h) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: h,
                height: g
            }
        }
        a = {
            value: {
                ma: e,
                aa: c,
                ja: "mraid",
                ha: b,
                ra: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.m.now()
        };
        return Object.assign({}, a, d, {
            Yj: f
        })
    }

    function ys(a, b, c, d) {
        d = d === void 0 ? function() {
            return !0
        } : d;
        return (new L(function(e) {
            var f = a.J.kc(745, function() {
                e.next(E.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).g(O(function(e) {
            return d.apply(null, y(e))
        }))
    };
    var Bs = function(a, b) {
        this.context = a;
        this.xb = b
    };
    q(Bs, ks);
    Bs.prototype.eb = function(a, b) {
        var c = new bd(1),
            d = new bd(1),
            e = ns(ss(this.context, this.xb, c, d, b.Xa), xq(this.context, b.Xa));
        return {
            mb: is(a.Va.g(e), b.qb, 1),
            cb: {
                Oe: c.g(V(this.context.i, 1)),
                Pe: d.g(V(this.context.i, 1))
            }
        }
    };

    function Cs(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function Ds(a, b) {
        var c = c === void 0 ? null : c;
        var d = new xc,
            e = void 0,
            f = a.Wf,
            g = d.g(N(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.m.now()
                }) : null
            }), O(function(k) {
                return k !== null
            }), N(function(k) {
                return k
            }));
        b = wd([Pd(f, g), b]);
        var h = c;
        return b.g(O(function(k) {
            k = x(k).next().value;
            h === null && (h = k.value.kh);
            return k.value.kh === h
        }), jf(function(k) {
            return void(e = x(k).next().value)
        }), N(function(k) {
            var l = x(k);
            k = l.next().value;
            l = l.next().value;
            try {
                var m = k.value.data,
                    u = k.timestamp,
                    t = m.viewport,
                    r, w, v = Object.assign({},
                        t, {
                            width: (r = t == null ? void 0 : t.width) != null ? r : 0,
                            height: (w = t == null ? void 0 : t.height) != null ? w : 0,
                            x: 0,
                            y: 0,
                            zk: t ? t.width * t.height : 0
                        }),
                    z = Es(v),
                    C = m.adView,
                    Q = C.measuringElement && C.containerGeometry ? Es(C.containerGeometry) : Es(C.geometry),
                    T = Es(C.geometry),
                    ma = C.reasons.some(Cs),
                    H = ma ? vi : Es(C.onScreenGeometry),
                    D;
                l && (D = C.percentageInView / 100);
                l && ma && (D = 0);
                return {
                    timestamp: u,
                    value: {
                        ja: "omid",
                        ma: Q,
                        aa: z,
                        ha: d,
                        X: "omid",
                        N: T,
                        ra: {
                            x: Q.left,
                            y: Q.top
                        },
                        Y: H,
                        qd: D
                    }
                }
            } catch (ic) {
                hh(ic, sh());
                var fa, Cc;
                m = (Cc = (fa = ic) == null ? void 0 : fa.message) !=
                    null ? Cc : "An unknown error occurred";
                fa = "Error while processing geometryChange event: " + JSON.stringify(k.value) + "; " + m;
                throw Error(fa);
            }
        }), cf(1), id())
    }

    function Es(a) {
        var b, c, d, e;
        return {
            left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
            top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
            width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
            height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0)
        }
    };

    function Fs(a, b, c, d) {
        c = c === void 0 ? Qd : c;
        var e = a.i;
        if (b === null) return $c(new ce(20));
        if (!b.validate()) return $c(new ce(21));
        var f;
        d = Gs(e, b, d).g(N(function(g) {
            var h = g.value;
            g = g.timestamp;
            var k = b.m,
                l = a.m;
            if (k.timeline !== g.timeline) throw new he;
            g = new qe(g.value - k.now().value + l.now().value, l.timeline);
            return f = {
                value: h,
                timestamp: g
            }
        }));
        return Pd(d, c.g(N(function() {
            return f
        }))).g(O(function(g) {
            return g !== void 0
        }), N(function(g) {
            return g
        }), V(a.i, 1))
    }

    function Gs(a, b, c) {
        return Ds(b, c).g(V(a, 1), N(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    ra: {
                        x: d.value.N.left,
                        y: d.value.N.top
                    },
                    ma: d.value.Y,
                    aa: d.value.aa,
                    ja: d.value.X,
                    ha: d.value.ha
                }
            }
        }))
    };
    var Hs = function(a, b, c) {
        this.pa = a;
        this.F = b;
        this.xb = c
    };
    q(Hs, ks);
    Hs.prototype.eb = function(a, b) {
        var c = b.Xa;
        b = Fs(this.F, this.pa, this.xb, b.yg);
        c = ns(b, xq(this.F, c));
        return {
            mb: a.Va.g(c),
            cb: {}
        }
    };
    var Is = function(a, b, c) {
        this.pa = a;
        this.F = b;
        this.Kh = c
    };
    q(Is, ks);
    Is.prototype.eb = function(a, b) {
        var c = Fs(this.F, this.pa, void 0, b.yg);
        b = Fq(this.F, b.Vg, this.Kh);
        c = ns(c, b);
        return {
            mb: a.Va.g(c),
            cb: {}
        }
    };

    function Js(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function Ks(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };

    function Ls(a) {
        return a.document.Ii.g(N(function(b) {
            return b === "visible"
        }), P(), V(a.i, 1))
    };
    var Ms;
    Ms = ["2026021101"].slice(-1)[0].substring(0, 8);

    function Ns(a, b, c) {
        var d;
        return b.g(P(), S(function(e) {
            return c.g(N(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), R(!1), V(a.i, 1))
    };

    function Os(a) {
        return K(Kq(N(function(b) {
            return br(b, a)
        })), dq(), N(function(b) {
            return Math.round(b)
        }))
    };

    function Ps(a, b, c, d, e) {
        var f = Br;
        if (f.length > 1)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.g(R(void 0), S(function() {
            return c.g(rq())
        }), P(), V(a, 1));
        e = e.g(R(void 0), S(function() {
            return c.g(Zr())
        }), P(), V(a, 1));
        return {
            Md: d.g(R(void 0), S(function() {
                return b.g(N(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: !0
                    }
                }), dq())
            }), P(), V(a, 1)),
            Nd: d.g(R(void 0), S(function() {
                return b.g(N(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: h.value === 0
                    }
                }), dq())
            }), P(), V(a, 1)),
            Jc: d.g(R(void 0), S(function() {
                return b.g(qq($r,
                    f))
            }), P(Kb), V(a, 1)),
            Oa: d.g(R(void 0), S(function() {
                return b.g(qq(Os, f), N(function(h) {
                    return h.map(function(k, l) {
                        return l > 0 ? k - h[l - 1] : k
                    })
                }))
            }), P(Kb), V(a, 1)),
            Ic: e,
            hb: g.g(P(Qq), V(a, 1))
        }
    };

    function Qs(a, b, c) {
        var d = c.g(N(function(e) {
            return {
                value: e,
                timestamp: a.m.now()
            }
        }), P(Qq));
        return b instanceof L ? b.g(P(), S(function(e) {
            return e ? (new W({
                value: !1,
                timestamp: a.m.now()
            })).W(a.i) : d
        })) : b.value === !1 ? d : new W(!1)
    }

    function Rs(a, b, c, d, e, f, g) {
        var h = ur;
        b = b instanceof L ? b.g(R(!1), P()) : b;
        var k = !(Zg() || Yg());
        c = Qs(a, c, d);
        a = g.Va.g(aq(a.i));
        return Object.assign({}, h, {
            sd: c,
            Xg: e,
            Cf: k,
            wg: b,
            vd: a,
            Ug: f
        })
    };

    function Ss(a) {
        a = a.global;
        if (typeof a.__google_lidar_ === "undefined") return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if (typeof b === "number" && b > 0 && (a = a.__google_lidar_radf_, typeof a === "function")) try {
            a()
        } catch (c) {}
        return !0
    }

    function Ts(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (b.__google_lidar_radf_ !== void 0) return Ac;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new xc;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.g(qg(a.J, 743))
    };
    var Us = function(a) {
            var b = this;
            this.Je = !1;
            this.Se = [];
            this.Re = [];
            a(function(c) {
                b.Je = !0;
                b.resolution = c;
                b.evaluate()
            }, function(c) {
                b.Oi = c;
                b.evaluate()
            })
        },
        Vs = function(a) {
            return new Us(function(b, c) {
                var d = [],
                    e = 0;
                a.forEach(function(f, g) {
                    f.then(function(h) {
                        d[g] = h;
                        ++e === a.length && b(d)
                    }).catch(function(h) {
                        c(h)
                    })
                })
            })
        };
    Us.prototype.evaluate = function() {
        var a = this.resolution,
            b = this.Oi;
        if (b !== void 0 || this.Je) this.Je && this.Se.forEach(function(c) {
            return void c(a)
        }), b !== void 0 && this.Re.forEach(function(c) {
            return void c(b)
        }), this.Se = [], this.Re = []
    };
    Us.prototype.then = function(a) {
        this.Se.push(a);
        this.evaluate();
        return this
    };
    Us.prototype.catch = function(a) {
        this.Re.push(a);
        this.evaluate();
        return this
    };
    var Ws = function(a) {
        this.children = a;
        this.Ge = !1;
        this.fe = []
    };
    Ws.prototype.complete = function() {
        var a = this;
        this.Ge = !0;
        this.fe.forEach(function(b) {
            return void b(a)
        });
        this.fe.splice(0)
    };
    Ws.prototype.onComplete = function(a) {
        this.Ge ? a(this) : this.fe.push(a)
    };
    Ws.prototype.fb = function(a) {
        var b = this.children.map(function(c) {
            return c.fb(a)
        });
        return b.find(function(c) {
            return c !== 2
        }) === void 0 ? 2 : this.completed ? 0 : b.some(function(c) {
            return c === 1
        }) ? 1 : 0
    };
    da.Object.defineProperties(Ws.prototype, {
        completed: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ge
            }
        }
    });
    var Xs = function() {
        var a = E.apply(0, arguments);
        Ws.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            d.onComplete(function() {
                --c === 0 && b.complete()
            })
        })
    };
    q(Xs, Ws);
    Xs.prototype.clone = function() {
        return new(Function.prototype.bind.apply(Xs, [null].concat(y(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    Xs.prototype.kf = function(a, b) {
        var c = this;
        if (!this.completed) {
            var d = this.events.find(function(e) {
                return e.fb(a) === 1
            });
            d !== void 0 && d.kf(a, function() {
                c.completed || b()
            })
        }
    };
    var Ys = function(a, b) {
        Ws.call(this, []);
        this.ne = a;
        this.wd = Symbol(b);
        this.Ji = a
    };
    q(Ys, Ws);
    Ys.prototype.clone = function() {
        var a = new Ys(this.Ji, this.wd.description);
        a.wd = this.wd;
        return a
    };
    Ys.prototype.fb = function(a) {
        return a !== this.event ? 2 : this.completed || this.ne === 0 ? 0 : 1
    };
    Ys.prototype.kf = function(a, b) {
        this.fb(a) === 1 && (this.ne--, b(), this.ne === 0 && this.complete())
    };
    da.Object.defineProperties(Ys.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.wd
            }
        }
    });
    var Zs = function(a) {
        Ys.call(this, 1, a)
    };
    q(Zs, Ys);
    var $s = function(a, b, c) {
        var d = E.apply(3, arguments);
        this.Sa = a;
        this.Hh = b;
        this.ke = c;
        this.Hc = new Set;
        this.Vb = d;
        if (this.Sa.F) this.context = this.Sa.F;
        else if (this.Sa.pa) this.context = this.Sa.pa;
        else throw Error("Ja");
        var e = d.reduce(function(h, k) {
            k.subscribedEvents.forEach(function(l) {
                return void h.add(l)
            });
            return h
        }, new Set);
        e = x(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                Qf: void 0
            }, f = e.next()) {
            g.Qf = f.value;
            f = d.filter(function(h) {
                return function(k) {
                    return k.controlledEvents.indexOf(h.Qf) >= 0
                }
            }(g));
            if (f.length ===
                0) throw Error("Ka");
            if (f.length > 1) throw Error("La");
        }
    };
    $s.prototype.start = function() {
        var a = this;
        this.Vb.forEach(function(b) {
            return void b.start(a.Sa)
        });
        this.ke.start(this.Sa, this.Ph.bind(this), this.Mb.bind(this), function() {})
    };
    $s.prototype.dispose = function() {
        var a = this;
        this.ke.dispose();
        this.Hc.forEach(function(b) {
            return void a.Mb(b)
        });
        this.Vb.forEach(function(b) {
            return void b.dispose()
        })
    };
    var at = function(a, b) {
            b = {
                measuringCreativeIds: [].concat(y(a.Hc.values())).map(function(c) {
                    return a.context.wc.getName(c)
                }),
                hasCreativeSourceCompleted: !!a.ke.Jd,
                colleagues: a.Vb.map(function(c) {
                    return {
                        name: c.name,
                        controlledEvents: c.controlledEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        }),
                        subscribedEvents: c.subscribedEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        })
                    }
                }),
                ephemeralCreativeStateChanges: b
            };
            b = {
                specMajor: 2,
                specMinor: 0,
                specPatch: 0,
                instanceId: a.context.wc.getName(a.context.Eb),
                timestamp: se(a.context.m.now(), new qe(0, a.context.m.timeline)),
                mediatorState: b
            };
            $d(a.context, b)
        },
        bt = function(a, b, c, d, e) {
            var f = {};
            at(a, (f[b] = {
                events: [{
                    timestamp: c,
                    description: d,
                    status: e
                }]
            }, f))
        };
    $s.prototype.Ph = function(a, b, c) {
        var d = this;
        if (!this.Hc.has(a)) {
            var e = this.Hh.clone();
            this.Hc.add(a);
            at(this, {});
            var f = !1,
                g = [];
            this.Vb.forEach(function(h) {
                var k = function(l, m, u) {
                    var t = d.context.wc.getName(a),
                        r = se(d.context.m.now(), new qe(0, d.context.m.timeline)),
                        w, v = (w = l.description) != null ? w : "n/a";
                    if (h.controlledEvents.indexOf(l) < 0 || e.fb(l) !== 1) return u(!1), bt(d, t, r, v, 1), new Us(function(C) {
                        return void C()
                    });
                    var z = new Us(function(C) {
                        e.kf(l, function() {
                            d.Vb.filter(function(Q) {
                                return Q.subscribedEvents.indexOf(l) >=
                                    0
                            }).forEach(function(Q) {
                                return void Q.handleEvent(a, l, m)
                            });
                            C()
                        })
                    });
                    return new Us(function(C) {
                        z.then(function() {
                            u(!0);
                            bt(d, t, r, v, 2);
                            C()
                        })
                    })
                };
                h.ye(a, b, c, function(l, m, u) {
                    return f ? k(l, m, u) : new Us(function(t) {
                        g.push(function() {
                            k(l, m, u).then(function() {
                                t()
                            })
                        })
                    })
                }, function(l) {
                    try {
                        d.context.L.M("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=colleague-executed&name=" + l, {
                            fa: "GET"
                        }).sendNow()
                    } catch (m) {}
                })
            });
            f = !0;
            g.forEach(function(h) {
                return void h()
            })
        }
    };
    $s.prototype.Mb = function(a) {
        this.Hc.delete(a);
        this.Vb.forEach(function(b) {
            b.Mb(a)
        });
        at(this, {})
    };
    var ct = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? !1 : b;
            this.valueType = "boolean"
        },
        dt = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? 0 : b;
            this.valueType = "number"
        };
    var et = {
        considerOmidZOrderOcclusions: [new ct("100006"), !1],
        extraPings: [new dt("45362137"), 0],
        extrapolators: [new ct("45377435"), !1],
        rxlidarStatefulBeacons: [new ct("45372163"), !1],
        shouldIgnoreAdChoicesIcon: [new ct("45382077"), !1],
        dedicatedViewableAttributionPing: [new dt("45389692"), 0],
        useReachIntegrationPolyfill: [new ct("45407239"), !1],
        useReachIntegrationSharedStorage: [new ct("45407240", !0), !0],
        sendBrowserIdInsteadOfVPID: [new ct("45407241"), !1],
        waitForImpressionColleague: [new ct("45430682"), !1],
        fetchLaterBeacons: [new ct("45618478"), !1],
        rxInNonrx: [new ct("45642405"), !1],
        addQueryIdToErrorPing: [new ct("45653435"), !1],
        shouldSendExplicitDisplayMeasurablePing: [new ct("45658589"), !1],
        reachUseCreateWorklet: [new ct("45661569"), !1],
        tosCustomTimeoutMillis: [new dt("45706257", 36E5), 36E5],
        shouldCacheTimeMetricsInLocalStorage: [new ct("45722991", !0), !0],
        omakaseAdStatsResetVersion: [new dt("45738539", 1), 1]
    };

    function ft(a) {
        return Object.entries(et).reduce(function(b, c) {
            var d = x(c);
            c = d.next().value;
            var e = x(d.next().value);
            d = e.next().value;
            e = e.next().value;
            var f;
            if (a == null) var g = void 0;
            else a: {
                var h = a.Tf[d.key];
                if (d.valueType === "proto") {
                    try {
                        var k = JSON.parse(h);
                        if (Array.isArray(k)) {
                            g = k;
                            break a
                        }
                    } catch (l) {}
                    g = d.defaultValue
                } else g = typeof h === typeof d.defaultValue ? h : d.defaultValue
            }
            b[c] = (f = g) != null ? f : e;
            return b
        }, {})
    };
    var Vm = function(a) {
        so.call(this, a)
    };
    q(Vm, so);
    var gt = function(a) {
        return ql(Gm(a, 3))
    };
    Vm.prototype.ue = function() {
        return an(this, 4, !0)
    };
    var ht = function(a) {
        return el(Gm(a, 5))
    };
    Vm.prototype.td = function() {
        return bn(this, 6)
    };
    var jt = function(a) {
        return an(a, 7)
    };
    Vm.U = "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
    var kt = [0, go, -2, fo, -1, bo, fo];
    Vm.prototype.P = uo(kt);
    var lt = function(a) {
        so.call(this, a)
    };
    q(lt, so);
    lt.prototype.Kg = function(a) {
        return en(this, 5, a)
    };
    lt.prototype.getType = function() {
        var a = a === void 0 ? 0 : a;
        var b = il(Gm(this, 6));
        return b != null ? b : a
    };
    var mt = vo(lt);
    lt.U = "ads.geo.GeoTargetMessage";
    var nt = function(a) {
        so.call(this, a)
    };
    q(nt, so);
    n = nt.prototype;
    n.Yf = function() {
        return cn(this, 2)
    };
    n.Zf = function() {
        return ql(Gm(this, 2))
    };
    n.ue = function() {
        return an(this, 3, !0)
    };
    n.ag = function() {
        return Xm(this, lt, 4)
    };
    n.Ig = function(a) {
        return $m(this, lt, 4, a)
    };
    n.cg = function() {
        return Nm(this, 7, il, void 0 === Ok ? 2 : 4)
    };
    n.Af = function(a) {
        return hn(this, 7, a)
    };
    n.Jg = function(a) {
        return dn(this, 9, a)
    };
    n.td = function() {
        return bn(this, 10)
    };
    nt.U = "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
    var ot = [0, jo, -4, lo, fo, bo, Yn, jo, Yn, jo, bo, jo, -1, [0, bo, -3], ko, ao, jo, $n, -1, bo, -1, $n, Yn, [0, $n, bo, -1, lo, Yn, $n], Xn, jo, [0, bo, -1], fo, Yn, [0, lo, -3]];
    lt.prototype.P = uo(ot);
    var pt = [0, go, -1, fo, ot, co, -1, mo, bo, fo, bo];
    nt.prototype.P = uo(pt);
    var qt = function(a) {
        so.call(this, a)
    };
    q(qt, so);
    qt.prototype.Yf = function() {
        return cn(this, 1)
    };
    qt.prototype.Zf = function() {
        return ql(Gm(this, 1))
    };
    qt.prototype.td = function() {
        return bn(this, 2)
    };
    qt.U = "ads.branding.measurement.client.serving.integrations.shared.SharedMetadata";
    var rt = [0, go, bo];
    qt.prototype.P = uo(rt);
    var st = function(a) {
        so.call(this, a)
    };
    q(st, so);
    var tt = function(a) {
        return Xm(a, nt, 1)
    };
    st.U = "ads.branding.measurement.client.serving.IntegratorMetadata";
    var ut = [0, pt, kt, rt];
    st.prototype.P = uo(ut);
    var vt = to(st, ut);
    var wt = function() {
        this.Tf = {}
    };
    var xt = function() {
        this.Mf = !1;
        this.Jf = new Map
    };
    xt.prototype.start = function(a, b, c, d) {
        var e = this;
        if (this.Jd === void 0 && a.F) {
            var f = a.F;
            this.If = d;
            c = !this.Mf && Ss(f);
            d = this.Mf ? Ac : Ts(f);
            d = jp(f, d);
            this.Jd = (c ? Ac : d.g(N(function(g) {
                var h = h === void 0 ? Symbol() : h;
                return Object.freeze({
                    Eb: h,
                    element: (new W(g)).W(f.i)
                })
            }), bp())).subscribe(function(g) {
                var h = g.Eb;
                e.Jf.set(h, g);
                g.element.g(Re(1)).subscribe(function(k) {
                    var l = Zo(k, "data-google-av-flags"),
                        m = new wt;
                    if (l !== null) try {
                        var u = JSON.parse(l)[0];
                        l = "";
                        for (var t = 0; t < u.length; t++) l += String.fromCharCode(u.charCodeAt(t) ^
                            "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(t % 10));
                        m.Tf = JSON.parse(l)
                    } catch (w) {}
                    m = ft(m);
                    k = Zo(k, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (k !== null) try {
                            var r = vt(k);
                            break a
                        } catch (w) {}
                        r = new st
                    }
                    b(h, r, m)
                })
            });
            c && this.dispose();
            a.pa && Kf(a.pa)
        }
    };
    xt.prototype.dispose = function() {
        var a, b;
        (a = this.Jd) == null || (b = a.unsubscribe) == null || b.call(a);
        this.Jd = void 0;
        var c;
        (c = this.If) == null || c.call(this);
        this.If = void 0
    };
    var yt = function(a) {
        so.call(this, a)
    };
    q(yt, so);
    yt.prototype.Kg = function(a) {
        return gn(this, 2, a)
    };
    yt.prototype.Cb = function(a) {
        return fn(this, 3, a)
    };
    yt.prototype.Bb = function(a) {
        return fn(this, 4, a)
    };
    yt.U = "ads.branding.measurement.client.frontend.integrations.active_view.OmakaseStatusMessage";
    var zt = [0, lo, -1, go, -3];
    yt.prototype.P = uo(zt);
    var At = function(a) {
        return function(b) {
            return Sn(b, a)
        }
    }(zt);

    function Bt(a, b) {
        var c = (new yt).Cb(b.name).Kg(1).Bb(b.message);
        c = fn(c, 5, b.stack);
        c = fn(c, 6, String(a.J.hf));
        switch (b.name) {
            case "SecurityError":
                gn(c, 1, 2);
                break;
            case "QuotaExceededError":
                gn(c, 1, 1);
                break;
            case "SyntaxError":
                gn(c, 1, 3);
                break;
            case "TypeError":
                gn(c, 1, 4);
                break;
            case "InvalidStateError":
                gn(c, 1, 7);
                break;
            case "AbortError":
                gn(c, 1, 6);
                break;
            case "NotSupportedError":
                gn(c, 1, 8);
                break;
            case "IframeError":
                gn(c, 1, 5);
                break;
            case "LocksApiUnavailableError":
                gn(c, 1, 9);
                break;
            default:
                gn(c, 1, 0)
        }
        b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=omakase&proto=" +
            encodeURIComponent(Sh(At(c))) + "&v=" + Ms;
        a.L.M(b, {
            fa: "GET"
        }).sendNow()
    };
    var Ct = function(a) {
        this.F = a
    };
    n = Ct.prototype;
    n.reportError = function(a) {
        Bt(this.F, a)
    };
    n.setItem = function(a, b) {
        try {
            this.hasLocalStorageAccess() && this.F.localStorage.setItem(a, b)
        } catch (c) {
            this.reportError(c)
        }
    };
    n.getItem = function(a) {
        try {
            if (this.hasLocalStorageAccess()) return this.F.localStorage.getItem(a)
        } catch (b) {
            this.reportError(b)
        }
        return null
    };
    n.hasLocalStorageAccess = function() {
        return Po(this.F)
    };
    n.zc = function() {
        return this.F.zc()
    };
    n.Ye = function(a, b) {
        var c = this;
        return Ca(function(d) {
            return d.A(c.F.Ye(a, b), 0)
        })
    };
    n.performExclusiveLockedOperation = function(a, b) {
        var c = this,
            d;
        return Ca(function(e) {
            if (e.u == 1) {
                if (!c.zc()) return b(), e.na(0);
                e.Ab(3);
                return e.A(c.F.Ye(a, b), 5)
            }
            if (e.u != 3) return e.Dc(0);
            d = e.kb();
            c.reportError(d);
            e.Tb()
        })
    };
    var Dt = function(a) {
        so.call(this, a)
    };
    q(Dt, so);
    var Et = function(a, b) {
        return fn(a, 1, b)
    };
    Dt.U = "contentads.bow.rendering.client.TurtleDoveReportingData";
    Dt.prototype.P = uo([0, go, bo, go, -5, lo, go, -4]);

    function Ft() {
        var a = Og();
        return a ? Hb("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;Version/8.0 Safari/601.1 WPE;WebOS".split(";"), function(b) {
            return Va(a, b)
        }) || Va(a, "OMI/") && !Va(a, "XiaoMi/") ? !0 : Va(a, "Presto") && Va(a, "Linux") && !Va(a, "X11") && !Va(a, "Android") && !Va(a, "Mobi") : !1
    };
    var ur = Object.freeze({
            Rg: 1E3,
            qe: .5,
            Le: .3
        }),
        Br = Object.freeze([1, .75, ur.qe, ur.Le, 0]),
        Gt = function(a, b, c, d, e, f, g) {
            this.Mi = a;
            this.Ub = b;
            this.Ob = c;
            this.rc = d;
            this.dd = e;
            this.ed = f;
            this.ae = g;
            this.name = "rxlidar";
            this.ri = new bd;
            this.controlledEvents = [];
            this.subscribedEvents = [];
            this.le = new bd;
            this.Ka = new bd;
            this.controlledEvents.push(this.rc, this.dd, this.ed);
            this.subscribedEvents.push(this.Ob)
        };
    n = Gt.prototype;
    n.start = function(a) {
        if (this.we === void 0 && a.F) {
            var b;
            if ((b = this.Ub) != null) var c = b;
            else {
                b = a.F;
                var d = (c = a.pa) != null ? c : null;
                c = {
                    Gh: .01,
                    ui: of (b.m, 36E5),
                    xb: b.m.Ba(100).g(V(b.i, 1)),
                    pa: d
                }
            }
            this.Ub = c;
            a = a.F;
            this.we = Ht(a, this.le.g(V(a.i, 1)), this.Ub.Gh, this.Ub.ui, this.Ub.xb, this.Ub.pa, this.Ka.g(R(!1), V(a.i, 1)), this.rc, this.dd, this.ed, this.ae).subscribe(this.ri)
        }
    };
    n.dispose = function() {
        this.le.complete();
        this.Ka.complete();
        var a;
        (a = this.we) == null || a.unsubscribe();
        this.we = void 0
    };
    n.ye = function(a, b, c, d, e) {
        if (!Km(b, Vm, 2) || Xm(b, Vm, 2).ue()) {
            this.le.next(Object.assign({}, this.Mi.Jf.get(a), {
                metadata: b,
                experimentState: c,
                Gk: a,
                Ta: d
            }));
            var f, g;
            e((g = (f = Xm(b, Vm, 2)) == null ? void 0 : f.td()) != null ? g : -1)
        }
    };
    n.Mb = function() {};
    n.handleEvent = function(a, b) {
        b === this.Ob && (this.Ka.next(!0), this.Ka.complete())
    };

    function Ht(a, b, c, d, e, f, g, h, k, l, m) {
        var u = Ls(a).g(N(function(r) {
                return !r
            })),
            t = new ls(a, [new rs(a, Br), new qs(a, e), new Is(f, a, Br), new Hs(f, a, e), new Bs(a, e)]);
        return mp(a, b, function(r, w) {
            var v = Yr(r, w.element),
                z = v.sa,
                C = v.sc,
                Q = v.ie,
                T = v.nf,
                ma = v.Ah,
                H = v.qb,
                D = v.hi,
                fa = v.De,
                Cc = v.He,
                ic = v.Xa,
                qd = v.qa,
                Qa = v.sj,
                vg = v.sb;
            v = v.Ke;
            var wg, Ya = (wg = gt(Wm(w.metadata))) != null ? wg : "",
                qu = jt(Wm(w.metadata));
            wg = Et(new Dt, atob(Ya)).Ya();
            Ya = (new W(w.experimentState)).W(r.i);
            var vn = new W(new qf(r, new Gg(r))),
                wn = Ya.g(N(function(B) {
                        return B.fetchLaterBeacons
                    }),
                    R(!1), P(), V(r.i, 1)),
                ru = wn.g(N(function(B) {
                    return B && (new Cg(r)).O({
                        Of: !0
                    })
                }), jf(function(B) {
                    B && vn.value.M("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&start&control&fle=1&sfl=1").sendNow()
                })),
                Be = Ya.g(N(function(B) {
                    return B.shouldIgnoreAdChoicesIcon
                })),
                Ra = H.g(Ne(D), N(function(B) {
                    var Za = x(B);
                    B = Za.next().value;
                    Za = Za.next().value;
                    (B = B || Za) || ((B = Va(Og(), "CrKey") && !(Va(Og(), "CrKey") && Va(Og(), "SmartSpeaker")) || Va(Og(), "PlayStation") || Va(Og(), "Roku") || Ft() || Va(Og(), "Xbox")) ||
                        (B = Og(), B = Va(B, "AppleTV") || Va(B, "Apple TV") || Va(B, "CFNetwork") || Va(B, "tvOS")), B || (B = Og(), B = Va(B, "sdk_google_atv_x86") || Va(B, "Android TV")));
                    return B
                }));
            D = new gs(r, w, ma, H, ic, Be);
            Be = Ya.g(N(function(B) {
                return B.considerOmidZOrderOcclusions
            }));
            var Gc, yb = (Gc = ht(Wm(w.metadata))) != null ? Gc : !1;
            Gc = t.eb(D, {
                qb: H,
                Vg: yb,
                Xa: ic,
                yg: Be
            });
            var fb = Gc.mb,
                Ce = Gc.cb;
            Gc = Ce.Oe;
            Be = Ce.Pe;
            Ce = Ce.ff;
            yb = (new W(yb)).W(r.i);
            var Hc = Rs(r, Cc, Ra, u, Qa, yb, D);
            Qa = Hr(r.i, r.m, fb, Hc);
            Ra = Ps(r.i, Qa.Aa.jf, Qa.Aa.visible, Qa.df, Qa.Vc);
            yb = Wr(r.i, r.m,
                Qa.Vc, Qa.Aa.ha, Qa.Aa.visible);
            fb = kr(r.i, r.m, fb, Hc);
            Hc = Ar(r.m, r.i, fb.Aa.jf, fb.Aa.visible, fb.df, fb.Vc);
            var xg = {
                    Sd: tr(r.i, r.m, fb.Vc, Hc.Ic)
                },
                Oi = Ya.g(N(function(B) {
                    return B.extrapolators
                }), R(!1));
            fb = $p(r.i, Oi, Object.assign({}, fb.Aa, Hc, xg), Object.assign({}, Qa.Aa, {
                Sd: ar(r, yb),
                Jc: ar(r, Ra.Jc),
                Oa: ar(r, Ra.Oa),
                Ic: ar(r, Ra.Ic),
                hb: Ra.hb.g(N(function(B) {
                    return new $q(r.m, B)
                })),
                Md: ar(r, Ra.Md),
                Nd: ar(r, Ra.Nd)
            }));
            Ra = Jq(r, d.g(Qe("t")));
            yb = (f !== null && f.validate() ? f.bj : Qd).g(V(r.i, 1), Qe("u"));
            Ra = Ud(Ra, yb);
            var xn = Ra.g(O(function(B) {
                return B !==
                    null
            }));
            yb = Ya.g(N(function(B) {
                return B.shouldCacheTimeMetricsInLocalStorage && qu
            }), P(), V(r.i, 1)).g(N(function(B) {
                B && It(r);
                return B && Po(r, function(Za) {
                    Bt(r, Za)
                }) && !r.rb
            }), P(), V(r.i, 1));
            Hc = Ya.g(N(function(B) {
                return B.omakaseAdStatsResetVersion
            }), P(), V(r.i, 1));
            var tu = r.m.Ba(4E3).g(Ne(u), O(function(B) {
                B = x(B);
                B.next();
                return !B.next().value
            }), N(function(B) {
                return x(B).next().value
            }), V(r.i, 1));
            xg = yb.g(S(function(B) {
                return B ? Pd(xn, tu) : xn
            }), P(), V(r.i, 1));
            Oi = Ns(r, fb.ha, xg);
            var yn = Jt(r, D, z),
                wu = Kt(r, Ra, w.element),
                xu = yn.mh.g(R({
                    x: 0,
                    y: 0
                })),
                yu = Ya.g(N(function(B) {
                    return B.rxlidarStatefulBeacons
                }), R(!1), P(), jf(function(B) {
                    Ih = B
                }), V(r.i, 1)),
                zn = fa.g(N(function(B) {
                    return B === 40 || B === 41 || B === 42
                })),
                zu = Ya.g(N(function(B) {
                    return B.waitForImpressionColleague
                }), R(!1), P(), V(r.i, 1)),
                Au = b.g(N(function(B) {
                    var Za;
                    return B.experimentState.addQueryIdToErrorPing ? (Za = Xm(B.metadata, qt, 3)) == null ? void 0 : Za.Zf() : void 0
                }));
            return Object.assign({}, {
                L: new W(r.L),
                Qb: new W("lidar2"),
                jj: new W("lidartos"),
                qh: new W(Ms),
                ae: new W(m),
                ge: new W(r.validate() ?
                    null : new de),
                wh: new W(ri(r.document)),
                Z: new W(Cp),
                pe: Ra,
                Qg: Ra,
                Bk: Oi,
                yc: g,
                rj: zu,
                wi: xg,
                cf: yb,
                Si: Hc,
                Ta: new W(w.Ta),
                rc: new W(h),
                dd: new W(k),
                ed: new W(l),
                zh: new W(r.rb ? 1 : void 0),
                Bh: new W(r.rh ? 1 : void 0),
                qb: H,
                sb: vg,
                lf: new W(wg),
                bc: vg.g(O(function(B) {
                    return B
                }), N(function() {
                    return r.bc.bind(r)
                })),
                Oe: Gc.g(V(r.i, 1)),
                Pe: Be.g(V(r.i, 1)),
                Lh: Ya.g(N(function(B) {
                    return B.extraPings
                })),
                lg: yu,
                Vh: wn,
                Og: ru,
                Ke: v,
                gi: zn,
                Wh: Ya.g(N(function(B) {
                    return B.dedicatedViewableAttributionPing
                })),
                Mh: vn,
                Pg: new W(Ih && (new Hh(r)).O({
                    fa: "GET"
                })),
                ej: new W(Number(w.experimentState.useReachIntegrationSharedStorage) << 0 + Number(w.experimentState.useReachIntegrationPolyfill) << 1 + Number(w.experimentState.sendBrowserIdInsteadOfVPID) << 2),
                yh: w.element.g(N(function(B) {
                    return B !== null
                })),
                pb: qd,
                kj: qd,
                ie: Q.g(R([])),
                nf: T.g(R([])),
                Th: Q.g(N(function(B) {
                    return B.length > 0 ? !0 : null
                }), R(null), P()),
                sc: C.g(R([]), V(r.i, 1)),
                ek: Ya,
                shouldSendExplicitDisplayMeasurablePing: Ya.g(N(function(B) {
                    return B.shouldSendExplicitDisplayMeasurablePing
                })),
                sa: z,
                uc: D.uc,
                De: fa.g(R(0),
                    V(r.i, 1)),
                si: ma,
                Xa: ic.g(R(0), V(r.i, 1)),
                Gb: zn.g(N(function(B) {
                    return B ? Yp : Bp
                })),
                lc: new W(Zp),
                He: Cc,
                ng: D.Fc.g(aq(r.i)),
                pf: D.pf
            }, fb, {
                md: wd([fb.md, xu]).g(N(function(B) {
                    var Za = x(B);
                    B = Za.next().value;
                    Za = Za.next().value;
                    return yi(B, Za)
                }), P(wi))
            }, yn, {
                Xc: Wh(r),
                Uh: wu,
                ff: Ce,
                Qd: Qa.Aa.Qd,
                sh: new W(new Sp),
                escapedQueryId: Au
            })
        }, Ap(a, "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=" + m + "&v=" + Ms, c), Fp(Gp(Hp(), Rp), op, Dp, yp(new Ct(a))))
    }

    function Jt(a, b, c) {
        var d = d === void 0 ? Ha : d;
        var e, f;
        d = ((e = d.performance) == null ? void 0 : (f = e.timing) == null ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            jh: new W(d),
            ih: oq(a, b)
        }, nq(a, b, c))
    }

    function Kt(a, b, c) {
        return b.g(O(function(d) {
            return d !== null
        }), S(function() {
            return c
        }), N(function(d) {
            var e = dp(a);
            return e.length > 0 && e.indexOf(d) >= 0
        }), N(function(d) {
            return !d
        }))
    }

    function It(a) {
        if (a.rb) {
            var b = Error();
            b.name = "IframeError";
            b.message = "Failure: Omakase is running in cross origin context.";
            Bt(a, b)
        }
        a.zc() || (b = Error(), b.name = "LocksApiUnavailableError", b.message = "Failure: Web Locks API is not present", Bt(a, b))
    };
    var Lt = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.Ob = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "impression";
        this.Ae = new Map
    };
    n = Lt.prototype;
    n.start = function(a) {
        this.Sa = a
    };
    n.dispose = function() {
        this.Ae.clear()
    };
    n.ye = function(a, b, c, d) {
        if (b = this.Sa) c = new Mt(b, c, this.Ob, d), this.Ae.set(a, c)
    };
    n.Mb = function(a) {
        this.Ae.delete(a)
    };
    n.handleEvent = function() {};
    var Mt = function(a, b, c, d) {
        var e = this;
        this.context = a;
        this.Ob = c;
        this.Tg = function() {};
        this.kg = [];
        this.ig = "&avradf=1";
        this.jg = Vs([]);
        this.Ka = new bd;
        c = a.pa;
        var f = c !== null && (c == null ? void 0 : c.validate()),
            g, h = (g = a.F) == null ? void 0 : g.i;
        this.Ka.g(R(!b.waitForImpressionColleague), V(h, 1));
        this.gj = f ? c == null ? void 0 : c.hg.g(Re(1), Qe(!0), R(!1)) : (new W(!0)).W(h);
        this.Tg = function(k, l) {
            e.Ka.next(!0);
            e.Ka.complete();
            wd([e.Ka, e.gj]).subscribe(function(m) {
                var u = x(m);
                m = u.next().value;
                u = u.next().value;
                if (!u) return Qd;
                m && u &&
                    d(e.Ob, k, l);
                return !0
            })
        };
        this.init(a.F)
    };
    Mt.prototype.init = function(a) {
        var b = this;
        this.Nc = a.global.document;
        this.kg.push(Nt(this));
        var c = {};
        this.jg = Vs(this.kg);
        this.jg.then(function() {
            b.ig = "&vis=" + Js(b.Nc) + "&uach=0&ms=0";
            c.paramString = b.ig;
            c.view_type = "DELAYED_IMPRESSION";
            b.Tg(c, function() {})
        })
    };
    var Nt = function(a) {
        return new Us(function(b) {
            var c = Ks(a.Nc);
            if (c)
                if (Js(a.Nc) === 3) {
                    var d = function() {
                        var e = a.Nc;
                        typeof e.removeEventListener === "function" && e.removeEventListener(c, d, !1);
                        b(!0)
                    };
                    Eh(a.Nc, c, d)
                } else b(!0)
        })
    };

    function Ot(a) {
        var b = Xh(a);
        return b ? b.g(N(function(c) {
            var d;
            c = (d = Zm(c).find(function(f) {
                return ql(Gm(f, 1)) === "Google Chrome"
            })) == null ? void 0 : ql(Gm(d, 2));
            if (!c) return !1;
            var e;
            return ((e = x(c.split(".").map(function(f) {
                return Number(f)
            })).next().value) != null ? e : 0) >= 121
        })) : Nh.W(a.i)
    };

    function Pt(a, b) {
        b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=reach&proto=" + encodeURIComponent(Sh(b.P()));
        a.L.M(b, {
            fa: "GET"
        }).sendNow()
    };

    function Qt(a) {
        return [{
            Kb: 2,
            Tc: !1,
            vc: !0,
            filterIds: Rt(a == null ? void 0 : a.productionFilterIds)
        }, {
            Kb: 2,
            Tc: !0,
            vc: !0,
            filterIds: Rt(a == null ? void 0 : a.testFilterIds)
        }, {
            Kb: 2,
            Tc: !1,
            vc: !1,
            filterIds: Rt(a == null ? void 0 : a.testFilterIds)
        }]
    }

    function Rt(a) {
        if (a !== void 0 && typeof BigInt === "function") return a.map(function(b) {
            return BigInt(b)
        })
    };
    var St = function(a) {
        so.call(this, a)
    };
    q(St, so);
    var Tt = function(a, b) {
        return gn(a, 1, b)
    };
    n = St.prototype;
    n.Cb = function(a) {
        return fn(this, 2, a)
    };
    n.Bb = function(a) {
        return fn(this, 3, a)
    };
    n.Uc = function(a) {
        return fn(this, 10, a)
    };
    n.ag = function() {
        return Xm(this, lt, 11)
    };
    n.Ig = function(a) {
        return $m(this, lt, 11, a)
    };
    St.U = "ads.branding.measurement.client.frontend.integrations.reach.ReachStatusMessage";
    St.prototype.P = uo([0, lo, go, -1, lo, -2, go, -1, bo, go, ot, mo, bo]);
    var Ut = function(a) {
            this.context = a;
            this.points = []
        },
        Vt = function(a, b) {
            Ca(function(c) {
                if (c.u == 1) return c.bf(2), c.A(b(), 4);
                if (c.u != 2) return c.return(c.V);
                c.pd();
                a.flush();
                return c.Bd(0)
            })
        };
    Ut.prototype.flush = function() {
        if (!(this.points.length <= 0)) {
            var a = new St;
            Tt(a, 9);
            var b = Qt().length;
            Im(a, 13, b == null ? b : kl(b));
            hn(a, 12, this.points);
            this.points.splice(0);
            Pt(this.context, a)
        }
    };

    function Wt() {
        this.blockSize = -1
    };

    function Xt(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.jd = Ha.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.Od = this.Pb = 0;
        this.D = [];
        this.Ci = a;
        this.mg = b;
        this.qj = Ha.Int32Array ? new Int32Array(64) : Array(64);
        Yt === void 0 && (Yt = Ha.Int32Array ? new Int32Array(Zt) : Zt);
        this.reset()
    }
    Na(Xt, Wt);
    for (var $t = [], au = 0; au < 63; au++) $t[au] = 0;
    var bu = [].concat(128, $t);
    Xt.prototype.reset = function() {
        this.Od = this.Pb = 0;
        this.D = Ha.Int32Array ? new Int32Array(this.mg) : Jb(this.mg)
    };
    var cu = function(a) {
        var b = a.jd;
        F(b.length == a.blockSize);
        for (var c = a.qj, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
        b = a.D[0] | 0;
        d = a.D[1] | 0;
        e = a.D[2] | 0;
        for (var f = a.D[3] | 0, g = a.D[4] | 0, h = a.D[5] | 0, k = a.D[6] | 0, l = a.D[7] | 0, m = 0; m < 64; m++) {
            var u = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                t = (l + ((g >>> 6 | g << 26) ^ (g >>> 11 |
                    g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^ ~g & k) + (Yt[m] | 0) | 0) + (c[m] | 0) | 0) | 0;
            l = k;
            k = h;
            h = g;
            g = f + t | 0;
            f = e;
            e = d;
            d = b;
            b = t + u | 0
        }
        a.D[0] = a.D[0] + b | 0;
        a.D[1] = a.D[1] + d | 0;
        a.D[2] = a.D[2] + e | 0;
        a.D[3] = a.D[3] + f | 0;
        a.D[4] = a.D[4] + g | 0;
        a.D[5] = a.D[5] + h | 0;
        a.D[6] = a.D[6] + k | 0;
        a.D[7] = a.D[7] + l | 0
    };
    Xt.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.Pb;
        if (typeof a === "string")
            for (; c < b;) this.jd[d++] = a.charCodeAt(c++), d == this.blockSize && (cu(this), d = 0);
        else if (Ka(a))
            for (; c < b;) {
                var e = a[c++];
                if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("Ma");
                this.jd[d++] = e;
                d == this.blockSize && (cu(this), d = 0)
            } else throw Error("Na");
        this.Pb = d;
        this.Od += b
    };
    Xt.prototype.digest = function() {
        var a = [],
            b = this.Od * 8;
        this.Pb < 56 ? this.update(bu, 56 - this.Pb) : this.update(bu, this.blockSize - (this.Pb - 56));
        for (var c = 63; c >= 56; c--) this.jd[c] = b & 255, b /= 256;
        cu(this);
        for (c = b = 0; c < this.Ci; c++)
            for (var d = 24; d >= 0; d -= 8) a[b++] = this.D[c] >> d & 255;
        return a
    };
    var Zt = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        Yt;

    function du() {
        Xt.call(this, 8, eu)
    }
    Na(du, Xt);
    var eu = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var po = function(a) {
        so.call(this, a)
    };
    q(po, so);
    po.U = "EventIdMessage";
    var fu = function(a) {
        so.call(this, a)
    };
    q(fu, so);
    fu.prototype.fc = function(a) {
        return en(this, 4, a)
    };
    fu.prototype.cg = function() {
        return Nm(this, 8, il, void 0 === Ok ? 2 : 4)
    };
    fu.prototype.Af = function(a) {
        return hn(this, 8, a)
    };
    fu.prototype.Jg = function(a) {
        return dn(this, 9, a)
    };
    fu.U = "ads.branding.measurement.client.frontend.integrations.reach.ContextIdMessage";
    var gu = [0, Zn, eo, -1];
    po.prototype.P = uo(gu);
    fu.prototype.P = uo([0, gu, fo, -1, jo, -3, no, fo]);
    var oo = function(a) {
        so.call(this, a, 1)
    };
    q(oo, so);
    oo.U = "proto2.bridge.MessageSet";
    var hu = {};
    oo[Pk] = hu;
    var iu = to(po, gu);
    hu[4156379] = {
        hk: new qo
    };
    var ju = function() {
        var a;
        this.message = a = a === void 0 ? new fu : a
    };
    ju.prototype.Uc = function(a) {
        var b = this.message;
        a = iu(Uh(a));
        this.message = $m(b, po, 1, a);
        return this
    };
    var ku = function(a, b) {
        var c = dn(a.message, 2, b.Kb === 2);
        b = dn(c, 3, !b.Tc);
        a.message = b;
        return a
    };
    ju.prototype.fc = function(a) {
        this.message = this.message.fc(Math.max(1, a));
        return this
    };
    var lu = function(a, b) {
            a.message = a.message.Af(b);
            return a
        },
        mu = function(a) {
            var b = Ms.match(/m\d{12}/g),
                c = Ms.match(/\d{8}/g);
            if (b && b.length > 0) {
                b = b[0].slice(1);
                c = a.message;
                var d = Number(b.slice(0, 8));
                c = en(c, 5, d);
                d = Number(b.slice(8, 10));
                c = en(c, 6, d);
                b = Number(b.slice(10, 12));
                b = en(c, 7, b);
                a.message = b;
                return a
            }
            if (c && c.length > 0) return b = en(a.message, 5, Number(c[0])), b = Im(b, 6), b = Im(b, 7), a.message = b, a;
            Ms === "unreleased" && (b = Im(a.message, 5), b = en(b, 6, 0), b = Im(b, 7), a.message = b);
            return a
        };
    ju.prototype.encode = function() {
        var a = this.message,
            b = Sh(a.P());
        b.length > 64 && (a = a.fc(1), b = Sh(a.P()));
        b.length > 64 && (a = Im(a, 6), b = Sh(a.P()));
        b.length > 64 && (a = Im(a, 7), b = Sh(a.P()));
        b.length > 64 && (a = Im(a, 5), b = Sh(a.P()));
        return b
    };

    function nu(a, b) {
        if (b === void 0 || b.length === 0) return Pt(a, Tt(new St, 7)), [ae(0)].filter(function(d) {
            return d !== void 0
        });
        var c = ae(-2147483648);
        return c === void 0 ? [] : b.map(function(d) {
            var e = d % c;
            d !== e && Pt(a, Tt(new St, 6));
            return e
        })
    };

    function ou(a, b) {
        var c = c === void 0 ? BigInt(0) : c;
        return {
            bucket: a,
            value: b ? 1 : 16384,
            filteringId: c
        }
    };

    function pu(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        if (b.length >= 24) throw Error("Oa");
        return [96 | b.length].concat(y(b))
    }

    function su(a) {
        if (a.length >= 24) throw Error("Pa");
        return [160 | a.length].concat(y(a.sort(uu).map(function(b) {
            return [].concat(y(b[0]), y(b[1]))
        }).flat()))
    }

    function vu(a) {
        if (a.length >= 24) throw Error("Qa");
        return [128 | a.length].concat(y(a.flat()))
    }

    function Bu(a, b) {
        for (var c = []; a > 0;) c.push(Number(a % BigInt(255))), a /= BigInt(255);
        for (; c.length < b;) c.push(0);
        return c.reverse()
    }

    function uu(a, b) {
        a = a[0];
        b = b[0];
        if (a.length !== b.length) return a.length - b.length;
        for (var c = 0; c < a.length; c++)
            if (a[c] !== b[c]) return a[c] - b[c];
        return 0
    };

    function Cu(a, b, c, d) {
        var e = ou(BigInt(c), d);
        b = {
            shared_info: JSON.stringify({
                api: "shared-storage",
                report_id: "PRE_WORKLET_ERROR",
                reporting_origin: "https://www.googleadservices.com",
                scheduled_report_time: String((new Date).getUTCSeconds()),
                version: "polyfill"
            }),
            aggregation_service_payloads: [],
            context_id: b,
            aggregation_coordinator_origin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com"
        };
        d ? (b.debug_key = "0", b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0",
                debug_cleartext_payload: Du([e])
            })) :
            b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0"
            });
        try {
            var f, g;
            (f = a.global) == null || (g = f.fetch) == null || g.call(f, "https://www.googleadservices.com/.well-known/private-aggregation/report-shared-storage", {
                method: "POST",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify(b)
            }).catch(function() {})
        } catch (h) {}
    }

    function Du(a) {
        a = su([
            [pu("data"), vu(a.map(function(b) {
                return su([
                    [pu("value"), [68].concat(y(Bu(BigInt(b.value), 4)))],
                    [pu("bucket"), [80].concat(y(Bu(b.bucket, 16)))],
                    [pu("filteringId"), [68].concat(y(Bu(b.filteringId, 4)))]
                ])
            }))],
            [pu("operation"), pu("histogram")]
        ]);
        return btoa(String.fromCharCode.apply(String, y(new Uint8Array(a))))
    };
    var Eu = {},
        Fu = (Eu[2] = "prod", Eu[1] = "canary", Eu);

    function Gu(a, b, c, d) {
        var e, f, g, h, k, l, m, u;
        return Ca(function(t) {
            switch (t.u) {
                case 1:
                    e = Qt(c);
                    f = function(r) {
                        e.forEach(function(w) {
                            var v, z = mu(ku(lu((new ju).Uc(c.escapedQueryId), (v = c.trafficTypes) != null ? v : [0]), w)).fc(-1).encode();
                            Cu(a, z, r, w.vc)
                        })
                    };
                    g = Oo(a);
                    if (g instanceof Error) return f(-16), h = Tt(new St, 8).Cb(g.name).Bb(g.message), Pt(a, h), t.return();
                    d.points.push(7);
                    k = Hu(a, c, e);
                    return t.A(c.experimentState.reachUseCreateWorklet ? Iu(a, b, f) : Ju(a, b, f), 2);
                case 2:
                    return l = t.V, t.A(k, 3);
                case 3:
                    return m = t.V, d.points.push(8),
                        u = e.map(function(r) {
                            var w, v, z;
                            return Ku(a, l, r, m, (w = c.deviceType) != null ? w : 1, c.escapedQueryId, (v = c.trafficTypes) != null ? v : [0], (z = c.isProductSplitVpidLogsExperiment) != null ? z : !1, function(C) {
                                var Q, T = mu(ku(lu((new ju).Uc(c.escapedQueryId), (Q = c.trafficTypes) != null ? Q : [0]).fc(-1), r)).encode();
                                Cu(a, T, C, r.vc)
                            })
                        }), t.A(Promise.all(u), 4);
                case 4:
                    d.points.push(9), t.Tb()
            }
        })
    }

    function Ju(a, b, c) {
        var d, e, f;
        return Ca(function(g) {
            switch (g.u) {
                case 1:
                    d = a.sharedStorage;
                    if (!d) return g.return(Promise.reject(Error("Ra")));
                    g.Ab(2);
                    return g.A(d.worklet.addModule(b), 4);
                case 4:
                    g.Dc(3);
                    break;
                case 2:
                    e = g.kb(), c(-17), f = Tt(new St, 1).Cb(e.name).Bb(e.message), Pt(a, f);
                case 3:
                    return g.return(d)
            }
        })
    }

    function Iu(a, b, c) {
        var d, e, f;
        return Ca(function(g) {
            if (g.u == 1) {
                d = a.sharedStorage;
                if (!d) return g.return(Promise.reject(Error("Ra")));
                g.Ab(2);
                return g.A(d.createWorklet(b, {
                    dataOrigin: "script-origin"
                }), 4)
            }
            if (g.u != 2) return g.return(g.V);
            e = g.kb();
            c(-17);
            f = Tt(new St, 1).Cb(e.name).Bb(e.message);
            Pt(a, f);
            return g.return(Promise.reject(e))
        })
    }

    function Hu(a, b, c) {
        var d, e, f;
        return Ca(function(g) {
            if (g.u == 1) return d = [].concat(y(new Set(c.map(function(h) {
                return h.Kb
            })))), e = d.map(function(h) {
                return Lu(a, b, h)
            }), g.A(Promise.all(e), 2);
            f = g.V;
            return g.return(new Map(f.map(function(h, k) {
                return [d[k], h]
            })))
        })
    }

    function Lu(a, b, c) {
        var d, e, f, g, h, k, l, m, u;
        return Ca(function(t) {
            switch (t.u) {
                case 1:
                    return e = (d = b.clientsideModelFilename) != null ? d : "model_person_country_code_XX_person_region_code_5858.json", f = void 0, g = 1, h = {
                        method: "GET"
                    }, k = 200, l = b.geoTargetMessage ? mt(b.geoTargetMessage) : void 0, m = (new St).Uc(b.escapedQueryId).Ig(l), t.Ab(2), t.A(a.global.fetch(Mu(c, e), h), 4);
                case 4:
                    f = t.V;
                    k = f.status;
                    if (f.ok) {
                        t.na(5);
                        break
                    }
                    return t.A(a.global.fetch(Mu(c, "model_person_country_code_XX_person_region_code_5858.json"), h), 6);
                case 6:
                    f =
                        t.V, g = 2;
                case 5:
                    t.Dc(3);
                    break;
                case 2:
                    u = t.kb(), k = -1, u instanceof Error && m.Cb(u.name).Bb(u.message);
                case 3:
                    var r = Tt(m, 2);
                    Im(r, 9, k == null ? k : kl(k));
                    if (!f || !f.ok) return r = gn(m, 4, 4), r = fn(r, 8, e), fn(r, 7, ""), Pt(a, m), t.return();
                    r = gn(m, 4, g);
                    fn(r, 7, g === 1 ? e : "");
                    Pt(a, m);
                    return t.A(f.text(), 7);
                case 7:
                    return t.return(t.V)
            }
        })
    }

    function Mu(a, b) {
        return "https://www.googletagservices.com/agrp/" + Fu[a] + "/" + b
    }

    function Ku(a, b, c, d, e, f, g, h, k) {
        var l, m, u, t, r, w, v;
        return Ca(function(z) {
            switch (z.u) {
                case 1:
                    l = d.get(c.Kb);
                    if (l === void 0) return z.return();
                    var C = ae(-2147483648);
                    if (C === void 0) C = -1;
                    else {
                        var Q = Number,
                            T = new du;
                        T.update(l);
                        var ma = T.digest();
                        T = BigInt(0);
                        ma = x(ma);
                        for (var H = ma.next(); !H.done; H = ma.next()) T = (T * BigInt(256) + BigInt(H.value)) % C;
                        C = Q(T)
                    }
                    m = C;
                    C = mu(ku(lu((new ju).Uc(f), g), c).fc(m));
                    C.message = C.message.Jg(h);
                    u = C.encode();
                    t = {
                        contextId: u,
                        aggregationCoordinatorOrigin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
                        filteringIdMaxBytes: 4
                    };
                    r = {
                        modelJson: l,
                        modelHash: m,
                        deviceType: e,
                        enableDebugMode: c.vc,
                        reportBrowserIdInsteadOfVPID: c.Tc,
                        filterIds: nu(a, c.filterIds)
                    };
                    w = b.run("google_reach", {
                        privateAggregationConfig: t,
                        data: r,
                        keepAlive: !0
                    });
                    if (w === void 0) {
                        z.na(2);
                        break
                    }
                    z.Ab(3);
                    return z.A(w, 5);
                case 5:
                    z.Dc(2);
                    break;
                case 3:
                    v = z.kb(), k(-18), C = v, ma = Tt(new St, 3).Cb((Q = C == null ? void 0 : C.name) != null ? Q : "unknown").Bb((T = C == null ? void 0 : C.message) != null ? T : ""), Pt(a, ma);
                case 2:
                    C = Tt(new St, 5), C = gn(C, 5, c.Kb === 1 ? 1 : 2), C = gn(C, 6, c.Tc ? 1 : 2),
                        Pt(a, C), z.Tb()
            }
        })
    };
    var Nu = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.Te = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "reach";
        this.Pc = new Map
    };
    n = Nu.prototype;
    n.start = function(a) {
        a.F && (this.context = a.F)
    };
    n.dispose = function() {
        this.Pc.forEach(function(a) {
            return void a.dispose()
        });
        this.Pc.clear()
    };
    n.ye = function(a, b, c, d, e) {
        var f = this,
            g = this.context;
        if (g) {
            var h = new Ut(g);
            Vt(h, function() {
                var k, l, m, u;
                return Ca(function(t) {
                    if (t.u == 1) {
                        h.points.push(1);
                        if (Km(b, nt, 1) && !tt(b).ue()) return t.return();
                        h.points.push(2);
                        return Oo(g) ? t.A(gd(Ot(g)), 2) : t.return()
                    }
                    if (t.u != 3) {
                        k = t.V;
                        if (!k) return t.return();
                        h.points.push(3);
                        l = new Ou(g, b, f.Te, c, d, h);
                        f.Pc.set(a, l);
                        return t.A(l.run(), 3)
                    }
                    e((u = (m = tt(b)) == null ? void 0 : m.td()) != null ? u : -1);
                    t.Tb()
                })
            })
        }
    };
    n.Mb = function(a) {
        var b;
        (b = this.Pc.get(a)) == null || b.dispose();
        this.Pc.delete(a)
    };
    n.handleEvent = function() {};
    var Ou = function(a, b, c, d, e, f) {
        this.context = a;
        this.metadata = b;
        this.Te = c;
        this.experimentState = d;
        this.Ta = e;
        this.he = f
    };
    Ou.prototype.run = function() {
        var a = this,
            b, c;
        return Ca(function(d) {
            if (d.u == 1) return b = {}, d.A(new Promise(function(e) {
                a.Ta(a.Te, b, e)
            }), 2);
            c = d.V;
            if (!c) return d.return();
            a.he.points.push(4);
            return d.A(Pu(a), 0)
        })
    };
    var Pu = function(a) {
            var b, c, d, e, f, g, h, k, l, m, u, t, r, w, v, z, C, Q;
            return Ca(function(T) {
                var ma = a.experimentState,
                    H = (l = (b = tt(a.metadata)) == null ? void 0 : b.Yf()) != null ? l : "",
                    D = (m = (c = tt(a.metadata)) == null ? void 0 : c.cg()) != null ? m : void 0,
                    fa = (d = tt(a.metadata)) == null ? void 0 : ql(Gm(d, 1)),
                    Cc = (u = (e = tt(a.metadata)) == null ? void 0 : (f = e.ag()) == null ? void 0 : f.Ya()) != null ? u : void 0,
                    ic = (t = (g = tt(a.metadata)) == null ? void 0 : bn(g, 8)) != null ? t : void 0,
                    qd = Qu;
                var Qa = (h = tt(a.metadata)) == null ? void 0 : Nm(h, 5, ll, Ok === Ok ? 2 : 4);
                qd = qd(a, (r = Qa) != null ?
                    r : void 0);
                Qa = Qu;
                var vg = (k = tt(a.metadata)) == null ? void 0 : Nm(k, 6, ll, Ok === Ok ? 2 : 4);
                v = {
                    experimentState: ma,
                    escapedQueryId: H,
                    trafficTypes: D,
                    isProductSplitVpidLogsExperiment: !0,
                    clientsideModelFilename: fa,
                    geoTargetMessage: Cc,
                    deviceType: ic,
                    productionFilterIds: qd,
                    testFilterIds: Qa(a, (w = vg) != null ? w : void 0)
                };
                if (a.experimentState.reachUseCreateWorklet) return Q = a.context.ef[2], a.he.points.push(10), T.A(Gu(a.context, Q, v, a.he), 0);
                z = a.context.ef[0];
                C = btoa(JSON.stringify(v));
                return T.A(ui(a.context.document, z, C), 0)
            })
        },
        Qu = function(a, b) {
            if (b !== void 0) return b.map(function(c) {
                var d;
                return String((d = ae(c)) != null ? d : 0)
            })
        };
    Ou.prototype.dispose = function() {};
    var Ru = Hf("m202602110101".match(/^m\d{10}$/g) !== null ? "m202602110101" : "current"),
        Su;
    a: {
        try {
            var Tu = new kg;
            Su = new Jf(Tu, "doubleclickbygoogle.com-omid", void 0, Ru);
            break a
        } catch (a) {}
        Su = void 0
    }
    var Uu = Su,
        Vu = {
            F: new No(void 0, void 0, void 0, Ru),
            pa: Uu
        };
    (function(a) {
        if (a && Ag(a)) {
            var b = zg(a);
            if (b) {
                a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-start2", {
                    method: "GET",
                    cache: "no-cache",
                    keepalive: !0,
                    mode: "no-cors"
                });
                try {
                    b("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-later2", {
                        method: "GET",
                        cache: "no-cache",
                        mode: "no-cors",
                        activateAfter: 96E4
                    })
                } catch (c) {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-fallback2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                }
                a.Ag.subscribe(function() {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-pagehide2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                })
            }
        }
    })(Vu.F);
    (function(a, b, c) {
        var d = new Zs("impression"),
            e = new Zs("begin to render"),
            f = new Zs("unmeasurable"),
            g = new Zs("viewable"),
            h = new Zs("reach vpid"),
            k = new Xs(d, h, e, g, f),
            l = new xt,
            m = new Lt(d.event);
        b = new Gt(l, c, d.event, e.event, f.event, g.event, b);
        h = new Nu(h.event);
        var u = new $s(a, k, l, m, b, h);
        u.start();
        return {
            dispose: function() {
                return void u.dispose()
            },
            colleagues: {
                ck: m,
                Ek: b,
                Ak: h
            }
        }
    })(Vu, 7);
}).call(this);