/** 
 * onetrust-banner-sdk
 * v202511.1.0
 * by OneTrust LLC
 * Copyright 2025 
 */
(() => {
    var G = function(e, t) {
        return (G = Object.setPrototypeOf || ({
                __proto__: []
            }
            instanceof Array ? function(e, t) {
                e.__proto__ = t
            } : function(e, t) {
                for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o])
            }))(e, t)
    };

    function x(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

        function o() {
            this.constructor = e
        }
        G(e, t), e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o)
    }
    var H, R = function() {
        return (R = Object.assign || function(e) {
            for (var t, o = 1, n = arguments.length; o < n; o++)
                for (var r in t = arguments[o]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e
        }).apply(this, arguments)
    };

    function F(e, s, a, l) {
        return new(a = a || Promise)(function(o, t) {
            function n(e) {
                try {
                    i(l.next(e))
                } catch (e) {
                    t(e)
                }
            }

            function r(e) {
                try {
                    i(l.throw(e))
                } catch (e) {
                    t(e)
                }
            }

            function i(e) {
                var t;
                e.done ? o(e.value) : ((t = e.value) instanceof a ? t : new a(function(e) {
                    e(t)
                })).then(n, r)
            }
            i((l = l.apply(e, s || [])).next())
        })
    }

    function M(n, r) {
        var i, s, a, l = {
                label: 0,
                sent: function() {
                    if (1 & a[0]) throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            },
            c = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
        return c.next = e(0), c.throw = e(1), c.return = e(2), "function" == typeof Symbol && (c[Symbol.iterator] = function() {
            return this
        }), c;

        function e(o) {
            return function(e) {
                var t = [o, e];
                if (i) throw new TypeError("Generator is already executing.");
                for (; l = c && t[c = 0] ? 0 : l;) try {
                    if (i = 1, s && (a = 2 & t[0] ? s.return : t[0] ? s.throw || ((a = s.return) && a.call(s), 0) : s.next) && !(a = a.call(s, t[1])).done) return a;
                    switch (s = 0, (t = a ? [2 & t[0], a.value] : t)[0]) {
                        case 0:
                        case 1:
                            a = t;
                            break;
                        case 4:
                            return l.label++, {
                                value: t[1],
                                done: !1
                            };
                        case 5:
                            l.label++, s = t[1], t = [0];
                            continue;
                        case 7:
                            t = l.ops.pop(), l.trys.pop();
                            continue;
                        default:
                            if (!(a = 0 < (a = l.trys).length && a[a.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                l = 0;
                                continue
                            }
                            if (3 === t[0] && (!a || t[1] > a[0] && t[1] < a[3])) l.label = t[1];
                            else if (6 === t[0] && l.label < a[1]) l.label = a[1], a = t;
                            else {
                                if (!(a && l.label < a[2])) {
                                    a[2] && l.ops.pop(), l.trys.pop();
                                    continue
                                }
                                l.label = a[2], l.ops.push(t)
                            }
                    }
                    t = r.call(n, l)
                } catch (e) {
                    t = [6, e], s = 0
                } finally {
                    i = a = 0
                }
                if (5 & t[0]) throw t[1];
                return {
                    value: t[0] ? t[1] : void 0,
                    done: !0
                }
            }
        }
    }

    function U() {
        for (var e = 0, t = 0, o = arguments.length; t < o; t++) e += arguments[t].length;
        for (var n = Array(e), r = 0, t = 0; t < o; t++)
            for (var i = arguments[t], s = 0, a = i.length; s < a; s++, r++) n[r] = i[s];
        return n
    }(e = H = H || {})[e.ACTIVE = 0] = "ACTIVE", e[e.ALWAYS_ACTIVE = 1] = "ALWAYS_ACTIVE", e[e.EXPIRED = 2] = "EXPIRED", e[e.NO_CONSENT = 3] = "NO_CONSENT", e[e.OPT_OUT = 4] = "OPT_OUT", e[e.PENDING = 5] = "PENDING", e[e.WITHDRAWN = 6] = "WITHDRAWN";
    var q = setTimeout;

    function j(e) {
        return Boolean(e && void 0 !== e.length)
    }

    function K() {}

    function z(e) {
        if (!(this instanceof z)) throw new TypeError("Promises must be constructed via new");
        if ("function" != typeof e) throw new TypeError("not a function");
        this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], Z(e, this)
    }

    function W(o, n) {
        for (; 3 === o._state;) o = o._value;
        0 === o._state ? o._deferreds.push(n) : (o._handled = !0, z._immediateFn(function() {
            var e, t = 1 === o._state ? n.onFulfilled : n.onRejected;
            if (null === t)(1 === o._state ? Y : J)(n.promise, o._value);
            else {
                try {
                    e = t(o._value)
                } catch (e) {
                    return void J(n.promise, e)
                }
                Y(n.promise, e)
            }
        }))
    }

    function Y(t, e) {
        try {
            if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
            if (e && ("object" == typeof e || "function" == typeof e)) {
                var o = e.then;
                if (e instanceof z) return t._state = 3, t._value = e, void X(t);
                if ("function" == typeof o) return void Z((n = o, r = e, function() {
                    n.apply(r, arguments)
                }), t)
            }
            t._state = 1, t._value = e, X(t)
        } catch (e) {
            J(t, e)
        }
        var n, r
    }

    function J(e, t) {
        e._state = 2, e._value = t, X(e)
    }

    function X(e) {
        2 === e._state && 0 === e._deferreds.length && z._immediateFn(function() {
            e._handled || z._unhandledRejectionFn(e._value)
        });
        for (var t = 0, o = e._deferreds.length; t < o; t++) W(e, e._deferreds[t]);
        e._deferreds = null
    }

    function Q(e, t, o) {
        this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = o
    }

    function Z(e, t) {
        var o = !1;
        try {
            e(function(e) {
                o || (o = !0, Y(t, e))
            }, function(e) {
                o || (o = !0, J(t, e))
            })
        } catch (e) {
            o || (o = !0, J(t, e))
        }
    }

    function $() {}
    z.prototype.catch = function(e) {
        return this.then(null, e)
    }, z.prototype.then = function(e, t) {
        var o = new this.constructor(K);
        return W(this, new Q(e, t, o)), o
    }, z.prototype.finally = function(t) {
        var o = this.constructor;
        return this.then(function(e) {
            return o.resolve(t()).then(function() {
                return e
            })
        }, function(e) {
            return o.resolve(t()).then(function() {
                return o.reject(e)
            })
        })
    }, z.all = function(t) {
        return new z(function(r, i) {
            if (!j(t)) return i(new TypeError("Promise.all accepts an array"));
            var s = Array.prototype.slice.call(t);
            if (0 === s.length) return r([]);
            var a = s.length;
            for (var e = 0; e < s.length; e++) ! function t(o, e) {
                try {
                    if (e && ("object" == typeof e || "function" == typeof e)) {
                        var n = e.then;
                        if ("function" == typeof n) return void n.call(e, function(e) {
                            t(o, e)
                        }, i)
                    }
                    s[o] = e, 0 == --a && r(s)
                } catch (e) {
                    i(e)
                }
            }(e, s[e])
        })
    }, z.resolve = function(t) {
        return t && "object" == typeof t && t.constructor === z ? t : new z(function(e) {
            e(t)
        })
    }, z.reject = function(o) {
        return new z(function(e, t) {
            t(o)
        })
    }, z.race = function(r) {
        return new z(function(e, t) {
            if (!j(r)) return t(new TypeError("Promise.race accepts an array"));
            for (var o = 0, n = r.length; o < n; o++) z.resolve(r[o]).then(e, t)
        })
    }, z._immediateFn = "function" == typeof setImmediate ? function(e) {
        setImmediate(e)
    } : function(e) {
        q(e, 0)
    }, z._unhandledRejectionFn = function(e) {
        "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
    }, $.prototype.initPolyfill = function() {
        this.initArrayIncludesPolyfill(), this.initObjectAssignPolyfill(), this.initArrayFillPolyfill(), this.initClosestPolyfill(), this.initIncludesPolyfill(), this.initEndsWithPoly(), this.initCustomEventPolyfill(), this.promisesPolyfil()
    }, $.prototype.initArrayIncludesPolyfill = function() {
        Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", {
            value: function(e) {
                for (var t = [], o = 1; o < arguments.length; o++) t[o - 1] = arguments[o];
                if (null == this) throw new TypeError("Array.prototype.includes called on null or undefined");
                var n = Object(this),
                    r = parseInt(n.length, 10) || 0;
                if (0 !== r) {
                    var i, s, a = t[1] || 0;
                    for (0 <= a ? i = a : (i = r + a) < 0 && (i = 0); i < r;) {
                        if (e === (s = n[i]) || e != e && s != s) return !0;
                        i++
                    }
                }
                return !1
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initEndsWithPoly = function() {
        String.prototype.endsWith || Object.defineProperty(String.prototype, "endsWith", {
            value: function(e, t) {
                return (void 0 === t || t > this.length) && (t = this.length), this.substring(t - e.length, t) === e
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initClosestPolyfill = function() {
        Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector), Element.prototype.closest || Object.defineProperty(Element.prototype, "closest", {
            value: function(e) {
                var t = this;
                do {
                    if (t.matches(e)) return t
                } while (null !== (t = t.parentElement || t.parentNode) && 1 === t.nodeType);
                return null
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initIncludesPolyfill = function() {
        String.prototype.includes || Object.defineProperty(String.prototype, "includes", {
            value: function(e, t) {
                return !((t = "number" != typeof t ? 0 : t) + e.length > this.length) && -1 !== this.indexOf(e, t)
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initObjectAssignPolyfill = function() {
        "function" != typeof Object.assign && Object.defineProperty(Object, "assign", {
            value: function(e, t) {
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                for (var o = Object(e), n = 1; n < arguments.length; n++) {
                    var r = arguments[n];
                    if (null != r)
                        for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (o[i] = r[i])
                }
                return o
            },
            writable: !0,
            configurable: !0
        })
    }, $.prototype.initArrayFillPolyfill = function() {
        Array.prototype.fill || Object.defineProperty(Array.prototype, "fill", {
            value: function(e) {
                if (null == this) throw new TypeError("this is null or not defined");
                for (var t = Object(this), o = t.length >>> 0, n = arguments[1] >> 0, r = n < 0 ? Math.max(o + n, 0) : Math.min(n, o), n = arguments[2], n = void 0 === n ? o : n >> 0, i = n < 0 ? Math.max(o + n, 0) : Math.min(n, o); r < i;) t[r] = e, r++;
                return t
            }
        })
    }, $.prototype.initCustomEventPolyfill = function() {
        if ("function" == typeof window.CustomEvent) return !1;

        function e(e, t) {
            t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            };
            var o = document.createEvent("CustomEvent");
            return o.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), o
        }
        e.prototype = window.Event.prototype, window.CustomEvent = e
    }, $.prototype.insertViewPortTag = function() {
        var e = document.querySelector('meta[name="viewport"]'),
            t = document.createElement("meta");
        t.name = "viewport", t.content = "width=device-width, initial-scale=1", e || document.head.appendChild(t)
    }, $.prototype.promisesPolyfil = function() {
        "undefined" == typeof Promise && (window.Promise = z)
    };
    var ee, te, oe, ne, re, ie, se, ae, le, ce, de, ue, pe, Ce, ge, he, ye, fe, Se, me, ve, Te, Pe, Ae, ke, Ie, be, Le, _e, o, Ee, Oe, De, Ve, we, Ne, Be, Ge = new $,
        xe = ((e = ee = ee || {})[e.Unknown = 0] = "Unknown", e[e.BannerCloseButton = 1] = "BannerCloseButton", e[e.ConfirmChoiceButton = 2] = "ConfirmChoiceButton", e[e.AcceptAll = 3] = "AcceptAll", e[e.RejectAll = 4] = "RejectAll", e[e.BannerSaveSettings = 5] = "BannerSaveSettings", e[e.ContinueWithoutAcceptingButton = 6] = "ContinueWithoutAcceptingButton", (e = te = te || {})[e.Banner = 1] = "Banner", e[e.PC = 2] = "PC", e[e.API = 3] = "API", (e = oe = oe || {}).AcceptAll = "AcceptAll", e.RejectAll = "RejectAll", e.UpdateConsent = "UpdateConsent", (e = ne = ne || {})[e.Purpose = 1] = "Purpose", e[e.SpecialFeature = 2] = "SpecialFeature", (e = re = re || {}).Legal = "legal", e.UserFriendly = "user_friendly", (e = ie = ie || {}).Top = "top", e.Bottom = "bottom", (e = se = se || {})[e.Banner = 0] = "Banner", e[e.PrefCenterHome = 1] = "PrefCenterHome", e[e.VendorList = 2] = "VendorList", e[e.CookieList = 3] = "CookieList", e[e.IabIllustrations = 4] = "IabIllustrations", (e = ae = ae || {})[e.RightArrow = 39] = "RightArrow", e[e.LeftArrow = 37] = "LeftArrow", e[e.UpArrow = 38] = "UpArrow", e[e.DownArrow = 40] = "DownArrow", (e = le = le || {}).AfterTitle = "AfterTitle", e.AfterDescription = "AfterDescription", e.AfterDPD = "AfterDPD", (e = ce = ce || {}).PlusMinus = "Plusminus", e.Caret = "Caret", e.NoAccordion = "NoAccordion", (e = de = de || {}).Consent = "Consent", e.LI = "LI", e.AddtlConsent = "AddtlConsent", (e = ue = ue || {}).Iab1Pub = "eupubconsent", e.Iab2Pub = "eupubconsent-v2", e.Iab1Eu = "euconsent", e.Iab2Eu = "euconsent-v2", (e = pe = pe || {})[e.Disabled = 0] = "Disabled", e[e.Consent = 1] = "Consent", e[e.LegInt = 2] = "LegInt", (e = Ce = Ce || {})[e["Banner - Allow All"] = 1] = "Banner - Allow All", e[e["Banner - Reject All"] = 2] = "Banner - Reject All", e[e["Banner - Close"] = 3] = "Banner - Close", e[e["Preference Center - Allow All"] = 4] = "Preference Center - Allow All", e[e["Preference Center - Reject All"] = 5] = "Preference Center - Reject All", e[e["Preference Center - Confirm"] = 6] = "Preference Center - Confirm", e[e["GPC value changed"] = 7] = "GPC value changed", (e = ge = ge || {}).Active = "1", e.InActive = "0", (e = he = he || {}).Host = "Host", e.GenVendor = "GenVen", (e = ye = ye || {})[e.Host = 1] = "Host", e[e.GenVen = 2] = "GenVen", e[e.HostAndGenVen = 3] = "HostAndGenVen", (e = fe = fe || {})[e.minDays = 1] = "minDays", e[e.maxDays = 30] = "maxDays", e[e.maxYear = 31536e3] = "maxYear", e[e.maxSecToDays = 86400] = "maxSecToDays", (e = Se = Se || {})[e.RTL = 0] = "RTL", e[e.LTR = 1] = "LTR", (e = me = me || {})[e.GoogleVendor = 1] = "GoogleVendor", e[e.GeneralVendor = 2] = "GeneralVendor", (e = xt = xt || {})[e.Days = 1] = "Days", e[e.Weeks = 7] = "Weeks", e[e.Months = 30] = "Months", e[e.Years = 365] = "Years", (e = ve = ve || {}).Checkbox = "Checkbox", e.Toggle = "Toggle", (e = Te = Te || {}).SlideIn = "Slide_In", e.FadeIn = "Fade_In", e.RemoveAnimation = "Remove_Animation", (e = Pe = Pe || {}).Link = "Link", e.Icon = "Icon", (e = Ae = Ae || {}).consent = "consent", e.set = "set", (e = ke = ke || {}).update = "update", e.default = "default", e.ads_data_redaction = "ads_data_redaction", (e = Ie = Ie || {}).analytics_storage = "analytics_storage", e.ad_storage = "ad_storage", e.functionality_storage = "functionality_storage", e.personalization_storage = "personalization_storage", e.security_storage = "security_storage", e.ad_user_data = "ad_user_data", e.ad_personalization = "ad_personalization", e.region = "region", e.wait_for_update = "wait_for_update", (e = be = be || {}).granted = "granted", e.denied = "denied", 0, (e = Le = Le || {}).OBJECT_TO_LI = "ObjectToLI", e.LI_ACTIVE_IF_LEGAL_BASIS = "LIActiveIfLegalBasis", (e = _e = _e || {}).cookies = "cookies", e.vendors = "vendors", (e = o = o || {}).GDPR = "GDPR", e.CCPA = "CCPA", e.IAB2 = "IAB2", e.IAB2V2 = "IAB2V2", e.GENERIC = "GENERIC", e.LGPD = "LGPD", e.GENERIC_PROMPT = "GENERIC_PROMPT", e.CPRA = "CPRA", e.CDPA = "CDPA", e.DELAWARE = "DELAWARE", e.IOWA = "IOWA", e.NEBRASKA = "NEBRASKA", e.USNATIONAL = "USNATIONAL", e.CUSTOM = "CUSTOM", e.FLORIDA = "FLORIDA", e.COLORADO = "COLORADO", e.CONNECTICUT = "CTDPA", e.MONTANA = "MONTANA", e.TEXAS = "TEXAS", e.OREGON = "OREGON", e.TENNESSEE = "TENNESSEE", e.NEWJERSEY = "NEWJERSEY", e.NEWHAMPSHIRE = "NEWHAMPSHIRE", e.UCPA = "UCPA", e.VIRGINIA = "VIRGINIA", {
            ca: o.CPRA,
            va: o.CDPA,
            co: o.COLORADO,
            or: o.OREGON,
            ct: o.CONNECTICUT,
            fl: o.FLORIDA,
            mt: o.MONTANA,
            tx: o.TEXAS,
            de: o.DELAWARE,
            ia: o.IOWA,
            ne: o.NEBRASKA,
            tn: o.TENNESSEE,
            nj: o.NEWJERSEY,
            nh: o.NEWHAMPSHIRE,
            ut: o.UCPA
        }),
        h = ((e = Ee = Ee || {}).ACCEPT_ALL = "ACCEPT_ALL", e.REJECT_ALL = "REJECT_ALL", e.SAVE_PREFERENCE = "SAVE_PREFERENCE", (e = Oe = Oe || {}).Name = "OTGPPConsent", e[e.ChunkSize = 4e3] = "ChunkSize", e.ChunkCountParam = "GPPCookiesCount", e.gppSid = "gppSid", (e = De = De || {}).MspaCoveredTransaction = "IsMSPAEnabled", e.MspaOptOutOptionMode = "Opt-Out", e.MspaServiceProviderMode = "Service Provider", 0, (e = Ve = Ve || {}).GpcSegmentType = "GpcSegmentType", e.Gpc = "Gpc", (e = we = we || {}).SensitiveDataProcessing = "SensitiveDataProcessing", e.KnownChildSensitiveDataConsents = "KnownChildSensitiveDataConsents", (e = Ne = Ne || {}).CPRA = "usca", e.CCPA = "usca", e.CDPA = "usva", e.OREGON = "usor", e.USNATIONAL = "usnat", e.COLORADO = "usco", e.FLORIDA = "usfl", e.CTDPA = "usct", e.MONTANA = "usmt", e.TEXAS = "ustx", e.DELAWARE = "usde", e.IOWA = "usia", e.NEBRASKA = "usne", e.TENNESSEE = "ustn", e.NEWJERSEY = "usnj", e.NEWHAMPSHIRE = "usnh", e.UCPA = "usut", e.VIRGINIA = "usva", e.IAB2V2 = "tcfeuv2", (e = Be = Be || {})[e.CPRA = 8] = "CPRA", e[e.CCPA = 8] = "CCPA", e[e.CDPA = 9] = "CDPA", e[e.OREGON = 15] = "OREGON", e[e.USNATIONAL = 7] = "USNATIONAL", e[e.COLORADO = 10] = "COLORADO", e[e.FLORIDA = 13] = "FLORIDA", e[e.MONTANA = 14] = "MONTANA", e[e.TEXAS = 16] = "TEXAS", e[e.DELAWARE = 17] = "DELAWARE", e[e.IOWA = 18] = "IOWA", e[e.NEBRASKA = 19] = "NEBRASKA", e[e.NEWHAMPSHIRE = 20] = "NEWHAMPSHIRE", e[e.NEWJERSEY = 21] = "NEWJERSEY", e[e.TENNESSEE = 22] = "TENNESSEE", e[e.UCPA = 11] = "UCPA", e[e.VIRGINIA = 9] = "VIRGINIA", e[e.CTDPA = 12] = "CTDPA", e[e.IAB2V2 = 2] = "IAB2V2", 0, 0, 0, 0, 0, {
            AWAITING_RE_CONSENT: "AwaitingReconsent",
            CONSENT_ID: "consentId",
            GEO_LOCATION: "geolocation",
            INTERACTION_COUNT: "interactionCount",
            IS_IAB_GLOBAL: "isIABGlobal",
            NOT_LANDING_PAGE: "NotLandingPage",
            GEO: "geo",
            GPC_ENABLED: "isGpcEnabled",
            GPC_Browser_Flag: "browserGpcFlag",
            IS_ANONYMOUS_CONSENT: "isAnonUser",
            IDENTIFIER_TYPE: "identifierType",
            PREV_USER_CONSENT: "iType",
            INTERACTION_TYPE: "intType",
            GROUPS: "groups",
            HEALTH_SIGNATURE_AUTHORIZATION: "healthAuth"
        }),
        y = {
            ADDITIONAL_CONSENT_STRING: "OTAdditionalConsentString",
            ALERT_BOX_CLOSED: "OptanonAlertBoxClosed",
            OPTANON_CONSENT: "OptanonConsent",
            EU_PUB_CONSENT: "eupubconsent-v2",
            EU_CONSENT: "euconsent-v2",
            SELECTED_VARIANT: "OTVariant",
            OT_PREVIEW: "otpreview",
            GPP_CONSENT: Oe.Name
        },
        He = "CONFIRMED",
        Re = "OPT_OUT",
        Fe = "NO_CHOICE",
        Me = "NOTGIVEN",
        Ue = "NO_OPT_OUT",
        f = {
            ALWAYS_INACTIVE: "always inactive",
            ALWAYS_ACTIVE: "always active",
            ACTIVE: "active",
            INACTIVE_LANDING_PAGE: "inactive landingpage",
            INACTIVE: "inactive",
            IMPLIED_CONSENT: "implied consent",
            GPC: "gpc",
            DNT: "dnt"
        },
        qe = {
            LOCAL: "LOCAL",
            TEST: "TEST",
            LOCAL_TEST: "LOCAL_TEST",
            PRODUCTION: "PRODUCTION"
        },
        je = "data-document-language",
        Ke = "data-language",
        ze = "otCookieSettingsButton.json",
        We = "otCookieSettingsButtonRtl.json",
        Ye = "otCenterRounded",
        Je = "otFlat",
        Xe = "otFloatingRoundedCorner",
        Qe = "otFloatingFlat",
        Ze = "otFloatingRoundedIcon",
        $e = "otFloatingRounded",
        et = "otChoicesBanner",
        tt = "otNoBanner",
        ot = "otPcCenter",
        nt = "otPcList",
        rt = "otPcPanel",
        it = "otPcPopup",
        st = "otPcTab",
        at = "hidebanner",
        lt = 210,
        ct = 160,
        dt = 105,
        ut = 30,
        pt = "--ot-footer-space",
        Ct = ((e = {})[xt.Days] = "PCenterVendorListLifespanDay", e[xt.Weeks] = "LfSpnWk", e[xt.Months] = "PCenterVendorListLifespanMonth", e[xt.Years] = "LfSpnYr", e),
        gt = "DNAC",
        ht = "Category",
        yt = "Host",
        ft = "General Vendor",
        St = "VendorService",
        mt = "aria-label",
        vt = "aria-hidden",
        Tt = "ad_storage",
        Pt = "user_data",
        At = "BRANCH",
        kt = "COOKIE",
        It = "IAB2V2_SPL_PURPOSE",
        bt = "IAB2V2_FEATURE",
        Lt = "IAB2V2_SPL_FEATURE",
        _t = ["IAB2_PURPOSE", "IAB2_STACK", "IAB2_FEATURE", "IAB2_SPL_PURPOSE", "IAB2_SPL_FEATURE", "IAB2V2_PURPOSE", "IAB2V2_SPL_PURPOSE", "IAB2V2_FEATURE", "IAB2V2_SPL_FEATURE", "IAB2V2_STACK"],
        Et = ["COOKIE", "BRANCH", "IAB2_STACK", "IAB2V2_STACK"],
        Ot = ["IAB2_PURPOSE", "IAB2_SPL_FEATURE", "IAB2V2_PURPOSE", "IAB2V2_SPL_FEATURE"],
        Dt = ["IAB2_FEATURE", "IAB2_SPL_PURPOSE", "IAB2V2_FEATURE", "IAB2V2_SPL_PURPOSE"],
        Vt = ["IAB2_PURPOSE", "IAB2_SPL_PURPOSE", "IAB2_FEATURE", "IAB2_SPL_FEATURE"],
        wt = {
            IAB2V2: "pur",
            IFE2V2: "ft",
            ISP2V2: "spl_pur",
            ISF2V2: "spl_ft"
        },
        Nt = {
            pur: "purposes",
            ft: "features",
            spl_pur: "specialPurposes",
            spl_ft: "specialFeatures"
        },
        S = new function() {};

    function d(e, t, o) {
        void 0 === o && (o = !1);

        function n(e) {
            return e ? (";" !== (e = e.trim()).charAt(e.length - 1) && (e += ";"), e.trim()) : null
        }
        var i = n(e.getAttribute("style")),
            s = n(t),
            t = "",
            t = o && i ? (() => {
                for (var e = i.split(";").concat(s.split(";")).filter(function(e) {
                        return 0 !== e.length
                    }), t = "", o = "", n = e.length - 1; 0 <= n; n--) {
                    var r = e[n].substring(0, e[n].indexOf(":") + 1).trim();
                    t.indexOf(r) < 0 && (t += r, o += e[n] + ";")
                }
                return o
            })() : s;
        e.setAttribute("style", t)
    }
    a.insertAfter = function(e, t) {
        t.parentNode.insertBefore(e, t.nextSibling)
    }, a.insertBefore = function(e, t) {
        t.parentNode.insertBefore(e, t)
    }, a.inArray = function(e, t) {
        return t.indexOf(e)
    }, a.ajax = function(e) {
        var t = null,
            o = new XMLHttpRequest,
            n = e.type,
            r = e.contentType,
            i = e.data,
            s = e.success,
            a = e.token,
            t = e.error;
        o.open(n, e.url, !e.sync), o.setRequestHeader("Content-Type", r), a && o.setRequestHeader("Authorization", a), o.withCredentials = !1, o.onload = function() {
            var e;
            200 <= this.status && this.status < 400 ? (e = JSON.parse(this.responseText), s(e)) : t({
                message: "Error Loading Data",
                statusCode: this.status
            })
        }, o.onerror = function(e) {
            t(e)
        }, "post" === n.toLowerCase() || "put" === n.toLowerCase() ? o.send(i) : o.send()
    }, a.prevNextHelper = function(o, e, n) {
        var r = [];

        function i(e, t, o) {
            t[e] && o ? o.includes(".") ? (t[e].classList[0] || t[e].classList.value && t[e].classList.value.includes(o.split(".")[1])) && r.push(t[e]) : o.includes("#") ? t[e].id === o.split("#")[1] && r.push(t[e]) : t[e].tagName === document.createElement(o.trim()).tagName && r.push(t[e]) : t[e] && r.push(t[e])
        }
        return "string" == typeof e ? Array.prototype.forEach.call(document.querySelectorAll(e), function(e, t) {
            i(o, e, n)
        }) : i(o, e, n), r
    }, a.browser = function() {
        var e, t, o;
        return navigator.sayswho = (o = (t = navigator.userAgent).match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [], /trident/i.test(o[1]) ? "IE " + ((e = /\brv[ :]+(\d+)/g.exec(t) || [])[1] || "") : "Chrome" === o[1] && null != (e = t.match(/\b(OPR|Edge)\/(\d+)/)) ? e.slice(1).join(" ").replace("OPR", "Opera") : (o = o[2] ? [o[1], o[2]] : [navigator.appName, navigator.appVersion, "-?"], null != (e = t.match(/version\/(\d+)/i)) && o.splice(1, 1, e[1]), o.join(" "))), {
            version: parseInt(navigator.sayswho.split(" ")[1]),
            type: navigator.sayswho.split(" ")[0],
            userAgent: navigator.userAgent
        }
    }, a.isNodeList = function(e) {
        e = Object.prototype.toString.call(e);
        return "[object NodeList]" === e || "[object Array]" === e
    }, a.getInnerHtmlContent = function(e) {
        return a.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createHTML(e) : e
    }, a.getScriptUrl = function(e) {
        return a.isCspTrustedType() ? window.OtTrustedType.TrustedTypePolicy.createScriptURL(e) : e
    }, a.isCspTrustedType = function() {
        var e;
        return (null == (e = window.OtTrustedType) ? void 0 : e.isCspTrustedTypeEnabled) && (null == (e = window.OtTrustedType) ? void 0 : e.TrustedTypePolicy)
    }, a.prototype.fadeOut = function(e) {
        var t = this;
        if (void 0 === e && (e = 60), 1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) d(this.el[o], "\n                    visibility: hidden;\n                    opacity: 0;\n                    transition: visibility 0s " + e + "ms, opacity " + e + "ms linear;\n                ", !0);
        var n = setInterval(function() {
            if (1 <= t.el.length)
                for (var e = 0; e < t.el.length; e++) t.el[e].style.opacity <= 0 && (d(t.el[e], "display: none;", !0), clearInterval(n), "optanon-popup-bg" === t.el[e].id) && t.el[e].removeAttribute("style")
        }, e);
        return this
    }, a.prototype.hide = function() {
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) d(this.el[e], "display: none;", !0), this.el[e].setAttribute(vt, !0);
        else a.isNodeList(this.el) || (d(this.el, "display: none;", !0), this.el.setAttribute(vt, !0));
        return this
    }, a.prototype.show = function(e) {
        if (void 0 === e && (e = "block"), 1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) d(this.el[t], "display: " + e + ";", !0), this.el[t].removeAttribute(vt);
        else a.isNodeList(this.el) || (d(this.el, "display: " + e + ";", !0), this.el.removeAttribute(vt));
        return this
    }, a.prototype.remove = function() {
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) this.el[e].parentNode.removeChild(this.el[e]);
        else this.el.parentNode.removeChild(this.el);
        return this
    }, a.prototype.css = function(e) {
        if (e)
            if (1 <= this.el.length) {
                if (!e.includes(":")) return this.el[0].style[e];
                for (var t = 0; t < this.el.length; t++) d(this.el[t], e)
            } else {
                if (!e.includes(":")) return this.el.style[e];
                d(this.el, e)
            }
        return this
    }, a.prototype.removeClass = function(e) {
        if (1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) this.el[t].classList ? this.el[t].classList.remove(e) : this.el[t].className = this.el[t].className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ");
        else this.el.classList ? this.el.classList.remove(e) : this.el.className = this.el.className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ");
        return this
    }, a.prototype.addClass = function(e) {
        if (1 <= this.el.length)
            for (var t = 0; t < this.el.length; t++) this.el[t].classList ? this.el[t].classList.add(e) : this.el[t].className += " " + e;
        else this.el.classList ? this.el.classList.add(e) : this.el.className += " " + e;
        return this
    }, a.prototype.on = function(r, i, s) {
        var e = this;
        if ("string" != typeof i)
            if (this.el && "HTML" === this.el.nodeName && "load" === r || "resize" === r || "scroll" === r) switch (r) {
                    case "load":
                        window.onload = i;
                        break;
                    case "resize":
                        window.onresize = i;
                        break;
                    case "scroll":
                        window.onscroll = i
                } else if (this.el && 1 <= this.el.length)
                    for (var t = 0; t < this.el.length; t++) this.el[t].addEventListener(r, i);
                else this.el && this.el instanceof Element && this.el.addEventListener(r, i);
        else if (this.el && "HTML" === this.el.nodeName && "load" === r || "resize" === r || "scroll" === r) switch (r) {
            case "load":
                window.onload = s;
                break;
            case "resize":
                window.onresize = s;
                break;
            case "scroll":
                window.onscroll = s
        } else {
            var a = function(o) {
                var n = o.target;
                e.el.eventExecuted = !0, Array.prototype.forEach.call(document.querySelectorAll(i), function(e, t) {
                    Bt["" + r + i] && delete Bt["" + r + i], e.addEventListener(r, s), e === n && s && s.call(e, o)
                }), e.el && e.el[0] ? e.el[0].removeEventListener(r, a) : e.el && e.el instanceof Element && e.el.removeEventListener(r, a)
            };
            if (this.el && 1 <= this.el.length)
                for (t = 0; t < this.el.length; t++) this.el[t].eventExecuted = !1, this.el[t].eventExecuted || this.el[t].addEventListener(r, a);
            else this.el && (this.el.eventExecuted = !1, !this.el.eventExecuted) && this.el instanceof Element && (Bt["" + r + i] || (Bt["" + r + i] = !0, this.el.addEventListener(r, a)))
        }
        return this
    }, a.prototype.off = function(e, t) {
        if (1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) this.el[o].removeEventListener(e, t);
        else this.el.removeEventListener(e, t);
        return this
    }, a.prototype.one = function(t, o) {
        var n = this;
        if (1 <= this.el.length)
            for (var e = 0; e < this.el.length; e++) this.el[e].addEventListener(t, function(e) {
                e.stopPropagation(), e.currentTarget.dataset.triggered || (o(), e.currentTarget.dataset.triggered = !0)
            });
        else {
            var r = function(e) {
                e.stopPropagation(), o(), n.off(t, r)
            };
            this.el.addEventListener(t, r)
        }
        return this
    }, a.prototype.trigger = function(e) {
        e = new CustomEvent(e, {
            customEvent: "yes"
        });
        return this.el.dispatchEvent(e), this
    }, a.prototype.focus = function() {
        return (1 <= this.el.length ? this.el[0] : this.el).focus(), this
    }, a.prototype.attr = function(e, t) {
        return this.el && 1 <= this.el.length ? t ? ("class" === e ? this.addClass(t) : this.el[0].setAttribute(e, t), this) : this.el[0].getAttribute(e) : t && this.el ? ("class" === e ? this.addClass(t) : this.el.setAttribute(e, t), this) : this.el && this.el.getAttribute(e)
    }, a.prototype.html = function(e) {
        if (null == e) return (1 <= this.el.length ? this.el[0] : this.el).innerHTML;
        var t = a.getInnerHtmlContent(e);
        if (1 <= this.el.length)
            for (var o = 0; o < this.el.length; o++) this.el[o].innerHTML = t;
        else this.el.innerHTML = t;
        return this
    }, a.prototype.append = function(e) {
        if ("string" != typeof e || e.includes("<") || e.includes(">"))
            if (Array.isArray(e)) {
                var o = this;
                Array.prototype.forEach.call(e, function(e, t) {
                    document.querySelector(o.selector).appendChild(new a(e, "ce").el)
                })
            } else {
                if ("string" == typeof e || Array.isArray(e)) return this.appendHtmlElement(e);
                if ("string" == typeof this.selector) document.querySelector(this.selector).appendChild(e);
                else if (1 <= e.length)
                    for (var t = 0; t < e.length; t++) this.selector.appendChild(e[t]);
                else this.selector.appendChild(e)
            }
        else this.el.insertAdjacentText("beforeend", e);
        return this
    }, a.prototype.text = function(o) {
        if (this.el) {
            if (1 <= this.el.length) {
                if (!o) return this.el[0].textContent;
                Array.prototype.forEach.call(this.el, function(e, t) {
                    e.textContent = o
                })
            } else {
                if (!o) return this.el.textContent;
                this.el.textContent = o
            }
            return this
        }
    }, a.prototype.data = function(o, n) {
        if (!(this.el.length < 1)) {
            if (!(1 <= this.el.length)) return r(this.el, n);
            Array.prototype.forEach.call(this.el, function(e, t) {
                r(e, n)
            })
        }
        return this;

        function r(e, t) {
            if (!t) return JSON.parse(e.getAttribute("data-" + o));
            "object" == typeof t ? e.setAttribute("data-" + o, JSON.stringify(t)) : e.setAttribute("data-" + o, t)
        }
    }, a.prototype.height = function(e) {
        this.el.length && (this.el = this.el[0]);
        for (var t = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("padding-top").split("px")[0]), o = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("padding-bottom").split("px")[0]), n = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("margin-top").split("px")[0]), r = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("margin-bottom").split("px")[0]), i = parseInt(window.getComputedStyle(this.el, null).getPropertyValue("height").split("px")[0]), s = [t, o, n, r], a = 0, l = 0; l < s.length; l++) 0 < s[l] && (a += s[l]);
        return e ? (t = e.toString().split(parseInt(e))[1] ? e.toString().split(parseInt(e))[1] : "px", o = "number" == typeof e ? e : parseInt(e.toString().split(t)[0]), (t && "px" === t || "%" === t || "em" === t || "rem" === t) && (0 < o ? d(this.el, "height: " + (a + o + t) + ";", !0) : "auto" === e && d(this.el, "height: " + e + ";", !0)), this) : this.selector === document ? i : this.el.clientHeight - a
    }, a.prototype.each = function(e) {
        var t = !1;
        return void 0 === this.el.length && (this.el = [this.el], t = !0), Array.prototype.forEach.call(this.el, e), t && (this.el = this.el[0]), this
    }, a.prototype.is = function(e) {
        return this.el.length ? (this.el[0].matches || this.el[0].matchesSelector || this.el[0].msMatchesSelector || this.el[0].mozMatchesSelector || this.el[0].webkitMatchesSelector || this.el[0].oMatchesSelector).call(this.el[0], e) : (this.el.matches || this.el.matchesSelector || this.el.msMatchesSelector || this.el.mozMatchesSelector || this.el.webkitMatchesSelector || this.el.oMatchesSelector).call(this.el, e)
    }, a.prototype.filter = function(e) {
        return this.el = Array.prototype.filter.call(document.querySelectorAll(this.selector), e), this
    }, a.prototype.animate = function(e, t) {
        var o, n, r, i, s = this;
        this.el = document.querySelector(this.selector);
        for (o in e) n = o, i = r = void 0, r = parseInt(e[n]), i = e[n].split(parseInt(e[n]))[1] ? e[n].split(parseInt(e[n]))[1] : "px", r = s.createKeyFrameAnimation(n, s.el, r, i), (i = document.head.querySelector("#onetrust-style")) ? i.innerHTML = a.getInnerHtmlContent(i.innerHTML + r) : ((i = document.createElement("style")).id = "onetrust-legacy-style", i.type = "text/css", i.innerHTML = a.getInnerHtmlContent(r), document.head.appendChild(i)), s.addWebKitAnimation(n, t);
        return this
    }, a.prototype.scrollTop = function() {
        return this.el.scrollTop
    }, a.prototype.appendHtmlElement = function(o) {
        var n, r, e;
        return "string" == typeof this.selector ? document.querySelector(this.selector).appendChild(new a(o, "ce").el) : this.useEl ? (n = document.createDocumentFragment(), (r = !(!o.includes("<th") && !o.includes("<td"))) && (e = o.split(" ")[0].split("<")[1], n.appendChild(document.createElement(e)), n.firstChild.innerHTML = a.getInnerHtmlContent(o)), Array.prototype.forEach.call(this.el, function(e, t) {
            r ? e.appendChild(n.firstChild) : e.appendChild(new a(o, "ce").el)
        })) : this.selector.appendChild(new a(o, "ce").el), this
    }, a.prototype.createKeyFrameAnimation = function(e, t, o, n) {
        return "\n        @keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        @-webkit-keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        @-moz-keyframes slide-" + ("top" === e ? "up" : "down") + "-custom {\n            0% {\n                " + ("top" === e ? "top" : "bottom") + ": " + ("top" === e ? t.getBoundingClientRect().top : window.innerHeight) + "px !important;\n            }\n            100% {\n                " + ("top" === e ? "top" : "bottom") + ": " + (o + n) + ";\n            }\n        }\n        "
    }, a.prototype.addWebKitAnimation = function(e, t) {
        (a.browser().type = a.browser().version <= 8) ? d(this.el, "top" === e ? "-webkit-animation: slide-up-custom " : "-webkit-animation: slide-down-custom " + t + "ms ease-out forwards;"): d(this.el, "\n                animation-name: " + ("top" === e ? "slide-up-custom" : "slide-down-custom") + ";\n                animation-duration: " + t + "ms;\n                animation-fill-mode: forwards;\n                animation-timing-function: ease-out;\n            ", !0)
    };
    var m = a;

    function a(e, t) {
        switch (void 0 === t && (t = ""), this.selector = e, this.useEl = !1, t) {
            case "ce":
                var o = a.browser().type.toLowerCase(),
                    n = a.browser().version;
                n < 10 && "safari" === o || "chrome" === o && n <= 44 || n <= 40 && "firefox" === o ? ((n = document.implementation.createHTMLDocument()).body.innerHTML = a.getInnerHtmlContent(e), this.el = n.body.children[0]) : (o = document.createRange().createContextualFragment(a.getInnerHtmlContent(e)), this.el = o.firstChild), this.length = 1;
                break;
            case "":
                this.el = e === document || e === window ? document.documentElement : "string" != typeof e ? e : document.querySelectorAll(e), this.length = e === document || e === window || "string" != typeof e ? 1 : this.el.length;
                break;
            default:
                this.length = 0
        }
    }

    function v(e, t) {
        return new m(e, t = void 0 === t ? "" : t)
    }
    var Bt = {};

    function Gt() {}
    Gt.prototype.convertKeyValueLowerCase = function(e) {
        for (var t in e) e[t.toLowerCase()] ? e[t.toLowerCase()] = e[t].toLowerCase() : (e[t] && (e[t.toLowerCase()] = e[t].toLowerCase()), delete e[t]);
        return e
    }, Gt.prototype.arrToStr = function(e) {
        return e.toString()
    }, Gt.prototype.strToArr = function(e) {
        return e ? e.split(",") : []
    }, Gt.prototype.strToMap = function(e) {
        if (!e) return new Map;
        for (var t = new Map, o = 0, n = this.strToArr(e); o < n.length; o++) {
            var r = n[o].split(":");
            t.set(r[0], "1" === r[1])
        }
        return t
    }, Gt.prototype.empty = function(e) {
        var t = document.getElementById(e);
        if (t)
            for (; t.hasChildNodes();) t.removeChild(t.lastChild)
    }, Gt.prototype.show = function(e) {
        e = document.getElementById(e);
        e && d(e, "display: block;", !0)
    }, Gt.prototype.remove = function(e) {
        e = document.getElementById(e);
        e && e.parentNode && e.parentNode.removeChild(e)
    }, Gt.prototype.appendTo = function(e, t) {
        var o, e = document.getElementById(e);
        e && ((o = document.createElement("div")).innerHTML = m.getInnerHtmlContent(t), e.appendChild(o))
    }, Gt.prototype.contains = function(e, t) {
        for (var o = 0; o < e.length; o += 1)
            if (e[o].toString().toLowerCase() === t.toString().toLowerCase()) return !0;
        return !1
    }, Gt.prototype.indexOf = function(e, t) {
        for (var o = 0; o < e.length; o += 1)
            if (e[o] === t) return o;
        return -1
    }, Gt.prototype.endsWith = function(e, t) {
        return -1 !== e.indexOf(t, e.length - t.length)
    }, Gt.prototype.generateUUID = function() {
        var o = (new Date).getTime();
        return "undefined" != typeof performance && "function" == typeof performance.now && (o += performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var t = (o + 16 * Math.random()) % 16 | 0;
            return o = Math.floor(o / 16), ("x" === e ? t : 3 & t | 8).toString(16)
        })
    }, Gt.prototype.getActiveIdArray = function(e) {
        return e.filter(function(e) {
            return "true" === e.split(":")[1]
        }).map(function(e) {
            return parseInt(e.split(":")[0])
        })
    }, Gt.prototype.distinctArray = function(e) {
        var t = new Array;
        return e.forEach(function(e) {
            t.indexOf(e) < 0 && t.push(e)
        }), t
    }, Gt.prototype.findIndex = function(e, t) {
        for (var o = -1, n = 0; n < e.length; n++)
            if (void 0 !== e[n] && t(e[n], n)) {
                o = n;
                break
            }
        return o
    }, Gt.prototype.getURL = function(e) {
        var t = document.createElement("a");
        return t.href = e, t
    }, Gt.prototype.removeURLPrefixes = function(e) {
        return e.toLowerCase().replace(/(^\w+:|^)\/\//, "").replace("www.", "")
    }, Gt.prototype.removeChild = function(e) {
        if (e)
            if (e instanceof NodeList || e instanceof Array)
                for (var t = 0; t < e.length; t++) e[t].parentElement.removeChild(e[t]);
            else e.parentElement.removeChild(e)
    }, Gt.prototype.getRelativeURL = function(e, t, o) {
        return void 0 === o && (o = !1), t ? (t = "./" + e.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/").replace(".json", ""), o ? t : t + ".js") : e
    }, Gt.prototype.setCheckedAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && (o ? t.setAttribute("checked", "") : t.removeAttribute("checked"), t.checked = o)
    }, Gt.prototype.setAriaCheckedAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && t.setAttribute("aria-checked", o)
    }, Gt.prototype.setDisabledAttribute = function(e, t, o) {
        (t = e ? document.querySelector(e) : t) && (o ? t.setAttribute("disabled", o.toString()) : t.removeAttribute("disabled"))
    }, Gt.prototype.setHtmlAttributes = function(e, t) {
        for (var o in t) e.setAttribute(o, t[o]), e[o] = t[o]
    }, Gt.prototype.calculateCookieLifespan = function(e) {
        return e < 0 ? L.LifespanTypeText : (e = Math.floor(e / fe.maxSecToDays)) < fe.minDays ? "< 1 " + L.PCenterVendorListLifespanDay : e < fe.maxDays ? e + " " + L.PCenterVendorListLifespanDays : 1 === (e = Math.floor(e / fe.maxDays)) ? e + " " + L.PCenterVendorListLifespanMonth : e + " " + L.PCenterVendorListLifespanMonths
    }, Gt.prototype.insertElement = function(e, t, o) {
        e && t && e.insertAdjacentElement(o, t)
    }, Gt.prototype.customQuerySelector = function(t) {
        return function(e) {
            return t.querySelector(e)
        }
    }, Gt.prototype.customQuerySelectorAll = function(t) {
        return function(e) {
            return t.querySelectorAll(e)
        }
    };
    var T, P = new Gt,
        xt = (Ht.prototype.removeAlertBox = function() {
            null !== this.getCookie(y.ALERT_BOX_CLOSED) && this.setCookie(y.ALERT_BOX_CLOSED, "", 0, !0)
        }, Ht.prototype.removeIab1 = function() {
            null !== this.getCookie(ue.Iab1Pub) && this.setCookie(ue.Iab1Pub, "", 0, !0)
        }, Ht.prototype.removeIab2 = function() {
            null !== this.getCookie(ue.Iab2Pub) && this.setCookie(ue.Iab2Pub, "", 0, !0)
        }, Ht.prototype.removeAddtlStr = function() {
            null !== this.getCookie(y.ADDITIONAL_CONSENT_STRING) && this.setCookie(y.ADDITIONAL_CONSENT_STRING, "", 0, !0)
        }, Ht.prototype.removeVariant = function() {
            null !== this.getCookie(y.SELECTED_VARIANT) && this.setCookie(y.SELECTED_VARIANT, "", 0, !0)
        }, Ht.prototype.removeOptanon = function() {
            null !== this.getCookie(y.OPTANON_CONSENT) && this.setCookie(y.OPTANON_CONSENT, "", 0, !0)
        }, Ht.prototype.removePreview = function() {
            null !== this.getCookie(y.OT_PREVIEW) && this.setCookie(y.OT_PREVIEW, "", 0, !0)
        }, Ht.prototype.removeAllCookies = function() {
            this.removeIab1(), this.removeIab2(), this.removePreview(), this.removeOptanon(), this.removeVariant(), this.removeAlertBox(), this.removeAddtlStr(), this.removeAmpStorage()
        }, Ht.prototype.writeCookieParam = function(e, t, o, n) {
            var r, i, s, a = {},
                l = this.getCookie(e);
            if (l)
                for (i = l.split("&"), r = 0; r < i.length; r += 1) s = i[r].split("="), a[decodeURIComponent(s[0])] = s[0] === t && n ? decodeURIComponent(s[1]) : decodeURIComponent(s[1]).replace(/\+/g, " ");
            a[t] = o;
            l = S.moduleInitializer.TenantFeatures;
            l && l.CookieV2CookieDateTimeInISO ? a.datestamp = (new Date).toISOString() : a.datestamp = (new Date).toString(), a.version = _.otSDKVersion, o = this.param(a), this.setCookie(e, o, L.ReconsentFrequencyDays)
        }, Ht.prototype.readCookieParam = function(e, t, o) {
            var n, r, i, s, e = this.getCookie(e);
            if (e) {
                for (r = {}, i = e.split("&"), n = 0; n < i.length; n += 1) s = i[n].split("="), r[decodeURIComponent(s[0])] = o ? decodeURIComponent(s[1]) : decodeURIComponent(s[1]).replace(/\+/g, " ");
                return t && r[t] ? r[t] : t && !r[t] ? "" : r
            }
            return ""
        }, Ht.prototype.getCookie = function(e) {
            if (S && S.moduleInitializer && S.moduleInitializer.MobileSDK) {
                var t = this.getCookieDataObj(e);
                if (t) return t.value
            }
            if (_.isAMP && (_.ampData = JSON.parse(localStorage.getItem(_.dataDomainId)) || {}, _.ampData)) return _.ampData[e] || null;
            for (var o, n = e + "=", r = document.cookie.split(";"), i = 0; i < r.length; i += 1) {
                for (o = r[i];
                    " " === o.charAt(0);) o = o.substring(1, o.length);
                if (0 === o.indexOf(n)) return o.substring(n.length, o.length)
            }
            return null
        }, Ht.prototype.setAmpStorage = function() {
            window.localStorage.setItem(_.dataDomainId, JSON.stringify(_.ampData))
        }, Ht.prototype.removeAmpStorage = function() {
            window.localStorage.removeItem(_.dataDomainId)
        }, Ht.prototype.handleAmp = function(e, t) {
            "" !== t ? _.ampData[e] = t : delete _.ampData[e], 0 === Object.keys(_.ampData).length ? this.removeAmpStorage() : this.setAmpStorage()
        }, Ht.prototype.getExpiryValue = function(e, t, o) {
            return void 0 === t && (t = !1), void 0 === o && (o = new Date), e ? (o.setTime(o.getTime() + 24 * e * 60 * 60 * 1e3), "; expires=" + o.toUTCString()) : t ? "; expires=" + new Date(0).toUTCString() : ""
        }, Ht.prototype.getDomainUrl = function() {
            var e, t = S.moduleInitializer;
            return t && t.RootDomainConsentEnabled ? e = t.RootDomainUrl : t && t.Domain && (e = t.Domain), e
        }, Ht.prototype.setCookie = function(e, t, o, n, r) {
            var i, s, a, l, c, d;
            void 0 === n && (n = !1), void 0 === r && (r = new Date), _.isAMP ? this.handleAmp(e, t) : (o = this.getExpiryValue(o, n, r), n = S.moduleInitializer, s = "", (i = (i = this.getDomainUrl()) ? i.split("/") : []).length <= 1 ? i[1] = "" : s = i.slice(1).join("/"), a = "Samesite=Lax", n.CookieSameSiteNoneEnabled && (a = "Samesite=None; Secure", n.PartitionedCookieEnabled) && (a += "; Partitioned"), l = S.moduleInitializer.TenantFeatures, c = n.ScriptType === qe.TEST || n.ScriptType === qe.LOCAL_TEST, _.isPreview || !c && !n.MobileSDK ? (d = t + o + "; path=/" + s + "; domain=." + i[0] + "; " + a, l && l.CookieV2CookiePriority && (d += ";Priority=High;"), document.cookie = e + "=" + d) : (d = t + o + "; path=/; " + a, l && l.CookieV2CookiePriority && (d += ";Priority=High;"), n.MobileSDK ? this.setCookieDataObj({
                name: e,
                value: t,
                expires: o,
                date: r,
                domainAndPath: i
            }) : document.cookie = e + "=" + d))
        }, Ht.prototype.setCookieDataObj = function(t) {
            var e;
            t && (_.otCookieData || (window.OneTrust && window.OneTrust.otCookieData ? _.otCookieData = window.OneTrust.otCookieData : _.otCookieData = []), -1 < (e = P.findIndex(_.otCookieData, function(e) {
                return e.name === t.name
            })) ? _.otCookieData[e] = t : _.otCookieData.push(t))
        }, Ht.prototype.getCookieDataObj = function(t) {
            _.otCookieData && 0 !== _.otCookieData.length || (window.OneTrust && window.OneTrust.otCookieData ? _.otCookieData = window.OneTrust.otCookieData : _.otCookieData = []);
            var e = P.findIndex(_.otCookieData, function(e) {
                return e.name === t
            });
            if (0 <= e) {
                var o = _.otCookieData[e];
                if (o.date) return new Date(o.date) < new Date ? (_.otCookieData.splice(e, 1), null) : o
            }
            return null
        }, Ht.prototype.getCookiesChunk = function(e, t) {
            var o = {};
            if (e.length <= 4e3) o[t] = e;
            else
                for (var n = 0, r = 0; n < e.length;) {
                    var i = e.slice(n, n + 4e3);
                    0 === r ? o[t] = i : o[t + "_" + r] = i, n += 4e3, r++
                }
            return o
        }, Ht.prototype.getMergedCookieByName = function(e) {
            var t = "",
                o = this.getCookie(e);
            if (!o) return "";
            t += o;
            for (var n = 1;;) {
                var r = this.getCookie(e + "_" + n);
                if (!r) break;
                t += r, n++
            }
            return t
        }, Ht.prototype.param = function(e) {
            var t, o = "";
            for (t in e) e.hasOwnProperty(t) && ("" !== o && (o += "&"), o += t + "=" + encodeURIComponent(e[t]).replace(/%20/g, "+"));
            return o
        }, Ht);

    function Ht() {}
    var A, k, Rt = {
            P_Content: "#ot-pc-content",
            P_Logo: ".ot-pc-logo",
            P_Title: "#ot-pc-title",
            P_Title_Mobile: "#ot-pc-title-mobile",
            P_Policy_Txt: "#ot-pc-desc",
            P_Vendor_Title_Elm: "#ot-lst-title",
            P_Vendor_Title: "#ot-lst-title h3",
            P_Manage_Cookies_Txt: "#ot-category-title",
            P_Label_Txt: ".ot-label-txt",
            P_Category_Header: ".ot-cat-header",
            P_Category_Grp: ".ot-cat-grp",
            P_Category_Item: ".ot-cat-item",
            P_Vendor_List: "#ot-pc-lst",
            P_Vendor_Content: "#ot-lst-cnt",
            P_Vendor_Container: "#ot-ven-lst",
            P_Ven_Bx: "ot-ven-box",
            P_Ven_Name: ".ot-ven-name",
            P_Ven_Link: ".ot-ven-link",
            P_Ven_Leg_Claim: ".ot-ven-legclaim-link",
            P_Ven_Ctgl: "ot-ven-ctgl",
            P_Ven_Ltgl: "ot-ven-litgl",
            P_Ven_Ltgl_Only: "ot-ven-litgl-only",
            P_Ven_Opts: ".ot-ven-opts",
            P_Triangle: "#ot-anchor",
            P_Fltr_Modal: "#ot-fltr-modal",
            P_Fltr_Options: ".ot-fltr-opts",
            P_Fltr_Option: ".ot-fltr-opt",
            P_Select_Cntr: "#ot-sel-blk",
            P_Host_Cntr: "#ot-host-lst",
            P_Host_Hdr: ".ot-host-hdr",
            P_Host_Desc: ".ot-host-desc",
            P_Li_Hdr: ".ot-pli-hdr",
            P_Li_Title: ".ot-li-title",
            P_Sel_All_Vendor_Consent_Handler: "#select-all-vendor-leg-handler",
            P_Sel_All_Vendor_Leg_Handler: "#select-all-vendor-groups-handler",
            P_Sel_All_Host_Handler: "#select-all-hosts-groups-handler",
            P_Host_Title: ".ot-host-name",
            P_Leg_Select_All: ".ot-sel-all-hdr",
            P_Leg_Header: ".ot-li-hdr",
            P_Acc_Header: ".ot-acc-hdr",
            P_Cnsnt_Header: ".ot-consent-hdr",
            P_Tgl_Cntr: ".ot-tgl-cntr",
            P_CBx_Cntr: ".ot-chkbox",
            P_Sel_All_Host_El: "ot-selall-hostcntr",
            P_Sel_All_Vendor_Consent_El: "ot-selall-vencntr",
            P_Sel_All_Vendor_Leg_El: "ot-selall-licntr",
            P_c_Name: "ot-c-name",
            P_c_Host: "ot-c-host",
            P_c_Duration: "ot-c-duration",
            P_c_Type: "ot-c-type",
            P_c_Category: "ot-c-category",
            P_c_Desc: "ot-c-description",
            P_Host_View_Cookies: ".ot-host-expand",
            P_Host_Opt: ".ot-host-opt",
            P_Host_Info: ".ot-host-info",
            P_Arrw_Cntr: ".ot-arw-cntr",
            P_Acc_Txt: ".ot-acc-txt",
            P_Vendor_CheckBx: "ot-ven-chkbox",
            P_Vendor_LegCheckBx: "ot-ven-leg-chkbox",
            P_Host_UI: "ot-hosts-ui",
            P_Host_Cnt: "ot-host-cnt",
            P_Host_Bx: "ot-host-box",
            P_Ven_Dets: ".ot-ven-dets",
            P_Ven_Disc: ".ot-ven-disc",
            P_Gven_List: "#ot-gn-venlst",
            P_Close_Btn: ".ot-close-icon",
            P_Ven_Lst_Cntr: ".ot-vlst-cntr",
            P_Host_Lst_cntr: ".ot-hlst-cntr",
            P_Sub_Grp_Cntr: ".ot-subgrp-cntr",
            P_Subgrp_Desc: ".ot-subgrp-desc",
            P_Subgp_ul: ".ot-subgrps",
            P_Subgrp_li: ".ot-subgrp",
            P_Subgrp_Tgl_Cntr: ".ot-subgrp-tgl",
            P_Grp_Container: ".ot-grps-cntr",
            P_Privacy_Txt: "#ot-pvcy-txt",
            P_Privacy_Hdr: "#ot-pvcy-hdr",
            P_Active_Menu: "ot-active-menu",
            P_Desc_Container: ".ot-desc-cntr",
            P_Tab_Grp_Hdr: "ot-grp-hdr1",
            P_Search_Cntr: "#ot-search-cntr",
            P_Clr_Fltr_Txt: "#clear-filters-handler",
            P_Acc_Grp_Desc: ".ot-acc-grpdesc",
            P_Acc_Container: ".ot-acc-grpcntr",
            P_Line_Through: "line-through",
            P_Vendor_Search_Input: "#vendor-search-handler"
        },
        Ft = {
            P_Grp_Container: ".groups-container",
            P_Content: "#ot-content",
            P_Category_Header: ".category-header",
            P_Desc_Container: ".description-container",
            P_Label_Txt: ".label-text",
            P_Acc_Grp_Desc: ".ot-accordion-group-pc-container",
            P_Leg_Int_Hdr: ".leg-int-header",
            P_Not_Always_Active: "p:not(.ot-always-active)",
            P_Category_Grp: ".category-group",
            P_Category_Item: ".category-item",
            P_Sub_Grp_Cntr: ".cookie-subgroups-container",
            P_Acc_Container: ".ot-accordion-pc-container",
            P_Close_Btn: ".pc-close-button",
            P_Logo: ".pc-logo",
            P_Title: "#pc-title",
            P_Title_Mobile: "#pc-title-mobile",
            P_Privacy_Txt: "#privacy-text",
            P_Privacy_Hdr: "#pc-privacy-header",
            P_Policy_Txt: "#pc-policy-text",
            P_Manage_Cookies_Txt: "#manage-cookies-text",
            P_Vendor_Title: "#vendors-list-title",
            P_Vendor_Title_Elm: "#vendors-list-title",
            P_Vendor_List: "#vendors-list",
            P_Vendor_Content: "#vendor-list-content",
            P_Vendor_Container: "#vendors-list-container",
            P_Ven_Bx: "vendor-box",
            P_Ven_Name: ".vendor-title",
            P_Ven_Link: ".vendor-privacy-notice",
            P_Ven_Leg_Claim: ".vendor-legclaim-link",
            P_Ven_Ctgl: "ot-vendor-consent-tgl",
            P_Ven_Ltgl: "ot-leg-int-tgl",
            P_Ven_Ltgl_Only: "ot-leg-int-tgl-only",
            P_Ven_Opts: ".vendor-options",
            P_Triangle: "#ot-triangle",
            P_Fltr_Modal: "#ot-filter-modal",
            P_Fltr_Options: ".ot-group-options",
            P_Fltr_Option: ".ot-group-option",
            P_Select_Cntr: "#select-all-container",
            P_Host_Cntr: "#hosts-list-container",
            P_Host_Hdr: ".host-info",
            P_Host_Desc: ".host-description",
            P_Host_Opt: ".host-option-group",
            P_Host_Info: ".vendor-host",
            P_Ven_Dets: ".vendor-purpose-groups",
            P_Ven_Disc: ".ot-ven-disc",
            P_Gven_List: "#ot-gn-venlst",
            P_Arrw_Cntr: ".ot-arrow-container",
            P_Li_Hdr: ".leg-int-header",
            P_Li_Title: ".leg-int-title",
            P_Acc_Txt: ".accordion-text",
            P_Tgl_Cntr: ".ot-toggle-group",
            P_CBx_Cntr: ".ot-chkbox-container",
            P_Host_Title: ".host-title",
            P_Leg_Select_All: ".leg-int-sel-all-hdr",
            P_Leg_Header: ".leg-int-hdr",
            P_Cnsnt_Header: ".consent-hdr",
            P_Acc_Header: ".accordion-header",
            P_Sel_All_Vendor_Consent_Handler: "#select-all-vendor-leg-handler",
            P_Sel_All_Vendor_Leg_Handler: "#select-all-vendor-groups-handler",
            P_Sel_All_Host_Handler: "#select-all-hosts-groups-handler",
            P_Sel_All_Host_El: "select-all-hosts-input-container",
            P_Sel_All_Vendor_Consent_El: "select-all-vendors-input-container",
            P_Sel_All_Vendor_Leg_El: "select-all-vendors-leg-input-container",
            P_c_Name: "cookie-name-container",
            P_c_Host: "cookie-host-container",
            P_c_Duration: "cookie-duration-container",
            P_c_Type: "cookie-type-container",
            P_c_Category: "cookie-category-container",
            P_c_Desc: "cookie-description-container",
            P_Host_View_Cookies: ".host-view-cookies",
            P_Vendor_CheckBx: "vendor-chkbox",
            P_Vendor_LegCheckBx: "vendor-leg-chkbox",
            P_Host_UI: "hosts-list",
            P_Host_Cnt: "host-list-content",
            P_Host_Bx: "host-box",
            P_Ven_Lst_Cntr: ".category-vendors-list-container",
            P_Host_Lst_cntr: ".category-host-list-container",
            P_Subgrp_Desc: ".cookie-subgroups-description-legal",
            P_Subgp_ul: ".cookie-subgroups",
            P_Subgrp_li: ".cookie-subgroup",
            P_Subgrp_Tgl_Cntr: ".cookie-subgroup-toggle",
            P_Active_Menu: "active-group",
            P_Tab_Grp_Hdr: "group-toggle",
            P_Search_Cntr: "#search-container",
            P_Clr_Fltr_Txt: "#clear-filters-handler p",
            P_Vendor_Search_Input: "#vendor-search-handler"
        },
        Mt = {
            GroupTypes: {
                Cookie: "COOKIE",
                Bundle: "BRANCH",
                Ft: "IAB2_FEATURE",
                Pur: "IAB2_PURPOSE",
                Spl_Ft: "IAB2_SPL_FEATURE",
                Spl_Pur: "IAB2_SPL_PURPOSE",
                Stack: "IAB2_STACK"
            },
            IdPatterns: {
                Pur: "IABV2_",
                Ft: "IFEV2_",
                Spl_Pur: "ISPV2_",
                Spl_Ft: "ISFV2_"
            }
        },
        Ut = {
            GroupTypes: {
                Cookie: "COOKIE",
                Bundle: "BRANCH",
                Ft: "IAB2V2_FEATURE",
                Pur: "IAB2V2_PURPOSE",
                Spl_Ft: "IAB2V2_SPL_FEATURE",
                Spl_Pur: "IAB2V2_SPL_PURPOSE",
                Stack: "IAB2V2_STACK"
            },
            IdPatterns: {
                Pur: "IAB2V2_",
                Ft: "IFE2V2_",
                Spl_Pur: "ISP2V2_",
                Spl_Ft: "ISF2V2_"
            }
        };
    jt.prototype.getDataLanguageCulture = function() {
        var e = I.getStubAttr(Ke) || S.moduleInitializer.DataLanguage;
        return e ? this.checkAndTansformLangCodeWithUnderdscore(e.toLowerCase()) : this.detectDocumentOrBrowserLanguage().toLowerCase()
    }, jt.prototype.checkAndTansformLangCodeWithUnderdscore = function(e) {
        return e.replace(/\_/, "-")
    }, jt.prototype.detectDocumentOrBrowserLanguage = function() {
        var e = "";
        if (b.langSwitcherPldr) {
            var t = P.convertKeyValueLowerCase(b.langSwitcherPldr),
                o = this.getUserLanguage().toLowerCase();
            if (!(e = t[o] || t[o + "-" + o] || (t.default === o ? t.default : null)))
                for (var n = Object.keys(t), r = 0; r < n.length; r += 1) {
                    var i = n[r];
                    if ((-1 === i.indexOf("-") ? i : i.substring(0, i.indexOf("-"))) === o) {
                        e = t[i];
                        break
                    }
                }
            e = e || t.default
        }
        return e
    }, jt.prototype.getUserLanguage = function() {
        return b.useDocumentLanguage ? this.checkAndTansformLangCodeWithUnderdscore(document.documentElement.lang) : navigator.languages && navigator.languages.length ? navigator.languages[0] : navigator.language || navigator.userLanguage
    }, jt.prototype.isValidLanguage = function(e, t) {
        var o = P.convertKeyValueLowerCase(b.langSwitcherPldr);
        return !(!o || !o[t] && !o[t + "-" + t] && o.default !== t)
    }, jt.prototype.getLangJsonUrl = function(e) {
        void 0 === e && (e = null);
        var t, o = b.getRegionRule();
        if (e) {
            if (e = e.toLowerCase(), !this.isValidLanguage(o, e)) return null
        } else e = this.getDataLanguageCulture();
        return l.lang = e, l.consentLanguage = -1 === e.indexOf("-") ? e : e.substring(0, e.indexOf("-")), t = b.canUseConditionalLogic ? b.bannerDataParentURL + "/" + o.Id + "/" + b.Condition.Id + "/" + e : b.bannerDataParentURL + "/" + o.Id + "/" + e, t = b.multiVariantTestingEnabled ? b.bannerDataParentURL + "/" + o.Id + "/variants/" + b.selectedVariant.Id + "/" + e : t
    }, jt.prototype.populateLangSwitcherPlhdr = function() {
        var e, t, o, n = b.getRegionRule();
        n && (e = n.Variants, b.multiVariantTestingEnabled && e ? (o = void 0, (t = T.getCookie(y.SELECTED_VARIANT)) && (o = e[P.findIndex(e, function(e) {
            return e.Id === t
        })]), t && o || (o = e[Math.floor(Math.random() * e.length)]), b.langSwitcherPldr = o.LanguageSwitcherPlaceholder, b.selectedVariant = o) : b.canUseConditionalLogic ? b.langSwitcherPldr = b.Condition.LanguageSwitcherPlaceholder : b.langSwitcherPldr = n.LanguageSwitcherPlaceholder)
    };
    var qt, e = jt;

    function jt() {}
    Wt.prototype.getLangJson = function(e) {
        var t;
        return void 0 === e && (e = null), b.previewMode ? (t = JSON.parse(window.sessionStorage.getItem("otPreviewData")), Promise.resolve(t.langJson)) : (t = qt.getLangJsonUrl(e)) ? Kt.otFetch(t + ".json", !1, !1, !0) : Promise.resolve(null)
    }, Wt.prototype.getPersistentCookieSvg = function(e) {
        e = e || L.cookiePersistentLogo;
        return e ? Kt.otFetch(e, !0) : Promise.resolve(null)
    }, Wt.prototype.getSpriteSvg = function(e) {
        return e ? Kt.otFetch(e, !0) : Promise.resolve(null)
    }, Wt.prototype.fetchGvlObj = function() {
        var e = S.moduleInitializer.IabV2Data.globalVendorListUrl;
        return "IAB2V2" === b.getRegionRuleType() && (e = S.moduleInitializer.Iab2V2Data.globalVendorListUrl), this.otFetch(e)
    }, Wt.prototype.fetchGoogleVendors = function() {
        var e = I.updateCorrectIABUrl(S.moduleInitializer.GoogleData.googleVendorListUrl);
        return I.checkMobileOfflineRequest(I.getBannerVersionUrl()) ? I.otFetchOfflineFile(P.getRelativeURL(e, !0)) : (b.mobileOnlineURL.push(e), this.otFetch(e))
    }, Wt.prototype.getStorageDisclosure = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                return [2, this.otFetch(t, !1, !0)]
            })
        })
    }, Wt.prototype.loadCMP = function() {
        var o = this;
        return new Promise(function(e) {
            var t = o.checkIfRequiresPollyfill() ? "otTCF-ie" : "otTCF";
            I.jsonp(I.getBannerVersionUrl() + "/" + t + ".js", e, e)
        })
    }, Wt.prototype.loadGPP = function() {
        return new Promise(function(e) {
            I.jsonp(I.getBannerVersionUrl() + "/otGPP.js", e, e)
        })
    }, Wt.prototype.loadConfirmDialog = function() {
        var e = document.createElement("link");
        return e.rel = "stylesheet", e.href = I.getBannerSDKAssestsUrl() + "/otConfirmDialog" + (L.useRTL ? "Rtl" : "") + ".css", document.head.appendChild(e), new Promise(function(e) {
            I.jsonp(I.getBannerVersionUrl() + "/otConfirmDialog.js", e, e)
        })
    }, Wt.prototype.getCSBtnContent = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = L.useRTL ? Se.RTL : Se.LTR, l.csBtnAsset[t]) ? [3, 2] : (o = I.getBannerSDKAssestsUrl() + "/" + (L.useRTL ? We : ze), n = l.csBtnAsset, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, l.csBtnAsset[t]]
                }
            })
        })
    }, Wt.prototype.getPcContent = function(i) {
        return void 0 === i && (i = !1), F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = L.useRTL ? Se.RTL : Se.LTR, l.pcAsset[t] && !i) ? [3, 2] : (o = I.getBannerSDKAssestsUrl(), L.PCTemplateUpgrade && (o += "/v2"), o = o + "/" + b.pcName + (L.useRTL ? "Rtl" : "") + ".json", n = l.pcAsset, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, l.pcAsset[t]]
                }
            })
        })
    }, Wt.prototype.getBannerContent = function(s, a) {
        return void 0 === s && (s = !1), void 0 === a && (a = null), F(this, void 0, void 0, function() {
            var t, o, n, r, i;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (t = L.useRTL ? Se.RTL : Se.LTR, o = a || qt.getDataLanguageCulture(), l.bAsset[t] && !s) return [3, 2];
                        if (i = b.getRegionRule(), n = void 0, S.fp.CookieV2SSR) {
                            if (b.previewMode) return r = JSON.parse(window.sessionStorage.getItem("otPreviewData")), [2, Promise.resolve(r.bLayout)];
                            n = b.bannerDataParentURL + "/" + i.Id, b.canUseConditionalLogic && (n += "/" + b.Condition.Id), n += "/bLayout-" + o + ".json"
                        } else n = I.getBannerSDKAssestsUrl() + ("/" + b.bannerName + (L.useRTL ? "Rtl" : "")) + ".json";
                        return r = l.bAsset, i = t, [4, this.otFetch(n)];
                    case 1:
                        r[i] = e.sent(), e.label = 2;
                    case 2:
                        return [2, l.bAsset[t]]
                }
            })
        })
    }, Wt.prototype.getCommonStyles = function(i) {
        return void 0 === i && (i = !1), F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = L.useRTL ? Se.RTL : Se.LTR, l.cStyles[t] && !i) ? [3, 2] : (o = I.getBannerSDKAssestsUrl() + "/otCommonStyles" + (L.useRTL ? "Rtl" : "") + ".css", n = l.cStyles, r = t, [4, this.otFetch(o, !0)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, l.cStyles[t]]
                }
            })
        })
    }, Wt.prototype.getSyncNtfyContent = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = L.useRTL ? Se.RTL : Se.LTR, l.syncNtfyContent[t]) ? [3, 2] : (o = I.getBannerSDKAssestsUrl() + "/otSyncNotification" + (L.useRTL ? "Rtl" : "") + ".json", n = l.syncNtfyContent, r = t, [4, this.otFetch(o)]);
                    case 1:
                        n[r] = e.sent(), e.label = 2;
                    case 2:
                        return [2, l.syncNtfyContent[t]]
                }
            })
        })
    }, Wt.prototype.getConsentProfile = function(e, t) {
        var o = this,
            n = {
                Identifier: e,
                TenantId: l.tenantId,
                Authorization: t
            };
        return new Promise(function(e) {
            o.getJSON(l.consentApi, n, e, e)
        })
    }, Wt.prototype.checkIfRequiresPollyfill = function() {
        var e = window.navigator.userAgent;
        return 0 < e.indexOf("MSIE ") || 0 < e.indexOf("Trident/") || "undefined" == typeof Set
    }, Wt.prototype.otFetch = function(r, i, s, a) {
        return void 0 === i && (i = !1), void 0 === s && (s = !1), void 0 === a && (a = !1), F(this, void 0, void 0, function() {
            var t, o, n = this;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return I.checkMobileOfflineRequest(r) ? [4, I.otFetchOfflineFile(r)] : [3, 2];
                    case 1:
                        return [2, e.sent()];
                    case 2:
                        return e.trys.push([2, 9, , 10]), b.mobileOnlineURL.push(r), "undefined" != typeof fetch ? [3, 3] : [2, new Promise(function(e) {
                            n.getJSON(r, null, e, e, i)
                        })];
                    case 3:
                        return [4, fetch(r)];
                    case 4:
                        return (t = e.sent(), s && t.headers.get("Access-Control-Allow-Credentials")) ? [2, Promise.resolve()] : (a && t.headers.get("X-OneTrust-IsBot") && (l.isBotHeader = "true" === t.headers.get("X-OneTrust-IsBot").toLowerCase()), i ? [4, t.text()] : [3, 6]);
                    case 5:
                        return [2, e.sent()];
                    case 6:
                        return [4, t.json()];
                    case 7:
                        return [2, e.sent()];
                    case 8:
                        return [3, 10];
                    case 9:
                        return o = e.sent(), console.log("Error in fetch URL : " + r + " Exception :" + o), [3, 10];
                    case 10:
                        return [2]
                }
            })
        })
    }, Wt.prototype.getJSON = function(e, t, o, n, r) {
        void 0 === t && (t = null), void 0 === r && (r = !1);
        var i = new XMLHttpRequest;
        if (i.open("GET", e, !0), i.withCredentials = !1, t)
            for (var s in t) i.setRequestHeader(s, t[s]);
        i.onload = function() {
            var e;
            200 <= this.status && this.status < 400 && this.responseText ? (e = void 0, e = r ? this.responseText : JSON.parse(this.responseText), o(e)) : n({
                message: "Error Loading Data",
                statusCode: this.status
            })
        }, i.onerror = function(e) {
            n(e)
        }, i.send()
    }, Wt.prototype.getGeolocation = function(t) {
        return F(this, void 0, void 0, function() {
            var o, n = this;
            return M(this, function(e) {
                return o = this.getGeolocationURL(t), [2, new Promise(function(e, t) {
                    n.getJSON(o, {
                        accept: "application/json"
                    }, e, t)
                })]
            })
        })
    }, Wt.prototype.getGeolocationURL = function(e) {
        var t = l.storageBaseURL + "/scripttemplates/" + e.Version;
        return new RegExp("^file://", "i").test(t) && e.MobileSDK ? "./" + e.GeolocationUrl.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/") + ".js" : e.GeolocationUrl
    };
    var Kt, zt = Wt;

    function Wt() {}
    var I, Yt = "groups",
        Jt = "hosts",
        Xt = "genVendors",
        Qt = "vs",
        Zt = ($t.prototype.addLogoUrls = function() {
            I.checkMobileOfflineRequest(I.getBannerVersionUrl()) || (b.mobileOnlineURL.push(I.updateCorrectUrl(L.optanonLogo)), b.mobileOnlineURL.push(I.updateCorrectUrl(L.oneTrustFtrLogo)))
        }, $t.prototype.getCookieLabel = function(e, t, o) {
            var n;
            return void 0 === o && (o = !0), e ? (n = e.Name, t ? '\n                <a  class="cookie-label"\n                    href="' + (o ? "https://cookiepedia.co.uk/cookies/" : "https://cookiepedia.co.uk/host/") + e.Name + '"\n                    rel="noopener noreferrer"\n                    target="_blank"\n                >\n                    ' + e.Name + '&nbsp;<span class="ot-scrn-rdr">' + L.NewWinTxt + "</span>\n                </a>\n            " : n) : ""
        }, $t.prototype.getBannerSDKAssestsUrl = function() {
            return this.getBannerVersionUrl() + "/assets"
        }, $t.prototype.getBannerVersionUrl = function() {
            var e = b.bannerScriptElement.getAttribute("src");
            return "" + (-1 !== e.indexOf("/consent/") ? e.split("consent/")[0] + "scripttemplates/" : e.split("otSDKStub")[0]) + S.moduleInitializer.Version
        }, $t.prototype.checkMobileOfflineRequest = function(e) {
            return S.moduleInitializer.MobileSDK && new RegExp("^file://", "i").test(e)
        }, $t.prototype.updateCorrectIABUrl = function(e) {
            var t, o = S.moduleInitializer.ScriptType;
            return o !== qe.LOCAL && o !== qe.LOCAL_TEST || (o = P.getURL(e), (t = (t = b.bannerScriptElement) && t.getAttribute("src") ? P.getURL(t.getAttribute("src")) : null) && o && t.hostname !== o.hostname && (e = (e = (t = "" + b.bannerDataParentURL) + o.pathname.split("/").pop().replace(/(^\/?)/, "/")).replace(o.hostname, t.hostname))), e
        }, $t.prototype.updateCorrectUrl = function(e, t) {
            if ((void 0 === t && (t = !1), b.previewMode) && new RegExp("^data:image/").test(e)) return e;
            var o = P.getURL(e),
                n = b.bannerScriptElement,
                n = n && n.getAttribute("src") ? P.getURL(n.getAttribute("src")) : null;
            if (n && o && n.hostname !== o.hostname) {
                var r = S.moduleInitializer.ScriptType;
                if (r === qe.LOCAL || r === qe.LOCAL_TEST) {
                    if (t) return e;
                    n = b.bannerDataParentURL + "/" + b.getRegionRule().Id, b.canUseConditionalLogic && (n += "/" + b.Condition.Id), e = n + (null == (r = null == (r = e) ? void 0 : r.replace(null == (t = S.moduleInitializer) ? void 0 : t.CDNLocation, "")) ? void 0 : r.replace(/(^\/?)/, "/"))
                } else e = null == (t = e) ? void 0 : t.replace(o.hostname, n.hostname)
            }
            return e
        }, $t.prototype.isBundleOrStackActive = function(n, r) {
            void 0 === r && (r = null);
            for (var i = _.oneTrustIABConsent, s = !0, a = (r = r || _.groupsConsent, 0);
                (() => {
                    var e, t, o = n.SubGroups[a];
                    o && o.Status !== f.ALWAYS_ACTIVE && (o.Type === kt ? (-1 < (t = P.findIndex(r, function(e) {
                        return e.split(":")[0] === o.CustomGroupId
                    })) && "0" === r[t].split(":")[1] || !r.length) && (s = !1) : (e = o.Type === k.GroupTypes.Spl_Ft ? i.specialFeatures : i.purpose, (-1 < (t = P.findIndex(e, function(e) {
                        return e.split(":")[0] === o.IabGrpId
                    })) && "false" === e[t].split(":")[1] || !e.length) && (s = !1))), a++
                })(), s && a < n.SubGroups.length;);
            return s
        }, $t.prototype.otFetchOfflineFile = function(n) {
            return F(this, void 0, void 0, function() {
                var t, o;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return n = n.replace(".json", ".js"), t = n.split("/"), t = t[t.length - 1], o = t.split(".js")[0], [4, new Promise(function(e) {
                                function t() {
                                    e(window[o])
                                }
                                I.jsonp(n, t, t)
                            })];
                        case 1:
                            return [2, e.sent()]
                    }
                })
            })
        }, $t.prototype.jsonp = function(e, t, o, n) {
            void 0 === n && (n = ""), I.checkMobileOfflineRequest(e) || b.mobileOnlineURL.push(e);
            var r = document.createElement("script"),
                i = document.getElementsByTagName("head")[0];

            function s() {
                t()
            }
            r.onreadystatechange = function() {
                "loaded" !== this.readyState && "complete" !== this.readyState || s()
            }, r.id = n, r.onload = s, r.onerror = function() {
                o()
            }, r.type = "text/javascript", b.sriHash && (e.includes("otTCF") && null != (n = b.sriHash) && n["otTCF.js"] && (r.integrity = b.sriHash["otTCF.js"]), e.includes("otGPP") && null != (n = b.sriHash) && n["otGPP.js"] && (r.integrity = b.sriHash["otGPP.js"]), e.includes("otConfirmDialog")) && null != (n = b.sriHash) && n["otConfirmDialog.js"] && (r.integrity = b.sriHash["otConfirmDialog.js"]), r.async = !0, r.src = m.getScriptUrl(e), _.crossOrigin && r.setAttribute("crossorigin", _.crossOrigin), i.appendChild(r)
        }, $t.prototype.isCookiePolicyPage = function(e) {
            for (var t = !1, o = P.removeURLPrefixes(window.location.href), n = v("<div></div>", "ce").el, r = (v(n).html(e), n.querySelectorAll("a")), i = 0; i < r.length; i++)
                if (P.removeURLPrefixes(r[i].href) === o) {
                    t = !0;
                    break
                }
            return t
        }, $t.prototype.isBannerVisible = function() {
            var e = !1,
                t = document.getElementById("onetrust-banner-sdk");
            return e = t && t.getAttribute("style") ? -1 === t.getAttribute("style").replace(/\s/g, "").indexOf("display:none") : e
        }, $t.prototype.hideBanner = function() {
            var e, t = this;
            _.bnrAnimationInProg ? setTimeout(function() {
                return t.hideBanner()
            }, 100) : (v("#onetrust-banner-sdk").fadeOut(400), null != (e = null == (e = window.OneTrust_ConfirmDialog) ? void 0 : e.getInstance()) && e.close())
        }, $t.prototype.resetFocusToBody = function() {
            document.activeElement && document.activeElement.blur()
        }, $t.prototype.getDuration = function(e) {
            var t, o = e.Length,
                e = e.DurationType;
            return o && 0 !== parseInt(o) ? (o = parseInt(o), e ? (t = 1 < (o = this.round_to_precision(o / e, .5)) ? Ct[e] + "s" : Ct[e], L.LifespanDurationText && 1 === e && (t = "LifespanDurationText"), o + " " + L[t]) : this.getDurationText(o)) : L.LfSpanSecs
        }, $t.prototype.isDateCurrent = function(e) {
            var e = e.split("/"),
                t = parseInt(e[1]),
                o = parseInt(e[0]),
                e = parseInt(e[2]),
                n = new Date,
                r = n.getDate(),
                i = n.getFullYear(),
                n = n.getMonth() + 1;
            return i < e || e === i && n < o || e === i && o === n && r <= t
        }, $t.prototype.insertFooterLogo = function(e) {
            var t = v(e).el;
            if (t.length && L.oneTrustFtrLogo) {
                var o = I.updateCorrectUrl(L.oneTrustFtrLogo);
                I.checkMobileOfflineRequest(I.getBannerVersionUrl()) && (o = P.getRelativeURL(o, !0, !0));
                for (var n = 0; n < t.length; n++) {
                    var r, i, s = "Powered by OneTrust " + L.NewWinTxt,
                        a = (v(t[n]).attr("href", L.pCFooterLogoUrl), v(t[n]).attr("aria-label", s), t[n].querySelector("img"));
                    S.fp.CMPIconSprite ? (t[n].removeChild(a), r = "#" + new URL(o, window.location.origin).pathname.split("/").pop().split(".").shift(), (i = document.createElementNS("http://www.w3.org/2000/svg", "svg")).classList.add("ot-footer-svg-logo"), i.innerHTML = "<use></use>", i.setAttribute("title", s), i.querySelector("use").setAttribute("href", r), t[n].appendChild(i)) : (a.setAttribute("src", o), a.setAttribute("title", s))
                }
            }
        }, $t.prototype.getUTCFormattedDate = function(e) {
            e = new Date(e);
            return e.getUTCFullYear() + "-" + (e.getUTCMonth() + 1).toString().padStart(2, "0") + "-" + e.getUTCDate().toString().toString().padStart(2, "0") + " " + e.getUTCHours() + ":" + e.getUTCMinutes().toString().toString().padStart(2, "0") + ":" + e.getUTCSeconds().toString().toString().padStart(2, "0")
        }, $t.prototype.getDurationText = function(e) {
            return 365 <= e ? (e = this.round_to_precision(e /= 365, .5)) + " " + (1 < e ? L.LfSpnYrs : L.LfSpnYr) : L.LifespanDurationText ? e + " " + L.LifespanDurationText : e + " " + (1 < e ? L.PCenterVendorListLifespanDays : L.PCenterVendorListLifespanDay)
        }, $t.prototype.round_to_precision = function(e, t) {
            e = +e + (void 0 === t ? .5 : t / 2);
            return e - e % (void 0 === t ? 1 : +t)
        }, $t.prototype.isOptOutEnabled = function() {
            return L.PCTemplateUpgrade ? _.genVenOptOutEnabled : L.allowHostOptOut
        }, $t.prototype.findUserType = function(e) {
            _.isKeyboardUser = !(!e || 0 !== e.detail)
        }, $t.prototype.getCSSPropsFromString = function(e) {
            var t, o;
            return e ? (t = e.length, o = {}, (e = e.endsWith(";") ? e.substring(0, t - 1) : e).trim().split(";").forEach(function(e) {
                e = e.trim().toString().split(":"), e = JSON.parse('{ "' + e[0].trim() + '" : "' + e[1].trim() + '" }');
                o = Object.assign(o, e)
            }), o) : {}
        }, $t.prototype.setCloseIcon = function(e) {
            var t, o, n = I.updateCorrectUrl(L.OTCloseBtnLogo),
                r = v(e);
            r.length && (t = e.querySelector("svg"), S.fp.CMPIconSprite && n && !t ? (t = new URL(n, window.location.origin).pathname.split("/").pop().split(".").shift(), (o = document.createElementNS("http://www.w3.org/2000/svg", "svg")).classList.add("ot-svg-icon"), o.innerHTML = "<use></use>", o.querySelector("use").setAttribute("href", "#" + t), e.appendChild(o)) : d(r.el, 'background-image: url("' + n + '")', !0))
        }, $t.prototype.createOptOutSignalElement = function(e, t) {
            var o = e(t ? "#ot-pc-content" : "#onetrust-policy"),
                n = document.createElement("div"),
                r = (n.classList.add("ot-optout-signal"), document.createElement("div")),
                i = (r.classList.add("ot-optout-icon"), document.createElement("span"));
            return i.innerText = this.getOptOutSignalText(t), n.append(r), n.append(i), null != (t = o) && t.prepend(n), this.applyGuardLogo(e), n
        }, $t.prototype.getOptOutSignalText = function(e) {
            if (null !== O.alertBoxCloseDate()) {
                if (e && L.PCOptOutSignalTextAfterConsent) return L.PCOptOutSignalTextAfterConsent;
                if (!e && L.BOptOutSignalTextAfterConsent) return L.BOptOutSignalTextAfterConsent
            }
            return e ? L.PCOptOutSignalText : L.BOptOutSignalText
        }, $t.prototype.shouldShowDoubleOptInSignal = function(n) {
            var e, t, r, i;
            return void 0 === n && (n = !1), !(!L.PCShowDoubleOptInSignal || (t = !!(e = _.isPCVisible ? document.getElementById("onetrust-pc-sdk") : document.getElementById("onetrust-banner-sdk")) && "none" !== window.getComputedStyle(e).display, !e) || !t) && (e = T.readCookieParam(y.OPTANON_CONSENT, Yt), t = P.strToArr(e), r = I.getGroupConsentMap(t), i = I.getGroupConsentMap(_.groupsConsent), null == (e = L.Groups) ? void 0 : e.some(function(e) {
                var t = e.Status === f.ACTIVE,
                    o = b.gpcEnabled && e.IsGpcEnabled;
                if (t || o) {
                    t = e.CustomGroupId;
                    if ("0" === r[t] && ("1" === i[t] || n)) return !0
                }
                return !1
            }))
        }, $t.prototype.getGroupConsentMap = function(e) {
            return null == (e = e) ? void 0 : e.reduce(function(e, t) {
                t = t.split(":");
                return e[t[0]] = t[1], e
            }, {})
        }, $t.prototype.createDoubleOptInConfirmDialog = function(e, t, o) {
            var n = null == (n = window.OneTrust_ConfirmDialog) ? void 0 : n.getInstance();
            n && (n.create({
                text: L.PCDoubleOptInSignalText,
                description: L.PCDoubleOptInSignalDescription,
                cancelText: L.PCDoubleOptInSignalCancelText,
                confirmText: L.PCDoubleOptInSignalConfirmText,
                onConfirm: t,
                onCancel: o
            }).open(e ? "#onetrust-pc-sdk" : "#onetrust-banner-sdk"), I.setCloseIcon(document.querySelector(".ot-confirm-dialog .ot-close-icon")))
        }, $t.prototype.applyGuardLogo = function(i) {
            return F(this, void 0, void 0, function() {
                var t, o, n, r;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return S.fp.CMPIconSprite ? (n = "<svg aria-hidden=\"true\">\n            <use href='#ot_opt_out_signal'></use>\n            </svg>", v(i(".ot-optout-icon")).html(n), v(i(".ot-optout-icon svg")).attr("class", "ot-source-sprite"), [3, 3]) : [3, 1];
                        case 1:
                            return (t = L.cookiePersistentLogo).includes("ot_guard_logo.svg") || (o = L.OTCloseBtnLogo, r = o.indexOf("static/"), t = o.replace(o.slice(r + 7), "ot_guard_logo.svg")), (o = S.moduleInitializer.ScriptType) !== qe.LOCAL && o !== qe.LOCAL_TEST || (t = I.updateCorrectUrl(t)), [4, Kt.getPersistentCookieSvg(t)];
                        case 2:
                            n = e.sent(), r = (r = n) && n.replace(/<svg([\s\S]*?)>/i, '<svg$1 aria-hidden="true">'), v(".ot-optout-icon").html(r), e.label = 3;
                        case 3:
                            return [2]
                    }
                })
            })
        }, $t.prototype.updateTCString = function() {
            var e = O.iabStringSDK().tcString().encode(_.tcModel);
            _.cmpApi.update(e, !1)
        }, $t.prototype.replaceTextFromString = function(e, t, o) {
            return t.split(e).join(o)
        }, $t.prototype.getStubQueryParam = function(e) {
            var t = b.stubUrl || window.otStubData && window.otStubData.stubUrl;
            return !t || (t = t.split("?")).length < 2 ? null : new URLSearchParams(t[1]).get(e)
        }, $t.prototype.getStubAttr = function(e) {
            var t = b.bannerScriptElement,
                t = t && t.getAttribute(e);
            return t || I.getStubQueryParam(e)
        }, $t.prototype.getVendorPageHeaderText = function() {
            var e = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]');
            return e instanceof HTMLElement ? e.innerText : ""
        }, $t.prototype.replaceHeadings = function(e) {
            var t;
            if (null != (t = S.moduleInitializer) && t.SEOOptimization)
                for (var o = 1; o <= 6; o++)(n => {
                    e.querySelectorAll("h" + n).forEach(function(e) {
                        var t, o = document.createElement("p");
                        o.setAttribute("role", "heading"), o.setAttribute("aria-level", n.toString()), o.innerHTML = e.innerHTML, e.className && (o.className = e.className), e.id && (o.id = e.id), e.title && (o.title = e.title), null != (t = e.parentNode) && t.replaceChild(o, e)
                    })
                })(o)
        }, $t.prototype.addExternalIconForLinks = function(e) {
            var o;
            L.BannerRequireExternalLinks && (o = S.fp.CMPIconSprite && L.OTExternalLinkLogo && !L.BannerExternalLinksLogo, e('a[target="_blank"]').forEach(function(e) {
                var t = e.parentElement;
                t && "DIV" === t.tagName && (t.classList.contains("ot-pc-footer-logo") || t.classList.contains("ot-bnr-footer-logo")) || (o ? (t = I.updateCorrectUrl(L.OTExternalLinkLogo), t = L.BannerExternalLinksLogo ? I.updateCorrectUrl(L.BannerExternalLinksLogo) : t, t = new URL(t, window.location.origin).pathname.split("/").pop().split(".").shift(), e.insertAdjacentHTML("afterend", m.getInnerHtmlContent("<svg class='ot-ext-lnk'>\n                                <use href='#" + t + "'></use>\n                                </svg>"))) : e.classList.add("ot-ext-lnk"))
            }))
        }, $t);

    function $t() {}
    t.prototype.getPurposeOneGrpId = function() {
        return k.IdPatterns.Pur + "1"
    }, t.prototype.setRegionRule = function(e) {
        this.rule = e
    }, t.prototype.getRegionRule = function() {
        return this.rule
    }, t.prototype.getRegionRuleType = function() {
        return this.multiVariantTestingEnabled && this.selectedVariant ? this.selectedVariant.TemplateType : this.conditionalLogicEnabled && !this.allConditionsFailed ? this.Condition.TemplateType : this.rule.Type
    }, t.prototype.getTemplateName = function() {
        return this.multiVariantTestingEnabled && this.selectedVariant ? this.selectedVariant.Name : (this.canUseConditionalLogic ? this.Condition : this.rule).TemplateName
    }, t.prototype.isGroupExistInImpliedConsentableGroup = function(t) {
        return b.consentableImpliedConsentGroup.some(function(e) {
            return e.CustomGroupId === t.CustomGroupId
        })
    }, t.prototype.removeGroupFromImpliedConsentableGroup = function(t) {
        this.consentableImpliedConsentGroup = this.consentableImpliedConsentGroup.filter(function(e) {
            return e.CustomGroupId !== t.CustomGroupId
        })
    }, t.prototype.initConsentableImpliedConsentGroup = function(e) {
        var t = this;
        e.forEach(function(e) {
            e.Status === f.INACTIVE_LANDING_PAGE && t.consentableImpliedConsentGroup.push(e)
        })
    }, t.prototype.resetImpliedConsentableGroups = function() {
        this.consentableImpliedConsentGroup = this.consentableGrps.filter(function(e) {
            return e.Status === f.INACTIVE_LANDING_PAGE
        })
    }, t.prototype.canUseGoogleVendors = function(e) {
        return !!e && (this.conditionalLogicEnabled && !this.allConditionsFailed ? this.Condition : this.rule).UseGoogleVendors
    }, t.prototype.initVariables = function() {
        this.consentableGrps = [], this.consentableImpliedConsentGroup = [], this.consentableIabGrps = [], this.iabGrps = [], this.iabGrpIdMap = {}, this.domainGrps = {}, this.iabGroups = {
            purposes: {},
            legIntPurposes: {},
            specialPurposes: {},
            features: {},
            specialFeatures: {}
        }
    }, t.prototype.init = function(e) {
        this.getGPCSignal(), this.initVariables();
        var t = e.DomainData;
        this.setPublicDomainData(JSON.parse(JSON.stringify(t))), this.domainDataMapper(t), this.commonDataMapper(e.CommonData), L.NtfyConfig = e.NtfyConfig || {}, this.setBannerName(), this.setPcName(), this.populateGPCSignal(), this.populateGPCBrowserSignal(), L.GoogleConsent.GCEnable && this.initGCM()
    }, t.prototype.getGPCSignal = function() {
        navigator.globalPrivacyControl ? this.gpcEnabled = !0 : this.gpcEnabled = !1
    }, t.prototype.isValidConsentNoticeGroup = function(e, t) {
        var o, n, r, i, s, a;
        return !!e.ShowInPopup && (o = this.isGroupHasCookies(e), s = i = r = n = !1, null != (a = e) && a.Parent || (e.SubGroups.length && (n = e.SubGroups.some(function(e) {
            return e.GroupName && e.ShowInPopup && e.FirstPartyCookies.length
        }), r = e.SubGroups.some(function(e) {
            return e.GroupName && e.ShowInPopup && (e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length)
        }), i = e.SubGroups.some(function(e) {
            return e.GroupName && e.AlwaysShowCategory
        }), !t || e.FirstPartyCookies.length && e.Hosts.length || (s = !e.SubGroups.some(function(e) {
            return -1 === _t.indexOf(e.Type)
        }))), a = e.SubGroups.some(function(e) {
            return -1 < _t.indexOf(e.Type)
        }), (-1 < _t.indexOf(e.Type) || a) && (e.ShowVendorList = !0), (e.Hosts.length || r || n) && (e.ShowHostList = !0)), this.isValidGroup(o, e, n, r, s, i))
    }, t.prototype.isValidGroup = function(e, t, o, n, r, i) {
        var s = l.showVendorService && t.VendorServices && t.VendorServices.length;
        return !!t.AlwaysShowCategory || e || -1 < _t.indexOf(t.Type) || o || n || i || r || s
    }, t.prototype.isGroupHasCookies = function(e) {
        return e.FirstPartyCookies.length || e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length || e.VendorServices && e.VendorServices.length
    }, t.prototype.extractGroupIdForIabGroup = function(e) {
        return -1 < e.indexOf(k.IdPatterns.Spl_Pur) ? e = e.replace(k.IdPatterns.Spl_Pur, "") : -1 < e.indexOf(k.IdPatterns.Pur) ? e = e.replace(k.IdPatterns.Pur, "") : -1 < e.indexOf(k.IdPatterns.Ft) ? e = e.replace(k.IdPatterns.Ft, "") : -1 < e.indexOf(k.IdPatterns.Spl_Ft) && (e = e.replace(k.IdPatterns.Spl_Ft, "")), e
    }, t.prototype.isIabGrpAndNonConsentable = function(e) {
        var t = k.GroupTypes;
        return !this.isIab2orv2Template && -1 < _t.indexOf(e.Type) || this.isIab2orv2Template && (e.Type === t.Pur || e.Type === t.Stack) && !e.HasConsentOptOut && !e.HasLegIntOptOut || e.Type === t.Spl_Ft && !e.HasConsentOptOut
    }, t.prototype.setTcfPurposeParentMapForGrp = function(e) {
        var t = k.GroupTypes;
        if (this.isTcfV2Template && e.Parent) switch (e.Type) {
            case t.Pur:
                this.tcfParentMap.pur.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Spl_Pur:
                this.tcfParentMap.spl_pur.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Ft:
                this.tcfParentMap.ft.set(parseInt(e.IabGrpId), e.Parent);
                break;
            case t.Spl_Ft:
                this.tcfParentMap.spl_ft.set(parseInt(e.IabGrpId), e.Parent)
        }
    }, t.prototype.populateGroups = function(e, r) {
        var i = this,
            s = {},
            a = [],
            l = k.GroupTypes,
            t = (e.forEach(function(e) {
                var t = e.CustomGroupId;
                if (i.setHealthSignatureDataIntoGroup(r, e), void 0 !== e.HasConsentOptOut && e.IsIabPurpose || (e.HasConsentOptOut = !0), !i.isIabGrpAndNonConsentable(e)) {
                    if (t !== b.getPurposeOneGrpId() || e.ShowInPopup || (i.purposeOneTreatment = !0), i.grpContainLegalOptOut = e.HasLegIntOptOut || i.grpContainLegalOptOut, e.SubGroups = [], e.Parent ? a.push(e) : s[t] = e, i.isIab2orv2Template && -1 < _t.indexOf(e.Type)) {
                        var o = i.extractGroupIdForIabGroup(t),
                            n = (i.iabGrpIdMap[t] = o, e.IabGrpId = o, {
                                description: e.GroupDescription,
                                descriptionLegal: e.DescriptionLegal,
                                id: Number(o),
                                name: e.GroupName
                            });
                        switch (e.Type) {
                            case l.Pur:
                                i.iabGroups.purposes[o] = n;
                                break;
                            case l.Spl_Pur:
                                i.iabGroups.specialPurposes[o] = n;
                                break;
                            case l.Ft:
                                i.iabGroups.features[o] = n;
                                break;
                            case l.Spl_Ft:
                                i.iabGroups.specialFeatures[o] = n
                        }
                    }
                    i.setTcfPurposeParentMapForGrp(e)
                }
            }), a.forEach(function(e) {
                s[e.Parent] && e.ShowInPopup && (e.AlwaysShowCategory || e.FirstPartyCookies.length || e.Hosts.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length || -1 < _t.indexOf(e.Type)) && s[e.Parent].SubGroups.push(e)
            }), []);
        return Object.keys(s).forEach(function(e) {
            i.isValidConsentNoticeGroup(s[e], r.IsIabEnabled) && (s[e].SubGroups.sort(function(e, t) {
                return e.Order - t.Order
            }), t.push(s[e]))
        }), this.initGrpVar(t), t.sort(function(e, t) {
            return e.Order - t.Order
        })
    }, t.prototype.setHealthSignatureDataIntoGroup = function(e, t) {
        this.requireSignatureEnabled && e.RequireSignatureCID === t.CustomGroupId && (t.needsHealthSignature = !0, "1" === T.readCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION)) && (t.healthSignatureId = T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID))
    }, t.prototype.isGrpConsentable = function(e) {
        var t = k.GroupTypes;
        return e.Type === t.Cookie || e.Type === t.Pur || e.Type === t.Spl_Ft
    }, t.prototype.initGrpVar = function(e) {
        var o = this,
            n = !0,
            r = !0;
        e.forEach(function(e) {
            U([e], e.SubGroups).forEach(function(e) {
                var t;
                o.isGrpConsentable(e) && (o.domainGrps[e.PurposeId.toLowerCase()] = e.CustomGroupId), -1 < Et.indexOf(e.Type) && o.consentableGrps.push(e), -1 < Ot.indexOf(e.Type) && o.consentableIabGrps.push(e), -1 === Et.indexOf(e.Type) && o.iabGrps.push(e), o.gpcEnabled && e.IsGpcEnabled && (e.Status = f.INACTIVE), (t = o.DNTEnabled && e.IsDntEnabled ? f.DNT : e.Status.toLowerCase()) !== f.ACTIVE && t !== f.INACTIVE_LANDING_PAGE && t !== f.DNT || (n = !1), t !== f.INACTIVE_LANDING_PAGE && t !== f.ALWAYS_ACTIVE && (r = !1), o.gpcForAGrpEnabled || (o.gpcForAGrpEnabled = e.IsGpcEnabled)
            })
        }), this.isOptInMode = n, this.isSoftOptInMode = r
    }, t.prototype.domainDataMapper = function(e) {
        this.requireSignatureEnabled = (null == (t = S.fp) ? void 0 : t.CookieV2SubmitPurpose) && e.IsRequireSignatureEnabled && e.PCTemplateUpgrade;
        var t = {
            AriaClosePreferences: e.AriaClosePreferences,
            AriaOpenPreferences: e.AriaOpenPreferences,
            AriaPrivacy: e.AriaPrivacy,
            CenterRounded: e.CenterRounded,
            Flat: e.Flat,
            FloatingFlat: e.FloatingFlat,
            FloatingRounded: e.FloatingRounded,
            FloatingRoundedCorner: e.FloatingRoundedCorner,
            FloatingRoundedIcon: e.FloatingRoundedIcon,
            VendorLevelOptOut: e.IsIabEnabled,
            AboutCookiesText: e.AboutCookiesText,
            AboutLink: e.AboutLink,
            AboutText: e.AboutText,
            ActiveText: e.ActiveText,
            AddLinksToCookiepedia: e.AddLinksToCookiepedia,
            AlertAllowCookiesText: e.AlertAllowCookiesText,
            AlertCloseText: e.AlertCloseText,
            AlertLayout: e.AlertLayout,
            AlertMoreInfoText: e.AlertMoreInfoText,
            AlertMoreInfoTextDialog: e.AlertMoreInfoTextDialog,
            AlertNoticeText: e.AlertNoticeText,
            AllowAllText: e.PreferenceCenterConfirmText,
            AlwaysActiveText: e.AlwaysActiveText,
            AlwaysInactiveText: e.AlwaysInactiveText,
            BannerAdditionalDescPlacement: e.BannerAdditionalDescPlacement,
            BannerAdditionalDescription: e.BannerAdditionalDescription,
            BannerCloseButtonText: e.BannerCloseButtonText,
            BannerFeatureDescription: e.BannerFeatureDescription,
            BannerFeatureTitle: e.BannerFeatureTitle,
            BannerIABPartnersLink: e.BannerIABPartnersLink,
            BannerInformationDescription: e.BannerInformationDescription,
            BannerInformationTitle: e.BannerInformationTitle,
            BannerNonIABVendorListText: e.BannerNonIABVendorListText,
            BannerPosition: e.BannerPosition,
            BannerPurposeDescription: e.BannerPurposeDescription,
            BannerPurposeTitle: e.BannerPurposeTitle,
            BannerRejectAllButtonText: e.BannerRejectAllButtonText,
            BannerRelativeFontSizesToggle: e.BannerRelativeFontSizesToggle,
            BannerSettingsButtonDisplayLink: e.BannerSettingsButtonDisplayLink,
            BannerShowRejectAllButton: e.BannerShowRejectAllButton,
            BShowOptOutSignal: e.BShowOptOutSignal,
            BOptOutSignalText: e.BOptOutSignalText,
            BOptOutSignalTextAfterConsent: e.BOptOutSignalTextAfterConsent,
            BRegionAriaLabel: e.BRegionAriaLabel,
            BannerTitle: e.BannerTitle,
            BCloseButtonType: e.BCloseButtonType,
            BContinueText: e.BContinueText,
            BCookiePolicyLinkScreenReader: e.BCookiePolicyLinkScreenReader,
            BnrLogoAria: e.BnrLogoAria,
            BImprintLinkScreenReader: e.BImprintLinkScreenReader,
            BInitialFocus: e.BInitialFocus,
            BInitialFocusLinkAndButton: e.BInitialFocusLinkAndButton,
            BRejectConsentType: e.BRejectConsentType,
            BSaveBtnTxt: e.BSaveBtnText,
            BShowImprintLink: e.BShowImprintLink,
            BShowPolicyLink: e.BShowPolicyLink,
            BShowSaveBtn: e.BShowSaveBtn,
            cctId: e.cctId,
            CanGenerateNotGivenReceipts: e.CanGenerateNotGivenReceipts,
            ChoicesBanner: e.ChoicesBanner,
            CloseShouldAcceptAllCookies: e.CloseShouldAcceptAllCookies,
            CloseText: e.CloseText,
            ConfirmText: e.ConfirmText,
            ConsentModel: {
                Name: e.ConsentModel
            },
            CookieListDescription: e.CookieListDescription,
            CookieListTitle: e.CookieListTitle,
            CookieSettingButtonText: e.CookieSettingButtonText,
            CookiesUsedText: e.CookiesUsedText,
            CustomJs: e.CustomJs,
            firstPartyTxt: e.CookieFirstPartyText,
            FooterDescriptionText: e.FooterDescriptionText,
            ForceConsent: e.ForceConsent,
            GeneralVendors: e.GeneralVendors,
            GeneralVendorsEnabled: e.PCenterUseGeneralVendorsToggle,
            GenVenOptOut: e.PCenterAllowVendorOptout,
            GlobalRestrictionEnabled: e.GlobalRestrictionEnabled,
            GlobalRestrictions: e.GlobalRestrictions,
            GoogleConsent: {
                GCAdStorage: e.GCAdStorage,
                GCAnalyticsStorage: e.GCAnalyticsStorage,
                GCEnable: e.GCEnable,
                GCFunctionalityStorage: e.GCFunctionalityStorage,
                GCPersonalizationStorage: e.GCPersonalizationStorage,
                GCRedactEnable: e.GCRedactEnable,
                GCSecurityStorage: e.GCSecurityStorage,
                GCWaitTime: e.GCWaitTime,
                GCAdUserData: e.GCAdUserData,
                GCAdPersonalization: e.GCAdPersonalization
            },
            MCMData: e.MCMData,
            ACMData: e.ACMData,
            GroupGenVenListLabel: e.PCenterGeneralVendorThirdPartyCookiesText,
            Groups: this.populateGroups(e.Groups, e),
            HideToolbarCookieList: e.HideToolbarCookieList,
            IabType: e.IabType,
            InactiveText: e.InactiveText,
            IsConsentLoggingEnabled: e.IsConsentLoggingEnabled,
            IsIabEnabled: e.IsIabEnabled,
            IsIabThirdPartyCookieEnabled: e.IsIabThirdPartyCookieEnabled,
            IsLifespanEnabled: e.IsLifespanEnabled,
            Language: e.Language,
            LastReconsentDate: e.LastReconsentDate,
            LfSpanSecs: e.PCLifeSpanSecs,
            LfSpnWk: e.PCLifeSpanWk,
            LfSpnWks: e.PCLifeSpanWks,
            LfSpnYr: e.PCLifeSpanYr,
            LfSpnYrs: e.PCLifeSpanYrs,
            LifespanDurationText: e.LifespanDurationText,
            MainInfoText: e.MainInfoText,
            MainText: e.MainText,
            ManagePreferenceText: e.PreferenceCenterManagePreferencesText,
            NewVendorsInactiveEnabled: e.NewVendorsInactiveEnabled,
            NewWinTxt: e.PreferenceCenterMoreInfoScreenReader,
            NextPageAcceptAllCookies: e.NextPageAcceptAllCookies,
            NextPageCloseBanner: e.NextPageCloseBanner,
            NoBanner: e.NoBanner,
            OnClickAcceptAllCookies: e.OnClickAcceptAllCookies,
            OnClickCloseBanner: e.OnClickCloseBanner,
            OverriddenVendors: null != (t = e.OverriddenVendors) ? t : {},
            OverridenGoogleVendors: null != (t = e.OverridenGoogleVendors) ? t : {},
            Publisher: e.publisher,
            PublisherCC: e.PublisherCC,
            ReconsentFrequencyDays: e.ReconsentFrequencyDays,
            ScrollAcceptAllCookies: e.ScrollAcceptAllCookies,
            ScrollCloseBanner: e.ScrollCloseBanner,
            ShowAlertNotice: e.ShowAlertNotice,
            showBannerCloseButton: e.showBannerCloseButton,
            ShowPreferenceCenterCloseButton: e.ShowPreferenceCenterCloseButton,
            ThirdPartyCookieListText: e.ThirdPartyCookieListText,
            thirdPartyTxt: e.CookieThirdPartyText,
            UseGoogleVendors: this.canUseGoogleVendors(e.PCTemplateUpgrade),
            VendorConsentModel: e.VendorConsentModel,
            VendorListText: e.VendorListText,
            Vendors: e.Vendors,
            PCCategoryStyle: e.PCCategoryStyle || ve.Checkbox,
            PCShowAlwaysActiveToggle: e.PCShowAlwaysActiveToggle,
            PCenterImprintLinkScreenReader: e.PCenterImprintLinkScreenReader,
            PCenterImprintLinkText: e.PCenterImprintLinkText,
            PCenterImprintLinkUrl: e.PCenterImprintLinkUrl,
            PCShowOptOutSignal: e.PCShowOptOutSignal,
            PCShowDoubleOptInSignal: e.PCShowDoubleOptInSignal,
            PCDoubleOptInSignalText: e.PCDoubleOptInSignalText,
            PCDoubleOptInSignalDescription: e.PCDoubleOptInSignalDescription,
            PCDoubleOptInSignalConfirmText: e.PCDoubleOptInSignalConfirmText,
            PCDoubleOptInSignalCancelText: e.PCDoubleOptInSignalCancelText,
            PCOptOutSignalText: e.PCOptOutSignalText,
            PCOptOutSignalTextAfterConsent: e.PCOptOutSignalTextAfterConsent,
            PCRegionAriaLabel: e.PCRegionAriaLabel,
            PCHostNotFound: e.PCHostNotFound,
            PCVendorNotFound: e.PCVendorNotFound,
            PCTechNotFound: e.PCTechNotFound,
            UseNonStandardStacks: e.UseNonStandardStacks,
            RequireSignatureCID: e.RequireSignatureCID,
            IsRequireSignatureEnabled: e.IsRequireSignatureEnabled,
            PCRequireSignatureHelpText: e.PCRequireSignatureHelpText,
            PCRequireSignatureFieldLabel: e.PCRequireSignatureFieldLabel,
            PCRequireSignatureHeaderText: e.PCRequireSignatureHeaderText,
            PCRequireSignatureHeaderDesc: e.PCRequireSignatureHeaderDesc,
            PCRequireSignatureRejectBtnText: e.PCRequireSignatureRejectBtnText,
            PCRequireSignatureConfirmBtnText: e.PCRequireSignatureConfirmBtnText,
            PCCookieListFiltersText: e.PCCookieListFiltersText,
            GPCOptOutNoteText: e.GPCOptOutNoteText,
            DNTOptOutNoteText: e.DNTOptOutNoteText
        };
        this.setButtonsOrder(t, e), this.setPCDomainData(t, e), this.setAdditionalTechnologies(t, e), this.setVendorServiceConfigData(t, e), this.setDomainCommonDataDefaults(t, e), this.setDomainPCDataDefaults(t, e), this.setGppData(t, e), e.PCTemplateUpgrade && (e.Center || e.Panel) && (t.PCAccordionStyle = e.PCAccordionStyle), t.PCenterEnableAccordion = e.PCAccordionStyle !== ce.NoAccordion, this.legIntSettings = e.LegIntSettings || {}, void 0 === this.legIntSettings.PAllowLI && (this.legIntSettings.PAllowLI = !0), S.moduleInitializer.MobileSDK || (this.pagePushedDown = e.BannerPushesDownPage), L = R(R({}, L), t)
    }, t.prototype.setButtonsOrder = function(e, t) {
        S.fp.WebButtonCustomisations && (e.PcBO = {
            0: t.PCBPOFirstPosition,
            1: t.PCBPOSecondPosition,
            2: t.PCBPOThirdPosition
        }, e.BannerBO = ((e = {})[t.BannerBPOFirstPosition] = 0, e[t.BannerBPOSecondPosition] = 1, e[t.BannerBPOThirdPosition] = 2, e[t.BannerBPOFourthPosition] = 3, e))
    }, t.prototype.setGppData = function(e, t) {
        e.GPPPurposes = R({}, t.GPPPurposes), e.IsGPPDataProcessingApplicable = t.IsGPPDataProcessingApplicable, e.IsGPPEnabled = t.IsGPPEnabled, e.IsGPPKnownChildApplicable = t.IsGPPKnownChildApplicable, e.IsMSPAEnabled = t.IsMSPAEnabled, e.MSPAOptionMode = t.MSPAOptionMode, e.UseGPPUSNational = t.UseGPPUSNational
    }, t.prototype.setPCDomainData = function(e, t) {
        e.PCAccordionStyle = ce.Caret, e.PCActiveText = t.PCActiveText, e.PCCloseButtonType = t.PCCloseButtonType, e.PCContinueText = t.PCContinueText, e.PCCookiePolicyLinkScreenReader = t.PCCookiePolicyLinkScreenReader, e.PCCookiePolicyText = t.PCCookiePolicyText, e.PCenterAllowAllConsentText = t.PCenterAllowAllConsentText, e.PCenterApplyFiltersText = t.PCenterApplyFiltersText, e.PCenterApplyFiltersAriaLabel = t.PCenterApplyFiltersAriaLabel, e.AmazonConsentSrcUrl = t.AmazonConsentSrcUrl, e.PCenterToggleActiveColor = t.PCenterToggleActiveColor, e.PCenterToggleInActiveColor = t.PCenterToggleInActiveColor, e.PCenterBackText = t.PCenterBackText, e.PCenterCancelFiltersText = t.PCenterCancelFiltersText, e.PCenterCancelFilterAriaLabel = t.PCenterCancelFilterAriaLabel, e.PCenterClearFiltersAriaLabel = t.PCenterClearFiltersAriaLabel, e.PCenterClearFiltersText = t.PCenterClearFiltersText, e.PCenterCookiesListText = t.PCenterCookiesListText, e.PCenterEnableAccordion = t.PCenterEnableAccordion, e.PCenterFilterText = t.PCenterFilterText, e.PCenterGeneralVendorsText = t.PCenterGeneralVendorsText, e.PCenterRejectAllButtonText = t.PCenterRejectAllButtonText, e.PCenterSelectAllVendorsText = t.PCenterSelectAllVendorsText, e.PCenterShowRejectAllButton = t.PCenterShowRejectAllButton, e.PCenterUserIdDescriptionText = t.PCenterUserIdDescriptionText, e.PCenterUserIdNotYetConsentedText = t.PCenterUserIdNotYetConsentedText, e.PCenterUserIdTimestampTitleText = t.PCenterUserIdTimestampTitleText, e.PCenterUserIdTitleText = t.PCenterUserIdTitleText, e.PCenterVendorListDescText = t.PCenterVendorListDescText, e.PCenterVendorListDisclosure = t.PCenterVendorListDisclosure, e.PCenterVendorListLifespan = t.PCenterVendorListLifespan, e.PCenterVendorListLifespanDay = t.PCenterVendorListLifespanDay, e.PCenterVendorListLifespanDays = t.PCenterVendorListLifespanDays, e.PCenterVendorListLifespanMonth = t.PCenterVendorListLifespanMonth, e.PCenterVendorListLifespanMonths = t.PCenterVendorListLifespanMonths, e.PCenterVendorListNonCookieUsage = t.PCenterVendorListNonCookieUsage, e.PCenterVendorListStorageDomain = t.PCenterVendorListStorageDomain, e.PCVLSDomainsUsed = t.PCVLSDomainsUsed, e.PCVLSUse = t.PCVLSUse, e.PCenterVendorListStorageIdentifier = t.PCenterVendorListStorageIdentifier, e.PCenterVendorListStoragePurposes = t.PCenterVendorListStoragePurposes, e.PCenterVendorListStorageType = t.PCenterVendorListStorageType, e.PCenterVendorsListText = t.PCenterVendorsListText, e.PCenterViewPrivacyPolicyText = t.PCenterViewPrivacyPolicyText, e.PCGoogleVendorsText = t.PCGoogleVendorsText, e.PCGrpDescLinkPosition = t.PCGrpDescLinkPosition, e.PCGrpDescType = t.PCGrpDescType, e.PCGVenPolicyTxt = t.PCGeneralVendorsPolicyText, e.PCIABVendorsText = t.PCIABVendorsText, e.PCIABVendorLegIntClaimText = t.PCIABVendorLegIntClaimText, e.PCVListDataDeclarationText = t.PCVListDataDeclarationText, e.PCVListDataRetentionText = t.PCVListDataRetentionText, e.PCVListStdRetentionText = t.PCVListStdRetentionText, e.IABDataCategories = t.IABDataCategories, e.PCInactiveText = t.PCInactiveText, e.PCIllusText = t.PCIllusText, e.PCLogoAria = t.PCLogoScreenReader, e.PCOpensCookiesDetailsAlert = t.PCOpensCookiesDetailsAlert, e.PCenterVendorListScreenReader = t.PCenterVendorListScreenReader, e.PCOpensVendorDetailsAlert = t.PCOpensVendorDetailsAlert, e.PCenterDynamicRenderingEnable = t.PCenterDynamicRenderingEnable, e.PCTemplateUpgrade = t.PCTemplateUpgrade, e.PCVendorFullLegalText = t.PCVendorFullLegalText, e.PCViewCookiesText = t.PCViewCookiesText, e.PCLayout = {
            Center: t.Center,
            List: t.List,
            Panel: t.Panel,
            Popup: t.Popup,
            Tab: t.Tab
        }, e.PCenterVendorListLinkText = t.PCenterVendorListLinkText, e.PCenterVendorListLinkAriaLabel = t.PCenterVendorListLinkAriaLabel, e.PreferenceCenterPosition = t.PreferenceCenterPosition, e.PCVendorsCountText = t.PCVendorsCountText, e.PCVendorsCountFeatureText = t.PCVendorsCountFeatureText, e.PCVendorsCountSpcFeatureText = t.PCVendorsCountSpcFeatureText, e.PCVendorsCountSpcPurposeText = t.PCVendorsCountSpcPurposeText
    }, t.prototype.setVendorServiceConfigData = function(e, t) {
        e.VendorServiceConfig = {
            PCVSOptOut: t.PCVSOptOut,
            PCVSEnable: t.PCVSEnable,
            PCVSExpandCategory: t.PCVSExpandCategory,
            PCVSExpandGroup: t.PCVSExpandGroup,
            PCVSCategoryView: t.PCVSCategoryView,
            PCVSNameText: t.PCVSNameText,
            PCVSAllowAllText: t.PCVSAllowAllText,
            PCVSListTitle: t.PCVSListTitle,
            PCVSParentCompanyText: t.PCVSParentCompanyText,
            PCVSAddressText: t.PCVSAddressText,
            PCVSDefaultCategoryText: t.PCVSDefaultCategoryText,
            PCVSDefaultDescriptionText: t.PCVSDefaultDescriptionText,
            PCVSDPOEmailText: t.PCVSDPOEmailText,
            PCVSDPOLinkText: t.PCVSDPOLinkText,
            PCVSPrivacyPolicyLinkText: t.PCVSPrivacyPolicyLinkText,
            PCVSCookiePolicyLinkText: t.PCVSCookiePolicyLinkText,
            PCVSOptOutLinkText: t.PCVSOptOutLinkText,
            PCVSLegalBasisText: t.PCVSLegalBasisText
        }
    }, t.prototype.setAdditionalTechnologies = function(e, t) {
        e.AdditionalTechnologiesConfig = {
            PCShowTrackingTech: t.PCShowTrackingTech,
            PCCookiesLabel: t.PCCookiesLabel,
            PCTechDetailsText: t.PCTechDetailsText,
            PCTrackingTechTitle: t.PCTrackingTechTitle,
            PCLocalStorageLabel: t.PCLocalStorageLabel,
            PCSessionStorageLabel: t.PCSessionStorageLabel,
            PCTechDetailsAriaLabel: t.PCTechDetailsAriaLabel,
            PCLocalStorageDurationText: t.PCLocalStorageDurationText,
            PCSessionStorageDurationText: t.PCSessionStorageDurationText
        }
    }, t.prototype.setDomainCommonDataDefaults = function(e, t) {
        e.AdvancedAnalyticsCategory = t.AdvancedAnalyticsCategory || "", e.BannerDPDDescription = t.BannerDPDDescription || [], e.BannerDPDDescriptionFormat = t.BannerDPDDescriptionFormat || "", e.BannerDPDTitle = t.BannerDPDTitle || "", e.CategoriesText = t.CategoriesText || "Categories", e.CookiesText = t.CookiesText || "Cookies", e.CookiesDescText = t.CookiesDescText || "Description", e.LifespanText = t.LifespanText || "Lifespan", e.LifespanTypeText = t.LifespanTypeText || "Session", e.PCenterConsentText = t.PCenterConsentText || "Consent"
    }, t.prototype.setDomainPCDataDefaults = function(e, t) {
        e.PCenterCookieListFilterAria = t.PCenterCookieListFilterAria || "Filter", e.PCenterCookieListSearch = t.PCenterCookieListSearch || "Search", e.PCenterCookieSearchAriaLabel = t.PCenterCookieSearchAriaLabel || "Cookie list search", e.PCenterCookieCategoriesAriaLabel = t.PCenterCookieCategoriesAriaLabel || "Cookie Categories", e.PCenterFilterAppliedAria = t.PCenterFilterAppliedAria || "Applied", e.PCenterFilterClearedAria = t.PCenterFilterClearedAria || "Filters Cleared", e.PCenterLegIntColumnHeader = t.PCenterLegIntColumnHeader || "Legitimate Interest", e.PCenterLegitInterestText = t.PCenterLegitInterestText || "Legitimate Interest", e.PCenterVendorListFilterAria = t.PCenterVendorListFilterAria || "Filter", e.PCenterVendorListSearch = t.PCenterVendorListSearch || "Search", e.PCenterVendorSearchAriaLabel = t.PCenterVendorSearchAriaLabel || "Vendor list search", e.PCFirstPartyCookieListText = t.PCFirstPartyCookieListText || "First Party Cookies", e.PCShowConsentLabels = !!t.PCTemplateUpgrade && t.PCShowConsentLabels, e.PCShowPersistentCookiesHoverButton = t.PCShowPersistentCookiesHoverButton || !1
    }, t.prototype.commonDataMapper = function(e) {
        var t = {
            iabThirdPartyConsentUrl: e.IabThirdPartyCookieUrl,
            optanonHideAcceptButton: e.OptanonHideAcceptButton,
            optanonHideCookieSettingButton: e.OptanonHideCookieSettingButton,
            optanonStyle: e.OptanonStyle,
            optanonStaticContentLocation: e.OptanonStaticContentLocation,
            bannerCustomCSS: e.BannerCustomCSS.replace(/\\n/g, ""),
            pcCustomCSS: e.PCCustomCSS.replace(/\\n/g, ""),
            textColor: e.TextColor,
            buttonColor: e.ButtonColor,
            buttonTextColor: e.ButtonTextColor,
            bannerMPButtonColor: e.BannerMPButtonColor,
            bannerMPButtonTextColor: e.BannerMPButtonTextColor,
            backgroundColor: e.BackgroundColor,
            bannerAccordionBackgroundColor: e.BannerAccordionBackgroundColor,
            BContinueColor: e.BContinueColor,
            PCContinueColor: e.PCContinueColor,
            pcTextColor: e.PcTextColor,
            pcButtonColor: e.PcButtonColor,
            pcButtonTextColor: e.PcButtonTextColor,
            pcAccordionBackgroundColor: e.PcAccordionBackgroundColor,
            pcLinksTextColor: e.PcLinksTextColor,
            bannerLinksTextColor: e.BannerLinksTextColor,
            pcEnableToggles: e.PcEnableToggles,
            pcBackgroundColor: e.PcBackgroundColor,
            pcMenuColor: e.PcMenuColor,
            pcMenuHighLightColor: e.PcMenuHighLightColor,
            legacyBannerLayout: e.LegacyBannerLayout,
            optanonLogo: e.OptanonLogo,
            oneTrustFtrLogo: e.OneTrustFooterLogo,
            optanonCookieDomain: e.OptanonCookieDomain,
            cookiePersistentLogo: e.CookiePersistentLogo,
            optanonGroupIdPerformanceCookies: e.OptanonGroupIdPerformanceCookies,
            optanonGroupIdFunctionalityCookies: e.OptanonGroupIdFunctionalityCookies,
            optanonGroupIdTargetingCookies: e.OptanonGroupIdTargetingCookies,
            optanonGroupIdSocialCookies: e.OptanonGroupIdSocialCookies,
            optanonShowSubGroupCookies: e.ShowSubGroupCookies,
            useRTL: e.UseRTL,
            showBannerCookieSettings: e.ShowBannerCookieSettings,
            showBannerAcceptButton: e.ShowBannerAcceptButton,
            showCookieList: e.ShowCookieList,
            allowHostOptOut: e.AllowHostOptOut,
            CookiesV2NewCookiePolicy: e.CookiesV2NewCookiePolicy,
            cookieListTitleColor: e.CookieListTitleColor,
            cookieListGroupNameColor: e.CookieListGroupNameColor,
            cookieListTableHeaderColor: e.CookieListTableHeaderColor,
            CookieListTableHeaderBackgroundColor: e.CookieListTableHeaderBackgroundColor,
            cookieListPrimaryColor: e.CookieListPrimaryColor,
            cookieListCustomCss: e.CookieListCustomCss,
            pcShowCookieHost: e.PCShowCookieHost,
            pcShowCookieDuration: e.PCShowCookieDuration,
            pcShowCookieType: e.PCShowCookieType,
            pcShowCookieCategory: e.PCShowCookieCategory,
            pcShowCookieDescription: e.PCShowCookieDescription,
            ConsentIntegration: e.ConsentIntegration,
            ConsentPurposesText: e.BConsentPurposesText || "Consent Purposes",
            FeaturesText: e.BFeaturesText || "Features",
            LegitimateInterestPurposesText: e.BLegitimateInterestPurposesText || "Legitimate Interest Purposes",
            ConsentText: e.BConsentText || "Consent",
            LegitInterestText: e.BLegitInterestText || "Legit. Interest",
            pcDialogClose: e.PCDialogClose || "dialog closed",
            pCFooterLogoUrl: e.PCFooterLogoUrl,
            SpecialFeaturesText: e.BSpecialFeaturesText || "Special Features",
            SpecialPurposesText: e.BSpecialPurposesText || "Special Purposes",
            pcCListName: e.PCCListName || "Name",
            pcCListHost: e.PCCListHost || "Host",
            pcCListDuration: e.PCCListDuration || "Duration",
            pcCListType: e.PCCListType || "Type",
            pcCListCategory: e.PCCListCategory || "Category",
            pcCListDescription: e.PCCListDescription || "Description",
            IabLegalTextUrl: e.IabLegalTextUrl,
            pcLegIntButtonColor: e.PcLegIntButtonColor,
            pcLegIntButtonTextColor: e.PcLegIntButtonTextColor,
            PCenterExpandToViewText: e.PCenterExpandToViewText,
            BCategoryContainerColor: e.BCategoryContainerColor,
            BCategoryStyleColor: e.BCategoryStyleColor,
            BLineBreakColor: e.BLineBreakColor,
            BSaveBtnColor: e.BSaveBtnColor,
            BCategoryStyle: e.BCategoryStyle,
            BAnimation: e.BAnimation,
            BFocusBorderColor: e.BFocusBorderColor,
            PCFocusBorderColor: e.PCFocusBorderColor,
            BnrLogo: e.BnrLogo,
            OTCloseBtnLogo: e.OTCloseBtnLogo,
            OTSpriteLogo: e.OTSpriteLogo,
            OTExternalLinkLogo: e.OTExternalLinkLogo,
            BannerExternalLinksLogo: this.customExternalLinkLogo(e),
            BannerRequireExternalLinks: e.BannerRequireExternalLinks,
            BannerRequireExternalLinksCustomLogo: e.BannerRequireExternalLinksCustomLogo
        };
        this.cookieListMapper(t, e), L = R(R({}, L), t), this.pubDomainData.CookiesV2NewCookiePolicy = e.CookiesV2NewCookiePolicy
    }, t.prototype.customExternalLinkLogo = function(e) {
        return e.BannerRequireExternalLinksCustomLogo ? e.BannerExternalLinksLogo : ""
    }, t.prototype.cookieListMapper = function(e, t) {
        e.TTLGroupByTech = t.TTLGroupByTech, e.TTLShowTechDesc = t.TTLShowTechDesc
    }, t.prototype.setPublicDomainData = function(n) {
        this.pubDomainData = {
            AboutCookiesText: n.AboutCookiesText,
            AboutLink: n.AboutLink,
            AboutText: n.AboutText,
            ActiveText: n.ActiveText,
            AddLinksToCookiepedia: n.AddLinksToCookiepedia,
            AlertAllowCookiesText: n.AlertAllowCookiesText,
            AlertCloseText: n.AlertCloseText,
            AlertLayout: n.AlertLayout,
            AlertMoreInfoText: n.AlertMoreInfoText,
            AlertMoreInfoTextDialog: n.AlertMoreInfoAriaLabel,
            AlertNoticeText: n.AlertNoticeText,
            AllowAllText: n.PreferenceCenterConfirmText,
            AlwaysActiveText: n.AlwaysActiveText,
            AlwaysInactiveText: n.AlwaysInactiveText,
            BAnimation: n.BAnimation,
            BannerCloseButtonText: n.BannerCloseButtonText,
            BannerDPDDescription: n.BannerDPDDescription || [],
            BannerDPDDescriptionFormat: n.BannerDPDDescriptionFormat || "",
            BannerDPDTitle: n.BannerDPDTitle || "",
            BannerFeatureDescription: n.BannerFeatureDescription,
            BannerFeatureTitle: n.BannerFeatureTitle,
            BannerIABPartnersLink: n.BannerIABPartnersLink,
            BannerInformationDescription: n.BannerInformationDescription,
            BannerInformationTitle: n.BannerInformationTitle,
            BannerPosition: n.BannerPosition,
            BannerPurposeDescription: n.BannerPurposeDescription,
            BannerPurposeTitle: n.BannerPurposeTitle,
            BannerRejectAllButtonText: n.BannerRejectAllButtonText,
            BannerRelativeFontSizesToggle: n.BannerRelativeFontSizesToggle,
            BannerSettingsButtonDisplayLink: n.BannerSettingsButtonDisplayLink,
            BannerShowRejectAllButton: n.BannerShowRejectAllButton,
            BannerTitle: n.BannerTitle,
            BCategoryContainerColor: n.BCategoryContainerColor,
            BCategoryStyle: n.BCategoryStyle,
            BCategoryStyleColor: n.BCategoryStyleColor,
            BCloseButtonType: n.BCloseButtonType,
            BContinueText: n.BContinueText,
            BInitialFocus: n.BInitialFocus,
            BInitialFocusLinkAndButton: n.BInitialFocusLinkAndButton,
            BLineBreakColor: n.BLineBreakColor,
            BRejectConsentType: n.BRejectConsentType,
            BSaveBtnColor: n.BSaveBtnColor,
            BSaveBtnTxt: n.BSaveBtnText,
            BShowSaveBtn: n.BShowSaveBtn,
            CategoriesText: n.CategoriesText,
            cctId: n.cctId,
            ChoicesBanner: n.ChoicesBanner,
            CloseShouldAcceptAllCookies: n.CloseShouldAcceptAllCookies,
            CloseText: n.CloseText,
            ConfirmText: n.ConfirmText,
            ConsentIntegrationData: null,
            ConsentModel: {
                Name: n.ConsentModel
            },
            CookieListDescription: n.CookieListDescription,
            CookieListTitle: n.CookieListTitle,
            CookieSettingButtonText: n.CookieSettingButtonText,
            CookiesText: n.CookiesText,
            CookiesDescText: n.CookiesDescText,
            CookiesUsedText: n.CookiesUsedText,
            CustomJs: n.CustomJs,
            Domain: S.moduleInitializer.Domain,
            FooterDescriptionText: n.FooterDescriptionText,
            ForceConsent: n.ForceConsent,
            GeneralVendors: n.GeneralVendors,
            GoogleConsent: {
                GCAdStorage: n.GCAdStorage,
                GCAnalyticsStorage: n.GCAnalyticsStorage,
                GCEnable: n.GCEnable,
                GCFunctionalityStorage: n.GCFunctionalityStorage,
                GCPersonalizationStorage: n.GCPersonalizationStorage,
                GCRedactEnable: n.GCRedactEnable,
                GCSecurityStorage: n.GCSecurityStorage,
                GCWaitTime: n.GCWaitTime,
                GCAdUserData: n.GCAdUserData,
                GCAdPersonalization: n.GCAdPersonalization
            },
            MCMData: n.MCMData,
            ACMData: n.ACMData,
            Groups: null,
            HideToolbarCookieList: n.HideToolbarCookieList,
            IabType: n.IabType,
            InactiveText: n.InactiveText,
            IsBannerLoaded: !1,
            IsConsentLoggingEnabled: n.IsConsentLoggingEnabled,
            IsIABEnabled: n.IsIabEnabled,
            IsIabThirdPartyCookieEnabled: n.IsIabThirdPartyCookieEnabled,
            IsLifespanEnabled: n.IsLifespanEnabled,
            Language: n.Language,
            LastReconsentDate: n.LastReconsentDate,
            LifespanDurationText: n.LifespanDurationText,
            LifespanText: n.LifespanText,
            LifespanTypeText: n.LifespanTypeText,
            MainInfoText: n.MainInfoText,
            MainText: n.MainText,
            ManagePreferenceText: n.PreferenceCenterManagePreferencesText,
            NextPageAcceptAllCookies: n.NextPageAcceptAllCookies,
            NextPageCloseBanner: n.NextPageCloseBanner,
            NoBanner: n.NoBanner,
            OnClickAcceptAllCookies: n.OnClickAcceptAllCookies,
            OnClickCloseBanner: n.OnClickCloseBanner,
            OverridenGoogleVendors: n.OverridenGoogleVendors,
            PCAccordionStyle: ce.Caret,
            PCCloseButtonType: n.PCCloseButtonType,
            PCContinueText: n.PCContinueText,
            PCenterAllowAllConsentText: n.PCenterAllowAllConsentText,
            PCenterApplyFiltersText: n.PCenterApplyFiltersText,
            PCenterBackText: n.PCenterBackText,
            PCenterCancelFiltersText: n.PCenterCancelFiltersText,
            PCenterClearFiltersText: n.PCenterClearFiltersText,
            PCenterCookieSearchAriaLabel: n.PCenterCookieSearchAriaLabel || "Cookie list search",
            PCenterCookieCategoriesAriaLabel: n.PCenterCookieCategoriesAriaLabel || "Cookie Categories",
            PCenterCookiesListText: n.PCenterCookiesListText,
            PCenterEnableAccordion: n.PCenterEnableAccordion,
            PCenterExpandToViewText: n.PCenterExpandToViewText,
            PCenterFilterAppliedAria: n.PCenterFilterAppliedAria || "Applied",
            PCenterFilterClearedAria: n.PCenterFilterClearedAria || "Filters Cleared",
            PCenterFilterText: n.PCenterFilterText,
            PCenterRejectAllButtonText: n.PCenterRejectAllButtonText,
            PCenterSelectAllVendorsText: n.PCenterSelectAllVendorsText,
            PCenterShowRejectAllButton: n.PCenterShowRejectAllButton,
            PCenterUserIdDescriptionText: n.PCenterUserIdDescriptionText,
            PCenterUserIdNotYetConsentedText: n.PCenterUserIdNotYetConsentedText,
            PCenterUserIdTimestampTitleText: n.PCenterUserIdTimestampTitleText,
            PCenterUserIdTitleText: n.PCenterUserIdTitleText,
            PCenterVendorListDescText: n.PCenterVendorListDescText,
            PCenterVendorSearchAriaLabel: n.PCenterVendorSearchAriaLabel || "Vendor list search",
            PCenterVendorsListText: n.PCenterVendorsListText,
            PCenterViewPrivacyPolicyText: n.PCenterViewPrivacyPolicyText,
            PCFirstPartyCookieListText: n.PCFirstPartyCookieListText,
            PCGoogleVendorsText: n.PCGoogleVendorsText,
            PCGrpDescLinkPosition: n.PCGrpDescLinkPosition,
            PCGrpDescType: n.PCGrpDescType,
            PCIABVendorsText: n.PCIABVendorsText,
            PCIABVendorLegIntClaimText: n.PCIABVendorLegIntClaimText,
            PCVListDataDeclarationText: n.PCVListDataDeclarationText,
            PCVListDataRetentionText: n.PCVListDataRetentionText,
            PCVListStdRetentionText: n.PCVListStdRetentionText,
            IABDataCategories: n.IABDataCategories,
            PCLogoAria: n.PCLogoScreenReader,
            PCOpensCookiesDetailsAlert: n.PCOpensCookiesDetailsAlert,
            PCenterVendorListScreenReader: n.PCenterVendorListScreenReader,
            PCOpensVendorDetailsAlert: n.PCOpensVendorDetailsAlert,
            PCShowPersistentCookiesHoverButton: n.PCShowPersistentCookiesHoverButton,
            PCenterDynamicRenderingEnable: n.PCenterDynamicRenderingEnable,
            PCTemplateUpgrade: n.PCTemplateUpgrade,
            PCVendorFullLegalText: n.PCVendorFullLegalText,
            PCViewCookiesText: n.PCViewCookiesText,
            PCLayout: {
                Center: n.Center,
                List: n.List,
                Panel: n.Panel,
                Popup: n.Popup,
                Tab: n.Tab
            },
            PCenterVendorListLinkText: n.PCenterVendorListLinkText,
            PCenterVendorListLinkAriaLabel: n.PCenterVendorListLinkAriaLabel,
            PCenterImprintLinkScreenReader: n.PCenterImprintLinkScreenReader,
            PCenterImprintLinkText: n.PCenterImprintLinkText,
            PCenterImprintLinkUrl: n.PCenterImprintLinkUrl,
            PreferenceCenterPosition: n.PreferenceCenterPosition,
            ScrollAcceptAllCookies: n.ScrollAcceptAllCookies,
            ScrollCloseBanner: n.ScrollCloseBanner,
            ShowAlertNotice: n.ShowAlertNotice,
            showBannerCloseButton: n.showBannerCloseButton,
            ShowPreferenceCenterCloseButton: n.ShowPreferenceCenterCloseButton,
            ThirdPartyCookieListText: n.ThirdPartyCookieListText,
            UseGoogleVendors: this.canUseGoogleVendors(n.PCTemplateUpgrade),
            VendorConsentModel: n.VendorConsentModel,
            VendorLevelOptOut: n.IsIabEnabled,
            VendorListText: n.VendorListText,
            CookiesV2NewCookiePolicy: !1
        }, n.PCTemplateUpgrade && (n.Center || n.Panel) && n.PCAccordionStyle !== ce.NoAccordion && (this.pubDomainData.PCAccordionStyle = n.PCAccordionStyle), this.pubDomainData.PCenterEnableAccordion = n.PCAccordionStyle !== ce.NoAccordion;
        var r = [];
        n.Groups.forEach(function(e) {
            var t, o;
            !n.IsIabEnabled && e.IsIabPurpose || (e.Cookies = JSON.parse(JSON.stringify(e.FirstPartyCookies)), o = null == (o = e.Hosts) ? void 0 : o.reduce(function(e, t) {
                return e.concat(JSON.parse(JSON.stringify(t.Cookies)))
            }, []), (t = e.Cookies).push.apply(t, o), r.push(e))
        }), this.pubDomainData.Groups = r
    }, t.prototype.setBannerScriptElement = function(e) {
        this.bannerScriptElement = e, this.setDomainElementAttributes()
    }, t.prototype.setGCMcallback = function() {
        window.otEventListeners && window.otEventListeners.length && window.otEventListeners.forEach(function(e) {
            e && "consent.changed" === e.event && (b.gcmUpdateCallback = e.listener)
        })
    }, t.prototype.setDomainElementAttributes = function() {
        var e;
        this.bannerScriptElement && ((e = "true" === I.getStubAttr(je) || S.moduleInitializer.LanguageDetectionEnabled && S.moduleInitializer.LanguageDetectionByHtml) && this.setUseDocumentLanguage(e), this.bannerScriptElement.hasAttribute("data-ignore-ga") && (this.ignoreGoogleAnlyticsCall = "true" === this.bannerScriptElement.getAttribute("data-ignore-ga")), this.bannerScriptElement.hasAttribute("data-ignore-html")) && (this.ignoreInjectingHtmlCss = "true" === this.bannerScriptElement.getAttribute("data-ignore-html"))
    }, t.prototype.setUseDocumentLanguage = function(e) {
        this.useDocumentLanguage = e
    }, t.prototype.setPcName = function() {
        var e = L.PCLayout;
        e.Center ? this.pcName = ot : e.Panel ? this.pcName = rt : e.Popup ? this.pcName = it : e.List ? this.pcName = nt : e.Tab && (this.pcName = st)
    }, t.prototype.setBannerName = function() {
        L.Flat ? this.bannerName = Je : L.FloatingRoundedCorner ? this.bannerName = Xe : L.FloatingFlat ? this.bannerName = Qe : L.FloatingRounded ? this.bannerName = $e : L.FloatingRoundedIcon ? this.bannerName = Ze : L.CenterRounded ? this.bannerName = Ye : L.ChoicesBanner ? this.bannerName = et : L.NoBanner && (this.bannerName = tt)
    }, t.prototype.populateGPCSignal = function() {
        var e = T.readCookieParam(y.OPTANON_CONSENT, h.GPC_ENABLED),
            t = this.gpcForAGrpEnabled && this.gpcEnabled ? "1" : "0";
        this.gpcValueChanged = e ? e != t : this.gpcForAGrpEnabled, T.writeCookieParam(y.OPTANON_CONSENT, h.GPC_ENABLED, t)
    }, t.prototype.populateGPCBrowserSignal = function() {
        var e = T.readCookieParam(y.OPTANON_CONSENT, h.GPC_Browser_Flag),
            t = this.gpcEnabled ? "1" : "0";
        this.gpcBrowserValueChanged = e !== t, T.writeCookieParam(y.OPTANON_CONSENT, h.GPC_Browser_Flag, t)
    }, t.prototype.initGCM = function() {
        var o = [],
            e = (Object.keys(this.rule.States).forEach(function(t) {
                b.rule.States[t].forEach(function(e) {
                    o.push((t + "-" + e).toUpperCase())
                })
            }), b.rule.Countries.map(function(e) {
                return e.toUpperCase()
            }));
        b.gcmCountries = e.concat(o)
    }, t.prototype.getRegionDetailsOnRuleSet = function(e, t) {
        var o, n;
        t && 1 < t.length && (o = ["co", "va", "ut"], 1 <= (n = t.filter(function(e) {
            return !o.includes(e)
        })).length) && n.length < t.length && (e.KnownChildSensitiveDataConsents = 2)
    };
    var eo = t;

    function t() {
        var t = this;
        this.DNTEnabled = "yes" === navigator.doNotTrack || "1" === navigator.doNotTrack, this.gpcEnabled = !1, this.gpcForAGrpEnabled = !1, this.pagePushedDown = !1, this.iabGroups = {
            purposes: {},
            legIntPurposes: {},
            specialPurposes: {},
            features: {},
            specialFeatures: {}
        }, this.iabType = null, this.grpContainLegalOptOut = !1, this.purposeOneTreatment = !1, this.ignoreInjectingHtmlCss = !1, this.ignoreGoogleAnlyticsCall = !1, this.mobileOnlineURL = [], this.iabGrpIdMap = {}, this.iabGrps = [], this.consentableGrps = [], this.consentableImpliedConsentGroup = [], this.consentableIabGrps = [], this.domainGrps = {}, this.thirdPartyiFrameLoaded = !1, this.thirdPartyiFrameResolve = null, this.thirdPartyiFramePromise = new Promise(function(e) {
            t.thirdPartyiFrameResolve = e
        }), this.isOptInMode = !1, this.isSoftOptInMode = !1, this.gpcValueChanged = !1, this.gpcBrowserValueChanged = !1, this.conditionalLogicEnabled = !1, this.allConditionsFailed = !1, this.canUseConditionalLogic = !1, this.gtmUpdatedinStub = !1, this.gcmDevIdSet = !1, this.makeGPCOrDNTConsentCall = !0, this.tcf2ActiveVendors = {
            all: 0,
            pur: new Map,
            ft: new Map,
            spl_pur: new Map,
            spl_ft: new Map,
            stack: new Map
        }, this.tcfParentMap = {
            pur: new Map,
            ft: new Map,
            spl_pur: new Map,
            spl_ft: new Map
        }
    }
    var b, L = {};

    function to() {
        this.otSDKVersion = "202511.1.0", this.isAMP = !1, this.ampData = {}, this.otCookieData = window.OneTrust && window.OneTrust.otCookieData || [], this.syncRequired = !1, this.isIabSynced = !1, this.isGacSynced = !1, this.grpsSynced = [], this.syncedValidGrp = !1, this.groupsConsent = [], this.initialGroupsConsent = [], this.hostsConsent = [], this.initialHostConsent = [], this.genVendorsConsent = {}, this.vsConsent = new Map, this.initialGenVendorsConsent = {}, this.vendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.initialVendors = {
            list: [],
            searchParam: "",
            vendorTemplate: null,
            selectedVendors: [],
            selectedPurpose: [],
            selectedLegInt: [],
            selectedLegIntVendors: [],
            selectedSpecialFeatures: []
        }, this.oneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.initialOneTrustIABConsent = {
            purpose: [],
            legimateInterest: [],
            features: [],
            specialFeatures: [],
            specialPurposes: [],
            vendors: [],
            legIntVendors: [],
            vendorList: null,
            IABCookieValue: ""
        }, this.addtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.initialAddtlVendors = {
            vendorConsent: [],
            vendorSelected: {}
        }, this.addtlConsentVersion = "1~", this.deletedGoogleVendors = {}, this.initialAddtlVendorsList = {}, this.isAddtlConsent = !1, this.currentGlobalFilteredList = [], this.filterByIABCategories = [], this.filterByCategories = [], this.hosts = {
            hostTemplate: null,
            hostCookieTemplate: null
        }, this.generalVendors = {
            gvTemplate: null,
            gvCookieTemplate: null
        }, this.oneTrustAlwaysActiveHosts = [], this.alwaysActiveGenVendors = [], this.softOptInGenVendors = [], this.optInGenVendors = [], this.optanonHostList = [], this.srcExecGrps = [], this.htmlExecGrps = [], this.srcExecGrpsTemp = [], this.htmlExecGrpsTemp = [], this.isPCVisible = !1, this.dataGroupState = [], this.userLocation = {
            country: "",
            state: "",
            stateName: ""
        }, this.vendorsSetting = {}, this.dsParams = {}, this.isV2Stub = !1, this.fireOnetrustGrp = !1, this.showVendorService = !1, this.showGeneralVendors = !1, this.genVenOptOutEnabled = !1, this.gpcConsentTxn = !1, this.vsIsActiveAndOptOut = !1, this.bAsset = {}, this.pcAsset = {}, this.csBtnAsset = {}, this.cStyles = {}, this.vendorDomInit = !1, this.genVendorDomInit = !1, this.syncNtfyContent = {}, this.ntfyRequired = !1, this.skipAddingHTML = !1, this.bnrAnimationInProg = !1, this.isPreview = !1, this.geoFromUrl = "", this.hideBanner = !1, this.setAttributePolyfillIsActive = !1, this.storageBaseURL = "", this.isKeyboardUser = !1, this.isBotHeader = !1, this.customerStyles = new Map, this.showTrackingTech = !1, this.currentTrackingTech = {}
    }
    to.prototype.getVendorsInDomain = function() {
        var e, t;
        return _._vendorsInDomain || (e = new Map, t = null != (t = L.Groups) ? t : [], _.setVendorServicesMap(t, e), _._vendorsInDomain = e), _._vendorsInDomain
    }, to.prototype.setVendorServicesMap = function(e, t) {
        for (var o, n = 0, r = e; n < r.length; n++) {
            var i = r[n];
            i.SubGroups && 0 < i.SubGroups.length && _.setVendorServicesMap(i.SubGroups, t);
            for (var s = 0, a = null != (o = i.VendorServices) ? o : []; s < a.length; s++) {
                var l = a[s],
                    c = Object.assign({}, i);
                delete c.VendorServices, l.groupRef = c, t.set(l.CustomVendorServiceId, l)
            }
        }
    }, to.prototype.clearVendorsInDomain = function() {
        _._vendorsInDomain = null
    }, to.prototype.checkVendorConsent = function(e) {
        return _.vendorsSetting[e] && _.vendorsSetting[e].consent
    };
    var _ = new to,
        l = _;

    function n() {
        this.IABTCF_DEFAULT_LANGUAGE = "EN", this.IABTCF_DEFAULT_SERBIAN = "SR-CYRL", this.IABTCF_DEFAULT_PORTUGUESE = "PT-PT", this.IABTCF_SUPPORTED_LANGUAGES = new Set(["AR", "BG", "BS", "CA", "CS", "CY", "DA", "DE", "EL", "EN", "ES", "ET", "EU", "FI", "FR", "GL", "HE", "HR", "HU", "HI", "ID", "IT", "JA", "KA", "KO", "LT", "LV", "MK", "MS", "MT", "NL", "NO", "PL", "PT-BR", "PT-PT", "RO", "RU", "SK", "SL", "SQ", "SR-LATN", "SR-CYRL", "SV", "SW", "TH", "TL", "TR", "UK", "VI", "ZH", "ZH-HANT"])
    }
    n.prototype.initializeBannerVariables = function(e) {
        var t = e.DomainData;
        b.iabType = t.IabType, A = t.PCTemplateUpgrade ? Rt : Ft, k = "IAB2" === b.iabType ? Mt : Ut, b.init(e), _.showGeneralVendors = L.GeneralVendorsEnabled && L.PCTemplateUpgrade, _.showVendorService = S.fp.CookieV2VendorServiceScript && L.VendorServiceConfig.PCVSEnable && !b.isIab2orv2Template && L.PCTemplateUpgrade, _.vsIsActiveAndOptOut = _.showVendorService && L.VendorServiceConfig.PCVSOptOut, _.showTrackingTech = S.fp.CookieV2TrackingTechPrefCenter && L.AdditionalTechnologiesConfig.PCShowTrackingTech, _.genVenOptOutEnabled = _.showGeneralVendors && L.GenVenOptOut, I.addLogoUrls(), this.ensureAmazonConsent(t), this.setGeolocationInCookies(), this.setOrUpdate3rdPartyIABConsentFlag()
    }, n.prototype.ensureAmazonConsent = function(e) {
        var t, o, n, r, i;
        try {
            window && "function" == typeof window.amznConsent || null != (t = L) && t.ACMData && L.ACMData.Enabled && (o = e.AmazonConsentSrcUrl) && !document.querySelector('script[src="' + o + '"]') && ((n = document.createElement("script")).src = o, n.async = !0, n.type = "text/javascript", (r = window.otStubData || {}).nonce && n.setAttribute("nonce", r.nonce), (i = r.crossOrigin || _.crossOrigin) && n.setAttribute("crossorigin", i), document.head.appendChild(n))
        } catch (e) {
            try {
                console.info("OT - Failed to ensure Amazon Consent script", e)
            } catch (e) {}
        }
    }, n.prototype.initializeVendorInOverriddenVendors = function(e, t) {
        L.OverriddenVendors[e] = {
            disabledCP: [],
            disabledLIP: [],
            active: t,
            legInt: !1,
            consent: !1
        }
    }, n.prototype.applyGlobalRestrictionsonNewVendor = function(e, t, o, n) {
        var r = L.GlobalRestrictions,
            i = L.OverriddenVendors;
        switch (L.Publisher.restrictions[o] || (L.Publisher.restrictions[o] = {}), i[t] || this.initializeVendorInOverriddenVendors(t, !0), i[t].disabledCP || (i[t].disabledCP = []), i[t].disabledLIP || (i[t].disabledLIP = []), r[o]) {
            case pe.Disabled:
                (n ? i[t].disabledCP : i[t].disabledLIP).push(o), L.Publisher.restrictions[o][t] = pe.Disabled;
                break;
            case pe.Consent:
                n ? (i[t].consent = !0, L.Publisher.restrictions[o][t] = pe.Consent) : (i[t].disabledLIP.push(o), this.checkFlexiblePurpose(e, t, o, !1));
                break;
            case pe.LegInt:
                n ? (i[t].disabledCP.push(o), this.checkFlexiblePurpose(e, t, o, !0)) : (i[t].legInt = !0, L.Publisher.restrictions[o][t] = pe.LegInt);
                break;
            case void 0:
                n ? i[t].consent = !0 : i[t].legInt = !0
        }
    }, n.prototype.checkFlexiblePurpose = function(e, t, o, n) {
        e.flexiblePurposes.includes(o) ? (n ? L.OverriddenVendors[t].legInt = !0 : L.OverriddenVendors[t].consent = !0, L.Publisher.restrictions[o][t] = n ? pe.LegInt : pe.Consent) : L.Publisher.restrictions[o][t] = pe.Disabled
    }, n.prototype.getActivePurposesForVendor = function(e, t) {
        var o = L.OverriddenVendors[t] && L.OverriddenVendors[t].disabledCP,
            n = L.OverriddenVendors[t] && L.OverriddenVendors[t].disabledLIP,
            o = o ? this.removeElementsFromArray(e.purposes, L.OverriddenVendors[t].disabledCP) || [] : e.purposes || [],
            n = n ? this.removeElementsFromArray(e.legIntPurposes, L.OverriddenVendors[t].disabledLIP) || [] : e.legIntPurposes || [],
            t = U(o, n, e.flexiblePurposes || []);
        return new Set(t)
    }, n.prototype.canInferGCMSettingsFromTCString = function() {
        return b.isTcfV2Template && L.GoogleConsent.GCEnable
    }, n.prototype.shouldOverrideTCData = function() {
        var e = this.canInferGCMSettingsFromTCString();
        return L.UseGoogleVendors || e
    }, n.prototype.setActiveVendorCount = function(o, e) {
        var n, r, i, s = this,
            a = [];
        "IAB2V2" === b.getRegionRuleType() && (n = new Set, r = b.tcf2ActiveVendors, (i = this.getActivePurposesForVendor(o, e)).forEach(function(e) {
            var t = r.pur.get(e) || 0;
            r.pur.set(e, t + 1), b.tcfParentMap.pur.get(e) && n.add(b.tcfParentMap.pur.get(e))
        }), o.specialPurposes && o.specialPurposes.forEach(function(e) {
            var t = r.spl_pur.get(e) || 0;
            r.spl_pur.set(e, t + 1), b.tcfParentMap.spl_pur.get(e) && (n.add(b.tcfParentMap.spl_pur.get(e)), t = b.tcfParentMap.spl_pur.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), o.features && o.features.forEach(function(e) {
            var t = r.ft.get(e) || 0;
            r.ft.set(e, t + 1), b.tcfParentMap.ft.get(e) && (n.add(b.tcfParentMap.ft.get(e)), t = b.tcfParentMap.ft.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), o.specialFeatures && o.specialFeatures.forEach(function(e) {
            var t = r.spl_ft.get(e) || 0;
            r.spl_ft.set(e, t + 1), b.tcfParentMap.spl_ft.get(e) && (n.add(b.tcfParentMap.spl_ft.get(e)), t = b.tcfParentMap.spl_ft.get(e), s.updateParentCountByType(t, r, o, a, i))
        }), n.forEach(function(e) {
            var t = r.stack.get(e) || 0;
            r.stack.set(e, t + 1)
        }))
    }, n.prototype.updateParentCountByType = function(e, t, o, n, r) {
        var i, s, a, l;
        e && !n.includes(e) && (i = !1, a = e.split("_"), s = ["IAB2V2", "IFE2V2", "ISP2V2", "ISF2V2"].includes(a[0]), 1 < a.length) && s && (s = this.readProp(wt, a[0]), a = parseInt(a[1]), l = void 0, (s === wt.IAB2V2 && !r.has(a) || s !== wt.IAB2V2 && (l = o[this.readProp(Nt, s)]) && !l.includes(a)) && (i = !0), s) && i && ((r = t[s].get(a)) ? t[s].set(a, r + 1) : (t[s].set(a, 1), n.push(e)))
    }, n.prototype.readProp = function(e, t) {
        var o, n = "";
        for (o in e)
            if (t === o) {
                n = e[o];
                break
            }
        return n
    }, n.prototype.isVendorInvalid = function(e, t) {
        var o = !1,
            n = !e.purposes.length && !e.flexiblePurposes.length,
            r = (L.OverriddenVendors[t] && !L.OverriddenVendors[t].consent && (n = !0), !0);
        return b.legIntSettings.PAllowLI && e.legIntPurposes.length && (!L.OverriddenVendors[t] || L.OverriddenVendors[t].legInt) && (r = !1), o = !n || !r || e.specialPurposes.length || e.features.length || e.specialFeatures.length ? o : !0
    }, n.prototype.removeInActiveVendorsForTcf = function(r) {
        var i = this,
            s = _.iabData.vendorListVersion,
            e = L.Publisher,
            a = L.GlobalRestrictionEnabled;
        0 !== Object.keys(e).length && e && Object.keys(e.restrictions).length, Object.keys(r.vendors).forEach(function(t) {
            var o = r.vendors[t],
                e = !1,
                n = i.getVendorGVLVersion(o),
                n = (s < n && (L.NewVendorsInactiveEnabled ? (i.initializeVendorInOverriddenVendors(t, !1), e = !0) : a && (o.purposes.forEach(function(e) {
                    i.applyGlobalRestrictionsonNewVendor(o, t, e, !0)
                }), o.legIntPurposes.forEach(function(e) {
                    i.applyGlobalRestrictionsonNewVendor(o, t, e, !1)
                }))), L.OverriddenVendors[t] && !L.OverriddenVendors[t].active && (e = !0), -1 < L.Vendors.indexOf(Number(t)) && (e = !0), i.isVendorInvalid(o, t));
            (e = e || n) && delete r.vendors[t], e || i.setActiveVendorCount(o, t)
        })
    }, n.prototype.getVendorGVLVersion = function(e) {
        return b.isTcfV2Template ? e.iab2V2GVLVersion : e.iab2GVLVersion
    }, n.prototype.removeElementsFromArray = function(e, t) {
        return e.filter(function(e) {
            return !t.includes(e)
        })
    }, n.prototype.setPublisherRestrictions = function() {
        var i, t, s, a, e = L.Publisher;
        e && e.restrictions && (i = this.iabStringSDK(), t = e.restrictions, s = _.iabData, a = _.oneTrustIABConsent.vendorList.vendors, Object.keys(t).forEach(function(o) {
            var n, r = t[o],
                e = b.iabGroups.purposes[o];
            e && (n = {
                description: e.description,
                purposeId: e.id,
                purposeName: e.name
            }), Object.keys(r).forEach(function(e) {
                var t;
                _.vendorsSetting[e] && (t = _.vendorsSetting[e].arrIndex, 1 === r[e] && -1 === a[e].purposes.indexOf(Number(o)) ? s.vendors[t].purposes.push(n) : 2 === r[e] && -1 === a[e].legIntPurposes.indexOf(Number(o)) && s.vendors[t].legIntPurposes.push(n), t = i.purposeRestriction(Number(o), r[e]), _.tcModel.publisherRestrictions.add(Number(e), t))
            })
        }))
    }, n.prototype.populateVendorListTCF = function() {
        var p;
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a, l, c, d, u;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = this.iabStringSDK(), o = _.iabData, n = I.updateCorrectIABUrl(o.globalVendorListUrl), r = !this.isIABCrossConsentEnabled(), s = this.getConsentLanguage(), I.checkMobileOfflineRequest(I.getBannerVersionUrl())) ? [3, 1] : (b.mobileOnlineURL.push(n), i = t.gvl(s, n, _.gvlObj), [3, 3]);
                    case 1:
                        return l = (a = t).gvl, c = [s, null], [4, I.otFetchOfflineFile(P.getRelativeURL(n, !0))];
                    case 2:
                        i = l.apply(a, c.concat([e.sent()])), e.label = 3;
                    case 3:
                        return this.removeInActiveVendorsForTcf(i), b.tcf2ActiveVendors.all = Object.keys(i.vendors).length, _.oneTrustIABConsent.vendorList = i, this.assignIABDataWithGlobalVendorList(i), d = _, [4, t.tcModel(i)];
                    case 4:
                        d.tcModel = e.sent(), r && this.setPublisherRestrictions(), _.tcModel.cmpId = parseInt(o.cmpId), b.isTcfV2Template && (_.tcModel.useNonStandardTexts = L.UseNonStandardStacks), _.tcModel.cmpVersion = parseInt(o.cmpVersion), 0 < (u = Object.keys(i.vendors).map(Number)).length && null != (p = null == (p = _.tcModel) ? void 0 : p.vendorsDisclosed) && p.set(u);
                        try {
                            _.tcModel.consentLanguage = _.consentLanguage
                        } catch (e) {
                            _.tcModel.consentLanguage = "EN"
                        }
                        return _.tcModel.consentScreen = parseInt(o.consentScreen), _.tcModel.isServiceSpecific = r, _.tcModel.purposeOneTreatment = b.purposeOneTreatment, L.PublisherCC ? _.tcModel.publisherCountryCode = L.PublisherCC : _.userLocation.country && (_.tcModel.publisherCountryCode = _.userLocation.country), _.cmpApi = t.cmpApi(_.tcModel.cmpId, _.tcModel.cmpVersion, r, this.shouldOverrideTCData() ? {
                            getTCData: this.overrideTCData,
                            getInAppTCData: this.overrideTCData
                        } : void 0), null !== this.alertBoxCloseDate() && !this.needReconsent() || this.resetTCModel(), [2]
                }
            })
        })
    }, n.prototype.resetTCModel = function() {
        var e, t, o = this.iabStringSDK(),
            n = _.tcModel.clone();
        n.unsetAll(), b.legIntSettings.PAllowLI && (e = b.consentableIabGrps.filter(function(e) {
            return e.HasLegIntOptOut && e.Type === k.GroupTypes.Pur
        }).map(function(e) {
            return parseInt(b.iabGrpIdMap[e.CustomGroupId])
        }), t = Object.keys(_.vendorsSetting).filter(function(e) {
            return _.vendorsSetting[e].legInt
        }).map(function(e) {
            return parseInt(e)
        }), n.purposeLegitimateInterests.set(e), n.vendorLegitimateInterests.set(t), n.isServiceSpecific) && n.publisherLegitimateInterests.set(e);
        try {
            var r, i = _.oneTrustIABConsent && _.oneTrustIABConsent.vendorList,
                s = i && i.vendors;
            s && n && n.vendorsDisclosed && "function" == typeof n.vendorsDisclosed.set && (r = Object.keys(s).map(Number)).length && n.vendorsDisclosed.set(r)
        } catch (e) {
            console.info(e)
        }
        _.cmpApi.update(o.tcString().encode(n), !0)
    }, n.prototype.overrideTCData = function(e, t, o) {
        var n = O.canInferGCMSettingsFromTCString();
        t && t.tcString && (L.UseGoogleVendors && (t.addtlConsent = "" + _.addtlConsentVersion + (_.isAddtlConsent ? _.addtlVendors.vendorConsent.join(".") : "")), n) && (t.enableAdvertiserConsentMode = !0), "function" == typeof e ? e(t, o) : console.error("__tcfapi received invalid parameters.")
    }, n.prototype.setIabData = function() {
        _.iabData = b.isTcfV2Template ? S.moduleInitializer.Iab2V2Data : S.moduleInitializer.IabV2Data, _.iabData.consentLanguage = _.consentLanguage
    }, n.prototype.assignIABDataWithGlobalVendorList = function(o) {
        var r = this,
            i = L.OverriddenVendors,
            s = (_.iabData.vendorListVersion = o.vendorListVersion, _.iabData.vendors = [], L.IABDataCategories);
        Object.keys(o.vendors).forEach(function(n) {
            _.vendorsSetting[n] = {
                consent: !0,
                legInt: !0,
                arrIndex: 0,
                specialPurposesOnly: !1
            };
            var e = {},
                t = o.vendors[n];
            e.vendorId = n, e.vendorName = t.name, e.policyUrl = t.policyUrl, r.setIAB2VendorData(t, e), e.cookieMaxAge = t.cookieMaxAgeSeconds ? P.calculateCookieLifespan(t.cookieMaxAgeSeconds) : null, e.usesNonCookieAccess = t.usesNonCookieAccess, e.deviceStorageDisclosureUrl = t.deviceStorageDisclosureUrl || null, b.legIntSettings.PAllowLI && !r.shouldHaveVendorLIUnset(i, t, n) || (_.vendorsSetting[n].legInt = !1), b.legIntSettings.PAllowLI && r.vendorHasNoLIAndPurConsent(i, t, n) && t.specialPurposes.length && (_.vendorsSetting[n].specialPurposesOnly = !0, _.anyVendorHasOnlySplPur = !0), r.canShowConsentToggle(i, t, n), e.features = t.features.reduce(function(e, t) {
                t = b.iabGroups.features[t];
                return t && e.push({
                    description: t.description,
                    featureId: t.id,
                    featureName: t.name
                }), e
            }, []), e.specialFeatures = o.vendors[n].specialFeatures.reduce(function(e, t) {
                t = b.iabGroups.specialFeatures[t];
                return t && e.push({
                    description: t.description,
                    featureId: t.id,
                    featureName: t.name
                }), e
            }, []), r.mapDataDeclarationForVendor(o.vendors[n], e, s), r.mapDataRetentionForVendor(o.vendors[n], e), e.purposes = o.vendors[n].purposes.reduce(function(e, t) {
                var o = b.iabGroups.purposes[t];
                return !o || i[n] && i[n].disabledCP && -1 !== i[n].disabledCP.indexOf(t) || e.push({
                    description: o.description,
                    purposeId: o.id,
                    purposeName: o.name
                }), e
            }, []), e.legIntPurposes = o.vendors[n].legIntPurposes.reduce(function(e, t) {
                var o = b.iabGroups.purposes[t];
                return !o || i[n] && i[n].disabledLIP && -1 !== i[n].disabledLIP.indexOf(t) || e.push({
                    description: o.description,
                    purposeId: o.id,
                    purposeName: o.name
                }), e
            }, []), e.specialPurposes = t.specialPurposes.reduce(function(e, t) {
                t = b.iabGroups.specialPurposes[t];
                return t && e.push({
                    description: t.description,
                    purposeId: t.id,
                    purposeName: t.name
                }), e
            }, []), _.iabData.vendors.push(e), _.vendorsSetting[n].arrIndex = _.iabData.vendors.length - 1
        })
    }, n.prototype.canShowConsentToggle = function(e, t, o) {
        var n = !!b.legIntSettings.PAllowLI && t.flexiblePurposes.every(function(e) {
                return t.legIntPurposes.includes(e)
            }),
            r = !!b.legIntSettings.PAllowLI && (e[o] ? !e[o].consent : n);
        (!e[o] || e[o].consent) && (e[o] || t.purposes.length || t.flexiblePurposes.length && (t.flexiblePurposes.length, !n)) && (t.purposes.length || t.flexiblePurposes.length && (t.flexiblePurposes.length, !r)) || (_.vendorsSetting[o].consent = !1)
    }, n.prototype.vendorHasNoLIAndPurConsent = function(e, t, o) {
        return e[o] && !e[o].legInt && !e[o].consent || !e[o] && !t.legIntPurposes.length && !t.purposes.length
    }, n.prototype.shouldHaveVendorLIUnset = function(e, t, o) {
        var n = !1,
            r = !1,
            i = t.specialPurposes.length;
        return (e[o] && !e[o].legInt || !e[o] && !t.legIntPurposes.length) && (n = !0), (e[o] && !e[o].consent || !e[o] && !t.purposes.length) && (r = !0), !(!n || r === Boolean(i) && (r || i))
    }, n.prototype.mapDataDeclarationForVendor = function(e, t, n) {
        var o;
        b.isTcfV2Template && null != (o = e.dataDeclaration) && o.length && (t.dataDeclaration = e.dataDeclaration.reduce(function(e, t) {
            var o = n.find(function(e) {
                return e.Id === t
            });
            return o && e.push({
                Description: o.Description,
                Id: o.Id,
                Name: o.Name
            }), e
        }, []))
    }, n.prototype.mapDataRetentionForVendor = function(o, n) {
        var e;
        n.dataRetention = {}, b.isTcfV2Template && o.dataRetention && (null !== (null == (e = o.dataRetention) ? void 0 : e.stdRetention) && void 0 !== (null == (e = o.dataRetention) ? void 0 : e.stdRetention) && (n.dataRetention = {
            stdRetention: o.dataRetention.stdRetention
        }), Object.keys(null == (e = o.dataRetention) ? void 0 : e.purposes).length && (n.dataRetention.purposes = JSON.parse(JSON.stringify(o.dataRetention.purposes)), Object.keys(o.dataRetention.purposes).forEach(function(e) {
            var t = b.iabGroups.purposes[e];
            t && (n.dataRetention.purposes[e] = {
                name: t.name,
                id: t.id,
                retention: o.dataRetention.purposes[e]
            })
        })), Object.keys(null == (e = o.dataRetention) ? void 0 : e.specialPurposes).length) && (n.dataRetention.specialPurposes = JSON.parse(JSON.stringify(o.dataRetention.specialPurposes)), Object.keys(o.dataRetention.specialPurposes).forEach(function(e) {
            var t = b.iabGroups.specialPurposes[e];
            t && (n.dataRetention.specialPurposes[e] = {
                name: t.name,
                id: t.id,
                retention: o.dataRetention.specialPurposes[e]
            })
        }))
    }, n.prototype.setIAB2VendorData = function(e, t) {
        var o, n, r;
        b.isTcfV2Template && (n = _.lang, r = (r = e.urls.find(function(e) {
            return e.langId === n
        })) || e.urls[0], t.vendorPrivacyUrl = (null == (o = r) ? void 0 : o.privacy) || "", t.legIntClaim = (null == (o = r) ? void 0 : o.legIntClaim) || "", null != (r = e.dataDeclaration) && r.length && (t.dataDeclaration = e.dataDeclaration), e.DataRetention) && (t.DataRetention = e.DataRetention)
    }, n.prototype.populateIABCookies = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!this.isIABCrossConsentEnabled()) return [3, 5];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, this.setIAB3rdPartyCookie(y.EU_CONSENT, "", 0, !0)];
                    case 2:
                        return e.sent(), [3, 4];
                    case 3:
                        return e.sent(), this.setIABCookieData(), this.updateCrossConsentCookie(!1), [3, 4];
                    case 4:
                        return [3, 6];
                    case 5:
                        O.needReconsent() || this.setIABCookieData(), e.label = 6;
                    case 6:
                        return [2]
                }
            })
        })
    }, n.prototype.setIAB3rdPartyCookie = function(e, t, o, n) {
        var r = L.iabThirdPartyConsentUrl;
        try {
            if (r && document.body) return this.updateThirdPartyConsent(r, e, t, o, n);
            throw new ReferenceError
        } catch (e) {
            throw e
        }
    }, n.prototype.setIABCookieData = function() {
        _.oneTrustIABConsent.IABCookieValue = T.getMergedCookieByName(y.EU_PUB_CONSENT)
    }, n.prototype.updateThirdPartyConsent = function(n, r, i, s, a) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                return t = window.location.protocol + "//" + n + "/?name=" + r + "&value=" + i + "&expire=" + s + "&isFirstRequest=" + a, document.getElementById("onetrustIabCookie") ? (document.getElementById("onetrustIabCookie").contentWindow.location.replace(t), [2]) : (d(o = document.createElement("iframe"), "display: none;", !0), o.id = "onetrustIabCookie", o.setAttribute("title", "OneTrust IAB Cookie"), o.src = t, document.body.appendChild(o), [2, new Promise(function(e) {
                    o.onload = function() {
                        b.thirdPartyiFrameResolve(), b.thirdPartyiFrameLoaded = !0, e()
                    }, o.onerror = function() {
                        throw b.thirdPartyiFrameResolve(), b.thirdPartyiFrameLoaded = !0, e(), new URIError
                    }
                })])
            })
        })
    }, n.prototype.setIABVendor = function(n, r, i) {
        var t, s = this;
        void 0 === n && (n = !0), void 0 === r && (r = !1), void 0 === i && (i = !1), _.iabData.vendors.forEach(function(e) {
            var t, o, e = e.vendorId;
            b.legIntSettings.PAllowLI ? (o = void 0, r ? o = n : (t = _.vendorsSetting[e], i && t.legInt && !t.specialPurposesOnly ? s.updateVendorPurposeOrLI(!0, e, !1) : (o = !!_.vendorsSetting[e].consent && n, s.updateVendorPurposeOrLI(!0, e, _.vendorsSetting[e].legInt))), s.updateVendorPurposeOrLI(!1, e, o)) : (_.oneTrustIABConsent.legIntVendors = [], s.updateVendorPurposeOrLI(!1, e, n))
        }), L.UseGoogleVendors && (t = _.addtlVendors, Object.keys(_.addtlVendorsList).forEach(function(e) {
            n ? (t.vendorSelected["" + e.toString()] = !0, t.vendorConsent.push("" + e.toString())) : r && (t.vendorSelected["" + e.toString()] = !1, e = t.vendorConsent.indexOf("" + e.toString()), t.vendorConsent.splice(e, 1))
        }))
    }, n.prototype.updateVendorPurposeOrLI = function(e, t, o) {
        void 0 === o && (o = !1), (e = void 0 === e ? !1 : e) ? -1 < (e = _.oneTrustIABConsent.legIntVendors.findIndex(function(e) {
            return e.includes(t.toString() + ":true") || e.includes(t.toString() + ":false")
        })) ? _.oneTrustIABConsent.legIntVendors[e] = t.toString() + ":" + o : _.oneTrustIABConsent.legIntVendors.push(t.toString() + ":" + o) : -1 < (e = _.oneTrustIABConsent.vendors.findIndex(function(e) {
            return e.includes(t.toString() + ":true") || e.includes(t.toString() + ":false")
        })) ? _.oneTrustIABConsent.vendors[e] = t.toString() + ":" + o : _.oneTrustIABConsent.vendors.push(t.toString() + ":" + o)
    }, n.prototype.setOrUpdate3rdPartyIABConsentFlag = function() {
        var e = this.getIABCrossConsentflagData();
        L.IsIabEnabled ? e && !this.needReconsent() || this.updateCrossConsentCookie(L.IsIabThirdPartyCookieEnabled) : e && !this.reconsentRequired() && "true" !== e || this.updateCrossConsentCookie(!1)
    }, n.prototype.isIABCrossConsentEnabled = function() {
        return "true" === this.getIABCrossConsentflagData()
    }, n.prototype.getIABCrossConsentflagData = function() {
        return T.readCookieParam(y.OPTANON_CONSENT, h.IS_IAB_GLOBAL)
    }, n.prototype.setGeolocationInCookies = function() {
        var e, t = T.readCookieParam(y.OPTANON_CONSENT, h.GEO_LOCATION);
        _.userLocation && !t && this.isAlertBoxClosedAndValid() ? (e = _.userLocation.country + ";" + _.userLocation.state, this.setUpdateGeolocationCookiesData(e)) : this.reconsentRequired() && t && this.setUpdateGeolocationCookiesData("")
    }, n.prototype.iabStringSDK = function() {
        var e = S.moduleInitializer.otIABModuleData;
        if (L.IsIabEnabled && e) return {
            gvl: e.tcfSdkRef.gvl,
            tcModel: e.tcfSdkRef.tcModel,
            tcString: e.tcfSdkRef.tcString,
            cmpApi: e.tcfSdkRef.cmpApi,
            purposeRestriction: e.tcfSdkRef.purposeRestriction
        }
    }, n.prototype.setUpdateGeolocationCookiesData = function(e) {
        T.writeCookieParam(y.OPTANON_CONSENT, h.GEO_LOCATION, e)
    }, n.prototype.calculateDaysFromDateToToday = function(e) {
        var e = new Date(e),
            t = new Date,
            t = (e.setUTCHours(0, 0, 0, 0), t.setUTCHours(0, 0, 0, 0), Math.abs(t.getTime() - e.getTime()));
        return Math.ceil(t / 864e5)
    }, n.prototype.reconsentRequired = function() {
        return (S.moduleInitializer.MobileSDK || this.awaitingReconsent()) && this.needReconsent()
    }, n.prototype.awaitingReconsent = function() {
        return "true" === T.readCookieParam(y.OPTANON_CONSENT, h.AWAITING_RE_CONSENT)
    }, n.prototype.needReconsent = function() {
        var e = this.alertBoxCloseDate(),
            t = L.LastReconsentDate;
        return !!(e && t && new Date(t) > new Date(e)) || (_.isAMP && e ? this.calculateDaysFromDateToToday(e) >= L.ReconsentFrequencyDays : void 0)
    }, n.prototype.updateCrossConsentCookie = function(e) {
        T.writeCookieParam(y.OPTANON_CONSENT, h.IS_IAB_GLOBAL, e)
    }, n.prototype.alertBoxCloseDate = function() {
        return T.getCookie(y.ALERT_BOX_CLOSED)
    }, n.prototype.isAlertBoxClosedAndValid = function() {
        return null !== this.alertBoxCloseDate() && !this.reconsentRequired()
    }, n.prototype.generateLegIntButtonElements = function(e, t, o, n) {
        return m.getInnerHtmlContent('<div class="ot-leg-btn-container" data-group-id="' + t + '" data-el-id="' + t + '-leg-out" is-vendor="' + (o = void 0 === o ? !1 : o) + '">\n                    <button class="ot-obj-leg-btn-handler ' + (e ? "ot-leg-int-enabled ot-inactive-leg-btn" : "ot-active-leg-btn") + '" aria-label="' + (n = void 0 === n ? "" : n) + ", " + (e ? b.legIntSettings.PObjectLegIntText : b.legIntSettings.PObjectionAppliedText) + '">\n                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512">\n                            <path fill="' + L.pcButtonTextColor + '" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"/>\n                        </svg>\n                        <span>' + (e ? b.legIntSettings.PObjectLegIntText : b.legIntSettings.PObjectionAppliedText) + '\n                        </span>\n                    </button>\n                    <button\n                        class="ot-remove-objection-handler"\n                            data-style="color:' + L.pcButtonColor + "; " + (e ? "display:none;" : "") + '"\n                            aria-label="' + n + ", " + b.legIntSettings.PRemoveObjectionText + '"\n                    >\n                        ' + b.legIntSettings.PRemoveObjectionText + "\n                    </button>\n                </div>")
    }, n.prototype.syncAlertBoxCookie = function(e) {
        var t = L.ReconsentFrequencyDays;
        T.setCookie(y.ALERT_BOX_CLOSED, e = e || "", t, !1, new Date(e))
    }, n.prototype.syncCookieExpiry = function() {
        if (_.syncRequired) {
            var e = L.ReconsentFrequencyDays,
                t = T.getCookie(y.ALERT_BOX_CLOSED),
                o = T.getCookie(y.OPTANON_CONSENT),
                o = (T.setCookie(y.OPTANON_CONSENT, o, e, !1, new Date(t)), O.needReconsent() && T.removeAlertBox(), T.getMergedCookieByName(y.EU_PUB_CONSENT));
            if (o)
                if (O.isIABCrossConsentEnabled()) T.removeIab2();
                else
                    for (var n = T.getCookiesChunk(o, y.EU_PUB_CONSENT), r = 0, i = Object.keys(n); r < i.length; r++) {
                        var s = i[r];
                        T.setCookie(s, n[s], e, !1, new Date(t))
                    }
            o = T.getCookie(y.ADDITIONAL_CONSENT_STRING);
            o && T.setCookie(y.ADDITIONAL_CONSENT_STRING, o, e, !1, new Date(t))
        }
    }, n.prototype.syncOtPreviewCookie = function() {
        var e = T.getCookie(y.OT_PREVIEW);
        e && T.setCookie(y.OT_PREVIEW, e, 1, !1)
    }, n.prototype.dispatchConsentEvent = function() {
        window.dispatchEvent(new CustomEvent("OTConsentApplied", {
            OTConsentApplied: "yes"
        }))
    }, n.prototype.getConsentLanguage = function() {
        var e;
        return _.lang ? (e = _.lang.toUpperCase(), this.IABTCF_SUPPORTED_LANGUAGES.has(e) || (e = e.substr(0, 2), this.IABTCF_SUPPORTED_LANGUAGES.has(e)) ? e : "PT" === e ? this.IABTCF_DEFAULT_PORTUGUESE : "SR" === e ? this.IABTCF_DEFAULT_SERBIAN : this.IABTCF_DEFAULT_LANGUAGE) : this.IABTCF_DEFAULT_LANGUAGE
    };
    var E, O = new n,
        oo = function() {};
    lo.prototype.isAlwaysActiveGroup = function(e) {
        var t;
        return !this.getGrpStatus(e) || (t = this.getGrpStatus(e).toLowerCase(), (t = e.Parent && t !== f.ALWAYS_ACTIVE ? this.getGrpStatus(this.getParentGroup(e.Parent)).toLowerCase() : t) === f.ALWAYS_ACTIVE)
    }, lo.prototype.getGrpStatus = function(e) {
        return e && e.Status ? b.DNTEnabled && e.IsDntEnabled ? f.DNT : e.Status : ""
    }, lo.prototype.getParentGroup = function(t) {
        var e;
        return t && 0 < (e = L.Groups.filter(function(e) {
            return e.OptanonGroupId === t
        })).length ? e[0] : null
    }, lo.prototype.checkIfGroupHasConsent = function(t) {
        var e = l.groupsConsent,
            o = P.findIndex(e, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            });
        return -1 < o && "1" === e[o].split(":")[1]
    }, lo.prototype.checkIsActiveByDefault = function(e) {
        var t;
        return !this.getGrpStatus(e) || (t = this.getGrpStatus(e).toLowerCase(), (t = e.Parent && t !== f.ALWAYS_ACTIVE ? this.getGrpStatus(this.getParentGroup(e.Parent)).toLowerCase() : t) === f.ALWAYS_ACTIVE) || t === f.INACTIVE_LANDING_PAGE || t === f.ACTIVE || t === f.DNT && !b.DNTEnabled
    }, lo.prototype.getGroupById = function(e) {
        for (var t = null, o = 0, n = L.Groups; o < n.length; o++) {
            for (var r = n[o], i = 0, s = U(r.SubGroups, [r]); i < s.length; i++) {
                var a = s[i];
                if (a.CustomGroupId === e) {
                    t = a;
                    break
                }
            }
            if (t) break
        }
        return t
    }, lo.prototype.isSoftOptInGrp = function(e) {
        return !!e && (e = e && !e.Parent ? e : D.getParentGroup(e.Parent), "inactive landingpage" === D.getGrpStatus(e).toLowerCase())
    }, lo.prototype.isOptInGrp = function(e) {
        return !!e && "inactive" === D.getGrpStatus(e).toLowerCase()
    }, lo.prototype.getParentByGrp = function(e) {
        return e.Parent ? this.getGroupById(e.Parent) : null
    }, lo.prototype.getVSById = function(e) {
        return l.getVendorsInDomain().get(e)
    }, lo.prototype.getGrpByVendorId = function(e) {
        var t = null;
        return t = l.getVendorsInDomain().has(e) ? l.getVendorsInDomain().get(e).groupRef : t
    };
    var D, no, ro, io, so, ao = lo;

    function lo() {}(Lr = no = no || {}).SaleOptOut = "SaleOptOutCID", Lr.SharingOptOut = "SharingOptOutCID", Lr.PersonalDataConsents = "PersonalDataCID", (Lr = ro = ro || {}).SharingOptOutNotice = "SharingOptOutCID", Lr.SaleOptOutNotice = "SaleOptOutCID", Lr.SensitiveDataLimitUseNotice = "SensitivePICID || SensitiveSICID || GeolocationCID || RREPInfoCID || CommunicationCID || GeneticCID|| BiometricCID || HealthCID || SexualOrientationCID", (Lr = io = io || {}).KnownChildSensitiveDataConsents1 = "KnownChildSellPICID", Lr.KnownChildSensitiveDataConsents2 = "KnownChildSharePICID", (Lr = so = so || {}).SensitiveDataProcessing1 = "SensitivePICID", Lr.SensitiveDataProcessing2 = "SensitiveSICID", Lr.SensitiveDataProcessing3 = "GeolocationCID", Lr.SensitiveDataProcessing4 = "RREPInfoCID", Lr.SensitiveDataProcessing5 = "CommunicationCID", Lr.SensitiveDataProcessing6 = "GeneticCID", Lr.SensitiveDataProcessing7 = "BiometricCID", Lr.SensitiveDataProcessing8 = "HealthCID", Lr.SensitiveDataProcessing9 = "SexualOrientationCID", po.prototype.initialiseCssReferences = function() {
        var e, t = "";
        document.getElementById("onetrust-style") ? e = document.getElementById("onetrust-style") : ((e = document.createElement("style")).id = "onetrust-style", S.moduleInitializer.CookieV2CSPEnabled && _.nonce && e.setAttribute("nonce", _.nonce)), xs.commonStyles && (t += xs.commonStyles), xs.bannerGroup && (t += xs.bannerGroup.css, S.fp.CookieV2SSR || (t += this.addCustomBannerCSS()), L.bannerCustomCSS) && (t += L.bannerCustomCSS), xs.preferenceCenterGroup && (t = (t += xs.preferenceCenterGroup.css) + this.addCustomPreferenceCenterCSS()), xs.cookieListGroup && !S.fp.CookieV2TrackingTechnologies && (t = (t += xs.cookieListGroup.css) + this.addCustomCookieListCSS()), t += this.addPersistentLogoCSS(), this.processedCSS = t, b.ignoreInjectingHtmlCss || (e.textContent = t, v(document.head).append(e))
    }, po.prototype.addPersistentLogoCSS = function() {
        if (L.cookiePersistentLogo) {
            var e = I.updateCorrectUrl(L.cookiePersistentLogo),
                t = new URL(e, window.location.origin).pathname;
            if (!(S.fp.CMPIconSprite && (S.fp.CMPIconSprite, t.includes("/logos/static/")) && (t.includes("src/assets/images/") || new URL(e, window.location.origin).host.includes("localhost")) || L.cookiePersistentLogo.includes("ot_guard_logo.svg"))) return ".ot-floating-button__front{background-image:url('" + e + "')}"
        }
        return ""
    }, po.prototype.shouldAddExtIconCss = function() {
        return L.BannerRequireExternalLinks && (!S.fp.CMPIconSprite || (S.fp.CMPIconSprite, L.BannerExternalLinksLogo))
    }, po.prototype.setToggleColor = function() {
        var e = L.PCenterToggleInActiveColor,
            t = L.PCenterToggleActiveColor,
            t = t ? "#onetrust-consent-sdk #onetrust-pc-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {\n                background-color: " + t + ";\n            }" : "";
        return e && (t += "\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-switch-nob {\n                    background-color: " + e + ";\n                }"), t
    }, po.prototype.setButonColor = function() {
        var e, t = L.pcButtonColor,
            o = L.pcButtonTextColor,
            n = L.pcLegIntButtonColor,
            r = L.pcLegIntButtonTextColor,
            i = "";
        return (t || o) && (e = b.pcName === nt ? "#onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Category_Item + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk.ot-leg-opt-out " + A.P_Li_Hdr + "{\n                    border-color: " + t + ";\n                }" : "", i = "#onetrust-consent-sdk #onetrust-pc-sdk\n            button:not(#clear-filters-handler):not(.ot-close-icon):not(#filter-btn-handler):not(.ot-remove-objection-handler):not(.ot-obj-leg-btn-handler):not([aria-expanded]):not(.ot-link-btn),\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-active-leg-btn {\n                " + (t ? "background-color: " + t + ";border-color: " + t + ";" : "") + "\n                " + (o ? "color: " + o + ";" : "") + "\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk ." + A.P_Active_Menu + " {\n                " + (t ? "border-color: " + t + ";" : "") + "\n            }\n            " + e + "\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-remove-objection-handler{\n                background-color: transparent;\n                border: 1px solid transparent;\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn {\n                " + (n ? "background-color: " + n + ";" : "") + "\n                " + (r ? "color: " + r + "; border-color: " + r + ";" : "") + "\n            }"), i
    }, po.prototype.setFocusBorderColor = function() {
        var e = "",
            t = L.PCFocusBorderColor;
        return t && (e += '\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-tgl input:focus + .ot-switch, .ot-switch .ot-switch-nob, .ot-switch .ot-switch-nob:before,\n            #onetrust-pc-sdk .ot-checkbox input[type="checkbox"]:focus + label::before,\n            #onetrust-pc-sdk .ot-chkbox input[type="checkbox"]:focus + label::before {\n                outline-color: ' + t + ";\n                outline-width: 1px;\n                outline-offset: 1px;\n            }\n            #onetrust-pc-sdk .ot-host-item > button:focus, #onetrust-pc-sdk .ot-ven-item > button:focus {\n                border: 1px solid " + t + ";\n            }\n            #onetrust-consent-sdk #onetrust-pc-sdk *:focus,\n            #onetrust-consent-sdk #onetrust-pc-sdk .ot-vlst-cntr > a:focus {\n               outline: 1px solid " + t + ";\n               outline-offset: 1px;\n            }"), e
    }, po.prototype.setCloseIconColor = function() {
        var e = "";
        return L.PCCloseButtonType === Pe.Link && (e += "#onetrust-pc-sdk.ot-close-btn-link .ot-close-icon {color: " + L.PCContinueColor + "}"), e
    }, po.prototype.setTabLayoutStyles = function() {
        var e = "",
            t = L.pcMenuColor,
            o = L.pcMenuHighLightColor;
        return b.pcName === st && (t && (e += "#onetrust-consent-sdk #onetrust-pc-sdk .category-menu-switch-handler {\n                    background-color: " + t + "\n                }"), o) && (e += "#onetrust-consent-sdk #onetrust-pc-sdk ." + A.P_Active_Menu + " {\n                    background-color: " + o + "\n                }"), e
    }, po.prototype.setFocusIfTemplateUpgrade = function() {
        var e = "",
            t = L.PCFocusBorderColor;
        return !L.PCTemplateUpgrade && t && (e += '\n            #onetrust-pc-sdk input[type="checkbox"]:focus + .accordion-header,\n            #onetrust-pc-sdk .category-item .ot-switch.ot-toggle input:focus + .ot-switch-label,\n            #onetrust-pc-sdk .checkbox input:focus + label::after {\n                outline-color: ' + t + ";\n                outline-width: 1px;\n            }"), e
    }, po.prototype.setExtLnkUrl = function() {
        var e = "",
            t = I.updateCorrectUrl(L.OTExternalLinkLogo);
        return t && (e += "a.ot-ext-lnk:after {\n                    content: '';\n                    background-image: url('" + (L.BannerExternalLinksLogo ? I.updateCorrectUrl(L.BannerExternalLinksLogo) : t) + "');\n                    display: inline-block;\n                    width: 13px;\n                    height: 13px;\n                    background-size: contain;\n                    background-repeat: no-repeat;\n                    margin-bottom: -2px;\n                    margin-left: 2px;\n                }\n            "), e
    }, po.prototype.setBannerLinkMargins = function() {
        return "#onetrust-banner-sdk #onetrust-policy-text a.ot-cookie-policy-link,\n                         #onetrust-banner-sdk #onetrust-policy-text a.ot-imprint-link {\n                    margin-left: 5px;\n                }"
    }, po.prototype.setCustomCss = function() {
        var e = "";
        return L.pcCustomCSS && (e += L.pcCustomCSS), e
    };
    var co, uo = po;

    function po() {
        this.processedCSS = "", this.addCustomBannerCSS = function() {
            var e = L.backgroundColor,
                t = L.buttonColor,
                o = L.textColor,
                n = L.buttonTextColor,
                r = L.bannerMPButtonColor,
                i = L.bannerMPButtonTextColor,
                s = L.bannerAccordionBackgroundColor,
                a = L.BSaveBtnColor,
                l = L.BCategoryContainerColor,
                c = L.BLineBreakColor,
                d = L.BCategoryStyleColor,
                u = L.bannerLinksTextColor,
                p = L.BFocusBorderColor,
                o = "\n        " + (b.bannerName === Qe ? e ? "#onetrust-consent-sdk #onetrust-banner-sdk .ot-sdk-container {\n                    background-color: " + e + ";}" : "" : e ? "#onetrust-consent-sdk #onetrust-banner-sdk {background-color: " + e + ";}" : "") + "\n            " + (o ? "#onetrust-consent-sdk #onetrust-policy-title,\n                    #onetrust-consent-sdk #onetrust-policy-text,\n                    #onetrust-consent-sdk .ot-b-addl-desc,\n                    #onetrust-consent-sdk .ot-dpd-desc,\n                    #onetrust-consent-sdk .ot-dpd-title,\n                    #onetrust-consent-sdk #onetrust-policy-text *:not(.onetrust-vendors-list-handler),\n                    #onetrust-consent-sdk .ot-dpd-desc *:not(.onetrust-vendors-list-handler),\n                    #onetrust-consent-sdk #onetrust-banner-sdk #banner-options *,\n                    #onetrust-banner-sdk .ot-cat-header,\n                    #onetrust-banner-sdk .ot-optout-signal\n                    {\n                        color: " + o + ";\n                    }" : "") + "\n            " + (s ? "#onetrust-consent-sdk #onetrust-banner-sdk .banner-option-details {\n                    background-color: " + s + ";}" : "") + "\n            " + (u ? " #onetrust-consent-sdk #onetrust-banner-sdk a[href],\n                    #onetrust-consent-sdk #onetrust-banner-sdk a[href] font,\n                    #onetrust-consent-sdk #onetrust-banner-sdk .ot-link-btn\n                        {\n                            color: " + u + ";\n                        }" : "");
            return (t || n) && (o += "#onetrust-consent-sdk #onetrust-accept-btn-handler,\n                         #onetrust-banner-sdk #onetrust-reject-all-handler,\n                         #onetrust-banner-sdk #ot-dialog-confirm-handler {\n                            " + (t ? "background-color: " + t + ";border-color: " + t + ";" : "") + "\n                " + (n ? "color: " + n + ";" : "") + "\n            }"), p && (o += "\n            #onetrust-consent-sdk #onetrust-banner-sdk *:focus,\n            #onetrust-consent-sdk #onetrust-banner-sdk:focus {\n               outline-color: " + p + ";\n               outline-width: 1px;\n            }"), (i || r) && (o += "\n            #onetrust-consent-sdk #onetrust-pc-btn-handler,\n            #onetrust-consent-sdk #onetrust-pc-btn-handler.cookie-setting-link,\n            #onetrust-consent-sdk #ot-dialog-cancel-handler {\n                " + (i ? "color: " + i + "; border-color: " + i + ";" : "") + "\n                background-color:\n                " + (r && !L.BannerSettingsButtonDisplayLink ? r : e) + ";\n            }"), b.bannerName === et && (r = i = t = u = s = void 0, d && (i = "background-color: " + d + ";", r = "border-color: " + d + ";"), p && (o += "\n                #onetrust-consent-sdk #onetrust-banner-sdk .ot-tgl input:focus+.ot-switch .ot-switch-nob,\n                #onetrust-consent-sdk #onetrust-banner-sdk .ot-chkbox input:focus + label::before {\n                    outline-color: " + p + ";\n                    outline-width: 1px;\n                }"), o += "#onetrust-banner-sdk .ot-bnr-save-handler {" + (s = a ? "color: " + n + ";border-color: " + n + ";background-color: " + a + ";" : s) + "}#onetrust-banner-sdk .ot-cat-lst {" + (u = l ? "background-color: " + l + ";" : u) + "}#onetrust-banner-sdk .ot-cat-bdr {" + (t = c ? "border-color: " + c + ";" : t) + "}#onetrust-banner-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob:before,#onetrust-banner-sdk .ot-chkbox input:checked~label::before {" + i + "}#onetrust-banner-sdk .ot-chkbox label::before,#onetrust-banner-sdk .ot-tgl input:checked+.ot-switch .ot-switch-nob {" + r + "}#onetrust-banner-sdk #onetrust-pc-btn-handler.cookie-setting-link {background: inherit}"), L.BCloseButtonType === Pe.Link && (o += "#onetrust-banner-sdk.ot-close-btn-link .banner-close-button {color: " + L.BContinueColor + "}"), o += co.setBannerLinkMargins()
        }, this.addCustomPreferenceCenterCSS = function() {
            var e = L.pcBackgroundColor,
                t = L.pcTextColor,
                o = L.pcLinksTextColor,
                n = L.PCenterEnableAccordion,
                r = L.pcAccordionBackgroundColor,
                e = "\n            " + (e ? (b.pcName === nt ? "#onetrust-consent-sdk #onetrust-pc-sdk .group-parent-container,\n                        #onetrust-consent-sdk #onetrust-pc-sdk .manage-pc-container,\n                        #onetrust-pc-sdk " + A.P_Vendor_List : "#onetrust-consent-sdk #onetrust-pc-sdk") + ",\n                #onetrust-consent-sdk " + A.P_Search_Cntr + ",\n                " + (n && b.pcName === nt ? "#onetrust-consent-sdk #onetrust-pc-sdk .ot-accordion-layout" + A.P_Category_Item : "#onetrust-consent-sdk #onetrust-pc-sdk .ot-switch.ot-toggle") + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Tab_Grp_Hdr + " .checkbox,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Title + ":after\n                " + (S.isV2Template ? ",#onetrust-consent-sdk #onetrust-pc-sdk #ot-sel-blk,\n                        #onetrust-consent-sdk #onetrust-pc-sdk #ot-fltr-cnt,\n                        #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Triangle : "") + " {\n                    background-color: " + e + ";\n                }\n               " : "") + "\n            " + (t ? "#onetrust-consent-sdk #onetrust-pc-sdk h3,\n                #onetrust-consent-sdk #onetrust-pc-sdk h4,\n                #onetrust-consent-sdk #onetrust-pc-sdk h5,\n                #onetrust-consent-sdk #onetrust-pc-sdk h6,\n                #onetrust-consent-sdk #onetrust-pc-sdk p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Vendor_Container + " " + A.P_Ven_Opts + " p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Policy_Txt + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Li_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Leg_Select_All + " span,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Host_Cntr + " " + A.P_Host_Info + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Fltr_Modal + " #modal-header,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-checkbox label span,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Vendor_List + " " + A.P_Select_Cntr + " p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Vendor_List + " " + A.P_Vendor_Title + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Vendor_List + ' #ot-lst-title p[aria-level="3"],\n                #onetrust-consent-sdk #onetrust-pc-sdk ' + A.P_Vendor_List + " .back-btn-handler p,\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Vendor_List + " " + A.P_Ven_Name + ",\n                #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Vendor_List + " " + A.P_Vendor_Container + " .consent-category,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-leg-btn-container .ot-inactive-leg-btn,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-label-status,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-chkbox label span,\n                #onetrust-consent-sdk #onetrust-pc-sdk #clear-filters-handler,\n                #onetrust-consent-sdk #onetrust-pc-sdk .ot-optout-signal\n                {\n                    color: " + t + ";\n                }" : "") + "\n            " + (o ? " #onetrust-consent-sdk #onetrust-pc-sdk .privacy-notice-link,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-pgph-link,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler + a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .category-host-list-handler,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Ven_Link + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Ven_Leg_Claim + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Host_Cntr + " " + A.P_Host_Title + " a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Host_Cntr + " " + A.P_Acc_Header + " " + A.P_Host_View_Cookies + ",\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Host_Cntr + " " + A.P_Host_Info + " a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Content + " " + A.P_Policy_Txt + " .ot-link-btn,\n                    #onetrust-consent-sdk #onetrust-pc-sdk .ot-vnd-serv .ot-vnd-item .ot-vnd-info a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-lst-cnt .ot-vnd-info a,\n                    #onetrust-consent-sdk #onetrust-pc-sdk #ot-pc-desc a\n                    {\n                        color: " + o + ";\n                    }" : "") + "\n            #onetrust-consent-sdk #onetrust-pc-sdk .category-vendors-list-handler:hover { text-decoration: underline;}\n            " + (n && r ? "#onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Acc_Container + A.P_Acc_Txt + ",\n            #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Acc_Txt + " " + A.P_Subgrp_Tgl_Cntr + " .ot-switch.ot-toggle\n             {\n                background-color: " + r + ";\n            }" : "") + "\n            " + (r ? " #onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Host_Cntr + " " + A.P_Host_Info + ",\n                    " + (S.isV2Template ? "#onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Acc_Txt + " .ot-ven-dets" : "#onetrust-consent-sdk #onetrust-pc-sdk " + A.P_Acc_Txt + " " + A.P_Ven_Opts) + "\n                            {\n                                background-color: " + r + ";\n                            }" : "") + "\n        ",
                e = (e = (e = (e = (e = (e = (e += co.setButonColor()) + co.setToggleColor()) + co.setFocusBorderColor()) + co.setCloseIconColor()) + co.setTabLayoutStyles()) + co.setTabLayoutStyles()) + co.setFocusIfTemplateUpgrade();
            return co.shouldAddExtIconCss() && (e += co.setExtLnkUrl()), e += co.setCustomCss()
        }, this.addCustomCookieListCSS = function() {
            var e = L.CookiesV2NewCookiePolicy ? "-v2.ot-sdk-cookie-policy" : "",
                e = "\n                " + (L.cookieListPrimaryColor ? "\n                    #ot-sdk-cookie-policy" + e + " h5,\n                    #ot-sdk-cookie-policy" + e + " h6,\n                    #ot-sdk-cookie-policy" + e + " li,\n                    #ot-sdk-cookie-policy" + e + " p,\n                    #ot-sdk-cookie-policy" + e + " a,\n                    #ot-sdk-cookie-policy" + e + " span,\n                    #ot-sdk-cookie-policy" + e + " td,\n                    #ot-sdk-cookie-policy" + e + " #cookie-policy-description {\n                        color: " + L.cookieListPrimaryColor + ";\n                    }" : "") + "\n                    " + (L.cookieListTableHeaderColor ? "#ot-sdk-cookie-policy" + e + " th {\n                        color: " + L.cookieListTableHeaderColor + ";\n                    }" : "") + "\n                    " + (L.cookieListGroupNameColor ? "#ot-sdk-cookie-policy" + e + " .ot-sdk-cookie-policy-group {\n                        color: " + L.cookieListGroupNameColor + ";\n                    }" : "") + "\n                    " + (L.cookieListTitleColor ? "\n                    #ot-sdk-cookie-policy" + e + " #cookie-policy-title {\n                            color: " + L.cookieListTitleColor + ";\n                        }\n                    " : "") + "\n            " + (e && L.CookieListTableHeaderBackgroundColor ? "\n                    #ot-sdk-cookie-policy" + e + " table th {\n                            background-color: " + L.CookieListTableHeaderBackgroundColor + ";\n                        }\n                    " : "") + "\n            ";
            return L.cookieListCustomCss && (e += L.cookieListCustomCss), e
        }
    }
    ho.prototype.getAllowAllButton = function() {
        return v("#onetrust-pc-sdk #accept-recommended-btn-handler")
    }, ho.prototype.getSelectedVendors = function() {
        return v("#onetrust-pc-sdk " + A.P_Tgl_Cntr + " .ot-checkbox input:checked")
    };
    var Co, go = ho;

    function ho() {}
    So.prototype.isIabCookieValid = function() {
        var e = null;
        return null !== (e = b.isIab2orv2Template ? T.getCookie("eupubconsent-v2") : e)
    }, So.prototype.iabTypeIsChanged = function() {
        this.isIabCookieValid() || (T.removeAlertBox(), T.removeIab1())
    }, So.prototype.initializeIABModule = function() {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return L.IsIabEnabled ? (S.moduleInitializer.otIABModuleData = window.otIabModule, O.setIabData(), [4, O.populateVendorListTCF()]) : [3, 2];
                    case 1:
                        return e.sent(), O.isIABCrossConsentEnabled() || this.iabTypeIsChanged(), O.populateIABCookies(), L.UseGoogleVendors && (L.NewVendorsInactiveEnabled && this.removeATPListVendors(), this.removeInActiveAddtlVendors()), [3, 3];
                    case 2:
                        T.removeIab1(), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, So.prototype.removeATPListVendors = function() {
        var e, t, o = S.moduleInitializer.GoogleData.vendorListVersion;
        for (t in _.addtlVendorsList)(null == (e = _.addtlVendorsList[t]) ? void 0 : e.gvlVersion) > o && (_.deletedGoogleVendors[t] = _.addtlVendorsList[t], delete _.addtlVendorsList[t])
    }, So.prototype.removeInActiveAddtlVendors = function() {
        var e, t = L.OverridenGoogleVendors;
        for (e in t) t[e].active || delete _.addtlVendorsList[e]
    }, So.prototype.getIABConsentData = function() {
        var e = _.oneTrustIABConsent,
            t = O.iabStringSDK().tcString(),
            o = (_.tcModel.unsetAllPurposeConsents(), _.tcModel.unsetAllVendorConsents(), _.tcModel.unsetAllVendorLegitimateInterests(), _.tcModel.unsetAllSpecialFeatureOptins(), _.tcModel.unsetAllPurposeLegitimateInterests(), _.tcModel.publisherConsents.empty(), _.tcModel.publisherLegitimateInterests.empty(), _.tcModel.purposeConsents.set(P.getActiveIdArray(e.purpose)), _.tcModel.publisherConsents.set(P.getActiveIdArray(e.purpose)), b.legIntSettings.PAllowLI ? P.getActiveIdArray(e.legimateInterest) : []),
            o = (_.tcModel.purposeLegitimateInterests.set(o), _.tcModel.publisherLegitimateInterests.set(o), _.tcModel.vendorConsents.set(P.getActiveIdArray(P.distinctArray(e.vendors))), b.legIntSettings.PAllowLI && this.shouldSetVendorLegitimateInterest(e) && (e.legIntVendors = []), _.tcModel.vendorLegitimateInterests.set(P.getActiveIdArray(P.distinctArray(e.legIntVendors))), _.tcModel.specialFeatureOptins.set(P.getActiveIdArray(e.specialFeatures)), new Date),
            e = new Date(o.getUTCFullYear(), o.getUTCMonth(), o.getUTCDate(), 0, 0, 0),
            o = (_.tcModel.lastUpdated = e, _.tcModel.created = e, t.encode(_.tcModel));
        return _.cmpApi.update(o, !1), o
    }, So.prototype.shouldSetVendorLegitimateInterest = function(e) {
        return !_.anyVendorHasOnlySplPur && !P.getActiveIdArray(e.legimateInterest)
    }, So.prototype.decodeTCString = function(e) {
        return O.iabStringSDK().tcString().decode(e)
    }, So.prototype.getVendorConsentsRequestV2 = function(e) {
        var o;
        return window.__tcfapi("getInAppTCData", 2, function(e, t) {
            o = [e, t]
        }), e.apply(this, o)
    }, So.prototype.getPingRequestForTcf = function(e) {
        var t;
        return window.__tcfapi("ping", 2, function(e) {
            t = [e]
        }), e.apply(this, t)
    }, So.prototype.populateVendorAndPurposeFromCookieData = function() {
        var n = _.oneTrustIABConsent,
            e = yo.decodeTCString(n.IABCookieValue),
            t = k.GroupTypes,
            r = {},
            i = {},
            s = (b.iabGrps.forEach(function(e) {
                e.Type === t.Pur ? r[b.iabGrpIdMap[e.CustomGroupId]] = e : e.Type === t.Spl_Ft && (i[b.iabGrpIdMap[e.CustomGroupId]] = e)
            }), []);
        this.syncVendorConsent(e), s = [], e.vendorLegitimateInterests.forEach(function(e, t) {
            var o = e;
            _.vendorsSetting[t] && _.vendorsSetting[t].legInt || !e || (s.push(t), o = !1), n.legIntVendors.push(t + ":" + o)
        }), e.vendorLegitimateInterests.unset(s), s = [], e.purposeConsents.forEach(function(e, o) {
            var t = e,
                e = (!(r[o] && r[o].HasConsentOptOut) && e && (s.push(o), t = !1), P.findIndex(n.purpose, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? n.purpose.push(o + ":" + t) : n.purpose[e] = o + ":" + t
        }), e.purposeConsents.unset(s), e.publisherConsents.unset(s), s = [], e.specialFeatureOptins.forEach(function(e, o) {
            var t = e,
                e = (!(i[o] && i[o].HasConsentOptOut) && e && (s.push(o), t = !1), P.findIndex(n.specialFeatures, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? n.specialFeatures.push(o + ":" + t) : n.specialFeatures[e] = o + ":" + t
        }), e.specialFeatureOptins.unset(s), this.syncPurAndPubLegInt(e, r), this.syncBundleAndStack(), e.gvl = _.tcModel.gvl, e.isServiceSpecific = !O.isIABCrossConsentEnabled(), _.tcModel = e, O.isAlertBoxClosedAndValid() ? _.cmpApi.update(n.IABCookieValue, !1) : O.resetTCModel()
    }, So.prototype.syncVendorConsent = function(e) {
        var n = [],
            r = [];
        e.vendorConsents.forEach(function(e, t) {
            var o = e;
            _.vendorsSetting[t] && _.vendorsSetting[t].consent || !e || (n.push(t), o = !1), r.push(t + ":" + o)
        }), _.oneTrustIABConsent.vendors = r, e.vendorConsents.unset(n)
    }, So.prototype.syncPurAndPubLegInt = function(e, n) {
        var r = [],
            i = _.oneTrustIABConsent;
        e.purposeLegitimateInterests.forEach(function(e, o) {
            var t = e,
                e = (!(n[o] && n[o].HasLegIntOptOut && b.legIntSettings.PAllowLI) && e && (r.push(o), t = !1), P.findIndex(i.legimateInterest, function(e, t) {
                    return e.split(":")[0] === o.toString()
                })); - 1 === e ? i.legimateInterest.push(o + ":" + t) : i.legimateInterest[e] = o + ":" + t
        }), e.purposeLegitimateInterests.unset(r), e.publisherLegitimateInterests.unset(r)
    }, So.prototype.syncBundleAndStack = function() {
        var e = T.readCookieParam(y.OPTANON_CONSENT, "groups"),
            n = (_.groupsConsent = P.strToArr(e), k.GroupTypes);
        L.Groups.forEach(function(t) {
            var e, o;
            t.Type !== n.Bundle && t.Type !== n.Stack || (o = I.isBundleOrStackActive(t), e = P.findIndex(_.groupsConsent, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            }), o = t.CustomGroupId + ":" + Number(o), -1 < e ? _.groupsConsent[e] = o : _.groupsConsent.push(o))
        }), T.writeCookieParam(y.OPTANON_CONSENT, "groups", _.groupsConsent.join(","))
    }, So.prototype.populateGoogleConsent = function() {
        var e;
        L.UseGoogleVendors && (e = T.getCookie(y.ADDITIONAL_CONSENT_STRING)) && (_.isAddtlConsent = !0, _.addtlVendors.vendorConsent = e.replace(_.addtlConsentVersion, "").split("."))
    }, So.prototype.isInitIABCookieData = function(e) {
        return "init" === e || O.needReconsent()
    }, So.prototype.updateFromGlobalConsent = function(e) {
        var t = _.oneTrustIABConsent;
        t.IABCookieValue = e, t.purpose = t.purpose || [], t.specialFeatures = t.specialFeatures || [], t.legIntVendors = [], t.legimateInterest = t.legimateInterest || [], t.vendors = [], yo.populateVendorAndPurposeFromCookieData(), T.setCookie(y.EU_PUB_CONSENT, "", -1)
    };
    var yo, fo = So;

    function So() {}
    To.prototype.loadBanner = function() {
        S.moduleInitializer.ScriptDynamicLoadEnabled ? "complete" === document.readyState ? v(window).trigger("otloadbanner") : window.addEventListener("load", function(e) {
            v(window).trigger("otloadbanner")
        }) : "loading" !== document.readyState ? v(window).trigger("otloadbanner") : window.addEventListener("DOMContentLoaded", function(e) {
            v(window).trigger("otloadbanner")
        }), b.pubDomainData.IsBannerLoaded = !0
    }, To.prototype.OnConsentChanged = function(e) {
        var t = e.toString();
        mo.consentChangedEventMap[t] || (mo.consentChangedEventMap[t] = !0, window.addEventListener("consent.onetrust", e))
    }, To.prototype.triggerGoogleAnalyticsEvent = function(e, t, o, n) {
        var r = !1;
        S.moduleInitializer.GATrackToggle && ("AS" === S.moduleInitializer.GATrackAssignedCategory || "" === S.moduleInitializer.GATrackAssignedCategory || window.OnetrustActiveGroups.includes("," + S.moduleInitializer.GATrackAssignedCategory + ",")) && (r = !0), !b.ignoreGoogleAnlyticsCall && r && (void 0 !== window._gaq && window._gaq.push(["_trackEvent", e, t, o, n]), "function" == typeof window.ga && window.ga("send", "event", e, t, o, n), r = window[b.otDataLayer.name], !b.otDataLayer.ignore) && void 0 !== r && r && r.constructor === Array && ("function" == typeof window.gtag ? window.gtag("event", "trackOptanonEvent", {
            optanonCategory: e,
            optanonAction: t,
            optanonLabel: o,
            optanonValue: n
        }) : r.push({
            event: "trackOptanonEvent",
            optanonCategory: e,
            optanonAction: t,
            optanonLabel: o,
            optanonValue: n
        }))
    }, To.prototype.setAlertBoxClosed = function(e) {
        var t = (new Date).toISOString(),
            e = (e ? T.setCookie(y.ALERT_BOX_CLOSED, t, L.ReconsentFrequencyDays) : T.setCookie(y.ALERT_BOX_CLOSED, t, 0), v(".onetrust-pc-dark-filter").el[0]);
        e && "none" !== getComputedStyle(e).getPropertyValue("display") && v(".onetrust-pc-dark-filter").fadeOut(400)
    }, To.prototype.updateConsentFromCookie = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                return t ? (yo.isInitIABCookieData(t) || yo.updateFromGlobalConsent(t), "init" === t && (T.removeIab1(), O.isAlertBoxClosedAndValid() && O.resetTCModel(), T.removeAlertBox())) : (O.resetTCModel(), O.updateCrossConsentCookie(!1), O.setIABCookieData()), mo.assetPromise.then(function() {
                    mo.loadBanner()
                }), [2]
            })
        })
    };
    var mo, vo = To;

    function To() {
        var t = this;
        this.consentChangedEventMap = {}, this.assetResolve = null, this.assetPromise = new Promise(function(e) {
            t.assetResolve = e
        })
    }
    ko.prototype.writeHstParam = function(e, t) {
        T.writeCookieParam(e, "hosts", P.arrToStr((t = void 0 === t ? null : t) || _.hostsConsent))
    }, ko.prototype.writeGenVenCookieParam = function(e) {
        var t = L.GeneralVendors,
            o = _.genVendorsConsent,
            n = "";
        t.forEach(function(e) {
            n += e.VendorCustomId + ":" + (o[e.VendorCustomId] ? "1" : "0") + ","
        }), T.writeCookieParam(e, "genVendors", n)
    }, ko.prototype.writeVSConsentCookieParam = function(e) {
        var o = "";
        _.vsConsent.forEach(function(e, t) {
            return o += t + ":" + (e ? "1" : "0") + ","
        }), o = o.slice(0, -1), T.writeCookieParam(e, Qt, o)
    }, ko.prototype.updateGroupsInCookie = function(e, t) {
        T.writeCookieParam(e, "groups", P.arrToStr((t = void 0 === t ? null : t) || _.groupsConsent))
    }, ko.prototype.writeGrpParam = function(e, t) {
        this.updateGroupsInCookie(e, t = void 0 === t ? null : t), L.IsIabEnabled && O.isAlertBoxClosedAndValid() && this.insertOrUpdateIabCookies()
    }, ko.prototype.insertOrUpdateIabCookies = function() {
        var e = _.oneTrustIABConsent;
        if (e.purpose && e.vendors) {
            _.isAddtlConsent = L.UseGoogleVendors, e.IABCookieValue = yo.getIABConsentData();
            var t = L.ReconsentFrequencyDays;
            if (O.isIABCrossConsentEnabled()) O.setIAB3rdPartyCookie(y.EU_CONSENT, e.IABCookieValue, t, !1);
            else {
                for (var o = T.getCookiesChunk(e.IABCookieValue, y.EU_PUB_CONSENT), n = 0, r = Object.keys(o); n < r.length; n++) {
                    var i = r[n];
                    T.setCookie(i, o[i], t)
                }
                L.UseGoogleVendors && T.setCookie(y.ADDITIONAL_CONSENT_STRING, "" + _.addtlConsentVersion + _.addtlVendors.vendorConsent.join("."), t)
            }
        }
    };
    var Po, Ao = ko;

    function ko() {}
    Lo.prototype.initGenVendorConsent = function() {
        var e, t, n = this;
        L.GenVenOptOut ? (e = b.consentableGrps, (t = T.readCookieParam(y.OPTANON_CONSENT, "genVendors")) ? (_.genVendorsConsent = {}, t.split(",").forEach(function(e) {
            e && "1" === (e = e.split(":"))[1] && (_.genVendorsConsent[e[0]] = !0)
        })) : (_.genVendorsConsent = {}, e.forEach(function(e) {
            var o = _.syncRequired ? D.checkIfGroupHasConsent(e) : D.checkIsActiveByDefault(e);
            e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                var t = n.isGenVenPartOfAlwaysActiveGroup(e);
                _.genVendorsConsent[e] = t || o
            })
        }))) : (_.genVendorsConsent = {}, Po.writeGenVenCookieParam(y.OPTANON_CONSENT))
    }, Lo.prototype.populateGenVendorLists = function() {
        b.consentableGrps.forEach(function(e) {
            e.GeneralVendorsIds && (D.isAlwaysActiveGroup(e) ? e.GeneralVendorsIds.forEach(function(e) {
                _.alwaysActiveGenVendors.push(e)
            }) : D.isOptInGrp(e) ? e.GeneralVendorsIds.forEach(function(e) {
                _.optInGenVendors.push(e)
            }) : D.isSoftOptInGrp(e) && e.GeneralVendorsIds.forEach(function(e) {
                _.optInGenVendors.includes(e) || _.softOptInGenVendors.push(e)
            }))
        })
    }, Lo.prototype.updateGenVendorStatus = function(e, t) {
        _.genVendorsConsent[e] = t || this.isGenVenPartOfAlwaysActiveGroup(e)
    }, Lo.prototype.isGenVenPartOfAlwaysActiveGroup = function(e) {
        return _.alwaysActiveGenVendors.includes(e)
    };
    var Io, bo = Lo;

    function Lo() {}
    Oo.prototype.isLandingPage = function() {
        var e = T.readCookieParam(y.OPTANON_CONSENT, "landingPath");
        return !e || e === location.href
    }, Oo.prototype.setLandingPathParam = function(e) {
        T.writeCookieParam(y.OPTANON_CONSENT, "landingPath", e)
    };
    var _o, Eo = Oo;

    function Oo() {}
    wo.prototype.synchroniseCookieGroupData = function(e) {
        var n = this,
            t = T.readCookieParam(y.OPTANON_CONSENT, "groups"),
            r = P.strToArr(t),
            i = P.strToArr(t.replace(/:0|:1/g, "")),
            t = O.needReconsent(),
            s = !1,
            a = !1,
            l = k.GroupTypes;
        e.forEach(function(e) {
            var t, o = e.CustomGroupId;
            e.Type !== l.Bundle && e.Type !== l.Stack && (-1 === P.indexOf(i, o) ? (s = !0, t = D.checkIsActiveByDefault(e), a = !0, r.push(o + (t ? ":1" : ":0"))) : a = n.updateImpliedConsentGroup(e, r, o, a), b.DNTEnabled && e.IsDntEnabled && -1 < r.indexOf(o + ":1") && (e.isDeniedByDNT = !0), b.gpcEnabled && e.IsGpcEnabled && b.gpcValueChanged && -1 < (t = r.indexOf(o + ":1"))) && (a = !0, _.gpcConsentTxn = !0, r[t] = o + ":0", e.isDeniedByGPC = !0)
        }), a = this.updateConsentForBundleGrps(e, r, i, a, t), (a = this.removeRedundantGrpsFromCookie(r, t, a)) && (_.fireOnetrustGrp = !0, Po.updateGroupsInCookie(y.OPTANON_CONSENT, r), _.syncRequired) && s && T.removeAlertBox()
    }, wo.prototype.updateImpliedConsentGroup = function(e, t, o, n) {
        return e.Status !== f.INACTIVE_LANDING_PAGE || O.isAlertBoxClosedAndValid() || _o.isLandingPage() || 0 <= (e = t.indexOf(o + ":0")) && (n = !0, t[e] = o + ":1"), n
    }, wo.prototype.removeRedundantGrpsFromCookie = function(e, o, t) {
        for (var n = e.length, r = t; n--;)(() => {
            var t = e[n].replace(/:0|:1/g, "");
            L.Groups.some(function(e) {
                return (!o || e.Type !== k.GroupTypes.Stack) && (e.CustomGroupId === t || e.SubGroups.some(function(e) {
                    return e.CustomGroupId === t
                }))
            }) || (r = !0, e.splice(n, 1))
        })();
        return r
    }, wo.prototype.updateConsentForBundleGrps = function(e, r, i, t, s) {
        var a = this,
            l = t,
            c = k.GroupTypes;
        return e.forEach(function(e) {
            var t, o = e.Type === c.Bundle || e.Type === c.Stack,
                n = e.CustomGroupId;
            o && (-1 === P.indexOf(i, n) ? (o = I.isBundleOrStackActive(e, r), l = !0, r.push(n + (o ? ":1" : ":0"))) : s && "false" === O.getIABCrossConsentflagData() || b.gpcEnabled && b.gpcValueChanged || _.syncRequired ? (o = I.isBundleOrStackActive(e, r), -1 < (t = r.indexOf(n + ":" + (o ? "0" : "1"))) && (l = !0, r[t] = n + (o ? ":1" : ":0"))) : l = a.updateImpliedConsentGroup(e, r, n, l))
        }), l
    }, wo.prototype.groupHasConsent = function(t) {
        var e = P.strToArr(T.readCookieParam(y.OPTANON_CONSENT, "groups")),
            o = P.findIndex(e, function(e) {
                return e.split(":")[0] === t.CustomGroupId
            });
        return -1 < o && "1" === e[o].split(":")[1]
    }, wo.prototype.synchroniseCookieHostData = function() {
        for (var n = this, e = T.readCookieParam(y.OPTANON_CONSENT, "hosts"), r = P.strToArr(e), i = P.strToArr(e.replace(/:0|:1/g, "")), s = !1, o = (L.Groups.forEach(function(e) {
                U(e.SubGroups, [e]).forEach(function(o) {
                    o.Hosts.length && o.Hosts.forEach(function(e) {
                        var t; - 1 === P.indexOf(i, e.HostId) && (s = !0, t = _.syncRequired ? n.groupHasConsent(o) : D.checkIsActiveByDefault(o), r.push(e.HostId + (t ? ":1" : ":0")))
                    })
                })
            }), r.length); o--;)(() => {
            var t = r[o].replace(/:0|:1/g, "");
            L.Groups.some(function(e) {
                return U(e.SubGroups, [e]).some(function(e) {
                    return e.Hosts.some(function(e) {
                        return e.HostId === t
                    })
                })
            }) || (s = !0, r.splice(o, 1))
        })();
        s && (_.fireOnetrustGrp = !0, Po.writeHstParam(y.OPTANON_CONSENT, r))
    }, wo.prototype.toggleGroupHosts = function(e, t) {
        var o = this;
        e.Hosts.forEach(function(e) {
            o.updateHostStatus(e, t)
        })
    }, wo.prototype.toggleGroupGenVendors = function(e, t) {
        e.GeneralVendorsIds.forEach(function(e) {
            Io.updateGenVendorStatus(e, t)
        })
    }, wo.prototype.updateHostStatus = function(t, e) {
        var o = P.findIndex(_.hostsConsent, function(e) {
            return !t.isActive && t.HostId === e.replace(/:0|:1/g, "")
        }); - 1 < o && (e = e || this.isHostPartOfAlwaysActiveGroup(t.HostId), _.hostsConsent[o] = t.HostId + ":" + (e ? "1" : "0"))
    }, wo.prototype.isHostPartOfAlwaysActiveGroup = function(e) {
        return _.oneTrustAlwaysActiveHosts.includes(e)
    };
    var Do, Vo = wo;

    function wo() {}
    var No, Bo = "OneTrust Cookie Consent",
        Go = "Banner Auto Close",
        xo = "Banner Close Button",
        Ho = "Banner - Continue without Accepting",
        Ro = "Banner - Confirm",
        Fo = "Preferences Close Button",
        Mo = "Preference Center Opened From Banner",
        Uo = "Preference Center Opened From Button",
        qo = "Preference Center Opened From Function",
        jo = "Preferences Save Settings",
        Ko = "Vendors List Opened From Function",
        zo = "Floating Cookie Settings Open Button",
        Wo = "Floating Cookie Settings Close Button",
        Yo = "Preferences Toggle On",
        Jo = "Preferences Toggle Off",
        Xo = "General Vendor Toggle On",
        Qo = "General Vendor Toggle Off",
        Zo = "Host Toggle On",
        $o = "Host Toggle Off",
        en = "Preferences Legitimate Interest Objection",
        tn = "Preferences Legitimate Interest Remove Objection",
        on = "IAB Vendor Toggle ON",
        nn = "IAB Vendor Toggle Off",
        rn = "IAB Vendor Legitimate Interest Objection",
        sn = "IAB Vendor Legitimate Interest Remove Objection",
        an = "Vendor Service Toggle On",
        ln = "Vendor Service Toggle Off",
        cn = (dn.prototype.setBannerFocus = function() {
            var e = this,
                t = Array.prototype.slice.call(v("#onetrust-banner-sdk .onetrust-vendors-list-handler").el),
                o = Array.prototype.slice.call(v('#onetrust-banner-sdk #onetrust-policy-text a,#onetrust-banner-sdk #onetrust-policy-text button,#onetrust-banner-sdk #onetrust-policy-text [tabindex]:not([tabindex="-1"])').el),
                n = Array.prototype.slice.call(v("#onetrust-banner-sdk .ot-bnr-save-handler").el),
                r = Array.prototype.slice.call(v("#onetrust-banner-sdk #onetrust-pc-btn-handler").el),
                i = Array.prototype.concat.call(Array.prototype.slice.call(v("#onetrust-banner-sdk .category-switch-handler:not([disabled])").el), Array.prototype.slice.call(v("#onetrust-banner-sdk .ot-cat-lst button").el), t),
                i = Array.prototype.concat.call(o, i),
                s = Array.prototype.slice.call(v("#onetrust-banner-sdk .onetrust-close-btn-handler").el),
                t = (b.bannerName === Qe && (i = Array.prototype.concat.call(t, o)), Array.prototype.slice.call(v("#onetrust-banner-sdk #onetrust-accept-btn-handler").el)),
                o = Array.prototype.slice.call(v("#onetrust-banner-sdk #onetrust-reject-all-handler").el),
                n = Array.prototype.concat.call(n, t, o, r),
                r = ((b.bannerName !== Je || L.IsIabEnabled) && b.bannerName !== Ye && b.bannerName !== $e || (n = Array.prototype.concat.call(r, o, t)), Array.prototype.slice.call(v("#onetrust-banner-sdk .ot-gv-list-handler").el)),
                o = (b.bannerName === et ? (i = Array.prototype.concat.call(r, i), n = Array.prototype.slice.call(v("#onetrust-banner-sdk #onetrust-button-group button").el)) : i = Array.prototype.concat.call(i, r), this.rearrangeInButtonOrder(n), v("#onetrust-banner-sdk .ot-b-addl-desc").el[0]),
                t = this.getTabbableElements(o),
                i = L.BannerAdditionalDescPlacement === le.AfterTitle ? Array.prototype.concat.call(t, i) : Array.prototype.concat.call(i, t),
                r = new Set(Array.prototype.concat.call(Array.prototype.slice.call(v("#onetrust-banner-sdk #onetrust-cookie-btn").el), i, Array.prototype.slice.call(v("#onetrust-banner-sdk .banner-option-input").el), n, Array.prototype.slice.call(v("#onetrust-banner-sdk .ot-bnr-footer-logo a").el), s));
            this.bannerEl = Array.from(r), this.banner = v("#onetrust-banner-sdk").el[0], (L.BInitialFocus || L.BInitialFocusLinkAndButton || L.ForceConsent) && (L.BInitialFocus ? setTimeout(function() {
                e.banner.focus()
            }, 1e3) : setTimeout(function() {
                e.bannerEl[0].focus()
            }, 1e3))
        }, dn.prototype.handleBannerFocus = function(e, t) {
            var o = e.target,
                n = No.bannerEl,
                r = n.indexOf(o),
                i = n.length - 1,
                s = null;
            if (this.handleBannerFocusBodyReset(t, r, i)) I.resetFocusToBody();
            else if (this.banner === o) s = this.handleInitialBannerFocus(t, n, i, s);
            else
                for (; !s;) {
                    var a = void 0;
                    0 !== (a = t ? r <= 0 ? n[i] : n[r - 1] : r === i ? n[0] : n[r + 1]).clientHeight || 0 !== a.offsetHeight ? s = a : t ? r-- : r++
                }
            s && (e.preventDefault(), s.focus())
        }, dn.prototype.rearrangeInButtonOrder = function(e) {
            L.PCTemplateUpgrade && S.fp.WebButtonCustomisations && e && e.sort(function(e, t) {
                function o(e) {
                    return (e = Array.from(e.classList).find(function(e) {
                        return e.startsWith("ot-button-order-")
                    })) ? parseInt(e.replace("ot-button-order-", "")) : 1 / 0
                }
                return o(e) - o(t)
            })
        }, dn.prototype.handleBannerFocusBodyReset = function(e, t, o) {
            return !(L.ForceConsent || !L.BInitialFocus && !L.BInitialFocusLinkAndButton || !(e && 0 === t || !e && t === o))
        }, dn.prototype.handleInitialBannerFocus = function(e, t, o, n) {
            return e && L.ForceConsent ? n = t[o] : e || (n = t[0]), n
        }, dn.prototype.setPCFocus = function(e) {
            if (e && !(e.length <= 0)) {
                for (var t = 0; t < e.length; t++) e[t].setAttribute("tabindex", "0");
                this.setFirstAndLast(e);
                this.firstItem ? this.firstItem.focus({
                    preventScroll: !0
                }) : e[0].focus(), this.firstItem && v(this.firstItem).on("keydown", No.firstItemHandler), this.lastItem && v(this.lastItem).on("keydown", No.lastItemHandler)
            }
        }, dn.prototype.setFirstAndLast = function(e) {
            this.firstItem = this.getElementForFocus(e, 0, !0), this.lastItem = this.firstItem ? this.getElementForFocus(e, e.length - 1, !1) : null
        }, dn.prototype.setLastItem = function() {
            var e = this.getPCElements(),
                e = this.getElementForFocus(e, e.length - 1, !1);
            e !== this.lastItem && (v(this.lastItem).off("keydown", No.lastItemHandler), this.lastItem = e, v(e).on("keydown", No.lastItemHandler))
        }, dn.prototype.getPCElements = function() {
            var e = "#onetrust-pc-sdk #close-pc-btn-handler,\n            #onetrust-pc-sdk .back-btn-handler,\n            #onetrust-pc-sdk ." + A.P_Active_Menu + ',\n            #onetrust-pc-sdk input,\n            #onetrust-pc-sdk a,\n            #onetrust-pc-sdk [tabindex="0"] button,\n            #onetrust-pc-sdk .save-preference-btn-handler,\n            #onetrust-pc-sdk .ot-pc-refuse-all-handler,\n            #onetrust-pc-sdk #accept-recommended-btn-handler';
            return _.pcLayer === se.CookieList ? e += " ,#onetrust-pc-sdk " + A.P_Content + " .powered-by-logo" : e += ",#onetrust-pc-sdk #vendor-list-save-btn .powered-by-logo", Array.prototype.slice.call(v(e).el)
        }, dn.prototype.getActiveTab = function() {
            return document.querySelector('#onetrust-pc-sdk .category-menu-switch-handler[tabindex="0"]')
        }, dn.prototype.getElementForFocus = function(e, t, o) {
            for (var n = e[t]; o ? n && null === n.offsetParent && t < e.length - 1 : n && null === n.offsetParent && 0 < t;) n = e[t], o ? ++t : --t;
            return n
        }, dn.prototype.handleFocusTabLayoutExceptClosePC = function(e) {
            var t = "close-pc-btn-handler" === e.target.id && (13 === e.keyCode || 32 === e.keyCode || "Enter" === e.code || "Space" === e.code);
            L.PCLayout.Tab && _.pcLayer === se.PrefCenterHome && !t && (t = No.getActiveTab()) && (e.preventDefault(), t.focus())
        }, dn.prototype.firstItemHandler = function(e) {
            var t = document.getElementById("onetrust-banner-sdk");
            9 === e.keyCode && e.shiftKey && No.firstItem !== t ? (e.preventDefault(), No.lastItem.focus()) : L.ShowPreferenceCenterCloseButton ? No.handleFocusTabLayoutExceptClosePC(e) : !L.PCLayout.Tab || _.pcLayer !== se.PrefCenterHome || 37 !== e.keyCode && 39 !== e.keyCode || (t = No.getActiveTab()) && v(t).on("keydown", No.firstItemHandler)
        }, dn.prototype.lastItemHandler = function(e) {
            9 !== e.keyCode || e.shiftKey || (e.preventDefault(), e = _.pcLayer === se.VendorList || _.pcLayer === se.CookieList, (L.PCLayout.Tab && _.isPCVisible && !L.ShowPreferenceCenterCloseButton && !e ? No.getActiveTab() : No.firstItem).focus())
        }, dn.prototype.getTabbableElements = function(e) {
            return e ? Array.from(e.querySelectorAll(["a[href]", "area[href]", "input:not([disabled])", "select:not([disabled])", "textarea:not([disabled])", "button:not([disabled])", '[tabindex]:not([tabindex="-1"])', "[contenteditable]"].join(","))).filter(function(e) {
                return !e.hasAttribute("disabled")
            }) : []
        }, dn);

    function dn() {
        this.bannerEl = []
    }
    pn.prototype.getAllGroupElements = function() {
        return document.querySelectorAll("div#onetrust-pc-sdk " + A.P_Category_Grp + " " + A.P_Category_Item + ":not(.ot-vnd-item)")
    }, pn.prototype.toggleGrpElements = function(e, t, o, n) {
        void 0 === n && (n = !1);
        for (var r = (e = b.pcName === st && L.PCTemplateUpgrade ? document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid")) : e).querySelectorAll('input[class*="category-switch-handler"]'), i = 0; i < r.length; i++) {
            var s = r[i].getAttribute("id").includes("leg-out");
            n && s || (P.setCheckedAttribute(null, r[i], o), r[i] && L.PCShowConsentLabels && (r[i].parentElement.parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(o ? L.PCActiveText : L.PCInactiveText)))
        }
        b.legIntSettings.PAllowLI && b.legIntSettings.PShowLegIntBtn && t.Type === k.GroupTypes.Pur && t.HasLegIntOptOut && !n && V.updateLegIntBtnElement(e.querySelector(".ot-leg-btn-container"), o)
    }, pn.prototype.toogleAllSubGrpElements = function(e, t) {
        var o;
        e.ShowSubgroup ? (o = e.CustomGroupId, o = this.getGroupElementByOptanonGroupId(o.toString()), V.toogleSubGroupElement(o, t, e.IsLegIntToggle)) : this.updateHiddenSubGroupData(e, t)
    }, pn.prototype.isSubGrpLegIntEnabled = function(e, t) {
        return b.legIntSettings.PAllowLI && b.legIntSettings.PShowLegIntBtn && e.Type === k.GroupTypes.Pur && e.HasLegIntOptOut && t.ShowSubgroupToggle
    }, pn.prototype.toogleSubGroupElement = function(e, t, o, n) {
        void 0 === o && (o = !1), void 0 === n && (n = !1);
        for (var r = (e = b.pcName === st && L.PCTemplateUpgrade ? document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid")) : e).querySelectorAll("li" + A.P_Subgrp_li), i = 0; i < r.length; i++) {
            var s = D.getGroupById(r[i].getAttribute("data-optanongroupid")),
                a = s.OptanonGroupId,
                l = D.getParentGroup(s.Parent),
                l = (this.isSubGrpLegIntEnabled(s, l) && o && V.updateLegIntBtnElement(r[i], t), o ? "[id='ot-sub-group-id-" + a + "-leg-out']" : "[id='ot-sub-group-id-" + a + "']"),
                a = r[i].querySelector('input[class*="cookie-subgroup-handler"]' + l);
            P.setCheckedAttribute(null, a, t), a && L.PCShowConsentLabels && (a.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(t ? L.PCActiveText : L.PCInactiveText)), n || (s.IsLegIntToggle = o, V.toggleGrpStatus(s, t), s.IsLegIntToggle = !1, Do.toggleGroupHosts(s, t), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(s, t))
        }
    }, pn.prototype.toggleGrpStatus = function(e, t) {
        var o = e.IsLegIntToggle && e.Type === k.GroupTypes.Pur ? t ? tn : en : t ? Yo : Jo;
        mo.triggerGoogleAnalyticsEvent(Bo, o, e.GroupName + ": " + e.OptanonGroupId), t ? this.updateEnabledGroupData(e) : this.updateDisabledGroupData(e)
    }, pn.prototype.setInputID = function(e, t, o, n, r) {
        v(e).attr("id", t), v(e).attr("name", t), v(e).data("optanonGroupId", o), P.setCheckedAttribute(null, e, n), v(e).attr("aria-labelledby", r)
    }, pn.prototype.updateEnabledGroupData = function(e) {
        var t, o; - 1 < Ot.indexOf(e.Type) ? this.updateIabGroupData(e, !0) : (t = V.getGroupVariable(), -1 !== (o = P.indexOf(t, e.CustomGroupId + ":0")) && (t[o] = e.CustomGroupId + ":1"))
    }, pn.prototype.updateDisabledGroupData = function(e) {
        var t, o; - 1 < Ot.indexOf(e.Type) ? this.updateIabGroupData(e, !1) : e.Status !== f.ALWAYS_ACTIVE && (t = V.getGroupVariable(), -1 !== (o = P.indexOf(t, e.CustomGroupId + ":1")) && (t[o] = e.CustomGroupId + ":0"), this.isImplicitConsentDefaultStatus(e)) && b.removeGroupFromImpliedConsentableGroup(e)
    }, pn.prototype.updateIabGroupData = function(e, t) {
        var o;
        e.Type === k.GroupTypes.Spl_Ft ? this.updateIabSpecialFeatureData(e.IabGrpId, t) : (o = e.IsLegIntToggle ? _.vendors.selectedLegInt : _.vendors.selectedPurpose, this.updateIabPurposeData(e.IabGrpId, t, o))
    }, pn.prototype.isAllSubgroupsDisabled = function(e) {
        return !e.SubGroups.some(function(e) {
            return V.isGroupActive(e)
        })
    }, pn.prototype.isAllSubgroupsEnabled = function(e) {
        return !e.SubGroups.some(function(e) {
            return V.IsGroupInActive(e)
        })
    }, pn.prototype.toggleGroupHtmlElement = function(e, t, o) {
        b.legIntSettings.PAllowLI && b.legIntSettings.PShowLegIntBtn && e.Type === k.GroupTypes.Pur && e.HasLegIntOptOut && (e = document.querySelector("[data-el-id=" + t + "]")) && this.updateLegIntBtnElement(e, o);
        e = v("#ot-group-id-" + t).el[0];
        P.setCheckedAttribute(null, e, o), e && L.PCShowConsentLabels && (e.parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(o ? L.PCActiveText : L.PCInactiveText))
    }, pn.prototype.updateLegIntBtnElement = function(e, t, o) {
        void 0 === o && (o = "");
        var n = b.legIntSettings,
            r = e.querySelector(".ot-obj-leg-btn-handler"),
            e = e.querySelector(".ot-remove-objection-handler");
        t ? (r.classList.add("ot-inactive-leg-btn"), r.classList.add("ot-leg-int-enabled"), r.classList.remove("ot-active-leg-btn"), r.focus()) : (r.classList.add("ot-active-leg-btn"), r.classList.remove("ot-inactive-leg-btn"), r.classList.remove("ot-leg-int-enabled")), r.querySelector("span").innerText = t ? n.PObjectLegIntText : n.PObjectionAppliedText, o && r.setAttribute("aria-label", o + ", " + (t ? n.PObjectLegIntText : n.PObjectionAppliedText)), d(e, "display: " + (t ? "none" : "inline-block") + ";", !0)
    }, pn.prototype.isGroupActive = function(e) {
        e = -1 < Ot.indexOf(e.Type) ? -1 !== this.isIabPurposeActive(e) : -1 !== m.inArray(e.CustomGroupId + ":1", V.getGroupVariable()) || this.isGroupEnabledForImplicitConsent(e);
        return e
    }, pn.prototype.isGroupEnabledForImplicitConsent = function(e) {
        return this.isImplicitConsentDefaultStatus(e) && b.isGroupExistInImpliedConsentableGroup(e)
    }, pn.prototype.isImplicitConsentDefaultStatus = function(e) {
        return e.Status === f.INACTIVE_LANDING_PAGE && !O.isAlertBoxClosedAndValid() && _o.isLandingPage()
    }, pn.prototype.safeFormattedGroupDescription = function(e) {
        return e && e.GroupDescription ? e.GroupDescription.replace(/\r\n/g, "<br>") : ""
    }, pn.prototype.canInsertForGroup = function(e, t) {
        void 0 === t && (t = !1);
        var o = null != e && void 0 !== e,
            n = T.readCookieParam(y.OPTANON_CONSENT, "groups"),
            r = _.groupsConsent.join(","),
            i = T.readCookieParam(y.OPTANON_CONSENT, "hosts"),
            s = _.hostsConsent.join(",");
        if (t) return !0;
        n === r && i === s || xs.ensureHtmlGroupDataInitialised();
        var a = [];
        if (_.showGeneralVendors)
            for (var l = 0, c = Object.entries(_.genVendorsConsent); l < c.length; l++) {
                var d = c[l],
                    u = d[0];
                a.push(u + ":" + (d[1] ? "1" : "0"))
            }
        _.showVendorService && _.vsConsent.forEach(function(e, t) {
            a.push(t + ":" + (e ? "1" : "0"))
        });
        t = _.groupsConsent.concat(_.hostsConsent).concat(a), n = P.contains(t, e + ":1"), r = this.doesHostExist(e), i = this.doesGroupExist(e), s = !1, _.showGeneralVendors ? s = this.doesGenVendorExist(e) : _.showVendorService && (s = this.doesVendorServiceExist(e)), t = !(!r && !s) || n && xs.canSoftOptInInsertForGroup(e);
        return !(!o || !(n && t || !i && !r && !s))
    }, pn.prototype.setAllowAllButton = function() {
        var t = 0,
            e = L.Groups.some(function(e) {
                if (-1 === Dt.indexOf(e.Type)) return V.IsGroupInActive(e) && t++, e.SubGroups.some(function(e) {
                    return V.IsGroupInActive(e)
                }) && t++, 1 <= t
            }),
            o = Co.getAllowAllButton();
        return e ? o.show("inline-block") : o.hide(), No.lastItem && No.setLastItem(), e
    }, pn.prototype.isAnyGroupOptedOut = function() {
        for (var e = !1, t = 0, o = L.Groups; t < o.length; t++) {
            var n = o[t];
            if (!0 === V.IsGroupInActive(n)) {
                e = !0;
                break
            }
        }
        return e
    }, pn.prototype.getGroupVariable = function() {
        return _.groupsConsent
    }, pn.prototype.IsGroupInActive = function(e) {
        e = -1 < Ot.indexOf(e.Type) ? -1 === this.isIabPurposeActive(e) : !(-1 < Dt.indexOf(e.Type)) && -1 === m.inArray(e.CustomGroupId + ":1", V.getGroupVariable());
        return e
    }, pn.prototype.updateIabPurposeData = function(t, e, o) {
        var n = P.findIndex(o, function(e) {
            return e.split(":")[0] === t
        });
        o[-1 === n ? Number(t) : n] = t + ":" + e
    }, pn.prototype.updateIabSpecialFeatureData = function(t, e) {
        var o = -1 === (o = P.findIndex(_.vendors.selectedSpecialFeatures, function(e) {
            return e.split(":")[0] === t
        })) ? Number(t) : o;
        _.vendors.selectedSpecialFeatures[o] = t + ":" + e
    }, pn.prototype.getGroupElementByOptanonGroupId = function(e) {
        return document.querySelector("#onetrust-pc-sdk " + A.P_Category_Grp + " " + A.P_Category_Item + '[data-optanongroupid=\n            "' + e + '"]')
    }, pn.prototype.updateHiddenSubGroupData = function(e, t) {
        e.SubGroups.forEach(function(e) {
            V.toggleGrpStatus(e, t), Do.toggleGroupHosts(e, t), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(e, t)
        })
    }, pn.prototype.isIabPurposeActive = function(e) {
        var t = e.Type === k.GroupTypes.Spl_Ft ? _.vendors.selectedSpecialFeatures : e.IsLegIntToggle ? _.vendors.selectedLegInt : _.vendors.selectedPurpose;
        return m.inArray(e.IabGrpId + ":true", t)
    }, pn.prototype.doesGroupExist = function(e) {
        return !!D.getGroupById(e)
    }, pn.prototype.doesHostExist = function(e) {
        var t = _.hostsConsent;
        return -1 !== t.indexOf(e + ":0") || -1 !== t.indexOf(e + ":1")
    }, pn.prototype.doesGenVendorExist = function(t) {
        return !!L.GeneralVendors && !!L.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        })
    }, pn.prototype.doesVendorServiceExist = function(e) {
        return _.getVendorsInDomain().has(e)
    };
    var V, un = pn;

    function pn() {}
    var Cn, gn, hn = "#onetrust-banner-sdk",
        yn = ".banner_logo",
        fn = "#onetrust-pc-sdk",
        Sn = "#onetrust-accept-btn-handler",
        mn = "#onetrust-reject-all-handler",
        vn = "#onetrust-pc-btn-handler",
        Tn = "#accept-recommended-btn-handler",
        Pn = (An.prototype.BannerPushDownHandler = function() {
            this.checkIsBrowserIE11OrBelow() || (gn.pushPageDown(hn), v(window).on("resize", function() {
                "none" !== v(hn).css("display") && gn.pushPageDown(hn)
            }))
        }, An.prototype.checkIsBrowserIE11OrBelow = function() {
            var e = window.navigator.userAgent;
            return 0 < e.indexOf("MSIE ") || 0 < e.indexOf("Trident/")
        }, An.prototype.addOTCssPropertiesToBody = function(e, t) {
            var o = gn.getCssData(e, t);
            l.customerStyles.set(e, o), gn.setStylesOnBody(t)
        }, An.prototype.removeAddedOTCssStyles = function(e) {
            void 0 === e && (e = Cn.Banner);
            var t = l.customerStyles.get(e);
            t ? (gn.setStylesOnBody(t.customerBodyCSS), gn.setStylesOnHtml(t.customerHtmlCSS), l.customerStyles.delete(e)) : 0 < l.customerStyles.size && l.customerStyles.forEach(function(e, t) {
                return gn.removeAddedOTCssStyles(t)
            })
        }, An.prototype.getCssData = function(e, t) {
            var o, n, r = v("body").el[0],
                i = v("html").el[0],
                s = {},
                a = {},
                e = l.customerStyles.get(e),
                a = e ? (o = e.scriptBodyCSS, n = e.customerBodyCSS, e = e.customerHtmlCSS, r.style.top !== o.top && (n.top = r.style.top), r.style.position !== o.position && (n.position = r.style.position), r.style.overflow !== o.overflow && (n.overflow = r.style.overflow), i.style.overflow !== o.overflow && (e.overflow = i.style.overflow), s = n, e) : (s = {
                    top: r.style.top,
                    position: r.style.position,
                    overflow: r.style.overflow
                }, {
                    overflow: i.style.overflow
                });
            return {
                scriptBodyCSS: t,
                customerBodyCSS: s,
                customerHtmlCSS: a
            }
        }, An.prototype.setStylesOnBody = function(e) {
            var t = v("body").el[0];
            gn.setStylesOnHtmlElement(t, e)
        }, An.prototype.setStylesOnHtml = function(e) {
            var t = v("html").el[0];
            gn.setStylesOnHtmlElement(t, {
                overflow: e.overflow
            })
        }, An.prototype.setStylesOnHtmlElement = function(e, t) {
            for (var o = "", n = 0, r = Object.entries(t); n < r.length; n++) {
                var i = r[n],
                    s = i[0],
                    i = i[1];
                i ? o += s + ": " + i + ";" : e.style.removeProperty(s)
            }
            o && d(e, o, !0)
        }, An.prototype.pushPageDown = function(e) {
            var t = v(e).height() + "px",
                e = (v(e).show().css("\n            bottom: auto;\n            position: absolute;\n            top: -" + t + ";\n        "), l.isPCVisible ? Cn.PC : Cn.Banner),
                t = {
                    position: "relative",
                    top: t
                };
            l.isPCVisible && (t.overflow = "hidden"), gn.addOTCssPropertiesToBody(e, t)
        }, An);

    function An() {}(Lr = Cn = Cn || {}).Banner = "Banner", Lr.PC = "PC", bn.prototype.showConsentNotice = function() {
        var e, t, o;
        !L.NoBanner || L.ForceConsent ? v(".onetrust-pc-dark-filter").removeClass("ot-hide") : v(".onetrust-pc-dark-filter").addClass("ot-hide"), v("" + kn.ONETRUST_PC_SDK).removeClass("ot-hide"), S.isV2Template && this.closePCText(!0), b.pcName === rt && (v("" + kn.ONETRUST_PC_SDK).el[0].classList.contains("ot-animated") || v("" + kn.ONETRUST_PC_SDK).addClass("ot-animated"), e = L.PreferenceCenterPosition, t = (o = L.useRTL) ? "right" : "left", o = o ? "left" : "right", v("" + kn.ONETRUST_PC_SDK).el[0].classList.contains("ot-slide-out-" + ("right" === e ? o : t)) && v("" + kn.ONETRUST_PC_SDK).removeClass("ot-slide-out-" + ("right" === e ? o : t)), v("" + kn.ONETRUST_PC_SDK).addClass("ot-slide-in-" + ("right" === e ? o : t))), S.fp.WebButtonCustomisations || V.setAllowAllButton(), No.setPCFocus(No.getPCElements()), L.NoBanner && L.ScrollCloseBanner || this.pcHasScroll(), this.handleBodyStylesForBannerPushdown()
    }, bn.prototype.hideConsentNoticeV2 = function() {
        var e, t, o;
        0 === v(this.ONETRUST_PC_SDK).length ? this.setFocusOnPage() : (S.isV2Template && this.closePCText(), L.ForceConsent && !I.isCookiePolicyPage(L.AlertNoticeText) && !O.isAlertBoxClosedAndValid() && L.ShowAlertNotice ? v("" + this.ONETRUST_PC_DARK_FILTER).css("z-index: 2147483645;").show() : v("" + this.ONETRUST_PC_DARK_FILTER).fadeOut(L.PCLayout.Panel ? 500 : 400), L.PCLayout.Panel && (e = L.PreferenceCenterPosition, t = (o = L.useRTL) ? "right" : "left", o = o ? "left" : "right", v("" + this.ONETRUST_PC_SDK).removeClass("ot-slide-in-" + ("right" === e ? o : t)), v("" + this.ONETRUST_PC_SDK).addClass("ot-slide-out-" + ("right" === e ? o : t))), v("" + this.ONETRUST_PC_SDK).fadeOut(L.PCLayout.Panel ? 500 : 400), l.isPCVisible = !1, l.pcLayer = se.Banner, this.setFocus())
    }, bn.prototype.setFocus = function() {
        var e;
        l.pcSource || O.isAlertBoxClosedAndValid() ? l.pcSource ? (l.pcSource.focus(), l.pcSource = null) : this.setFocusOnPage() : (e = v("#onetrust-banner-sdk #onetrust-pc-btn-handler").el[0]) && e.focus()
    }, bn.prototype.handleBodyStylesForBannerPushdown = function() {
        b.pcName === st && b.pagePushedDown && "top" === L.BannerPosition && gn.addOTCssPropertiesToBody(Cn.PC, {})
    }, bn.prototype.setFocusOnPage = function() {
        var e = document.querySelectorAll('button, a, input, select, textarea, [tabindex]:not([tabindex="-1"])');
        l.isKeyboardUser && e.length && e[0].focus()
    }, bn.prototype.closePCText = function(e) {
        void 0 === e && (e = !1);
        var t = document.querySelector("#onetrust-pc-sdk span[aria-live]"),
            o = L.AboutCookiesText;
        t && (t.innerText = e ? "" : o + (" " + L.pcDialogClose))
    }, bn.prototype.pcHasScroll = function() {
        this.bodyStyleChanged = !0;
        var e = v("body");
        e && e.length && gn.addOTCssPropertiesToBody(Cn.PC, {
            overflow: "hidden"
        })
    }, bn.prototype.checkIfPcSdkContainerExist = function() {
        return !v("" + kn.ONETRUST_PC_SDK).length
    };
    var kn, In = bn;

    function bn() {
        this.ONETRUST_PC_SDK = "#onetrust-pc-sdk", this.ONETRUST_PC_DARK_FILTER = ".onetrust-pc-dark-filter", this.bodyStyleChanged = !1
    }
    En.prototype.updateGtmMacros = function(e) {
        void 0 === e && (e = !0);
        var n = [];
        _.groupsConsent.forEach(function(e) {
            var t = e.replace(":1", ""),
                o = D.getGrpStatus(D.getGroupById(t)).toLowerCase() === f.ALWAYS_ACTIVE;
            P.endsWith(e, ":1") && (xs.canSoftOptInInsertForGroup(t) || o) && n.push(t)
        }), _.hostsConsent.forEach(function(e) {
            P.endsWith(e, ":1") && n.push(e.replace(":1", ""))
        }), _.showGeneralVendors && L.GenVenOptOut && L.GeneralVendors.forEach(function(e) {
            !_.genVendorsConsent[e.VendorCustomId] || _.softOptInGenVendors.includes(e.VendorCustomId) && _o.isLandingPage() || n.push(e.VendorCustomId)
        });
        _.vsIsActiveAndOptOut && _.getVendorsInDomain().forEach(function(e) {
            _.vsConsent.get(e.CustomVendorServiceId) && n.push(e.CustomVendorServiceId)
        });
        var t = "," + P.arrToStr(n) + ",",
            o = this.includeAllActiveIABData();
        L.GoogleConsent.GCEnable && !b.otDataLayer.ignore && this.updateGCMTags(U(n, o)), L.MCMData && L.MCMData.Enabled && (this.updateMCMTags(U(n, o)), this.updateClarityTags(U(n, o))), this.updateACMTags(U(n, o)), window.OnetrustActiveGroups = t, window.OptanonActiveGroups = t, b.gcmUpdateCallback && b.gcmUpdateCallback(), b.otDataLayer.ignore || void 0 === this._window[b.otDataLayer.name] || this._window[b.otDataLayer.name].constructor !== Array ? !b.otDataLayer.ignore && b.otDataLayer.name && (this._window[b.otDataLayer.name] = [{
            event: "OneTrustLoaded",
            OnetrustActiveGroups: t
        }, {
            event: "OptanonLoaded",
            OptanonActiveGroups: t
        }]) : (this._window[b.otDataLayer.name].push({
            event: "OneTrustLoaded",
            OnetrustActiveGroups: t
        }), this._window[b.otDataLayer.name].push({
            event: "OptanonLoaded",
            OptanonActiveGroups: t
        })), this.dispatchEvents(e, n, t)
    }, En.prototype.includeAllActiveIABData = function() {
        try {
            for (var n = [], e = 0, t = ["purpose", "features", "specialFeatures", "specialPurposes"]; e < t.length; e++)(o => {
                var t, e = _.oneTrustIABConsent[o];
                "purpose" === o || "specialFeatures" === o ? e.forEach(function(e) {
                    var t = "purpose" === o ? "IAB2V2" : "ISF2V2",
                        e = e.split(":");
                    "true" === e[1] && n.push(t + "_" + e[0])
                }) : (t = [], e.forEach(function(e) {
                    e.value && t.push(e.groupId.toString())
                }), n = U(n, t))
            })(t[e]);
            return n
        } catch (e) {
            return []
        }
    }, En.prototype.dispatchEvents = function(e, t, o) {
        !e && b.gtmUpdatedinStub || (n = new CustomEvent("consent.onetrust", {
            detail: t
        }));
        var n, r, i = T.readCookieParam(y.OPTANON_CONSENT, "groups"),
            s = _.fireOnetrustGrp || !i || e || !b.gtmUpdatedinStub;
        s && (_.fireOnetrustGrp = !1, !b.otDataLayer.ignore && this._window[b.otDataLayer.name] && this._window[b.otDataLayer.name].constructor === Array && this._window[b.otDataLayer.name].push({
            event: "OneTrustGroupsUpdated",
            OnetrustActiveGroups: o
        }), r = new CustomEvent("OneTrustGroupsUpdated", {
            detail: t
        })), setTimeout(function() {
            n && s && window.dispatchEvent(n), r && window.dispatchEvent(r)
        })
    }, En.prototype.isCategoryMapped = function(e) {
        return e !== gt && "" !== e
    }, En.prototype.updateGCMTags = function(o) {
        var n, r = this,
            i = {},
            e = (this.canUpdateGCMCategories() && (e = [
                [L.GoogleConsent.GCAdStorage, Ie.ad_storage],
                [L.GoogleConsent.GCAnalyticsStorage, Ie.analytics_storage],
                [L.GoogleConsent.GCFunctionalityStorage, Ie.functionality_storage],
                [L.GoogleConsent.GCPersonalizationStorage, Ie.personalization_storage],
                [L.GoogleConsent.GCSecurityStorage, Ie.security_storage]
            ], S.fp.CookieV2GCMDMA && (e.push([L.GoogleConsent.GCAdUserData, Ie.ad_user_data]), e.push([L.GoogleConsent.GCAdPersonalization, Ie.ad_personalization])), e.forEach(function(e) {
                var t;
                r.isCategoryMapped(e[0]) && (t = o.includes(e[0]) ? be.granted : be.denied, i[e[1]] = t)
            })), T.getCookie(y.ALERT_BOX_CLOSED)),
            t = b.getRegionRule().Global;
        "function" != typeof window.gtag && (n = this._window, window.gtag = function(e, t, o) {
            b.otDataLayer.ignore || (n[b.otDataLayer.name] ? n[b.otDataLayer.name].push(arguments) : n[b.otDataLayer.name] = [arguments])
        }), "function" == typeof window.gtag && (b.gcmDevIdSet || (window.gtag(Ae.set, "developer_id.dYWJhMj", !0), b.gcmDevIdSet = !0), e) && (t || (i[Ie.region] = b.gcmCountries), 0 !== Object.keys(i).length) && window.gtag(Ae.consent, ke.update, i)
    }, En.prototype.updateMCMTags = function(e) {
        for (var t = "uetq", o = {}, n = 0, r = Object.entries(L.MCMData.StorageTypes); n < r.length; n++) {
            var i = r[n],
                s = i[0],
                i = i[1];
            this.isCategoryMapped(i) && (i = e.includes(i) ? be.granted : be.denied, o[s] = i)
        }
        this._window[t] = this._window[t] || [], this._window[t].push("consent", "update", o)
    }, En.prototype.updateClarityTags = function(e) {
        var t = "clarity",
            o = {};
        try {
            if (L.MCMData && L.MCMData.Enabled) {
                for (var n, r = L.MCMData.StorageTypes || {}, i = 0, s = Object.entries(r); i < s.length; i++) {
                    var a, l = s[i],
                        c = l[0],
                        d = l[1];
                    this.isCategoryMapped(d) && (a = e.includes(d) ? be.granted : be.denied, o["analytics_storage" === c ? "analytics_Storage" : "ad_storage" === c ? "ad_Storage" : c] = a)
                }
                "function" != typeof this._window[t] && ((n = this._window)[t] = function() {
                    (n[t].q = n[t].q || []).push(arguments)
                }), Object.keys(o).length && this._window[t]("consentv2", o)
            }
        } catch (e) {
            console.error("Error updating Clarity tags:", e)
        }
    }, En.prototype.updateACMTags = function(e) {
        var t, o;
        L.ACMData && L.ACMData.Enabled && ((o = {}).countryCode = null == (t = _.userLocation) ? void 0 : t.country, this.setConsentOnMode(o, Pt, e), this.setConsentOnMode(o, Tt, e), this.pollForAmazonConsent(o))
    }, En.prototype.pollForAmazonConsent = function(e) {
        var t = this,
            o = 0,
            n = setInterval(function() {
                o++;
                try {
                    t._window.amznConsent && "function" == typeof t._window.amznConsent ? (t._window.amznConsent().setCountryCode(e.countryCode).setEnableAdStorage(e[Tt]).setEnableUserData(e[Pt]).build(), clearInterval(n)) : 50 <= o && (clearInterval(n), console.warn("OneTrust: Amazon Consent JS not available after timeout. ACM consent not set."))
                } catch (e) {
                    clearInterval(n), console.warn("OneTrust: Error setting Amazon Consent. ACM consent not set.", e)
                }
            }, 100)
    }, En.prototype.setConsentOnMode = function(e, t, o) {
        var n = L.ACMData.StorageTypes[t],
            o = !(!this.isCategoryMapped(n) || !o.includes(n));
        e[t] = o
    }, En.prototype.canUpdateGCMCategories = function() {
        return L.GoogleConsent.GCAdStorage !== gt || L.GoogleConsent.GCAnalyticsStorage !== gt || L.GoogleConsent.GCFunctionalityStorage !== gt || L.GoogleConsent.GCPersonalizationStorage !== gt || L.GoogleConsent.GCSecurityStorage !== gt || L.GoogleConsent.GCAdUserData !== gt || L.GoogleConsent.GCAdPersonalization !== gt
    }, En.prototype.checkAndWarnGCMConfig = function() {
        var e = 0,
            t = 0,
            o = 0,
            n = 0;
        if (L.GoogleConsent.GCEnable && !b.otDataLayer.ignore) {
            for (var r = this._window[b.otDataLayer.name], i = 0, s = Object.keys(r); i < s.length; i++) {
                var a = s[i];
                n++, this.isObjectTypeArgs(r[a]) && ("consent" === r[a][0] && "default" === r[a][1] ? t = n : "consent" === r[a][0] && "update" === r[a][1] ? o = n : 0 === e && "config" === r[a][0] && this.isGoogleTag(r[a][1]) && (e = n))
            }
            this.addGCMConfigStatus(e, t, o)
        }
    }, En.prototype.addGCMConfigStatus = function(e, t, o) {
        0 !== e && (e < t ? console.warn("Google Consent mode default value is set after the Google tags were loaded.") : 0 === t ? console.warn("Google Consent mode default or consent value has not been set but the Google tags were loaded.") : (t < e || o < e) && console.info("Google Consent mode is properly configured."))
    }, En.prototype.isGoogleTag = function(e) {
        return e && (-1 < e.indexOf("GT-") || -1 < e.indexOf("G-") || -1 < e.indexOf("AW-"))
    }, En.prototype.isObjectTypeArgs = function(e) {
        return "[object Arguments]" === Object.prototype.toString.call(e)
    };
    var Ln, _n = En;

    function En() {
        this._window = window
    }
    Vn.prototype.updateFilterSelection = function(e) {
        o = (e = void 0 === e ? !1 : e) ? (t = _.filterByCategories, "data-optanongroupid") : (t = _.filterByIABCategories, "data-purposeid");
        for (var t, o, n = v("#onetrust-pc-sdk .category-filter-handler").el, r = 0; r < n.length; r++) {
            var i = n[r].getAttribute(o),
                i = -1 < t.indexOf(i);
            P.setCheckedAttribute(null, n[r], i)
        }
    }, Vn.prototype.cancelHostFilter = function() {
        for (var e = v("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o = e[t].getAttribute("data-optanongroupid"),
                o = 0 <= _.filterByCategories.indexOf(o);
            P.setCheckedAttribute(null, e[t], o)
        }
    }, Vn.prototype.updateHostFilterList = function() {
        for (var e = v("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o, n = e[t].getAttribute("data-optanongroupid");
            e[t].checked && _.filterByCategories.indexOf(n) < 0 ? _.filterByCategories.push(n) : !e[t].checked && -1 < _.filterByCategories.indexOf(n) && (o = _.filterByCategories, _.filterByCategories.splice(o.indexOf(n), 1))
        }
        return _.filterByCategories
    }, Vn.prototype.InitializeHostList = function() {
        var e = A.P_Vendor_List + " " + A.P_Host_Cntr + " li";
        _.hosts.hostTemplate = v(e).el[0].cloneNode(!0), _.hosts.hostCookieTemplate = v(A.P_Vendor_List + " " + A.P_Host_Cntr + " " + A.P_Host_Opt + " li").el[0].cloneNode(!0)
    }, Vn.prototype.getCookiesForGroup = function(t) {
        var o = [],
            n = [];
        return t.FirstPartyCookies.length && t.FirstPartyCookies.forEach(function(e) {
            n.push(R(R({}, e), {
                groupName: t.GroupName
            }))
        }), t.Hosts.length && t.Hosts.forEach(function(e) {
            o.push(R(R({}, e), {
                isActive: "always active" === D.getGrpStatus(t).toLowerCase(),
                groupName: t.GroupName,
                Type: he.Host
            }))
        }), {
            firstPartyCookiesList: n,
            thirdPartyCookiesList: o
        }
    }, Vn.prototype.reactivateSrcTag = function(e) {
        var t = ["src"];
        e.setAttribute(t[0], e.getAttribute("data-" + t[0])), e.removeAttribute("data-src")
    }, Vn.prototype.reactivateScriptTag = function(e) {
        var t = e.parentNode,
            o = document.createElement(e.tagName),
            n = (o.innerHTML = m.getInnerHtmlContent(m.getInnerHtmlContent(e.innerHTML)), e.attributes);
        if (0 < n.length)
            for (var r = 0; r < n.length; r++) "type" !== n[r].name ? o.setAttribute(n[r].name, n[r].value, !0) : o.setAttribute("type", "text/javascript", !0);
        t.appendChild(o), t.removeChild(e)
    }, Vn.prototype.reactivateTag = function(e, t) {
        var o, n = 0 <= e.className.indexOf("ot-vscat"),
            r = 0 <= e.className.indexOf("optanon-category"),
            i = (n && r ? o = this.getGroupElements(e.className, _.showVendorService) : n ? _.showVendorService ? o = this.getGroupElements(e.className, !0) : this.unBlockTag(t, e) : r && (_.showVendorService ? this.unBlockTag(t, e) : o = this.getGroupElements(e.className, !1)), !0);
        if (o && 0 < o.length) {
            for (var s = 0; s < o.length; s++)
                if (!V.canInsertForGroup(o[s].trim())) {
                    i = !1;
                    break
                }
            i && this.unBlockTag(t, e)
        }
    }, Vn.prototype.unBlockTag = function(e, t) {
        e ? this.reactivateSrcTag(t) : this.reactivateScriptTag(t)
    }, Vn.prototype.getGroupElements = function(e, t) {
        return t ? null == (t = e.match(/ot-vscat(-[a-zA-Z0-9,]+)+/)) ? void 0 : t[0].split(/ot-vscat-/i)[1].split("-") : null == (t = e.match(/optanon-category(-[a-zA-Z0-9,]+)+/)) ? void 0 : t[0].split(/optanon-category-/i)[1].split("-")
    }, Vn.prototype.substitutePlainTextScriptTags = function() {
        var t = this,
            e = [].slice.call(document.querySelectorAll('script[class*="optanon-category"]')),
            o = [].slice.call(document.querySelectorAll('*[class*="optanon-category"]')),
            e = Array.from(new Set(e.concat([].slice.call(document.querySelectorAll('script[class*="ot-vscat"]') || [])))),
            o = Array.from(new Set(o.concat([].slice.call(document.querySelectorAll('*[class*="ot-vscat"]') || []))));
        Array.prototype.forEach.call(o, function(e) {
            "SCRIPT" !== e.tagName && e.hasAttribute("data-src") && t.reactivateTag(e, !0)
        }), Array.prototype.forEach.call(e, function(e) {
            e.hasAttribute("type") && "text/plain" === e.getAttribute("type") && t.reactivateTag(e, !1)
        })
    };
    var On, Dn = Vn;

    function Vn() {}
    var wn, Nn = "Banner",
        Bn = "Preference Center",
        Gn = "API",
        xn = "Close",
        Hn = "Allow All",
        Rn = "Reject All",
        Fn = "Confirm",
        Mn = "Confirm",
        Un = "Continue without Accepting",
        qn = (jn.prototype.init = function() {
            this.insertHtml(), this.insertCss(), this.showNty(), this.initHandler()
        }, jn.prototype.getContent = function() {
            return F(this, void 0, void 0, function() {
                return M(this, function(e) {
                    return [2, Kt.getSyncNtfyContent().then(function(e) {
                        l.syncNtfyGrp = {
                            name: e.name,
                            html: atob(e.html),
                            css: e.css
                        }
                    })]
                })
            })
        }, jn.prototype.insertHtml = function() {
            this.removeHtml();

            function e(e) {
                return t.querySelector(e)
            }
            var t = document.createDocumentFragment(),
                o = document.createElement("div"),
                o = (v(o).html(l.syncNtfyGrp.html), o.querySelector(this.El)),
                n = (L.BannerRelativeFontSizesToggle && v(o).addClass("otRelFont"), L.useRTL && v(o).attr("dir", "rtl"), v(t).append(o), L.NtfyConfig),
                n = (this.initHtml("Sync", n.Sync, e, t.querySelector(this.El)), n.ShowCS ? v(e(".ot-pc-handler")).html(n.CSTxt) : (v(o).addClass("ot-hide-csbtn"), e(".ot-sync-btncntr").parentElement.removeChild(e(".ot-sync-btncntr"))), document.createElement("div"));
            v(n).append(t), v("#onetrust-consent-sdk").append(n.firstChild)
        }, jn.prototype.initHandler = function() {
            v(this.El + " .ot-sync-close-handler").on("click", function() {
                return wn.close()
            })
        }, jn.prototype.showNty = function() {
            var e = v(this.El);
            e.css("bottom: -300px;"), e.animate({
                bottom: "1em;"
            }, 1e3), setTimeout(function() {
                e.css("bottom: 1rem;")
            }, 1e3), e.focus()
        }, jn.prototype.changeState = function() {
            setTimeout(function() {
                wn.refreshState()
            }, 1500)
        }, jn.prototype.refreshState = function() {
            function e(e) {
                return t.querySelector(e)
            }
            var t = v(this.El).el[0],
                o = (t.classList.add("ot-nty-complete"), t.classList.remove("ot-nty-sync"), L.NtfyConfig);
            this.initHtml("Complete", o.Complete, e, t), o.ShowCS && ("LINK" === o.CSType && v(e(".ot-pc-handler")).addClass("ot-pc-link"), v(".ot-sync-btncntr").show("inline-block"), this.alignContent(), v(window).on("resize", function() {
                return wn.resizeEvent
            })), setTimeout(function() {
                wn.close()
            }, 1e3 * L.NtfyConfig.NtfyDuration)
        }, jn.prototype.insertCss = function() {
            var e = document.getElementById("onetrust-style");
            e.innerHTML = m.getInnerHtmlContent(e.innerHTML + l.syncNtfyGrp.css), e.innerHTML = m.getInnerHtmlContent(e.innerHTML + this.addCustomStyles())
        }, jn.prototype.addCustomStyles = function() {
            var e = L.NtfyConfig,
                t = e.Sync,
                o = e.Complete,
                n = e.CSButton,
                r = e.CSLink;
            return "\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync {\n            background-color: " + t.BgColor + ";\n            border: 1px solid " + t.BdrColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-sync-refresh>g {\n            fill: " + t.IconBgColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync #ot-sync-title {\n            text-align: " + t.TitleAlign + ";\n            color: " + t.TitleColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-sync .ot-sync-desc  {\n            text-align: " + t.DescAlign + ";\n            color: " + t.DescColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete {\n            background-color: " + o.BgColor + ";\n            border: 1px solid " + o.BdrColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-sync-check>g {\n            fill: " + o.IconBgColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete #ot-sync-title {\n            text-align: " + o.TitleAlign + ";\n            color: " + o.TitleColor + ";\n        }\n        #onetrust-consent-sdk #ot-sync-ntfy.ot-nty-complete .ot-sync-desc  {\n            text-align: " + o.DescAlign + ";\n            color: " + o.DescColor + ";\n        }\n        " + ("BUTTON" === e.CSType ? "\n        #onetrust-consent-sdk #ot-sync-ntfy .ot-pc-handler {\n            background-color: " + n.BgColor + ";\n            border: 1px solid " + n.BdrColor + ";\n            color: " + n.Color + ";\n            text-align: " + n.Align + ";\n        }" : " #onetrust-consent-sdk #ot-sync-ntfy .ot-pc-handler.ot-pc-link {\n            color: " + r.Color + ";\n            text-align: " + r.Align + ";\n        }") + "\n        "
        }, jn.prototype.initHtml = function(e, t, o, n) {
            var r = "Complete" === e ? ".ot-sync-refresh" : ".ot-sync-check";
            t.ShowIcon ? (v(o("Sync" === e ? ".ot-sync-refresh" : ".ot-sync-check")).show(), v(o(r)).hide(), v(o(".ot-sync-icon")).show("inline-block"), n.classList.remove("ot-hide-icon")) : (v(o(".ot-sync-icon")).hide(), n.classList.add("ot-hide-icon")), t.Title ? v(o("#ot-sync-title")).html(t.Title) : v(o("#ot-sync-title")).hide(), t.Desc ? v(o(".ot-sync-desc")).html(t.Desc) : v(o(".ot-sync-desc")).hide(), t.ShowClose ? (v(o(".ot-sync-close-handler")).show("inline-block"), v(o(".ot-close-icon")).attr("aria-label", t.CloseAria), n.classList.remove("ot-hide-close")) : (v(o(".ot-sync-close-handler")).hide(), n.classList.add("ot-hide-close"))
        }, jn.prototype.close = function() {
            this.hideSyncNtfy(), I.resetFocusToBody()
        }, jn.prototype.hideSyncNtfy = function() {
            L.NtfyConfig.ShowCS && window.removeEventListener("resize", wn.resizeEvent), v("#ot-sync-ntfy").fadeOut(400)
        }, jn.prototype.removeHtml = function() {
            var e = v(this.El).el;
            e && P.removeChild(e)
        }, jn.prototype.alignContent = function() {
            v(".ot-sync-btncntr").el[0].clientHeight > v(".ot-sync-titlecntr").el[0].clientHeight && (v(".ot-sync-titlecntr").addClass("ot-pos-abs"), v(".ot-sync-btncntr").addClass("ot-pos-rel"))
        }, jn.prototype.resizeEvent = function() {
            window.innerWidth <= 896 && wn.alignContent()
        }, jn);

    function jn() {
        this.El = "#ot-sync-ntfy"
    }
    Wn.prototype.toggleVendorConsent = function(e, t) {
        void 0 === t && (t = null), (e = (e = void 0 === e ? [] : e).length ? e : l.oneTrustIABConsent.vendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = v(A.P_Vendor_Container + " ." + A.P_Ven_Ctgl + ' [vendorid="' + t + '"]').el[0];
            t && P.setCheckedAttribute("", t, "true" === e)
        });
        var o, n = v("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0];
        n && (o = P.getActiveIdArray(P.distinctArray(e)), (t = null === t ? o.length === e.length : t) || 0 === o.length ? n.parentElement.classList.remove(Rt.P_Line_Through) : n.parentElement.classList.add(Rt.P_Line_Through), P.setCheckedAttribute("", n, t))
    }, Wn.prototype.toggleVendorLi = function(e, t) {
        void 0 === t && (t = null), (e = (e = void 0 === e ? [] : e).length ? e : l.oneTrustIABConsent.legIntVendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = v(A.P_Vendor_Container + " ." + A.P_Ven_Ltgl + ' [leg-vendorid="' + t + '"]').el[0];
            t && P.setCheckedAttribute("", t, "true" === e)
        });
        var o, n = v("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0];
        n && (o = P.getActiveIdArray(P.distinctArray(e)), (t = null === t ? o.length === e.length : t) || 0 === o.length ? n.parentElement.classList.remove(Rt.P_Line_Through) : n.parentElement.classList.add(Rt.P_Line_Through), P.setCheckedAttribute("", n, t))
    }, Wn.prototype.updateVendorLegBtns = function(e) {
        (e = (e = void 0 === e ? [] : e).length ? e : l.oneTrustIABConsent.legIntVendors).forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = e[1],
                t = v(A.P_Vendor_Container + ' .ot-leg-btn-container[data-group-id="' + t + '"]').el[0];
            t && V.updateLegIntBtnElement(t, "true" === e)
        })
    };
    var Kn, zn = Wn;

    function Wn() {}

    function Yn() {
        return (!b.isIab2orv2Template && L.PCTemplateUpgrade && L.PCCategoryStyle === ve.Toggle ? E.toggleEl : E.chkboxEl).cloneNode(!0)
    }
    Xn.prototype.setHtmlTemplate = function(e) {
        w.setInternalData(), w.rootHtml = e, w.cloneHtmlElements()
    }, Xn.prototype.getVendorListEle = function(e) {
        var t = document.createDocumentFragment(),
            o = document.createElement("div"),
            n = (o.classList.add("ot-vs-list"), L.VendorServiceConfig.PCVSExpandGroup);
        return e.forEach(function(e, t) {
            e = w.createVendor(e.groupRef, e, n, "ot-vs-lst-id-" + t);
            o.appendChild(e)
        }), t.appendChild(o), t
    }, Xn.prototype.insertVendorServiceHtml = function(e, t) {
        var o;
        w.checkIfIsInvalid(e, t) || (o = document.createDocumentFragment(), w.setVendorContainer(o, e), w.setVendorList(o, e), e.SubGroups && 0 < e.SubGroups.length ? (o.querySelector(this.MAIN_CONT_ELE).classList.add("ot-vnd-subgrp-cnt"), e = t.children[1], b.pcName === st && (e = t.children[2]), t.insertBefore(o, e)) : t.appendChild(o))
    }, Xn.prototype.toggleVendorService = function(e, t, o, n) {
        e = D.getGroupById(e), t = D.getVSById(t);
        n = n || w.getVendorInputElement(t.CustomVendorServiceId), w.setVendorServiceState(n, t, o), o ? w.changeGroupState(e, o, w.isToggle) : w.checkGroupChildrenState(e) || w.changeGroupState(e, !1, w.isToggle)
    }, Xn.prototype.setVendorStateByGroup = function(e, t) {
        e = e.VendorServices;
        if (l.showVendorService && e)
            for (var o = 0, n = e; o < n.length; o++) {
                var r = n[o],
                    i = w.getVendorInputElement(r.CustomVendorServiceId);
                w.setVendorServiceState(i, r, t)
            }
    }, Xn.prototype.resetVendorUIState = function(e) {
        e.forEach(function(e, t) {
            t = w.getVendorInputElement(t);
            w.changeVendorServiceUIState(t, e)
        })
    }, Xn.prototype.setVendorServiceState = function(e, t, o) {
        w.changeVendorServiceState(t, o), w.changeVendorServiceUIState(e, o);
        e = o ? an : ln;
        mo.triggerGoogleAnalyticsEvent(Bo, e, t.ServiceName + ": " + t.CustomVendorServiceId)
    }, Xn.prototype.removeVSUITemplate = function(e) {
        var t = e.querySelector(this.MAIN_CONT_ELE);
        t && e.removeChild(t)
    }, Xn.prototype.consentAll = function(o) {
        l.getVendorsInDomain().forEach(function(e) {
            var t = o;
            o || (t = D.isAlwaysActiveGroup(e.groupRef)), w.toggleVendorService(e.groupRef.CustomGroupId, e.CustomVendorServiceId, t || o)
        })
    }, Xn.prototype.cloneHtmlElements = function() {
        var e, t, o, n, r = w.rootHtml.querySelector(this.MAIN_CONT_ELE);
        r && (e = r.querySelector(".ot-vnd-serv-hdr-cntr"), n = (o = (t = r.querySelector(".ot-vnd-lst-cont")).querySelector(".ot-vnd-item")).querySelector(".ot-vnd-info"), w.vendorLabelContainerClone = e.cloneNode(!0), r.removeChild(e), w.vendorInfoClone = n.cloneNode(!0), o.querySelector(".ot-vnd-info-cntr").removeChild(n), w.vendorItemClone = o.cloneNode(!0), t.removeChild(o), w.vendorListContainerClone = t.cloneNode(!0), r.removeChild(t), w.vendorServMainContainerClone = r.cloneNode(!0), w.rootHtml.removeChild(r))
    }, Xn.prototype.setInternalData = function() {
        w.isToggle = L.PCCategoryStyle === ve.Toggle;
        var e = L.VendorServiceConfig;
        w.stringTranslation = new Map, w.stringTranslation.set("ServiceName", e.PCVSNameText || "ServiceName"), w.stringTranslation.set("ParentCompany", e.PCVSParentCompanyText || "ParentCompany"), w.stringTranslation.set("Address", e.PCVSAddressText || "Address"), w.stringTranslation.set("DefaultCategoryName", e.PCVSDefaultCategoryText || "DefaultCategoryName"), w.stringTranslation.set("Description", e.PCVSDefaultDescriptionText || "Description"), w.stringTranslation.set("DPOEmail", e.PCVSDPOEmailText || "DPOEmail"), w.stringTranslation.set("DPOLink", e.PCVSDPOLinkText || "DPOLink"), w.stringTranslation.set("PrivacyPolicyLink", e.PCVSPrivacyPolicyLinkText || "PrivacyPolicyLink"), w.stringTranslation.set("CookiePolicyLink", e.PCVSCookiePolicyLinkText || "CookiePolicyLink"), w.stringTranslation.set("OptOutLink", e.PCVSOptOutLinkText || "OptOutLink"), w.stringTranslation.set("LegalBasis", e.PCVSLegalBasisText || "LegalBasis")
    }, Xn.prototype.setVendorContainer = function(e, t) {
        var o = w.vendorServMainContainerClone.cloneNode(!0),
            t = (o.setAttribute("data-group-id", t.CustomGroupId), w.vendorLabelContainerClone.cloneNode(!0));
        t.querySelector(".ot-vnd-serv-hdr").innerHTML = m.getInnerHtmlContent(L.VendorServiceConfig.PCVSListTitle), o.appendChild(t), e.appendChild(o)
    }, Xn.prototype.setVendorList = function(e, t) {
        for (var o = 0, n = w.getVSFromGroupAndSubgroups(t), r = n.length, e = e.querySelector(this.MAIN_CONT_ELE), i = w.vendorListContainerClone.cloneNode(), s = L.VendorServiceConfig.PCVSExpandCategory; o < r; o++) {
            var a = w.createVendor(t, n[o], s);
            i.appendChild(a)
        }
        e.appendChild(i)
    }, Xn.prototype.getVSFromGroupAndSubgroups = function(e, t) {
        var o, n = null != (o = e.VendorServices) ? o : [];
        if (t = void 0 === t ? !1 : t)
            for (var r = 0, i = null != (o = e.SubGroups) ? o : []; r < i.length; r++) {
                var s = null != (s = i[r].VendorServices) ? s : [];
                n.push.apply(n, s)
            }
        return n
    }, Xn.prototype.createVendor = function(e, t, o, n) {
        var r = w.vendorItemClone.cloneNode(!0),
            i = (r.setAttribute("data-vnd-id", t.CustomVendorServiceId), L.PCAccordionStyle === ce.NoAccordion ? (r.classList.remove("ot-accordion-layout"), (i = r.querySelector("button")) && r.removeChild(i)) : w.setExpandVendorList(r, o), w.setVendorHeader(e, t, r, n), r.querySelector(".ot-vnd-info-cntr"));
        return w.setVendorInfo(i, t), r
    }, Xn.prototype.setExpandVendorList = function(e, t) {
        e.querySelector("button").setAttribute("aria-expanded", "" + t)
    }, Xn.prototype.setVendorHeader = function(e, t, o, n) {
        var r = L.PCShowAlwaysActiveToggle,
            i = "always active" === D.getGrpStatus(e).toLowerCase(),
            o = o.querySelector(".ot-acc-hdr"),
            s = (i && o.classList.add("ot-always-active-group"), null),
            e = (i && L.PCCategoryStyle === ve.Toggle || (s = w.setHeaderInputStyle(e, t, i, n)), w.setHeaderText(t, o)),
            n = (o.appendChild(e), w.getPositionForElement(L.PCAccordionStyle, w.isToggle)),
            t = n.positionIcon;
        s && o.insertAdjacentElement(n.positionInput, s), i && r && (e = w.getAlwaysActiveElement(), o.insertAdjacentElement("beforeend", e)), L.PCAccordionStyle !== ce.NoAccordion && (n = w.setHeaderAccordionIcon(), o.insertAdjacentElement(t, n))
    }, Xn.prototype.getPositionForElement = function(e, t) {
        var o = "beforeend",
            n = "beforeend";
        return {
            positionIcon: o = t && e === ce.PlusMinus ? "afterbegin" : o,
            positionInput: n = t ? n : "afterbegin"
        }
    }, Xn.prototype.setHeaderAccordionIcon = function() {
        var e = (L.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0);
        return e
    }, Xn.prototype.setHeaderText = function(e, t) {
        var o = t.querySelector(".ot-cat-header"),
            n = o.cloneNode();
        return t.removeChild(o), n.innerText = e.ServiceName, n
    }, Xn.prototype.setHeaderInputStyle = function(e, t, o, n) {
        var r, i, s, a;
        return L.VendorServiceConfig.PCVSOptOut ? (e = D.checkIsActiveByDefault(e), r = !1, r = (i = l.vsConsent).has(t.CustomVendorServiceId) ? i.get(t.CustomVendorServiceId) : e, (i = Yn()).querySelector("input").classList.add("category-switch-handler"), e = i.querySelector("input"), a = t.CustomVendorServiceId, n = null != n ? n : "ot-vendor-id-" + a, s = "ot-vendor-header-id-" + a, v(e).attr("id", n), v(e).attr("name", n), v(e).attr("aria-labelledby", s), v(e).data("ot-vs-id", a), v(e).data("optanongroupid", t.groupRef.CustomGroupId), e.disabled = o, P.setCheckedAttribute(null, e, r), a = w.isToggle ? n : s, v(i.querySelector("label")).attr("for", a), v(i.querySelector(".ot-label-txt")).html(t.ServiceName), i) : null
    }, Xn.prototype.getAlwaysActiveElement = function() {
        var e = document.createElement("div");
        return e.classList.add("ot-always-active"), e.innerText = L.AlwaysActiveText, e
    }, Xn.prototype.setVendorInfo = function(e, t) {
        var o, n, r, i, s, a, l = ["DPOLink", "PrivacyPolicyLink", "CookiePolicyLink", "OptOutLink"];
        for (o in t) w.skipVendorInfoKey(o, t) || (n = t[o], (r = w.vendorInfoClone.cloneNode(!0)).dataset.vndInfoKey = o + "-" + t.CustomVendorServiceId, i = r.querySelector(".ot-vnd-lbl"), s = r.querySelector(".ot-vnd-cnt"), i.innerHTML = m.getInnerHtmlContent(w.getLocalizedString(o)), l.includes(o) ? (s.remove(), a = document.createElement("a"), v(a).attr("href", n), v(a).attr("target", "_blank"), v(a).attr("rel", "noopener"), v(a).attr("aria-label", n + " " + L.NewWinTxt), a.classList.add("ot-vnd-cnt"), a.innerText = n, i.insertAdjacentElement("afterend", a)) : s.innerHTML = m.getInnerHtmlContent(n), e.appendChild(r))
    }, Xn.prototype.skipVendorInfoKey = function(e, t) {
        return "VendorServiceId" === e || "DefaultCategoryId" === e || "ServiceName" === e || "groupRef" === e || "CustomVendorServiceId" === e || "PurposeId" === e || !t[e]
    }, Xn.prototype.getLocalizedString = function(e) {
        return w.stringTranslation.has(e) ? w.stringTranslation.get(e) : "DEFAULT"
    }, Xn.prototype.checkGroupChildrenState = function(e) {
        for (var t, o = 0, n = null != (t = e.SubGroups) ? t : []; o < n.length; o++) {
            var r = n[o];
            if (w.checkGroupChildrenState(r)) return !0
        }
        for (var i = 0, s = null != (t = e.VendorServices) ? t : []; i < s.length; i++) {
            var a = s[i];
            if (l.vsConsent.get(a.CustomVendorServiceId)) return !0
        }
        return !1
    }, Xn.prototype.changeVendorServiceState = function(e, t) {
        l.vsConsent.set(e.CustomVendorServiceId, t)
    }, Xn.prototype.changeVendorServiceUIState = function(e, t) {
        e && P.setCheckedAttribute(null, e, t)
    }, Xn.prototype.changeGroupState = function(e, t, o) {
        var n = D.getParentByGrp(e);
        V.toggleGrpStatus(e, t), w.updateGroupUIState(e.CustomGroupId, t, o, null !== n), n && (e = w.checkGroupChildrenState(n), w.changeGroupState(n, e, o))
    }, Xn.prototype.updateGroupUIState = function(e, t, o, n) {
        void 0 === n && (n = !1);
        n = document.querySelector((n ? "#ot-sub-group-id-" : "#ot-group-id-") + e);
        n && P.setCheckedAttribute(null, n, t)
    }, Xn.prototype.getVendorInputElement = function(e) {
        return document.getElementById("ot-vendor-id-" + e)
    }, Xn.prototype.checkIfIsInvalid = function(e, t) {
        return !e || !e.VendorServices || !t || e.VendorServices.length <= 0
    };
    var w, Jn = Xn;

    function Xn() {
        this.MAIN_CONT_ELE = ".ot-vnd-serv"
    }

    function Qn(e, t) {
        var o, n, r = "otGenericBackdrop",
            i = "#" + r,
            s = "ot-generic-modal-layer";

        function a(e) {
            e ? (v(i).removeClass("ot-hide"), v(i).el[0].removeAttribute("style")) : (v(i).fadeOut(400), v(i).addClass("ot-hide"))
        }
        return (o = document.createElement("div")).classList.add(s), (n = document.createElement("div")).setAttribute("id", r), n.classList.add("onetrust-pc-dark-filter"), o.appendChild(n), (r = document.createElement("div")).classList.add("ot-general-modal"), r.setAttribute("id", null != e ? e : "genericModal"), o.appendChild(r), n = "#onetrust-consent-sdk .ot-general-modal { background-color: " + L.pcBackgroundColor + ";}", (e = document.getElementById("onetrust-style")).textContent = e.textContent + n, {
            dialogLayerHtml: o,
            modalHtml: r,
            closeModalHandler: function() {
                a(!1);
                var e = t.querySelector("." + s);
                t.removeChild(e)
            },
            openModalHandler: function() {
                a(!0)
            }
        }
    }
    $n.getInstance = function() {
        return $n.instance = $n.instance ? $n.instance : new $n
    }, $n.prototype.getHealthSignatureUIIfNeeded = function(e) {
        if ((void 0 === e && (e = !1), b.requireSignatureEnabled) && (this.healthSignatureGroup = L.Groups.find(function(e) {
                return e.needsHealthSignature
            }), this.healthSignatureGroup))
            if (b.healthSignatureGroup || e)
                if (b.healthSignatureData) this.setSignHealthDataIntoCookieGroup(b.healthSignatureData);
                else {
                    var t = V.isGroupActive(this.healthSignatureGroup),
                        o = "1" === T.readCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION);
                    if (!(e && t && o)) return this.showHealthSignatureModal(function() {}), this.healthSignatureElement
                }
        else(t = V.isGroupActive(this.healthSignatureGroup)) && kr.setDataSubjectIdV2(b.healthSignatureData), T.writeCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION, t ? "1" : "");
        return null
    }, $n.prototype.checkIfHealthSignatureNeeded = function(e) {
        var t, o, n = this;
        return void 0 === e && (e = !1), !b.requireSignatureEnabled || l.bannerCloseSource === ee.RejectAll || l.bannerCloseSource === ee.BannerCloseButton || l.bannerCloseSource === ee.ContinueWithoutAcceptingButton ? Promise.resolve() : (this.healthSignatureGroup = L.Groups.find(function(e) {
            return e.needsHealthSignature
        }), this.healthSignatureGroup ? (e = e || this.getGroupToggleHtmlValue()) ? b.healthSignatureData ? (this.setSignHealthDataIntoCookieGroup(b.healthSignatureData), Promise.resolve()) : (t = V.isGroupActive(this.healthSignatureGroup), o = "1" === T.readCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION), e && t && o ? Promise.resolve() : new Promise(function(e) {
            n.showHealthSignatureModal(e)
        })) : ((t = V.isGroupActive(this.healthSignatureGroup)) && kr.setDataSubjectIdV2(b.healthSignatureData), T.writeCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION, t ? "1" : ""), Promise.resolve()) : (e = "🛑 INVALID Cookie category: " + L.RequireSignatureCID, Promise.reject(e)))
    }, $n.prototype.getHealthSignatureComponent = function(e, t) {
        this.isModal = !1, this.langJson = L, this.parentElement = e, this.healthSignatureGroup = t;
        e = {
            errorMessage: this.langJson.PCRequireSignatureHelpText,
            inputLabelText: this.langJson.PCRequireSignatureFieldLabel
        }, t = '<form class="ot-signature-health-form" id="form">\n        <div class="ot-input-field-cont">\n            <label for="otHealthSignatureData" class="ot-signature-label">' + e.inputLabelText + '</label>\n            <input type="text" id="otHealthSignatureData" name="otHealthSignatureData" required aria-required="true" class="ot-signature-input"\n                aria-label="' + e.inputLabelText + '" autofocus aria-invalid="true" aria-describedby="otHealthSignatureErrorMesg"/>\n            <span id="otHealthSignatureErrorMesg" class="ot-health-signature-error">\n                ' + e.errorMessage + "\n            </span>\n        </div>\n    </form>", e = document.createElement("div");
        e.innerHTML = m.getInnerHtmlContent(t), e.classList.add("ot-signature-health-group"), this.setConsentIdInput(e), this.healthSignatureElement = e, this.parentElement.appendChild(e), this.addEventHandlers()
    }, $n.prototype.resetHealthSignatureData = function(e) {
        void 0 === e && (e = !1), b.requireSignatureEnabled && (b.healthSignatureData = "", b.healthSignatureGroup = null, e) && T.writeCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION, "")
    }, $n.prototype.setConsentIdInPC = function() {
        this.setConsentIdInput(null)
    }, $n.prototype.setConsentIdInput = function(e) {
        var t;
        this.healthSignatureGroup && (T.readCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION) ? (t = (e || document).querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR)) && (e = "", V.isGroupActive(this.healthSignatureGroup) && (e = T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID)), t.value = e) : (t = document.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR)) && (t.value = ""))
    }, $n.prototype.showHealthSignatureModal = function(t) {
        var o = this;
        kn.hideConsentNoticeV2(), this.langJson = L, this.parentElement = document.querySelector(this.PARENT_SELECTOR), this.setMyHealthDataModal(function(e) {
            o.setSignHealthDataIntoCookieGroup(e), t()
        }, function() {
            V.toggleGrpStatus(o.healthSignatureGroup, !1), V.toggleGroupHtmlElement(o.healthSignatureGroup, o.healthSignatureGroup.CustomGroupId, !1), t()
        })
    }, $n.prototype.setMyHealthDataModal = function(e, t) {
        this.isModal = !0, this.rejectCallback = t, this.confirmCallback = e, this.configOptions = {
            mainTitle: this.healthSignatureGroup.GroupName,
            description: this.healthSignatureGroup.GroupDescription,
            subtitle: this.langJson.PCRequireSignatureHeaderText,
            ariaLabel: this.langJson.PCRequireSignatureHeaderDesc,
            errorMessage: this.langJson.PCRequireSignatureHelpText,
            subDescription: this.langJson.PCRequireSignatureHeaderDesc,
            inputLabelText: this.langJson.PCRequireSignatureFieldLabel,
            rejectButtonText: this.langJson.PCRequireSignatureRejectBtnText,
            acceptButtonText: this.langJson.PCRequireSignatureConfirmBtnText
        };
        t = document.createDocumentFragment(), e = this.createModal(t);
        this.healthSignatureElement = this.createHealtSignatureForm(e), this.parentElement.appendChild(t), this.setFocusOnInput(), this.addEventHandlers(), this.genericModal.openModalHandler()
    }, $n.prototype.setSignHealthDataIntoCookieGroup = function(e) {
        e ? (kr.setDataSubjectIdV2(e), b.healthSignatureData = e, V.toggleGrpStatus(this.healthSignatureGroup, !0)) : (b.healthSignatureData = "", V.toggleGrpStatus(this.healthSignatureGroup, !1)), T.writeCookieParam(y.OPTANON_CONSENT, h.HEALTH_SIGNATURE_AUTHORIZATION, e ? "1" : "")
    }, $n.prototype.createModal = function(e) {
        return this.genericModal = Qn(this.MODAL_ID, this.parentElement), e.appendChild(this.genericModal.dialogLayerHtml), this.genericModal.modalHtml
    }, $n.prototype.createHealtSignatureForm = function(e) {
        t = this.configOptions, o = !0 === (null == (o = S.moduleInitializer) ? void 0 : o.SEOOptimization);
        var t, o = '<div\n        class="ot-signature-health"\n        role="dialog"\n        aria-label="' + t.ariaLabel + '"\n        aria-describedby="otSignatureGroupDesc">\n        <section class="ot-signature-cont">\n            ' + (o ? '<p id="otSignatureSubtitle" class="ot-signature-subtitle" role="heading" aria-level="4">' + t.subtitle + "</p>" : '<h4 id="otSignatureSubtitle" class="ot-signature-subtitle">' + t.subtitle + "</h4>") + '\n            <p class="ot-signature-paragraph">' + t.subDescription + '</p>\n        </section>\n        <section class="ot-signature-cont">\n            ' + (o ? '<p id="otSignatureGroupTitle" class="ot-signature-group-title" role="heading" aria-level="5">' + t.mainTitle + "</p>" : '<h5 id="otSignatureGroupTitle" class="ot-signature-group-title">' + t.mainTitle + "</h5>") + '\n            <p id="otSignatureGroupDesc" class="ot-signature-paragraph">' + t.description + '</p>\n        </section>\n        <form class="ot-signature-health-form" id="form">\n            <label for="otHealthSignatureData" class="ot-signature-label">' + t.inputLabelText + '</label>\n            <input type="text" id="otHealthSignatureData" name="otHealthSignatureData" required aria-required="true" class="ot-signature-input"\n                aria-label="' + t.inputLabelText + '" autofocus aria-invalid="true" aria-describedby="otHealthSignatureErrorMesg"/>\n            <span id="otHealthSignatureErrorMesg" class="ot-health-signature-error" aria-live="assertive">\n                ' + t.errorMessage + '\n            </span>\n        </form>\n        <div class="ot-signature-buttons-cont">\n            <button class="ot-signature-button reject">' + t.rejectButtonText + '</button>\n            <button class="ot-signature-button accept">' + t.acceptButtonText + "</button>\n        </div>\n    </div>";
        return e.innerHTML = m.getInnerHtmlContent(o), this.setConsentIdInput(e), this.addStyles(), e.querySelector(".ot-signature-health")
    }, $n.prototype.addEventHandlers = function() {
        this.isModal ? (this.parentElement.querySelector(this.REJECT_SELECTOR).addEventListener("click", this.rejectListener.bind(this)), this.parentElement.querySelector(this.CONFIRM_SELECTOR).addEventListener("click", this.confirmListener.bind(this))) : this.parentElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).addEventListener("keyup", this.healthSignatureInputChanged.bind(this))
    }, $n.prototype.removeModal = function() {
        this.removeEventHandlers(), this.genericModal.closeModalHandler()
    }, $n.prototype.removeEventHandlers = function() {
        this.isModal ? (this.parentElement.querySelector(this.REJECT_SELECTOR).removeEventListener("click", this.rejectListener), this.parentElement.querySelector(this.CONFIRM_SELECTOR).removeEventListener("click", this.confirmListener)) : this.parentElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).removeEventListener("keyup", this.healthSignatureInputChanged)
    }, $n.prototype.rejectListener = function() {
        this.removeModal(), this.rejectCallback && this.rejectCallback()
    }, $n.prototype.confirmListener = function() {
        var e = this.healthSignatureElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).value;
        e && (this.removeModal(), this.confirmCallback(e))
    }, $n.prototype.healthSignatureInputChanged = function(e) {
        b.healthSignatureData = e.target.value
    }, $n.prototype.setFocusOnInput = function() {
        this.healthSignatureElement.querySelector(this.HEALTH_SIGNATURE_INPUT_SELECTOR).focus()
    }, $n.prototype.addStyles = function() {
        var e = "",
            t = (e = (e = (e += this.setParagraphStyles()) + this.setAcceptButtonsStyles()) + this.setRejectButtonsStyles(), document.getElementById("onetrust-style"));
        t.textContent = t.textContent + e
    }, $n.prototype.setRejectButtonsStyles = function() {
        return "#onetrust-consent-sdk .ot-signature-health " + this.REJECT_SELECTOR + " {\n            color: " + L.bannerMPButtonTextColor + ";\n            border-color: " + L.bannerMPButtonTextColor + ";\n            background-color: " + L.bannerMPButtonColor + ";\n        }"
    }, $n.prototype.setAcceptButtonsStyles = function() {
        return "#onetrust-consent-sdk .ot-signature-health " + this.CONFIRM_SELECTOR + " {\n            color: " + L.buttonTextColor + ";\n            border-color: " + L.buttonColor + ";\n            background-color: " + L.buttonColor + ";\n        }"
    }, $n.prototype.setParagraphStyles = function() {
        return this.HEALTH_SIGNATURE_PARAGRAPH_SELECTOR + " {\n            color: " + L.textColor + ";\n        }"
    }, $n.prototype.getGroupToggleHtmlValue = function() {
        var e = this.healthSignatureGroup.CustomGroupId,
            e = document.querySelector("input#ot-group-id-" + e + ", input#ot-bnr-hdr-id-" + e + ", input#ot-bnr-grp-id-" + e);
        return !!e && !0 === e.checked
    };
    var Zn = $n;

    function $n() {
        this.MODAL_ID = "healthSignatureDataModal", this.PARENT_SELECTOR = "#onetrust-consent-sdk", this.REJECT_SELECTOR = ".ot-signature-button.reject", this.CONFIRM_SELECTOR = ".ot-signature-button.accept", this.HEALTH_SIGNATURE_INPUT_SELECTOR = "#otHealthSignatureData", this.HEALTH_SIGNATURE_PARAGRAPH_SELECTOR = "p.ot-signature-paragraph"
    }
    tr.prototype.updateDataSubjectTimestamp = function() {
        var e = O.alertBoxCloseDate(),
            e = e && I.getUTCFormattedDate(e);
        v(".ot-userid-timestamp").html(L.PCenterUserIdTimestampTitleText + ": " + e)
    }, tr.prototype.closeBanner = function(e, t) {
        var o = this;
        void 0 === t && (t = !1), e ? !t && I.shouldShowDoubleOptInSignal(!0) ? I.createDoubleOptInConfirmDialog(!1, function() {
            o.closeOptanonAlertBox(), o.allowAll(!1)
        }, function() {
            L.OnClickCloseBanner && document.body.addEventListener("click", C.bodyClickEvent), L.ScrollCloseBanner && window.addEventListener("scroll", C.scrollCloseBanner)
        }) : (this.closeOptanonAlertBox(), this.allowAll(!1)) : (this.checkImplicitConsentWhenBannerIsClosed(!1), this.closeOptanonAlertBox(), this.close(!1))
    }, tr.prototype.allowAll = function(e, t) {
        void 0 === t && (t = !1), S.moduleInitializer.MobileSDK ? window.OneTrust.AllowAll() : this.AllowAllV2(e, t)
    }, tr.prototype.bannerActionsHandler = function(t, n, e) {
        var r = this,
            i = (void 0 === e && (e = !1), _o.setLandingPathParam(h.NOT_LANDING_PAGE), _.groupsConsent = [], _.hostsConsent = [], _.genVendorsConsent = {}, {});
        L.Groups.forEach(function(e) {
            if (e.IsAboutGroup) return !1;
            U(e.SubGroups, [e]).forEach(function(e) {
                var o = r.getGroupStatus(t, n, e);
                r.setGroupConsent(o, e), e.Hosts.length && I.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    var t;
                    i[e.HostId] ? Do.updateHostStatus(e, o) : (i[e.HostId] = !0, t = Do.isHostPartOfAlwaysActiveGroup(e.HostId), _.hostsConsent.push(e.HostId + ":" + (t || o ? "1" : "0")))
                }), _.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    Io.updateGenVendorStatus(e, o)
                })
            })
        }), L.IsIabEnabled && (t ? this.iab.allowAllhandler() : this.iab.rejectAllHandler(e)), gn.removeAddedOTCssStyles(), kn.hideConsentNoticeV2(), Po.writeGrpParam(y.OPTANON_CONSENT), Po.writeHstParam(y.OPTANON_CONSENT), _.genVenOptOutEnabled && Po.writeGenVenCookieParam(y.OPTANON_CONSENT), _.vsIsActiveAndOptOut && Po.writeVSConsentCookieParam(y.OPTANON_CONSENT), On.substitutePlainTextScriptTags(), Ln.updateGtmMacros(), this.executeOptanonWrapper(), null != (e = null == (e = S) ? void 0 : e.moduleInitializer) && e.BannerRefreshAfterCallToActionEnabled && this.reloadPage()
    }, tr.prototype.getGroupStatus = function(e, t, o) {
        return e ? o.Status.toLowerCase() !== f.ALWAYS_INACTIVE : !!t && D.isAlwaysActiveGroup(o)
    }, tr.prototype.setGroupConsent = function(e, t) {
        var o; - 1 < Et.indexOf(t.Type) && (o = "", o = b.requireSignatureEnabled && t.needsHealthSignature ? b.healthSignatureData ? "1" : "0" : e && t.HasConsentOptOut ? "1" : "0", _.groupsConsent.push(t.CustomGroupId + ":" + o))
    }, tr.prototype.nextPageCloseBanner = function() {
        _o.isLandingPage() || O.isAlertBoxClosedAndValid() || this.closeBanner(L.NextPageAcceptAllCookies, !0)
    }, tr.prototype.rmScrollAndClickBodyEvents = function() {
        L.ScrollCloseBanner && window.removeEventListener("scroll", this.scrollCloseBanner), L.OnClickCloseBanner && document.body.removeEventListener("click", this.bodyClickEvent)
    }, tr.prototype.onClickCloseBanner = function(e) {
        O.isAlertBoxClosedAndValid() || (mo.triggerGoogleAnalyticsEvent(Bo, Go), this.closeBanner(L.OnClickAcceptAllCookies)), C.rmScrollAndClickBodyEvents()
    }, tr.prototype.scrollCloseBanner = function() {
        var e = v(document).height() - v(window).height(),
            e = (0 === e && (e = v(window).height()), 100 * v(window).scrollTop() / e);
        25 < (e = e <= 0 ? 100 * (document.scrollingElement && document.scrollingElement.scrollTop || document.documentElement && document.documentElement.scrollTop || document.body && document.body.scrollTop) / (document.scrollingElement && document.scrollingElement.scrollHeight || document.documentElement && document.documentElement.scrollHeight || document.body && document.body.scrollHeight) : e) && !O.isAlertBoxClosedAndValid() && (!_.isPCVisible || L.NoBanner) ? (mo.triggerGoogleAnalyticsEvent(Bo, Go), C.closeBanner(L.ScrollAcceptAllCookies), C.rmScrollAndClickBodyEvents()) : O.isAlertBoxClosedAndValid() && C.rmScrollAndClickBodyEvents()
    }, tr.prototype.AllowAllV2 = function(e, t) {
        void 0 === t && (t = !1);
        for (var o = this.groupsClass.getAllGroupElements(), n = 0; n < o.length; n++) {
            var r = D.getGroupById(o[n].getAttribute("data-optanongroupid"));
            b.requireSignatureEnabled && r.needsHealthSignature ? this.groupsClass.toggleGrpElements(o[n], r, !!b.healthSignatureData) : (this.groupsClass.toggleGrpElements(o[n], r, !0), this.groupsClass.toogleSubGroupElement(o[n], !0, !1, !0), this.groupsClass.toogleSubGroupElement(o[n], !0, !0, !0))
        }
        _.showVendorService && w.consentAll(!0), this.bannerActionsHandler(!0, !1), this.consentTransactions(e, !0, t), L.IsIabEnabled && (this.iab.updateIabVariableReference(), this.iab.updateVendorsDOMToggleStatus(!0), this.updateVendorLegBtns(!0))
    }, tr.prototype.rejectAll = function(e, t) {
        for (var o, n, r = (t = void 0 === t ? !1 : t) ? Ce[5] : Ce[2], i = this.groupsClass.getAllGroupElements(), s = null != (o = null == (o = S) ? void 0 : o.fp) && o.CookieV2RejectAll ? (n = this.initializeObjectToLIRejectAll(t), this.initializeAllowLIRejectAll(t)) : !(n = !0), a = 0; a < i.length; a++) {
            var l = D.getGroupById(i[a].getAttribute("data-optanongroupid"));
            "always active" !== D.getGrpStatus(l).toLowerCase() && (V.toggleGrpElements(i[a], l, !1, s), this.groupsClass.toogleSubGroupElement(i[a], !1, !1, !0), L.IsIabEnabled && (L.IsIabEnabled, !n) || this.groupsClass.toogleSubGroupElement(i[a], !1, !0, !0))
        }
        _.showVendorService && w.consentAll(!1), this.bannerActionsHandler(!1, !0, s), r !== _.consentInteractionType && this.consentTransactions(e, !1, t), L.IsIabEnabled && (this.iab.updateIabVariableReference(), this.iab.updateVendorsDOMToggleStatus(!1, s), s || this.updateVendorLegBtns(!1))
    }, tr.prototype.initializeObjectToLIRejectAll = function(e) {
        return !e && L.BannerShowRejectAllButton && L.BRejectConsentType === Le.OBJECT_TO_LI || e && L.PCenterShowRejectAllButton && L.BRejectConsentType === Le.OBJECT_TO_LI
    }, tr.prototype.initializeAllowLIRejectAll = function(e) {
        return L.IsIabEnabled && (!e && L.BannerShowRejectAllButton && L.BRejectConsentType === Le.LI_ACTIVE_IF_LEGAL_BASIS || e && L.PCenterShowRejectAllButton && L.BRejectConsentType === Le.LI_ACTIVE_IF_LEGAL_BASIS)
    }, tr.prototype.updateConsentData = function(e) {
        _o.setLandingPathParam(h.NOT_LANDING_PAGE), L.IsIabEnabled && !e && this.iab.saveVendorStatus(), Po.writeGrpParam(y.OPTANON_CONSENT), Po.writeHstParam(y.OPTANON_CONSENT), _.showGeneralVendors && L.GenVenOptOut && Po.writeGenVenCookieParam(y.OPTANON_CONSENT), _.vsIsActiveAndOptOut && Po.writeVSConsentCookieParam(y.OPTANON_CONSENT), On.substitutePlainTextScriptTags(), Ln.updateGtmMacros()
    }, tr.prototype.close = function(e, t) {
        var o;
        void 0 === t && (t = te.Banner), kn.hideConsentNoticeV2(), this.updateConsentData(e), L.IsConsentLoggingEnabled ? (o = t === te.PC ? Fn : t === te.Banner ? xn : b.apiSource, e = t === te.PC ? Bn : t === te.Banner ? Nn : Gn, _.bannerCloseSource === ee.ContinueWithoutAcceptingButton && (o = Un), _.bannerCloseSource === ee.BannerSaveSettings && (o = Mn), Ns.createConsentTxn(!1, e + " - " + o, t === te.PC)) : O.dispatchConsentEvent(), this.executeOptanonWrapper(), null == (t = null == (e = S) ? void 0 : e.moduleInitializer) || !t.BannerRefreshAfterCallToActionEnabled || o !== Mn && o !== Fn || this.reloadPage()
    }, tr.prototype.reloadPage = function() {
        console.warn("Triggering Page Refresh"), setTimeout(function() {
            location.reload()
        }, 200)
    }, tr.prototype.executeOptanonWrapper = function() {
        try {
            if ("function" == typeof window.OptanonWrapper && "undefined" !== window.OptanonWrapper) {
                window.OptanonWrapper();
                for (var e = 0, t = _.srcExecGrpsTemp; e < t.length; e++) {
                    var o = t[e]; - 1 === _.srcExecGrps.indexOf(o) && _.srcExecGrps.push(o)
                }
                _.srcExecGrpsTemp = [];
                for (var n = 0, r = _.htmlExecGrpsTemp; n < r.length; n++) {
                    o = r[n]; - 1 === _.htmlExecGrps.indexOf(o) && _.htmlExecGrps.push(o)
                }
                _.htmlExecGrpsTemp = []
            }
        } catch (e) {
            console.warn("Error in Optanon wrapper, please review your code. " + e)
        }
    }, tr.prototype.updateVendorLegBtns = function(e) {
        if (b.legIntSettings.PAllowLI && b.legIntSettings.PShowLegIntBtn)
            for (var t = v(A.P_Vendor_Container + " .ot-leg-btn-container").el, o = 0; o < t.length; o++) this.groupsClass.updateLegIntBtnElement(t[o], e)
    }, tr.prototype.showFltgCkStgButton = function() {
        var e = v("#ot-sdk-btn-floating"),
            e = (e.removeClass("ot-hide"), e.removeClass("ot-pc-open"), L.cookiePersistentLogo.includes("ot_guard_logo.svg") && v(C.fltgFrontBtnSvg).attr(vt, ""), v(C.fltgBackBtnSvg).attr(vt, "true"), document.querySelector(C.fltgBtnBackBtn)),
            t = document.querySelector(C.fltgBtnFrontBtn);
        t && (t.setAttribute(vt, "false"), t.style.display = "block"), e && (e.setAttribute(vt, "true"), e.style.display = "none")
    }, tr.prototype.consentTransactions = function(e, t, o) {
        void 0 === o && (o = !1), Ns && !e && L.IsConsentLoggingEnabled ? Ns.createConsentTxn(!1, (o ? Bn : Nn) + " - " + (t ? Hn : Rn), o) : O.dispatchConsentEvent()
    }, tr.prototype.hideVendorsList = function() {
        kn.checkIfPcSdkContainerExist() || (L.PCTemplateUpgrade ? v("#onetrust-pc-sdk " + A.P_Content).removeClass("ot-hide") : v("#onetrust-pc-sdk .ot-main-content").show(), v("#onetrust-pc-sdk #close-pc-btn-handler.main").show(), v("#onetrust-pc-sdk " + A.P_Vendor_List).addClass("ot-hide"))
    }, tr.prototype.resetConsent = function() {
        var e = this,
            t = this.getInitialConsent();
        _.groupsConsent = JSON.parse(JSON.stringify(t)), _.hostsConsent = JSON.parse(JSON.stringify(_.initialHostConsent)), _.showGeneralVendors && (_.genVendorsConsent = JSON.parse(JSON.stringify(_.initialGenVendorsConsent))), _.vsIsActiveAndOptOut && (_.vsConsent = new Map(_.initialVendorsServiceConsent)), L.IsIabEnabled && (_.oneTrustIABConsent = JSON.parse(JSON.stringify(_.initialOneTrustIABConsent)), _.vendors = JSON.parse(JSON.stringify(_.initialVendors)), _.vendors.vendorTemplate = _.initialVendors.vendorTemplate), L.UseGoogleVendors && (_.addtlVendors = JSON.parse(JSON.stringify(_.initialAddtlVendors)), _.addtlVendorsList = JSON.parse(JSON.stringify(_.initialAddtlVendorsList))), setTimeout(function() {
            e.resetConsentUI()
        }, 400)
    }, tr.prototype.getInitialConsent = function() {
        var e;
        return L.NoBanner && L.ShowPreferenceCenterCloseButton && 0 < b.consentableImpliedConsentGroup.length ? (e = _.initialGroupsConsent.map(function(e) {
            var t = e.split(":")[0];
            return b.consentableImpliedConsentGroup.find(function(e) {
                return e.CustomGroupId === t
            }) ? t + ":1" : e
        }), b.consentableImpliedConsentGroup = [], e) : _.initialGroupsConsent
    }, tr.prototype.setLblTxtForTgl = function(e, t) {
        e = e.querySelector(".ot-label-status");
        L.PCShowConsentLabels && e && (e.innerHTML = m.getInnerHtmlContent(t ? L.PCActiveText : L.PCInactiveText))
    }, tr.prototype.resetConsentUI = function() {
        var p = this;
        V.getAllGroupElements().forEach(function(e) {
            var t = e.getAttribute("data-optanongroupid"),
                t = D.getGroupById(t),
                o = V.isGroupActive(t),
                n = k.GroupTypes;
            if (b.pcName === st && L.PCTemplateUpgrade && (e = document.querySelector("#ot-desc-id-" + e.getAttribute("data-optanongroupid"))), p.setLblTxtForTgl(e, o), t.Type === At || t.Type === n.Stack || 0 < (null == (n = t.SubGroups) ? void 0 : n.length))
                for (var r = e.querySelector('input[class*="category-switch-handler"]'), i = (P.setCheckedAttribute(null, r, o), e.querySelectorAll("li" + A.P_Subgrp_li)), s = 0; s < i.length; s++) {
                    var a = D.getGroupById(i[s].getAttribute("data-optanongroupid")),
                        l = (a.OptanonGroupId, V.isGroupActive(a)),
                        c = i[s].querySelector('input[class*="cookie-subgroup-handler"]'),
                        d = i[s].querySelector(".ot-label-status"),
                        u = e.querySelector(".ot-label-status");
                    L.PCShowConsentLabels && d && (u.innerHTML = m.getInnerHtmlContent(l ? L.PCActiveText : L.PCInactiveText)), P.setCheckedAttribute(null, c, l), C.resetLegIntButton(a, i[s])
                } else {
                    r = e.querySelector('input[class*="category-switch-handler"]');
                    P.setCheckedAttribute(null, r, o), C.resetLegIntButton(t, e)
                }
        }), L.IsIabEnabled && Kn.toggleVendorConsent(), this.resetGenVenUI(), this.resetGoogleVenUI(), _.vsIsActiveAndOptOut && w.resetVendorUIState(_.vsConsent)
    }, tr.prototype.resetGenVenUI = function() {
        var e = v("#onetrust-pc-sdk .ot-gnven-chkbox-handler").el;
        if (_.showGeneralVendors && e && e.length) {
            for (var t = 0, o = e; t < o.length; t++) {
                var n = o[t],
                    r = n.getAttribute("gn-vid"),
                    i = Boolean(_.genVendorsConsent[r]);
                P.setCheckedAttribute("", n, i), Io.updateGenVendorStatus(r, i)
            }
            g.genVenSelectAllTglEvent()
        }
    }, tr.prototype.resetGoogleVenUI = function() {
        var e = v("#onetrust-pc-sdk .ot-addtlven-chkbox-handler").el;
        if (L.UseGoogleVendors && e && e.length)
            for (var t = 0, o = e; t < o.length; t++) {
                var n = o[t],
                    r = n.getAttribute("addtl-vid");
                _.addtlVendorsList[r] && (r = Boolean(_.addtlVendors.vendorSelected[r]), P.setCheckedAttribute("", n, r))
            }
    }, tr.prototype.resetLegIntButton = function(e, t) {
        var o;
        b.legIntSettings.PAllowLI && e.Type === k.GroupTypes.Pur && e.HasLegIntOptOut && b.legIntSettings.PShowLegIntBtn && (o = !0, -1 < _.vendors.selectedLegInt.indexOf(e.IabGrpId + ":false") && (o = !1), V.updateLegIntBtnElement(t, o))
    }, tr.prototype.handleTogglesOnSingularConsentUpdate = function(e, t) {
        if (this.closeOptanonAlertBox(), e === ht)
            for (var s = this, o = 0, n = t; o < n.length; o++) {
                var r = n[o];
                ((e, t) => {
                    for (var o = D.getGroupById(e), n = s.groupsClass.getAllGroupElements(), r = 0; r < n.length; r++) {
                        var i = D.getGroupById(n[r].getAttribute("data-optanongroupid"));
                        if (i.OptanonGroupId === o.OptanonGroupId && !i.Parent) {
                            u.toggleV2Category(null, i, t, i.CustomGroupId);
                            break
                        }
                        i = i.SubGroups.find(function(e) {
                            return e.OptanonGroupId === o.OptanonGroupId
                        });
                        i && u.toggleSubCategory(null, i.CustomGroupId, t, i.CustomGroupId)
                    }
                })(c = r.id, d = r.isEnabled)
            } else if (e === St)
                for (var i = 0, a = t; i < a.length; i++) {
                    var l = a[i],
                        c = l.id,
                        d = l.isEnabled,
                        l = D.getGrpByVendorId(c);
                    l && w.toggleVendorService(l.CustomGroupId, c, d)
                }
        this.close(!1, te.API)
    }, tr.prototype.checkImplicitConsentWhenBannerIsClosed = function(e) {
        var t;
        void 0 === e && (e = !1), O.isAlertBoxClosedAndValid() || !_o.isLandingPage() && !e || (_.bannerCloseSource === ee.BannerCloseButton && b.resetImpliedConsentableGroups(), t = new Map, b.consentableImpliedConsentGroup.forEach(function(o) {
            var n;
            o.Status === f.INACTIVE_LANDING_PAGE && 0 <= (n = P.findIndex(_.groupsConsent, function(e) {
                return e.split(":")[0] === o.CustomGroupId
            })) && (t.set(o.CustomGroupId, o), U(o.SubGroups, [o]).forEach(function(e) {
                var t = b.gpcEnabled && e.IsGpcEnabled;
                _.groupsConsent[n] = o.CustomGroupId + ":1", t && (_.groupsConsent[n] = o.CustomGroupId + ":0"), !t && e.Hosts.length && I.isOptOutEnabled() && e.Hosts.forEach(function(e) {
                    return Do.updateHostStatus(e, !0)
                }), !t && _.genVenOptOutEnabled && e.GeneralVendorsIds && e.GeneralVendorsIds.length && e.GeneralVendorsIds.forEach(function(e) {
                    return Io.updateGenVendorStatus(e, !0)
                })
            }))
        }), this.setImplicitConsentUI(t))
    }, tr.prototype.setImplicitConsentUI = function(e) {
        var o = this;
        e.size <= 0 || e.forEach(function(e, t) {
            t = o.getGroupElement(t);
            t && (o.groupsClass.toggleGrpElements(t, e, !0), o.groupsClass.toogleSubGroupElement(t, !0, !1, !0), o.groupsClass.toogleSubGroupElement(t, !0, !0, !0))
        })
    }, tr.prototype.getGroupElement = function(e) {
        return document.querySelector("div#onetrust-pc-sdk " + A.P_Category_Grp + " " + A.P_Category_Item + '[data-optanongroupid="' + e + '"]:not(.ot-vnd-item)')
    };
    var C, er = tr;

    function tr() {
        var n = this;
        this.iab = g, this.groupsClass = V, this.fltgBackBtnSvg = ".ot-floating-button__back svg", this.fltgFrontBtnSvg = ".ot-floating-button__front svg", this.fltgBtnBackBtn = ".ot-floating-button__back button", this.fltgBtnFrontBtn = ".ot-floating-button__front button", this.closeOptanonAlertBox = function() {
            var e;
            I.hideBanner(), v(document).off("keydown", u.closePCWhenEscPressed), L.NtfyConfig.ShowNtfy && wn.hideSyncNtfy(), mo.setAlertBoxClosed(!0), L.PCTemplateUpgrade && L.PCenterUserIdTitleText && L.IsConsentLoggingEnabled && n.updateDataSubjectTimestamp(), O.isAlertBoxClosedAndValid() && (e = v(".onetrust-pc-dark-filter").el[0]) && "none" !== getComputedStyle(e).getPropertyValue("display") && v(".onetrust-pc-dark-filter").fadeOut(400), xs.csBtnGroup && n.showFltgCkStgButton()
        }, this.bodyClickEvent = function(e) {
            var t = e.target;
            t.closest("#onetrust-banner-sdk") || t.closest("#onetrust-pc-sdk") || t.closest(".onetrust-pc-dark-filter") || t.closest(".ot-sdk-show-settings") || t.closest(".optanon-show-settings") || t.closest(".optanon-toggle-display") || t.closest(".ot-confirm-dialog-overlay") || C.onClickCloseBanner(e)
        }, this.bannerCloseButtonHandler = function(o) {
            return void 0 === o && (o = !1), F(n, void 0, void 0, function() {
                var t;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (C.checkImplicitConsentWhenBannerIsClosed(o), C.closeOptanonAlertBox(), S.moduleInitializer.MobileSDK) ? (window.OneTrust.Close(), [3, 5]) : [3, 1];
                        case 1:
                            return e.trys.push([1, 3, , 4]), [4, Zn.getInstance().checkIfHealthSignatureNeeded()];
                        case 2:
                            return e.sent(), [3, 4];
                        case 3:
                            return t = e.sent(), console.error(t), [3, 4];
                        case 4:
                            t = _.bannerCloseSource === ee.ConfirmChoiceButton ? te.PC : te.Banner, C.close(o, t), e.label = 5;
                        case 5:
                            return [2, !1]
                    }
                })
            })
        }, this.allowAllEventHandler = function(r) {
            return void 0 === r && (r = !1), F(n, void 0, void 0, function() {
                var o, t, n = this;
                return M(this, function(e) {
                    return v(document).off("keydown", u.shiftBannerFocus), o = r ? "Preferences Allow All" : "Banner Accept Cookies", t = function() {
                        return F(n, void 0, void 0, function() {
                            var t;
                            return M(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        mo.triggerGoogleAnalyticsEvent(Bo, o), r && b.requireSignatureEnabled && (kn.hideConsentNoticeV2(), this.closeOptanonAlertBox()), e.label = 1;
                                    case 1:
                                        return e.trys.push([1, 3, , 4]), [4, Zn.getInstance().checkIfHealthSignatureNeeded(!0)];
                                    case 2:
                                        return e.sent(), [3, 4];
                                    case 3:
                                        return t = e.sent(), console.error(t), [3, 4];
                                    case 4:
                                        return this.allowAllEvent(!1, r), this.hideVendorsList(), [2]
                                }
                            })
                        })
                    }, I.shouldShowDoubleOptInSignal(!0) ? I.createDoubleOptInConfirmDialog(r, t) : t(), [2]
                })
            })
        }, this.allowAllEvent = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = !1), n.closeOptanonAlertBox(), C.allowAll(e, t)
        }, this.rejectAllEventHandler = function(e) {
            void 0 === e && (e = !1), v(document).off("keydown", u.shiftBannerFocus), mo.triggerGoogleAnalyticsEvent(Bo, e ? "Preferences Reject All" : "Banner Reject All"), Zn.getInstance().resetHealthSignatureData(!0), S.moduleInitializer.MobileSDK ? window.OneTrust.RejectAll() : (n.rejectAllEvent(!1, e), n.hideVendorsList())
        }, this.rejectAllEvent = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = !1), n.closeOptanonAlertBox(), !O.isIABCrossConsentEnabled() || b.thirdPartyiFrameLoaded ? n.rejectAll(e, t) : b.thirdPartyiFramePromise.then(function() {
                n.rejectAll(e, t)
            })
        }
    }
    rr.prototype.setFilterList = function(o) {
        var e, n = this,
            r = (v("#onetrust-pc-sdk #ot-filter-list-header").html(L.PCCookieListFiltersText), null == (e = null == (e = null == (e = v("#onetrust-pc-sdk " + A.P_Fltr_Modal + " " + A.P_Fltr_Option)) ? void 0 : e.el) ? void 0 : e[0]) ? void 0 : e.cloneNode(!0));
        v("#onetrust-pc-sdk " + A.P_Fltr_Modal + " " + A.P_Fltr_Options).html(""), (S.isV2Template || L.PCLayout.Popup) && (v(this.CANCEL_FILTER).html(L.PCenterCancelFiltersText || "Cancel"), v(this.CANCEL_FILTER).attr(mt, L.PCenterCancelFilterAriaLabel)), !S.isV2Template && L.PCLayout.Popup || (v("#onetrust-pc-sdk " + A.P_Clr_Fltr_Txt).html(L.PCenterClearFiltersText), v("#onetrust-pc-sdk " + A.P_Clr_Fltr_Txt).attr(mt, L.PCenterClearFiltersAriaLabel), e = I.getVendorPageHeaderText(), v("#filter-btn-handler").el[0].setAttribute("aria-label", L.PCenterFilterText + " " + e)), v("#onetrust-pc-sdk #filter-apply-handler").html(L.PCenterApplyFiltersText), v("#onetrust-pc-sdk #filter-apply-handler").attr(mt, L.PCenterApplyFiltersAriaLabel), o ? b.consentableGrps.forEach(function(e) {
            var t = _.cookieListType === ye.GenVen || _.cookieListType === ye.HostAndGenVen ? e.Hosts.length || e.FirstPartyCookies.length || e.GeneralVendorsIds && e.GeneralVendorsIds.length : e.Hosts.length || e.FirstPartyCookies.length;
            t && n.filterGroupOptionSetter(r, e, o)
        }) : b.iabGrps.forEach(function(e) {
            n.filterGroupOptionSetter(r, e, o)
        })
    }, rr.prototype.setFilterListByGroup = function(e, t) {
        var o, n, r = this;
        !e || e.length <= 0 ? v("#onetrust-pc-sdk " + A.P_Fltr_Modal + " " + A.P_Fltr_Options).html("") : (o = null == (n = null == (n = null == (n = v("#onetrust-pc-sdk " + A.P_Fltr_Modal + " " + A.P_Fltr_Option)) ? void 0 : n.el) ? void 0 : n[0]) ? void 0 : n.cloneNode(!0), v("#onetrust-pc-sdk " + A.P_Fltr_Modal + " " + A.P_Fltr_Options).html(""), (S.isV2Template || L.PCLayout.Popup) && (v(this.CANCEL_FILTER).html(L.PCenterCancelFiltersText || "Cancel"), v(this.CANCEL_FILTER).attr(mt, L.PCenterCancelFilterAriaLabel)), !S.isV2Template && L.PCLayout.Popup || (v("#onetrust-pc-sdk " + A.P_Clr_Fltr_Txt).html(L.PCenterClearFiltersText), v("#onetrust-pc-sdk " + A.P_Clr_Fltr_Txt).attr(mt, L.PCenterClearFiltersAriaLabel), n = I.getVendorPageHeaderText(), v("#filter-btn-handler").el[0].setAttribute("aria-label", L.PCenterFilterText + " " + n)), v("#onetrust-pc-sdk #filter-apply-handler").html(L.PCenterApplyFiltersText), e.forEach(function(e) {
            r.filterGroupOptionSetter(o, e, t)
        }))
    }, rr.prototype.filterGroupOptionSetter = function(e, t, o) {
        var n = t.CustomGroupId,
            r = n + "-filter";
        e && (e = e.cloneNode(!0), v(A.P_Fltr_Modal + " " + A.P_Fltr_Options).append(e), v(e.querySelector("input")).attr("id", r), v(e.querySelector("label")).attr("for", r), (S.isV2Template ? v(e.querySelector(A.P_Label_Txt)) : v(e.querySelector("label span"))).html(t.GroupName), v(e.querySelector("input")).attr(o ? "data-optanongroupid" : "data-purposeid", n))
    };
    var or, nr = rr;

    function rr() {
        this.bodyScrollProp = "", this.htmlScrollProp = "", this.ONETRUST_PC_SDK = "#onetrust-pc-sdk", this.ONETRUST_PC_DARK_FILTER = ".onetrust-pc-dark-filter", this.CANCEL_FILTER = "#onetrust-pc-sdk #filter-cancel-handler"
    }
    ar.prototype.showParagraph = function(e) {
        var t = R({}, e),
            o = t.listTitle,
            n = t.htmlFragment,
            t = t.paragrphContainerSelector;
        ir.options = e, ir.hideOtherHtmlElements(e), ir.setParagraphTitle(o), ir.addItemListToRootElement(n, t)
    }, ar.prototype.hideParagraphUI = function() {
        var e = R({}, ir.options),
            t = e.showFooter;
        e.showSearchBox || (null != (e = ir.checkboxesContainerEle) && e.classList.remove("ot-hide"), null != (e = ir.searchInputContainerEle) && e.classList.remove("ot-hide"), null != (e = ir.listHotsVendorsContainerEle) && e.classList.remove("ot-hide")), t || (null != (e = ir.footerButtonContainerEle) && e.classList.remove("ot-hide"), u.setCenterLayoutFooterHeight()), ir.rootEle.removeChild(ir.paragraphContainerEle)
    }, ar.prototype.addItemListToRootElement = function(e, t) {
        var o = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_List);
        ir.rootEle = o.querySelector(this.MAIN_CONT_ELE), ir.rootEle.appendChild(e), ir.paragraphContainerEle = ir.rootEle.querySelector(t)
    }, ar.prototype.setParagraphTitle = function(e) {
        document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]').innerHTML = m.getInnerHtmlContent(e)
    }, ar.prototype.hideOtherHtmlElements = function(e) {
        var e = R({}, e),
            t = e.showFooter,
            e = e.showSearchBox,
            o = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_List),
            o = (!e && o && (ir.checkboxesContainerEle = o.querySelector(this.SEL_BLK_ELE), ir.searchInputContainerEle = o.querySelector(this.LST_SUBHDR_ELE), ir.listHotsVendorsContainerEle = o.querySelector(this.SDK_ROW_ELE), null != (e = ir.checkboxesContainerEle) && e.classList.add("ot-hide"), null != (o = ir.searchInputContainerEle) && o.classList.add("ot-hide"), null != (e = ir.listHotsVendorsContainerEle)) && e.classList.add("ot-hide"), document.querySelector("#onetrust-pc-sdk .ot-pc-footer .ot-btn-container"));
        !t && o && (ir.footerButtonContainerEle = o, null != (e = ir.footerButtonContainerEle) && e.classList.add("ot-hide"), u.setCenterLayoutFooterHeight())
    };
    var ir, sr = ar;

    function ar() {
        this.SDK_ROW_ELE = ".ot-sdk-row", this.SEL_BLK_ELE = "#ot-sel-blk", this.MAIN_CONT_ELE = "#ot-lst-cnt", this.LST_SUBHDR_ELE = ".ot-lst-subhdr"
    }
    dr.prototype.showIllustrations = function(e, t) {
        e = lr.insertParagraphContainer(e, t), t = {
            showFooter: !1,
            showSearchBox: !1,
            listTitle: L.PCIllusText,
            htmlFragment: e,
            paragrphContainerSelector: "." + this.PARAGRAPH_CONTAINER_ELE
        };
        ir.showParagraph(t)
    }, dr.prototype.hideUI = function() {
        ir.hideParagraphUI()
    }, dr.prototype.addIllustrationsLink = function(e, t, o, n) {
        void 0 === n && (n = !1);
        var r = t.IabIllustrations && 0 < t.IabIllustrations.length;
        o && r && L.PCGrpDescType === re.UserFriendly && (o = L.PCVendorFullLegalText + "&nbsp;", (r = document.createElement("button")).classList.add("ot-link-btn"), r.classList.add("ot-pgph-link"), r.setAttribute("aria-label", t.GroupName + ", " + L.PCVendorFullLegalText), r.setAttribute("data-parent-id", t.CustomGroupId), n ? (r.classList.add("ot-pgph-link-subgroup"), e.appendChild(r)) : (o = "&nbsp;|&nbsp" + o, e.insertAdjacentElement("afterend", r)), r.innerHTML = m.getInnerHtmlContent(o))
    }, dr.prototype.insertParagraphContainer = function(e, t) {
        var o = document.createDocumentFragment(),
            n = document.createElement("div"),
            e = (n.classList.add(this.PARAGRAPH_CONTAINER_ELE), lr.insertPurposeTitle(e)),
            r = (n.appendChild(e), document.createElement("div"));
        return r.classList.add("ot-paragraph-lst"), t.forEach(function(e, t) {
            e = lr.insertDescriptionElement(e, t);
            r.appendChild(e)
        }), n.appendChild(r), o.appendChild(n), o
    }, dr.prototype.insertPurposeTitle = function(e) {
        null != (o = S.moduleInitializer) && o.SEOOptimization ? ((t = document.createElement("p")).setAttribute("role", "heading"), t.setAttribute("aria-level", "4")) : t = document.createElement("h4"), t.classList.add("ot-pgph-title");
        var t, o = document.createTextNode(e);
        return t.appendChild(o), t
    }, dr.prototype.insertDescriptionElement = function(e, t) {
        var o = document.createElement("p");
        return o.setAttribute("id", "ot-pgph-desc-id-" + t), o.classList.add("ot-pgph-desc"), o.innerText = e, o
    };
    var lr, cr = dr;

    function dr() {
        this.PARAGRAPH_CONTAINER_ELE = "ot-pgph-contr"
    }
    r.prototype.insertPcHtml = function() {
        N.jsonAddAboutCookies(L);
        var t = document.createDocumentFragment(),
            e = (xs.preferenceCenterGroup && (o = document.createElement("div"), v(o).html(xs.preferenceCenterGroup.html), o = o.querySelector("#onetrust-pc-sdk"), N.addClassesPerConfig(o), v(t).append(o), N.manageCloseButtons(o, o = function(e) {
                return t.querySelectorAll(e)
            }, n = function(e) {
                return t.querySelector(e)
            }), L.Language && L.Language.Culture && v(n("#onetrust-pc-sdk")).attr("lang", L.Language.Culture), N.addLogos(n, o), v(n(A.P_Title)).html(L.MainText), L.PCCloseButtonType === Pe.Link && L.PCTemplateUpgrade && b.pcName === st && v(n(A.P_Title)).addClass("ot-pc-title-shrink"), L.PCTemplateUpgrade && v(n(fn + ' > div[role="dialog"]')).css("height: 100%;"), v(n(fn + ' > div[role="dialog"]')).attr(this._ariaLabel, L.MainText), L.PCRegionAriaLabel && (v(n("#onetrust-pc-sdk")).attr(this._ariaLabel, L.PCRegionAriaLabel), v(n("#onetrust-pc-sdk")).attr("role", "region")), b.pcName === st && (null != (e = v(n(A.P_Title))) && e.attr("title", L.MainText), v(n(A.P_Privacy_Txt)).html(L.AboutCookiesText), v(n(A.P_Privacy_Hdr)).html(L.AboutCookiesText), null != (e = v(n("#onetrust-pc-sdk " + A.P_Content + " .ot-tab-list"))) && e.attr(this._ariaLabel, L.PCenterCookieCategoriesAriaLabel), N.updateTitleForMobileView(n)), e = '<span class="ot-tcf2-vendor-count ot-text-bold tcf2-vcount">' + b.tcf2ActiveVendors.all.toString() + "</span>", e = I.replaceTextFromString("[VENDOR_NUMBER]", L.MainInfoText, e), v(n(A.P_Policy_Txt)).html(e), N.configureLinkFields(n, o), N.configureSubjectDataFields(n), N.configureButtons(n, o), N.setManagePreferenceText(n), N.initializePreferenceCenterGroups(n, t), N.removeListsWhenAppropriate(n), L.PCTemplateUpgrade) && N.setOptOutSignalNotification(n), document.createElement("iframe")),
            o = (e.setAttribute("class", "ot-text-resize"), e.setAttribute("sandbox", "allow-same-origin"), e.setAttribute("title", "onetrust-text-resize"), d(e, "position: absolute; top: -50000px; width: 100em;"), e.setAttribute(this._ariaHidden, "true"), v(t.querySelector("#onetrust-pc-sdk")).append(e), I.replaceHeadings(t), document.getElementById("onetrust-consent-sdk")),
            n = (v(o).append(t), b.ignoreInjectingHtmlCss || v(document.body).append(o), (L.showCookieList || _.showGeneralVendors) && On.InitializeHostList(), A.P_Vendor_List + " " + A.P_Host_Cntr + " li"),
            e = v(n).el[0];
        e && P.removeChild(e)
    }, r.prototype.updateTitleForMobileView = function(e) {
        function t() {
            var e = window.getComputedStyle(o.el).display;
            o.attr(N._ariaHidden, "none" !== e ? "false" : "true"), n.attr(N._ariaHidden, "none" !== e ? "true" : "false")
        }
        var o = v(e(A.P_Title_Mobile)),
            n = v(e(A.P_Title));
        o.html(L.MainText), setTimeout(t), v(window).on("resize", t)
    }, r.prototype.addClassesPerConfig = function(e) {
        /Chrome|Safari/i.test(navigator.userAgent) && /Google Inc|Apple Computer/i.test(navigator.vendor) || v(e).addClass("ot-sdk-not-webkit"), L.useRTL && v(e).attr("dir", "rtl"), b.legIntSettings.PAllowLI && b.isIab2orv2Template && (v(e).addClass("ot-leg-opt-out"), b.legIntSettings.PShowLegIntBtn) && v(e).addClass("ot-leg-btn"), L.BannerRelativeFontSizesToggle && v(e).addClass("otRelFont"), L.PCShowConsentLabels && v(e).addClass("ot-tgl-with-label"), (L.UseGoogleVendors || _.showGeneralVendors) && v(e).addClass("ot-addtl-vendors"), "right" === L.PreferenceCenterPosition && v(e).addClass(L.useRTL ? "right-rtl" : "right")
    }, r.prototype.manageCloseButtons = function(e, t, o) {
        var n = v(t(A.P_Close_Btn)).el;
        if (L.ShowPreferenceCenterCloseButton) {
            L.CloseText || (L.CloseText = "Close Preference Center");
            for (var r = 0, i = n; r < i.length; r++) {
                var s = i[r];
                L.PCCloseButtonType === Pe.Link && L.PCTemplateUpgrade ? (v(s).html(L.PCContinueText), v(e).addClass("ot-close-btn-link"), v(s).el.removeAttribute(this._ariaLabel)) : (v(s).el.setAttribute(this._ariaLabel, L.CloseText), I.setCloseIcon(o("#onetrust-pc-sdk .ot-close-icon")))
            }
        } else
            for (var a = 0; a < n.length; a++) v(n[a].parentElement).el.removeChild(n[a])
    }, r.prototype.addLogos = function(e, t) {
        var o, n, r, e = e(A.P_Logo);
        e && L.optanonLogo && (o = I.updateCorrectUrl(L.optanonLogo), I.checkMobileOfflineRequest(I.getBannerVersionUrl()) && (o = P.getRelativeURL(o, !0, !0)), r = new URL(o, window.location.origin).pathname, S.fp.CMPIconSprite && (r.includes("/logos/static/") || r.includes("src/assets/images/") && new URL(o, window.location.origin).host.includes("localhost")) ? (r = r.split("/").pop().split(".").shift(), (n = document.createElementNS("http://www.w3.org/2000/svg", "svg")).innerHTML = "<use></use>", n.querySelector("use").setAttribute("href", "#" + r), L.PCLogoAria && v(e).attr(this._ariaLabel, L.PCLogoAria), e.setAttribute("role", "img"), e.append(n)) : ((r = document.createElement("img")).setAttribute("alt", L.PCLogoAria), r.setAttribute("src", o), e.append(r))), I.insertFooterLogo(t(".ot-pc-footer-logo a"))
    }, r.prototype.configureLinkFields = function(e, t) {
        var o;
        L.AboutText && v(e(A.P_Policy_Txt)).html(v(e(A.P_Policy_Txt)).html() + '\n            <br/><a href="' + L.AboutLink + '" class="privacy-notice-link" rel="noopener noreferrer" target="_blank"\n                    aria-label="' + L.PCCookiePolicyLinkScreenReader + '">' + L.AboutText + "</a>"), L.PCenterImprintLinkText && (L.AboutText || e(A.P_Policy_Txt).insertAdjacentHTML("beforeend", m.getInnerHtmlContent("<br/>")), (o = document.createElement("a")).classList.add("ot-link-btn", "ot-imprint-handler"), o.textContent = L.PCenterImprintLinkText, o.setAttribute(this._ariaLabel, L.PCenterImprintLinkScreenReader), o.setAttribute("href", L.PCenterImprintLinkUrl), o.setAttribute("rel", "noopener noreferrer"), o.setAttribute("target", "_blank"), e(A.P_Policy_Txt).appendChild(o)), L.PCenterVendorListLinkText && (o = !L.IsIabEnabled && _.showGeneralVendors ? "ot-gv-list-handler" : "onetrust-vendors-list-handler", e(A.P_Policy_Txt).insertAdjacentHTML("beforeend", m.getInnerHtmlContent('<button class="ot-link-btn ' + o + '" aria-label="' + L.PCenterVendorListLinkAriaLabel + '">\n                    ' + L.PCenterVendorListLinkText + "\n                    </button>"))), I.addExternalIconForLinks(t)
    }, r.prototype.configureSubjectDataFields = function(e) {
        var t;
        L.PCTemplateUpgrade && L.PCenterUserIdTitleText && L.IsConsentLoggingEnabled && (t = T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID), e(A.P_Policy_Txt).insertAdjacentHTML("beforeend", m.getInnerHtmlContent('<div class="ot-userid-title"><strong>' + L.PCenterUserIdTitleText + ": </strong> " + t + "</div>")), L.PCenterUserIdDescriptionText && e(A.P_Policy_Txt).insertAdjacentHTML("beforeend", m.getInnerHtmlContent('<div class="ot-userid-desc"><em>' + L.PCenterUserIdDescriptionText + "</em></div>")), L.PCenterUserIdTimestampTitleText) && (t = (t = T.getCookie(y.ALERT_BOX_CLOSED)) && I.getUTCFormattedDate(t) || L.PCenterUserIdNotYetConsentedText, e(A.P_Policy_Txt).insertAdjacentHTML("beforeend", m.getInnerHtmlContent('<div class="ot-userid-timestamp"><strong>' + L.PCenterUserIdTimestampTitleText + ": </strong> " + t + "</div>")))
    }, r.prototype.setManagePreferenceText = function(e) {
        var e = e(A.P_Manage_Cookies_Txt),
            t = v(e);
        e && (t.html(L.ManagePreferenceText), L.ManagePreferenceText || P.removeChild(t.el))
    }, r.prototype.configureButtons = function(e, t) {
        this.setButtonsOrder(e), L.ConfirmText.trim() ? v(e(Tn)).html(L.ConfirmText) : e(Tn).parentElement.removeChild(e(Tn));
        for (var o = t(".save-preference-btn-handler"), n = 0; n < o.length; n++) v(o[n]).html(L.AllowAllText);
        var r = t(".ot-pc-refuse-all-handler");
        if (L.PCenterShowRejectAllButton && L.PCenterRejectAllButtonText.trim())
            for (n = 0; n < r.length; n++) v(r[n]).html(L.PCenterRejectAllButtonText);
        else P.removeChild(r);
        this.checkIfStackButtons(e)
    }, r.prototype.setButtonsOrder = function(e) {
        if (L.PCTemplateUpgrade && S.fp.WebButtonCustomisations && this.checkButtonsOrderValidation(e)) {
            var t = new Map,
                o = new Map,
                n = e(".ot-pc-refuse-all-handler"),
                r = e(Tn),
                i = e(".save-preference-btn-handler"),
                s = (this.setButtonOrderConfig(r, t, o, Ee.ACCEPT_ALL), this.setButtonOrderConfig(n, t, o, Ee.REJECT_ALL), this.setButtonOrderConfig(i, t, o, Ee.SAVE_PREFERENCE), e("#onetrust-pc-sdk .ot-pc-footer .ot-btn-container"));
            if (s) {
                s.classList.add("ot-button-order-container");
                for (var a = 0, l = Object.entries(L.PcBO); a < l.length; a++) {
                    var c = l[a],
                        d = c[0],
                        c = c[1],
                        u = t.get(Number(d)),
                        c = o.get(c);
                    u && c && (u.replaceWith(c), c.classList.add("ot-button-order-" + d), "0" !== d || b.pcName !== ot && b.pcName !== rt || s.insertBefore(c, s.firstChild))
                }
                b.pcName === st && (r = s.querySelectorAll('[class*="ot-button-order-"]'), s.innerHTML = "", null != (n = r)) && n.forEach(function(e) {
                    return s.appendChild(e)
                })
            }
        }
    }, r.prototype.checkIfStackButtons = function(e) {
        var t = this.butttonsTextAreLarge();
        L.PCTemplateUpgrade && S.fp.WebButtonCustomisations && (b.pcName === ot || b.pcName === st) && t && (t = e(".ot-btn-container.ot-button-order-container")) && (t.classList.add("ot-stack-buttons"), null != (e = t = e(".ot-pc-footer")) && e.style.setProperty("height", "100%"), null != (e = t) && e.style.setProperty("display", "flex"), null != (e = t)) && e.style.setProperty("flex-direction", "column")
    }, r.prototype.butttonsTextAreLarge = function() {
        var e;
        return 20 < (null == (e = L.ConfirmText) ? void 0 : e.length) || 20 < (null == (e = L.AllowAllText) ? void 0 : e.length) || 20 < (null == (e = L.PCenterRejectAllButtonText) ? void 0 : e.length)
    }, r.prototype.checkButtonsOrderValidation = function(e) {
        var t = e(".ot-pc-refuse-all-handler"),
            o = e(Tn);
        return !(e(".save-preference-btn-handler") && !this.checkIfConfigurationIsValid(Ee.SAVE_PREFERENCE) || o && !this.checkIfConfigurationIsValid(Ee.ACCEPT_ALL) || t && !this.checkIfConfigurationIsValid(Ee.REJECT_ALL))
    }, r.prototype.checkIfConfigurationIsValid = function(e) {
        var t, o = !1;
        for (t in L.PcBO) {
            var n = Number(t);
            if (L.PcBO[n] === e) {
                o = !0;
                break
            }
        }
        return o
    }, r.prototype.setButtonOrderConfig = function(e, t, o, n) {
        var r;
        e && (r = Number(e.getAttribute("ot-button-order")), e.removeAttribute("ot-button-order"), t.set(r, e), o.set(n, e.cloneNode(!0)))
    }, r.prototype.removeListsWhenAppropriate = function(e) {
        var t;
        L.IsIabEnabled || (t = e(A.P_Vendor_Container)) && t.parentElement.removeChild(t), L.showCookieList || _.showGeneralVendors || (t = e(A.P_Host_Cntr)) && t.parentElement.removeChild(t)
    }, r.prototype.setParentGroupName = function(e, t, o, n) {
        var r = e.querySelector('.category-header,.ot-cat-header,.category-menu-switch-handler>h3,.category-menu-switch-handler>p[aria-level="3"]');
        v(r).html(t), v(r).attr("id", o), b.pcName === st && (e.querySelector(A.P_Category_Header).innerHTML = m.getInnerHtmlContent(t), e.querySelector("" + A.P_Desc_Container).setAttribute("id", n), e.querySelector(".category-menu-switch-handler").setAttribute("aria-controls", n))
    }, r.prototype.setLegIntButton = function(e, t, o, n) {
        void 0 === o && (o = !1);
        var r = !0,
            r = (-1 < _.vendors.selectedLegInt.indexOf(t.IabGrpId + ":false") && (r = !1), O.generateLegIntButtonElements(r, t.OptanonGroupId, !1, t.GroupName)),
            t = (o ? n.insertAdjacentHTML("afterend", r) : e.insertAdjacentHTML("beforeend", r), e.querySelector(".ot-remove-objection-handler"));
        t && d(t, t.getAttribute("data-style"))
    }, r.prototype.setParentGroupDescription = function(e, t, o, n, r) {
        var i = V.safeFormattedGroupDescription(t),
            s = e.querySelector("p:not(.ot-always-active)"),
            a = e.querySelector(A.P_Acc_Grp_Desc),
            s = s || a;
        return -1 < Vt.indexOf(t.Type) && o.PCGrpDescType === re.Legal ? i = t.DescriptionLegal : s.classList.add("ot-category-desc"), b.legIntSettings.PAllowLI && !b.legIntSettings.PShowLegIntBtn && (t.SubGroups.some(function(e) {
            return e.HasLegIntOptOut
        }) || t.HasLegIntOptOut ? s.parentElement.classList.add("ot-leg-border-color") : P.removeChild(e.querySelector(A.P_Li_Hdr))), b.pcName !== st && s.setAttribute("id", n), v(s).html(i), t.Type === k.GroupTypes.Stack && P.removeChild(s), s
    }, r.prototype.cloneOtHtmlEls = function(e) {
        var t = /otPcPanel|otPcCenter/;
        E.toggleEl = v(e(".ot-tgl")).el.cloneNode(!0), E.arrowEl = v(e('#onetrust-pc-sdk [role="dialog"] > ' + A.P_Arrw_Cntr)).el.cloneNode(!0), E.subGrpEl = v(e(A.P_Sub_Grp_Cntr)).el.cloneNode(!0), E.vListEl = v(e(A.P_Ven_Lst_Cntr)).el.cloneNode(!0), E.cListEl = v(e(A.P_Host_Lst_cntr)).el.cloneNode(!0), E.chkboxEl = v(e(A.P_CBx_Cntr)).el.cloneNode(!0), E.accordionEl = v(e(".ot-acc-cntr")).el.cloneNode(!0), t.test(b.pcName) && (E.plusMinusEl = v(e(".ot-plus-minus")).el.cloneNode(!0)), P.removeChild(e(".ot-tgl")), P.removeChild(e('#onetrust-pc-sdk [role="dialog"] > ' + A.P_Arrw_Cntr)), P.removeChild(e(A.P_Sub_Grp_Cntr)), P.removeChild(e(A.P_Ven_Lst_Cntr)), P.removeChild(e(A.P_Host_Lst_cntr)), P.removeChild(e(A.P_CBx_Cntr)), P.removeChild(e(".ot-acc-cntr")), t.test(b.pcName) && P.removeChild(e(".ot-plus-minus"))
    }, r.prototype.insertSelectAllEls = function(e) {
        var e = e(A.P_Select_Cntr + " .ot-sel-all-chkbox"),
            t = _.showVendorService ? Yn() : E.chkboxEl.cloneNode(!0),
            t = (t.id = A.P_Sel_All_Host_El, t.querySelector("input").id = "select-all-hosts-groups-handler", t.querySelector("label").setAttribute("for", "select-all-hosts-groups-handler"), v(e).append(t), _.showVendorService ? Yn() : E.chkboxEl.cloneNode(!0)),
            t = (t.id = A.P_Sel_All_Vendor_Consent_El, t.querySelector("input").id = "select-all-vendor-groups-handler", t.querySelector("label").setAttribute("for", "select-all-vendor-groups-handler"), v(e).append(t), _.showVendorService ? Yn() : E.chkboxEl.cloneNode(!0));
        t.id = A.P_Sel_All_Vendor_Leg_El, t.querySelector("input").id = "select-all-vendor-leg-handler", t.querySelector("label").setAttribute("for", "select-all-vendor-leg-handler"), v(e).append(t)
    }, r.prototype.initializePreferenceCenterGroups = function(e, t) {
        var o, n = b.pcName,
            r = (S.isV2Template && (N.cloneOtHtmlEls(e), (r = E.chkboxEl.cloneNode(!0)).querySelector("input").classList.add("category-filter-handler"), v(e(A.P_Fltr_Modal + " " + A.P_Fltr_Option)).append(r), N.insertSelectAllEls(e)), v(e("#onetrust-pc-sdk " + A.P_Category_Grp))),
            i = (n === ot || n === rt || n === nt ? L.PCenterEnableAccordion ? P.removeChild(r.el.querySelector(A.P_Category_Item + ":not(.ot-accordion-layout)")) : P.removeChild(r.el.querySelector(A.P_Category_Item + ".ot-accordion-layout")) : n === st && (L.PCenterEnableAccordion = !1), e("#onetrust-pc-sdk " + A.P_Category_Item)),
            s = S.isV2Template ? E.subGrpEl.cloneNode(!0) : v(e(A.P_Sub_Grp_Cntr)),
            a = S.isV2Template ? null : v(e(A.P_Acc_Container + " " + A.P_Sub_Grp_Cntr));
        L.PCTemplateUpgrade && /otPcTab/.test(n) && (o = e(".ot-abt-tab").cloneNode(!0), P.removeChild(e(".ot-abt-tab"))), r.el.removeChild(i), N.setVendorListClass(e, i), N.setPCHeader(e, i), N.createHtmlForEachGroup({
            fm: e,
            fragment: t,
            categoryGroupTemplate: i,
            cookiePreferencesContainer: r,
            popupSubGrpContainer: a,
            subGrpContainer: s
        }), N.setPcTabLayout(e, t, o)
    }, r.prototype.getActiveVendorCount = function(e) {
        var t = parseInt(e.IabGrpId),
            o = 0;
        return e.Type === k.GroupTypes.Pur ? o = b.tcf2ActiveVendors.pur.get(t) : e.Type === k.GroupTypes.Ft ? o = b.tcf2ActiveVendors.ft.get(t) : e.Type === k.GroupTypes.Spl_Pur ? o = b.tcf2ActiveVendors.spl_pur.get(t) : e.Type === k.GroupTypes.Spl_Ft && (o = b.tcf2ActiveVendors.spl_ft.get(t)), o || 0
    }, r.prototype.getActiveVendorCountForStack = function(e) {
        return b.tcf2ActiveVendors.stack.get(e) || 0
    }, r.prototype.getVendorCountEl = function(e, t) {
        var o = "[VENDOR_NUMBER]",
            n = "";
        switch (t) {
            case bt:
                n = L.PCVendorsCountFeatureText;
                break;
            case Lt:
                n = L.PCVendorsCountSpcFeatureText;
                break;
            case It:
                n = L.PCVendorsCountSpcPurposeText;
                break;
            default:
                n = L.PCVendorsCountText
        }
        return n && -1 < n.indexOf(o) ? '<span class="ot-pur-vdr-count"> ' + n.replace(o, e.toString()) + " </span>" : ""
    }, r.prototype.createHtmlForEachGroup = function(e) {
        var t = e.fm,
            o = e.fragment,
            n = e.categoryGroupTemplate,
            r = e.cookiePreferencesContainer,
            i = e.popupSubGrpContainer,
            s = e.subGrpContainer,
            e = L.Groups.filter(function(e) {
                return e.Order
            });
        L.PCTemplateUpgrade && (_.showVendorService ? w.setHtmlTemplate(t('#onetrust-pc-sdk div[role="dialog"]')) : w.removeVSUITemplate(t('#onetrust-pc-sdk div[role="dialog"]')));
        for (var a = 0, l = e; a < l.length; a++) {
            var c = l[a],
                d = c.GroupName,
                u = c.CustomGroupId,
                d = N.appendVendorCountElement(c, d),
                p = n.cloneNode(!0),
                p = v(p).el,
                C = "ot-group-id-" + u,
                g = "ot-header-id-" + u,
                h = "ot-desc-id-" + u,
                y = "",
                u = (c.Status === f.ALWAYS_ACTIVE && (y = " ot-status-id-" + u), p.setAttribute("data-optanongroupid", u), p.querySelector("input,button")),
                u = (u && (c.Type !== k.GroupTypes.Stack && u.setAttribute("aria-controls", h), u.setAttribute("aria-labelledby", g + y)), N.setParentGroupName(p, d, g, h), N.setPopupData(c, p), N.setParentGroupDescription(p, c, L, h, C)),
                y = (S.isV2Template ? N.setToggle(p, u, c, C, g) : N.setToggleProps(p, u, c, C, g), this.addCategoryGroupsToParent(t, r, p), N.setSubGroupData(c, p, i, s), L.PCGrpDescLinkPosition === ie.Top),
                d = (c.Type === k.GroupTypes.Stack && y && (u = p.querySelector(A.P_Sub_Grp_Cntr)), y ? u : null);
            N.setVendorListBtn(p, t, o, c, d, L), N.setHostListBtn(p, t, o, c), N.setVendorServiceData(c, p), N.appendHealthSignatureFormToGroup(c, p), _.dataGroupState.push(c)
        }
    }, r.prototype.addCategoryGroupsToParent = function(e, t, o) {
        var n = 0 === t.el.children.length,
            e = !!e("#onetrust-pc-sdk " + A.P_Category_Grp).querySelector(A.P_Category_Item),
            r = (r = t.el.querySelectorAll(A.P_Category_Item + ":not(.ot-vnd-item)"))[r.length - 1];
        n ? t.append(o) : (n = t.el.querySelector(A.P_Li_Hdr) || t.el.querySelector("h3") || t.el.querySelector('p[aria-level="3"]'), !e && n ? m.insertAfter(o, n) : r ? m.insertAfter(o, r) : t.el.insertBefore(o, t.el.firstChild))
    }, r.prototype.appendHealthSignatureFormToGroup = function(e, t) {
        var o;
        b.requireSignatureEnabled && e.needsHealthSignature && (o = A.P_Acc_Container, L.PCLayout.Tab && (o = "#ot-desc-id-" + e.CustomGroupId), t = t.querySelector(o), Zn.getInstance().getHealthSignatureComponent(t, e))
    }, r.prototype.appendVendorCountElement = function(e, t) {
        var o, n, r = -1 < e.SubGroups.findIndex(function(e) {
            return e.IsIabPurpose
        });
        return b.isTcfV2Template && (e.IsIabPurpose || r) && (n = void 0, n = e.Type !== k.GroupTypes.Stack && e.Type !== k.GroupTypes.Bundle && e.Type !== k.GroupTypes.Cookie ? this.getActiveVendorCount(e) : (o = "", o = !e.IsIabPurpose && r ? e.CustomGroupId : e.IabGrpId, this.getActiveVendorCountForStack(o)), t += this.getVendorCountEl(n, e.Type)), t
    }, r.prototype.setPopupData = function(e, t) {
        b.pcName === it && (e.ShowVendorList && b.isIab2orv2Template ? (P.removeChild(t.querySelector("p:not(.ot-always-active)")), P.removeChild(t.querySelector(A.P_Acc_Txt + ":not(" + A.P_Acc_Container + ")")), e.SubGroups.length || S.isV2Template || P.removeChild(t.querySelector(A.P_Sub_Grp_Cntr))) : P.removeChild(t.querySelector(A.P_Acc_Container)))
    }, r.prototype.setVendorServiceData = function(e, t) {
        var o, n = b.pcName;
        _.showVendorService && L.VendorServiceConfig.PCVSCategoryView && (o = A.P_Acc_Txt, n === st && (o = A.P_Desc_Container), n = t.querySelector(o), L.PCAccordionStyle === ce.NoAccordion && (n = t), w.insertVendorServiceHtml(e, n))
    }, r.prototype.jsonAddAboutCookies = function(e) {
        var t = {};
        return t.GroupName = e.AboutCookiesText, t.GroupDescription = e.MainInfoText, t.ShowInPopup = !0, t.Order = 0, t.IsAboutGroup = !0, t
    }, r.prototype.setVendorListBtn = function(e, t, o, n, r, i) {
        var s, a, l = b.pcName;
        n.ShowVendorList ? (s = a = void 0, S.isV2Template ? a = (s = E.vListEl.cloneNode(!0)).querySelector(".category-vendors-list-handler") : s = (a = e.querySelector(".category-vendors-list-handler")).parentElement, a.setAttribute("dir", "ltr"), a.innerHTML = m.getInnerHtmlContent(i.VendorListText), a.setAttribute(this._ariaLabel, L.PCOpensVendorDetailsAlert), a.setAttribute("data-parent-id", n.CustomGroupId), N.setIABLegalLink(a, n, i), S.isV2Template && (a = e, l === st ? a = e.querySelector("" + A.P_Desc_Container) : i.PCenterEnableAccordion && (a = e.querySelector(A.P_Acc_Txt)), a.insertAdjacentElement("beforeend", s)), r && r.insertAdjacentElement("beforebegin", s)) : S.isV2Template || (l !== rt && l !== ot || i.PCenterEnableAccordion ? (l === it || l === rt || l === ot && i.PCenterEnableAccordion) && (n = t("#vendor-list-container"), a = e.querySelector(A.P_Acc_Txt), n && o.querySelector("" + A.P_Content).removeChild(n), S.isV2Template || v(a).el.removeChild(a.querySelector(A.P_Ven_Lst_Cntr))) : P.removeChild(e.querySelector(A.P_Ven_Lst_Cntr)), l !== st && l !== nt) || (r = e.querySelector(A.P_Ven_Lst_Cntr)) && r.parentElement.removeChild(r)
    }, r.prototype.setIABLegalLink = function(e, t, o) {
        var n, r;
        b.isTcfV2Template ? lr.addIllustrationsLink(e, t, t.ShowVendorList) : o.PCGrpDescType === re.UserFriendly && (t = void 0, n = !1, L.BannerRequireExternalLinks && (S.fp.CMPIconSprite && L.OTExternalLinkLogo && !L.BannerExternalLinksLogo && (n = !0, r = I.updateCorrectUrl(L.OTExternalLinkLogo), r = L.BannerExternalLinksLogo ? I.updateCorrectUrl(L.BannerExternalLinksLogo) : r, t = "<svg class='ot-ext-lnk'>\n                            <use href='#" + new URL(r, window.location.origin).pathname.split("/").pop().split(".").shift() + "'></use>\n                            </svg>"), L.BannerRequireExternalLinks) && n && e.insertAdjacentHTML("afterend", m.getInnerHtmlContent(t)), r = L.BannerRequireExternalLinks && !n, e.insertAdjacentHTML("afterend", m.getInnerHtmlContent("<a href='" + L.IabLegalTextUrl + "?lang=" + _.consentLanguage + '\'\n                        rel="noopener noreferrer" ' + (r ? 'class="ot-ext-lnk"' : "") + " target='_blank'>&nbsp;|&nbsp;" + o.PCVendorFullLegalText + '&nbsp;<span class="ot-scrn-rdr">\n                        ' + L.NewWinTxt + "</span></a>")))
    }, r.prototype.setHostListBtn = function(e, t, o, n) {
        var r, i = b.pcName,
            s = !1,
            a = (L.showCookieList && (s = -1 < P.findIndex(U(n.SubGroups, [n]), function(e) {
                return -1 === _t.indexOf(e.Type) && e.FirstPartyCookies.length
            })), _.showGeneralVendors && n.GeneralVendorsIds && n.GeneralVendorsIds.length);
        !_.showVendorService && (L.showCookieList || _.showGeneralVendors) && (n.ShowHostList || s || a) ? (s = void 0, S.isV2Template ? (s = (a = E.cListEl.cloneNode(!0)).querySelector(".category-host-list-handler"), r = e, i === st ? r = e.querySelector("" + A.P_Desc_Container) : L.PCenterEnableAccordion && (r = e.querySelector(A.P_Acc_Txt)), r.insertAdjacentElement("beforeend", a)) : s = e.querySelector(".category-host-list-handler"), N.setcListHandler(s, n)) : N.setHostListVendorList(t, o, e)
    }, r.prototype.setcListHandler = function(e, t) {
        var o, n;
        e && (o = (n = N.setcListHeaderTitleAndScreenReader())[0], n = n[1], e.setAttribute("dir", "ltr"), e.innerHTML = m.getInnerHtmlContent(o), e.setAttribute(this._ariaLabel, t.GroupName + " - " + n), e.setAttribute("data-parent-id", t.CustomGroupId))
    }, r.prototype.setcListHeaderTitleAndScreenReader = function() {
        var e, t = _.showTrackingTech ? (e = L.AdditionalTechnologiesConfig.PCTechDetailsText, L.AdditionalTechnologiesConfig.PCTechDetailsAriaLabel) : _.showGeneralVendors ? (e = L.GroupGenVenListLabel, L.PCenterVendorListScreenReader) : (e = L.ThirdPartyCookieListText, L.PCOpensCookiesDetailsAlert);
        return [e, t]
    }, r.prototype.setHostListVendorList = function(e, t, o) {
        var n;
        b.pcName === it ? (e = e("#vendor-list-container"), n = o.querySelector(A.P_Acc_Txt), e && t.querySelector("" + A.P_Content).removeChild(e), n.querySelector(A.P_Host_Lst_cntr) && v(n).el.removeChild(n.querySelector(A.P_Host_Lst_cntr))) : (t = o.querySelector(A.P_Host_Lst_cntr)) && t.parentElement.removeChild(t)
    }, r.prototype.setSubGroupData = function(e, t, o, n) {
        var r;
        0 < e.SubGroups.length && e.ShowSubgroup && (r = b.pcName === it && e.ShowVendorList && b.isIab2orv2Template && !L.PCTemplateUpgrade, N.setSubGrps(e, r ? o : n, t, L))
    }, r.prototype.setSubGrps = function(t, o, n, r) {
        var e;
        b.pcName === it && t.ShowVendorList && b.isIab2orv2Template && !L.PCTemplateUpgrade && (e = n.querySelector(A.P_Sub_Grp_Cntr)).parentElement.removeChild(e), t.SubGroups.forEach(function(e) {
            N.setSubGroups({
                group: t,
                subgroup: e,
                grpEl: n,
                subGrpEl: o,
                json: r
            })
        })
    }, r.prototype.setSubGroups = function(e) {
        var t, o = e.group,
            n = e.subgroup,
            r = e.grpEl,
            i = e.subGrpEl,
            e = e.json,
            s = b.pcName,
            a = N.getRemoveConsentToggle(n),
            i = (S.isV2Template ? i : i.el).cloneNode(!0),
            l = i.querySelector(A.P_Subgp_ul),
            c = i.querySelector(A.P_Subgrp_li).cloneNode(!0),
            d = n.CustomGroupId,
            u = "ot-sub-group-id-" + d,
            p = D.getGrpStatus(n).toLowerCase(),
            C = c.querySelector('.cookie-subgroup>h4, .cookie-subgroup>h5,\n            .cookie-subgroup>h6, .ot-subgrp>h4,\n            .ot-subgrp>h5, .ot-subgrp>h6, .cookie-subgroup>p[aria-level="4"], .cookie-subgroup>p[aria-level="5"],\n            .cookie-subgroup>p[aria-level="6"], .ot-subgrp>p[aria-level="4"],\n            .ot-subgrp>p[aria-level="5"], .ot-subgrp>p[aria-level="6"]'),
            g = c.querySelector(A.P_Tgl_Cntr),
            d = (c.setAttribute("data-optanongroupid", d), S.isV2Template ? ((t = N.getInputEle()).querySelector("input").setAttribute("data-optanongroupid", d), t.querySelector("input").classList.add("cookie-subgroup-handler"), t = t.cloneNode(!0), g.insertAdjacentElement("beforeend", t)) : (t = c.querySelector(".ot-toggle")).querySelector("input").setAttribute("data-optanongroupid", d), v(i.querySelector(A.P_Subgp_ul)).html(""), N.addSubgroupName(n, C), N.setDataIfVendorServiceEnabled(C, c, t), t.querySelector("input").setAttribute("id", u), t.querySelector("input").setAttribute(this._ariaLabel, n.GroupName), t.querySelector("label").setAttribute("for", u), N.setSubGroupDescription({
                json: e,
                group: o,
                subgroup: n,
                subGroupClone: c
            }), b.isTcfV2Template && lr.addIllustrationsLink(c, n, o.ShowVendorList, !0), U(Ot, Et));
        o.ShowSubgroupToggle && -1 < d.indexOf(n.Type) ? N.setSubGroupToggle({
            id: u,
            subGroupClone: c,
            group: o,
            subgroup: n,
            toggleGroup: g
        }) : p === f.ALWAYS_ACTIVE && (o.ShowSubgroupToggle || -1 === Dt.indexOf(n.Type)) || (a = !0), N.setSubGroupsProperties({
            removeConsentToggle: a,
            subGroupToggle: t,
            subGroupClone: c,
            status: p,
            subgroup: n,
            grpEl: r,
            pcName: s,
            json: e,
            subGrpElClone: i,
            ulParentContainerEle: l
        })
    }, r.prototype.getRemoveConsentToggle = function(e) {
        var t = !1;
        return t = b.isIab2orv2Template && e.Type === k.GroupTypes.Pur && !e.HasConsentOptOut ? !0 : t
    }, r.prototype.addSubgroupName = function(e, t) {
        var o, n = e.GroupName;
        b.isTcfV2Template && e.IsIabPurpose && (o = this.getActiveVendorCount(e), n += this.getVendorCountEl(o, e.Type)), v(t).html(n)
    }, r.prototype.setDataIfVendorServiceEnabled = function(e, t, o) {
        var n;
        _.showVendorService && ((n = document.createElement("div")).classList.add("ot-acc-hdr"), e.classList.add("ot-cat-header"), n.appendChild(e), e = "afterbegin", L.PCCategoryStyle === ve.Toggle && (e = "beforeend"), n.insertAdjacentElement(e, o), t.removeChild(t.querySelector(A.P_Subgrp_Tgl_Cntr)), t.insertAdjacentElement("afterbegin", n))
    }, r.prototype.setSubGroupDescription = function(e) {
        var t, o = e.json,
            n = e.group,
            r = e.subgroup,
            e = e.subGroupClone,
            i = b.pcName,
            s = o.PCGrpDescType === re.Legal,
            i = i === it && n.ShowVendorList && b.isIab2orv2Template,
            a = v(e.querySelector(A.P_Subgrp_Desc));
        i ? (t = r.DescriptionLegal && s ? r.DescriptionLegal : r.GroupDescription, a.html(t)) : (t = V.safeFormattedGroupDescription(r), i = !1, -1 < Vt.indexOf(r.Type) && s && (i = !0, t = r.DescriptionLegal), o.PCenterEnableAccordion && i || (a = v(e.querySelector("p"))), n.ShowSubGroupDescription ? a.html(t) : a.html(""))
    }, r.prototype.setSubGroupToggle = function(e) {
        var t = e.id,
            o = e.subGroupClone,
            n = e.group,
            r = e.subgroup,
            e = e.toggleGroup,
            i = V.isGroupActive(r),
            n = (N.setSubGroupActive({
                group: n,
                subgroup: r,
                subGroupClone: o
            }, i), e.querySelector(".ot-label-status"));
        L.PCShowConsentLabels ? n.innerHTML = m.getInnerHtmlContent(i ? L.PCActiveText : L.PCInactiveText) : P.removeChild(n), b.legIntSettings.PAllowLI && r.Type === k.GroupTypes.Pur && r.HasLegIntOptOut && (b.legIntSettings.PShowLegIntBtn ? N.setLegIntButton(o, r) : (i = e.cloneNode(!0), e.insertAdjacentElement("afterend", i), n = i.querySelector(".ot-label-status"), (o = i.querySelector("input")).setAttribute("id", t + "-leg-out"), i.querySelector("label").setAttribute("for", t + "-leg-out"), r.IsLegIntToggle = !0, e = V.isGroupActive(r), L.PCShowConsentLabels ? n.innerHTML = m.getInnerHtmlContent(e ? L.PCActiveText : L.PCInactiveText) : P.removeChild(n), P.setCheckedAttribute(null, o, e), r.IsLegIntToggle = !1))
    }, r.prototype.setSubGroupActive = function(e, t) {
        var o;
        t && (t = e.group, o = e.subgroup, e = e.subGroupClone, t = D.getGrpStatus(t).toLowerCase(), e.querySelector("input").setAttribute("checked", ""), t === f.ALWAYS_ACTIVE) && -1 === Vt.indexOf(o.Type) && (e.querySelector("input").disabled = !0, e.querySelector("input").setAttribute("disabled", "true"))
    }, r.prototype.setSubGroupsProperties = function(e) {
        var t = e.removeConsentToggle,
            o = e.subGroupToggle,
            n = e.subGroupClone,
            r = e.status,
            i = e.subgroup,
            s = e.grpEl,
            a = e.pcName,
            l = e.json,
            c = e.subGrpElClone,
            e = e.ulParentContainerEle;
        t && (o.classList.add("ot-hide-tgl"), o.querySelector("input").setAttribute(this._ariaHidden, "true")), r !== f.ALWAYS_ACTIVE && r !== f.ALWAYS_INACTIVE || t || (o && o.parentElement.removeChild(o), (t = n.querySelector(A.P_Tgl_Cntr)) && t.classList.add("ot-always-active-subgroup"), N.setAlwaysActive(n, !0, r === f.ALWAYS_INACTIVE)), "COOKIE" === i.Type && -1 !== i.Parent.indexOf("STACK") && d(c, "display: none;"), v(e).append(n), S.isV2Template ? (o = s, "otPcTab" === a ? o = s.querySelector("" + A.P_Desc_Container) : l.PCenterEnableAccordion && (o = s.querySelector(A.P_Acc_Txt)), o.insertAdjacentElement("beforeend", c)) : (t = s.querySelector(A.P_Category_Item + " " + A.P_Ven_Lst_Cntr)) && t.insertAdjacentElement("beforebegin", c), _.showVendorService && L.VendorServiceConfig.PCVSCategoryView && w.insertVendorServiceHtml(i, e)
    }, r.prototype.getInputEleForCategory = function(e) {
        return _.showVendorService && L.PCCategoryStyle === ve.Checkbox && e.classList.add("ot-checkbox-consent"), N.getInputEle()
    }, r.prototype.getInputEle = function() {
        return !b.isIab2orv2Template && L.PCTemplateUpgrade ? Yn() : E.toggleEl.cloneNode(!0)
    }, r.prototype.setToggle = function(e, t, o, n, r) {
        var i = N.getInputEleForCategory(e),
            s = (i.querySelector("input").classList.add("category-switch-handler"), i.querySelector("input")),
            a = e.querySelector(A.P_Category_Header),
            l = V.isGroupActive(o),
            c = [f.ALWAYS_ACTIVE, f.ALWAYS_INACTIVE].includes(D.getGrpStatus(o).toLowerCase()),
            d = o.OptanonGroupId.toString(),
            u = k.GroupTypes,
            p = !0;
        !b.isIab2orv2Template || o.Type !== u.Pur && o.Type !== u.Stack || o.HasConsentOptOut || (p = !1), v(i.querySelector("label")).attr("for", n), v(i.querySelector(".ot-label-txt")).html(o.GroupName);
        b.legIntSettings.PAllowLI && o.Type === u.Pur && o.HasLegIntOptOut && (b.legIntSettings.PShowLegIntBtn ? N.setLegIntButton(e, o, !0, t) : (u = i.cloneNode(!0), o.IsLegIntToggle = !0, t = V.isGroupActive(o), C = u.querySelector(".ot-label-status"), L.PCShowConsentLabels ? C.innerHTML = m.getInnerHtmlContent(t ? L.PCActiveText : L.PCInactiveText) : P.removeChild(C), o.IsLegIntToggle = !1, V.setInputID(u.querySelector("input"), n + "-leg-out", d, t, r), v(u.querySelector("label")).attr("for", n + "-leg-out"), a.insertAdjacentElement("afterend", u)));
        var C = i.querySelector(".ot-label-status"),
            d = (L.PCShowConsentLabels ? C.innerHTML = m.getInnerHtmlContent(l ? L.PCActiveText : L.PCInactiveText) : P.removeChild(C), L.PCCategoryStyle === ve.Toggle);
        this.hideToggleContainer(c, p, d, i), p && this.setAlwaysActiveOrToggleInput(o, e, i, s, n, r), N.setNoAccordionHeader(e, c)
    }, r.prototype.setNoAccordionHeader = function(e, t) {
        var o, n, r, i;
        !b.isIab2orv2Template && L.PCTemplateUpgrade && (o = L.PCCategoryStyle === ve.Checkbox, L.PCAccordionStyle === ce.NoAccordion) && o && ((o = document.createElement("div")).classList.add("ot-acc-hdr"), n = e.querySelector(".ot-chkbox"), r = e.querySelector(".ot-always-active"), i = e.querySelector(A.P_Category_Header), n && o.appendChild(n), o.appendChild(i), t && o.appendChild(r), e.insertBefore(o, e.firstChild))
    }, r.prototype.hideToggleContainer = function(e, t, o, n) {
        !e && t || !o || (n.classList.add("ot-hide-tgl"), n.querySelector("input").setAttribute(this._ariaHidden, "true"))
    }, r.prototype.setAlwaysActiveOrToggleInput = function(e, t, o, n, r, i) {
        var s = "always active" === D.getGrpStatus(e).toLowerCase(),
            a = "always inactive" === D.getGrpStatus(e).toLowerCase(),
            l = L.PCCategoryStyle === ve.Toggle,
            c = e.OptanonGroupId.toString(),
            e = V.isGroupActive(e),
            d = t.querySelector(A.P_Category_Header);
        !b.isIab2orv2Template && L.PCTemplateUpgrade ? ((s || a) && L.PCShowAlwaysActiveToggle && (N.setAlwaysActive(t, !1, a), o.querySelector("input").setAttribute("disabled", "true")), s && l || N.insertAccordionInputHeader(d, o), V.setInputID(n, r, c, e, i), N.insertAccordionPointer(t, d)) : (N.insertAccordionPointer(t, d), s || a ? L.PCShowAlwaysActiveToggle && N.setAlwaysActive(t, !1, a) : (N.insertAccordionInputHeader(d, o), V.setInputID(n, r, c, e, i)))
    }, r.prototype.setOptOutSignalVisibility = function(e) {
        var t = b.gpcEnabled && b.gpcForAGrpEnabled,
            o = O.isAlertBoxClosedAndValid() && V.isAnyGroupOptedOut();
        L.PCShowOptOutSignal && (t || o || b.previewMode) ? e.classList.remove("ot-hide") : e.classList.add("ot-hide")
    }, r.prototype.setOptOutSignalNotification = function(e) {
        e = I.createOptOutSignalElement(e, !0);
        N.setOptOutSignalVisibility(e)
    }, r.prototype.insertAccordionInputHeader = function(e, t) {
        var o = N.getPositionForInputEle();
        e.insertAdjacentElement(o, t)
    }, r.prototype.getPositionForInputEle = function() {
        var e = "beforebegin";
        return e = !b.isIab2orv2Template && L.PCTemplateUpgrade && L.PCCategoryStyle !== ve.Toggle ? e : "afterend"
    }, r.prototype.insertAccordionPointer = function(e, t) {
        var o, n;
        e.classList.add("ot-vs-config"), L.PCenterEnableAccordion && (!b.isIab2orv2Template && L.PCTemplateUpgrade ? (e = e.querySelector(A.P_Acc_Header), o = n = void 0, n = (L.PCAccordionStyle === ce.Caret ? (o = "beforeend", E.arrowEl) : (o = L.PCCategoryStyle === ve.Checkbox ? "beforeend" : "afterbegin", E.plusMinusEl)).cloneNode(!0), e.insertAdjacentElement(o, n)) : L.PCAccordionStyle === ce.Caret ? t.insertAdjacentElement("afterend", E.arrowEl.cloneNode(!0)) : t.insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)))
    }, r.prototype.setToggleProps = function(e, t, o, n, r) {
        var i = e.querySelectorAll("input:not(.cookie-subgroup-handler)"),
            s = e.querySelectorAll("label"),
            a = V.isGroupActive(o),
            l = o.CustomGroupId,
            c = e.querySelector(".label-text");
        c && v(c).html(o.GroupName);
        for (var d, u, p, C, g = 0; g < i.length; g++) s[g] && v(s[g]).attr("for", n), 2 <= i.length && 0 === g ? v(i[g]).attr("id", n + "-toggle") : (d = this.canShowConsentToggle(o), this.canShowLegIntToggle(o) && (b.legIntSettings.PShowLegIntBtn ? N.setLegIntButton(e, o, !0, t) : (C = (u = e.querySelector(A.P_Tgl_Cntr + ":not(" + A.P_Subgrp_Tgl_Cntr + ")") || e.querySelector(".ot-toggle")).cloneNode(!0), u.insertAdjacentElement("afterend", C), u = C.querySelector("input"), o.IsLegIntToggle = !0, p = V.isGroupActive(o), o.IsLegIntToggle = !1, V.setInputID(u, n + "-leg-out", l, p, r), v(C.querySelector("label")).attr("for", n + "-leg-out"), P.removeChild(C.querySelector(A.P_Arrw_Cntr)))), u = D.getGrpStatus(o).toLowerCase() === f.ALWAYS_ACTIVE, p = D.getGrpStatus(o).toLowerCase() === f.ALWAYS_INACTIVE, !u && d || (C = i[g].closest(".ot-toggle")) && (C.classList.add("ot-hide-tgl"), C.querySelector("input").setAttribute(this._ariaHidden, !0)), d && (u && N.setAlwaysActive(e, !1, p), V.setInputID(i[g], n, l, a, r)))
    }, r.prototype.canShowConsentToggle = function(e) {
        var t = !0,
            o = k.GroupTypes;
        return t = !b.isIab2orv2Template || e.Type !== o.Pur && e.Type !== o.Stack || e.HasConsentOptOut ? t : !1
    }, r.prototype.canShowLegIntToggle = function(e) {
        var t = k.GroupTypes;
        return b.legIntSettings.PAllowLI && e.Type === t.Pur && e.HasLegIntOptOut
    }, r.prototype.setAlwaysActive = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = !1);
        var n, r = b.pcName;
        r === it || r === st || t ? (r = e.querySelector(A.P_Tgl_Cntr)) && r.insertAdjacentElement("afterbegin", v("<div class='ot-always-active'>" + (o ? L.AlwaysInactiveText : L.AlwaysActiveText) + "</div>", "ce").el) : (r = "ot-status-id-" + (r = null == (n = r = (t = e.querySelector(A.P_Category_Header)).id) ? void 0 : n.split("-")[3]), !S.isV2Template && L.PCenterEnableAccordion && (r = "ot-status-id-" + (r = null == (n = r = (t = e.querySelector(A.P_Arrw_Cntr)).id) ? void 0 : n.split("-")[3])), v(t).el.insertAdjacentElement("afterend", v('<div id="' + r + "\" class='ot-always-active'>" + (o ? L.AlwaysInactiveText : L.AlwaysActiveText) + "</div>", "ce").el)), L.PCenterEnableAccordion ? (n = e.querySelector(A.P_Acc_Header)) && n.classList.add("ot-always-active-group") : ((t = e.querySelector("" + A.P_Desc_Container)) && t.classList.add("ot-always-active-group"), e.classList.add("ot-always-active-group"))
    }, r.prototype.setPcTabLayout = function(e, t, o) {
        var n, r = e(".ot-tab-desc");
        "otPcTab" === b.pcName && (o && e("#onetrust-pc-sdk " + A.P_Category_Grp).insertAdjacentElement("afterbegin", o), r && 640 < window.innerWidth && v(r).append(t.querySelectorAll("#onetrust-pc-sdk " + A.P_Desc_Container)), L.IsIabEnabled ? (n = e(A.P_Desc_Container + " .category-vendors-list-handler")) && (n.setAttribute("dir", "ltr"), n.innerHTML = m.getInnerHtmlContent(L.VendorListText)) : (n = e(A.P_Desc_Container + " .category-vendors-list-handler")) && n.parentElement.removeChild(n))
    }, r.prototype.setVendorListClass = function(e, t) {
        S.isV2Template ? L.PCAccordionStyle === ce.Caret && (v(e("#onetrust-pc-sdk " + A.P_Vendor_List)).addClass("ot-enbl-chr"), L.PCenterEnableAccordion) && v(e("#onetrust-pc-sdk " + A.P_Content)).addClass("ot-enbl-chr") : v(t.querySelector(A.P_Sub_Grp_Cntr)).remove()
    }, r.prototype.setPCHeader = function(e, t) {
        var o = b.pcName,
            n = e(A.P_Li_Hdr) || t.querySelector(A.P_Li_Hdr);
        b.legIntSettings.PAllowLI && b.grpContainLegalOptOut && b.isIab2orv2Template && !b.legIntSettings.PShowLegIntBtn ? (n.querySelector("span:first-child").innerText = L.ConsentText, n.querySelector("span:last-child").innerText = L.LegitInterestText, S.isV2Template && (n.querySelector("span:first-child").innerText = L.PCenterConsentText, n.querySelector("span:last-child").innerText = L.PCenterLegIntColumnHeader), L.PCenterEnableAccordion && n ? n.classList.add("ot-leg-border-color") : "otPcList" === o && t.insertAdjacentElement("afterbegin", n)) : (P.removeChild(e("#onetrust-pc-sdk " + A.P_Li_Hdr)), P.removeChild(t.querySelector(A.P_Li_Hdr)))
    };
    var N, ur = r;

    function r() {
        this._ariaHidden = "aria-hidden", this._ariaLabel = "aria-label"
    }
    gr.prototype.showBanner = function() {
        var e = b.bannerName,
            t = v(this.El);
        l.skipAddingHTML && "none" === getComputedStyle(t.el[0]).getPropertyValue("display") && e !== Xe && e !== Je && e !== $e ? t.css("display: block;") : L.BAnimation === Te.SlideIn ? this.slideInAnimation(t, e) : L.BAnimation === Te.FadeIn && t.addClass("ot-fade-in")
    }, gr.prototype.insertAlertHtml = function() {
        L.IsGPPEnabled && Ds.setCmpDisplayStatus("visible");

        function e(e) {
            return t.querySelector(e)
        }
        var t = document.createDocumentFragment(),
            o = document.createElement("div"),
            o = (v(o).html(xs.bannerGroup.html), o.querySelector("#onetrust-banner-sdk"));
        this.setAriaModalForBanner(o), S.fp.CookieV2SSR ? (v(t).append(o), this.setBannerLinkAttributes(e), this._rejectBtn = e(mn), this._acceptBtn = e(Sn)) : this.insertHtmlForNonSSRFlow(o, t, e, function(e) {
            return t.querySelectorAll(e)
        }), this.ssrAndNonSSRCommonHtml(t)
    }, gr.prototype.insertHtmlForNonSSRFlow = function(e, t, o, n) {
        var r, i, s = b.bannerName;
        xs.bannerGroup && (L.BannerRelativeFontSizesToggle && v(e).addClass("otRelFont"), (L.BInitialFocus || L.BInitialFocusLinkAndButton) && e.setAttribute("tabindex", "0"), L.useRTL && v(e).attr("dir", "rtl"), b.isIab2orv2Template && L.BannerDPDDescription.length && v(e).addClass("ot-iab-2"), (r = L.BannerPosition) && ("bottom-left" === r ? v(e).addClass("ot-bottom-left") : "bottom-right" === r ? v(e).addClass("ot-bottom-right") : v(e).addClass(r)), v(t).append(e), this.setBannerData(o), r = this.setIAB2HtmlData(o), this.setAcceptAndRejectBtnHtml(o), this.setButtonsOrder(o), t = this.htmlForBannerButtons(e, o, n), n = L.showBannerCloseButton, i = L.BCloseButtonType === Pe.Link, this.setWidthForFlatBanner(o, r, t), n && s === Qe && b.isIab2orv2Template && !i && ((t = o(".banner-close-btn-container")).parentElement.removeChild(t), v(e).el.insertAdjacentElement("beforeEnd", t), v(o("#onetrust-banner-sdk .ot-sdk-container")).addClass("ot-top-cntr")), this.setBannerOptions(o, r), this.setBannerLogo(e, o))
    }, gr.prototype.setBannerOptions = function(e, t) {
        var o = this,
            n = b.bannerName,
            r = this.isCmpEnabled(),
            i = [{
                type: "purpose",
                titleKey: "BannerPurposeTitle",
                descriptionKey: "BannerPurposeDescription",
                identifier: "purpose-option"
            }, {
                type: "feature",
                titleKey: "BannerFeatureTitle",
                descriptionKey: "BannerFeatureDescription",
                identifier: "feature-option"
            }, {
                type: "information",
                titleKey: "BannerInformationTitle",
                descriptionKey: "BannerInformationDescription",
                identifier: "information-option"
            }],
            s = v(e(this._bannerOptionsSelector)).el;
        r ? (n === Ze ? this.setFloatingRoundedIconBannerCmpOptions(e, i) : (this.setCmpBannerOptions(e, i), n === et && t.el.insertAdjacentElement("beforeend", s)), v(window).on("resize", function() {
            window.innerWidth <= 896 && o.setBannerOptionContent()
        })) : (b.bannerName === Qe && (s = v(e(".banner-options-card")).el), P.removeChild(s))
    }, gr.prototype.setWidthForFlatBanner = function(e, t, o) {
        var n = b.bannerName,
            r = L.showBannerCloseButton,
            i = this.hasNoActionButtons();
        n === Je && (b.isIab2orv2Template && (t.removeClass("ot-sdk-eight"), this.setOrderForAcceptAndCookieSettings(e, o)), r && !i && b.isIab2orv2Template ? t.addClass("ot-sdk-nine") : r && i ? t.addClass("ot-sdk-eleven") : !r && i ? t.addClass("ot-sdk-twelve") : r || i || !b.isIab2orv2Template || (t.addClass("ot-sdk-ten"), v(e(this._btnGrpParentSelector)).addClass("ot-sdk-two"), v(e(this._btnGrpParentSelector)).removeClass("ot-sdk-three")))
    }, gr.prototype.setOrderForAcceptAndCookieSettings = function(e, t) {
        L.PCTemplateUpgrade && S.fp.WebButtonCustomisations || (L.showBannerAcceptButton && t.insertAdjacentElement("afterbegin", this._acceptBtn), L.showBannerCookieSettings && t.insertAdjacentElement("beforeend", e(vn)))
    }, gr.prototype.hasNoActionButtons = function() {
        var e = !L.showBannerAcceptButton && !L.showBannerCookieSettings && !L.BannerShowRejectAllButton;
        return b.bannerName === et ? e && !L.BShowSaveBtn : e
    }, gr.prototype.htmlForBannerButtons = function(e, t, o) {
        var n = b.bannerName,
            r = (this.hasNoActionButtons() && t(this._btnGrpParentSelector).parentElement.removeChild(t(this._btnGrpParentSelector)), L.showBannerCloseButton),
            i = v(o(".banner-close-button")).el,
            s = t("#onetrust-button-group"),
            a = L.BCloseButtonType === Pe.Link;
        if (r)
            for (l = 0; l < i.length; l++) a ? (v(i[l]).html(L.BContinueText), v(e).addClass("ot-close-btn-link"), v(i[l]).addClass("ot-close-link"), v(i[l]).removeClass("onetrust-close-btn-ui"), v(i[l]).removeClass("ot-close-icon"), n !== Qe && n !== Ze || (s.insertAdjacentElement("afterbegin", t(".onetrust-close-btn-handler").parentElement), v(i[l]).attr("tabindex", "1"))) : (I.setCloseIcon(t("#onetrust-banner-sdk .ot-close-icon")), v(i[l]).el.setAttribute(mt, L.BannerCloseButtonText || "Close Cookie Banner"));
        else {
            for (var l = 0; l < i.length; l++) v(i[l].parentElement).el.removeChild(i[l]);
            n !== Je && n !== Ze || P.removeChild(t("#onetrust-close-btn-container-mobile"))
        }
        return s
    }, gr.prototype.setButtonsOrder = function(e) {
        if (this.checkButtonOrderPreconditions()) {
            var t = e("#onetrust-button-group");
            if (t) {
                t.classList.add("ot-button-order-container");
                var o, n, r = new Map;
                if (L.showBannerAcceptButton && (o = e(Sn)) && (o.classList.add("ot-button-order-" + L.BannerBO.ACCEPT_ALL), r.set(L.BannerBO.ACCEPT_ALL, o)), L.BannerShowRejectAllButton && (o = e(mn)) && (o.classList.add("ot-button-order-" + L.BannerBO.REJECT_ALL), r.set(L.BannerBO.REJECT_ALL, o)), L.BShowSaveBtn && (o = e(".ot-bnr-save-handler")) && (n = void 0 !== L.BannerBO.SAVE_PREFERENCE && 0 <= L.BannerBO.SAVE_PREFERENCE ? L.BannerBO.SAVE_PREFERENCE : L.BannerBO.COOKIE_SETTINGS, o.classList.add("ot-button-order-" + n), r.set(n, o)), L.showBannerCookieSettings && this.addCookieSettingsButtonsOrder(e, r), !(r.size <= 0)) {
                    t.innerHTML = "";
                    for (var i = Array.from(r.keys()).sort(function(e, t) {
                            return e - t
                        }), s = 0; s < i.length; s++) {
                        var a = r.get(i[s]);
                        a && t.appendChild(a)
                    }
                }
            }
        }
    }, gr.prototype.checkButtonOrderPreconditions = function() {
        return !(!L.PCTemplateUpgrade || !S.fp.WebButtonCustomisations || (this._isValidButtonOrderConfig = this.checkButtonsOrderValidation(), !this._isValidButtonOrderConfig))
    }, gr.prototype.checkButtonsOrderValidation = function() {
        var e;
        return !(L.BShowSaveBtn && void 0 === L.BannerBO.SAVE_PREFERENCE && void 0 === L.BannerBO.COOKIE_SETTINGS || L.showBannerAcceptButton && void 0 === L.BannerBO.ACCEPT_ALL || L.BannerShowRejectAllButton && void 0 === L.BannerBO.REJECT_ALL || (e = this.isFourButtonsConfigured(), L.showBannerCookieSettings && void 0 === L.BannerBO.COOKIE_SETTINGS && !e))
    }, gr.prototype.addCookieSettingsButtonsOrder = function(e, t) {
        var e = e(vn),
            o = b.bannerName === et,
            n = this.isFourButtonsConfigured(),
            r = o && n ? Number.MAX_VALUE : L.BannerBO.COOKIE_SETTINGS;
        e && (o && n || e.classList.add("ot-button-order-" + r), t.set(r, e))
    }, gr.prototype.isFourButtonsConfigured = function() {
        return L.BannerShowRejectAllButton && L.showBannerAcceptButton && L.showBannerCookieSettings && L.BShowSaveBtn
    }, gr.prototype.setAcceptAndRejectBtnHtml = function(e) {
        var t = b.bannerName,
            e = (L.showBannerAcceptButton ? (this._acceptBtn = e(Sn), v(this._acceptBtn).html(L.AlertAllowCookiesText), t !== $e || L.showBannerCookieSettings || L.BannerShowRejectAllButton || v(this._acceptBtn.parentElement).addClass("accept-btn-only")) : P.removeChild(e(Sn)), L.BannerShowRejectAllButton && L.BannerRejectAllButtonText.trim() ? (this._rejectBtn = e(mn), v(this._rejectBtn).html(L.BannerRejectAllButtonText), e(this._btnGrpParentSelector).classList.add("has-reject-all-button")) : (P.removeChild(e(mn)), P.removeChild(e("#onetrust-reject-btn-container"))), v(e(vn)));
        L.showBannerCookieSettings ? (e.html(L.AlertMoreInfoText), e.attr("aria-label", L.AlertMoreInfoTextDialog), L.BannerSettingsButtonDisplayLink && e.addClass("cookie-setting-link"), t !== $e || L.showBannerAcceptButton || e.addClass("cookie-settings-btn-only")) : P.removeChild(e.el)
    }, gr.prototype.setIAB2HtmlData = function(e) {
        var t = b.bannerName,
            o = (b.isIab2orv2Template && L.BannerDPDDescription.length && t !== et ? (v(e(".ot-dpd-container .ot-dpd-title")).html(L.BannerDPDTitle), v(e(".ot-dpd-container .ot-dpd-desc")).html(L.BannerDPDDescription.join(",&nbsp;"))) : P.removeChild(e(".ot-dpd-container")), v(e(this._otGrpContainerSelector))),
            t = (b.isIab2orv2Template && L.BannerAdditionalDescription.trim() && this.setAdditionalDesc(e), b.isIab2orv2Template && L.BannerDPDDescription.length ? t !== et ? v(e(".ot-dpd-container .ot-dpd-desc")) : o : v(e(pr.POLICY_TEXT_SELECTOR)));
        return L.IsIabEnabled && L.BannerIABPartnersLink && t.append('<button class="ot-link-btn onetrust-vendors-list-handler">\n        ' + L.BannerIABPartnersLink + "\n        </button>"), o
    }, gr.prototype.setBannerData = function(e) {
        var t;
        L.BannerTitle ? (v(e("#onetrust-policy-title")).html(L.BannerTitle), v(e('[role="dialog"]')).attr(mt, L.BannerTitle)) : (P.removeChild(e("#onetrust-policy-title")), v(e("#onetrust-banner-sdk")).addClass("ot-wo-title"), v(e('[role="dialog"]')).attr(mt, L.AriaPrivacy)), !L.IsIabEnabled && l.showGeneralVendors && L.BannerNonIABVendorListText && ((t = document.createElement("div")).setAttribute("id", "ot-gv-link-ctnr"), v(t).html('<button class="ot-link-btn ot-gv-list-handler">' + L.BannerNonIABVendorListText + "</button>"), v(e("#onetrust-policy")).el.appendChild(t)), v(e(pr.POLICY_TEXT_SELECTOR)).html(L.AlertNoticeText), this.setBannerLinkAttributes(e)
    }, gr.prototype.setBannerLinkAttributes = function(e) {
        var t, o;
        v(e(this.cookiePolicyLinkSelector)).length && (t = v(e(pr.POLICY_TEXT_SELECTOR + " .ot-cookie-policy-link")), e = v(e(pr.POLICY_TEXT_SELECTOR + " .ot-imprint-link")), o = "noopener noreferrer", L.BShowPolicyLink && t && (t.attr(mt, L.BCookiePolicyLinkScreenReader), t.attr("rel", o), t.attr("target", "_blank")), L.BShowImprintLink) && e && (e.attr(mt, L.BImprintLinkScreenReader), e.attr("rel", o), e.attr("target", "_blank"))
    }, gr.prototype.isCmpEnabled = function() {
        return L.BannerPurposeTitle || L.BannerPurposeDescription || L.BannerFeatureTitle || L.BannerFeatureDescription || L.BannerInformationTitle || L.BannerInformationDescription
    }, gr.prototype.ssrAndNonSSRCommonHtml = function(t) {
        function e(e) {
            return t.querySelector(e)
        }

        function o(e) {
            return t.querySelectorAll(e)
        }
        var n, r = this,
            i = this.isCmpEnabled(),
            s = (this.setOptOutSignalNotification(e), "[VENDOR_NUMBER]"),
            a = v(e(pr.POLICY_TEXT_SELECTOR)).html(),
            s = (b.isIab2orv2Template && -1 < a.indexOf(s) && (n = '<span class="ot-tcf2-vendor-count ot-text-bold">' + b.tcf2ActiveVendors.all.toString() + "</span>", a = I.replaceTextFromString(s, a, n), v(e(pr.POLICY_TEXT_SELECTOR)).html(a)), v(e("#onetrust-banner-sdk")).attr("role", "region"), L.BRegionAriaLabel && v(e("#onetrust-banner-sdk")).attr(mt, L.BRegionAriaLabel), b.bannerName === et && S.moduleInitializer.IsSuppressPC && (l.dataGroupState = L.Groups.filter(function(e) {
                return e.Order
            })), I.addExternalIconForLinks(o), b.bannerName === et && (this._fourBtns = this.isFourButtonsConfigured(), this._saveBtn = e(".ot-bnr-save-handler"), this._settingsBtn = e(vn), this._btnsCntr = e(".banner-actions-container"), L.BShowSaveBtn ? v(this._saveBtn).html(L.BSaveBtnTxt) : (P.removeChild(this._saveBtn), this._saveBtn = null), I.insertFooterLogo(o(".ot-bnr-footer-logo a")), this._descriptCntr = e(".ot-cat-lst"), this.setBannerBtn(), window.addEventListener("resize", function() {
                r.setBannerBtn()
            }), this._fourBtns && v(e("#onetrust-banner-sdk")).addClass("has-reject-all-button"), this.insertGrps(e)), I.replaceHeadings(t), document.createElement("div"));
        v(s).append(t), b.ignoreInjectingHtmlCss || (v("#onetrust-consent-sdk").append(s.firstChild), i && this.setBannerOptionContent()), this.setBnrBtnGrpAlignment()
    }, gr.prototype.setAriaModalForBanner = function(e) {
        L.ForceConsent && e.querySelector('[role="dialog"]').setAttribute("aria-modal", "true")
    }, gr.prototype.setBnrBtnGrpAlignment = function() {
        var e = v(this._otGrpContainerSelector).el,
            t = v(this._btnGrpParentSelector).el,
            e = ((e.length && e[0].clientHeight) < (t.length && t[0].clientHeight) ? v("#onetrust-banner-sdk").removeClass("vertical-align-content") : v("#onetrust-banner-sdk").addClass("vertical-align-content"), document.querySelector("#onetrust-button-group-parent button:first-of-type")),
            t = document.querySelector("#onetrust-button-group-parent button:last-of-type");
        t && e && 1 < Math.abs(t.offsetTop - e.offsetTop) && v("#onetrust-banner-sdk").addClass("ot-buttons-fw")
    }, gr.prototype.slideInAnimation = function(e, t) {
        t === Je ? "bottom" === L.BannerPosition ? (e.css("bottom: -99px;"), e.animate({
            bottom: "0px"
        }, 1e3), l.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("bottom: 0px;"), l.bnrAnimationInProg = !1
        }, 1e3)) : (e.css("top: -99px; bottom: auto;"), b.pagePushedDown && !gn.checkIsBrowserIE11OrBelow() ? gn.BannerPushDownHandler() : (e.animate({
            top: "0"
        }, 1e3), l.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("top: 0px; bottom: auto;"), l.bnrAnimationInProg = !1
        }, 1e3))) : t !== Xe && t !== $e || (e.css("bottom: -300px;"), e.animate({
            bottom: "1em"
        }, 2e3), l.bnrAnimationInProg = !0, setTimeout(function() {
            e.css("bottom: 1rem;"), l.bnrAnimationInProg = !1
        }, 2e3))
    }, gr.prototype.setBannerBtn = function() {
        var e;
        L.PCTemplateUpgrade && S.fp.WebButtonCustomisations && this._isValidButtonOrderConfig && b.bannerName === et ? window.innerWidth <= 600 && this._fourBtns ? (e = document.querySelector("#onetrust-button-group"), P.insertElement(e, this._settingsBtn, "beforeend")) : this._fourBtns && this._descriptCntr.insertAdjacentElement("beforeend", this._settingsBtn) : window.innerWidth <= 600 ? (P.insertElement(this._btnsCntr, this._settingsBtn, "afterbegin"), P.insertElement(this._btnsCntr, this._saveBtn, "afterbegin"), P.insertElement(this._btnsCntr, this._acceptBtn, "afterbegin"), P.insertElement(this._btnsCntr, this._rejectBtn, "afterbegin")) : this._fourBtns ? (this._descriptCntr.insertAdjacentElement("beforeend", this._settingsBtn), this._acceptBtn.insertAdjacentElement("beforebegin", this._rejectBtn), this._btnsCntr.insertAdjacentElement("beforebegin", this._saveBtn)) : (P.insertElement(this._btnsCntr, this._settingsBtn, "beforebegin"), P.insertElement(this._btnsCntr, this._saveBtn, this._settingsBtn ? "afterbegin" : "beforebegin"), P.insertElement(this._btnsCntr, this._rejectBtn, "beforeend"), P.insertElement(this._btnsCntr, this._acceptBtn, "beforeend"))
    }, gr.prototype.setCmpBannerOptions = function(n, e) {
        var r = v(n("#banner-options .banner-option")).el.cloneNode(!0),
            i = (v(n(this._bannerOptionsSelector)).html(""), 1);
        e.forEach(function(e) {
            var t = r.cloneNode(!0),
                o = L[e.titleKey],
                e = L[e.descriptionKey];
            (o || e) && (t.querySelector(".banner-option-header :first-child").innerHTML = m.getInnerHtmlContent(o), o = t.querySelector(".banner-option-details"), e ? (o.setAttribute("id", "option-details-" + i++), o.innerHTML = m.getInnerHtmlContent(e)) : o.parentElement.removeChild(o), v(n("#banner-options")).el.appendChild(t))
        })
    }, gr.prototype.setFloatingRoundedIconBannerCmpOptions = function(r, e) {
        var i = this,
            s = v(r("#banner-options button")).el.cloneNode(!0),
            n = v(r(".banner-option-details")).el.cloneNode(!0);
        v(r(this._bannerOptionsSelector)).html(""), e.forEach(function(e) {
            var t = s.cloneNode(!0),
                o = L[e.titleKey],
                n = L[e.descriptionKey];
            (o || n) && (t.setAttribute("id", e.identifier), t.querySelector(".banner-option-header :first-child").innerHTML = m.getInnerHtmlContent(o), v(r(i._bannerOptionsSelector)).el.appendChild(t))
        }), e.forEach(function(e) {
            var t, o = L[e.descriptionKey];
            o && ((t = n.cloneNode(!0)).innerHTML = m.getInnerHtmlContent(o), t.classList.add(e.identifier), v(r(i._bannerOptionsSelector)).el.appendChild(t))
        })
    }, gr.prototype.setBannerOptionContent = function() {
        var t = this;
        b.bannerName !== Je && b.bannerName !== Ze || setTimeout(function() {
            var e;
            (window.innerWidth < 769 ? (e = v(t._bannerOptionsSelector).el[0], v(t._otGrpContainerSelector)) : (e = v(t._bannerOptionsSelector).el[0], b.bannerName === Ze ? v(".banner-content") : v("#onetrust-banner-sdk .ot-sdk-container"))).el[0].appendChild(e)
        })
    }, gr.prototype.setAdditionalDesc = function(e) {
        var t = L.BannerAdditionalDescPlacement,
            o = document.createElement("span"),
            n = (o.classList.add("ot-b-addl-desc"), v(o).html(L.BannerAdditionalDescription), e(pr.POLICY_TEXT_SELECTOR));
        t === le.AfterTitle ? n.insertAdjacentElement("beforeBegin", o) : t === le.AfterDescription ? n.insertAdjacentElement("afterEnd", o) : t === le.AfterDPD && (n = e(".ot-dpd-container .ot-dpd-desc"), (n = L.ChoicesBanner ? e(this._otGrpContainerSelector) : n).insertAdjacentElement("beforeEnd", o))
    }, gr.prototype.insertGrps = function(e) {
        var d = e(".ot-cat-item").cloneNode(!0),
            u = (P.removeChild(e(".ot-cat-item")), L.BCategoryStyle === ve.Checkbox ? P.removeChild(d.querySelector(".ot-tgl")) : (P.removeChild(d.querySelector(".ot-chkbox")), v(d).addClass("ot-cat-bdr")), e(".ot-cat-lst ul"));
        L.Groups.forEach(function(e) {
            var t = d.cloneNode(!0),
                o = t.querySelector(".ot-tgl,.ot-chkbox"),
                n = e.GroupName,
                r = e.CustomGroupId,
                i = "ot-bnr-grp-id-" + r,
                s = "ot-bnr-hdr-id-" + r,
                a = -1 !== Dt.indexOf(e.Type),
                l = D.getGrpStatus(e).toLowerCase() === f.ALWAYS_ACTIVE || a,
                c = D.getGrpStatus(e).toLowerCase() === f.ALWAYS_INACTIVE || a,
                a = V.isGroupActive(e) || a,
                e = (v(o.querySelector("label")).attr("for", i), v(o.querySelector(".ot-label-txt")).html(e.GroupName), o.querySelector("input")),
                l = ((l || c) && (L.BCategoryStyle === ve.Toggle ? (P.removeChild(o), t.insertAdjacentElement("beforeend", v("<div class='ot-always-active'>" + (c ? L.AlwaysInactiveText : L.AlwaysActiveText) + "</div>", "ce").el)) : v(e).attr("disabled", !0)), e.classList.add("category-switch-handler"), V.setInputID(e, i, r, a, s), t.querySelector('h4, p[aria-level="4"]'));
            v(l).html(n), v(l).attr("id", s), v(u).append(t)
        })
    }, gr.prototype.setBannerLogo = function(e, t) {
        var o, n;
        S.fp.CookieV2BannerLogo && L.BnrLogo && (o = t(yn), n = "afterend", b.bannerName === Ze && (o = t("#onetrust-cookie-btn"), n = "beforeend"), t = I.updateCorrectUrl(L.BnrLogo), v(e).addClass("ot-bnr-w-logo"), v(o).el.innerHTML = m.getInnerHtmlContent(""), o.insertAdjacentHTML(n, m.getInnerHtmlContent("<img class='ot-bnr-logo' src='" + t + "'\n            title='" + L.BnrLogoAria + "'\n            alt='" + L.BnrLogoAria + "'/>")))
    }, gr.prototype.setOptOutSignalNotification = function(e) {
        var t = b.gpcEnabled && b.gpcForAGrpEnabled;
        L.BShowOptOutSignal && (t || b.previewMode) && I.createOptOutSignalElement(e, !1)
    };
    var pr, Cr = gr;

    function gr() {
        this.POLICY_TEXT_SELECTOR = "#onetrust-policy-text", this.El = "#onetrust-banner-sdk", this._saveBtn = null, this._settingsBtn = null, this._acceptBtn = null, this._rejectBtn = null, this._descriptCntr = null, this._btnsCntr = null, this._fourBtns = !1, this._isValidButtonOrderConfig = !0, this._bannerOptionsSelector = "#banner-options", this._btnGrpParentSelector = "#onetrust-button-group-parent", this._otGrpContainerSelector = "#onetrust-group-container", this.cookiePolicyLinkSelector = "#onetrust-policy-text a"
    }
    yr.prototype.setHeaderConfig = function() {
        c.setHeader(), c.setSearchInput(), c.setHeaderUIConsent();
        var e = c.getGroupsForFilter();
        or.setFilterListByGroup(e, !1)
    }, yr.prototype.filterVendorByString = function(e) {
        c.searchQuery = e, c.filterVendorByGroupOrQuery()
    }, yr.prototype.filterVendorByGroup = function(e) {
        c.filterGroups = e, c.filterVendorByGroupOrQuery()
    }, yr.prototype.showVSList = function() {
        c.removeListeners(), c.showEmptyResults(!1, ""), c.clearUIElementsInMain(), c.addVSList(l.getVendorsInDomain())
    }, yr.prototype.showEmptyResults = function(e, t) {
        e ? this.setNoResultsContent(t) : (v("#onetrust-pc-sdk " + A.P_Vendor_Content).removeClass("no-results"), (e = v("#onetrust-pc-sdk #no-results")).length && e.remove())
    }, yr.prototype.setNoResultsContent = function(e) {
        var t, o, n, r, i = v("#onetrust-pc-sdk #no-results").el[0];
        if (!i) return t = document.createElement("div"), o = document.createElement("p"), n = document.createTextNode(" " + L.PCVendorNotFound + "."), r = document.createElement("span"), t.id = "no-results", t.setAttribute("aria-live", "assertive"), t.setAttribute("aria-atomic", "true"), r.id = "user-text", r.innerText = e, o.appendChild(r), o.appendChild(n), t.appendChild(o), v("#onetrust-pc-sdk " + A.P_Vendor_Content).addClass("no-results"), v("#vendor-search-handler").el[0].setAttribute("aria-describedby", t.id), v("#onetrust-pc-sdk " + A.P_Vendor_Content).append(t);
        i.querySelector("span").innerText = e
    }, yr.prototype.getGroupsFilter = function() {
        for (var e = [], t = 0, o = v("#onetrust-pc-sdk .category-filter-handler").el; t < o.length; t++) {
            var n = o[t],
                r = n.getAttribute("data-purposeid");
            n.checked && e.push(r)
        }
        return e
    }, yr.prototype.cancelFilter = function() {
        for (var e = 0, t = v("#onetrust-pc-sdk .category-filter-handler").el; e < t.length; e++) {
            var o = t[e],
                n = o.getAttribute("data-optanongroupid"),
                n = 0 <= l.filterByCategories.indexOf(n);
            P.setCheckedAttribute(null, o, n)
        }
        var r = c.getGroupsFilter();
        c.filterVendorByGroup(r)
    }, yr.prototype.clearFilter = function() {
        c.searchQuery = "", c.filterGroups = []
    }, yr.prototype.toggleVendors = function(r) {
        l.getVendorsInDomain().forEach(function(e, t) {
            var o, n;
            D.isAlwaysActiveGroup(e.groupRef) || (o = document.getElementById("ot-vendor-id-" + t), n = document.getElementById("ot-vs-lst-id-" + t), w.toggleVendorService(e.groupRef.CustomGroupId, t, r, o), w.toggleVendorService(e.groupRef.CustomGroupId, t, r, n))
        })
    }, yr.prototype.hideVendorList = function() {
        c.removeListeners(), c.clearUIElementsInMain()
    }, yr.prototype.addListeners = function() {
        v("#onetrust-pc-sdk " + A.P_Vendor_Content + " .ot-vs-list .category-switch-handler").on("click", c.toggleVendorHandler), v("#onetrust-pc-sdk").on("click", ".ot-vs-list", u.onCategoryItemToggle.bind(this))
    }, yr.prototype.removeListeners = function() {
        var e;
        document.querySelectorAll("#onetrust-pc-sdk .ot-vs-list .category-switch-handler").forEach(function(e) {
            return e.removeEventListener("click", u.toggleGroupORVendorHandler)
        }), null != (e = document.querySelector("#onetrust-pc-sdk .ot-vs-list")) && e.removeEventListener("click", u.onCategoryItemToggle)
    }, yr.prototype.toggleVendorHandler = function(e) {
        u.toggleVendorFromListHandler(e), c.checkAllowAllCheckedValue()
    }, yr.prototype.filterVendorByGroupOrQuery = function() {
        var o = new Map;
        l.getVendorsInDomain().forEach(function(e, t) {
            c.checkVendorConditions(e) && o.set(t, e)
        }), c.showEmptyResults(o.size <= 0, c.searchQuery), c.removeListeners(), c.clearUIElementsInMain(), c.addVSList(o)
    }, yr.prototype.checkVendorConditions = function(e) {
        return !("" !== c.searchQuery && e.ServiceName.toLowerCase().indexOf(c.searchQuery.toLowerCase()) < 0 || 0 < c.filterGroups.length && c.filterGroups.indexOf(e.groupRef.CustomGroupId) < 0)
    }, yr.prototype.addVSList = function(e) {
        var t = v("#onetrust-pc-sdk " + A.P_Vendor_Content + " .ot-sdk-column"),
            e = w.getVendorListEle(e);
        t.append(e), c.addListeners()
    }, yr.prototype.getGroupsForFilter = function() {
        var t = new Map;
        return l.getVendorsInDomain().forEach(function(e) {
            t.has(e.groupRef.CustomGroupId) || t.set(e.groupRef.CustomGroupId, e.groupRef)
        }), Array.from(t.values())
    }, yr.prototype.clearUIElementsInMain = function() {
        v("#onetrust-pc-sdk " + A.P_Vendor_Content + " ul" + A.P_Host_Cntr).html(""), v("#onetrust-pc-sdk " + A.P_Vendor_Content + " ul" + A.P_Host_Cntr).hide(), v("#onetrust-pc-sdk " + A.P_Vendor_Content + " ul" + A.P_Vendor_Container).html(""), v("#onetrust-pc-sdk " + A.P_Vendor_Content + " ul" + A.P_Vendor_Container).hide();
        var e = v("#onetrust-pc-sdk " + A.P_Vendor_Content + " .ot-vs-list");
        e && e.length && e.remove()
    }, yr.prototype.setHeader = function() {
        var e = L.VendorServiceConfig.PCVSListTitle,
            t = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]');
        t && (t.innerText = e)
    }, yr.prototype.setSearchInput = function() {
        var e = L.PCenterCookieListSearch,
            t = L.PCenterCookieSearchAriaLabel,
            o = v("#onetrust-pc-sdk " + A.P_Vendor_Search_Input);
        o.el[0].placeholder = e, o.attr("aria-label", t)
    }, yr.prototype.setHeaderUIConsent = function() {
        var e, t, o;
        v("#onetrust-pc-sdk " + A.P_Select_Cntr).addClass("ot-vnd-list-cnt"), v("#onetrust-pc-sdk " + A.P_Select_Cntr + " .ot-sel-all").addClass("ot-vs-selc-all"), L.PCCategoryStyle === ve.Toggle && (v("#onetrust-pc-sdk " + A.P_Select_Cntr + " .ot-sel-all").addClass("ot-toggle-conf"), L.PCAccordionStyle === ce.Caret) && v("#onetrust-pc-sdk " + A.P_Select_Cntr + " .ot-sel-all").addClass("ot-caret-conf"), v("#onetrust-pc-sdk " + A.P_Leg_Select_All).hide(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Host_El).hide(), v("#onetrust-pc-sdk " + A.P_Host_Cntr).hide(), v(A.P_Vendor_List + " #select-all-text-container").hide(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).hide(), v("#onetrust-pc-sdk " + A.P_Vendor_Container).show(), v("#onetrust-pc-sdk " + A.P_Select_Cntr).show(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Consent_El).show("inline-block"), v("#onetrust-pc-sdk " + A.P_Vendor_List).removeClass(A.P_Host_UI), v("#onetrust-pc-sdk " + A.P_Vendor_Content).removeClass(A.P_Host_Cnt), document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox .sel-all-hdr") || (e = void 0, null != (t = S.moduleInitializer) && t.SEOOptimization ? ((e = document.createElement("p")).setAttribute("role", "heading"), e.setAttribute("aria-level", "4")) : e = document.createElement("h4"), e.className = "sel-all-hdr", e.textContent = (null == (t = L.VendorServiceConfig) ? void 0 : t.PCVSAllowAllText) || "PCVSAllowAllText", t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"), o = L.PCCategoryStyle === ve.Checkbox ? "beforeend" : "afterbegin", t.insertAdjacentElement(o, e)), c.checkAllowAllCheckedValue()
    }, yr.prototype.checkAllowAllCheckedValue = function() {
        var t = !0,
            e = (l.vsConsent.forEach(function(e) {
                e || (t = !1)
            }), document.getElementById("#select-all-vendor-groups-handler"));
        P.setCheckedAttribute(null, e, t)
    };
    var c, hr = yr;

    function yr() {
        this.searchQuery = "", this.filterGroups = []
    }
    i.prototype.initCookieSettingHandlers = function() {
        v(document).on("click", ".optanon-show-settings, .optanon-toggle-display, .ot-sdk-show-settings, .ot-pc-handler", this.cookiesSettingsBoundListener)
    }, i.prototype.initFlgtCkStgBtnEventHandlers = function() {
        v(".ot-floating-button__open").on("click", function(e) {
            setTimeout(function() {
                u.floatingCookieSettingOpenBtnClicked(e)
            }, 0)
        }), v(".ot-floating-button__close").on("click", function(e) {
            setTimeout(function() {
                u.floatingCookieSettingCloseBtnClicked(e)
            }, 0)
        })
    }, i.prototype.floatingCookieSettingOpenBtnClicked = function(e) {
        v(u.fltgBtnSltr).addClass("ot-pc-open"), L.cookiePersistentLogo.includes("ot_guard_logo.svg") && v(u.fltgBtnFSltr).attr(vt, "true"), v(u.fltgBtnBSltr).attr(vt, ""), v(u.fltgBtnFrontBtn).el[0].setAttribute(vt, !0), v(u.fltgBtnFrontBtn).el[0].style.display = "none", v(u.fltgBtnBackBtn).el[0].setAttribute(mt, L.AriaClosePreferences), v(u.fltgBtnBackBtn).el[0].setAttribute(vt, !1), v(u.fltgBtnBackBtn).el[0].style.display = "block", mo.triggerGoogleAnalyticsEvent(Bo, zo), u.showCookieSettingsHandler(e)
    }, i.prototype.floatingCookieSettingCloseBtnClicked = function(e) {
        v(u.fltgBtnFrontBtn).el[0].setAttribute(mt, L.CookieSettingButtonText), v(u.fltgBtnFrontBtn).el[0].setAttribute(vt, !1), v(u.fltgBtnFrontBtn).el[0].style.display = "block", v(u.fltgBtnBackBtn).el[0].setAttribute(vt, !0), v(u.fltgBtnBackBtn).el[0].style.display = "none", e && (mo.triggerGoogleAnalyticsEvent(Bo, Wo), u.hideCookieSettingsHandler(e))
    }, i.prototype.initialiseLegIntBtnHandlers = function() {
        v(document).on("click", ".ot-obj-leg-btn-handler", u.onLegIntButtonClick), v(document).on("click", ".ot-remove-objection-handler", u.onLegIntButtonClick)
    }, i.prototype.initialiseAddtlVenHandler = function() {
        v("#onetrust-pc-sdk #ot-addtl-venlst").on("click", u.selectVendorsGroupHandler), v("#onetrust-pc-sdk #ot-selall-adtlven-handler").on("click", u.selAllAdtlVenHandler)
    }, i.prototype.initializeGenVenHandlers = function() {
        v("#onetrust-pc-sdk #ot-gn-venlst .ot-gnven-chkbox-handler").on("click", u.genVendorToggled), v("#onetrust-pc-sdk #ot-gn-venlst .ot-gv-venbox").on("click", u.genVendorDetails), v("#onetrust-pc-sdk #ot-selall-gnven-handler").on("click", u.selectAllGenVenHandler)
    }, i.prototype.initialiseConsentNoticeHandlers = function() {
        var e = this;
        b.pcName === st && u.categoryMenuSwitchHandler(), v("#onetrust-pc-sdk .onetrust-close-btn-handler").on("click", function(e) {
            setTimeout(function() {
                u.bannerCloseButtonHandler(e)
            }, 0)
        }), v("#onetrust-pc-sdk #accept-recommended-btn-handler").on("click", function() {
            setTimeout(function() {
                C.allowAllEventHandler(!0)
            }, 0)
        }), v("#onetrust-pc-sdk .ot-pc-refuse-all-handler").on("click", function() {
            setTimeout(function() {
                C.rejectAllEventHandler(!0)
            }, 0)
        }), v("#onetrust-pc-sdk #close-pc-btn-handler").on("click", function(e) {
            setTimeout(function() {
                u.hideCookieSettingsHandler(e)
            }, 0)
        }), v(document).on("keydown", u.closePCWhenEscPressed), v("#onetrust-pc-sdk #vendor-close-pc-btn-handler").on("click", u.hideCookieSettingsHandler), v("#onetrust-pc-sdk .category-switch-handler").on("click", u.toggleGroupORVendorHandler), v("#onetrust-pc-sdk .cookie-subgroup-handler").on("click", u.toggleSubCategory), v("#onetrust-pc-sdk .category-menu-switch-handler").on("keydown", function(e) {
            b.pcName !== st || e.keyCode !== ae.UpArrow && e.keyCode !== ae.DownArrow || (e.preventDefault(), L.PCTemplateUpgrade ? u.changeSelectedTabV2(e) : u.changeSelectedTab(e))
        }), v("" + u.PC_SELECTOR).on("click", A.P_Category_Item + " > input:first-child," + A.P_Category_Item + " > button:first-child", u.onCategoryItemToggle.bind(this)), (L.showCookieList || _.showGeneralVendors) && (v("#onetrust-pc-sdk .category-host-list-handler").on("click", function(e) {
            setTimeout(function() {
                _.showGeneralVendors && L.showCookieList ? _.cookieListType = ye.HostAndGenVen : _.showGeneralVendors ? _.cookieListType = ye.GenVen : _.cookieListType = ye.Host, u.pcLinkSource = e.target, u.loadCookieList(e.target)
            }, 0)
        }), I.isOptOutEnabled() ? (v("#onetrust-pc-sdk #select-all-hosts-groups-handler").on("click", u.selectAllHostsGroupsHandler), v("#onetrust-pc-sdk " + A.P_Host_Cntr).on("click", u.selectHostsGroupHandler)) : v("#onetrust-pc-sdk " + A.P_Host_Cntr).on("click", u.toggleAccordionStatus)), u.addListenerWhenIabEnabled(), u.addEventListenerWhenIsHostOrVendorsAreEnabled(), u.adddListenerWhenNoBanner(), v("#onetrust-pc-sdk .ot-gv-list-handler").on("click", function(t) {
            return F(e, void 0, void 0, function() {
                return M(this, function(e) {
                    return _.cookieListType = ye.GenVen, u.loadCookieList(t.target), [2]
                })
            })
        }), u.addListenerWhenVendorServices(), u.addEventListnerForVendorsList()
    }, i.prototype.addEventListenerWhenIsHostOrVendorsAreEnabled = function() {
        var e;
        (L.IsIabEnabled || L.showCookieList || _.showGeneralVendors || _.showVendorService) && (v(document).on("click", ".back-btn-handler", u.backBtnHandler), u.addListenerSearchKeyEvent(), v("#onetrust-pc-sdk #filter-btn-handler").on("click", u.toggleVendorFiltersHandler), v("#onetrust-pc-sdk #filter-apply-handler").on("click", function() {
            setTimeout(function() {
                u.applyFilterHandler()
            }, 0)
        }), v("#onetrust-pc-sdk " + A.P_Fltr_Modal).on("click", u.tglFltrOptionHandler), !S.isV2Template && b.pcName !== it || v("#onetrust-pc-sdk #filter-cancel-handler").on("click", u.cancelFilterHandler), !S.isV2Template && b.pcName === it || v("#onetrust-pc-sdk #clear-filters-handler").on("click", u.clearFiltersHandler), S.isV2Template ? v("#onetrust-pc-sdk #filter-cancel-handler").on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || e.shiftKey || (e.preventDefault(), v("#onetrust-pc-sdk #clear-filters-handler").el[0].focus())
        }) : v("#onetrust-pc-sdk #filter-apply-handler").on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || e.shiftKey || (e.preventDefault(), v("#onetrust-pc-sdk .category-filter-handler").el[0].focus())
        }), e = v("#onetrust-pc-sdk .category-filter-handler").el, v(e[0]).on("keydown", function(e) {
            9 !== e.keyCode && "tab" !== e.code || !e.shiftKey || (e.preventDefault(), v("#onetrust-pc-sdk #filter-apply-handler").el[0].focus())
        }))
    }, i.prototype.addListenerSearchKeyEvent = function() {
        v(u.VENDOR_SEARCH_SELECTOR).on("keyup", function(e) {
            e = e.target.value.trim();
            u.currentSearchInput !== e && (_.showVendorService ? c.filterVendorByString(e) : u.isCookieList ? (g.searchHostList(e), _.showTrackingTech && u.addEventAdditionalTechnologies()) : (g.loadVendorList(e, []), L.UseGoogleVendors && g.searchVendors(g.googleSearchSelectors, _.addtlVendorsList, me.GoogleVendor, e), _.showGeneralVendors && L.GeneralVendors.length && g.searchVendors(g.genVendorSearchSelectors, L.GeneralVendors, me.GeneralVendor, e)), g.playSearchStatus(u.isCookieList), u.currentSearchInput = e)
        })
    }, i.prototype.addListenerWhenIabEnabled = function() {
        L.IsIabEnabled && (v("#onetrust-pc-sdk .category-vendors-list-handler").on("click", function(e) {
            setTimeout(function() {
                u.pcLinkSource = e.target, u.showVendorsList(e.target)
            }, 0)
        }), v("#onetrust-pc-sdk .ot-pgph-link").on("click", function(e) {
            u.pcLinkSource = e.target, u.showIllustrations(e.target)
        }), v("#onetrust-pc-sdk " + A.P_Vendor_Container).on("click", u.selectVendorsGroupHandler), L.UseGoogleVendors || u.bindSelAllHandlers(), u.initialiseLegIntBtnHandlers())
    }, i.prototype.adddListenerWhenNoBanner = function() {
        L.NoBanner && (L.OnClickCloseBanner && document.body.addEventListener("click", C.bodyClickEvent), L.ScrollCloseBanner) && window.addEventListener("scroll", C.scrollCloseBanner)
    }, i.prototype.addListenerWhenVendorServices = function() {
        _.showVendorService && (u.bindSelAllHandlers(), v("#onetrust-pc-sdk .onetrust-vendors-list-handler").on("click", function() {
            setTimeout(function() {
                u.showVendorsList(null, !0)
            }, 0)
        }))
    }, i.prototype.bindSelAllHandlers = function() {
        v("#onetrust-pc-sdk #select-all-vendor-leg-handler").on("click", u.selectAllVendorsLegIntHandler), v("#onetrust-pc-sdk #select-all-vendor-groups-handler").on("click", u.SelectAllVendorConsentHandler)
    }, i.prototype.hideCookieSettingsHandler = function(e) {
        var t;
        return void 0 === e && (e = window.event), Zn.getInstance().resetHealthSignatureData(), mo.triggerGoogleAnalyticsEvent(Bo, Fo), gn.removeAddedOTCssStyles(Cn.PC), _.pcLayer === se.IabIllustrations && lr.hideUI(), kn.hideConsentNoticeV2(), null != (t = null == (t = window.OneTrust_ConfirmDialog) ? void 0 : t.getInstance()) && t.close(), v(document).off("keydown", u.closePCWhenEscPressed), u.getResizeElement().removeEventListener("resize", u.setCenterLayoutFooterHeight), window.removeEventListener("resize", u.setCenterLayoutFooterHeight), !S.isV2Template && b.pcName !== it || u.closeFilter(!1), b.pcName === nt && v("#onetrust-pc-sdk " + A.P_Content).removeClass("ot-hide"), C.hideVendorsList(), xs.csBtnGroup && (v(u.fltgBtnSltr).removeClass("ot-pc-open"), u.floatingCookieSettingCloseBtnClicked(null)), u.confirmPC(e), C.resetConsent(), !1
    }, i.prototype.selectAllHostsGroupsHandler = function(e) {
        var t = e.target.checked,
            e = v("#onetrust-pc-sdk #" + A.P_Sel_All_Host_El).el[0],
            o = e.classList.contains("line-through"),
            n = v("#onetrust-pc-sdk .host-checkbox-handler").el;
        P.setCheckedAttribute("#select-all-hosts-groups-handler", null, t), P.setAriaCheckedAttribute("#select-all-hosts-groups-handler", null, t.toString());
        for (var r = 0; r < n.length; r++) n[r].getAttribute("disabled") || P.setCheckedAttribute(null, n[r], t);
        _.optanonHostList.forEach(function(e) {
            Do.updateHostStatus(e, t)
        }), n.forEach(function(e) {
            Io.updateGenVendorStatus(e.getAttribute("hostId"), t)
        }), o && e.classList.remove("line-through")
    }, i.prototype.selectHostsGroupHandler = function(e) {
        u.toggleAccordionStatus(e);
        var t = e.target.getAttribute("hostId"),
            o = e.target.getAttribute("ckType"),
            n = e.target.checked;
        null !== t && (o === he.GenVendor ? (o = L.GeneralVendors.find(function(e) {
            return e.VendorCustomId === t
        }).Name, mo.triggerGoogleAnalyticsEvent(Bo, n ? Xo : Qo, o + ": VEN_" + t), Io.updateGenVendorStatus(t, n)) : (o = P.findIndex(_.optanonHostList, function(e) {
            return e.HostId === t
        }), o = _.optanonHostList[o], u.toggleHostStatus(o, n)), P.setCheckedAttribute(null, e.target, n))
    }, i.prototype.onCategoryItemToggle = function(e) {
        e.stopPropagation();
        var t = e.target;
        "BUTTON" !== t.tagName && "INPUT" !== t.tagName || (b.pcName === nt && this.setPcListContainerHeight(), u.toggleAccordionStatus(e))
    }, i.prototype.toggleAccordionStatus = function(e) {
        var t, e = e.target;
        e && e.getAttribute("aria-expanded") && (t = "true" === e.getAttribute("aria-expanded") ? "false" : "true", e.setAttribute("aria-expanded", t))
    }, i.prototype.toggleHostStatus = function(e, t) {
        mo.triggerGoogleAnalyticsEvent(Bo, t ? Zo : $o, e.HostName + ": H_" + e.HostId), Do.updateHostStatus(e, t)
    }, i.prototype.toggleBannerOptions = function(e) {
        v(".banner-option-input").each(function(e) {
            v(e).el.setAttribute("aria-expanded", !1)
        }), u.toggleAccordionStatus(e)
    }, i.prototype.bannerCloseButtonHandler = function(n) {
        var r;
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                return v(document).off("keydown", u.shiftBannerFocus), -1 < (t = (null == (r = null == (r = n) ? void 0 : r.target) ? void 0 : r.className) || "").indexOf("save-preference-btn-handler") ? (_.bannerCloseSource = ee.ConfirmChoiceButton, mo.triggerGoogleAnalyticsEvent(Bo, jo)) : -1 < t.indexOf("banner-close-button") ? (_.bannerCloseSource = ee.BannerCloseButton, o = xo, -1 < t.indexOf("ot-close-link") && (o = Ho, _.bannerCloseSource = ee.ContinueWithoutAcceptingButton), mo.triggerGoogleAnalyticsEvent(Bo, o)) : -1 < t.indexOf("ot-bnr-save-handler") && (_.bannerCloseSource = ee.BannerSaveSettings, mo.triggerGoogleAnalyticsEvent(Bo, Ro)), gn.removeAddedOTCssStyles(), C.hideVendorsList(), [2, C.bannerCloseButtonHandler()]
            })
        })
    }, i.prototype.onLegIntButtonClick = function(e) {
        var t, o, n, r;
        e && (n = "true" === (e = e.currentTarget).parentElement.getAttribute("is-vendor"), t = e.parentElement.getAttribute("data-group-id"), r = "", o = !e.classList.contains("ot-leg-int-enabled"), n ? u.onVendorToggle(t, de.LI) : (r = (n = D.getGroupById(t)).GroupName, n.Parent ? u.updateSubGroupToggles(n, o, !0) : u.updateGroupToggles(n, o, !0)), V.updateLegIntBtnElement(e.parentElement, o, r))
    }, i.prototype.updateGroupToggles = function(t, o, e) {
        Do.toggleGroupHosts(t, o), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(t, o), t.IsLegIntToggle = e, u.toggleGroupStatus(t, o), t.SubGroups && t.SubGroups.length && (b.bannerName === et && S.moduleInitializer.IsSuppressPC && t.SubGroups.length ? t.SubGroups.forEach(function(e) {
            e.IsLegIntToggle = t.IsLegIntToggle, V.toggleGrpStatus(e, o), e.IsLegIntToggle = !1, Do.toggleGroupHosts(e, o), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(e, o), w.setVendorStateByGroup(e, o)
        }) : V.toogleAllSubGrpElements(t, o), t.SubGroups.forEach(function(e) {
            return w.setVendorStateByGroup(e, o)
        })), w.setVendorStateByGroup(t, o), S.fp.WebButtonCustomisations || this.allowAllVisible(V.setAllowAllButton()), t.IsLegIntToggle = !1
    }, i.prototype.toggleGroupStatus = function(e, t) {
        var o;
        b.requireSignatureEnabled && e.needsHealthSignature ? (o = !1, t ? (b.healthSignatureData && (o = !0), b.healthSignatureGroup = e) : b.healthSignatureGroup = null, V.toggleGrpStatus(e, o)) : V.toggleGrpStatus(e, t)
    }, i.prototype.updateSubGroupToggles = function(e, t, o) {
        Do.toggleGroupHosts(e, t), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(e, t);
        var n = D.getGroupById(e.Parent),
            o = (e.IsLegIntToggle = o, n.IsLegIntToggle = e.IsLegIntToggle, V.isGroupActive(n));
        t ? (V.toggleGrpStatus(e, !0), V.isAllSubgroupsEnabled(n) && !o && (V.toggleGrpStatus(n, !0), Do.toggleGroupHosts(n, t), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(n, t), V.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), !0))) : (V.toggleGrpStatus(e, !1), V.isAllSubgroupsDisabled(n) && o ? (V.toggleGrpStatus(n, !1), Do.toggleGroupHosts(n, t), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(n, t), V.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), t)) : (V.toggleGrpStatus(n, !1), Do.toggleGroupHosts(n, !1), _.genVenOptOutEnabled && Do.toggleGroupGenVendors(n, t), V.toggleGroupHtmlElement(e, e.Parent + (e.IsLegIntToggle ? "-leg-out" : ""), !1))), this.allowAllVisible(V.setAllowAllButton()), e.IsLegIntToggle = !1, n.IsLegIntToggle = e.IsLegIntToggle
    }, i.prototype.hideCategoryContainer = function(e) {
        this.isCookieList = e = void 0 === e ? !1 : e, u.addHideClassContainer(), _.showVendorService ? c.setHeaderConfig() : (e ? u.setCookieListTemplate() : u.setVendorListTemplate(), or.setFilterList(e))
    }, i.prototype.setCookieListTemplate = function() {
        var e = S.isV2Template;
        v(A.P_Vendor_List + " #select-all-text-container").show("inline-block"), v("#onetrust-pc-sdk " + A.P_Host_Cntr).show(), I.isOptOutEnabled() ? v("#onetrust-pc-sdk #" + A.P_Sel_All_Host_El).show("inline-block") : v("#onetrust-pc-sdk #" + A.P_Sel_All_Host_El).hide(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).hide(), v("#onetrust-pc-sdk " + A.P_Leg_Header).hide(), e || v("#onetrust-pc-sdk " + A.P_Leg_Select_All).hide(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Consent_El).hide(), v("#onetrust-pc-sdk  " + A.P_Vendor_Container).hide(), (L.UseGoogleVendors || _.showGeneralVendors) && v("#onetrust-pc-sdk .ot-acc-cntr").hide(), v("#onetrust-pc-sdk " + A.P_Vendor_List).addClass(A.P_Host_UI), v("#onetrust-pc-sdk " + A.P_Vendor_Content).addClass(A.P_Host_Cnt)
    }, i.prototype.setVendorListTemplate = function() {
        v("#onetrust-pc-sdk " + A.P_Vendor_Container).show(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Consent_El).show("inline-block"), L.UseGoogleVendors && v("#onetrust-pc-sdk .ot-acc-cntr").show(), b.legIntSettings.PAllowLI && b.isIab2orv2Template ? (v("#onetrust-pc-sdk " + A.P_Select_Cntr).show(S.isV2Template ? void 0 : "inline-block"), v("#onetrust-pc-sdk " + A.P_Leg_Select_All).show("inline-block"), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).show("inline-block"), v(A.P_Vendor_List + " #select-all-text-container").hide(), b.legIntSettings.PShowLegIntBtn ? (v("#onetrust-pc-sdk " + A.P_Leg_Header).hide(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).hide()) : v("#onetrust-pc-sdk " + A.P_Leg_Header).show()) : (v("#onetrust-pc-sdk " + A.P_Select_Cntr).show(), v(A.P_Vendor_List + " #select-all-text-container").show("inline-block"), v("#onetrust-pc-sdk " + A.P_Leg_Select_All).hide(), v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).hide()), v("#onetrust-pc-sdk #" + A.P_Sel_All_Host_El).hide(), v("#onetrust-pc-sdk " + A.P_Host_Cntr).hide(), v("#onetrust-pc-sdk " + A.P_Vendor_List).removeClass(A.P_Host_UI), v("#onetrust-pc-sdk " + A.P_Vendor_Content).removeClass(A.P_Host_Cnt)
    }, i.prototype.showAllVendors = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, u.fetchAndSetupPC()];
                    case 1:
                        return e.sent(), u.showVendorsList(null, !0), _.isPCVisible ? [3, 3] : [4, u.showCookieSettingsHandler(t)];
                    case 2:
                        e.sent(), e.label = 3;
                    case 3:
                        return [2]
                }
            })
        })
    }, i.prototype.fetchAndSetupPC = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return S.moduleInitializer.IsSuppressPC && 0 === v("" + u.PC_SELECTOR).length ? [4, Kt.getPcContent()] : [3, 2];
                    case 1:
                        t = e.sent(), xs.preferenceCenterGroup = {
                            name: t.name,
                            html: atob(t.html),
                            css: t.css
                        }, S.isV2Template = L.PCTemplateUpgrade && /otPcPanel|otPcCenter|otPcTab/.test(t.name), (t = document.getElementById("onetrust-style")).innerHTML = m.getInnerHtmlContent(t.innerHTML + xs.preferenceCenterGroup.css), t.innerHTML = m.getInnerHtmlContent(t.innerHTML + co.addCustomPreferenceCenterCSS()), N.insertPcHtml(), u.initialiseConsentNoticeHandlers(), L.IsIabEnabled && g.InitializeVendorList(), e.label = 2;
                    case 2:
                        return 0 !== v("" + u.PC_SELECTOR).length && L.PCTemplateUpgrade && ((t = document.querySelector("#onetrust-pc-sdk .ot-optout-signal")).querySelector("span").innerText = I.getOptOutSignalText(!0), N.setOptOutSignalVisibility(t)), [2]
                }
            })
        })
    }, i.prototype.setVendorContent = function() {
        v("" + u.FILTER_COUNT_SELECTOR).text(_.filterByIABCategories.length.toString()), g.loadVendorList("", _.filterByIABCategories), L.UseGoogleVendors && (_.vendorDomInit ? g.resetAddtlVendors() : (g.initGoogleVendors(), v("" + u.PC_SELECTOR).on("click", ".ot-acc-cntr > button", u.toggleAccordionStatus.bind(this)))), _.vendorDomInit || (_.vendorDomInit = !0, u.initialiseLegIntBtnHandlers(), L.UseGoogleVendors && (u.initialiseAddtlVenHandler(), u.bindSelAllHandlers())), _.showGeneralVendors && !_.genVendorDomInit && (_.genVendorDomInit = !0, g.initGenVendors(), u.initializeGenVenHandlers(), L.UseGoogleVendors || (u.bindSelAllHandlers(), v("" + u.PC_SELECTOR).on("click", ".ot-acc-cntr > button", u.toggleAccordionStatus.bind(this))))
    }, i.prototype.addEventAdditionalTechnologies = function() {
        var e = document.querySelectorAll("#onetrust-pc-sdk .ot-acc-cntr.ot-add-tech > button");
        0 < e.length && (v(e).off("click", u.toggleAccordionStatus), v(e).on("click", u.toggleAccordionStatus))
    }, i.prototype.showVendorsList = function(e, t) {
        return void 0 === t && (t = !1), _.cookieListType = null, u.hideCategoryContainer(!1), gn.addOTCssPropertiesToBody(Cn.PC, {}), _.showVendorService ? c.showVSList() : (t || (t = e.getAttribute("data-parent-id")) && (t = D.getGroupById(t)) && (t = U(t.SubGroups, [t]).reduce(function(e, t) {
            return -1 < _t.indexOf(t.Type) && e.push(t.CustomGroupId), e
        }, []), _.filterByIABCategories = U(_.filterByIABCategories, t)), u.setVendorContent(), On.updateFilterSelection(!1)), _.pcLayer = se.VendorList, e && No.setPCFocus(No.getPCElements()), this.setSearchInputFocus(), !1
    }, i.prototype.showIllustrations = function(e) {
        e = e.getAttribute("data-parent-id"), e = D.getGroupById(e);
        _.cookieListType = null, _.pcLayer = se.IabIllustrations, u.addHideClassContainer(), lr.showIllustrations(e.GroupName, e.IabIllustrations), No.setPCFocus(No.getPCElements())
    }, i.prototype.addHideClassContainer = function() {
        var e = b.pcName;
        L.PCTemplateUpgrade ? v("#onetrust-pc-sdk " + A.P_Content).addClass("ot-hide") : v("#onetrust-pc-sdk .ot-main-content").hide(), v("#onetrust-pc-sdk " + A.P_Vendor_List).removeClass("ot-hide"), e !== it && e !== nt && v("#onetrust-pc-sdk #close-pc-btn-handler.main").hide(), e === nt && d(v("" + u.PC_SELECTOR).el[0], 'height: "";', !0)
    }, i.prototype.loadCookieList = function(e) {
        _.filterByCategories = [], u.hideCategoryContainer(!0);
        var t, e = e && e.getAttribute("data-parent-id");
        return e && (t = D.getGroupById(e), _.filterByCategories.push(e), t.SubGroups.length) && t.SubGroups.forEach(function(e) {
            -1 === _t.indexOf(e.Type) && (e = e.CustomGroupId, _.filterByCategories.indexOf(e) < 0) && _.filterByCategories.push(e)
        }), g.loadHostList("", _.filterByCategories), _.showTrackingTech && u.addEventAdditionalTechnologies(), v("" + u.FILTER_COUNT_SELECTOR).text(_.filterByCategories.length.toString()), On.updateFilterSelection(!0), _.pcLayer = se.CookieList, No.setPCFocus(No.getPCElements()), this.setSearchInputFocus(), !1
    }, i.prototype.selectAllVendorsLegIntHandler = function(e) {
        var t = v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).el[0],
            o = t.classList.contains("line-through"),
            n = v(A.P_Vendor_Container + ' li:not([style="display: none;"]) .vendor-leg-checkbox-handler').el,
            r = e.target.checked,
            i = {};
        _.vendors.selectedLegIntVendors.map(function(e, t) {
            i[e.split(":")[0]] = t
        });
        for (var s = 0; s < n.length; s++) {
            P.setCheckedAttribute(null, n[s], r), L.PCShowConsentLabels && (n[s].parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(r ? L.PCActiveText : L.PCInactiveText));
            var a = n[s].getAttribute("leg-vendorid"),
                l = i[a];
            void 0 === l && (l = a), _.vendors.selectedLegIntVendors[l] = a + ":" + r
        }
        o && t.classList.remove("line-through"), P.setCheckedAttribute(null, e.target, r), P.setAriaCheckedAttribute(null, e.target, r)
    }, i.prototype.selAllAdtlVenHandler = function(e) {
        for (var t = v("#onetrust-pc-sdk #ot-selall-adtlvencntr").el[0], o = t.classList.contains("line-through"), n = v("#onetrust-pc-sdk .ot-addtlven-chkbox-handler").el, r = e.target.checked, i = 0; i < n.length; i++) P.setCheckedAttribute(null, n[i], r), L.PCShowConsentLabels && (n[i].parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(r ? L.PCActiveText : L.PCInactiveText));
        r ? L.UseGoogleVendors && Object.keys(_.addtlVendorsList).forEach(function(e) {
            _.addtlVendors.vendorSelected[e] = !0
        }) : _.addtlVendors.vendorSelected = {}, o && t.classList.remove("line-through")
    }, i.prototype.selectAllGenVenHandler = function(e) {
        var t = e.target.checked;
        u.selectAllHandler({
            selAllEl: "#onetrust-pc-sdk #ot-selall-gnvencntr",
            vendorBoxes: "#onetrust-pc-sdk .ot-gnven-chkbox-handler"
        }, "genven", t), P.setCheckedAttribute(null, e.target, t), P.setAriaCheckedAttribute(null, e.target, t)
    }, i.prototype.selectAllHandler = function(e, t, o) {
        for (var n = v(e.selAllEl).el[0], r = n.classList.contains("line-through"), i = v(e.vendorBoxes).el, s = 0; s < i.length; s++) "genven" === t && !o && _.alwaysActiveGenVendors.includes(i[s].getAttribute("gn-vid")) ? (P.setDisabledAttribute(null, i[s], !0), P.setCheckedAttribute(null, i[s], !0)) : P.setCheckedAttribute(null, i[s], o), L.PCShowConsentLabels && (i[s].parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(o ? L.PCActiveText : L.PCInactiveText));
        o ? "googleven" === t && L.UseGoogleVendors ? Object.keys(_.addtlVendorsList).forEach(function(e) {
            _.addtlVendors.vendorSelected[e] = !0
        }) : "genven" === t && _.showGeneralVendors && L.GeneralVendors.forEach(function(e) {
            _.genVendorsConsent[e.VendorCustomId] = !0
        }) : "googleven" === t ? _.addtlVendors.vendorSelected = {} : (_.genVendorsConsent = {}, _.alwaysActiveGenVendors.forEach(function(e) {
            _.genVendorsConsent[e] = !0
        })), r && n.classList.remove("line-through")
    }, i.prototype.SelectAllVendorConsentHandler = function(e) {
        var t = e.target.checked;
        if (_.showVendorService) c.toggleVendors(t);
        else {
            var o = v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Consent_El).el[0],
                n = o.classList.contains("line-through"),
                r = v(A.P_Vendor_Container + ' li:not([style="display: none;"]) .vendor-checkbox-handler').el,
                i = {};
            _.vendors.selectedVendors.map(function(e, t) {
                i[e.split(":")[0]] = t
            });
            for (var s = 0; s < r.length; s++) {
                P.setCheckedAttribute(null, r[s], t), L.PCShowConsentLabels && (r[s].parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(t ? L.PCActiveText : L.PCInactiveText));
                var a = r[s].getAttribute("vendorid"),
                    l = i[a];
                void 0 === l && (l = a), _.vendors.selectedVendors[l] = a + ":" + t
            }
            n && o.classList.remove("line-through")
        }
        P.setCheckedAttribute(null, e.target, t), P.setAriaCheckedAttribute(null, e.target, t)
    }, i.prototype.onVendorToggle = function(o, e) {
        var t = _.vendors,
            n = _.addtlVendors,
            r = e === de.LI ? t.selectedLegIntVendors : e === de.AddtlConsent ? [] : t.selectedVendors,
            i = !1,
            s = Number(o);
        r.some(function(e, t) {
            e = e.split(":");
            if (e[0] === o) return s = t, i = "true" === e[1], !0
        }), e === de.LI ? (mo.triggerGoogleAnalyticsEvent(Bo, i ? rn : sn, t.list.find(function(e) {
            return e.vendorId === o
        }).vendorName + ": " + k.IdPatterns.Pur + o), t.selectedLegIntVendors[s] = o + ":" + !i, b.legIntSettings.PShowLegIntBtn || g.vendorLegIntToggleEvent()) : e === de.AddtlConsent ? (n.vendorSelected[o] ? delete n.vendorSelected[o] : n.vendorSelected[o] = !0, g.venAdtlSelAllTglEvent()) : (mo.triggerGoogleAnalyticsEvent(Bo, i ? nn : on, t.list.find(function(e) {
            return e.vendorId === o
        }).vendorName + ": " + k.IdPatterns.Pur + o), t.selectedVendors[s] = o + ":" + !i, g.vendorsListEvent())
    }, i.prototype.onVendorDisclosure = function(r) {
        var i;
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = _.discVendors)[r].isFetched ? [3, 4] : (t[r].isFetched = !0, o = t[r].disclosureUrl, n = void 0, null != (i = S.moduleInitializer) && i.DisclosureCDNUrl ? (o = S.moduleInitializer.DisclosureCDNUrl + "/" + r + ".json", [4, Kt.getStorageDisclosure(o)]) : [3, 2]);
                    case 1:
                        if (n = e.sent()) return [2, g.updateVendorDisclosure(r, n)];
                        o = t[r].disclosureUrl, e.label = 2;
                    case 2:
                        return [4, Kt.getStorageDisclosure(o)];
                    case 3:
                        return n = e.sent(), [2, g.updateVendorDisclosure(r, n)];
                    case 4:
                        return [2]
                }
            })
        })
    }, i.prototype.tglFltrOptionHandler = function(e) {
        e && e.target.classList.contains("category-filter-handler") && P.setCheckedAttribute(null, e.target, e.target.checked)
    }, i.prototype.selectVendorsGroupHandler = function(e) {
        u.toggleAccordionStatus(e);
        var t = e.target.getAttribute("leg-vendorid"),
            o = e.target.getAttribute("vendorid"),
            n = e.target.getAttribute("addtl-vid"),
            r = e.target.getAttribute("disc-vid");
        t ? u.onVendorToggle(t, de.LI) : o ? u.onVendorToggle(o, de.Consent) : n && u.onVendorToggle(n, de.AddtlConsent), r && u.onVendorDisclosure(r), (t || o || n) && (P.setCheckedAttribute(null, e.target, e.target.checked), L.PCShowConsentLabels) && (e.target.parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(e.target.checked ? L.PCActiveText : L.PCInactiveText))
    }, i.prototype.toggleVendorFiltersHandler = function() {
        var e, t = !1,
            o = v("#onetrust-pc-sdk " + A.P_Fltr_Modal).el[0];
        switch (b.pcName) {
            case rt:
            case ot:
            case nt:
            case st:
                (t = "block" === o.style.display) ? u.closeFilter(): (e = v("#onetrust-pc-sdk " + A.P_Triangle).el[0], v(e).attr("style", "display: block;"), v(o).attr("style", "display: block;"), e = Array.prototype.slice.call(o.querySelectorAll("[href], input, button")), No.setPCFocus(e));
                break;
            case it:
                896 < window.innerWidth || 896 < window.screen.height ? d(o, "width: 400px;", !0) : d(o, "height: 100%; width: 100%;"), o.querySelector(".ot-checkbox input").focus();
                break;
            default:
                return
        }
        S.isV2Template && !t && (v("#onetrust-pc-sdk").addClass("ot-shw-fltr"), v("#onetrust-pc-sdk .ot-fltr-scrlcnt").el[0].scrollTop = 0)
    }, i.prototype.clearFiltersHandler = function() {
        u.setAriaLabelforButtonInFilter(L.PCenterFilterClearedAria);
        for (var e = v("#onetrust-pc-sdk " + A.P_Fltr_Modal + " input").el, t = 0; t < e.length; t++) P.setCheckedAttribute(null, e[t], !1);
        u.isCookieList ? _.filterByCategories = [] : _.filterByIABCategories = []
    }, i.prototype.cancelFilterHandler = function() {
        _.showVendorService ? c.cancelFilter() : u.isCookieList ? On.cancelHostFilter() : g.cancelVendorFilter(), u.closeFilter(), v("#onetrust-pc-sdk #filter-btn-handler").focus()
    }, i.prototype.applyFilterHandler = function() {
        var e;
        u.setAriaLabelforButtonInFilter(L.PCenterFilterAppliedAria), _.showVendorService ? (e = c.getGroupsFilter(), c.filterVendorByGroup(e)) : u.isCookieList ? (e = On.updateHostFilterList(), g.loadHostList("", e), _.showTrackingTech && u.addEventAdditionalTechnologies()) : (e = g.updateVendorFilterList(), g.loadVendorList("", e)), v("" + u.FILTER_COUNT_SELECTOR).text(String(e.length)), u.closeFilter(), v("#onetrust-pc-sdk #filter-btn-handler").focus(), g.playSearchStatus(u.isCookieList)
    }, i.prototype.setAriaLabelforButtonInFilter = function(e) {
        var t = _.isPCVisible ? document.querySelector("#onetrust-pc-sdk span[aria-live]") : document.querySelector("#onetrust-banner-sdk span[aria-live]");
        if (!t) {
            (t = document.createElement("span")).classList.add("ot-scrn-rdr"), t.setAttribute("aria-atomic", "true");
            var o = void 0;
            if (_.isPCVisible ? o = document.getElementById(u.pcSDKSelector) : document.getElementById(u.bannerSelector) && (o = document.getElementById(u.bannerSelector)), !o) return;
            o.appendChild(t)
        }
        t.setAttribute("aria-atomic", "true"), t.setAttribute("aria-relevant", "additions"), t.setAttribute("aria-live", "assertive"), t.setAttribute(mt, e), u.timeCallback && clearTimeout(u.timeCallback), u.timeCallback = setTimeout(function() {
            u.timeCallback = null, t.setAttribute(mt, "")
        }, 900)
    }, i.prototype.setPcListContainerHeight = function() {
        v("#onetrust-pc-sdk " + A.P_Content).el[0].classList.contains("ot-hide") ? d(v("" + u.PC_SELECTOR).el[0], 'height: "";', !0) : setTimeout(function() {
            var e = window.innerHeight;
            768 <= window.innerWidth && 600 <= window.innerHeight && (e = .8 * window.innerHeight), !v("#onetrust-pc-sdk " + A.P_Content).el[0].scrollHeight || v("#onetrust-pc-sdk " + A.P_Content).el[0].scrollHeight >= e ? d(v("" + u.PC_SELECTOR).el[0], "height: " + e + "px;", !0) : d(v("" + u.PC_SELECTOR).el[0], "height: auto;", !0)
        })
    }, i.prototype.changeSelectedTab = function(e) {
        var t, o = v("#onetrust-pc-sdk .category-menu-switch-handler"),
            n = 0,
            r = v(o.el[0]);
        o.each(function(e, t) {
            v(e).el.classList.contains(A.P_Active_Menu) && (n = t, v(e).el.classList.remove(A.P_Active_Menu), r = v(e))
        }), e.keyCode === ae.DownArrow ? t = n + 1 >= o.el.length ? v(o.el[0]) : v(o.el[n + 1]) : e.keyCode === ae.UpArrow && (t = v(n - 1 < 0 ? o.el[o.el.length - 1] : o.el[n - 1])), this.tabMenuToggle(t, r)
    }, i.prototype.changeSelectedTabV2 = function(e) {
        var t, o = e.target.parentElement,
            e = (e.keyCode === ae.DownArrow ? t = o.nextElementSibling || o.parentElement.firstChild : e.keyCode === ae.UpArrow && (t = o.previousElementSibling || o.parentElement.lastChild), t.querySelector(".category-menu-switch-handler"));
        e.focus(), this.groupTabClick(e)
    }, i.prototype.categoryMenuSwitchHandler = function() {
        for (var o = this, e = v("#onetrust-pc-sdk .category-menu-switch-handler").el, n = this, t = 0; t < e.length; t++)(t => {
            e[t].addEventListener("click", n.groupTabClick), e[t].addEventListener("keydown", function(e) {
                if (1 <= t && e.shiftKey && 9 === e.keyCode && !L.ShowPreferenceCenterCloseButton && L.PCLayout.Tab && (e.preventDefault(), No.lastItem.focus()), 32 === e.keyCode || "space" === e.code) return o.groupTabClick(e.currentTarget), e.preventDefault(), !1
            })
        })(t)
    }, i.prototype.groupTabClick = function(e) {
        var t = v("#onetrust-pc-sdk " + A.P_Grp_Container).el[0],
            o = t.querySelector("." + A.P_Active_Menu),
            e = e.currentTarget || e,
            n = e.getAttribute("aria-controls");
        o.setAttribute("tabindex", -1), o.setAttribute("aria-selected", !1), o.classList.remove(A.P_Active_Menu), t.querySelector(A.P_Desc_Container + ":not(.ot-hide)").classList.add("ot-hide"), t.querySelector("#" + n).classList.remove("ot-hide"), e.setAttribute("tabindex", 0), e.setAttribute("aria-selected", !0), e.classList.add(A.P_Active_Menu)
    }, i.prototype.tabMenuToggle = function(e, t) {
        e.el.setAttribute("tabindex", 0), e.el.setAttribute("aria-selected", !0), t.el.setAttribute("tabindex", -1), t.el.setAttribute("aria-selected", !1), e.focus(), t.el.parentElement.parentElement.querySelector("" + A.P_Desc_Container).classList.add("ot-hide"), e.el.parentElement.parentElement.querySelector("" + A.P_Desc_Container).classList.remove("ot-hide"), e.el.classList.add(A.P_Active_Menu)
    }, i.prototype.closeFilter = function(e) {
        var t, o;
        void 0 === e && (e = !0), kn.checkIfPcSdkContainerExist() || (t = v("#onetrust-pc-sdk " + A.P_Fltr_Modal).el[0], o = v("#onetrust-pc-sdk " + A.P_Triangle).el[0], b.pcName === it ? 896 < window.innerWidth || 896 < window.screen.height ? d(t, "width: 0;", !0) : d(t, "height: 0;") : d(t, "display: none;"), o && v(o).attr("style", "display: none;"), S.isV2Template && v("#onetrust-pc-sdk").removeClass("ot-shw-fltr"), e && No.setFirstAndLast(No.getPCElements()))
    }, i.prototype.setBackButtonFocus = function() {
        v("#onetrust-pc-sdk .back-btn-handler").el[0].focus()
    }, i.prototype.setSearchInputFocus = function() {
        v(u.VENDOR_SEARCH_SELECTOR).el[0].focus()
    }, i.prototype.setCenterLayoutFooterHeight = function() {
        var e = u.pc;
        if (b.pcName === st && e) {
            var t = e.querySelectorAll("" + A.P_Desc_Container),
                o = e.querySelectorAll("li .category-menu-switch-handler");
            if (!e.querySelector(".category-menu-switch-handler + " + A.P_Desc_Container) && window.innerWidth <= 640)
                for (var n = 0; n < t.length; n++) o[n].insertAdjacentElement("afterend", t[n]);
            else e.querySelector(".category-menu-switch-handler + " + A.P_Desc_Container) && 640 < window.innerWidth && v(e.querySelector(".ot-tab-desc")).append(t)
        }
        u.pcCenterAndTabCheckButtonsOrderSizes(), u.setPanelLayoutButtonsSize(), u.setMainContentHeight()
    }, i.prototype.pcCenterAndTabCheckButtonsOrderSizes = function() {
        var e, t, o, n, r;
        L.PCTemplateUpgrade && S.fp.WebButtonCustomisations && (b.pcName === ot || b.pcName === st) && (window.innerWidth <= 500 || 20 < (null == (e = L.ConfirmText) ? void 0 : e.length) || 20 < (null == (e = L.AllowAllText) ? void 0 : e.length) || 20 < (null == (e = L.PCenterRejectAllButtonText) ? void 0 : e.length) ? u.stackButtons() : (e = document.querySelector(u.PC_SELECTOR), t = document.querySelector(u.PC_FOOTER), o = document.querySelector(u.otPcContainerSelector), n = document.querySelector("#ot-pc-lst"), null != (r = t) && r.style.setProperty("height", "auto"), r = ct, null != (e = null == (e = e) ? void 0 : e.classList) && e.contains("ot-ftr-stacked") && (r = lt), null != (e = t) && e.style.setProperty(pt, r + "px"), null != (t = o) && t.style.setProperty(pt, r + "px"), null != (e = n) && e.style.setProperty(pt, r + "px")))
    }, i.prototype.setPanelLayoutButtonsSize = function() {
        var e, t, o, n, r;
        L.PCTemplateUpgrade && S.fp.WebButtonCustomisations && b.pcName === rt && (o = document.querySelector(".ot-btn-container.ot-button-order-container")) && (t = (null == (t = o.children) ? void 0 : t.length) * lt / 3, t = Math.max(dt, Math.min(lt, t)), o.classList.contains("ot-hide") && (t = Math.min(ut, t)), o = document.querySelector(".ot-pc-footer"), n = document.querySelector("#ot-pc-lst"), r = document.querySelector(u.otPcContainerSelector), null != (e = o) && e.style.setProperty("height", "100%"), null != (e = o) && e.style.setProperty("display", "flex"), null != (e = o) && e.style.setProperty("flex-direction", "column"), null != (e = o) && e.style.setProperty(pt, t + "px"), null != (o = r) && o.style.setProperty(pt, t + "px"), null != (e = n)) && e.style.setProperty(pt, t + "px")
    }, i.prototype.stackButtons = function() {
        var e, t = document.querySelector(u.PC_FOOTER),
            o = document.querySelector(u.otPcContainerSelector),
            n = document.querySelector("#ot-pc-lst"),
            r = document.querySelector(".ot-btn-container.ot-button-order-container");
        r && (e = (null == (e = r) ? void 0 : e.children.length) * lt / 3, e = Math.max(dt, Math.min(lt, e)), r.classList.contains("ot-hide") && (e = Math.min(ut, e)), null != (r = t) && r.style.setProperty("height", "100%"), null != (r = t) && r.style.setProperty(pt, e + "px"), null != (t = o) && t.style.setProperty(pt, e + "px"), null != (r = n)) && r.style.setProperty(pt, e + "px")
    }, i.prototype.setMainContentHeight = function() {
        var e, t = this.pc,
            o = t.querySelector(u.PC_FOOTER),
            n = t.querySelector(".ot-pc-header"),
            r = L.PCLayout,
            i = (u.toggleFtrStackedClass(t), L.PCTemplateUpgrade || r.Center || (e = t.clientHeight - o.clientHeight - n.clientHeight - 3, L.PCTemplateUpgrade && !r.Tab && L.PCenterVendorListDescText && (e = e - ((i = v("#vdr-lst-dsc").el).length && i[0].clientHeight) - 10), d(t.querySelector("" + A.P_Vendor_List), "height: " + e + "px;", !0)), t.querySelector("" + A.P_Content));
        L.PCTemplateUpgrade && r.Center ? (e = 600 < window.innerWidth && 475 < window.innerHeight, !this.pcBodyHeight && e && (this.pcBodyHeight = i.scrollHeight), e ? (i = this.pcBodyHeight + o.clientHeight + n.clientHeight + 20) > .8 * window.innerHeight || 0 === this.pcBodyHeight ? d(t, "height: " + .8 * window.innerHeight + "px;", !0) : d(t, "height: " + i + "px;", !0) : d(t, "height: 95%;", !0)) : this.setPCContentAndListHeight(t, r)
    }, i.prototype.toggleFtrStackedClass = function(e) {
        var t = e.querySelectorAll(".ot-pc-footer button"),
            t = Array.from(t).filter(function(e) {
                return "none" !== getComputedStyle(e).display
            }),
            o = t[t.length - 1];
        e.classList.remove("ot-ftr-stacked"), t[0] && o && o.offsetTop > t[0].offsetTop + 1 && e.classList.add("ot-ftr-stacked")
    }, i.prototype.setPCContentAndListHeight = function(e, t) {
        var o = e.querySelector(u.PC_FOOTER),
            n = e.querySelector(".ot-pc-header"),
            r = e.querySelector("#ot-pc-lst");
        d(e.querySelector("" + A.P_Content), "height: " + (e.clientHeight - o.clientHeight - n.clientHeight - 3) + "px;", !0), t.Tab && d(r, "height: " + (e.clientHeight - o.clientHeight - n.clientHeight - 3) + "px;", !0)
    }, i.prototype.allowAllVisible = function(e) {
        e !== this.allowVisible && L.PCLayout.Tab && L.PCTemplateUpgrade && (this.pc && this.setMainContentHeight(), this.allowVisible = e)
    }, i.prototype.restorePc = function() {
        _.pcLayer === se.CookieList ? (u.hideCategoryContainer(!0), g.loadHostList("", _.filterByCategories), _.showTrackingTech && u.addEventAdditionalTechnologies(), v("" + u.FILTER_COUNT_SELECTOR).text(_.filterByCategories.length.toString())) : _.pcLayer === se.VendorList && (u.hideCategoryContainer(!1), u.setVendorContent()), _.isPCVisible = !1, u.toggleInfoDisplay(), _.pcLayer !== se.VendorList && _.pcLayer !== se.CookieList || (On.updateFilterSelection(_.pcLayer === se.CookieList), u.setBackButtonFocus(), No.setPCFocus(No.getPCElements()))
    }, i.prototype.toggleInfoDisplay = function() {
        var n;
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return xs.csBtnGroup && (v(u.fltgBtnSltr).addClass("ot-pc-open"), u.otGuardLogoPromise.then(function() {
                            L.cookiePersistentLogo.includes("ot_guard_logo.svg") && v(u.fltgBtnFSltr).attr(vt, "true")
                        }), v(u.fltgBtnBSltr).attr(vt, ""), v(u.fltgBtnBackBtn).el[0].style.display = "block"), [4, u.fetchAndSetupPC()];
                    case 1:
                        return e.sent(), b.pcName === nt && this.setPcListContainerHeight(), void 0 !== _.pcLayer && _.pcLayer !== se.Banner || (_.pcLayer = se.PrefCenterHome), t = v("" + u.PC_SELECTOR).el[0], v(".onetrust-pc-dark-filter").el[0].removeAttribute("style"), t.removeAttribute("style"), _.isPCVisible || (kn.showConsentNotice(), _.isPCVisible = !0, o = document.querySelector(u.otPcContainerSelector), null != (n = o) && n.setAttribute("tabindex", "-1"), L.PCTemplateUpgrade && (this.pc = t, o = t.querySelector("#accept-recommended-btn-handler"), this.allowVisible = o && 0 < o.clientHeight, this.setCenterLayoutFooterHeight(), u.getResizeElement().addEventListener("resize", u.setCenterLayoutFooterHeight), window.addEventListener("resize", u.setCenterLayoutFooterHeight)), v(document).on("keydown", u.closePCWhenEscPressed)), window.dispatchEvent(new CustomEvent("OneTrustPCLoaded", {
                            OneTrustPCLoaded: "yes"
                        })), u.captureInitialConsent(), b.requireSignatureEnabled && Zn.getInstance().setConsentIdInPC(), [2]
                }
            })
        })
    }, i.prototype.close = function(t) {
        return F(this, void 0, void 0, function() {
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return L.BCloseButtonType === Pe.Link ? _.bannerCloseSource = ee.ContinueWithoutAcceptingButton : _.bannerCloseSource = ee.BannerCloseButton, [4, C.bannerCloseButtonHandler(t)];
                    case 1:
                        return e.sent(), gn.removeAddedOTCssStyles(), u.getResizeElement().removeEventListener("resize", u.setCenterLayoutFooterHeight), window.removeEventListener("resize", u.setCenterLayoutFooterHeight), [2]
                }
            })
        })
    }, i.prototype.closePreferenceCenter = function(e) {
        e && e.preventDefault(), window.location.href = "https://otsdk//consentChanged"
    }, i.prototype.initializeAlartHtmlAndHandler = function() {
        _.skipAddingHTML = 0 < v("#onetrust-banner-sdk").length, _.skipAddingHTML || pr.insertAlertHtml(), this.initialiseAlertHandlers(), No.setBannerFocus()
    }, i.prototype.initialiseAlertHandlers = function() {
        var e = this,
            t = (pr.showBanner(), L.ForceConsent && !I.isCookiePolicyPage(L.AlertNoticeText) && v(".onetrust-pc-dark-filter").removeClass("ot-hide").css("z-index:2147483645;"), L.OnClickCloseBanner && document.body.addEventListener("click", C.bodyClickEvent), L.ScrollCloseBanner && (window.addEventListener("scroll", C.scrollCloseBanner), v(document).on("click", ".onetrust-close-btn-handler", C.rmScrollAndClickBodyEvents), v(document).on("click", "#onetrust-accept-btn-handler", C.rmScrollAndClickBodyEvents), v(document).on("click", "#accept-recommended-btn-handler", C.rmScrollAndClickBodyEvents)), this.addEventListnerForVendorsList(), L.FloatingRoundedIcon && v("#onetrust-banner-sdk #onetrust-cookie-btn").on("click", function(e) {
                _.pcSource = e.currentTarget, u.showCookieSettingsHandler(e)
            }), v("#onetrust-banner-sdk .onetrust-close-btn-handler").on("click", function(e) {
                setTimeout(function() {
                    Zn.getInstance().resetHealthSignatureData(), u.bannerCloseButtonHandler(e)
                }, 0)
            }), v("#onetrust-banner-sdk .ot-bnr-save-handler").on("click", u.bannerCloseButtonHandler), v("#onetrust-banner-sdk #onetrust-pc-btn-handler").on("click", function(e) {
                setTimeout(function() {
                    u.showCookieSettingsHandler(e)
                }, 0)
            }), v("#onetrust-banner-sdk #onetrust-accept-btn-handler").on("click", function() {
                setTimeout(function() {
                    C.allowAllEventHandler(!1)
                }, 0)
            }), v("#onetrust-banner-sdk #onetrust-reject-all-handler").on("click", function() {
                setTimeout(function() {
                    C.rejectAllEventHandler(!1)
                }, 0)
            }), v("#onetrust-banner-sdk .banner-option-input").on("click", b.bannerName === Ze ? u.toggleBannerOptions : u.toggleAccordionStatus), v("#onetrust-banner-sdk .ot-gv-list-handler").on("click", function(t) {
                return F(e, void 0, void 0, function() {
                    return M(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return _.cookieListType = ye.GenVen, [4, u.fetchAndSetupPC()];
                            case 1:
                                return e.sent(), u.loadCookieList(t.target), u.showCookieSettingsHandler(t), [2]
                        }
                    })
                })
            }), v("#onetrust-banner-sdk .category-switch-handler").on("click", u.toggleBannerCategory), document.getElementById("onetrust-banner-sdk"));
        L.ForceConsent && t && "none" !== window.getComputedStyle(t).display && v(document).on("keydown", u.shiftBannerFocus), v("#onetrust-banner-sdk").on("keydown", function(e) {
            32 !== e.keyCode && "Space" !== e.code && 13 !== e.keyCode && "Enter" !== e.code || I.findUserType(e)
        })
    }, i.prototype.addEventListnerForVendorsList = function() {
        (L.IsIabEnabled || L.UseGoogleVendors || _.showGeneralVendors) && !_.showVendorService && v(document).on("click", ".onetrust-vendors-list-handler", function(e) {
            setTimeout(function() {
                u.showAllVendors(e)
            }, 0)
        })
    }, i.prototype.getResizeElement = function() {
        var e = document.querySelector("#onetrust-pc-sdk .ot-text-resize");
        return e ? e.contentWindow || e : document
    }, i.prototype.insertCookieSettingText = function(e) {
        void 0 === e && (e = !1);
        for (var t = L.CookieSettingButtonText, o = v(".ot-sdk-show-settings").el, n = v(".optanon-toggle-display").el, r = 0; r < o.length; r++) v(o[r]).text(t), v(n[r]).text(t);
        e ? (null != (e = document.querySelector(".ot-sdk-show-settings")) && e.addEventListener("click", this.cookiesSettingsBoundListener), null != (e = document.querySelector(".optanon-toggle-display")) && e.addEventListener("click", this.cookiesSettingsBoundListener)) : u.initCookieSettingHandlers()
    }, i.prototype.genVendorToggled = function(e) {
        var t = e.target.getAttribute("gn-vid"),
            o = (Io.updateGenVendorStatus(t, e.target.checked), L.GeneralVendors.find(function(e) {
                return e.VendorCustomId === t
            }).Name);
        mo.triggerGoogleAnalyticsEvent(Bo, e.target.checked ? Xo : Qo, o + ": VEN_" + t), g.genVenSelectAllTglEvent()
    }, i.prototype.genVendorDetails = function(e) {
        u.toggleAccordionStatus(e)
    }, i.prototype.confirmPC = function(n) {
        return F(this, void 0, void 0, function() {
            var t, o;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (t = O.isAlertBoxClosedAndValid(), L.NoBanner && L.ShowPreferenceCenterCloseButton && !t) ? (_.bannerCloseSource = ee.BannerCloseButton, [4, C.bannerCloseButtonHandler()]) : [3, 2];
                    case 1:
                        e.sent(), e.label = 2;
                    case 2:
                        return o = I.isBannerVisible(), !S.moduleInitializer.MobileSDK || !t && o || u.closePreferenceCenter(n), [2]
                }
            })
        })
    }, i.prototype.captureInitialConsent = function() {
        _.initialGroupsConsent = JSON.parse(JSON.stringify(_.groupsConsent)), _.initialHostConsent = JSON.parse(JSON.stringify(_.hostsConsent)), _.showGeneralVendors && (_.initialGenVendorsConsent = JSON.parse(JSON.stringify(_.genVendorsConsent))), L.IsIabEnabled && (_.initialOneTrustIABConsent = JSON.parse(JSON.stringify(_.oneTrustIABConsent)), _.initialVendors = JSON.parse(JSON.stringify(_.vendors)), _.initialVendors.vendorTemplate = _.vendors.vendorTemplate), L.UseGoogleVendors && (_.initialAddtlVendorsList = JSON.parse(JSON.stringify(_.addtlVendorsList)), _.initialAddtlVendors = JSON.parse(JSON.stringify(_.addtlVendors))), _.vsIsActiveAndOptOut && (_.initialVendorsServiceConsent = new Map(_.vsConsent))
    }, i.prototype.getShowCookieSettingClassName = function(e) {
        if (!e || !e.target) return "";
        var e = e.target,
            t = e.className;
        if ("BUTTON" !== e.tagName) {
            e = e.closest("button");
            if (!e) return "";
            t = e.className
        }
        return "string" != typeof t ? "" : t
    };
    var u, fr = i;

    function i() {
        var t = this;
        this.allowVisible = !1, this.fltgBtnBackBtn = ".ot-floating-button__back button", this.fltgBtnBSltr = ".ot-floating-button__back svg", this.fltgBtnFrontBtn = ".ot-floating-button__front button", this.fltgBtnFSltr = ".ot-floating-button__front svg", this.fltgBtnSltr = "#ot-sdk-btn-floating", this.PC_SELECTOR = "#onetrust-pc-sdk", this.FILTER_COUNT_SELECTOR = "#onetrust-pc-sdk #filter-count", this.VENDOR_SEARCH_SELECTOR = "#onetrust-pc-sdk #vendor-search-handler", this.PC_FOOTER = ".ot-pc-footer", this.isCookieList = !1, this.pc = null, this.currentSearchInput = "", this.pcLinkSource = null, this.pcSDKSelector = "onetrust-pc-sdk", this.bannerSelector = "onetrust-banner-sdk", this.otPcContainerSelector = "#ot-pc-content", this.otGuardLogoResolve = null, this.otGuardLogoPromise = new Promise(function(e) {
            t.otGuardLogoResolve = e
        }), this.closePCWhenEscPressed = function(e) {
            var t, o = document.getElementById(u.pcSDKSelector);
            o && (t = "none" !== window.getComputedStyle(o).display, 27 === e.keyCode && o && t && ("block" === (o = v("#onetrust-pc-sdk " + A.P_Fltr_Modal).el[0]).style.display || "0px" < o.style.width ? (u.closeFilter(), v("#onetrust-pc-sdk #filter-btn-handler").focus()) : L.NoBanner && !L.ShowPreferenceCenterCloseButton || u.hideCookieSettingsHandler(), u.confirmPC()), t && 32 === e.keyCode || "Space" === e.code || 13 === e.keyCode || "Enter" === e.code) && I.findUserType(e)
        }, this.showCookieSettingsHandler = function(n) {
            return F(t, void 0, void 0, function() {
                var t, o;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (o = document.getElementById(u.pcSDKSelector), o && "none" !== window.getComputedStyle(o).getPropertyValue("display")) ? [2] : (v(document).on("keydown", u.closePCWhenEscPressed), n && n.stopPropagation(), n && n.target && (o = this.getShowCookieSettingClassName(n), t = "onetrust-pc-btn-handler" === n.target.id, o = o.includes("ot-sdk-show-settings"), (t || o) && (o = t ? Mo : Uo, mo.triggerGoogleAnalyticsEvent(Bo, o)), _.pcSource = n.target), [4, u.toggleInfoDisplay()]);
                        case 1:
                            return e.sent(), [2, !1]
                    }
                })
            })
        }, this.cookiesSettingsBoundListener = this.showCookieSettingsHandler.bind(this), this.backBtnHandler = function() {
            return _.pcLayer === se.IabIllustrations ? lr.hideUI() : (_.showVendorService && c.hideVendorList(), _.showTrackingTech && (u.currentSearchInput = "")), C.hideVendorsList(), b.pcName === nt && (v("#onetrust-pc-sdk " + A.P_Content).removeClass("ot-hide"), v("" + u.PC_SELECTOR).el[0].removeAttribute("style"), t.setPcListContainerHeight()), v("" + u.FILTER_COUNT_SELECTOR).text("0"), v(u.VENDOR_SEARCH_SELECTOR).length && (v(u.VENDOR_SEARCH_SELECTOR).el[0].value = ""), _.currentGlobalFilteredList = [], _.filterByCategories = [], _.filterByIABCategories = [], _.vendors.searchParam = "", u.closeFilter(), _.pcLayer = se.PrefCenterHome, t.pcLinkSource ? (t.pcLinkSource.focus(), t.pcLinkSource = null) : No.setPCFocus(No.getPCElements()), !1
        }, this.bannerCloseBoundListener = this.bannerCloseButtonHandler.bind(this), this.toggleGroupORVendorHandler = function(e) {
            var t = e.currentTarget;
            t.dataset.otVsId ? u.toggleVendorServiceHandler.bind(this)(e) : t.dataset.optanongroupid && u.toggleV2Category.bind(this)()
        }, this.toggleVendorFromListHandler = function(e) {
            var e = e.currentTarget,
                t = e.checked,
                o = e.dataset.otVsId,
                e = e.dataset.optanongroupid,
                n = document.getElementById("ot-vendor-id-" + o);
            w.toggleVendorService(e, o, t, n)
        }, this.toggleVendorServiceHandler = function(e) {
            var e = e.currentTarget,
                t = e.checked,
                o = e.dataset.otVsId,
                n = e.dataset.optanongroupid,
                n = (w.toggleVendorService(n, o, t, e), D.getVSById(o));
            u.setAriaLabelforButtonInFilter(n.ServiceName)
        }, this.toggleV2Category = function(e, t, o, n) {
            t || (r = this.getAttribute("data-optanongroupid"), i = "function" == typeof this.getAttribute, a = P.findIndex(_.dataGroupState, function(e) {
                return i && e.CustomGroupId === r
            }), t = _.dataGroupState[a]), void 0 === o && (o = v(this).is(":checked")), L.ChoicesBanner && P.setCheckedAttribute("#ot-bnr-grp-id-" + t.CustomGroupId, null, o), n ? document.querySelector("#ot-group-id-" + n) && (P.setCheckedAttribute("#ot-group-id-" + n, null, o), s = document.querySelector("#ot-group-id-" + n)) : (P.setCheckedAttribute(null, s = this, o), s.parentElement.querySelector(".ot-switch-nob")), L.PCShowConsentLabels && (s.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(o ? L.PCActiveText : L.PCInactiveText));
            var r, i, s, a = this instanceof HTMLElement && -1 !== this.getAttribute("id").indexOf("-leg-out");
            u.setAriaLabelforButtonInFilter(t.GroupName), u.updateGroupToggles(t, o, a)
        }, this.toggleBannerCategory = function() {
            var t = this,
                e = P.findIndex(_.dataGroupState, function(e) {
                    return "function" == typeof t.getAttribute && e.CustomGroupId === t.getAttribute("data-optanongroupid")
                }),
                e = _.dataGroupState[e],
                o = v(t).is(":checked");
            u.toggleV2Category(null, e, o, e.CustomGroupId)
        }, this.shiftBannerFocus = function(e) {
            var t = document.getElementById(u.pcSDKSelector),
                o = !1;
            t && (o = "none" !== window.getComputedStyle(t).display), "Tab" !== e.code || o || No.handleBannerFocus(e, e.shiftKey)
        }, this.toggleSubCategory = function(e, t, o, n) {
            t = t || this.getAttribute("data-optanongroupid");
            var r, t = D.getGroupById(t),
                n = (void 0 === o && (o = v(this).is(":checked")), n ? (P.setCheckedAttribute("#ot-sub-group-id-" + n, null, o), r = document.querySelector("#ot-sub-group-id-" + n)) : P.setCheckedAttribute(null, r = this, o), D.getParentGroup(t.Parent).ShowSubgroup),
                n = (L.PCShowConsentLabels && n && (r.parentElement.parentElement.querySelector(".ot-label-status").innerHTML = m.getInnerHtmlContent(o ? L.PCActiveText : L.PCInactiveText)), this instanceof HTMLElement && -1 !== this.getAttribute("id").indexOf("-leg-out"));
            u.setAriaLabelforButtonInFilter(t.GroupName), u.updateSubGroupToggles(t, o, n), w.setVendorStateByGroup(t, o)
        }
    }
    vr.prototype.initialiseLandingPath = function() {
        var e = O.needReconsent();
        _o.isLandingPage() ? _o.setLandingPathParam(location.href) : e && !O.awaitingReconsent() ? (_o.setLandingPathParam(location.href), T.writeCookieParam(y.OPTANON_CONSENT, h.AWAITING_RE_CONSENT, !0)) : (e || T.writeCookieParam(y.OPTANON_CONSENT, h.AWAITING_RE_CONSENT, !1), _o.setLandingPathParam(h.NOT_LANDING_PAGE), b.isSoftOptInMode && !S.moduleInitializer.MobileSDK && mo.setAlertBoxClosed(!0), L.NextPageCloseBanner && L.ShowAlertNotice && C.nextPageCloseBanner())
    };
    var Sr, mr = vr;

    function vr() {}
    Ar.prototype.insertCookiePolicyHtml = function() {
        if (v(this.ONETRUST_COOKIE_POLICY).length) {
            var e, t, o, n = document.createDocumentFragment(),
                r = (xs.cookieListGroup && (t = L.CookiesV2NewCookiePolicy ? ".ot-sdk-cookie-policy" : "#ot-sdk-cookie-policy-v2", o = document.createElement("div"), v(o).html(xs.cookieListGroup.html), o.removeChild(o.querySelector(t)), e = o.querySelector(".ot-sdk-cookie-policy"), L.useRTL) && v(e).attr("dir", "rtl"), e.querySelector("#cookie-policy-title").innerHTML = m.getInnerHtmlContent(L.CookieListTitle || ""), e.querySelector("#cookie-policy-description").innerHTML = m.getInnerHtmlContent(L.CookieListDescription || ""), e.querySelector("section")),
                i = e.querySelector("section tbody tr"),
                s = null,
                a = null;
            L.CookiesV2NewCookiePolicy || (s = e.querySelector("section.subgroup"), a = e.querySelector("section.subgroup tbody tr"), v(e).el.removeChild(e.querySelector("section.subgroup"))), v(e).el.removeChild(e.querySelector("section")), !v(this.COOKIE_POLICY_SELECTOR).length && v(this.OPTANON_POLICY_SELECTOR).length ? v(this.OPTANON_POLICY_SELECTOR).append('<div id="ot-sdk-cookie-policy"></div>') : (v(this.COOKIE_POLICY_SELECTOR).html(""), v(this.OPTANON_POLICY_SELECTOR).html(""));
            for (var l = 0, c = L.Groups; l < c.length; l++) {
                var d = c[l],
                    u = {
                        json: L,
                        group: d,
                        sectionTemplate: r,
                        tableRowTemplate: i,
                        cookieList: e,
                        fragment: n
                    };
                if (L.CookiesV2NewCookiePolicy) this.insertGroupHTMLV2(u);
                else if (this.insertGroupHTML(u), d.ShowSubgroup)
                    for (var p = 0, C = d.SubGroups; p < C.length; p++) {
                        var g = C[p],
                            g = {
                                json: L,
                                group: g,
                                sectionTemplate: s,
                                tableRowTemplate: a,
                                cookieList: e,
                                fragment: n
                            };
                        this.insertGroupHTML(g)
                    }
            }
        }
    }, Ar.prototype.insertGroupHTMLV2 = function(e) {
        function t(e) {
            return c.querySelector(e)
        }
        var o, n = this,
            r = e.json,
            i = e.group,
            s = e.sectionTemplate,
            a = e.tableRowTemplate,
            l = e.cookieList,
            e = e.fragment,
            c = s.cloneNode(!0),
            s = i.SubGroups,
            d = (v(t("tbody")).html(""), i.Hosts.slice()),
            u = i.FirstPartyCookies.slice(),
            p = d.length || u.length ? i.GroupName : "",
            s = (i.ShowSubgroup && s.length ? (o = c.querySelector("section.ot-sdk-subgroup ul li"), s.forEach(function(e) {
                var t = o.cloneNode(!0);
                d = d.concat(e.Hosts), u = u.concat(e.FirstPartyCookies), (e.Hosts.length || e.FirstPartyCookies.length) && (p += "," + e.GroupName), v(t.querySelector(".ot-sdk-cookie-policy-group")).html(e.GroupName), v(t.querySelector(".ot-sdk-cookie-policy-group-desc")).html(n.groupsClass.safeFormattedGroupDescription(e)), v(o.parentElement).append(t)
            }), c.querySelector("section.ot-sdk-subgroup ul").removeChild(o)) : c.removeChild(c.querySelector("section.ot-sdk-subgroup")), L.TTLGroupByTech && (this.setCookieListHeaderOrder(c), this.setCookieListBodyOrder(a)), r.IsLifespanEnabled ? v(t("th.ot-life-span")).el.innerHTML = m.getInnerHtmlContent(r.LifespanText) : v(t("thead tr")).el.removeChild(v(t("th.ot-life-span")).el), v(t("th.ot-cookies")).el.innerHTML = m.getInnerHtmlContent(r.CookiesText), v(t("th.ot-host")).el.innerHTML = m.getInnerHtmlContent(r.CategoriesText), v(t("th.ot-cookies-type")).el.innerHTML = m.getInnerHtmlContent(r.CookiesUsedText), v(t("th.ot-host-description")).el.innerHTML = m.getInnerHtmlContent(r.CookiesDescText), this.transformFirstPartyCookies(u, d, i)),
            C = !1;
        (C = L.TTLGroupByTech ? L.TTLShowTechDesc : s.some(function(e) {
            return e.Description
        })) || v(t("thead tr")).el.removeChild(v(t("th.ot-host-description")).el), v(t(".ot-sdk-cookie-policy-group")).html(i.GroupName), v(t(".ot-sdk-cookie-policy-group-desc")).html(this.groupsClass.safeFormattedGroupDescription(i)), L.TTLGroupByTech ? this.insertCookieLineByLine({
            json: r,
            hosts: s,
            tableRowTemplate: a,
            showHostDescription: C,
            st: t
        }) : this.insertHostHtmlV2({
            json: r,
            hosts: s,
            tableRowTemplate: a,
            showHostDescription: C,
            st: t
        }), 0 === s.length ? c.removeChild(c.querySelector("table")) : v(t("caption")).el.innerHTML = m.getInnerHtmlContent(p), v(l).append(c), v(e).append(l), v(this.COOKIE_POLICY_SELECTOR).append(e)
    }, Ar.prototype.insertHostHtmlV2 = function(e) {
        for (var l, c = e.json, d = e.tableRowTemplate, u = e.showHostDescription, p = e.st, C = this, t = 0, o = e.hosts; t < o.length; t++)(e => {
            for (var t = d.cloneNode(!0), o = function(e) {
                    return t.querySelector(e)
                }, n = (C.clearCookieRowElement(o), []), r = [], i = 0, s = e.Cookies; i < s.length; i++) {
                var a = s[i],
                    a = ((l = a).IsSession ? n.push(c.LifespanTypeText) : n.push(I.getDuration(l)), l.Name);
                e.Type && (a = '\n                    <a href="https://cookiepedia.co.uk/cookies/' + l.Name + '"\n                        rel="noopener noreferrer" target="_blank" aria-label="' + l.Name + " " + L.NewWinTxt + '">\n                        ' + l.Name + "\n                    </a>"), r.push(a)
            }
            C.setDataLabelAttribute(o, c), C.createCookieRowHtmlElement({
                host: e,
                subGroupCookie: l,
                trt: o,
                json: c,
                lifespanText: n.join(", "),
                hostType: r.join(", ")
            }), C.removeLifeSpanOrHostDescription(c, u, t, o), v(p("tbody")).append(t)
        })(o[t])
    }, Ar.prototype.insertGroupHTML = function(e) {
        function t(e) {
            return l.querySelector(e)
        }
        var o, n = e.json,
            r = e.group,
            i = e.sectionTemplate,
            s = e.tableRowTemplate,
            a = e.cookieList,
            e = e.fragment,
            l = i.cloneNode(!0),
            i = (v(t("caption")).el.innerHTML = m.getInnerHtmlContent(r.GroupName), v(t("tbody")).html(""), v(t("thead tr")), n.IsLifespanEnabled ? v(t("th.life-span")).el.innerHTML = m.getInnerHtmlContent(n.LifespanText) : v(t("thead tr")).el.removeChild(v(t("th.life-span")).el), v(t("th.cookies")).el.innerHTML = m.getInnerHtmlContent(n.CookiesText), v(t("th.host")).el.innerHTML = m.getInnerHtmlContent(n.CategoriesText), !1);
        if (r.Hosts.some(function(e) {
                return e.description
            }) ? i = !0 : v(t("thead tr")).el.removeChild(v(t("th.host-description")).el), v(t(".ot-sdk-cookie-policy-group")).html(r.GroupName), v(t(".ot-sdk-cookie-policy-group-desc")).html(this.groupsClass.safeFormattedGroupDescription(r)), 0 < r.FirstPartyCookies.length) {
            v(t(".cookies-used-header")).html(n.CookiesUsedText), v(t(".cookies-list")).html("");
            for (var c = 0; c < r.FirstPartyCookies.length; c++) o = r.FirstPartyCookies[c], v(t(".cookies-list")).append("<li> " + I.getCookieLabel(o, n.AddLinksToCookiepedia) + " <li>")
        } else l.removeChild(t(".cookies-used-header")), l.removeChild(t(".cookies-list"));
        this.insertHostHtmlV1({
            json: n,
            hosts: r.Hosts,
            tableRowTemplate: s,
            showHostDescription: i,
            st: t
        }), v(a).append(l), v(e).append(a), v(this.COOKIE_POLICY_SELECTOR).append(e)
    }, Ar.prototype.insertHostHtmlV1 = function(e) {
        for (var l = e.json, t = e.hosts, c = e.tableRowTemplate, d = e.showHostDescription, u = e.st, o = 0, n = t; o < n.length; o++)(e => {
            for (var t = c.cloneNode(!0), o = function(e) {
                    return t.querySelector(e)
                }, n = (v(o(".cookies-td ul")).html(""), v(o(".life-span-td ul")).html(""), v(o(".host-td")).html(""), v(o(".host-description-td")).html('<span class="ot-mobile-border"></span><p>' + e.Description + "</p> "), 0), r = 0, i = e.Cookies; r < i.length; r++) {
                var s = i[r],
                    a = "",
                    a = s.IsSession ? l.LifespanTypeText : 0 === s.Length ? "<1 " + l.LifespanDurationText || l.PCenterVendorListLifespanDays : s.Length + " " + l.LifespanDurationText || l.PCenterVendorListLifespanDays,
                    a = l.IsLifespanEnabled ? "&nbsp;(" + a + ")" : "";
                v(o(".cookies-td ul")).append("<li> " + s.Name + " " + a + " </li>"), l.IsLifespanEnabled && (a = s.Length ? s.Length + " days" : "N/A", v(o(".life-span-td ul")).append("<li>" + a + "</li>")), 0 === n && (v(o(".host-td")).append('<span class="ot-mobile-border"></span>'), v(o(".host-td")).append('<a href="https://cookiepedia.co.uk/host/' + s.Host + '" rel="noopener noreferrer" target="_blank"\n                        aria-label="' + (e.DisplayName || e.HostName) + " " + L.NewWinTxt + '">' + (e.DisplayName || e.HostName) + "</a>")), n++
            }
            d || t.removeChild(o("td.host-description-td")), v(u("tbody")).append(t)
        })(n[o]);
        0 === t.length && v(u("table")).el.removeChild(v(u("thead")).el)
    }, Ar.prototype.transformFirstPartyCookies = function(e, t, o) {
        var n = this,
            r = t.slice(),
            t = (e.forEach(function(e) {
                n.populateHostGroup(e, r, L.firstPartyTxt)
            }), o.GeneralVendorsIds),
            e = (this.populateGenVendor(t, o, r), o.SubGroups || []);
        return e.length && e.forEach(function(e) {
            var t = e.GeneralVendorsIds;
            n.populateGenVendor(t, e, r)
        }), r
    }, Ar.prototype.populateGenVendor = function(e, o, n) {
        var r = this;
        e.length && e.forEach(function(t) {
            var e = L.GeneralVendors.find(function(e) {
                return e.VendorCustomId === t
            });
            e.Cookies.length && e.Cookies.forEach(function(e) {
                var t;
                e.category === o.GroupName && (t = e.isThirdParty ? "" : L.firstPartyTxt, r.populateHostGroup(e, n, t))
            })
        })
    }, Ar.prototype.populateHostGroup = function(t, e, o) {
        e.some(function(e) {
            if (e.HostName === t.Host && e.Type === o) return e.Cookies.push(t), !0
        }) || e.unshift({
            HostName: t.Host,
            DisplayName: t.Host,
            HostId: "",
            Description: "",
            Type: o,
            Cookies: [t]
        })
    }, Ar.prototype.insertCookieLineByLine = function(e) {
        for (var t = e.json, o = e.tableRowTemplate, n = e.showHostDescription, r = e.st, i = 0, s = e.hosts; i < s.length; i++)
            for (var a = s[i], l = 0, c = a.Cookies; l < c.length; l++) {
                var d = c[l],
                    u = d.IsSession ? t.LifespanTypeText : I.getDuration(d),
                    p = d.Name,
                    C = (a.Type && (p = '<a href="https://cookiepedia.co.uk/cookies/' + p + '"\n                        rel="noopener noreferrer" target="_blank" aria-label="' + p + " " + L.NewWinTxt + '">' + p + "\n                    </a>"), o.cloneNode(!0)),
                    g = this.queryToHtmlElement(C);
                this.clearCookieRowElement(g), this.createCookieRowHtmlElement({
                    host: a,
                    subGroupCookie: d,
                    trt: g,
                    json: t,
                    lifespanText: u,
                    hostType: p
                }), this.removeLifeSpanOrHostDescription(t, n, C, g), v(r("tbody")).append(C)
            }
    }, Ar.prototype.removeLifeSpanOrHostDescription = function(e, t, o, n) {
        e.IsLifespanEnabled || o.removeChild(n("td.ot-life-span-td")), t || o.removeChild(n("td.ot-host-description-td"))
    }, Ar.prototype.createCookieRowHtmlElement = function(e) {
        var t = e.host,
            o = e.subGroupCookie,
            n = e.trt,
            r = e.lifespanText,
            i = e.hostType,
            s = ".ot-host-td",
            e = (this.setDataLabelAttribute(n, e.json), v(n(".ot-host-description-td")).html('<span class="ot-mobile-border"></span><p>' + o.description + "</p> "), v(n(s)).append('<span class="ot-mobile-border"></span>'), t.DisplayName || t.HostName);
        v(n(s)).append(t.Type ? e : '<a href="https://cookiepedia.co.uk/host/' + o.Host + '" rel="noopener noreferrer" target="_blank"\n                        aria-label="' + e + " " + L.NewWinTxt + '">\n                        ' + e + "\n                        </a>"), n(".ot-cookies-td .ot-cookies-td-content").insertAdjacentHTML("beforeend", m.getInnerHtmlContent(i)), v(n(".ot-life-span-td .ot-life-span-td-content")).html(r), v(n(".ot-cookies-type .ot-cookies-type-td-content")).html(t.Type ? L.firstPartyTxt : L.thirdPartyTxt)
    }, Ar.prototype.setDataLabelAttribute = function(e, t) {
        var o = "data-label";
        e(".ot-host-td").setAttribute(o, t.CategoriesText), e(".ot-cookies-td").setAttribute(o, t.CookiesText), e(".ot-cookies-type").setAttribute(o, t.CookiesUsedText), e(".ot-life-span-td").setAttribute(o, t.LifespanText), e(".ot-host-description-td").setAttribute(o, t.CookiesDescText)
    }, Ar.prototype.clearCookieRowElement = function(e) {
        v(e(".ot-cookies-td span")).text(""), v(e(".ot-life-span-td span")).text(""), v(e(".ot-cookies-type span")).text(""), v(e(".ot-cookies-td .ot-cookies-td-content")).html(""), v(e(".ot-host-td")).html("")
    }, Ar.prototype.setCookieListHeaderOrder = function(e) {
        var e = e.querySelector("section table thead tr"),
            t = e.querySelector("th.ot-host"),
            o = e.querySelector("th.ot-cookies"),
            n = e.querySelector("th.ot-life-span"),
            r = e.querySelector("th.ot-cookies-type"),
            i = e.querySelector("th.ot-host-description");
        e.innerHTML = m.getInnerHtmlContent(""), e.appendChild(o.cloneNode(!0)), e.appendChild(t.cloneNode(!0)), e.appendChild(n.cloneNode(!0)), e.appendChild(r.cloneNode(!0)), e.appendChild(i.cloneNode(!0))
    }, Ar.prototype.setCookieListBodyOrder = function(e) {
        var t = e.querySelector("td.ot-host-td"),
            o = e.querySelector("td.ot-cookies-td"),
            n = e.querySelector("td.ot-life-span-td"),
            r = e.querySelector("td.ot-cookies-type"),
            i = e.querySelector("td.ot-host-description-td");
        e.innerHTML = m.getInnerHtmlContent(""), e.appendChild(o.cloneNode(!0)), e.appendChild(t.cloneNode(!0)), e.appendChild(n.cloneNode(!0)), e.appendChild(r.cloneNode(!0)), e.appendChild(i.cloneNode(!0))
    }, Ar.prototype.queryToHtmlElement = function(t) {
        return function(e) {
            return t.querySelector(e)
        }
    };
    var Tr, Pr = Ar;

    function Ar() {
        this.groupsClass = V, this.COOKIE_POLICY_SELECTOR = "#ot-sdk-cookie-policy", this.OPTANON_POLICY_SELECTOR = "#optanon-cookie-policy", this.ONETRUST_COOKIE_POLICY = "#ot-sdk-cookie-policy, #optanon-cookie-policy"
    }
    br.prototype.IsAlertBoxClosedAndValid = function() {
        return O.isAlertBoxClosedAndValid()
    }, br.prototype.LoadBanner = function() {
        mo.loadBanner()
    }, br.prototype.Init = function(e) {
        void 0 === e && (e = !1), Ge.insertViewPortTag(), xs.ensureHtmlGroupDataInitialised(), Ln.updateGtmMacros(!1), Sr.initialiseLandingPath(), e || co.initialiseCssReferences()
    }, br.prototype.FetchAndDownloadPC = function() {
        u.fetchAndSetupPC()
    }, br.prototype.ToggleInfoDisplay = function() {
        mo.triggerGoogleAnalyticsEvent(Bo, qo), u.toggleInfoDisplay()
    }, br.prototype.Close = function(e) {
        u.close(e)
    }, br.prototype.AllowAll = function(e) {
        I.shouldShowDoubleOptInSignal(!0) ? I.createDoubleOptInConfirmDialog(_.isPCVisible, function() {
            C.allowAllEvent(e)
        }) : C.allowAllEvent(e)
    }, br.prototype.RejectAll = function(e) {
        C.rejectAllEvent(e)
    }, br.prototype.sendReceipt = function() {
        var e = T.readCookieParam(y.OPTANON_CONSENT, h.INTERACTION_TYPE);
        Ns.createConsentTxn(!1, e, !1, !0, !0)
    }, br.prototype.setDataSubjectIdV2 = function(e, t, o) {
        void 0 === t && (t = !1), void 0 === o && (o = ""), (e || t) && (e && e.trim() && (e = e.replace(/ /g, ""), T.writeCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID, e, !0)), null != (e = o) && e.trim() && T.writeCookieParam(y.OPTANON_CONSENT, h.IDENTIFIER_TYPE, o.trim()), _.dsParams.isAnonymous = t, _.dsParams.forceUserConsentAttributes = !0, T.writeCookieParam(y.OPTANON_CONSENT, h.IS_ANONYMOUS_CONSENT, t ? "1" : "0"))
    }, br.prototype.getDataSubjectId = function() {
        return T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID, !0)
    }, br.prototype.getDSDefaultIdentifier = function() {
        var e;
        return null == (e = L.ConsentIntegration) ? void 0 : e.DefaultIdentifier
    }, br.prototype.synchroniseCookieWithPayload = function(n) {
        var e = T.readCookieParam(y.OPTANON_CONSENT, "groups"),
            e = P.strToArr(e),
            r = [];
        e.forEach(function(e) {
            var e = e.split(":"),
                t = D.getGroupById(e[0]),
                o = P.findIndex(n, function(e) {
                    return e.Id === t.PurposeId
                }),
                o = n[o];
            o ? o.TransactionType === He ? (r.push(e[0] + ":1"), t.Parent ? u.toggleSubCategory(null, t.CustomGroupId, !0, t.CustomGroupId) : u.toggleV2Category(null, t, !0, t.CustomGroupId)) : (r.push(e[0] + ":0"), t.Parent ? u.toggleSubCategory(null, t.CustomGroupId, !1, t.CustomGroupId) : u.toggleV2Category(null, t, !1, t.CustomGroupId)) : r.push(e[0] + ":" + e[1])
        }), Po.writeGrpParam(y.OPTANON_CONSENT, r)
    }, br.prototype.getGeolocationData = function() {
        return _.userLocation
    }, br.prototype.TriggerGoogleAnalyticsEvent = function(e, t, o, n) {
        mo.triggerGoogleAnalyticsEvent(e, t, o, n)
    }, br.prototype.ReconsentGroups = function() {
        var n = !1,
            e = T.readCookieParam(y.OPTANON_CONSENT, "groups"),
            r = P.strToArr(e),
            i = P.strToArr(e.replace(/:0|:1/g, "")),
            s = !1,
            t = T.readCookieParam(y.OPTANON_CONSENT, "hosts"),
            a = P.strToArr(t),
            l = P.strToArr(t.replace(/:0|:1/g, "")),
            c = ["inactive", "inactive landingpage", "do not track"];
        e && (L.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                var t = e.CustomGroupId,
                    o = P.indexOf(i, t); - 1 !== o && (e = D.getGrpStatus(e).toLowerCase(), -1 < c.indexOf(e)) && (n = !0, r[o] = t + ("inactive landingpage" === e ? ":1" : ":0"))
            })
        }), n) && Po.writeGrpParam(y.OPTANON_CONSENT, r), t && (L.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(n) {
                n.Hosts.forEach(function(e) {
                    var t, o = P.indexOf(l, e.HostId); - 1 !== o && (t = D.getGrpStatus(n).toLowerCase(), -1 < c.indexOf(t)) && (s = !0, a[o] = e.HostId + ("inactive landingpage" === t ? ":1" : ":0"))
                })
            })
        }), s) && Po.writeHstParam(y.OPTANON_CONSENT, a)
    }, br.prototype.SetAlertBoxClosed = function(e) {
        mo.setAlertBoxClosed(e)
    }, br.prototype.GetDomainData = function() {
        return b.pubDomainData
    }, br.prototype.setGeoLocation = function(e, t) {
        _.userLocation = {
            country: e,
            state: t = void 0 === t ? "" : t,
            stateName: ""
        }
    }, br.prototype.changeLang = function(t) {
        var o;
        t !== _.lang && (o = S.moduleInitializer, Kt.getLangJson(t).then(function(e) {
            e ? (b.init(e), xs.fetchAssets(t).then(function() {
                var e = document.getElementById("onetrust-style"),
                    e = (e && (e.textContent = ""), co.initialiseCssReferences(), o.IsSuppressPC && !_.isPCVisible || (P.removeChild(v("#onetrust-pc-sdk").el), _.vendorDomInit = !1, _.genVendorDomInit = !1, N.insertPcHtml(), u.initialiseConsentNoticeHandlers(), L.IsIabEnabled && (O.assignIABDataWithGlobalVendorList(_.gvlObj), g.InitializeVendorList()), _.isPCVisible && u.restorePc()), !0);
                P.removeChild(v("#onetrust-banner-sdk").el), O.isAlertBoxClosedAndValid() || o.IsSuppressBanner && (o.IsSuppressBanner, _.skipAddingHTML) || L.NoBanner || !L.ShowAlertNotice || (u.initializeAlartHtmlAndHandler(), No.setBannerFocus(), e = !1), kr.initCookiePolicyAndSettings(), P.removeChild(v("#ot-sdk-btn-floating").el), qs.insertCSBtn(e), kr.processedHtml = null, kr.updateTCStringOnLangChange(t)
            })) : console.error("Language:" + t + " doesn't exist for the geo rule")
        }))
    }, br.prototype.updateTCStringOnLangChange = function(e) {
        b.isIab2orv2Template && (_.consentLanguage = e, _.tcModel.consentLanguage = _.consentLanguage, _.tcModel.useNonStandardTexts = L.UseNonStandardStacks, O.isAlertBoxClosedAndValid() || I.updateTCString())
    }, br.prototype.initCookiePolicyAndSettings = function(e) {
        var t;
        (e = void 0 === e ? !1 : e) && (null != (t = document.querySelector(".ot-sdk-show-settings")) && t.removeEventListener("click", u.cookiesSettingsBoundListener), null != (t = document.querySelector(".optanon-toggle-display"))) && t.removeEventListener("click", u.cookiesSettingsBoundListener), S.fp.CookieV2TrackingTechnologies ? qs.insertTrackingTechnologies() : Tr.insertCookiePolicyHtml(), u.insertCookieSettingText(e)
    }, br.prototype.showVendorsList = function() {
        _.pcLayer !== se.VendorList && (u.showAllVendors(), mo.triggerGoogleAnalyticsEvent(Bo, Ko))
    }, br.prototype.getTestLogData = function() {
        var e = L.Groups,
            t = b.pubDomainData,
            o = S.moduleInitializer.Version,
            o = (console.info("%cWelcome to OneTrust Log", "padding: 8px; background-color: #43c233; color: white; font-style: italic; border: 1px solid black; font-size: 1.5em;"), console.info("Script is for: %c" + (t.Domain || L.optanonCookieDomain), "padding: 4px 6px; font-style: italic; border: 2px solid #43c233; font-size: 12px;"), console.info("Script Version Published: " + o), console.info("The consent model is: " + t.ConsentModel.Name), null !== O.alertBoxCloseDate()),
            n = (console.info("Consent has " + (o ? "" : "not ") + "been given " + (o ? "👍" : "🛑")), Ln.checkAndWarnGCMConfig(), []),
            r = (e.forEach(function(e) {
                var t = "",
                    t = e.Status && "always active" === e.Status.toLowerCase() ? "Always Active" : V.isGroupActive(e) ? "Active" : "Inactive";
                n.push({
                    CustomGroupId: e.CustomGroupId,
                    GroupName: e.GroupName,
                    Status: t
                })
            }), console.groupCollapsed("Current Category Status"), console.table(n), console.groupEnd(), []),
            o = (t.GeneralVendors.forEach(function(e) {
                r.push({
                    CustomGroupId: e.VendorCustomId,
                    Name: e.Name,
                    Status: kr.isCategoryActive(e.VendorCustomId) ? "active" : "inactive"
                })
            }), console.groupCollapsed("General Vendor Ids"), console.table(r), console.groupEnd(), b.getRegionRule()),
            t = _.userLocation,
            i = S.moduleInitializer.GeoRuleGroupName,
            t = (b.conditionalLogicEnabled ? console.groupCollapsed("Geolocation, Template & Condition") : console.groupCollapsed("Geolocation and Template"), _.userLocation.country && console.info("The Geolocation is " + t.country.toUpperCase()), console.info("The Geolocation rule is " + o.Name), console.info("The GeolocationRuleGroup is " + i), b.canUseConditionalLogic && console.info("The Condition name is " + b.Condition.Name), console.info("The TemplateName is " + b.getTemplateName()), console.groupEnd(), e.filter(function(e) {
                return V.isGroupActive(e) && "COOKIE" === e.Type
            }));
        console.groupCollapsed("The cookies expected to be active if blocking has been implemented are"), t.forEach(function(e) {
            console.groupCollapsed(e.GroupName);
            e = kr.getAllFormatCookiesForAGroup(e);
            console.table(e, ["Name", "Host", "description"]), console.groupEnd()
        }), console.groupEnd()
    }, br.prototype.isCategoryActive = function(e) {
        return -1 !== window.OptanonActiveGroups.indexOf("," + e + ",")
    }, br.prototype.getAllFormatCookiesForAGroup = function(e) {
        var t = [];
        return e.FirstPartyCookies.forEach(function(e) {
            return t.push({
                Name: e.Name,
                Host: e.Host,
                Description: e.description
            })
        }), (null == (e = e.Hosts) ? void 0 : e.reduce(function(e, t) {
            return e.concat(JSON.parse(JSON.stringify(t.Cookies)))
        }, [])).forEach(function(e) {
            return t.push({
                Name: e.Name,
                Host: e.Host,
                Description: e.description
            })
        }), t
    }, br.prototype.updateSingularConsent = function(l, c) {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, u.fetchAndSetupPC()];
                    case 1:
                        for (e.sent(), b.apiSource = oe.UpdateConsent, t = c.split(","), o = [], n = 0, r = t; n < r.length; n++) s = r[n], s = s.split(":"), i = s[0], s = s[1], a = Boolean(Number(s)), l === ht ? "always active" === D.getGrpStatus(D.getGroupById(i)) || (kr.updateConsentArray(_.groupsConsent, i, s), o.push({
                            id: i,
                            isEnabled: a
                        })) : l === yt ? kr.updateConsentArray(_.hostsConsent, i, s) : l === ft ? _.genVendorsConsent[i] = a : l === St && o.push({
                            id: i,
                            isEnabled: a
                        });
                        return C.handleTogglesOnSingularConsentUpdate(l, o), [2]
                }
            })
        })
    }, br.prototype.vendorServiceEnabled = function() {
        return _.showVendorService
    }, br.prototype.updateGCM = function(e) {
        e || console.error("No callback passed to the UpdateGCM"), b.gcmUpdateCallback = e
    }, br.prototype.updateConsentArray = function(e, t, o) {
        var n = e.findIndex(function(e) {
            return e === t + ":0" || e === t + ":1"
        }); - 1 < n ? e[n] = t + ":" + o : e.push(t + ":" + o)
    };
    var kr, Ir = br;

    function br() {
        this.processedHtml = "", this.useGeoLocationService = !0, this.IsAlertBoxClosed = this.IsAlertBoxClosedAndValid, this.InitializeBanner = function() {
            return qs.initBanner()
        }, this.getHTML = function() {
            return document.getElementById("onetrust-banner-sdk") || (N.insertPcHtml(), pr.insertAlertHtml()), kr.processedHtml || (kr.processedHtml = document.querySelector("#onetrust-consent-sdk").outerHTML), kr.processedHtml
        }, this.getCSS = function() {
            return co.processedCSS
        }, this.setConsentProfile = function(e) {
            var t, o;
            e.customPayload && null != (t = o = e.customPayload) && t.Interaction && T.writeCookieParam(y.OPTANON_CONSENT, h.INTERACTION_COUNT, o.Interaction), kr.setDataSubjectIdV2(e.identifier, e.isAnonymous, e.identifierType), kr.synchroniseCookieWithPayload(e.purposes), C.executeOptanonWrapper()
        }, this.InsertScript = function(e, t, o, n, r, i) {
            var s, a = null != n && void 0 !== n,
                l = a && void 0 !== n.ignoreGroupCheck && !0 === n.ignoreGroupCheck;
            if (V.canInsertForGroup(r, l) && !P.contains(_.srcExecGrps, r)) {
                _.srcExecGrpsTemp.push(r), a && void 0 !== n.deleteSelectorContent && !0 === n.deleteSelectorContent && P.empty(t);
                var c = document.createElement("script");
                switch (null != o && void 0 !== o && (s = !1, c.onload = c.onreadystatechange = function() {
                    s || this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || (s = !0, o())
                }), c.type = "text/javascript", c.src = e, i && (c.async = i), t) {
                    case "head":
                        document.getElementsByTagName("head")[0].appendChild(c);
                        break;
                    case "body":
                        document.getElementsByTagName("body")[0].appendChild(c);
                        break;
                    default:
                        var d = document.getElementById(t);
                        d && (d.appendChild(c), a) && void 0 !== n.makeSelectorVisible && !0 === n.makeSelectorVisible && P.show(t)
                }
                if (a && void 0 !== n.makeElementsVisible)
                    for (var u = 0, p = n.makeElementsVisible; u < p.length; u++) {
                        var C = p[u];
                        P.show(C)
                    }
                if (a && void 0 !== n.deleteElements)
                    for (var g = 0, h = n.deleteElements; g < h.length; g++) {
                        C = h[g];
                        P.remove(C)
                    }
            }
        }, this.InsertHtml = function(e, t, o, n, r) {
            var i = null != n && void 0 !== n,
                s = i && void 0 !== n.ignoreGroupCheck && !0 === n.ignoreGroupCheck;
            if (V.canInsertForGroup(r, s) && !P.contains(_.htmlExecGrps, r)) {
                if (_.htmlExecGrpsTemp.push(r), i && void 0 !== n.deleteSelectorContent && !0 === n.deleteSelectorContent && P.empty(t), P.appendTo(t, e), i && void 0 !== n.makeSelectorVisible && !0 === n.makeSelectorVisible && P.show(t), i && void 0 !== n.makeElementsVisible)
                    for (var a = 0, l = n.makeElementsVisible; a < l.length; a++) {
                        var c = l[a];
                        P.show(c)
                    }
                if (i && void 0 !== n.deleteElements)
                    for (var d = 0, u = n.deleteElements; d < u.length; d++) {
                        c = u[d];
                        P.remove(c)
                    }
                null != o && void 0 !== o && o()
            }
        }, this.BlockGoogleAnalytics = function(e, t) {
            window["ga-disable-" + e] = !V.canInsertForGroup(t)
        }
    }
    _r.prototype.getFieldsValues = function(e, t, o, n, r) {
        void 0 === r && (r = !1);
        e = this.getSectionFieldsMapping(e), t = this.getSectionFieldsMapping(t, !0), o = this.getDynamicFields(o, n), n = this.getMSPASectionFieldValue(), r = r ? this.getGpcSectionFieldValue() : {};
        return L.IsMSPAEnabled && L.MSPAOptionMode === De.MspaServiceProviderMode && S.fp.CookieIABGPPV2 ? this.serviceProviderMode(e, t, o, n, r) : R(R(R(R(R({}, e), t), o), n), r)
    }, _r.prototype.serviceProviderMode = function(e, t, o, n, r) {
        e = this.getNotApplicableValue(e), t = this.getNotApplicableValue(t), o = this.getNotApplicableValue(o);
        return R(R(R(R(R({}, e), t), o), n), r)
    }, _r.prototype.getNotApplicableValue = function(e) {
        var o = {};
        return Object.entries(e).forEach(function(e) {
            var t = e[0],
                e = e[1];
            Array.isArray(e) ? o[t] = e.map(function(e) {
                return 0
            }) : o[t] = 0
        }), o
    }, _r.prototype.getGpcSectionFieldValue = function() {
        var e = {};
        return e[Ve.GpcSegmentType] = 1, e[Ve.Gpc] = b.gpcEnabled, e
    }, _r.prototype.getMSPASectionFieldValue = function() {
        var e = {};
        return L.IsMSPAEnabled ? (e.MspaCoveredTransaction = 1, L.MSPAOptionMode === De.MspaServiceProviderMode ? (e.MspaServiceProviderMode = 1, e.MspaOptOutOptionMode = 2) : L.MSPAOptionMode === De.MspaOptOutOptionMode ? (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 1) : (e.MspaServiceProviderMode = 2, e.MspaOptOutOptionMode = 2)) : (e.MspaCoveredTransaction = 2, e.MspaServiceProviderMode = 0, e.MspaOptOutOptionMode = 0), e
    }, _r.prototype.getDynamicArrayFieldsValue = function(e, t) {
        for (var o = {}, n = [], r = this.getSectionFieldsMapping(t), i = 1; i <= Object.keys(r).length; i++) n.push(r[e + i]);
        return o[e] = n, o
    }, _r.prototype.getDynamicFields = function(e, t) {
        var o, n = {};
        return L.IsGPPKnownChildApplicable && e && (o = this.getDynamicArrayFieldsValue(we.KnownChildSensitiveDataConsents, e), n = R(R({}, n), o)), L.IsGPPDataProcessingApplicable && t && (o = this.getDynamicArrayFieldsValue(we.SensitiveDataProcessing, t), n = R(R({}, n), o)), n
    }, _r.prototype.getSectionFieldsMapping = function(e, o) {
        var n = this,
            r = (void 0 === o && (o = !1), {});
        return S.fp, Object.entries(e).forEach(function(e) {
            var t = e[0],
                e = n.evaluateValueOperators(e[1]);
            r[t] = n.calculateFieldValue(e, o)
        }), r
    }, _r.prototype.evaluateValueOperators = function(e) {
        var t, o, n = "",
            r = [];
        return e && (t = e.split(" && "), o = e.split(" || "), r = (1 < t.length ? (n = "&&", t) : 1 < o.length ? (n = "||", o) : (n = "", [e])).map(function(e) {
            return L.GPPPurposes[e] || ""
        })), {
            values: r,
            operator: n
        }
    }, _r.prototype.calculateFieldValue = function(e, t) {
        var o;
        if (e.values.length) switch (e.operator) {
            case "&&":
                o = this.calculateAndFieldValue(e.values, t);
                break;
            case "||":
                o = this.calculateOrFieldValue(e.values, t);
                break;
            default:
                o = this.calculateSingleFieldValue(e.values[0], t)
        } else o = 0;
        return o
    }, _r.prototype.calculateOrFieldValue = function(e, t) {
        var o = this;
        return this.isNotApplicable(e) ? 0 : (e = e.filter(function(e) {
            return "" !== e.trim()
        }).some(function(e) {
            return o.fieldValueCondition(e, t)
        }), this.calculateFieldValueFromBit(e, t))
    }, _r.prototype.calculateAndFieldValue = function(e, t) {
        var o = this;
        return this.isNotApplicable(e) ? 0 : (e = e.every(function(e) {
            return o.fieldValueCondition(e, t)
        }), this.calculateFieldValueFromBit(e, t))
    }, _r.prototype.calculateSingleFieldValue = function(e, t) {
        return e && this.isValidGroup(e) ? (e = this.fieldValueCondition(e, t), this.calculateFieldValueFromBit(e, t)) : 0
    }, _r.prototype.isValidGroup = function(e) {
        e = e ? D.getGroupById(e) : null;
        return !!e && b.isValidConsentNoticeGroup(e, L.IsIabEnabled)
    }, _r.prototype.calculateFieldValueFromBit = function(e, t) {
        t = t ? e ? 1 : 0 : e ? 2 : 1;
        return t
    }, _r.prototype.isNotApplicable = function(e) {
        var t = this;
        return !e.some(function(e) {
            return Boolean(e) && t.isValidGroup(e)
        })
    }, _r.prototype.fieldValueCondition = function(e, t) {
        return t ? Boolean(e) : kr.isCategoryActive(e)
    };
    var Lr = _r;

    function _r() {}
    x(Nr, Er = Lr), Nr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(no, ro, io, so, !0)
    };
    var Er, Or, Dr, Vr, wr = Nr;

    function Nr() {
        return null !== Er && Er.apply(this, arguments) || this
    }(p = Or = Or || {}).SaleOptOut = "SaleOptOutCID", p.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (p = Dr = Dr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = Vr = Vr || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(Hr, Br = Lr), Hr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Or, Dr, null, Vr, !1)
    };
    var Br, Gr, xr = Hr;

    function Hr() {
        return null !== Br && Br.apply(this, arguments) || this
    }(p = Gr = Gr || {}).Version = "version", p.CmpId = "cmpId", p.CmpVersion = "cmpVersion", p.ConsentScreen = "consentScreen", p.ConsentLanguage = "consentLanguage", p.VendorListVersion = "vendorListVersion", p.PolicyVersion = "policyVersion", p.IsServiceSpecific = "isServiceSpecific", p.UseNonStandardStacks = "useNonStandardTexts", p.PurposeOneTreatment = "purposeOneTreatment", p.PublisherCountryCode = "publisherCountryCode", p.NumCustomPurposes = "numCustomPurposes", p.VendorsAllowedSegmentType = "VendorsAllowedSegmentType", p.VendorsDisclosedSegmentType = "VendorsDisclosedSegmentType", p.PublisherPurposesSegmentType = "PublisherPurposesSegmentType", jr.prototype.getSectionFieldsValues = function() {
        for (var e = {}, t = 0, o = Object.keys(Gr); t < o.length; t++) {
            var n = o[t],
                r = Gr[n];
            l.tcModel && l.tcModel[r] && (e[n] = l.tcModel[r])
        }
        e.ConsentLanguage = null == (i = e.ConsentLanguage) ? void 0 : i.toString().toUpperCase();
        var i = this.setPurposesData();
        return R(R({}, e), i)
    }, jr.prototype.setPurposesData = function() {
        var e = {},
            t = l.oneTrustIABConsent,
            o = this.getConsentValuesFromPurpose(t.purpose),
            o = (e.PurposeConsents = o, e.PublisherConsents = o, b.legIntSettings.PAllowLI ? this.getConsentValuesFromPurpose(t.legimateInterest) : []);
        return e.PurposeLegitimateInterests = o, e.PublisherLegitimateInterests = o, e.VendorConsents = this.syncVendorConsent(l.tcModel.vendorConsents), b.legIntSettings.PAllowLI && !o.length && (t.legIntVendors = []), e.VendorLegitimateInterests = this.getConsentValuesFromPurpose(P.distinctArray(t.legIntVendors), !0, !0), e.SpecialFeatureOptins = this.getConsentValuesFromPurpose(t.specialFeatures), e
    }, jr.prototype.syncVendorConsent = function(e) {
        var e = e.clone(),
            o = [];
        return e.forEach(function(e, t) {
            l.vendorsSetting[t] && l.vendorsSetting[t].consent || !e || o.push(t)
        }), e.unset(o), Array.from(e.values())
    }, jr.prototype.getConsentValuesFromPurpose = function(e, t, o) {
        var n = (t = void 0 === t ? !1 : t) ? 0 : 1;
        return (o = void 0 === o ? !1 : o) && (e = e.filter(function(e) {
            return "true" === e.split(":")[1]
        })), t ? e.map(function(e) {
            return parseInt(e.split(":")[n])
        }) : e.map(function(e) {
            return "true" === e.split(":")[n]
        })
    };
    var Rr, Fr, Mr, Ur, qr = jr;

    function jr() {}(p = Rr = Rr || {}).SaleOptOut = "SaleOptOutCID", p.SharingOptOut = "SharingOptOutCID", p.PersonalDataConsents = "PersonalDataCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (p = Fr = Fr || {}).SharingNotice = "SharingOptOutCID", p.SaleOptOutNotice = "SaleOptOutCID", p.SharingOptOutNotice = "SharingOptOutCID", p.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID || ConsumerHealthCID || CrimeVictimCID || NationalOriginCID || TransgenderCID", p.SensitiveDataLimitUseNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID || SensitivePICID || SensitiveSICID || UnionMembershipCID || CommunicationCID || ConsumerHealthCID || CrimeVictimCID || NationalOriginCID || TransgenderCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = Mr = Mr || {}).KnownChildSensitiveDataConsents1 = "PDCAboveAgeCID", p.KnownChildSensitiveDataConsents2 = "PDCBelowAgeCID", p.KnownChildSensitiveDataConsents3 = "KnownChildProcessAge16To17CID", (p = Ur = Ur || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", p.SensitiveDataProcessing9 = "SensitivePICID", p.SensitiveDataProcessing10 = "SensitiveSICID", p.SensitiveDataProcessing11 = "UnionMembershipCID", p.SensitiveDataProcessing12 = "CommunicationCID", p.SensitiveDataProcessing13 = "ConsumerHealthCID", p.SensitiveDataProcessing14 = "CrimeVictimCID", p.SensitiveDataProcessing15 = "NationalOriginCID", p.SensitiveDataProcessing16 = "TransgenderCID", x(Xr, Kr = Lr), Xr.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Rr, Fr, Mr, Ur, !0)
    };
    var Kr, zr, Wr, Yr, Jr = Xr;

    function Xr() {
        return null !== Kr && Kr.apply(this, arguments) || this
    }(p = zr = zr || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", p.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (p = Wr = Wr || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = Yr = Yr || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", x(ni, Qr = Lr), ni.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(zr, Wr, null, Yr, !0)
    };
    var Qr, Zr, $r, ei, ti, oi = ni;

    function ni() {
        return null !== Qr && Qr.apply(this, arguments) || this
    }(p = Zr = Zr || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (p = $r = $r || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = ei = ei || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", p.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", p.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (p = ti = ti || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(di, ri = Lr), di.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Zr, $r, ei, ti, !0)
    };
    var ri, ii, si, ai, li, ci = di;

    function di() {
        return null !== ri && ri.apply(this, arguments) || this
    }(p = ii = ii || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", p.AdditionalDataProcessingConsent = "PersonalDataCID", (p = si = si || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = ai = ai || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", p.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", p.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (p = li = li || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(yi, ui = Lr), yi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ii, si, ai, li, !0)
    };
    var ui, pi, Ci, gi, hi = yi;

    function yi() {
        return null !== ui && ui.apply(this, arguments) || this
    }(p = pi = pi || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", p.AdditionalDataProcessingConsent = "PersonalDataCID", p.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (p = Ci = Ci || {}).ProcessingNotice = "PersonalDataCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = gi = gi || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(Ai, fi = Lr), Ai.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(pi, Ci, null, gi, !0)
    };
    var fi, Si, mi, vi, Ti, Pi = Ai;

    function Ai() {
        return null !== fi && fi.apply(this, arguments) || this
    }(p = Si = Si || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (B = mi = mi || {}).ProcessingNotice = p.AdditionalDataProcessingConsent = "PersonalDataCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = vi = vi || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessBelowAge13CID", p.KnownChildSensitiveDataConsents2 = "KnownChildProcessBetweenAge13To16CID", p.KnownChildSensitiveDataConsents3 = "KnownChildProcessBetweenAge16To18CID", (B = Ti = Ti || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", x(Oi, ki = Lr), Oi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Si, mi, vi, Ti, !1)
    };
    var ki, Ii, bi, Li, _i, Ei = Oi;

    function Oi() {
        return null !== ki && ki.apply(this, arguments) || this
    }(p = Ii = Ii || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (B = bi = bi || {}).ProcessingNotice = p.AdditionalDataProcessingConsent = "PersonalDataCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = Li = Li || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", p.KnownChildSensitiveDataConsents2 = "KnownChildSellPICID", p.KnownChildSensitiveDataConsents3 = "KnownChildSharePICID", p.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To18CID", p.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To18CID", (B = _i = _i || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", B.SensitiveDataProcessing9 = "TransgenderCID", x(Gi, Di = Lr), Gi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Ii, bi, Li, _i, !0)
    };
    var Di, Vi, wi, Ni, Bi = Gi;

    function Gi() {
        return null !== Di && Di.apply(this, arguments) || this
    }(p = Vi = Vi || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", p.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (B = wi = wi || {}).ProcessingNotice = "AdditionalDataCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", B.SensitiveDataOptOutNotice = "RaceCID || ReligionCID || HealthCID || SexualOrientationCID || ImmigrationCID || GeneticCID || BiometricCID || GeolocationCID", (p = Ni = Ni || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(Ui, xi = Lr), Ui.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Vi, wi, null, Ni, !0)
    };
    var xi, Hi, Ri, Fi, Mi = Ui;

    function Ui() {
        return null !== xi && xi.apply(this, arguments) || this
    }(B = Hi = Hi || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", B.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (p = Ri = Ri || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = Fi = Fi || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "HealthCID", B.SensitiveDataProcessing4 = "SexualOrientationCID", B.SensitiveDataProcessing5 = "ImmigrationCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", x(Yi, qi = Lr), Yi.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Hi, Ri, null, Fi, !0)
    };
    var qi, ji, Ki, zi, Wi = Yi;

    function Yi() {
        return null !== qi && qi.apply(this, arguments) || this
    }(p = ji = ji || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", p.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (B = Ki = Ki || {}).ProcessingNotice = p.AdditionalDataProcessingConsent = "PersonalDataCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (p = zi = zi || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(ts, Ji = Lr), ts.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ji, Ki, null, zi, !0)
    };
    var Ji, Xi, Qi, Zi, $i, es = ts;

    function ts() {
        return null !== Ji && Ji.apply(this, arguments) || this
    }(B = Xi = Xi || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (p = Qi = Qi || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = Zi = Zi || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", B.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", B.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", B.KnownChildSensitiveDataConsents4 = "KnownChildSellAge16To17CID", B.KnownChildSensitiveDataConsents5 = "KnownChildProcessAge16To17CID", (p = $i = $i || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", p.SensitiveDataProcessing9 = "TransgenderCID", p.SensitiveDataProcessing10 = "SensitiveSICID", x(ls, os = Lr), ls.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(Xi, Qi, Zi, $i, !0)
    };
    var os, ns, rs, is, ss, as = ls;

    function ls() {
        return null !== os && os.apply(this, arguments) || this
    }(B = ns = ns || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (p = rs = rs || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = is = is || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", B.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", B.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (p = ss = ss || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "ImmigrationCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(gs, cs = Lr), gs.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ns, rs, is, ss, !0)
    };
    var cs, ds, us, ps, Cs = gs;

    function gs() {
        return null !== cs && cs.apply(this, arguments) || this
    }(B = ds = ds || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", B.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (p = us = us || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = ps = ps || {}).SensitiveDataProcessing1 = "RaceCID", B.SensitiveDataProcessing2 = "ReligionCID", B.SensitiveDataProcessing3 = "SexualOrientationCID", B.SensitiveDataProcessing4 = "ImmigrationCID", B.SensitiveDataProcessing5 = "HealthCID", B.SensitiveDataProcessing6 = "GeneticCID", B.SensitiveDataProcessing7 = "BiometricCID", B.SensitiveDataProcessing8 = "GeolocationCID", x(vs, hs = Lr), vs.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ds, us, null, ps, !1)
    };
    var hs, ys, fs, Ss, ms = vs;

    function vs() {
        return null !== hs && hs.apply(this, arguments) || this
    }(p = ys = ys || {}).SaleOptOut = "SaleOptOutCID", p.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", p.KnownChildSensitiveDataConsents = "KnownChildSellPICID || KnownChildProcessCID || KnownChildSharePICID || KnownChildSellAge16To18CID || KnownChildProcessAge16To18CID || KnownChildProcessBelowAge13CID || KnownChildProcessBetweenAge13To16CID || KnownChildProcessBetweenAge16To18CID || KnownChildSellAge16To17CID || KnownChildProcessAge16To17CID", (B = fs = fs || {}).SharingNotice = "SaleOptOutCID || TargetedAdvertisingOptOutCID", B.SaleOptOutNotice = "SaleOptOutCID", B.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", B.SensitiveDataProcessingOptOutNotice = "RaceCID || ReligionCID || SexualOrientationCID || ImmigrationCID || HealthCID || GeneticCID || BiometricCID || GeolocationCID", (p = Ss = Ss || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "SexualOrientationCID", p.SensitiveDataProcessing4 = "ImmigrationCID", p.SensitiveDataProcessing5 = "HealthCID", p.SensitiveDataProcessing6 = "GeneticCID", p.SensitiveDataProcessing7 = "BiometricCID", p.SensitiveDataProcessing8 = "GeolocationCID", x(As, Ts = Lr), As.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ys, fs, null, Ss, !1)
    };
    var Ts, Ps = As;

    function As() {
        return null !== Ts && Ts.apply(this, arguments) || this
    }(B = ks = ks || {}).SaleOptOut = "SaleOptOutCID", B.TargetedAdvertisingOptOut = "TargetedAdvertisingOptOutCID", (p = Is = Is || {}).ProcessingNotice = B.AdditionalDataProcessingConsent = "PersonalDataCID", p.SaleOptOutNotice = "SaleOptOutCID", p.TargetedAdvertisingOptOutNotice = "TargetedAdvertisingOptOutCID", (B = bs = bs || {}).KnownChildSensitiveDataConsents1 = "KnownChildProcessCID", B.KnownChildSensitiveDataConsents2 = "PDCAboveAgeCID", B.KnownChildSensitiveDataConsents3 = "PDCBelowAgeCID", (p = Ls = Ls || {}).SensitiveDataProcessing1 = "RaceCID", p.SensitiveDataProcessing2 = "ReligionCID", p.SensitiveDataProcessing3 = "HealthCID", p.SensitiveDataProcessing4 = "SexualOrientationCID", p.SensitiveDataProcessing5 = "TransgenderCID", p.SensitiveDataProcessing6 = "ImmigrationCID", p.SensitiveDataProcessing7 = "NationalOriginCID", p.SensitiveDataProcessing8 = "CrimeVictimCID", p.SensitiveDataProcessing9 = "GeneticCID", p.SensitiveDataProcessing10 = "BiometricCID", p.SensitiveDataProcessing11 = "GeolocationCID", x(Os, _s = Lr), Os.prototype.getSectionFieldsValues = function() {
        return this.getFieldsValues(ks, Is, bs, Ls, !0)
    };
    var ks, Is, bs, Ls, _s, Es = Os;

    function Os() {
        return null !== _s && _s.apply(this, arguments) || this
    }
    ws.prototype.initGppConsent = function() {
        this.initTemplateAndSectionInstance(), this.cmpApi.setApplicableSections(this.getApplicableSections(this.gppTemplateApplied));
        var o, n, e = this.readGppCookies(),
            t = this.getCurrentSectionName(this.gppTemplateApplied),
            r = !1;
        this.gppSectionId = this.getCurrentSectionId(this.gppTemplateApplied), e && (O.needReconsent() ? this.deleteAllGppCookies() : (this.cmpApi.setGppString(e), r = !0)), this.cmpApi.setSupportedAPIs((o = [], n = {}, Object.keys(Be).forEach(function(e) {
            var t = {},
                e = (t[e] = Be[e], Object.assign(t, n));
            n = e
        }), Object.keys(Ne).map(function(e) {
            return {
                name: e,
                value: Ne[e]
            }
        }).forEach(function(e) {
            e = n[e.name] + ":" + e.value;
            o.push(e)
        }), o.filter(function(e, t) {
            return o.indexOf(e) === t
        }))), this.cmpApi.setCmpStatus(null == (e = this.gppSDKRef) ? void 0 : e.cmpStatus.LOADED), (t && !this.cmpApi.hasSection(t) || b.gpcBrowserValueChanged || l.grpsSynced && 0 < l.grpsSynced.length) && this.setOrUpdateGppSectionString(t, r), window.OneTrust.OnConsentChanged(this.updateGppConsentString), this.cmpApi.setSignalStatus(null == (e = this.gppSDKRef) ? void 0 : e.signalStatus.READY)
    }, ws.prototype.initTemplateAndSectionInstance = function() {
        var e = S.fp;
        e && e.CookieIABGPPV2 ? this.gppTemplateApplied = this.getTemplateTypeByLocation() : this.gppTemplateApplied = this.getGppTemplateApplied(), this.gppSection = this.getSectionInstance(this.gppTemplateApplied)
    }, ws.prototype.setCmpDisplayStatus = function(e) {
        var t;
        "visible" === e ? this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.VISIBLE) : "hidden" === e ? this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.HIDDEN) : "disabled" === e && this.cmpApi.setCmpDisplayStatus(null == (t = this.gppSDKRef) ? void 0 : t.displayStatus.DISABLED)
    }, ws.prototype.setGppCookies = function(e, t) {
        t ? this.updateGppCookies(e) : (t = this.getCookiesChunk(e), e = Object.keys(t).length, this.writeGppCookies(e, t))
    }, ws.prototype.readGppCookies = function() {
        var e = Number(T.readCookieParam(y.OPTANON_CONSENT, Oe.ChunkCountParam) || 0);
        if (e <= 1) return 0 === e ? "" : T.getCookie(y.GPP_CONSENT);
        for (var t = "", o = 1; o <= e; o++) var n = T.getCookie("" + Oe.Name + o),
            t = t.concat(n);
        return t
    }, ws.prototype.deleteGppCookies = function(e, t) {
        if (0 < e && (1 === e && (T.setCookie("" + Oe.Name, "", 0, !0), e++), e <= t))
            for (var o = e; o <= t; o++) T.setCookie("" + Oe.Name + o, "", 0, !0)
    }, ws.prototype.getSectionInstance = function(e) {
        var t;
        switch (e) {
            case o.CPRA:
            case o.CCPA:
                t = new wr;
                break;
            case o.CDPA:
                t = new xr;
                break;
            case o.USNATIONAL:
                t = new Jr;
                break;
            case o.COLORADO:
                t = new oi;
                break;
            case o.OREGON:
                t = new Es;
                break;
            case o.FLORIDA:
                t = new Ei;
                break;
            case o.CONNECTICUT:
                t = new ci
        }
        return t = ["MONTANA", "TEXAS", "DELAWARE", "NEBRASKA", "IOWA", "TENNESSEE", "NEWJERSEY", "NEWHAMPSHIRE", "UCPA", "VIRGINIA", "IAB2V2"].includes(e) ? this.getSectionInstanceByTempType(e) : t
    }, ws.prototype.getSectionInstanceByTempType = function(e) {
        var t;
        switch (e) {
            case o.MONTANA:
                t = new hi;
                break;
            case o.TEXAS:
                t = new Pi;
                break;
            case o.DELAWARE:
                t = new Bi;
                break;
            case o.IOWA:
                t = new Mi;
                break;
            case o.NEBRASKA:
                t = new Wi;
                break;
            case o.TENNESSEE:
                t = new es;
                break;
            case o.NEWJERSEY:
                t = new as;
                break;
            case o.NEWHAMPSHIRE:
                t = new Cs;
                break;
            case o.UCPA:
                t = new Ps;
                break;
            case o.VIRGINIA:
                t = new ms;
                break;
            case o.IAB2V2:
                t = new qr
        }
        return t
    }, ws.prototype.getTemplateTypeByLocation = function() {
        var e;
        return b.getRegionRuleType() === o.IAB2V2 ? o.IAB2V2 : !L.UseGPPUSNational && "us" === (e = kr.getGeolocationData()).country.toLocaleLowerCase() && xe[e.state.toLocaleLowerCase()] || o.USNATIONAL
    }, ws.prototype.hasGPPSection = function() {
        return !!this.gppSection
    }, ws.prototype.getGppTemplateApplied = function() {
        return L.UseGPPUSNational ? o.USNATIONAL : b.getRegionRuleType()
    }, ws.prototype.initGppSDK = function() {
        var e, t = Number.parseInt((null == (t = S.moduleInitializer.GppData) ? void 0 : t.cmpId) || "28");
        return null == (e = this.gppSDKRef) ? void 0 : e.gppCmpApi(t, 1.1)
    }, ws.prototype.setOrUpdateGppSectionString = function(o, e) {
        var n = this,
            t = this.gppSection.getSectionFieldsValues();
        Object.entries(t).forEach(function(e) {
            var t = e[0];
            n.cmpApi.setFieldValue(o, t, e[1])
        }), this.cmpApi.fireSectionChange(o), this.setGppCookies(this.cmpApi.getGppString(), e)
    }, ws.prototype.getCurrentSectionName = function(t) {
        var e, o = "",
            n = Object.entries(Ne).find(function(e) {
                return e[0] === t
            });
        return o = null != (e = n) && e.length && 1 < n.length ? n[1] : o
    }, ws.prototype.getCurrentSectionId = function(t) {
        var e, o = 0,
            n = Object.entries(Be).find(function(e) {
                return e[0] === t
            });
        return o = null != (e = n) && e.length && 1 < n.length ? n[1] : o
    }, ws.prototype.updateGppCookies = function(e) {
        var e = this.getCookiesChunk(e),
            t = Object.keys(e).length,
            o = Number(T.readCookieParam(y.OPTANON_CONSENT, Oe.ChunkCountParam) || 0);
        this.writeGppCookies(t, e), t < o && this.deleteGppCookies(t + 1, o)
    }, ws.prototype.deleteAllGppCookies = function() {
        var e = Number(T.readCookieParam(y.OPTANON_CONSENT, Oe.ChunkCountParam) || 0);
        this.deleteGppCookies(1, e)
    }, ws.prototype.getCookiesChunk = function(e) {
        for (var t = {}, o = !1, n = e, r = 1; n.length;) {
            var i, s = void 0;
            n.length > Oe.ChunkSize ? s = Oe.ChunkSize : (s = n.length, o = 1 === r), o ? (t[Oe.Name] = n, n = "") : (i = n.slice(0, s), n = n.slice(s, n.length), t["" + Oe.Name + r] = i), r++
        }
        return t
    }, ws.prototype.writeGppCookies = function(e, t) {
        T.writeCookieParam(y.OPTANON_CONSENT, Oe.ChunkCountParam, e), T.writeCookieParam(y.OPTANON_CONSENT, Oe.gppSid, this.gppSectionId);
        for (var o = 0, n = Object.entries(t); o < n.length; o++) {
            var r = n[o],
                i = r[0];
            T.setCookie(i, r[1], L.ReconsentFrequencyDays)
        }
    }, ws.prototype.getSupportedAPIs = function() {
        return Object.values(Ne).filter(function(e, t, o) {
            return o.indexOf(e) === t
        })
    }, ws.prototype.getApplicableSections = function(e) {
        return [this.getCurrentSectionId(e)]
    };
    var Ds, Vs = ws;

    function ws() {
        var e, t = this;
        this.gppSDKRef = null == (e = window.otIabModule) ? void 0 : e.gppSdkRef, this.cmpApi = this.initGppSDK(), this.updateGppConsentString = function() {
            t.cmpApi.getCmpDisplayStatus() === (null == (e = t.gppSDKRef) ? void 0 : e.displayStatus.VISIBLE) && t.cmpApi.setCmpDisplayStatus(null == (e = t.gppSDKRef) ? void 0 : e.displayStatus.HIDDEN);
            var e = t.getCurrentSectionName(t.gppTemplateApplied);
            t.setOrUpdateGppSectionString(e, !0)
        }
    }
    Gs.prototype.isAuthUsr = function(e) {
        var t = T.readCookieParam(y.OPTANON_CONSENT, h.IS_ANONYMOUS_CONSENT);
        _.consentPreferences || "1" !== t ? T.writeCookieParam(y.OPTANON_CONSENT, "iType", "") : T.writeCookieParam(y.OPTANON_CONSENT, "iType", "" + Ce[e])
    }, Gs.prototype.isBannerClosedByIconOrLink = function() {
        var e = _.bannerCloseSource;
        return e === ee.BannerCloseButton || e === ee.ContinueWithoutAcceptingButton
    }, Gs.prototype.addCrossDeviceAttributes = function(e) {
        _.isV2Stub && (e.syncGroup = _.syncGrpId, L.UseGoogleVendors) && (e.gacString = T.getCookie(y.ADDITIONAL_CONSENT_STRING))
    }, Gs.prototype.addAdvAnalyticsAttributes = function(e, t) {
        var o, n = D.getGroupById(L.AdvancedAnalyticsCategory);
        n && this.canSendAdvancedAnalytics(e.purposes, n) && (o = window.navigator.userAgent, e.dsDataElements = {
            InteractionType: t,
            Country: _ && _.userLocation && /^[a-zA-Z]{2}$/.test(_.userLocation.country) ? _.userLocation.country.toUpperCase() : "",
            UserAgent: o,
            ConsentModel: L.ConsentModel.Name
        }, e.source = {
            purposeIds: [n.PurposeId],
            content: window.location.href,
            type: "WEB"
        }, this.addGeolocationAttributes(e, n))
    }, Gs.prototype.addGeolocationAttributes = function(e, t) {
        var o = _.userLocation;
        o && (e.geolocation = {
            country: o.country.toUpperCase(),
            state: o.state,
            stateName: o.stateName || "",
            purposeIds: t ? [t.PurposeId] : []
        })
    }, Gs.prototype.canSendConsentReceipt = function(e, t, o) {
        return e || b.apiSource === oe.UpdateConsent || _.consentInteractionType !== t || o
    }, Gs.prototype.addGppStringAttribute = function(e) {
        L.IsGPPEnabled && Ds.hasGPPSection() && Ds.updateGppConsentString();
        var t = T.getCookie(y.GPP_CONSENT);
        t && (e.gppString = t)
    }, Gs.prototype.addConsentStringToPayload = function(e) {
        var t = T.getMergedCookieByName(y.EU_PUB_CONSENT),
            o = b.getRegionRuleType();
        (b.isIab2orv2Template || "IABC" === o) && t ? e.consentString = {
            type: "IABC" === o ? "tcfcanada" : "IAB2" !== o && "IAB2V2" !== o ? "" : "tcfeu",
            content: t
        } : L.IsGPPEnabled && e.hasOwnProperty("gppString") && e.gppString && (e.consentString = {
            type: "gpp",
            content: e.gppString
        }, delete e.gppString)
    }, Gs.prototype.createConsentTxn = function(e, t, o, n, r, i) {
        void 0 === t && (t = ""), void 0 === o && (o = !1), void 0 === i && (i = "");
        var s = this.ensureConsentId(e, n = void 0 === n ? !0 : n, r = void 0 === r ? !1 : r),
            a = L.ConsentIntegration,
            l = this.getConsentURL(s.isAnonymous),
            c = this.canCreateConsentReceiptTxn(s, e);
        _.isV2Stub && t && this.isAuthUsr(t), c && (c = S.moduleInitializer, Ns.noOptOutToogle = c.TenantFeatures.CookieV2NoOptOut, Ns.isCloseByIconOrLink = this.isBannerClosedByIconOrLink(), s = {
            requestInformation: a.RequestInformation,
            identifier: s.id,
            identifierType: s.identifierType,
            customPayload: {
                Interaction: s.count,
                AddDefaultInteraction: s.addDfltInt
            },
            isAnonymous: s.isAnonymous,
            test: c.ScriptType === qe.TEST || c.ScriptType === qe.LOCAL_TEST,
            purposes: this.getConsetPurposes(e, i, t),
            dsDataElements: {}
        }, this.handleReceiptsWhenSendReceiptIsEnabled(s, r, t), this.addCrossDeviceAttributes(s), this.addAdvAnalyticsAttributes(s, t), this.addGppStringAttribute(s), this.addConsentStringToPayload(s), !c.MobileSDK && n && s.purposes.length && (i = JSON.stringify(s), c = this.getAuthToken(), this.sendBeaconSupported(e, c) ? (navigator.sendBeacon(l, i), O.dispatchConsentEvent()) : this.canSendConsentReceipt(o, t, r) && m.ajax({
            url: l,
            type: "post",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify(s),
            sync: e,
            success: function() {
                O.dispatchConsentEvent()
            },
            error: function() {
                O.dispatchConsentEvent()
            },
            token: c
        })), b.pubDomainData.ConsentIntegrationData = {
            consentApi: a.ConsentApi,
            consentPayload: s
        }), _.consentInteractionType = t, this.storeInteractionType(t)
    }, Gs.prototype.canCreateConsentReceiptTxn = function(e, t) {
        var o = L.ConsentIntegration,
            n = this.getConsentURL(e.isAnonymous),
            r = window.navigator.userAgent,
            r = /OneTrust/.test(r),
            i = _.isBotHeader;
        return n && o.RequestInformation && e.id && !r && !i && !this.blockDefaultReceiptCall(t)
    }, Gs.prototype.getConsentURL = function(e) {
        var t = L.ConsentIntegration,
            o = t.ConsentApi,
            n = S.moduleInitializer.TenantFeatures;
        return n && n.CookieV2NewConsentReceiptAPI && (e && t.AnonymousConsentApi ? o = t.AnonymousConsentApi : _.isV2Stub && t.CROConsentApi && (o = t.CROConsentApi)), o
    }, Gs.prototype.blockDefaultReceiptCall = function(e) {
        return !!e && !!S.fp.CMPNotGiven && !L.CanGenerateNotGivenReceipts
    }, Gs.prototype.ensureConsentId = function(e, t, o) {
        void 0 === o && (o = !1);
        var n, r = !1,
            i = this.getIdenTypeAndIsAnonAttr(),
            s = i.isAnonymous,
            i = i.identifierType,
            e = e || !t || o ? 0 : (r = !0, 1),
            a = T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID, !0);
        return a ? (n = parseInt(T.readCookieParam(y.OPTANON_CONSENT, h.INTERACTION_COUNT), 10), isNaN(n) || (t && !o && ++n, e = n, r = !1)) : (a = P.generateUUID(), T.writeCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID, a)), T.writeCookieParam(y.OPTANON_CONSENT, h.INTERACTION_COUNT, e), T.writeCookieParam(y.OPTANON_CONSENT, h.IS_ANONYMOUS_CONSENT, s ? "1" : "0"), {
            id: a,
            count: e,
            addDfltInt: r,
            identifierType: i,
            isAnonymous: s
        }
    }, Gs.prototype.getIdenTypeAndIsAnonAttr = function() {
        var e = !0,
            t = T.readCookieParam(y.OPTANON_CONSENT, h.IDENTIFIER_TYPE, !1),
            o = t,
            n = (!1 !== (null == (n = L.ConsentIntegration) ? void 0 : n.IdentifiedReceiptsAllowed) && _.isV2Stub || (e = !0, o = null == (n = L.ConsentIntegration) ? void 0 : n.DefaultAnonymousIdentifier), (_.isV2Stub || null != (n = L.ConsentIntegration) && n.IdentifiedReceiptsAllowed && !_.isV2Stub) && (e = (n = this.setAnonymityBasedOnKnownUserOrNot(e, o)).isAnonymous, o = n.idTypeUpdated), _.dsParams);
        return n.forceUserConsentAttributes && (n && n.hasOwnProperty("isAnonymous") && (e = n.isAnonymous), t) && (o = t), {
            isAnonymous: e,
            identifierType: o
        }
    }, Gs.prototype.setAnonymityBasedOnKnownUserOrNot = function(e, t) {
        var o, n = "",
            n = null != (o = _.dsParams) && o.id ? (e = !1, null != (o = t) && o.trim().length ? t : null == (o = L.ConsentIntegration) ? void 0 : o.DefaultIdentifier) : (e = !0, null == (t = L.ConsentIntegration) ? void 0 : t.DefaultAnonymousIdentifier);
        return {
            isAnonymous: e,
            idTypeUpdated: n
        }
    }, Gs.prototype.storeInteractionType = function(e) {
        var t;
        null != (t = e) && t.length && (isNaN(e) && (e = Ce[e]), T.writeCookieParam(y.OPTANON_CONSENT, h.INTERACTION_TYPE, e))
    }, Gs.prototype.getAuthToken = function() {
        var e = null;
        return e = L.ConsentIntegration.EnableJWTAuthForKnownUsers && _.dsParams.id && _.dsParams.token ? _.dsParams.token : e
    }, Gs.prototype.sendBeaconSupported = function(e, t) {
        return e && navigator.sendBeacon && !t
    }, Gs.prototype.handleReceiptsWhenSendReceiptIsEnabled = function(e, t, o) {
        !_.isV2Stub && t && ((t = T.getCookie(y.ALERT_BOX_CLOSED)) && (e.interactionDate = t), o && (e.InteractionType = o), e.enableDataElementDateValidation = !0)
    }, Gs.prototype.getGrpDetails = function(e, o) {
        var n = [];
        return e.forEach(function(e) {
            var e = e.split(":"),
                t = e[0],
                e = "true" === e[1] ? "1" : "0",
                t = Ns.getOptanonIdForIabGroup(t, o);
            n.push(t + ":" + e)
        }), n
    }, Gs.prototype.getOptanonIdForIabGroup = function(e, t) {
        var o;
        return t === ne.Purpose ? o = k.IdPatterns.Pur + e : t === ne.SpecialFeature && (o = k.IdPatterns.Spl_Ft + e), o
    }, Gs.prototype.getConsetPurposes = function(n, r, i) {
        var s = this,
            a = [],
            e = [],
            t = _.oneTrustIABConsent,
            o = t && t.purpose ? this.getGrpDetails(t.purpose, ne.Purpose) : [],
            l = t && t.specialFeatures ? this.getGrpDetails(t.specialFeatures, ne.SpecialFeature) : [],
            e = U(t.specialPurposes, t.features);
        return U(_.groupsConsent, o, l).forEach(function(e) {
            var t, e = e.split(":"),
                o = D.getGroupById(e[0]);
            o && o.PurposeId && (e = s.getTransactionType(o, e, n), t = s.processGroupConsentPurpose(o, e, a, r, i), s.setVSConsentByGroup(o, e, t).forEach(function(e) {
                return a.push(e)
            }))
        }), e.forEach(function(e) {
            e.purposeId && a.push({
                Id: e.purposeId,
                TransactionType: Fe
            })
        }), "GPC" !== r && "DNT" !== r || (a = a.filter(function(e) {
            return e.PurposeNote
        })), _.bannerCloseSource = ee.Unknown, a
    }, Gs.prototype.setVSConsentByGroup = function(e, o, n) {
        var r = [];
        return _.showVendorService && e.VendorServices && e.VendorServices.forEach(function(e) {
            var t;
            t = o.useOwn ? _.vsConsent.get(e.CustomVendorServiceId) ? He : Re : o.txnType, r.push("GPC" === n ? {
                Id: e.PurposeId,
                TransactionType: t,
                PurposeNote: {
                    noteId: L.ConsentIntegration.GPCReasonID,
                    noteType: "UNSUBSCRIBE_REASON",
                    noteText: L.GPCOptOutNoteText
                }
            } : "DNT" === n ? {
                Id: e.PurposeId,
                TransactionType: t,
                PurposeNote: {
                    noteId: L.ConsentIntegration.DNTReasonID,
                    noteType: "UNSUBSCRIBE_REASON",
                    noteText: L.DNTOptOutNoteText
                }
            } : {
                Id: e.PurposeId,
                TransactionType: t
            })
        }), r
    }, Gs.prototype.getTransactionType = function(e, t, o) {
        var n = {
            txnType: Fe,
            useOwn: !1
        };
        return e.Status === f.ALWAYS_ACTIVE ? n.txnType = Fe : e.Status.toLowerCase() === f.ALWAYS_INACTIVE || e.Status === f.INACTIVE && Ns.isCloseByIconOrLink || o ? n.txnType = Me : e.Status === f.ACTIVE && Ns.isCloseByIconOrLink ? n.txnType = Ns.noOptOutToogle ? Ue : He : (n.useOwn = !0, n.txnType = this.getTxnType(t[1])), n
    }, Gs.prototype.getTxnType = function(e) {
        return "0" === e ? Re : He
    }, Gs.prototype.isPurposeConsentedTo = function(e, t) {
        var o = [He, Fe];
        return e.some(function(e) {
            return e.Id === t.PurposeId && (-1 !== o.indexOf(e.TransactionType) || D.checkIfGroupHasConsent(t))
        })
    }, Gs.prototype.processGroupConsentPurpose = function(e, t, o, n, r) {
        return (!n && "GPC value changed" === r || "GPC" === n) && e.isDeniedByGPC ? (o.push({
            Id: e.PurposeId,
            TransactionType: t.txnType,
            PurposeNote: {
                noteId: L.ConsentIntegration.GPCReasonID,
                noteType: "UNSUBSCRIBE_REASON",
                noteText: L.GPCOptOutNoteText
            }
        }), "GPC") : "DNT" === n && e.isDeniedByDNT ? (o.push({
            Id: e.PurposeId,
            TransactionType: t.txnType,
            PurposeNote: {
                noteId: L.ConsentIntegration.DNTReasonID,
                noteType: "UNSUBSCRIBE_REASON",
                noteText: L.DNTOptOutNoteText
            }
        }), "DNT") : (o.push({
            Id: e.PurposeId,
            TransactionType: t.txnType
        }), "none")
    }, Gs.prototype.canSendAdvancedAnalytics = function(t, e) {
        var o = this;
        return "BRANCH" === e.Type || e.Type === k.GroupTypes.Stack ? e.SubGroups.length && e.SubGroups.every(function(e) {
            return o.isPurposeConsentedTo(t, e)
        }) : this.isPurposeConsentedTo(t, e)
    };
    var Ns, Bs = Gs;

    function Gs() {}
    var xs, Hs = function() {
            this.assets = function() {
                return {
                    name: "otCookiePolicy",
                    html: '<div class="ot-sdk-cookie-policy ot-sdk-container">\n    <h3 id="cookie-policy-title">Cookie Tracking Table</h3>\n    <div id="cookie-policy-description"></div>\n    <section>\n        <h4 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h4>\n        <p class="ot-sdk-cookie-policy-group-desc">group description</p>\n        <h5 class="cookies-used-header">Cookies Used</h5>\n        <ul class="cookies-list">\n            <li>Cookie 1</li>\n        </ul>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="table-header host">Host</th>\n                    <th scope="col" class="table-header host-description">Host Description</th>\n                    <th scope="col" class="table-header cookies">Cookies</th>\n                    <th scope="col" class="table-header life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="host-description-td" data-label="Host Description"><span\n                            class="ot-mobile-border"></span>These\n                        cookies are used to make sure\n                        visitor page requests are routed to the same server in all browsing sessions.</td>\n                    <td class="cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>ARRAffinity</li>\n                        </ul>\n                    </td>\n                    <td class="life-span-td" data-label="Life Span"><span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>100 days</li>\n                        </ul>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n    <section class="subgroup">\n        <h5 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h5>\n        <p class="ot-sdk-cookie-policy-group-desc">description</p>\n        <h6 class="cookies-used-header">Cookies Used</h6>\n        <ul class="cookies-list">\n            <li>Cookie 1</li>\n        </ul>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="table-header host">Host</th>\n                    <th scope="col" class="table-header host-description">Host Description</th>\n                    <th scope="col" class="table-header cookies">Cookies</th>\n                    <th scope="col" class="table-header life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="host-description-td" data-label="Host Description">\n                        <span class="ot-mobile-border"></span>\n                        cookies are used to make sureng sessions.\n                    </td>\n                    <td class="cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>ARRAffinity</li>\n                        </ul>\n                    </td>\n                    <td class="life-span-td" data-label="Life Span"><span class="ot-mobile-border"></span>\n                        <ul>\n                            <li>100 days</li>\n                        </ul>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n</div>\n\x3c!-- New Cookies policy Link--\x3e\n<div id="ot-sdk-cookie-policy-v2" class="ot-sdk-cookie-policy ot-sdk-container">\n    <h3 id="cookie-policy-title" class="ot-sdk-cookie-policy-title">Cookie Tracking Table</h3>\n    <div id="cookie-policy-description"></div>\n    <section>\n        <h4 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h4>\n        <p class="ot-sdk-cookie-policy-group-desc">group description</p>\n        <section class="ot-sdk-subgroup">\n            <ul>\n                <li>\n                    <h5 class="ot-sdk-cookie-policy-group">Strictly Necessary Cookies</h5>\n                    <p class="ot-sdk-cookie-policy-group-desc">description</p>\n                </li>\n            </ul>\n        </section>\n        <table>\n            <caption class="ot-scrn-rdr">caption</caption>\n            <thead>\n                <tr>\n                    <th scope="col" class="ot-table-header ot-host">Host</th>\n                    <th scope="col" class="ot-table-header ot-host-description">Host Description</th>\n                    <th scope="col" class="ot-table-header ot-cookies">Cookies</th>\n                    <th scope="col" class="ot-table-header ot-cookies-type">Type</th>\n                    <th scope="col" class="ot-table-header ot-life-span">Life Span</th>\n                </tr>\n            </thead>\n            <tbody>\n                <tr>\n                    <td class="ot-host-td" data-label="Host"><span class="ot-mobile-border"></span><a\n                            href="https://cookiepedia.co.uk/host/.app.onetrust.com?_ga=2.157675898.1572084395.1556120090-1266459230.1555593548&_ga=2.157675898.1572084395.1556120090-1266459230.1555593548">Azure</a>\n                    </td>\n                    <td class="ot-host-description-td" data-label="Host Description">\n                        <span class="ot-mobile-border"></span>\n                        cookies are used to make sureng sessions.\n                    </td>\n                    <td class="ot-cookies-td" data-label="Cookies">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-cookies-td-content">ARRAffinity</span>\n                    </td>\n                    <td class="ot-cookies-type" data-label="Type">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-cookies-type-td-content">1st Party</span>\n                    </td>\n                    <td class="ot-life-span-td" data-label="Life Span">\n                        <span class="ot-mobile-border"></span>\n                        <span class="ot-life-span-td-content">100 days</span>\n                    </td>\n                </tr>\n            </tbody>\n        </table>\n    </section>\n</div>',
                    css: ".ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-left:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-right:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:left}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;left:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-left:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;left:6px;width:40%;padding-right:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;left:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-right:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;left:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-right:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}",
                    cssRTL: ".ot-sdk-cookie-policy{font-family:inherit;font-size:16px}.ot-sdk-cookie-policy.otRelFont{font-size:1rem}.ot-sdk-cookie-policy h3,.ot-sdk-cookie-policy h4,.ot-sdk-cookie-policy h6,.ot-sdk-cookie-policy p,.ot-sdk-cookie-policy li,.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy th,.ot-sdk-cookie-policy #cookie-policy-description,.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}.ot-sdk-cookie-policy h4{font-size:1.2em}.ot-sdk-cookie-policy h6{font-size:1em;margin-top:2em}.ot-sdk-cookie-policy th{min-width:75px}.ot-sdk-cookie-policy a,.ot-sdk-cookie-policy a:hover{background:#fff}.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}.ot-sdk-cookie-policy .ot-mobile-border{display:none}.ot-sdk-cookie-policy section{margin-bottom:2em}.ot-sdk-cookie-policy table{border-collapse:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy{font-family:inherit;font-size:1rem}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h3,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h4,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy h6,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy p,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-title{color:dimgray}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup{margin-right:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy #cookie-policy-description,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group-desc,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-table-header,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td{font-size:.9em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td span,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td a{font-size:inherit}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-group{font-size:1em;margin-bottom:.6em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-cookie-policy-title{margin-bottom:1.2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy>section{margin-bottom:1em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th{min-width:75px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy a:hover{background:#fff}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead{background-color:#f6f6f4;font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-mobile-border{display:none}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy section{margin-bottom:2em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li{list-style:disc;margin-right:1.5em}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy .ot-sdk-subgroup ul li h4{display:inline-block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{border-collapse:inherit;margin:auto;border:1px solid #d7d7d7;border-radius:5px;border-spacing:initial;width:100%;overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border-bottom:1px solid #d7d7d7;border-left:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr th:last-child,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr td:last-child{border-left:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:25%}.ot-sdk-cookie-policy[dir=rtl]{text-align:right}#ot-sdk-cookie-policy h3{font-size:1.5em}@media only screen and (max-width: 530px){.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) table,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tbody,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) th,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td,.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{display:block}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) thead tr{position:absolute;top:-9999px;right:-9999px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr{margin:0 0 1em 0}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd),.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) tr:nth-child(odd) a{background:#f6f6f4}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td{border:none;border-bottom:1px solid #eee;position:relative;padding-right:50%}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{position:absolute;height:100%;right:6px;width:40%;padding-left:10px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) .ot-mobile-border{display:inline-block;background-color:#e4e4e4;position:absolute;height:100%;top:0;right:45%;width:2px}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) td:before{content:attr(data-label);font-weight:bold}.ot-sdk-cookie-policy:not(#ot-sdk-cookie-policy-v2) li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table{overflow:hidden}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table td{border:none;border-bottom:1px solid #d7d7d7}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tbody,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy th,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{display:block}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-host,#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table .ot-cookies-type{width:auto}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy tr{margin:0 0 1em 0}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{height:100%;width:40%;padding-left:10px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy td:before{content:attr(data-label);font-weight:bold}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy li{word-break:break-word;word-wrap:break-word}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy thead tr{position:absolute;top:-9999px;right:-9999px;z-index:-9999}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td{border-bottom:1px solid #d7d7d7;border-left:0px}#ot-sdk-cookie-policy-v2.ot-sdk-cookie-policy table tr:last-child td:last-child{border-bottom:0px}}"
                }
            }
        },
        Rs = "opt-out",
        Fs = (Ms.prototype.initializeFeaturesAndSpecialPurposes = function() {
            var t = this;
            _.oneTrustIABConsent.features = [], _.oneTrustIABConsent.specialPurposes = [], L.Groups.forEach(function(e) {
                t.checkAndPopulateFeatAndSplPur(e)
            })
        }, Ms.prototype.checkAndPopulateFeatAndSplPur = function(e) {
            var t, o = this,
                n = k.GroupTypes;
            e.Type !== n.Ft && e.Type !== n.Spl_Pur || ((t = {}).groupId = e.OptanonGroupId, t.purposeId = e.PurposeId, t.value = !0, (e.Type === n.Ft ? _.oneTrustIABConsent.features : _.oneTrustIABConsent.specialPurposes).push(t)), e.SubGroups && e.SubGroups.forEach(function(e) {
                o.checkAndPopulateFeatAndSplPur(e)
            })
        }, Ms.prototype.initGrpsAndHosts = function() {
            this.initializeGroupData(b.consentableGrps), O.isAlertBoxClosedAndValid() || b.initConsentableImpliedConsentGroup(b.consentableGrps), L.showCookieList && I.isOptOutEnabled() ? this.initializeHostData(b.consentableGrps) : (_.hostsConsent = [], Po.writeHstParam(y.OPTANON_CONSENT))
        }, Ms.prototype.ensureHtmlGroupDataInitialised = function() {
            var e, t, o, n;
            this.initGrpsAndHosts(), _.showGeneralVendors && (Io.populateGenVendorLists(), Io.initGenVendorConsent()), L.IsIabEnabled && (this.initializeIABData(), this.initializeFeaturesAndSpecialPurposes()), _.vsIsActiveAndOptOut && this.initializeVendorsService(), O.setOrUpdate3rdPartyIABConsentFlag(), O.setGeolocationInCookies(), L.IsConsentLoggingEnabled && (e = window.OneTrust.dataSubjectParams || {}, t = T.readCookieParam(y.OPTANON_CONSENT, "iType"), o = "", n = !1, _.isV2Stub && e.id && e.token && (t || b.forceCreateTrxLocalConsentIsGreater) && (n = !0, o = Ce[t]), Ns.createConsentTxn(!1, o, !1, n))
        }, Ms.prototype.initializeVendorsService = function() {
            var o = O.isAlertBoxClosedAndValid(),
                e = T.readCookieParam(y.OPTANON_CONSENT, Qt),
                n = P.strToMap(e);
            _.getVendorsInDomain().forEach(function(e, t) {
                n.has(t) || (e = !o && D.checkIsActiveByDefault(e.groupRef), n.set(t, e))
            }), _.vsConsent = n
        }, Ms.prototype.initializeGroupData = function(e) {
            var t;
            T.readCookieParam(y.OPTANON_CONSENT, Yt) ? (Do.synchroniseCookieGroupData(e), t = T.readCookieParam(y.OPTANON_CONSENT, Yt), _.groupsConsent = P.strToArr(t), _.gpcConsentTxn && (L.IsConsentLoggingEnabled && Ns.createConsentTxn(!1, "GPC value changed", !1, !0), _.gpcConsentTxn = !1, mo.setAlertBoxClosed(!0))) : (_.groupsConsent = [], e.forEach(function(e) {
                var t = D.checkIsActiveByDefault(e) && e.HasConsentOptOut;
                e.Status === f.INACTIVE_LANDING_PAGE && !O.isAlertBoxClosedAndValid() && _o.isLandingPage() && (t = !1), _.groupsConsent.push(e.CustomGroupId + ":" + (t ? "1" : "0")), b.gpcEnabled && e.IsGpcEnabled && e.Status === f.INACTIVE && (e.isDeniedByGPC = !0), b.DNTEnabled && e.IsDntEnabled && e.Status === f.ACTIVE && (e.isDeniedByDNT = !0)
            }), L.IsConsentLoggingEnabled && window.addEventListener("beforeunload", this.consentDefaulCall)), L.IsConsentLoggingEnabled && b.makeGPCOrDNTConsentCall && !O.isAlertBoxClosedAndValid() && (b.makeGPCOrDNTConsentCall = !1, b.gpcEnabled && e.some(function(e) {
                return !0 === e.isDeniedByGPC
            }) ? Ns.createConsentTxn(!1, "GPC value changed", !1, !0, !1, "GPC") : b.DNTEnabled && e.some(function(e) {
                return !0 === e.isDeniedByDNT
            }) && Ns.createConsentTxn(!1, "DNT value changed", !1, !0, !1, "DNT"))
        }, Ms.prototype.initializeHostData = function(e) {
            var t, r;
            T.readCookieParam(y.OPTANON_CONSENT, "hosts") ? (Do.synchroniseCookieHostData(), t = T.readCookieParam(y.OPTANON_CONSENT, "hosts"), _.hostsConsent = P.strToArr(t), e.forEach(function(e) {
                D.isAlwaysActiveGroup(e) && e.Hosts.length && e.Hosts.forEach(function(e) {
                    _.oneTrustAlwaysActiveHosts.push(e.HostId)
                })
            })) : (_.hostsConsent = [], r = {}, e.forEach(function(e) {
                var o = D.isAlwaysActiveGroup(e),
                    n = _.syncRequired ? Do.groupHasConsent(e) : D.checkIsActiveByDefault(e);
                e.Hosts.length && e.Hosts.forEach(function(e) {
                    var t;
                    r[e.HostId] ? Do.updateHostStatus(e, n) : (r[e.HostId] = !0, o && _.oneTrustAlwaysActiveHosts.push(e.HostId), t = Do.isHostPartOfAlwaysActiveGroup(e.HostId), _.hostsConsent.push(e.HostId + (t || n ? ":1" : ":0")))
                })
            }))
        }, Ms.prototype.consentDefaulCall = function() {
            var e = parseInt(T.readCookieParam(y.OPTANON_CONSENT, h.INTERACTION_COUNT), 10);
            !isNaN(e) && 0 !== e || (mo.triggerGoogleAnalyticsEvent(Bo, "Click", "No interaction"), L.IsConsentLoggingEnabled && Ns.createConsentTxn(!0), window.removeEventListener("beforeunload", xs.consentDefaulCall))
        }, Ms.prototype.fetchAssets = function(s) {
            return void 0 === s && (s = null), F(this, void 0, void 0, function() {
                var t, o, n, r, i;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return t = S.moduleInitializer, i = O.isAlertBoxClosedAndValid(), o = !!s, i = xs.isFetchBanner(t.IsSuppressBanner, i), n = xs.cookieSettingBtnPresent(), n = b.isIab2orv2Template ? L.PCShowPersistentCookiesHoverButton && (!L.PCenterDynamicRenderingEnable || (L.PCenterDynamicRenderingEnable, !n)) : L.PCShowPersistentCookiesHoverButton, r = "true" === _.urlParams.get(at), _.hideBanner = r, [4, Promise.all([!i || L.NoBanner || r ? Promise.resolve(null) : Kt.getBannerContent(o, s), !t.IsSuppressPC || _.isPCVisible ? Kt.getPcContent() : Promise.resolve(null), n ? Kt.getCSBtnContent() : Promise.resolve(null), Kt.getCommonStyles()])];
                        case 1:
                            return i = e.sent(), r = i[0], o = i[1], t = i[2], n = i[3], xs.fetchContent(r, o, t, n), xs.setCookieListGroupData(), [2]
                    }
                })
            })
        }, Ms.prototype.fetchContent = function(e, t, o, n) {
            var r;
            e && (r = e.html, S.fp.CookieV2SSR || (r = atob(e.html)), this.bannerGroup = {
                name: e.name,
                html: r,
                css: e.css
            }), t && (this.preferenceCenterGroup = {
                name: t.name,
                html: atob(t.html),
                css: t.css
            }, S.isV2Template = L.PCTemplateUpgrade && /otPcPanel|otPcCenter|otPcTab/.test(t.name)), o && (this.csBtnGroup = {
                name: "CookieSettingsButton",
                html: atob(o.html),
                css: o.css
            }), n && (this.commonStyles = n)
        }, Ms.prototype.cookieSettingBtnPresent = function() {
            return v("#ot-sdk-btn").length || v(".ot-sdk-show-settings").length || v(".optanon-show-settings").length
        }, Ms.prototype.isFetchBanner = function(e, t) {
            return !e || L.ShowAlertNotice && !t && e && !v("#onetrust-banner-sdk").length
        }, Ms.prototype.setCookieListGroupData = function() {
            var e;
            S.fp.CookieV2TrackingTechnologies || (e = (new Hs).assets(), xs.cookieListGroup = {
                name: e.name,
                html: e.html,
                css: L.useRTL ? e.cssRTL : e.css
            })
        }, Ms.prototype.initializeIabPurposeConsentOnReload = function() {
            var t = this;
            b.consentableIabGrps.forEach(function(e) {
                t.setIABConsent(e, !1), e.IsLegIntToggle = !0, t.setIABConsent(e, !1)
            })
        }, Ms.prototype.initializeIABData = function(o, n, r) {
            var i = this,
                e = (void 0 === o && (o = !1), void 0 === n && (n = !1), void 0 === r && (r = !1), _.oneTrustIABConsent),
                t = (e.purpose = [], e.vendors = [], e.legIntVendors = [], e.specialFeatures = [], e.legimateInterest = [], _.addtlVendors),
                s = L.VendorConsentModel === Rs;
            t.vendorConsent = [], !e.IABCookieValue || o || n || O.reconsentRequired() ? (b.consentableIabGrps.forEach(function(e) {
                var t;
                n && !r ? i.setIABConsent(e, D.isAlwaysActiveGroup(e)) : r ? e.HasConsentOptOut && i.setIABConsent(e, !1) : (t = o && e.HasConsentOptOut, i.setIABConsent(e, t), e.Type === k.GroupTypes.Pur && (e.IsLegIntToggle = !0, i.setIABConsent(e, e.HasLegIntOptOut)))
            }), L.IsIabEnabled && r && (_.oneTrustIABConsent.legimateInterest = _.vendors.selectedLegInt.slice()), t = o || !n && s, r && this.iab.saveVendorStatus(r), O.setIABVendor(t, r, n), !O.reconsentRequired() || o || n || O.resetTCModel()) : (this.initializeIabPurposeConsentOnReload(), yo.populateGoogleConsent(), yo.populateVendorAndPurposeFromCookieData())
        }, Ms.prototype.canSoftOptInInsertForGroup = function(e) {
            var e = D.getGroupById(e);
            if (e) return e = e && !e.Parent ? e : D.getParentGroup(e.Parent), "inactive landingpage" !== D.getGrpStatus(e).toLowerCase() || !_o.isLandingPage()
        }, Ms.prototype.setIABConsent = function(e, t) {
            e.Type === k.GroupTypes.Spl_Ft ? this.setIabSpeciFeatureConsent(e, t) : e.IsLegIntToggle ? (this.setIabLegIntConsent(e, t), e.IsLegIntToggle = !1) : this.setIabPurposeConsent(e, t)
        }, Ms.prototype.setIabPurposeConsent = function(o, n) {
            var r = !1;
            _.oneTrustIABConsent.purpose = _.oneTrustIABConsent.purpose.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || _.oneTrustIABConsent.purpose.push(o.IabGrpId + ":" + n)
        }, Ms.prototype.setIabLegIntConsent = function(o, n) {
            var r = !1;
            _.oneTrustIABConsent.legimateInterest = _.oneTrustIABConsent.legimateInterest.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || _.oneTrustIABConsent.legimateInterest.push(o.IabGrpId + ":" + n)
        }, Ms.prototype.setIabSpeciFeatureConsent = function(o, n) {
            var r = !1;
            _.oneTrustIABConsent.specialFeatures = _.oneTrustIABConsent.specialFeatures.map(function(e) {
                var t = e.split(":")[0];
                return t === o.IabGrpId && (e = t + ":" + n, r = !0), e
            }), r || _.oneTrustIABConsent.specialFeatures.push(o.IabGrpId + ":" + n)
        }, Ms);

    function Ms() {
        this.iab = g
    }
    s.prototype.getSearchQuery = function(e) {
        var t = this,
            e = e.trim().split(/\s+/g);
        return new RegExp(e.map(function(e) {
            return t.escapeRegExp(e)
        }).join("|") + "(.+)?", "gi")
    }, s.prototype.escapeRegExp = function(e) {
        return e.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")
    }, s.prototype.setGlobalFilteredList = function(e) {
        return _.currentGlobalFilteredList = e
    }, s.prototype.vendorHasPurpose = function(e, t) {
        var o = !1,
            n = parseInt(b.iabGrpIdMap[t]);
        return -1 < t.indexOf(k.IdPatterns.Ft) ? (e.features || []).forEach(function(e) {
            e.featureId === n && (o = !0)
        }) : -1 < t.indexOf(k.IdPatterns.Spl_Ft) ? e.specialFeatures.forEach(function(e) {
            e.featureId === n && (o = !0)
        }) : -1 < t.indexOf(k.IdPatterns.Spl_Pur) ? (e.specialPurposes || []).forEach(function(e) {
            e.purposeId === n && (o = !0)
        }) : (e.purposes.forEach(function(e) {
            e.purposeId === n && (o = !0)
        }), e.legIntPurposes.forEach(function(e) {
            e.purposeId === n && (o = !0)
        })), o
    }, s.prototype.filterList = function(t, e, o) {
        var n, r, i = o && o.length;
        return "" !== t || i ? (i && (i = v("#onetrust-pc-sdk " + A.P_Fltr_Options + " input").el.length, r = !(n = []), i !== o.length ? e.forEach(function(t) {
            r = !0, t.vendorName && o.forEach(function(e) {
                g.vendorHasPurpose(t, e) && n.push(t)
            })
        }) : n = e, r && (n = n.filter(function(e, t, o) {
            return o.indexOf(e) === t
        })), this.setGlobalFilteredList(n)), "" === t ? _.currentGlobalFilteredList : _.currentGlobalFilteredList.filter(function(e) {
            if (e.vendorName) return e.vendorName.toLowerCase().includes(t.toLowerCase())
        })) : this.setGlobalFilteredList(e)
    }, s.prototype.loadVendorList = function(e, t) {
        void 0 === e && (e = "");
        var o = _.vendors,
            o = (_.currentGlobalFilteredList = o.list, e ? (o.searchParam = e, _.filterByIABCategories = [], On.updateFilterSelection(!1)) : o.searchParam !== e ? o.searchParam = "" : t = _.filterByIABCategories, this.filterList(o.searchParam, o.list, t));
        v("#onetrust-pc-sdk " + A.P_Vendor_Content).el[0].scrollTop = 0, _.addtlVendorsList && 0 < Object.keys(_.addtlVendorsList).length && (this.hasGoogleVendors = !0), this.initVendorsData(e, o)
    }, s.prototype.searchVendors = function(e, t, o, n) {
        if (n) {
            var r, i, s = this.getSearchQuery(n),
                a = 0;
            for (r in t) r && (i = o === me.GoogleVendor ? r : t[r].VendorCustomId, i = v("" + e.vendorAccBtn + i).el[0].parentElement, s.lastIndex = 0, s.test(t[r][e.name]) ? (d(i, this._displayNull, !0), a++) : d(i, "display: none;", !0));
            0 === a ? (v(e.accId).hide(), o === me.GoogleVendor ? this.hasGoogleVendors = !1 : this.hasGenVendors = !1) : (o === me.GoogleVendor ? this.hasGoogleVendors = !0 : this.hasGenVendors = !0, v(e.accId).show()), this.showEmptyResults(!this.hasGoogleVendors && !this.hasIabVendors && !this.hasGenVendors, n)
        } else
            for (var l = v(" " + e.venListId + ' li[style^="display: none"]').el, c = 0; c < l.length; c++) d(l[c], this._displayNull, !0);
        n = v("#onetrust-pc-sdk " + e.selectAllEvntHndlr).el[0];
        document.querySelector(e.venListId + ' li:not([style^="display: none"]) ' + e.ctgl + " > input[checked]") ? P.setCheckedAttribute("", n, !0) : P.setCheckedAttribute("", n, !1), document.querySelector(e.venListId + ' li:not([style^="display: none"]) ' + e.ctgl + " > input:not([checked])") ? n.parentElement.classList.add(this.LINE_THROUGH_CLASS) : n.parentElement.classList.remove(this.LINE_THROUGH_CLASS)
    }, s.prototype.initGoogleVendors = function() {
        this.populateAddtlVendors(_.addtlVendorsList), this.venAdtlSelAllTglEvent()
    }, s.prototype.initGenVendors = function() {
        this.populateGeneralVendors(), L.GenVenOptOut && L.GeneralVendors && L.GeneralVendors.length && this.genVenSelectAllTglEvent()
    }, s.prototype.resetAddtlVendors = function() {
        g.searchVendors(g.googleSearchSelectors, _.addtlVendorsList, me.GoogleVendor), this.showConsentHeader()
    }, s.prototype.venAdtlSelAllTglEvent = function() {
        g.selectAllEventHandler({
            vendorsList: '#ot-addtl-venlst li:not([style^="display: none"]) .ot-ven-adtlctgl input',
            selAllCntr: "#onetrust-pc-sdk #ot-selall-adtlvencntr",
            selAllChkbox: "#onetrust-pc-sdk #ot-selall-adtlven-handler"
        })
    }, s.prototype.genVenSelectAllTglEvent = function() {
        var e = {
            vendorsList: A.P_Gven_List + ' li:not([style^="display: none"]) .ot-ven-gvctgl input',
            selAllCntr: "#onetrust-pc-sdk #ot-selall-gnvencntr",
            selAllChkbox: "#onetrust-pc-sdk #ot-selall-gnven-handler"
        };
        g.selectAllEventHandler(e)
    }, s.prototype.handleSelectAllChboxSelection = function(e, t, o) {
        for (var n = !0, r = !0, i = 0; i < e.length && (e[i].checked ? r = !1 : n = !1, n || r); i++);
        n || r ? o.classList.remove(this.LINE_THROUGH_CLASS) : (o.classList.add(this.LINE_THROUGH_CLASS), P.setAriaCheckedAttribute("", t, "mixed")), t.checked = !1, n ? (t.checked = !0, P.setAriaCheckedAttribute("", t, t.checked)) : r && P.setAriaCheckedAttribute("", t, t.checked), P.setCheckedAttribute("", t, t.checked)
    }, s.prototype.selectAllEventHandler = function(e) {
        var t = v(e.vendorsList).el,
            o = v(e.selAllCntr).el[0],
            e = v(e.selAllChkbox).el[0];
        g.handleSelectAllChboxSelection(t, e, o)
    }, s.prototype.vendorLegIntToggleEvent = function() {
        var e = v(A.P_Vendor_Container + ' li:not([style^="display: none"]) .' + A.P_Ven_Ltgl + " input").el,
            t = v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Leg_El).el[0],
            o = v("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0];
        g.handleSelectAllChboxSelection(e, o, t)
    }, s.prototype.vendorsListEvent = function() {
        var e = v(A.P_Vendor_Container + ' li:not([style^="display: none"]) .' + A.P_Ven_Ctgl + " input").el,
            t = v("#onetrust-pc-sdk #" + A.P_Sel_All_Vendor_Consent_El).el[0],
            o = v("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0];
        g.handleSelectAllChboxSelection(e, o, t)
    }, s.prototype.showEmptyResults = function(e, t, o) {
        void 0 === o && (o = !1);
        var n = v("#onetrust-pc-sdk #no-results");
        e ? this.setNoResultsContent(t, o) : (v("#onetrust-pc-sdk " + A.P_Vendor_Content).removeClass("no-results"), n.length && n.remove())
    }, s.prototype.playSearchStatus = function(e) {
        var t = e ? document.querySelectorAll(A.P_Host_Cntr + " > li") : document.querySelectorAll(A.P_Vendor_Container + ' > li:not([style$="none;"]),' + A.P_Gven_List + ' > li:not([style$="none;"])'),
            o = t.length,
            n = v('#onetrust-pc-sdk [role="status"]');
        o ? n.text(t.length + " " + (e ? "host" : "vendor") + (1 < o ? "s" : "") + " returned.") : n.el[0].textContent = ""
    }, s.prototype.setNoResultsContent = function(e, t) {
        void 0 === t && (t = !1);
        var o, n, r, i = v("#onetrust-pc-sdk #no-results").el[0];
        if (!i) return t = g.getNoResultsFound(t), o = document.createElement("div"), n = document.createElement("p"), t = document.createTextNode(t), r = document.createElement("span"), o.id = "no-results", o.setAttribute("aria-live", "assertive"), o.setAttribute("aria-atomic", "true"), r.id = "user-text", r.innerText = e, n.appendChild(r), n.appendChild(t), o.appendChild(n), v("#onetrust-pc-sdk " + A.P_Vendor_Content).addClass("no-results"), v("#vendor-search-handler").el[0].setAttribute("aria-describedby", o.id), v("#onetrust-pc-sdk " + A.P_Vendor_Content).append(o);
        i.querySelector("span").innerText = e
    }, s.prototype.searchHostList = function(e) {
        var t = {},
            o = [];
        _.showTrackingTech ? (t = _.currentTrackingTech, o = (t = e ? g.getFilteredAdditionaTechtData(e, t) : t).Cookies) : (o = _.currentGlobalFilteredList, e && (o = this.searchList(e, o))), this.initHostData({
            searchString: e,
            cookiesList: o,
            addTechData: t
        })
    }, s.prototype.searchList = function(e, t) {
        var o = this.getSearchQuery(e);
        return t.filter(function(e) {
            return o.lastIndex = 0, o.test(e.DisplayName || e.HostName)
        })
    }, s.prototype.setListSearchValues = function(e) {
        var t = L.PCenterVendorSearchAriaLabel,
            o = L.PCenterVendorListSearch,
            n = L.PCenterVendorsListText,
            r = L.PCenterVendorListFilterAria;
        e === _e.cookies && (t = L.PCenterCookieSearchAriaLabel, o = L.PCenterCookieListSearch, n = L.PCenterCookiesListText, r = L.PCenterCookieListFilterAria), _.cookieListType !== ye.HostAndGenVen && _.cookieListType !== ye.Host || !_.showTrackingTech || (n = L.AdditionalTechnologiesConfig.PCTrackingTechTitle), document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Title + ', #onetrust-pc-sdk #ot-lst-title p[aria-level="3"]').innerText = n;
        v("#filter-btn-handler").el[0].setAttribute(this.ARIA_LABEL_ATTRIBUTE, r + " " + n);
        e = v("#onetrust-pc-sdk " + A.P_Vendor_Search_Input);
        e.el[0].placeholder = o, e.attr("aria-label", t)
    }, s.prototype.initHostData = function(e) {
        var t = e.searchString,
            o = e.cookiesList,
            e = e.addTechData,
            n = (_.optanonHostList = o, !1),
            r = (this.setBackBtnTxt(), v(A.P_Vendor_List + " #select-all-text-container p").html(L.PCenterAllowAllConsentText), g.getHostParentContainer()),
            i = o && 0 === o.length,
            s = (_.showTrackingTech && (i = 0 === e.LocalStorages.length && 0 === e.SessionStorages.length && (0 === e.Cookies.length || 0 === e.Cookies[0].Cookies.length)), _.cookieListType === ye.Host),
            i = (this.showEmptyResults(i, t, s), this.setHostListSearchValues(), v("#filter-btn-handler").el[0]),
            t = I.getVendorPageHeaderText();
        i.setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCenterCookieListFilterAria + " " + t);
        v("#filter-btn-handler title").html(L.PCenterCookieListFilterAria), S.isV2Template && v("#ot-sel-blk span:first-child").html(L.PCenterAllowAllConsentText || L.ConsentText);
        for (var a = document.createDocumentFragment(), l = 0; l < o.length; l++) {
            var c = _.hosts.hostTemplate.cloneNode(!0),
                d = o[l].DisplayName || o[l].HostName;
            this.createHostAccordions(d, c, l), n = this.createHostCheckboxes(d, o, l, c, n), this.populateHostDataIntoDOMElements(c, o, d, l, a)
        }
        g.setCookiesInsideHostContainer(r, a, e);
        s = 1 === o.length && o[0].HostName === L.PCFirstPartyCookieListText;
        if (I.isOptOutEnabled() && !s) {
            P.setDisabledAttribute("#onetrust-pc-sdk #select-all-hosts-groups-handler", null, !n);
            for (var u = v("#onetrust-pc-sdk " + A.P_Host_Cntr + " .ot-host-tgl input").el, p = 0; p < u.length; p++) u[p].addEventListener("click", this.hostsListEvent);
            v("#onetrust-pc-sdk " + A.P_Select_Cntr).removeClass("ot-hide"), this.hostsListEvent()
        } else v("#onetrust-pc-sdk " + A.P_Select_Cntr).addClass("ot-hide")
    }, s.prototype.setCookiesInsideHostContainer = function(e, t, o) {
        var n, r;
        _.showTrackingTech && o ? 0 < (o = g.getAdditionalTechnologiesHtml(o)).children.length && ((n = o.querySelector("." + this.TECH_COOKIES_SELECTOR + " " + this.ACC_TXT)) && ((r = e.querySelector("ul" + A.P_Host_Cntr)).appendChild(t), n.appendChild(r)), e.appendChild(o)) : e.appendChild(t)
    }, s.prototype.getHostParentContainer = function() {
        var e = null;
        return _.showTrackingTech ? (e = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Content + " .ot-sdk-column"), g.removeTrackingTechAccorions()) : (e = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Content + " ul" + A.P_Host_Cntr)).innerHTML = m.getInnerHtmlContent(""), e
    }, s.prototype.removeTrackingTechAccorions = function() {
        var e = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Content + " .ot-sdk-column"),
            t = e.querySelector("." + this.TECH_COOKIES_SELECTOR + " ul" + A.P_Host_Cntr);
        if (t ? (t.innerHTML = m.getInnerHtmlContent(""), e.appendChild(t)) : (t = e.querySelector("ul" + A.P_Host_Cntr)).innerHTML = m.getInnerHtmlContent(""), e)
            for (var o = e.querySelectorAll(".ot-add-tech"), n = o.length - 1; 0 <= n; n--) {
                var r = o.item(n);
                e.removeChild(r)
            }
    }, s.prototype.setHostListSearchValues = function() {
        var e = b.pcName;
        L.GeneralVendorsEnabled && (S.isV2Template || e !== st) && this.setListSearchValues(_e.vendors), L.GeneralVendorsEnabled || !S.isV2Template && e === st || this.setListSearchValues(_e.cookies)
    }, s.prototype.createHostAccordions = function(e, t, o) {
        var n = t.querySelector("." + A.P_Host_Bx),
            e = (n && P.setHtmlAttributes(n, {
                id: "host-" + o,
                name: "host-" + o,
                "aria-label": e + " " + L.PCViewCookiesText,
                "aria-controls": "ot-host-acc-txt-" + o
            }), t.querySelector(A.P_Acc_Txt));
        e && P.setHtmlAttributes(e, {
            id: "ot-host-acc-txt-" + o,
            role: "region",
            "aria-labelledby": n.id
        })
    }, s.prototype.createHostCheckboxes = function(e, t, o, n, r) {
        var i = I.isOptOutEnabled(),
            s = S.isV2Template,
            a = b.pcName;
        return !i || t[o].isFirstParty ? (i = n.querySelector(".ot-host-tgl")) && i.parentElement.removeChild(i) : (i = void 0, s ? ((i = E.chkboxEl.cloneNode(!0)).classList.add("ot-host-tgl"), i.querySelector("input").classList.add("host-checkbox-handler"), a === st ? n.querySelector(A.P_Host_Hdr).insertAdjacentElement("beforebegin", i) : n.querySelector(A.P_Tgl_Cntr).insertAdjacentElement("beforeend", i)) : i = n.querySelector(".ot-host-tgl"), P.setHtmlAttributes(i.querySelector("input"), {
            id: "ot-host-chkbox-" + o,
            "aria-label": e,
            hostId: t[o].HostId,
            ckType: t[o].Type
        }), i.querySelector("label").setAttribute("for", "ot-host-chkbox-" + o), (t[o].Type === he.GenVendor ? _.genVendorsConsent[t[o].HostId] : -1 !== _.hostsConsent.indexOf(t[o].HostId + ":1")) ? (P.setCheckedAttribute(null, i.querySelector("input"), !0), t[o].isActive ? P.setDisabledAttribute(null, i.querySelector("input"), !0) : r = r || !0) : (r = !0, P.setCheckedAttribute(null, i.querySelector("input"), !1)), i.querySelector(A.P_Label_Txt).innerText = e), r
    }, s.prototype.populateHostDataIntoDOMElements = function(t, o, e, n, r) {
        var i, s = this,
            a = S.isV2Template,
            l = b.pcName,
            l = (L.PCAccordionStyle === ce.PlusMinus ? t.querySelector(A.P_Acc_Header).insertAdjacentElement("afterbegin", E.plusMinusEl.cloneNode(!0)) : a && (i = E.arrowEl.cloneNode(!0), l === st ? t.querySelector(A.P_Host_View_Cookies).insertAdjacentElement("afterend", i) : t.querySelector(A.P_Tgl_Cntr).insertAdjacentElement("beforeend", i)), L.AddLinksToCookiepedia && !o[n].isFirstParty && (e = '\n                            <a  class="cookie-label"\n                                href="https://cookiepedia.co.uk/host/' + o[n].HostName + '"\n                                rel="noopener noreferrer"\n                                target="_blank"\n                            >\n                                ' + e + '&nbsp;<span class="ot-scrn-rdr">' + L.NewWinTxt + "</span>\n                            </a>\n                        "), t.querySelector(A.P_Host_Title).innerHTML = m.getInnerHtmlContent(e), t.querySelector(A.P_Host_Desc).innerHTML = m.getInnerHtmlContent(o[n].Description), o[n].PrivacyPolicy && L.pcShowCookieHost && t.querySelector(A.P_Host_Desc).insertAdjacentHTML("afterend", m.getInnerHtmlContent('<a href="' + o[n].PrivacyPolicy + '" rel="noopener noreferrer" target="_blank">' + (a ? L.PCGVenPolicyTxt : L.PCCookiePolicyText) + '&nbsp;<span class="ot-scrn-rdr">' + L.NewWinTxt + "</span></a>")), t.querySelector(A.P_Host_View_Cookies));
        return !_.showGeneralVendors || o[n].Cookies && o[n].Cookies.length ? L.PCViewCookiesText && (l.innerHTML = m.getInnerHtmlContent(L.PCViewCookiesText)) : (P.removeChild(l), v(t).addClass("ot-hide-acc")), o[n].Description && L.pcShowCookieHost || (i = t.querySelector(A.P_Host_Desc)).parentElement.removeChild(i), v(t.querySelector(A.P_Host_Opt)).html(""), null != (a = o[n].Cookies) && a.forEach(function(e) {
            e = s.getCookieElement(e, o[n]);
            v(t.querySelector(A.P_Host_Opt)).append(e)
        }), r.append(t), e
    }, s.prototype.hostsListEvent = function() {
        var e = v("#onetrust-pc-sdk " + A.P_Host_Cntr + " .ot-host-tgl input").el,
            t = v("#onetrust-pc-sdk #" + A.P_Sel_All_Host_El).el[0],
            o = v("#onetrust-pc-sdk #select-all-hosts-groups-handler").el[0],
            n = v("#onetrust-pc-sdk " + A.P_Cnsnt_Header).el[0];
        g.handleSelectAllChboxSelection(e, o, t), o && n && o.setAttribute(this.ARIA_LABEL_ATTRIBUTE, n.textContent + " " + L.PCenterSelectAllVendorsText)
    }, s.prototype.loadHostList = function(e, t) {
        var o = {},
            n = [],
            n = _.showTrackingTech ? (o = g.getAdditionalTechnologiesDataFromGroup(t), (_.currentTrackingTech = o).Cookies) : g.getCombinedCookieList(t);
        _.currentGlobalFilteredList = n, this.initHostData({
            searchString: e,
            cookiesList: n,
            addTechData: o
        })
    }, s.prototype.getCombinedCookieList = function(e) {
        var t, o = [],
            n = [];
        return _.cookieListType !== ye.GenVen && (n = (t = g.getFirstsAndThirdCookisFromGroups(e)).firstPartyCookiesList, o = t.thirdPartyCookiesList, n.length) && o.unshift({
            HostName: L.PCFirstPartyCookieListText,
            DisplayName: L.PCFirstPartyCookieListText,
            HostId: this.FIRST_PARTY_COOKIES_GROUP_NAME,
            isFirstParty: !0,
            Cookies: n,
            Description: ""
        }), _.showGeneralVendors ? (t = this.getFilteredGenVendorsList(e), U(o, this.mapGenVendorListToHostFormat(t))) : o
    }, s.prototype.mapGenVendorListToHostFormat = function(e) {
        return e.map(function(e) {
            return {
                Cookies: e.Cookies,
                DisplayName: e.Name,
                HostName: e.Name,
                HostId: e.VendorCustomId,
                Description: e.Description,
                Type: he.GenVendor,
                PrivacyPolicy: e.PrivacyPolicyUrl,
                isActive: -1 < _.alwaysActiveGenVendors.indexOf(e.VendorCustomId)
            }
        })
    }, s.prototype.mapGenVendorToHostFormat = function(e) {
        return {
            Cookies: e.Cookies,
            DisplayName: e.Name,
            HostName: e.Name,
            HostId: e.VendorCustomId,
            Description: e.Description,
            Type: he.GenVendor
        }
    }, s.prototype.getFilteredGenVendorsList = function(t) {
        var e, o = [],
            n = [];
        return t.length ? (L.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                -1 !== t.indexOf(e.CustomGroupId) && e.GeneralVendorsIds && e.GeneralVendorsIds.forEach(function(e) {
                    o.push(e)
                })
            })
        }), e = L.GeneralVendors, o.length ? e.filter(function(e) {
            if (-1 < o.indexOf(e.VendorCustomId)) return e
        }) : n) : L.GeneralVendors
    }, s.prototype.initVendorsData = function(e, t) {
        var o = this,
            n = t,
            t = _.vendors.list,
            r = (this.setBackBtnTxt(), v(A.P_Vendor_List + " #select-all-text-container p").html(L.PCenterAllowAllConsentText), g.setConsentLegIntAndHeaderText(), I.getVendorPageHeaderText());
        if (v("#onetrust-pc-sdk #filter-btn-handler").el[0].setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCenterVendorListFilterAria + " " + r), v("#onetrust-pc-sdk #filter-btn-handler title").html(L.PCenterVendorListFilterAria), this.hasIabVendors = 0 < n.length, this.showEmptyResults(!this.hasGoogleVendors && !this.hasIabVendors && !this.hasGenVendors, e, !1), g.hideOrShowVendorList(n), v("#onetrust-pc-sdk " + A.P_Vendor_Container + " ." + A.P_Ven_Bx).length !== t.length && this.attachVendorsToDOM(), n.length !== t.length) t.forEach(function(e) {
            var t = v(A.P_Vendor_Container + " #IAB" + e.vendorId).el[0].parentElement; - 1 === n.indexOf(e) ? d(t, "display: none;", !0) : d(t, o._displayNull, !0)
        });
        else
            for (var i = v(A.P_Vendor_Container + ' li[style^="display: none"]').el, s = 0; s < i.length; s++) d(i[s], this._displayNull, !0);
        !S.isV2Template && b.pcName === st || this.setListSearchValues(_e.vendors);
        r = document.querySelector("#vdr-lst-dsc");
        !r && L.PCenterVendorListDescText && ((r = document.createElement("p")).id = "vdr-lst-dsc", v(r).html(L.PCenterVendorListDescText), b.pcName !== st && b.pcName !== nt ? (e = document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Title_Elm)) && e.insertAdjacentElement("afterend", r) : (t = document.querySelector(A.P_Vendor_Content + " .ot-sdk-row")) && t.insertAdjacentElement("beforebegin", r)), v("#onetrust-pc-sdk " + A.P_Select_Cntr).removeClass("ot-hide"), this.vendorsListEvent(), b.legIntSettings.PAllowLI && this.vendorLegIntToggleEvent()
    }, s.prototype.setConsentLegIntAndHeaderText = function() {
        S.isV2Template && (v("#ot-sel-blk span:first-child").html(L.PCenterAllowAllConsentText || L.ConsentText), v("#ot-sel-blk span:last-child").html(L.LegitInterestText), v("#onetrust-pc-sdk " + A.P_Cnsnt_Header).html(L.PCenterAllowAllConsentText), b.legIntSettings.PAllowLI && !b.legIntSettings.PShowLegIntBtn && v("#onetrust-pc-sdk .ot-sel-all-hdr .ot-li-hdr").html(L.PCenterLegitInterestText), b.legIntSettings.PAllowLI && !b.legIntSettings.PShowLegIntBtn || d(v("#ot-sel-blk span:first-child").el[0], "max-width: 100%;", !0))
    }, s.prototype.hideOrShowVendorList = function(e) {
        0 === e.length ? v("#ot-lst-cnt .ot-acc-cntr").hide() : v("#ot-lst-cnt .ot-acc-cntr").show(), _.showTrackingTech && g.removeTrackingTechAccorions()
    }, s.prototype.updateVendorsDOMToggleStatus = function(e, t) {
        void 0 === t && (t = !1);
        for (var o = v(A.P_Vendor_Container + " " + A.P_Tgl_Cntr).el, n = 0; n < o.length; n++) {
            var r = o[n].querySelector("." + A.P_Ven_Ctgl + " input"),
                i = o[n].querySelector("." + A.P_Ven_Ltgl + " input");
            t ? r && P.setCheckedAttribute("", r, !1) : (r && P.setCheckedAttribute("", r, e), i && P.setCheckedAttribute("", i, e))
        }
        var s = v("#onetrust-pc-sdk #select-all-vendor-leg-handler").el[0],
            s = (s && (s.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", s, !!t || e)), v("#onetrust-pc-sdk #select-all-vendor-groups-handler").el[0]);
        s && (s.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", s, !t && e)), L.UseGoogleVendors && (t ? this.updateGoogleCheckbox(!1) : this.updateGoogleCheckbox(e)), _.showGeneralVendors && L.GenVenOptOut && this.updateGenVenCheckbox(e)
    }, s.prototype.updateGenVenCheckbox = function(e) {
        for (var t = v(A.P_Gven_List + " .ot-ven-gvctgl input").el, o = 0; o < t.length; o++) P.setCheckedAttribute("", t[o], e);
        var n = v("#onetrust-pc-sdk #ot-selall-gnven-handler").el[0];
        n && (n.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", n, e))
    }, s.prototype.updateGoogleCheckbox = function(e) {
        for (var t = v("#ot-addtl-venlst .ot-tgl-cntr input").el, o = 0; o < t.length; o++) P.setCheckedAttribute("", t[o], e);
        var n = v("#onetrust-pc-sdk #ot-selall-adtlven-handler").el[0];
        n && (n.parentElement.classList.remove(this.LINE_THROUGH_CLASS), P.setCheckedAttribute("", n, e))
    }, s.prototype.updateVendorDisclosure = function(e, t) {
        var r, i, e = v(A.P_Vendor_Container + " #IAB" + e).el[0].parentElement;
        t && t.disclosures && (r = e.querySelector(A.P_Ven_Dets), (e = (i = e.querySelector(A.P_Ven_Disc).cloneNode(!0)).cloneNode(!0)).innerHTML = m.getInnerHtmlContent(this.getHeadingElement(L.PCenterVendorListDisclosure + ": ", "5")), r.insertAdjacentElement("beforeend", e), t.disclosures.forEach(function(e) {
            var t, o = i.cloneNode(!0),
                n = "<p>" + L.PCenterVendorListStorageIdentifier + " </p> <p>" + (e.name || e.identifier) + " </p>";
            e.type && (n += "<p>" + L.PCenterVendorListStorageType + " </p> <p>" + e.type + " </p>"), e.maxAgeSeconds && (t = P.calculateCookieLifespan(e.maxAgeSeconds), n += "<p>" + L.PCenterVendorListLifespan + " </p> <p>" + t + " </p>"), e.domain && (n += "<p>" + L.PCenterVendorListStorageDomain + " </p> <p>" + e.domain + " </p>"), e.purposes && (n += "<p>" + L.PCenterVendorListStoragePurposes + ' </p><div class="disc-pur-cont">', e.purposes.forEach(function(e) {
                e = null == (e = b.iabGroups.purposes[e]) ? void 0 : e.name;
                e && (n += ' <p class="disc-pur">' + e + " </p>")
            }), n += "</div>"), o.innerHTML = m.getInnerHtmlContent(n), r.insertAdjacentElement("beforeend", o)
        }), this.updateDomainsUsageInDisclosures(t, i, r))
    }, s.prototype.getHeadingElement = function(e, t, o) {
        var n;
        return null != (n = S.moduleInitializer) && n.SEOOptimization ? '<p role="heading" aria-level="' + t + '" class="' + o + '">' + e + "</p>" : "<h" + t + ' class="' + o + '">' + e + "</h" + t + ">"
    }, s.prototype.updateDomainsUsageInDisclosures = function(e, n, r) {
        var t;
        e.domains && e.domains.length && ((t = n.cloneNode(!0)).innerHTML = m.getInnerHtmlContent(this.getHeadingElement(L.PCVLSDomainsUsed + ": ", "5")), r.insertAdjacentElement("beforeend", t), e.domains.forEach(function(e) {
            var t, o = n.cloneNode(!0);
            e.domain && (t = "<p>" + L.PCenterVendorListStorageDomain + " </p> <p>" + e.domain + " </p>"), e.use && (t += "<p>" + L.PCVLSUse + " </p> <p>" + e.use + " </p>"), o.innerHTML = m.getInnerHtmlContent(t), r.insertAdjacentElement("beforeend", o)
        }))
    }, s.prototype.addDescriptionElement = function(e, t) {
        var o = document.createElement("p");
        o.innerHTML = m.getInnerHtmlContent(t || ""), e.parentNode.insertBefore(o, e)
    }, s.prototype.setVdrConsentTglOrChbox = function(e, t, o, n, r, i) {
        var s, a, l = _.vendorsSetting[e],
            t = t.cloneNode(!0);
        l.consent && (t.classList.add(A.P_Ven_Ctgl), l = -1 !== m.inArray(e + ":true", _.vendors.selectedVendors), s = t.querySelector("input"), S.isV2Template && (s.classList.add("vendor-checkbox-handler"), a = t.querySelector(this.LABEL_STATUS), L.PCShowConsentLabels ? a.innerHTML = m.getInnerHtmlContent(l ? L.PCActiveText : L.PCInactiveText) : P.removeChild(a)), P.setCheckedAttribute("", s, l), P.setHtmlAttributes(s, {
            id: A.P_Vendor_CheckBx + "-" + i,
            vendorid: e,
            "aria-label": o
        }), t.querySelector("label").setAttribute("for", A.P_Vendor_CheckBx + "-" + i), t.querySelector(A.P_Label_Txt).textContent = o, b.pcName === st ? L.PCTemplateUpgrade ? n.insertAdjacentElement("beforeend", t) : v(n).append(t) : n.insertBefore(t, r))
    }, s.prototype.setVndrLegIntTglTxt = function(e, t) {
        e = e.querySelector(this.LABEL_STATUS);
        L.PCShowConsentLabels ? e.innerHTML = m.getInnerHtmlContent(t ? L.PCActiveText : L.PCInactiveText) : P.removeChild(e)
    }, s.prototype.setVdrLegIntTglOrChbx = function(t, e, o, n, r, i, s) {
        var a, l = _.vendorsSetting[t],
            o = o.cloneNode(!0),
            c = null == (c = _.vendors.list.find(function(e) {
                return e.vendorId === t
            }).legIntPurposes) ? void 0 : c.length;
        l.legInt && !l.specialPurposesOnly && c && (c = -1 !== m.inArray(t + ":true", _.vendors.selectedLegIntVendors), b.legIntSettings.PShowLegIntBtn ? (a = O.generateLegIntButtonElements(c, t, !0, n), e.querySelector(A.P_Acc_Txt).insertAdjacentHTML("beforeend", a), (a = e.querySelector(".ot-remove-objection-handler")) && d(a, a.getAttribute("data-style"))) : (a = o.querySelector("input"), S.isV2Template && (a.classList.add("vendor-checkbox-handler"), this.setVndrLegIntTglTxt(o, c)), o.classList.add(A.P_Ven_Ltgl), a.classList.remove("vendor-checkbox-handler"), a.classList.add("vendor-leg-checkbox-handler"), P.setCheckedAttribute("", a, c), P.setHtmlAttributes(a, {
            id: A.P_Vendor_LegCheckBx + "-" + r,
            "leg-vendorid": t,
            "aria-label": n
        }), o.querySelector("label").setAttribute("for", A.P_Vendor_LegCheckBx + "-" + r), o.querySelector(A.P_Label_Txt).textContent = n, e.querySelector("." + A.P_Ven_Ctgl) && (i = e.querySelector("." + A.P_Ven_Ctgl)), b.pcName !== st || s.children.length ? s.insertBefore(o, i) : v(s).append(o), l.consent || b.pcName !== st || o.classList.add(A.P_Ven_Ltgl_Only)))
    }, s.prototype.setVndrSplPurSection = function(e, t) {
        var o = this,
            n = e.querySelector(".spl-purpose"),
            e = e.querySelector(".spl-purpose-grp"),
            r = e.cloneNode(!0);
        e.parentElement.removeChild(e), b.isIab2orv2Template && t.specialPurposes.forEach(function(e) {
            v(r.querySelector(o.CONSENT_CATEGORY)).text(e.purposeName), n.insertAdjacentHTML("afterend", m.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.specialPurposes.length ? n.parentElement.removeChild(n) : v(n.querySelector("p")).text(L.SpecialPurposesText)
    }, s.prototype.setVndrFtSection = function(e, t) {
        var o = this,
            n = e.querySelector(".vendor-feature"),
            e = e.querySelector(".vendor-feature-group"),
            r = e.cloneNode(!0);
        e.parentElement.removeChild(e), v(n.querySelector("p")).text(L.FeaturesText), t.features.forEach(function(e) {
            v(r.querySelector(o.CONSENT_CATEGORY)).text(e.featureName), n.insertAdjacentHTML("afterend", m.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.features.length && n.parentElement.removeChild(n)
    }, s.prototype.setVndrSplFtSection = function(e, t) {
        var o = this,
            n = e.querySelector(".vendor-spl-feature"),
            e = e.querySelector(".vendor-spl-feature-grp"),
            r = e.cloneNode(!0);
        n.parentElement.removeChild(e), b.isIab2orv2Template && t.specialFeatures.forEach(function(e) {
            v(r.querySelector(o.CONSENT_CATEGORY)).text(e.featureName), n.insertAdjacentHTML("afterend", m.getInnerHtmlContent(r.outerHTML))
        }), 0 === t.specialFeatures.length ? n.parentElement.removeChild(n) : v(n.querySelector("p")).text(L.SpecialFeaturesText)
    }, s.prototype.setVndrAccTxt = function(e, t) {
        t = t.querySelector(A.P_Acc_Txt);
        t && P.setHtmlAttributes(t, {
            id: "IAB-ACC-TXT" + e,
            "aria-labelledby": "IAB-ACC-TXT" + e,
            role: "region"
        })
    }, s.prototype.setVndrDisclosure = function(e, t, o) {
        t.deviceStorageDisclosureUrl && (P.setHtmlAttributes(o, {
            "disc-vid": e
        }), _.discVendors[e] = {
            isFetched: !1,
            disclosureUrl: t.deviceStorageDisclosureUrl
        })
    }, s.prototype.setVndrListSelectAllChkBoxs = function() {
        var e = v("#onetrust-pc-sdk " + A.P_Sel_All_Vendor_Consent_Handler).el[0],
            e = (e && e.setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCenterSelectAllVendorsText + " " + L.LegitInterestText), v("#onetrust-pc-sdk " + A.P_Sel_All_Vendor_Leg_Handler).el[0]);
        e && e.setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCIABVendorsText + ", " + L.PCenterSelectAllVendorsText)
    }, s.prototype.setVndrConsentPurposes = function(e, t, o) {
        var n = this,
            r = e.querySelector(".vendor-consent-group"),
            i = e.querySelector(".vendor-option-purpose"),
            s = r.cloneNode(!0),
            a = e.querySelector(".legitimate-interest"),
            l = !1;
        return r.parentElement.removeChild(r), t.consent && (v(i.querySelector("p")).text(L.ConsentPurposesText), o.purposes.forEach(function(e) {
            v(s.querySelector(n.CONSENT_CATEGORY)).text(e.purposeName);
            e = s.querySelector(".consent-status");
            e && s.removeChild(e), a.insertAdjacentHTML("beforebegin", m.getInnerHtmlContent(s.outerHTML)), l = !0
        })), t.consent || i.parentElement.removeChild(i), l
    }, s.prototype.getVndrTglCntr = function(e) {
        return S.isV2Template ? E.chkboxEl.cloneNode(!0) : e.querySelector(".ot-checkbox")
    }, s.prototype.attachVendorsToDOM = function() {
        for (var u, p, C = this, g = _.vendors.list, h = _.vendors.vendorTemplate.cloneNode(!0), y = (_.discVendors = {}, S.isV2Template && (u = h.querySelector(".ot-ven-pur").cloneNode(!0), p = h.querySelector(A.P_Ven_Disc).cloneNode(!0), v(h.querySelector(".ot-ven-dets")).html("")), document.createDocumentFragment()), f = this, e = 0; e < g.length; e++)(e => {
            var t, o, n = h.cloneNode(!0),
                r = g[e].vendorId,
                i = g[e].vendorName,
                s = n.querySelector("." + A.P_Ven_Bx),
                a = _.vendorsSetting[r],
                l = (P.setHtmlAttributes(s, {
                    id: "IAB" + r,
                    name: "IAB" + r,
                    "aria-controls": "IAB-ACC-TXT" + r,
                    "aria-label": i
                }), s.nextElementSibling.setAttribute("for", "IAB" + r), n.querySelector(A.P_Ven_Name).innerText = i, f.updateIABLinksDOM(g[e], n), f.getVndrTglCntr(n)),
                c = n.querySelector(A.P_Tgl_Cntr),
                d = (S.isV2Template || l.parentElement.removeChild(l), n.querySelector(A.P_Arrw_Cntr));
            f.setVdrConsentTglOrChbox(r, l, i, c, d, e), f.setVdrLegIntTglOrChbx(r, n, l, i, e, d, c), S.isV2Template && (c.insertAdjacentElement("beforeend", E.arrowEl.cloneNode(!0)), L.PCAccordionStyle !== ce.Caret) && n.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)), f.setVndrAccTxt(r, n), f.setVndrDisclosure(r, g[e], s), S.isV2Template ? f.populateVendorDetailsHtml(n, u, g[e], p) : (t = n.querySelector(".legitimate-interest"), l = n.querySelector(".legitimate-interest-group"), o = l.cloneNode(!0), p = n.querySelector(A.P_Ven_Disc), i = n.querySelector(A.P_Ven_Dets), d = p.cloneNode(!0), p.parentElement.removeChild(p), f.attachVendorDisclosure(d, g[e]), i.insertAdjacentElement("afterbegin", d), f.setVndrConsentPurposes(n, a, g[e]), c = o.querySelector(".vendor-opt-out-handler"), b.isIab2orv2Template && c.parentElement.removeChild(c), l.parentElement.removeChild(l), a.legInt && (v(t.querySelector("p")).text(L.LegitimateInterestPurposesText), b.legIntSettings.PAllowLI) && b.isIab2orv2Template && g[e].legIntPurposes.forEach(function(e) {
                v(o.querySelector(C.CONSENT_CATEGORY)).text(e.purposeName), t.insertAdjacentHTML("afterend", m.getInnerHtmlContent(o.outerHTML))
            }), a.legInt || t.parentElement.removeChild(t), f.setVndrSplPurSection(n, g[e]), f.setVndrFtSection(n, g[e]), f.setVndrSplFtSection(n, g[e]), (r = s.parentElement.querySelector(".vendor-purposes p")).parentElement.removeChild(r)), y.appendChild(n), f.setVndrListSelectAllChkBoxs()
        })(e);
        document.querySelector("#onetrust-pc-sdk " + A.P_Vendor_Container).append(y)
    }, s.prototype.updateIABLinksDOM = function(e, t) {
        var o, n = e.vendorName,
            r = t.querySelector(A.P_Ven_Link),
            t = t.querySelector(A.P_Ven_Leg_Claim),
            i = b.isTcfV2Template ? e.vendorPrivacyUrl : e.policyUrl,
            s = !1;
        L.BannerRequireExternalLinks && (S.fp.CMPIconSprite && L.OTExternalLinkLogo && !L.BannerExternalLinksLogo ? (s = !0, o = I.updateCorrectUrl(L.OTExternalLinkLogo), o = L.BannerExternalLinksLogo ? I.updateCorrectUrl(L.BannerExternalLinksLogo) : o, o = "<svg class='ot-ext-lnk'>\n                        <use href='#" + new URL(o, window.location.origin).pathname.split("/").pop().split(".").shift() + "'></use>\n                        </svg>") : r.classList.add(this.EXT_LINK_CLASS)), P.setHtmlAttributes(r, {
            href: i,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), r.innerHTML = m.getInnerHtmlContent(L.PCenterViewPrivacyPolicyText + "&nbsp;<span class='ot-scrn-rdr'>" + n + " " + L.NewWinTxt + "</span>"), L.BannerRequireExternalLinks && s && r.insertAdjacentHTML("afterend", m.getInnerHtmlContent(o)), b.isTcfV2Template && e.legIntClaim && 0 < L.PCIABVendorLegIntClaimText.trim().length ? (P.setHtmlAttributes(t, {
            href: e.legIntClaim,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), t.innerHTML = m.getInnerHtmlContent(L.PCIABVendorLegIntClaimText + "&nbsp;<span class='ot-scrn-rdr'>" + n + " " + L.NewWinTxt + "</span>"), L.BannerRequireExternalLinks && (s ? t.insertAdjacentHTML("afterend", m.getInnerHtmlContent(o)) : t.classList.add(this.EXT_LINK_CLASS))) : t.remove()
    }, s.prototype.populateVendorDetailsHtml = function(e, o, t, n) {
        function r(e, t, o, n, r) {
            if (void 0 === r && (r = !1), t.length) {
                for (var i = u.getHeadingElement(String(L[e]), "5") + "<ul>", s = 0, a = t; s < a.length; s++) {
                    var l, c = a[s],
                        d = o(c);
                    r && null != (l = n) && l[c.purposeId] && (d += " (" + (l = n[c.purposeId].retention) + " " + (1 === l ? L.PCenterVendorListLifespanDay : L.PCenterVendorListLifespanDays) + ")"), i += "<li><p>" + d + "</p></li>"
                }
                p(i += "</ul>")
            }
        }
        var i, u = this,
            s = e.querySelector(".ot-ven-dets"),
            e = _.vendorsSetting[t.vendorId],
            p = function(e) {
                var t = o.cloneNode(!0);
                t.innerHTML = m.getInnerHtmlContent(e), s.insertAdjacentElement("beforeend", t)
            },
            n = n.cloneNode(!0);
        this.attachVendorDisclosure(n, t), s.insertAdjacentElement("beforeend", n), b.isTcfV2Template && null != (n = t.dataDeclaration) && n.length && r("PCVListDataDeclarationText", t.dataDeclaration, function(e) {
            return e.Name
        }), b.isTcfV2Template && null != (null == (n = t.dataRetention) ? void 0 : n.stdRetention) && (i = 1 === (n = t.dataRetention.stdRetention) ? L.PCenterVendorListLifespanDay : L.PCenterVendorListLifespanDays, n = this.getHeadingElement(L.PCVListDataRetentionText, "5") + ("<li><p>" + L.PCVListStdRetentionText) + " (" + n + " " + i + ")</p></li>", p(n)), e.consent && r("ConsentPurposesText", t.purposes, function(e) {
            return e.purposeName
        }, null == (i = t.dataRetention) ? void 0 : i.purposes, !0), e.legInt && null != (n = t.legIntPurposes) && n.length && r("LegitimateInterestPurposesText", t.legIntPurposes, function(e) {
            return e.purposeName
        }), b.isIab2orv2Template && null != (i = t.specialPurposes) && i.length && r("SpecialPurposesText", t.specialPurposes, function(e) {
            return e.purposeName
        }, null == (e = t.dataRetention) ? void 0 : e.specialPurposes, !0), null != (n = t.features) && n.length && r("FeaturesText", t.features, function(e) {
            return e.featureName
        }), b.isIab2orv2Template && null != (i = t.specialFeatures) && i.length && r("SpecialFeaturesText", t.specialFeatures, function(e) {
            return e.featureName
        })
    }, s.prototype.InitializeVendorList = function() {
        var e;
        _.vendors.list = _.iabData ? _.iabData.vendors : null, _.vendors.vendorTemplate = v(A.P_Vendor_Container + " li").el[0].cloneNode(!0), v("#onetrust-pc-sdk " + A.P_Vendor_Container).html(""), S.isV2Template || b.pcName !== st || (e = _.vendors.vendorTemplate.querySelectorAll(A.P_Acc_Header), (e = b.legIntSettings.PAllowLI && b.isIab2orv2Template ? e[0] : e[1]).parentElement.removeChild(e))
    }, s.prototype.cancelVendorFilter = function() {
        for (var e = v("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o = e[t].getAttribute("data-purposeid"),
                o = 0 <= _.filterByIABCategories.indexOf(o);
            P.setCheckedAttribute(null, e[t], o)
        }
    }, s.prototype.attachVendorDisclosure = function(e, t) {
        var o = "";
        t.cookieMaxAge && (o += this.getHeadingElement(L.PCenterVendorListLifespan + " :", "5")), o += "<span> " + t.cookieMaxAge + "</span>", t.usesNonCookieAccess && (o += "<p>" + L.PCenterVendorListNonCookieUsage + "</p>"), e.innerHTML = m.getInnerHtmlContent(o)
    }, s.prototype.updateVendorFilterList = function() {
        for (var e = v("#onetrust-pc-sdk .category-filter-handler").el, t = 0; t < e.length; t++) {
            var o, n = e[t].getAttribute("data-purposeid");
            e[t].checked && _.filterByIABCategories.indexOf(n) < 0 ? _.filterByIABCategories.push(n) : !e[t].checked && -1 < _.filterByIABCategories.indexOf(n) && (o = _.filterByIABCategories, _.filterByIABCategories.splice(o.indexOf(n), 1))
        }
        return _.filterByIABCategories
    }, s.prototype.saveVendorStatus = function(e) {
        var t = _.vendors,
            o = _.oneTrustIABConsent,
            e = ((e = void 0 === e ? !1 : e) || (o.purpose = t.selectedPurpose.slice(), o.specialFeatures = t.selectedSpecialFeatures.slice()), o.legimateInterest = t.selectedLegInt.slice(), o.vendors = t.selectedVendors.slice(), o.legIntVendors = t.selectedLegIntVendors.slice(), _.addtlVendors);
        e.vendorConsent = Object.keys(e.vendorSelected)
    }, s.prototype.updateIabVariableReference = function() {
        var e = _.oneTrustIABConsent,
            t = _.vendors,
            o = (t.selectedPurpose = e.purpose.slice(), t.selectedLegInt = e.legimateInterest.slice(), t.selectedVendors = e.vendors.slice(), t.selectedLegIntVendors = e.legIntVendors.slice(), t.selectedSpecialFeatures = e.specialFeatures.slice(), _.addtlVendors);
        o.vendorSelected = {}, o.vendorConsent.forEach(function(e) {
            o.vendorSelected[e] = !0
        })
    }, s.prototype.allowAllhandler = function() {
        xs.initializeIABData(!0, !1)
    }, s.prototype.rejectAllHandler = function(e) {
        xs.initializeIABData(!1, !0, e = void 0 === e ? !1 : e)
    }, s.prototype.populateAddtlVendors = function(e) {
        var t, o, n, r, i, s, a, l = (L.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0),
            c = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"),
            d = c.cloneNode(!0),
            c = (P.removeChild(d.querySelector("#ot-selall-hostcntr")), P.removeChild(c.querySelector("#ot-selall-vencntr")), P.removeChild(c.querySelector("#ot-selall-licntr")), E.accordionEl.cloneNode(!0)),
            c = (c.classList.add("ot-iab-acc"), c.querySelector(g.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", l.cloneNode(!0)), c.querySelector(g.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", m.getInnerHtmlContent(this.getHeadingElement(L.PCIABVendorsText, "4", this.VEN_TITLE_CLASS))), c.querySelector(".ot-acc-hdr").insertAdjacentElement("beforeEnd", d), c.querySelector(this.ACC_TXT).insertAdjacentElement("beforeEnd", v("#ot-ven-lst").el[0]), v("#ot-lst-cnt .ot-sdk-column").append(c), c.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCIABVendorsText), this.iabAccInit = !0, d.cloneNode(!0)),
            u = (P.removeChild(c.querySelector("#ot-selall-licntr")), c.querySelector(".ot-chkbox").id = "ot-selall-adtlvencntr", c.querySelector("input").id = "ot-selall-adtlven-handler", c.querySelector("label").setAttribute("for", "ot-selall-adtlven-handler"), E.accordionEl.cloneNode(!0)),
            p = (u.querySelector(g.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", l.cloneNode(!0)), u.querySelector(g.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", m.getInnerHtmlContent(this.getHeadingElement(L.PCGoogleVendorsText, "4", this.VEN_TITLE_CLASS))), u.querySelector(g.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", c), u.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeEnd", m.getInnerHtmlContent("<ul id='ot-addtl-venlst'></ul>")), u.classList.add("ot-adtlv-acc"), u.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCGoogleVendorsText), u.querySelector("#ot-selall-adtlven-handler").setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCGoogleVendorsText + ", " + L.PCenterSelectAllVendorsText), _.vendors.vendorTemplate.cloneNode(!0));
        for (t in p.querySelector("button").classList.remove("ot-ven-box"), p.querySelector("button").classList.add("ot-addtl-venbox"), P.removeChild(p.querySelector(this.ACC_TXT)), e) e[t] && (o = p.cloneNode(!0), n = e[t].name, o.querySelector(A.P_Ven_Name).innerText = n, r = o.querySelector("button"), P.setHtmlAttributes(r, {
            id: "Adtl-IAB" + t
        }), P.setHtmlAttributes(o.querySelector(A.P_Ven_Link), {
            href: e[t].policyUrl,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), o.querySelector(A.P_Ven_Link).innerHTML = m.getInnerHtmlContent(L.PCenterViewPrivacyPolicyText + "&nbsp;<span class='ot-scrn-rdr'>" + n + " " + L.NewWinTxt + "</span>"), L.BannerRequireExternalLinks && (S.fp.CMPIconSprite && L.OTExternalLinkLogo && !L.BannerExternalLinksLogo ? (r = I.updateCorrectUrl(L.OTExternalLinkLogo), r = L.BannerExternalLinksLogo ? I.updateCorrectUrl(L.BannerExternalLinksLogo) : r, r = "<svg class='ot-ext-lnk'>\n                                    <use href='#" + new URL(r, window.location.origin).pathname.split("/").pop().split(".").shift() + "'></use>\n                                    </svg>", o.querySelector(A.P_Ven_Link).insertAdjacentHTML("afterend", m.getInnerHtmlContent(r))) : o.querySelector(A.P_Ven_Link).classList.add(this.EXT_LINK_CLASS)), (r = E.chkboxEl.cloneNode(!0)).classList.remove("ot-ven-ctgl"), r.classList.add("ot-ven-adtlctgl"), i = Boolean(_.addtlVendors.vendorSelected[t]), (s = r.querySelector("input")).classList.add("ot-addtlven-chkbox-handler"), a = r.querySelector(this.LABEL_STATUS), L.PCShowConsentLabels ? a.innerHTML = m.getInnerHtmlContent(i ? L.PCActiveText : L.PCInactiveText) : P.removeChild(a), P.setCheckedAttribute("", s, i), P.setHtmlAttributes(s, {
            id: "ot-addtlven-chkbox-" + t,
            "addtl-vid": t,
            "aria-label": n
        }), r.querySelector("label").setAttribute("for", "ot-addtlven-chkbox-" + t), r.querySelector(A.P_Label_Txt).textContent = n, a = o.querySelector(A.P_Tgl_Cntr), v(a).append(r), a.insertAdjacentElement("beforeend", E.arrowEl.cloneNode(!0)), L.PCAccordionStyle !== ce.Caret && o.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)), this.checkIfLegLinkRemove(o), v(u.querySelector("#ot-addtl-venlst")).append(o));
        v("#ot-lst-cnt .ot-sdk-column").append(u), v("#onetrust-pc-sdk").on("click", "#ot-pc-lst .ot-acc-cntr > input", function(e) {
            P.setCheckedAttribute(null, e.target, e.target.checked)
        }), this.showConsentHeader()
    }, s.prototype.populateGeneralVendors = function() {
        var e, t, o, n, r, i = this,
            s = L.GeneralVendors,
            a = document.querySelector(".ot-gv-acc"),
            l = Boolean(a);
        s.length ? (this.handleVendorsPresence(a), e = this.getArrowElement(), this.iabAccInit || this.addIabAccordion(), t = this.createSelectAllCheckbox(), o = this.createGeneralVendorsAccordion(e, t), n = this.createVendorTemplate(), l && v("" + A.P_Gven_List).html(""), r = !0, s.forEach(function(e) {
            var t = i.createVendorElement(e, n);
            v(l ? "" + A.P_Gven_List : o.querySelector("" + A.P_Gven_List)).append(t), Io.isGenVenPartOfAlwaysActiveGroup(e.VendorCustomId) || (r = !1)
        }), l || v("#ot-lst-cnt .ot-sdk-column").append(o), v("#onetrust-pc-sdk").on("click", "#ot-pc-lst .ot-acc-cntr > input", function(e) {
            return P.setCheckedAttribute(null, e.target, e.target.checked)
        }), this.showConsentHeader(), r && P.setDisabledAttribute("#ot-selall-gnven-handler", null, !0)) : this.handleNoVendors(a)
    }, s.prototype.handleNoVendors = function(e) {
        this.hasGenVendors = !1, e && v(e).hide()
    }, s.prototype.handleVendorsPresence = function(e) {
        this.hasGenVendors = !0, e && v(e).show()
    }, s.prototype.getArrowElement = function() {
        return (L.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0)
    }, s.prototype.createSelectAllCheckbox = function() {
        var e = document.createElement("div"),
            t = (e.setAttribute("class", "ot-sel-all-chkbox"), E.chkboxEl.cloneNode(!0));
        return t.id = "ot-selall-gnvencntr", t.querySelector("input").id = "ot-selall-gnven-handler", t.querySelector("label").setAttribute("for", "ot-selall-gnven-handler"), v(e).append(t), e
    }, s.prototype.createGeneralVendorsAccordion = function(e, t) {
        var o = E.accordionEl.cloneNode(!0),
            n = o.querySelector(g.ACC_HDR_CLASS);
        return n.insertAdjacentElement("beforeend", e.cloneNode(!0)), n.insertAdjacentHTML("beforeend", m.getInnerHtmlContent(this.getHeadingElement(L.PCenterGeneralVendorsText, "4", this.VEN_TITLE_CLASS))), L.GenVenOptOut && n.insertAdjacentElement("beforeend", t), o.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeend", m.getInnerHtmlContent("<ul id='ot-gn-venlst'></ul>")), o.classList.add("ot-gv-acc"), o.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCenterGeneralVendorsText), o
    }, s.prototype.createVendorTemplate = function() {
        var e = _.vendors.vendorTemplate.cloneNode(!0),
            t = e.querySelector("button");
        return t.classList.remove("ot-ven-box"), t.classList.add("ot-gv-venbox"), v(e.querySelector(this.ACC_TXT)).html('<ul class="ot-host-opt"></ul>'), e
    }, s.prototype.createVendorElement = function(e, t) {
        var o, n = this,
            r = this.mapGenVendorToHostFormat(e),
            i = t.cloneNode(!0),
            t = e.VendorCustomId,
            s = e.Name,
            a = (i.querySelector(A.P_Ven_Name).innerText = s, i.querySelector("button")),
            a = (P.setHtmlAttributes(a, {
                id: "Gn-" + t
            }), i.querySelector(A.P_Ven_Link));
        return e.PrivacyPolicyUrl ? (P.setHtmlAttributes(a, {
            href: e.PrivacyPolicyUrl,
            rel: this.TARGET_BLANK_REL_NOOPENER,
            target: "_blank"
        }), a.innerHTML = m.getInnerHtmlContent(L.PCGVenPolicyTxt + "&nbsp;<span class='ot-scrn-rdr'>" + s + " " + L.NewWinTxt + "</span>"), L.BannerRequireExternalLinks && (S.fp.CMPIconSprite && L.OTExternalLinkLogo && !L.BannerExternalLinksLogo ? (o = I.updateCorrectUrl(L.OTExternalLinkLogo), o = L.BannerExternalLinksLogo ? I.updateCorrectUrl(L.BannerExternalLinksLogo) : o, o = new URL(o, window.location.origin).pathname.split("/").pop().split(".").shift(), a.insertAdjacentHTML("afterend", m.getInnerHtmlContent("<svg class='ot-ext-lnk'>\n                                <use href='#" + o + "'></use>\n                                </svg>"))) : a.classList.add(this.EXT_LINK_CLASS))) : a.classList.add("ot-hide"), this.addDescriptionElement(a, e.Description), L.GenVenOptOut && this.addConsentToggle(i, e, t, s, r), L.PCAccordionStyle !== ce.Caret && i.querySelector(".ot-ven-hdr").insertAdjacentElement("beforebegin", E.plusMinusEl.cloneNode(!0)), e.Cookies.length || v(i).addClass("ot-hide-acc"), e.Cookies.forEach(function(e) {
            e = n.getCookieElement(e, r);
            v(i.querySelector(".ot-host-opt")).append(e)
        }), this.checkIfLegLinkRemove(i), i
    }, s.prototype.addConsentToggle = function(e, t, o, n, r) {
        var i = E.chkboxEl.cloneNode(!0),
            s = (i.classList.remove("ot-ven-ctgl"), i.classList.add("ot-ven-gvctgl"), Boolean(_.genVendorsConsent[o])),
            a = i.querySelector("input"),
            l = (a.classList.add("ot-gnven-chkbox-handler"), i.querySelector(this.LABEL_STATUS)),
            l = (L.PCShowConsentLabels ? l.innerHTML = m.getInnerHtmlContent(s ? L.PCActiveText : L.PCInactiveText) : P.removeChild(l), P.setCheckedAttribute("", a, s), P.setHtmlAttributes(a, {
                id: "ot-gnven-chkbox-" + o,
                "gn-vid": o,
                "aria-label": n
            }), Io.isGenVenPartOfAlwaysActiveGroup(o) && P.setDisabledAttribute(null, a, !0), i.querySelector("label").setAttribute("for", "ot-gnven-chkbox-" + o), i.querySelector(A.P_Label_Txt).textContent = n, e.querySelector(A.P_Tgl_Cntr));
        v(l).append(i), l.insertAdjacentElement("beforeend", E.arrowEl.cloneNode(!0))
    }, s.prototype.addIabAccordion = function() {
        var e = (L.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0),
            t = document.querySelector("#onetrust-pc-sdk .ot-sel-all-chkbox"),
            o = t.cloneNode(!0),
            t = (P.removeChild(o.querySelector("#ot-selall-hostcntr")), P.removeChild(t.querySelector("#ot-selall-vencntr")), P.removeChild(t.querySelector("#ot-selall-licntr")), E.accordionEl.cloneNode(!0));
        t.classList.add("ot-iab-acc"), t.querySelector(g.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", e.cloneNode(!0)), t.querySelector(g.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", m.getInnerHtmlContent(this.getHeadingElement(L.PCIABVendorsText, "4", this.VEN_TITLE_CLASS))), t.querySelector(g.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", o), t.querySelector(this.ACC_TXT).insertAdjacentElement("beforeEnd", v("#ot-ven-lst").el[0]), v("#ot-lst-cnt .ot-sdk-column").append(t), t.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, L.PCIABVendorsText), this.iabAccInit = !0
    }, s.prototype.showConsentHeader = function() {
        var e = b.legIntSettings;
        v("#onetrust-pc-sdk .ot-sel-all-hdr").show(), e.PAllowLI && !e.PShowLegIntBtn || v("#onetrust-pc-sdk .ot-li-hdr").hide()
    }, s.prototype.setBackBtnTxt = function() {
        (S.isV2Template ? (v(A.P_Vendor_List + " .back-btn-handler").attr(this.ARIA_LABEL_ATTRIBUTE, L.PCenterBackText), v(A.P_Vendor_List + " .back-btn-handler title")) : v(A.P_Vendor_List + " .back-btn-handler .pc-back-button-text")).html(L.PCenterBackText)
    }, s.prototype.getCookieElement = function(e, t) {
        var o = _.hosts.hostCookieTemplate.cloneNode(!0),
            n = o.querySelector("dl").cloneNode(!0),
            r = (n.classList.remove("cookie-name-container"), v(o).html(""), e.Name),
            i = (L.AddLinksToCookiepedia && t.isFirstParty && (r = I.getCookieLabel(e, L.AddLinksToCookiepedia)), n.cloneNode(!0));
        return i.classList.add(A.P_c_Name), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(L.pcCListName), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(r), v(o).append(i), L.pcShowCookieHost && ((i = n.cloneNode(!0)).classList.add(A.P_c_Host), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(L.pcCListHost), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(e.Host), v(o).append(i)), L.pcShowCookieDuration && ((i = n.cloneNode(!0)).classList.add(A.P_c_Duration), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(L.pcCListDuration), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(e.IsSession ? L.LifespanTypeText : I.getDuration(e)), v(o).append(i)), L.pcShowCookieType && (r = t.Type === he.GenVendor ? !e.isThirdParty : t.isFirstParty, (i = n.cloneNode(!0)).classList.add(A.P_c_Type), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(L.pcCListType), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(r ? L.firstPartyTxt : L.thirdPartyTxt), v(o).append(i)), L.pcShowCookieCategory && (r = void 0, r = t.Type === he.GenVendor ? e.category : (t.isFirstParty ? e : t).groupName) && ((i = n.cloneNode(!0)).classList.add(A.P_c_Category), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(L.pcCListCategory), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(r), v(o).append(i)), L.pcShowCookieDescription && e.description && ((i = n.cloneNode(!0)).classList.add(A.P_c_Desc), i.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(L.pcCListDescription), i.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(e.description), v(o).append(i)), o
    }, s.prototype.getNoResultsFound = function(e) {
        e = _.showTrackingTech ? L.PCTechNotFound : e ? L.PCHostNotFound : L.PCVendorNotFound;
        return " " + e + "."
    }, s.prototype.getAdditionalTechnologiesHtml = function(e) {
        var t = document.createDocumentFragment(),
            o = L.AdditionalTechnologiesConfig,
            n = 0 < e.Cookies.length;
        return (n = n && e.Cookies[0].HostId === this.FIRST_PARTY_COOKIES_GROUP_NAME ? 0 < e.Cookies[0].Cookies.length : n) && ((n = g.getMainAccordionContainer(o.PCCookiesLabel, o.PCCookiesLabel, !1)).classList.add(this.TECH_COOKIES_SELECTOR), t.appendChild(n)), 0 < e.LocalStorages.length && ((n = g.getMainAccordionContainer(o.PCLocalStorageLabel, o.PCLocalStorageLabel)).classList.add("tech-local"), g.setSessionLocalStorageTemplate(n, e.LocalStorages, L.AdditionalTechnologiesConfig.PCLocalStorageDurationText), t.appendChild(n)), 0 < e.SessionStorages.length && ((n = g.getMainAccordionContainer(o.PCSessionStorageLabel, o.PCSessionStorageDurationText)).classList.add("tech-session"), g.setSessionLocalStorageTemplate(n, e.SessionStorages, L.AdditionalTechnologiesConfig.PCSessionStorageDurationText), t.appendChild(n)), t
    }, s.prototype.getMainAccordionContainer = function(e, t, o) {
        void 0 === o && (o = !0);
        var n = g.getAccordionStyleElement(),
            r = E.accordionEl.cloneNode(!0);
        return r.classList.add("ot-add-tech"), r.querySelector(g.ACC_HDR_CLASS).insertAdjacentElement("beforeEnd", n), r.querySelector(g.ACC_HDR_CLASS).insertAdjacentHTML("beforeEnd", m.getInnerHtmlContent(this.getHeadingElement(e, "4", this.VEN_TITLE_CLASS))), r.querySelector("button").setAttribute(this.ARIA_LABEL_ATTRIBUTE, t), o && r.querySelector(this.ACC_TXT).insertAdjacentHTML("beforeend", m.getInnerHtmlContent('<ul id="ot-host-lst" style="display: block;"></ul>')), r.cloneNode(!0)
    }, s.prototype.setSessionLocalStorageTemplate = function(e, t, o) {
        var n = _.hosts.hostTemplate.cloneNode(!0),
            r = (P.removeChild(n.querySelector(".ot-a scc-txt")), e.querySelector(this.ACC_TXT + " " + A.P_Host_Cntr));
        r.removeAttribute("style"), r.classList.add("ot-host-opt");
        for (var i = 0, s = t; i < s.length; i++) {
            var a = s[i],
                a = g.getSessionLocalStorageElement(a, o);
            r.append(a)
        }
    }, s.prototype.getSessionLocalStorageElement = function(e, t) {
        var o = _.hosts.hostCookieTemplate.cloneNode(!0),
            n = o.querySelector("dl").cloneNode(!0),
            r = (v(o).html(""), g.createKeyValueDivEle(n, A.P_c_Name, L.pcCListName, e.Name)),
            r = (v(o).append(r), g.createKeyValueDivEle(n, A.P_c_Host, L.pcCListHost, e.Host)),
            r = (v(o).append(r), g.createKeyValueDivEle(n, A.P_c_Duration, L.pcCListDuration, t)),
            t = (v(o).append(r), g.createKeyValueDivEle(n, A.P_c_Desc, L.pcCListDescription, e.description));
        return v(o).append(t), o
    }, s.prototype.createKeyValueDivEle = function(e, t, o, n) {
        e = e.cloneNode(!0);
        return e.classList.add(t), e.querySelector(this.NTH_CHILD_ONE_SELECTOR).innerHTML = m.getInnerHtmlContent(o), e.querySelector(this.NTH_CHILD_TWO_SELECTOR).innerHTML = m.getInnerHtmlContent(n), e
    }, s.prototype.getAdditionalTechnologiesDataFromGroup = function(e) {
        for (var t, o = [], n = {
                SessionStorages: [],
                LocalStorages: [],
                Cookies: []
            }, r = 0, i = g.getGroupsFromFilter(e); r < i.length; r++) {
            var s = i[r],
                a = On.getCookiesForGroup(s),
                o = U(o, null != (t = a.firstPartyCookiesList) ? t : []);
            n.Cookies = U(n.Cookies, a.thirdPartyCookiesList), n.LocalStorages = U(n.LocalStorages, null != (a = null == (t = s.TrackingTech) ? void 0 : t.LocalStorages) ? a : []), n.SessionStorages = U(n.SessionStorages, null != (a = null == (t = s.TrackingTech) ? void 0 : t.SessionStorages) ? a : [])
        }
        return o.length && n.Cookies.unshift({
            HostName: L.PCFirstPartyCookieListText,
            DisplayName: L.PCFirstPartyCookieListText,
            HostId: this.FIRST_PARTY_COOKIES_GROUP_NAME,
            isFirstParty: !0,
            Cookies: o,
            Description: ""
        }), n
    }, s.prototype.getFirstsAndThirdCookisFromGroups = function(e) {
        var t = [],
            o = [];
        return g.getGroupsFromFilter(e).forEach(function(e) {
            e = On.getCookiesForGroup(e);
            t = U(t, e.firstPartyCookiesList), o = U(o, e.thirdPartyCookiesList)
        }), {
            firstPartyCookiesList: t,
            thirdPartyCookiesList: o
        }
    }, s.prototype.getGroupsFromFilter = function(t) {
        var o = [];
        return L.Groups.forEach(function(e) {
            U(e.SubGroups, [e]).forEach(function(e) {
                (!t || !t.length || -1 !== t.indexOf(e.CustomGroupId)) && o.push(e)
            })
        }), o
    }, s.prototype.getAccordionStyleElement = function() {
        return (L.PCAccordionStyle === ce.Caret ? E.arrowEl : E.plusMinusEl).cloneNode(!0)
    }, s.prototype.getFilteredAdditionaTechtData = function(e, t) {
        var o, n = {
                SessionStorages: [],
                LocalStorages: [],
                Cookies: []
            },
            r = this.getSearchQuery(e),
            e = JSON.parse(JSON.stringify(t));
        return e.Cookies[0].HostId === this.FIRST_PARTY_COOKIES_GROUP_NAME && ((o = e.Cookies.shift()).Cookies = null == (t = o.Cookies) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        })), n.Cookies = null == (t = e.Cookies) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.DisplayName || e.HostName)
        }), o && 0 < o.Cookies.length && n.Cookies.unshift(o), n.LocalStorages = null == (t = e.LocalStorages) ? void 0 : t.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        }), n.SessionStorages = null == (o = e.SessionStorages) ? void 0 : o.filter(function(e) {
            return r.lastIndex = 0, r.test(e.Name || e.Host)
        }), n
    }, s.prototype.checkIfLegLinkRemove = function(e) {
        b.isTcfV2Template && e.querySelector(A.P_Ven_Leg_Claim).remove()
    };
    var g, Us = s;

    function s() {
        this.hasIabVendors = !1, this.hasGoogleVendors = !1, this.hasGenVendors = !1, this.iabAccInit = !1, this._displayNull = "display: '';", this.ARIA_LABEL_ATTRIBUTE = "aria-label", this.TECH_COOKIES_SELECTOR = "tech-cookies", this.FIRST_PARTY_COOKIES_GROUP_NAME = "first-party-cookies-group", this.LABEL_STATUS = ".ot-label-status", this.CONSENT_CATEGORY = ".consent-category", this.ACC_TXT = ".ot-acc-txt", this.NTH_CHILD_ONE_SELECTOR = "dt:nth-child(1)", this.NTH_CHILD_TWO_SELECTOR = "dd:nth-child(2)", this.LINE_THROUGH_CLASS = "line-through", this.ACC_HDR_CLASS = ".ot-acc-hdr", this.VEN_TITLE_CLASS = "ot-vensec-title", this.EXT_LINK_CLASS = "ot-ext-lnk", this.TARGET_BLANK_REL_NOOPENER = "noopener noreferrer", this.googleSearchSelectors = {
            vendorAccBtn: "#ot-addtl-venlst #Adtl-IAB",
            name: "name",
            accId: ".ot-adtlv-acc",
            selectAllEvntHndlr: "#ot-selall-adtlven-handler",
            venListId: "#ot-addtl-venlst",
            ctgl: ".ot-ven-adtlctgl"
        }, this.genVendorSearchSelectors = {
            vendorAccBtn: "#ot-gn-venlst #Gn-",
            name: "Name",
            accId: ".ot-gv-acc",
            selectAllEvntHndlr: "#ot-selall-gnven-handler",
            venListId: "#ot-gn-venlst",
            ctgl: ".ot-ven-gvctgl"
        }
    }
    Ks.prototype.initBanner = function() {
        this.canImpliedConsentLandingPage(), S.moduleInitializer.CookieSPAEnabled ? v(window).on("otloadbanner", this.windowLoadBanner.bind(this)) : v(window).one("otloadbanner", this.windowLoadBanner.bind(this))
    }, Ks.prototype.insertCSBtnHtmlAndCss = function(e) {
        var t = document.getElementById("onetrust-style"),
            t = (t.innerHTML = m.getInnerHtmlContent(t.innerHTML + xs.csBtnGroup.css), document.createElement("div")),
            t = (v(t).html(xs.csBtnGroup.html), t.querySelector("#ot-sdk-btn-floating"));
        e && t && v(t).removeClass("ot-hide"), v("#onetrust-consent-sdk").append(t), L.cookiePersistentLogo && (L.cookiePersistentLogo.includes("ot_guard_logo.svg") ? this.applyPersistentSvgOnDOM() : (v(".ot-floating-button__front, .ot-floating-button__back").addClass("custom-persistent-icon"), e = I.updateCorrectUrl(L.cookiePersistentLogo), t = new URL(e, window.location.origin).pathname, S.fp.CMPIconSprite && (t.includes("/logos/static/") || t.includes("src/assets/images/") && new URL(e, window.location.origin).host.includes("localhost")) && (e = "<svg>\n                    <use href='#" + t.split("/").pop().split(".").shift() + "'></use>\n                    </svg>", v(".ot-floating-button__front > button").html(e), v(".ot-floating-button__front svg").attr("class", "ot-source-sprite"))))
    }, Ks.prototype.applyPersistentSvgOnDOM = function() {
        return F(this, void 0, void 0, function() {
            var t;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return S.fp.CMPIconSprite ? (t = "<svg>\n            <use href='#ot_guard_logo'></use>\n            </svg>", [3, 3]) : [3, 1];
                    case 1:
                        return [4, Kt.getPersistentCookieSvg()];
                    case 2:
                        t = e.sent(), e.label = 3;
                    case 3:
                        return v(this.FLOATING_COOKIE_FRONT_BTN).html(t), u.otGuardLogoResolve(!0), [2]
                }
            })
        })
    }, Ks.prototype.canImpliedConsentLandingPage = function() {
        this.isImpliedConsent() && !_o.isLandingPage() && "true" === T.readCookieParam(y.OPTANON_CONSENT, h.AWAITING_RE_CONSENT) && this.checkForRefreshCloseImplied()
    }, Ks.prototype.isImpliedConsent = function() {
        return L.ConsentModel && "implied consent" === L.ConsentModel.Name.toLowerCase() || 0 < b.consentableImpliedConsentGroup.length
    }, Ks.prototype.checkForRefreshCloseImplied = function() {
        C.bannerCloseButtonHandler(!0)
    }, Ks.prototype.hideCustomHtml = function() {
        var e = document.getElementById("onetrust-banner-sdk");
        e && d(e, "display: none;")
    }, Ks.prototype.shouldShowBanner = function(e) {
        return L.ShowAlertNotice && !e && !L.NoBanner && !_.hideBanner
    }, Ks.prototype.shouldShowPc = function(e) {
        return L.ShowAlertNotice && !e && L.NoBanner
    }, Ks.prototype.windowLoadBanner = function() {
        return F(this, void 0, void 0, function() {
            var t, o, n, r, i, s, a;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return (this.core.substitutePlainTextScriptTags(), t = S.moduleInitializer, v("#onetrust-consent-sdk").length ? o = document.getElementById("onetrust-consent-sdk") : (o = document.createElement("div"), v(o).attr("id", "onetrust-consent-sdk"), v(o).attr("data-nosnippet", "true"), v(document.body).append(o)), S.fp.CMPIconSprite) ? (r = L.OTSpriteLogo, (n = S.moduleInitializer.ScriptType) !== qe.LOCAL && n !== qe.LOCAL_TEST || (r = I.updateCorrectUrl(L.OTSpriteLogo)), [4, Kt.getSpriteSvg(r)]) : [3, 2];
                    case 1:
                        n = e.sent(), r = document.createElement("div"), v(r).attr("id", "onetrust-sprite-svg"), v(r).html(n), v(o).append(r), e.label = 2;
                    case 2:
                        return (v(".onetrust-pc-dark-filter").length || (i = document.createElement("div"), v(i).attr("class", "onetrust-pc-dark-filter"), v(i).attr("class", "ot-hide"), v(i).attr("class", "ot-fade-in"), o.firstChild ? o.insertBefore(i, o.firstChild) : v(o).append(i)), L.IsIabEnabled && this.iab.updateIabVariableReference(), i = O.isAlertBoxClosedAndValid(), s = this.shouldShowBanner(i), a = this.shouldShowPc(i), _.ntfyRequired ? (this.hideCustomHtml(), wn.init(), wn.changeState()) : (s ? u.initializeAlartHtmlAndHandler() : (L.IsGPPEnabled && Ds.setCmpDisplayStatus("disabled"), this.hideCustomHtml()), u.addEventListnerForVendorsList()), t.IsSuppressPC || (N.insertPcHtml(), u.initialiseConsentNoticeHandlers(), L.IsIabEnabled && this.iab.InitializeVendorList()), this.prepopulateCookieOrVendorPageTitle(), this.initializeHbbTvScript(), this.insertCSBtn(!s), a) ? [4, u.toggleInfoDisplay()] : [3, 4];
                    case 3:
                        e.sent(), e.label = 4;
                    case 4:
                        return u.insertCookieSettingText(), this.initializeFloatingButtonOnBannerLoad(a), qs.insertTrackigTechOrCookiePolicy(), C.executeOptanonWrapper(), this.initializeCookieParamsOnBannerLoad(s), [2]
                }
            })
        })
    }, Ks.prototype.prepopulateCookieOrVendorPageTitle = function() {
        S.isV2Template && (L.GeneralVendorsEnabled ? this.iab.setListSearchValues(_e.vendors) : this.iab.setListSearchValues(_e.cookies))
    }, Ks.prototype.initializeFloatingButtonOnBannerLoad = function(e) {
        var t = v(this.FLOATING_COOKIE_BTN),
            o = v(this.FLOATING_COOKIE_FRONT_BTN),
            n = v(this.FLOATING_COOKIE_BACK_BTN);
        t.length && (t.attr("data-title", L.CookieSettingButtonText), o.el[0].setAttribute(mt, L.CookieSettingButtonText), n.el[0].setAttribute(mt, L.AriaClosePreferences), e ? (o.el[0].setAttribute(vt, !0), o.el[0].style.display = "none") : (n.el[0].setAttribute(vt, !0), n.el[0].style.display = "none"))
    }, Ks.prototype.initializeCookieParamsOnBannerLoad = function(e) {
        T.readCookieParam(y.OPTANON_CONSENT, Yt) || Po.writeGrpParam(y.OPTANON_CONSENT), T.readCookieParam(y.OPTANON_CONSENT, Jt) || Po.writeHstParam(y.OPTANON_CONSENT), _.showGeneralVendors && !T.readCookieParam(y.OPTANON_CONSENT, Xt) && Po.writeGenVenCookieParam(y.OPTANON_CONSENT), _.vsIsActiveAndOptOut && !T.readCookieParam(y.OPTANON_CONSENT, Qt) && Po.writeVSConsentCookieParam(y.OPTANON_CONSENT), e && No.setBannerFocus()
    }, Ks.prototype.initializeHbbTvScript = function() {
        var e;
        S.moduleInitializer.RemoteActionsEnabled && ((e = document.getElementById("hbbtv")) && e.remove(), (e = document.createElement("script")).id = "hbbtv", e.src = _.storageBaseURL + "/scripttemplates/" + S.moduleInitializer.Version + "/hbbtv.js", e.type = "text/javascript", v(document.body).append(e))
    }, Ks.prototype.insertCSBtn = function(e) {
        xs.csBtnGroup && (this.insertCSBtnHtmlAndCss(e), u.initFlgtCkStgBtnEventHandlers())
    }, Ks.prototype.insertTrackingTechnologies = function() {
        var e, t;
        v("#ot-sdk-cookie-policy, #optanon-cookie-policy").length && (window.OnetrustCookiePolicy && window.OnetrustCookiePolicy.InsertCookiePolicyHtml ? window.OnetrustCookiePolicy.InsertCookiePolicyHtml(I, L, v) : ((t = document.createElement("script")).id = "cookie-policy-script", t.onload = function() {
            return window.OnetrustCookiePolicy.InsertCookiePolicyHtml(I, L, v)
        }, t.type = "text/javascript", t.src = _.storageBaseURL + "/scripttemplates/" + S.moduleInitializer.Version + "/trackingTechnologies.js", null != (e = b.sriHash) && e["trackingTechnologies.js"] && (t.integrity = b.sriHash["trackingTechnologies.js"]), document.head.appendChild(t)))
    }, Ks.prototype.insertTrackigTechOrCookiePolicy = function() {
        S.fp.CookieV2TrackingTechnologies ? qs.insertTrackingTechnologies() : Tr.insertCookiePolicyHtml()
    };
    var qs, js = Ks;

    function Ks() {
        this.iab = g, this.core = On, this.FLOATING_COOKIE_BTN = "#ot-sdk-btn-floating", this.FLOATING_COOKIE_FRONT_BTN = "#ot-sdk-btn-floating .ot-floating-button__front .ot-floating-button__open", this.FLOATING_COOKIE_BACK_BTN = "#ot-sdk-btn-floating .ot-floating-button__back .ot-floating-button__close"
    }
    x(Js, zs = Ir), Js.prototype.Close = function(e) {
        C.closeBanner(!1), window.location.href = "https://otsdk//consentChanged"
    }, Js.prototype.RejectAll = function(e) {
        C.rejectAllEvent(), window.location.href = "https://otsdk//consentChanged"
    }, Js.prototype.AllowAll = function(e) {
        C.AllowAllV2(e), window.location.href = "https://otsdk//consentChanged"
    }, Js.prototype.ToggleInfoDisplay = function() {
        u.toggleInfoDisplay()
    };
    var zs, Ws, Ys = Js;

    function Js() {
        var e = null !== zs && zs.apply(this, arguments) || this;
        return e.mobileOnlineURL = b.mobileOnlineURL, e
    }
    Zs.prototype.syncConsentProfile = function(t, e, o) {
        void 0 === o && (o = !1), t ? _.dsParams.id = t.trim() : t = _.dsParams.id, o && (_.dsParams.isAnonymous = o), e = e || _.dsParams.token, t && e && Kt.getConsentProfile(t, e).then(function(e) {
            e = Array.isArray(e) ? e[0] : null;
            Xs.consentProfileCallback(e, t)
        })
    }, Zs.prototype.checkCarryOverAnonConsentForIAB = function() {
        if (null == (o = b.consentableIabGrps) || !o.length) return {
            iabSyncRequired: !1,
            latestConsentDate: new Date(0)
        };
        if (!b.checkLocalConsentForIabPurposes) return {
            iabSyncRequired: !1,
            latestConsentDate: new Date(0)
        };
        var e, t, o = !1,
            n = _.consentPreferences,
            r = n && 0 < n.purposes.length;
        if (b.carryOverAnonymousConsent ? (e = (t = this.checkLatestConsentDate(b.serverLatestDateForCookies)).consentedDate, t = t.isLocalConsentLatest) : (t = !1, i = this.getLastesConsentDateFromIabConsent(), b.serverLatestDateForCookies > (e = i) && (e = b.serverLatestDateForCookies)), this.checkIfServerConsent(r, t)) {
            T.writeCookieParam(y.OPTANON_CONSENT, h.PREV_USER_CONSENT, "");
            var o = !0,
                i = "",
                s = (Array.isArray(n.consentStrings) && n.consentStrings.length && (i = (null == (s = n.consentStrings.find(function(e) {
                    return "tcfeu" === e.type
                })) ? void 0 : s.content) || ""), n.gacString || "");
            if (i) {
                _.isIabSynced = !0, _.syncRequired = !0;
                for (var a = T.getCookiesChunk(i, y.EU_PUB_CONSENT), l = 0, c = Object.keys(a); l < c.length; l++) {
                    var d = c[l];
                    T.setCookie(d, a[d], L.ReconsentFrequencyDays, !1, new Date(e))
                }
            }
            s && (_.isGacSynced = !0, _.syncRequired = !0, T.setCookie(y.ADDITIONAL_CONSENT_STRING, s, L.ReconsentFrequencyDays, !1, new Date(e)))
        }
        return this.forceConsentReceipt(r, t), {
            iabSyncRequired: o,
            latestConsentDate: e
        }
    }, Zs.prototype.syncPreferences = function(e, t) {
        void 0 === t && (t = !1);
        var o, n = T.getCookie(y.ALERT_BOX_CLOSED),
            r = n,
            i = !1,
            s = !0,
            a = !1,
            l = !1,
            c = P.strToArr(T.readCookieParam(y.OPTANON_CONSENT, "groups"));
        if (e && null != (o = e.purposes) && o.length) {
            this.checkIfConsentIsGiven(e);
            for (var d = void 0, u = 0, p = e.purposes; u < p.length; u++) {
                var C = p[u],
                    C = this.syncGroupWithPreferences(C, c, r, a, t),
                    i = i || C.syncRequired,
                    a = a || C.syncOnlyDate,
                    l = l || C.isLocalConsentLatest;
                (!d || new Date(C.latestConsentDate) > new Date(d)) && (d = C.latestConsentDate)
            }
            n = d
        } else s = !1;
        return this.forceConsentReceipt(s, l), {
            alertBoxCookieVal: n,
            groupsConsent: c,
            profileFound: s,
            syncRequired: i,
            syncOnlyDate: a = a && !i
        }
    }, Zs.prototype.checkIfConsentIsGiven = function(e) {
        for (var t = 0, o = e.purposes; t < o.length; t++) {
            var n = o[t],
                r = b.domainGrps[n.id];
            r && this.isCookieGroup(r) && (b.consentGiven = b.consentGiven || n.status !== H[H.NO_CONSENT] && n.status !== H[H.ALWAYS_ACTIVE])
        }
    }, Zs.prototype.syncGroupWithPreferences = function(e, t, o, n, r) {
        var i, s = !1,
            a = e.status === H[H.NO_CONSENT],
            l = b.domainGrps[e.id],
            c = !1;
        if (l && this.isCookieGroup(l)) {
            i = o, -1 < _.grpsSynced.indexOf(l) && (_.syncedValidGrp = !0);
            var d = b.carryOverAnonymousConsent,
                o = new Date(e.lastInteractionDate) > new Date(o),
                s = !o;
            if (!d && b.consentGiven || d && o)
                if (a) {
                    if (t.length) {
                        for (var u = -1, p = 0; p < t.length; p++)
                            if (t[p].split(":")[0] === l) {
                                u = p;
                                break
                            } - 1 < u && (t.splice(u, 1), _.grpsSynced.push(l))
                    }
                } else {
                    d = this.getConsentValue(e.status);
                    n = !0, i = e.lastInteractionDate, c = this.updateCookieCatConsent(r, l, d, t)
                }
        }
        return {
            syncRequired: c,
            syncOnlyDate: n,
            latestConsentDate: i,
            isLocalConsentLatest: s
        }
    }, Zs.prototype.updateCookieCatConsent = function(e, t, o, n) {
        var r = !1;
        if (!e) {
            for (var i = t + ":" + o, s = -1, a = 0; a < n.length; a++) {
                var l = n[a].split(":");
                if (l[0] === t) {
                    l[1] !== o && (n[a] = i, r = !0), s = a;
                    break
                }
            } - 1 === s && (n.push(i), r = !0)
        }
        return r
    }, Zs.prototype.getConsentValue = function(e) {
        var t = null;
        switch (e) {
            case H[H.ACTIVE]:
            case H[H.ALWAYS_ACTIVE]:
                t = ge.Active;
                break;
            case H[H.EXPIRED]:
            case H[H.OPT_OUT]:
            case H[H.PENDING]:
            case H[H.WITHDRAWN]:
                t = ge.InActive
        }
        return t
    }, Zs.prototype.isCookieGroup = function(e) {
        return !/IABV2|ISPV2|IFEV2|ISFV2|IAB2V2|IFE2V2|ISP2V2|ISF2V2/.test(e)
    }, Zs.prototype.hideBannerAndPc = function() {
        var e = I.isBannerVisible();
        e && I.hideBanner(), (e || _.isPCVisible) && (gn.removeAddedOTCssStyles(), kn.hideConsentNoticeV2())
    }, Zs.prototype.setOptanonConsentCookie = function(e, t) {
        var o;
        e.syncRequired && (T.writeCookieParam(y.OPTANON_CONSENT, "groups", e.groupsConsent.toString()), o = T.getCookie(y.OPTANON_CONSENT), T.setCookie(y.OPTANON_CONSENT, o, t, !1, new Date(e.alertBoxCookieVal)), T.writeCookieParam(y.OPTANON_CONSENT, h.PREV_USER_CONSENT, ""), T.writeCookieParam(y.OPTANON_CONSENT, h.IS_ANONYMOUS_CONSENT, "0"))
    }, Zs.prototype.setIabCookie = function(e, t, o, n) {
        var e = this.checkLatestConsentDate(new Date(e)),
            r = e.isLocalConsentLatest,
            i = e.consentedDate,
            e = "",
            n = (n && Array.isArray(n.consentStrings) && n.consentStrings.length && (e = (null == (s = n.consentStrings.find(function(e) {
                return "tcfeu" === e.type
            })) ? void 0 : s.content) || ""), (null == (s = n) ? void 0 : s.gacString) || ""),
            s = e || n;
        if (this.checkIfServerConsent(!!s, r)) {
            if (t.syncRequired = !0, t.profileFound = !0, t.alertBoxCookieVal = i.toISOString(), e)
                for (var a = T.getCookiesChunk(e, y.EU_PUB_CONSENT), l = 0, c = Object.keys(a); l < c.length; l++) {
                    var d = c[l];
                    T.setCookie(d, a[d], o, !1, new Date(i))
                }
            n && T.setCookie(y.ADDITIONAL_CONSENT_STRING, n, o, !1, new Date(i))
        } else s || (t.profileFound = !1);
        this.forceConsentReceipt(t.profileFound, r)
    }, Zs.prototype.setAddtlVendorsCookie = function(e, t) {
        L.UseGoogleVendors && !T.getCookie(y.ADDITIONAL_CONSENT_STRING) && T.setCookie(y.ADDITIONAL_CONSENT_STRING, _.addtlConsentVersion, t, !1, new Date(e.alertBoxCookieVal))
    }, Zs.prototype.updateGrpsDom = function(s) {
        for (var e = 0, t = V.getAllGroupElements(); e < t.length; e++)(e => {
            var t, o = e.getAttribute("data-optanongroupid"),
                n = D.getGroupById(o),
                r = !0,
                i = P.findIndex(_.groupsConsent, function(e) {
                    return e.split(":")[0] === o
                });
            (-1 < i && _.groupsConsent[i].split(":")[1] === ge.InActive || L.IsIabEnabled && s && "COOKIE" !== n.Type && -1 < (t = s.purposes.findIndex(function(e) {
                return e.id === n.PurposeId.toLowerCase()
            })) && -1 === ["ACTIVE", "ALWAYS_ACTIVE"].findIndex(function(e) {
                return e === s.purposes[t].status
            })) && (r = !1), V.toggleGrpElements(e, n, r), V.toogleSubGroupElement(e, r, !1, !0), V.toogleSubGroupElement(e, r, !0, !0)
        })(t[e])
    }, Zs.prototype.updateVendorsDom = function() {
        L.IsIabEnabled && (g.updateIabVariableReference(), Kn.toggleVendorConsent(), b.legIntSettings.PAllowLI) && (b.legIntSettings.PShowLegIntBtn ? Kn.updateVendorLegBtns() : Kn.toggleVendorLi())
    }, Zs.prototype.consentProfileCallback = function(r, i) {
        return F(this, void 0, void 0, function() {
            var t, o, n;
            return M(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this.checkIfKnownUsersAreLogged(r, i) ? [2] : (t = this.syncPreferences(r), _.consentPreferences = r, o = L.ReconsentFrequencyDays, n = O.isIABCrossConsentEnabled(), this.setOptanonConsentCookie(t, o), L.IsIabEnabled && !n && this.setIabCookie(t.alertBoxCookieVal, t, o, r), t.syncOnlyDate && (O.syncAlertBoxCookie(t.alertBoxCookieVal), O.syncCookieExpiry()), kr.setDataSubjectIdV2(i), t.syncRequired && t.profileFound ? (T.writeCookieParam(y.OPTANON_CONSENT, h.PREV_USER_CONSENT, ""), T.writeCookieParam(y.OPTANON_CONSENT, h.IS_ANONYMOUS_CONSENT, "0"), _.syncRequired = t.syncRequired, O.syncAlertBoxCookie(t.alertBoxCookieVal), this.setAddtlVendorsCookie(t, o), this.hideBannerAndPc(), C.closeOptanonAlertBox(), xs.initGrpsAndHosts(), !n && L.NtfyConfig.ShowNtfy && O.isAlertBoxClosedAndValid() ? [4, wn.getContent()] : [3, 2]) : [3, 3]);
                    case 1:
                        e.sent(), wn.init(), wn.changeState(), e.label = 2;
                    case 2:
                        return L.IsIabEnabled && (O.setIABCookieData(), xs.initializeIabPurposeConsentOnReload(), yo.populateVendorAndPurposeFromCookieData()), this.updateGrpsDom(r), this.updateVendorsDom(), _o.setLandingPathParam(h.NOT_LANDING_PAGE), On.substitutePlainTextScriptTags(), Ln.updateGtmMacros(!0), C.executeOptanonWrapper(), [3, 4];
                    case 3:
                        t.profileFound && !b.forceCreateTrxLocalConsentIsGreater || !t.alertBoxCookieVal || this.createTrans(b.forceCreateTrxLocalConsentIsGreater), e.label = 4;
                    case 4:
                        return [2]
                }
            })
        })
    }, Zs.prototype.checkIfKnownUsersAreLogged = function(e, t) {
        var o = T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID),
            n = T.readCookieParam(y.OPTANON_CONSENT, h.PREV_USER_CONSENT),
            e = 0 < (null == (e = null == (e = e) ? void 0 : e.purposes) ? void 0 : e.length);
        return o !== t && !n && (T.removeAllCookies(), !e) && (!L.ShowAlertNotice || L.NoBanner || _.hideBanner || u.initializeAlartHtmlAndHandler(), kr.setDataSubjectIdV2(t), !0)
    }, Zs.prototype.createTrans = function(e) {
        var t = T.readCookieParam(y.OPTANON_CONSENT, "iType");
        Ns.createConsentTxn(!1, Ce[t], !1, !0, e)
    }, Zs.prototype.checkLatestConsentDate = function(e) {
        var t = T.getCookie(y.ALERT_BOX_CLOSED),
            t = t ? new Date(t) : new Date(0),
            o = this.getLastesConsentDateFromIabConsent();
        return t < o ? {
            isLocalConsentLatest: !1,
            consentedDate: o < e ? e : o
        } : t < e ? {
            isLocalConsentLatest: !1,
            consentedDate: e
        } : {
            isLocalConsentLatest: !0,
            consentedDate: t
        }
    }, Zs.prototype.getLastesConsentDateFromIabConsent = function() {
        var e = _.consentPreferences;
        if (!e) return new Date(0);
        for (var t = b.consentableIabGrps.reduce(function(e, t) {
                return e[t.PurposeId] = t, e
            }, {}), o = null, n = 0, r = e.purposes; n < r.length; n++) {
            var i = r[n];
            t[i.id.toUpperCase()] && (i = new Date(i.lastInteractionDate), !o || o < i) && (o = i)
        }
        return o
    }, Zs.prototype.checkIfServerConsent = function(e, t) {
        var o = b.carryOverAnonymousConsent;
        return !!(!o && e || o && e && !t)
    }, Zs.prototype.forceConsentReceipt = function(e, t) {
        var o = b.carryOverAnonymousConsent,
            n = T.readCookieParam(y.OPTANON_CONSENT, h.PREV_USER_CONSENT);
        b.forceCreateTrxLocalConsentIsGreater = b.forceCreateTrxLocalConsentIsGreater || !(!n || "" === n || "0" === n) && (!e || o && t)
    };
    var Xs, Qs = Zs;

    function Zs() {}
    ta.prototype.removeCookies = function() {
        T.removePreview(), T.removeOptanon(), T.removeAlertBox(), T.removeIab2(), T.removeAddtlStr(), T.removeVariant(), l.isPreview && $s.setPreviewCookie(), l.urlParams.get("otreset") && l.urlParams.set("otreset", "false");
        var e = window.location.pathname + "?" + l.urlParams.toString() + window.location.hash;
        $s.replaceHistory(e)
    }, ta.prototype.setPreviewCookie = function() {
        var e = new Date,
            t = (e.setTime(e.getTime() + 864e5), l.geoFromUrl ? "&geo=" + l.geoFromUrl : ""),
            e = "expiry=" + e.toISOString() + t;
        T.setCookie(y.OT_PREVIEW, e, 1, !1)
    }, ta.prototype.bindStopPreviewEvent = function() {
        (window.attachEvent || window.addEventListener)("message", function(e) {
            return $s.onMessage(e)
        })
    }, ta.prototype.replaceHistory = function(e) {
        history.pushState({}, "", e), location.reload()
    }, ta.prototype.onMessage = function(e) {
        "string" == typeof e.data && e.data === $s.CLEAR_COOKIES && ($s.removeCookies(), e.source) && e.source.postMessage && e.source.postMessage($s.CLEARED_COOKIES, e.origin)
    };
    var $s, ea, p, B = ta;

    function ta() {
        this.CLEAR_COOKIES = "CLEAR_OT_COOKIES", this.CLEARED_COOKIES = "CLEARED_OT_COOKIES"
    }
    Ge.initPolyfill(), T = new xt, I = new Zt, b = new eo, qt = new e, $s = new B, (p = window.otStubData) && (S.moduleInitializer = p.domainData, S.fp = S.moduleInitializer.TenantFeatures, _.isAMP = p.isAmp, _.dataDomainId = p.domainId, _.isPreview = p.isPreview, _.urlParams = p.urlParams, _.isV2Stub = p.isV2Stub || !1, b.gtmUpdatedinStub = p.gtmUpdated, p.isReset ? $s.removeCookies() : p.isPreview && $s.setPreviewCookie(), p.isV2Stub && (b.landingPath = p.landingPathValue), b.setBannerScriptElement(p.stubElement), b.setRegionRule(p.regionRule), S.fp.CookieV2TargetedTemplates && (b.conditionalLogicEnabled = !(null == (ea = b.getRegionRule().Conditions) || !ea.length), b.conditionalLogicEnabled) && ((() => {
            for (var e = b.getRegionRule(), t = 0; t < e.Conditions.length; t++) try {
                if ((e => {
                        if (e) return e = window.atob(e), Function('"use strict"; return ' + e)()
                    })(e.Conditions[t].Expression)) return b.Condition = e.Conditions[t]
            } catch (e) {
                console.warn(e);
                continue
            }
            b.allConditionsFailed = !0
        })(), b.canUseConditionalLogic = !b.allConditionsFailed), _.userLocation = p.userLocation, _.crossOrigin = p.crossOrigin, b.bannerDataParentURL = p.bannerBaseDataURL, b.mobileOnlineURL = U(b.mobileOnlineURL, p.mobileOnlineURL), ea = b.getRegionRule(), b.multiVariantTestingEnabled = S.moduleInitializer.MultiVariantTestingEnabled && 0 < ea.Variants.length && I.isDateCurrent(ea.TestEndTime), b.otDataLayer = p.otDataLayer, _.grpsSynced = p.grpsSynced || [], _.isIabSynced = p.isIabSynced, _.isGacSynced = p.isGacSynced, _.syncRequired = p.isIabSynced || p.isGacSynced || p.grpsSynced && 0 < p.grpsSynced.length, _.consentPreferences = p.preferences, _.syncGrpId = p.syncGrpId, _.consentApi = p.consentApi, _.tenantId = p.tenantId, _.geoFromUrl = p.geoFromUrl, _.nonce = p.nonce, _.setAttributePolyfillIsActive = p.setAttributePolyfillIsActive, _.storageBaseURL = p.storageBaseURL, _.identifierType = p.identifierType, b.previewMode = p.previewMode, b.prevUserWasAnon = p.prevUserWasAnon, b.userHasProfile = p.userHasProfile, b.consentGiven = p.consentGiven, b.serverLatestDateForCookies = p.serverLatestDateForCookies, b.carryOverAnonymousConsent = p.domainData.AuthenticatedConsent, b.checkLocalConsentForIabPurposes = p.checkLocalConsentForIabPurposes, b.forceCreateTrxLocalConsentIsGreater = p.forceCreateTrxLocalConsentIsGreater, b.stubUrl = p.stubUrl, b.sriHash = p.sriHash, qt.populateLangSwitcherPlhdr(), window.otStubData = {
            userLocation: _.userLocation
        }, window.OneTrustStub = null),
        function() {
            F(this, void 0, void 0, function() {
                var i, s, a, l;
                return M(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return (D = new ao, V = new un, Co = new go, g = new Us, On = new Dn, C = new er, u = new fr, N = new ur, pr = new Cr, qs = new js, S.fp.CookieV2TrackingTechnologies || (Tr = new Pr), co = new uo, Io = new bo, xs = new Fs, Ln = new _n, Sr = new mr, mo = new vo, E = new oo, Xs = new Qs, Kn = new zn, Kt = new zt, No = new cn, kn = new In, w = new Jn, ir = new sr, lr = new cr, c = new hr, S.moduleInitializer.MobileSDK ? Ws = new Ys : kr = new Ir, yo = new fo, n = T.getCookie(y.ALERT_BOX_CLOSED), r = T.getCookie(y.OPTANON_CONSENT), n && !r && T.removeAlertBox(), b.setGCMcallback(), l = b.getRegionRule(), l = (b.canUseConditionalLogic ? b.Condition : l).UseGoogleVendors, b.isIab2orv2Template = "IAB2" === b.getRegionRuleType() || "IAB2V2" === b.getRegionRuleType(), b.isTcfV2Template = "IAB2V2" === b.getRegionRuleType(), b.isIab2orv2Template) ? [4, Promise.all([Kt.getLangJson(), Kt.fetchGvlObj(), l ? Kt.fetchGoogleVendors() : Promise.resolve(null), Kt.loadCMP()])] : [3, 2];
                        case 1:
                            return l = e.sent(), i = l[0], s = l[1], a = l[2], _.gvlObj = s, _.addtlVendorsList = a ? a.vendors : null, [3, 4];
                        case 2:
                            return [4, Kt.getLangJson()];
                        case 3:
                            i = e.sent(), e.label = 4;
                        case 4:
                            return i.DomainData.IsGPPEnabled ? [4, Kt.loadGPP()] : [3, 6];
                        case 5:
                            e.sent(), Ds = new Vs, e.label = 6;
                        case 6:
                            return i.DomainData.PCShowDoubleOptInSignal ? [4, Kt.loadConfirmDialog()] : [3, 8];
                        case 7:
                            e.sent(), window.OneTrust_ConfirmDialog && window.OneTrust_ConfirmDialog.initConfirmDialog(), e.label = 8;
                        case 8:
                            var t, o;
                            return function(C) {
                                var g;
                                F(this, void 0, void 0, function() {
                                    var p;
                                    return M(this, function(e) {
                                        switch (e.label) {
                                            case 0:
                                                window.OneTrust = window.Optanon = Object.assign({}, window.OneTrust, (e => {
                                                    var t, o = S.moduleInitializer.MobileSDK,
                                                        n = {
                                                            AllowAll: (t = o ? Ws : kr).AllowAll,
                                                            BlockGoogleAnalytics: t.BlockGoogleAnalytics,
                                                            Close: t.Close,
                                                            getCSS: t.getCSS,
                                                            GetDomainData: t.GetDomainData,
                                                            getGeolocationData: t.getGeolocationData,
                                                            getHTML: t.getHTML,
                                                            Init: t.Init,
                                                            InitializeBanner: t.InitializeBanner,
                                                            initializeCookiePolicyHtml: t.initCookiePolicyAndSettings,
                                                            InsertHtml: t.InsertHtml,
                                                            InsertScript: t.InsertScript,
                                                            IsAlertBoxClosed: t.IsAlertBoxClosed,
                                                            IsAlertBoxClosedAndValid: t.IsAlertBoxClosedAndValid,
                                                            LoadBanner: t.LoadBanner,
                                                            OnConsentChanged: mo.OnConsentChanged,
                                                            ReconsentGroups: t.ReconsentGroups,
                                                            RejectAll: t.RejectAll,
                                                            SetAlertBoxClosed: t.SetAlertBoxClosed,
                                                            setGeoLocation: t.setGeoLocation,
                                                            ToggleInfoDisplay: t.ToggleInfoDisplay,
                                                            TriggerGoogleAnalyticsEvent: t.TriggerGoogleAnalyticsEvent,
                                                            useGeoLocationService: t.useGeoLocationService,
                                                            FetchAndDownloadPC: t.FetchAndDownloadPC,
                                                            changeLanguage: t.changeLang,
                                                            testLog: t.getTestLogData,
                                                            UpdateConsent: t.updateSingularConsent,
                                                            IsVendorServiceEnabled: t.vendorServiceEnabled,
                                                            UpdateGCM: t.updateGCM
                                                        };
                                                    return e.IsConsentLoggingEnabled && (n.getDataSubjectId = t.getDataSubjectId, n.setConsentProfile = t.setConsentProfile, n.setDataSubjectId = t.setDataSubjectIdV2, n.getDSDefaultIdentifier = t.getDSDefaultIdentifier, _.isV2Stub ? n.syncConsentProfile = Xs.syncConsentProfile : n.SendReceipt = t.sendReceipt), o && (n.mobileOnlineURL = t.mobileOnlineURL, n.otCookieData = _.otCookieData), e.IsIabEnabled && (n.updateConsentFromCookies = mo.updateConsentFromCookie, n.getPingRequest = yo.getPingRequestForTcf, n.getVendorConsentsRequestV2 = yo.getVendorConsentsRequestV2, n.showVendorsList = t.showVendorsList), n
                                                })(C.DomainData)), O.initializeBannerVariables(C), Po = new Ao, Do = new Vo, Ns = new Bs, gn = new Pn, _o = new Eo, or = new nr, wn = new qn;
                                                var t = window.OTExternalConsent;
                                                if (t && t.consentedDate && (t.groups || t.dsId || t.tcString || t.addtlString)) {
                                                    console.info("Consent is being passed to SDK through OTExternalConsent and is accepted.", t);
                                                    var o = [],
                                                        n = t.groups.split(",");
                                                    if (n.forEach(function(e) {
                                                            e = e.split(":");
                                                            o.push({
                                                                lastInteractionDate: t.consentedDate,
                                                                status: "1" === e[1] ? H[H.ACTIVE] : H[H.OPT_OUT],
                                                                id: e[0]
                                                            }), _.grpsSynced.push(e[0])
                                                        }), _.consentPreferences = {
                                                            purposes: [],
                                                            gacString: "",
                                                            consentStrings: []
                                                        }, _.syncRequired = !0, Po.updateGroupsInCookie(y.OPTANON_CONSENT, n), T.setCookie(y.ALERT_BOX_CLOSED, t.consentedDate, 365), t.dsId && !T.readCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID, !0) && T.writeCookieParam(y.OPTANON_CONSENT, h.CONSENT_ID, t.dsId), t.tcString) {
                                                        _.isIabSynced = !0;
                                                        for (var r = T.getCookiesChunk(t.tcString, y.EU_PUB_CONSENT), i = 0, s = Object.keys(r); i < s.length; i++) {
                                                            var a = s[i];
                                                            T.setCookie(a, r[a], 365)
                                                        }
                                                    }
                                                    t.addtlString && (_.isGacSynced = !0, T.setCookie(y.ADDITIONAL_CONSENT_STRING, "" + t.addtlString, 365))
                                                }
                                                _.isPreview && (O.syncOtPreviewCookie(), $s.bindStopPreviewEvent()), _.isV2Stub && (n = Xs.syncPreferences(_.consentPreferences, !0), d = Xs.checkCarryOverAnonConsentForIAB(), u = d.iabSyncRequired, d = d.latestConsentDate, u && (n.alertBoxCookieVal = d.toISOString()), n.syncRequired = n.syncRequired || u, _.syncRequired || n.syncRequired) && O.syncAlertBoxCookie(n.alertBoxCookieVal), O.syncCookieExpiry();
                                                var l, c, d = C,
                                                    u = window.OneTrust.dataSubjectParams || {},
                                                    u = ((_.dsParams = u).id && (l = u.identifierType || (null == (l = d.CommonData.ConsentIntegration) ? void 0 : l.DefaultIdentifier), kr.setDataSubjectIdV2(u.id, u.isAnonymous, l)), null == (l = u.identifierType) ? void 0 : l.trim());
                                                return _.isV2Stub && (l = void 0, c = null == (c = _.identifierType) ? void 0 : c.trim(), l = c || u || (null == (c = d.CommonData.ConsentIntegration) ? void 0 : c.DefaultIdentifier), T.writeCookieParam(y.OPTANON_CONSENT, h.IDENTIFIER_TYPE, l)), b.multiVariantTestingEnabled && b.selectedVariant && T.setCookie(y.SELECTED_VARIANT, b.selectedVariant.Id, L.ReconsentFrequencyDays), _.isV2Stub && null != (g = b.landingPath) && g.length && L.NextPageCloseBanner && T.writeCookieParam(y.OPTANON_CONSENT, "landingPath", b.landingPath), [4, yo.initializeIABModule()];
                                            case 1:
                                                return e.sent(), [4, function() {
                                                    var o;
                                                    return F(this, void 0, void 0, function() {
                                                        var t;
                                                        return M(this, function(e) {
                                                            switch (e.label) {
                                                                case 0:
                                                                    return null == (o = L) || !o.ACMData || !L.ACMData.Enabled || null != (o = _.userLocation) && o.country ? [3, 2] : [4, Kt.getGeolocation(S.moduleInitializer)];
                                                                case 1:
                                                                    t = e.sent(), _.userLocation = {
                                                                        country: t.country,
                                                                        state: t.state,
                                                                        stateName: t.stateName
                                                                    }, e.label = 2;
                                                                case 2:
                                                                    return [2]
                                                            }
                                                        })
                                                    })
                                                }()];
                                            case 2:
                                                return e.sent(), window.OneTrust.Init(!0), C.DomainData.IsGPPEnabled && Ds.initGppConsent(), [4, xs.fetchAssets()];
                                            case 3:
                                                return (e.sent(), qs.initBanner(), mo.assetResolve(!0), co.initialiseCssReferences(), p = O.isIABCrossConsentEnabled(), (_.syncedValidGrp || _.isIabSynced || _.isGacSynced) && !p && L.NtfyConfig.ShowNtfy && O.isAlertBoxClosedAndValid()) ? (_.ntfyRequired = !0, [4, wn.getContent()]) : [3, 5];
                                            case 4:
                                                e.sent(), e.label = 5;
                                            case 5:
                                                return p || window.OneTrust.LoadBanner(), [2]
                                        }
                                        var u, d
                                    })
                                })
                            }(i), S.moduleInitializer.WebFormIntegrationEnabled && S.moduleInitializer.WebFormSrcUrl && (n = window.otStubData, r = document.createElement("script"), t = S.moduleInitializer.WebFormSrcUrl, r.type = "text/javascript", r.src = t, o = S.moduleInitializer.TenantGuid, S.moduleInitializer.ScriptType === qe.TEST && (o += "-test"), r.setAttribute("dataId", o), r.setAttribute("worker", S.moduleInitializer.WebFormWorkerUrl), n.charset && r.setAttribute("charset", n.charset), n.crossOrigin && r.setAttribute("crossorigin", n.crossOrigin), document.querySelector('script[src="' + t + '"]') || document.getElementsByTagName("head")[0].appendChild(r)), [2]
                    }
                    var n, r
                })
            })
        }()
})();