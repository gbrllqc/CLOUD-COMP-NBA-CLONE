//tealium universal tag - nbatag.3 ut4.0.202602061808, Copyright 2026 Tealium.com Inc. All Rights Reserved.
var braze = braze || {};
var brazeQueue = brazeQueue || []; + function(a, p, P, b, y) {
    a.braze = {};
    a.brazeQueue = [];
    for (var s = "BrazeSdkMetadata DeviceProperties Card Card.prototype.dismissCard Card.prototype.removeAllSubscriptions Card.prototype.removeSubscription Card.prototype.subscribeToClickedEvent Card.prototype.subscribeToDismissedEvent Card.fromContentCardsJson Banner CaptionedImage ClassicCard ControlCard ContentCards ContentCards.prototype.getUnviewedCardCount Feed Feed.prototype.getUnreadCardCount ControlMessage InAppMessage InAppMessage.SlideFrom InAppMessage.ClickAction InAppMessage.DismissType InAppMessage.OpenTarget InAppMessage.ImageStyle InAppMessage.Orientation InAppMessage.TextAlignment InAppMessage.CropType InAppMessage.prototype.closeMessage InAppMessage.prototype.removeAllSubscriptions InAppMessage.prototype.removeSubscription InAppMessage.prototype.subscribeToClickedEvent InAppMessage.prototype.subscribeToDismissedEvent InAppMessage.fromJson FullScreenMessage ModalMessage HtmlMessage SlideUpMessage User User.Genders User.NotificationSubscriptionTypes User.prototype.addAlias User.prototype.addToCustomAttributeArray User.prototype.addToSubscriptionGroup User.prototype.getUserId User.prototype.incrementCustomUserAttribute User.prototype.removeFromCustomAttributeArray User.prototype.removeFromSubscriptionGroup User.prototype.setCountry User.prototype.setCustomLocationAttribute User.prototype.setCustomUserAttribute User.prototype.setDateOfBirth User.prototype.setEmail User.prototype.setEmailNotificationSubscriptionType User.prototype.setFirstName User.prototype.setGender User.prototype.setHomeCity User.prototype.setLanguage User.prototype.setLastKnownLocation User.prototype.setLastName User.prototype.setPhoneNumber User.prototype.setPushNotificationSubscriptionType InAppMessageButton InAppMessageButton.prototype.removeAllSubscriptions InAppMessageButton.prototype.removeSubscription InAppMessageButton.prototype.subscribeToClickedEvent FeatureFlag FeatureFlag.prototype.getStringProperty FeatureFlag.prototype.getNumberProperty FeatureFlag.prototype.getBooleanProperty automaticallyShowInAppMessages destroyFeed hideContentCards showContentCards showFeed showInAppMessage toggleContentCards toggleFeed changeUser destroy getDeviceId initialize isPushBlocked isPushPermissionGranted isPushSupported logCardClick logCardDismissal logCardImpressions logContentCardImpressions logContentCardClick logContentCardsDisplayed logCustomEvent logFeedDisplayed logInAppMessageButtonClick logInAppMessageClick logInAppMessageHtmlClick logInAppMessageImpression logPurchase openSession requestPushPermission removeAllSubscriptions removeSubscription requestContentCardsRefresh requestFeedRefresh refreshFeatureFlags requestImmediateDataFlush enableSDK isDisabled setLogger setSdkAuthenticationSignature addSdkMetadata disableSDK subscribeToContentCardsUpdates subscribeToFeedUpdates subscribeToInAppMessage subscribeToSdkAuthenticationFailures toggleLogging unregisterPush wipeData handleBrazeAction subscribeToFeatureFlagsUpdates getAllFeatureFlags".split(" "), i = 0; i < s.length; i++) {
        for (var m = s[i], k = a.braze, l = m.split("."), j = 0; j < l.length - 1; j++) k = k[l[j]];
        k[l[j]] = (new Function("return function " + m.replace(/\./g, "_") + "(){window.brazeQueue.push(arguments); return true}"))()
    }
    window.braze.getCachedContentCards = function() {
        return new window.braze.ContentCards
    };
    window.braze.getCachedFeed = function() {
        return new window.braze.Feed
    };
    window.braze.getUser = function() {
        return new window.braze.User
    };
    window.braze.getFeatureFlag = function() {
        return new window.braze.FeatureFlag
    };
}(window, document, 'script');
try {
    (function(id, loader) {
        var u = {
            "id": id
        };
        nbatag.o[loader].sender[id] = u;
        if (nbatag.ut === undefined) {
            nbatag.ut = {};
        }
        var match = /ut\d\.(\d*)\..*/.exec(nbatag.cfg.v);
        if (nbatag.ut.loader === undefined || !match || parseInt(match[1]) < 41) {
            u.loader = function(o, a, b, c, l, m) {
                nbatag.DB(o);
                a = document;
                if (o.type == "iframe") {
                    m = a.getElementById(o.id);
                    if (m && m.tagName == "IFRAME") {
                        b = m;
                    } else {
                        b = a.createElement("iframe");
                    }
                    o.attrs = o.attrs || {};
                    nbatag.ut.merge(o.attrs, {
                        "height": "1",
                        "width": "1",
                        "style": "display:none"
                    }, 0);
                } else if (o.type == "img") {
                    nbatag.DB("Attach img: " + o.src);
                    b = new Image();
                } else {
                    b = a.createElement("script");
                    b.language = "javascript";
                    b.type = "text/javascript";
                    b.async = 1;
                    b.charset = "utf-8";
                }
                if (o.id) {
                    b.id = o.id;
                }
                for (l in nbatag.loader.GV(o.attrs)) {
                    b.setAttribute(l, o.attrs[l]);
                }
                b.setAttribute("src", o.src);
                if (typeof o.cb == "function") {
                    if (b.addEventListener) {
                        b.addEventListener("load", function() {
                            o.cb();
                        }, false);
                    } else {
                        b.onreadystatechange = function() {
                            if (this.readyState == "complete" || this.readyState == "loaded") {
                                this.onreadystatechange = null;
                                o.cb();
                            }
                        };
                    }
                }
                if (o.type != "img" && !m) {
                    l = o.loc || "head";
                    c = a.getElementsByTagName(l)[0];
                    if (c) {
                        nbatag.DB("Attach to " + l + ": " + o.src);
                        if (l == "script") {
                            c.parentNode.insertBefore(b, c);
                        } else {
                            c.appendChild(b);
                        }
                    }
                }
            };
        } else {
            u.loader = nbatag.ut.loader;
        }
        if (nbatag.ut.typeOf === undefined) {
            u.typeOf = function(e) {
                return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
            };
        } else {
            u.typeOf = nbatag.ut.typeOf;
        }
        u.ev = {
            "view": 1,
            "link": 1
        };
        u.initialized = false;
        u.scriptrequested = false;
        u.queue = [];
        u.map_func = function(arr, obj, item) {
            var i = arr.shift();
            obj[i] = obj[i] || {};
            if (arr.length > 0) {
                u.map_func(arr, obj[i], item);
            } else {
                obj[i] = item;
            }
        };
        u.clearEmptyKeys = function(object) {
            for (var key in object) {
                if (object[key] === "" || object[key] === undefined) {
                    delete object[key];
                }
            }
            return object;
        };
        u.hasOwn = function(o, a) {
            return o != null && Object.prototype.hasOwnProperty.call(o, a);
        };
        u.isEmptyObject = function(o, a) {
            for (a in o) {
                if (u.hasOwn(o, a)) {
                    return false;
                }
            }
            return true;
        };
        u.map = {
            "direct_call_event:annual_LP_optout": "annual_auto-renew_opt-out",
            "direct_call_event:monthly_LP_cxl_confirm": "monthly_subscription_cancellation",
            "direct_call_event:nba_sign-in_success": "sign_in_web,SetEmail",
            "direct_call_event:tve_sign-in_success": "sign_in_web",
            "direct_call_event:sign up success": "create_account_web",
            "direct_call_event:video completed": "video_completed_web",
            "direct_call_event:video start": "video_start_web",
            "direct_call_event:add favorite team": "add_favorite_team_web",
            "direct_call_event:My Account Team Update Success": "add_favorite_team_web",
            "direct_call_event:add favorite player": "add_favorite_player_web",
            "direct_call_event:Braze: Hide Scores Toggled": "no_spoilers_web",
            "direct_call_event:opin_sign-in_success": "sign_in_web",
            "videoName": "video_completed_web.mediaContentName,video_start_web.mediaContentName",
            "videoID": "video_completed_web.mediaContentId,video_start_web.mediaContentId",
            "videoCategory": "video_completed_web.videoType,video_start_web.videoType",
            "premiumVideo": "video_completed_web.premiumMedia,video_start_web.premiumMedia",
            "contentType": "video_start_web.mediaContentType,video_completed_web.mediaContentType",
            "brazeEvent:add_favorite_player_web": "add_favorite_player_web",
            "brazeEvent:unfollow_player_web": "unfollow_player_web",
            "brazeEvent:sign_out_web": "sign_out_web",
            "brazeEvent:add_favorite_team_web": "add_favorite_team_web",
            "brazeEvent:follow_team_web": "follow_team_web",
            "brazeEvent:viewed_home_web": "viewed_home_web",
            "brazeEvent:viewed_fantasy_web": "viewed_fantasy_web",
            "brazeEvent:viewed_schedule_web": "viewed_schedule_web",
            "brazeEvent:viewed_packages_page_web": "viewed_packages_page_web",
            "brazeEvent:viewed_stats_web": "viewed_stats_web",
            "brazeEvent:viewed_summer_league_hub_web": "viewed_summer_league_hub_web",
            "brazeEvent:viewed_nbabet_hub_web": "viewed_nbabet_hub_web",
            "brazeEvent:viewed_standings_web": "viewed_standings_web",
            "brazeEvent:viewed_news_web": "viewed_news_web",
            "brazeEvent:viewed_game_index_web": "viewed_game_index_web",
            "brazeEvent:viewed_player_web": "viewed_player_web",
            "brazeEvent:viewed_team_web": "viewed_team_web",
            "brazeEvent:viewed_game_details_web": "viewed_game_details_web",
            "brazeEvent:viewed_article_web": "viewed_article_web",
            "brazeEvent:viewed_nbabet_article_web": "viewed_nbabet_article_web",
            "brazeEvent:viewed_draft_board_web": "viewed_draft_board_web",
            "brazeEvent:viewed_draft_home_web": "viewed_draft_home_web",
            "brazeEvent:viewed_all-star_web": "viewed_all-star_web",
            "brazeEvent:enter_payment_information_web": "enter_payment_information_web",
            "brazeEvent:viewed_summer_league_content_web": "viewed_summer_league_content_web",
            "brazeEvent:no_spoilers_web": "no_spoilers_web",
            "brazeEvent:unfollow_team_web": "unfollow_team_web",
            "currentlyFollowedTeam": "follow_team_web.team tri-code",
            "page.pageInfo.pageName": "follow_team_web.pageName,unfollow_team_web.pageName,viewed_game_index_web.pageName,viewed_home_web.pageName,add_favorite_player_web.pageName,unfollow_player_web.pageName,sign_out_web.pageName,add_favorite_team_web.pageName,follow_team_web.pageName,viewed_fantasy_web.pageName,viewed_schedule_web.pageName,viewed_packages_page_web.pageName,viewed_stats_web.pageName,viewed_summer_league_hub_web.pageName,viewed_nbabet_hub_web.pageName,viewed_standings_web.pageName,viewed_news_web.pageName,viewed_game_index_web.pageName,viewed_player_web.pageName,viewed_team_web.pageName,viewed_game_details_web.pageName,viewed_article_web.pageName,viewed_nbabet_article_web.pageName,viewed_draft_board_web.pageName,iewed_draft_home_web.pageName,viewed_all-star_web.pageName,enter_payment_information_web.pageName,no_spoilers_web.pageName,viewed_summer_league_content_web.pageName,sign_out_web.pageName,sign_in_web.pageName,no_spoilers_web.pageName,create_account_web.pageName,video_start_web.pageName,video_completed_web.pageName",
            "unfollowedTeam": "unfollow_team_web.team tricode,unfollow_team_web.RmvAtt.favorite_team_nba_app_web",
            "playerName": "viewed_player_web.playerName",
            "playerId": "viewed_player_web.playerId",
            "teamName": "viewed_team_web.teamName",
            "gameID": "viewed_game_details_web.gameId",
            "articleTitle": "viewed_article_web.articleTitle,viewed_nbabet_article_web.articleTitle",
            "articleID": "viewed_article_web.articleId,viewed_nbabet_article_web.articleId",
            "contentNetworkProvider": "viewed_nbabet_article_web.contentNetworkProvider",
            "summerLeagueContentType": "viewed_summer_league_content_web.content type",
            "braze_id": "api_key",
            "braze_enableHtmlInAppMessages": "initOpt.enable_htmlmsgs",
            "videoId": "video_start_web.mediaContentId,video_start_web.mediaContentId",
            "favorite_team": "add_favorite_team_web.team tricode,add_favorite_team_web.AddAtt.favorite_team_nba_app_web",
            "currentlyFavoritedPlayer": "add_favorite_player_web.playerName",
            "currentlyFavoritedPlayerID": "add_favorite_player_web.playerId,add_favorite_player_web.AddAtt.followed_nba_players",
            "unfavoritedPlayer": "unfollow_player_web.playerName",
            "unfavoritedPlayerID": "unfollow_player_web.playerId,unfollow_player_web.RmvAtt.followed_nba_players",
            "followTeam": "follow_team_web.team tricode,add_favorite_team_web.team tricode,follow_team_web.AddAtt.favorite_team_nba_app_web,add_favorite_team_web.AddAtt.favorite_team_nba_app_web",
            "currentlyFollowedTeamID": "follow_team_web.team tricode,follow_team_web.AddAtt.favorite_team_nba_app_web",
            "unfollowedTeamID": "unfollow_team_web.team tricode,unfollow_team_web.RmvAtt.favorite_team_nba_app_web",
            "teamID": "add_favorite_team_web.teamId",
            "team": "add_favorite_team_web.team tricode",
            "mediaContentName": "video_start_web.mediaContentName,video_completed_web.mediaContentName",
            "mediaContentId": "video_completed_web.mediaContentId,video_start_web.mediaContentId",
            "mediaContentType": "video_completed_web.mediaContentType,video_start_web.mediaContentType",
            "contentPosition": "no_spoilers_web.no_spoilers_web,no_spoilers_web.SetAtt.no_spoilers_web",
            "videoType": "video_start_web.videoType",
            "user.userID": "customer_id"
        };
        u.extend = [function(a, b) {
            try {
                if ((typeof b['page.content.categoryTitle'] != 'undefined' && b['page.content.categoryTitle'].toString().toLowerCase().indexOf('fantasy'.toLowerCase()) > -1 && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    b['brazeEvent'] = 'viewed_fantasy_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['direct_call_event'] != 'undefined' && b['direct_call_event'] == 'Braze - Hide Scores Toggled' && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase()) || (typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().indexOf('hide-scores:toggle') > -1 && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    if (typeof braze != "undefined")
                        braze.getUser().setCustomUserAttribute('no_spoilers_web', b['contentPosition']);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((b['tealium_event'].toString().indexOf('User Favorite: Add Player') > -1 && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    if (typeof braze != "undefined")
                        braze.getUser().addToCustomAttributeArray('followed_nba_players', b['interactionContentID']);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((b['tealium_event'].toString().indexOf('User Favorite: Follow Team') > -1 && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    if (typeof braze != "undefined")
                        braze.getUser().addToCustomAttributeArray('favorite_team_nba_app_web', b['interactionContent']);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase() && b['tealium_event'].toString().toLowerCase() == 'User Account: Login Success'.toLowerCase()) || (typeof b['tealium_event'] != 'undefined' && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase() && b['tealium_event'].toString().toLowerCase() == 'User Account: Registration Success'.toLowerCase())) {
                    if (typeof braze != "undefined")
                        braze.changeUser(b['user.userID']);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((b['tealium_event'].toString().indexOf('User Favorite: Unfollow Team') > -1 && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    if (typeof braze != "undefined")
                        braze.getUser().removeFromCustomAttributeArray('favorite_team_nba_app_web', b['interactionContent']);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((b['tealium_event'].toString().indexOf('User Account: Remove Player') > -1 && b['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    if (typeof braze != "undefined")
                        braze.getUser().removeFromCustomAttributeArray('followed_nba_players', b['interactionContentID']);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }];
        u.loader_cb = function() {
            nbatag.DB("send:3:CALLBACK");
            u.initialized = true;
            var g = {},
                i, _event, p;
            if (!u.isEmptyObject(u.data.initOpt)) {
                var config = {};
                if (u.data.initOpt.allow_crawler) {
                    config.allowCrawlerActivity = u.toBoolean(u.data.initOpt.allow_crawler);
                }
                if (u.data.initOpt.allow_user_supplied_javascript) {
                    config.allowUserSuppliedJavascript = u.toBoolean(u.data.initOpt.allow_user_supplied_javascript);
                }
                if (u.data.initOpt.app_ver) {
                    config.appVersion = u.data.initOpt.app_ver;
                }
                if (u.data.initOpt.base_url) {
                    config.baseUrl = u.data.initOpt.base_url;
                }
                if (u.data.initOpt.no_cookies) {
                    config.noCookies = u.toBoolean(u.data.initOpt.no_cookies);
                }
                if (u.data.initOpt.no_fntawsm) {
                    config.doNotLoadFontAwesome = u.toBoolean(u.data.initOpt.no_fntawsm);
                }
                if (u.data.initOpt.enable_logging) {
                    config.enableLogging = u.toBoolean(u.data.initOpt.enable_logging);
                }
                if (u.data.initOpt.localization) {
                    config.localization = u.data.initOpt.localization;
                }
                if (u.data.initOpt.min_trggrinterval) {
                    config.minimumIntervalBetweenTriggerActionsInSeconds = u.data.initOpt.min_trggrinterval;
                }
                if (u.data.initOpt.msg_innewtab) {
                    config.openInAppMessagesInNewTab = u.toBoolean(u.data.initOpt.msg_innewtab);
                }
                if (u.data.initOpt.card_innewtab) {
                    config.openNewsFeedCardsInNewTab = u.data.initOpt.card_innewtab;
                }
                if (u.data.initOpt.explicit_dissmisal) {
                    config.requireExplicitInAppMessageDismissal = u.toBoolean(u.data.initOpt.explicit_dissmisal);
                }
                if (u.data.initOpt.safari_pushid) {
                    config.safariWebsitePushId = u.data.initOpt.safari_pushid;
                }
                if (u.data.initOpt.srvcewrkr_location) {
                    config.serviceWorkerLocation = u.data.initOpt.srvcewrkr_location;
                }
                if (u.data.initOpt.session_timeout) {
                    config.sessionTimeoutInSeconds = u.data.initOpt.session_timeout;
                }
                if (u.data.initOpt.devicePropertyAllowlist) {
                    config.devicePropertyAllowlist = u.data.initOpt.devicePropertyAllowlist;
                }
                if (u.data.initOpt.enableSdkAuthentication) {
                    config.enableSdkAuthentication = u.toBoolean(u.data.initOpt.enableSdkAuthentication);
                }
                if (u.data.initOpt.content_security_nonce) {
                    config.contentSecurityNonce = u.data.initOpt.content_security_nonce;
                }
                if (u.data.initOpt.disable_push_token_maintenance) {
                    config.disablePushTokenMaintenance = u.toBoolean(u.data.initOpt.disable_push_token_maintenance);
                }
                if (u.data.initOpt.in_app_message_zindex) {
                    config.inAppMessageZIndex = u.data.initOpt.in_app_message_zindex;
                }
                if (u.data.initOpt.manage_service_worker_externally) {
                    config.manageServiceWorkerExternally = u.toBoolean(u.data.initOpt.manage_service_worker_externally);
                }
                if (u.data.initOpt.open_cards_in_new_tab) {
                    config.openCardsInNewTab = u.toBoolean(u.data.initOpt.open_cards_in_new_tab);
                }
                if (u.data.initOpt.custom) {
                    Object.keys(u.data.initOpt.custom).map(function(param) {
                        config[param] = u.data.initOpt.custom[param];
                    });
                }
                braze.initialize(u.data.api_key, config);
            } else {
                braze.initialize(u.data.api_key);
            }
            braze.addSdkMetadata([braze.BrazeSdkMetadata.TEALIUM]);
            braze.automaticallyShowInAppMessages();
            if (u.data.customer_id) {
                braze.changeUser(u.data.customer_id);
            }
            braze.openSession();
            if (u.data.order_id) {
                for (i = 0; i < u.data.event.length; i++) {
                    if (u.data.event[i] === "Purchase") {
                        p = true;
                    }
                }
                if (!p) {
                    u.data.event.push("Purchase");
                }
            }
            for (i = 0; i < u.data.event.length; i++) {
                _event = u.data.event[i];
                g = u.data[_event] = u.data[_event] || {};
                if (_event === "Purchase") {
                    if (!u.isEmptyObject(g.purchase_properties)) {
                        braze.logPurchase(g.product_id || u.data.product_id[0], g.order_subtotal || u.data.order_subtotal, g.order_currency || u.data.order_currency, g.product_quantity || u.data.product_quantity[0], g.purchase_properties);
                    } else {
                        braze.logPurchase(g.product_id || u.data.product_id[0], g.order_subtotal || u.data.order_subtotal, g.order_currency || u.data.order_currency, g.product_quantity || u.data.product_quantity[0]);
                    }
                } else if (_event === "Alias") {
                    braze.getUser().addAlias(g.alias, g.label);
                } else if (_event === "AddAtt") {
                    braze.getUser().addToCustomAttributeArray(g.key, g.value);
                } else if (_event === "addToSubscriptionGroup") {
                    braze.getUser().addToSubscriptionGroup(g.subscriptionGroupId);
                } else if (_event === "IncAtt") {
                    braze.getUser().incrementCustomUserAttribute(g.key, g.inc_value);
                } else if (_event === "RmvAtt") {
                    braze.getUser().removeFromCustomAttributeArray(g.key, g.value);
                } else if (_event === "SetAtt") {
                    braze.getUser().setCustomUserAttribute(g.key, g.value);
                } else if (_event === "SetLoc") {
                    braze.getUser().setLastKnownLocation(g.latitude, g.longitude, g.accuracy, g.altitude, g.altitude_accuracy);
                } else if (_event === "SetDOB") {
                    braze.getUser().setDateOfBirth(g.year, g.month, g.day);
                } else if (_event === "SetEmail") {
                    braze.getUser().setEmail(g.email);
                } else if (_event === "SetEmailSub") {
                    braze.getUser().setEmailNotificationSubscriptionType(g.notification_type);
                } else if (_event === "SetPushSub") {
                    braze.getUser().setPushNotificationSubscriptionType(g.notification_type);
                } else if (_event === "SetFirst") {
                    braze.getUser().setFirstName(g.first_name);
                } else if (_event === "SetLast") {
                    braze.getUser().setLastName(g.last_name);
                } else if (_event === "SetCity") {
                    braze.getUser().setHomeCity(g.customer_city || u.data.customer_city);
                } else if (_event === "SetCountry") {
                    braze.getUser().setCountry(g.customer_country || u.data.customer_country);
                } else if (_event === "SetLang") {
                    braze.getUser().setLanguage(g.language);
                } else if (_event === "SetPhone") {
                    braze.getUser().setPhoneNumber(g.phone_number);
                } else if (_event === "SetGender") {
                    braze.getUser().setGender(g.gender);
                } else if (_event) {
                    if (!u.isEmptyObject(u.data[_event])) {
                        braze.logCustomEvent(_event, u.data[_event]);
                    } else {
                        braze.logCustomEvent(_event);
                    }
                }
            }
            nbatag.DB("send:3:CALLBACK:COMPLETE");
        };
        u.callBack = function() {
            var data = {};
            while (data = u.queue.shift()) {
                u.loader_cb();
            }
        };
        u.toBoolean = function(val) {
            val = val || "";
            return val === true || val.toLowerCase() === "true" || val.toLowerCase() === "on";
        };
        u.send = function(a, b) {
            if (u.ev[a] || u.ev.all !== undefined) {
                nbatag.DB("send:3");
                nbatag.DB(b);
                var c, d, e, f, h;
                u.data = {
                    "qsp_delim": "&",
                    "kvp_delim": "=",
                    "base_url": "https://js.appboycdn.com/web-sdk/##nbatag_code_version##/braze.no-amd.min.js",
                    "code_version": "4.8",
                    "api_key": "",
                    "cst_url": "sdk.iad-03.braze.com",
                    "enable_logging": "false",
                    "initOpt": {},
                    "product_id": [],
                    "product_quantity": [],
                    "event": [],
                    "custom": {}
                };
                for (c = 0; c < u.extend.length; c++) {
                    try {
                        d = u.extend[c](a, b);
                        if (d == false) return
                    } catch (e) {}
                };
                nbatag.DB("send:3:EXTENSIONS");
                nbatag.DB(b);
                c = [];
                for (d in nbatag.loader.GV(u.map)) {
                    if (b[d] !== undefined && b[d] !== "") {
                        e = u.map[d].split(",");
                        for (f = 0; f < e.length; f++) {
                            u.map_func(e[f].split("."), u.data, b[d]);
                        }
                    } else {
                        h = d.split(":");
                        if (h.length === 2 && b[h[0]] === h[1]) {
                            if (u.map[d]) {
                                u.data.event = u.data.event.concat(u.map[d].split(","));
                            }
                        }
                    }
                }
                nbatag.DB("send:3:MAPPINGS");
                nbatag.DB(u.data);
                u.data.order_id = u.data.order_id || b._corder || "";
                u.data.order_subtotal = u.data.order_subtotal || b._csubtotal || "";
                u.data.order_currency = u.data.order_currency || b._ccurrency || "";
                u.data.customer_id = u.data.customer_id || b._ccustid || "";
                u.data.customer_city = u.data.customer_city || b._ccity || "";
                u.data.customer_country = u.data.customer_country || b._ccountry || "";
                if (u.data.product_id.length === 0 && b._cprod !== undefined) {
                    u.data.product_id = b._cprod.slice(0);
                }
                if (u.data.product_quantity.length === 0 && b._cquan !== undefined) {
                    u.data.product_quantity = b._cquan.slice(0);
                }
                if (u.data.event.length === 0 && b._cevent !== undefined) {
                    u.data.event = (u.typeOf(b._cevent) === "array") ? b._cevent.slice(0) : [b._cevent];
                }
                if (!u.data.api_key) {
                    nbatag.DB(u.id + ": Tag not fired: Required attribute 'API Key' not populated");
                    return;
                }
                if (!u.data.cst_url) {
                    nbatag.DB(u.id + ": Tag not fired: Required attribute 'Base URL' not populated");
                    return;
                }
                u.data.code_version = u.data.code_version.split(".").slice(0, 2).join(".");
                u.data.base_url = u.data.base_url.replace("##nbatag_code_version##", u.data.code_version);
                if (u.data.cst_url && !u.data.initOpt.base_url) {
                    u.data.initOpt.base_url = u.data.cst_url;
                }
                if (u.data.initOpt.enable_logging === undefined && u.data.enable_logging === "true") {
                    u.data.initOpt.enable_logging = u.data.enable_logging;
                }
                if (u.initialized) {
                    u.loader_cb();
                } else {
                    u.queue.push({
                        "data": u.data,
                        "a": a,
                        "b": b,
                        "c": c
                    });
                    if (!u.scriptrequested) {
                        u.scriptrequested = true;
                        u.loader({
                            "type": "script",
                            "src": u.data.base_url,
                            "cb": u.callBack,
                            "loc": "script",
                            "id": "nbatag_3",
                            "attrs": {}
                        });
                    }
                }
                nbatag.DB("send:3:COMPLETE");
            }
        };
        nbatag.o[loader].loader.LOAD(id);
    }("3", "nba.nba-web"));
} catch (error) {
    nbatag.DB(error);
}