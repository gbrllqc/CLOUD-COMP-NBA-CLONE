//tealium universal tag - nbatag.2 ut4.0.202602061808, Copyright 2026 Tealium.com Inc. All Rights Reserved.
try {
    (function(id, loader) {
        var u = {
            id: id
        };
        nbatag.o[loader].sender[id] = u;
        if (nbatag.ut.typeOf === undefined) {
            u.typeOf = function(e) {
                return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
            };
        } else {
            u.typeOf = nbatag.ut.typeOf;
        }
        u.ev = {
            view: 1,
            link: 1
        };
        u.initialized = false;
        u.scriptrequested = false;
        u.queue = [];
        u.clearEmptyKeys = function(object) {
            Object.keys(object).forEach(function(key) {
                if (object[key] === '' || object[key] === undefined) {
                    delete object[key];
                }
            });
            return object;
        };
        u.forceBoolean = function(input) {
            var bool;
            if (typeof input === 'boolean') {
                bool = input;
            } else if (typeof input === 'string' && input.toLowerCase() === 'true') {
                bool = true;
            } else {
                bool = false;
            }
            return bool;
        };
        u.map_func = function(arr, obj, item) {
            var i = arr.shift();
            obj[i] = obj[i] || {};
            if (arr.length > 0) {
                u.map_func(arr, obj[i], item);
            } else {
                obj[i] = item;
            }
        };
        u.loaderCallback = function() {
            nbatag.DB('send:2:CALLBACK');
            u.initialized = true;
            if (u.data.event) {
                u.data.event.forEach(function(event_name) {
                    var event_data = {};
                    if (typeof u.data[event_name] === 'object') {
                        Object.keys(u.data[event_name]).forEach(function(key) {
                            event_data[key] = u.data[event_name][key];
                        });
                    }
                    window.kochava.activity(event_name, event_data);
                });
            }
            nbatag.DB('send:2:CALLBACK:COMPLETE');
        };
        u.createUrl = function(cash) {
            var url = 'https://assets.kochava.com/kochava.js/v2.2/kochava.min.js';
            return u.forceBoolean(cash) ? url : (url + '?c=' + Math.random());
        };
        u.map = {
            "kochava_id": "app_guid",
            "user.userID": "identity_link_ids,authentication_success.user_id",
            "kochavaEvent:Start Account Creation": "Start Account Creation",
            "kochavaEvent:Registration Complete": "Registration Complete",
            "kochavaEvent:Authentication_Success": "Authentication_Success",
            "kochavaEvent:Checkout Start": "Checkout Start",
            "direct_call_event:sign up success": "Registration Complete",
            "direct_call_event:nba_sign-in_success": "Authentication_Success",
            "direct_call_event:purchase initiate direct to payment": "Checkout Start",
            "tealium_event:Page View: Sign Up": "Start Account Creation",
            "userID": "authentication_success.user_id,identity_link_ids,Authentication_Success.user_id,Registration Complete.user_id,registrationcomplete.user_id"
        };
        u.extend = [];
        u.send = function(nbatag_event, data_layer) {
            if (u.ev[nbatag_event] || u.ev.all !== undefined) {
                nbatag.DB('send:2');
                nbatag.DB(data_layer);
                var a, b, c, d, e, f, g, h, query_params;
                a = nbatag_event;
                b = data_layer;
                u.data = {
                    base_url: u.createUrl('false'),
                    command_id: 'kochava',
                    command_name: '',
                    app_guid: '',
                    autoPage: 'false',
                    autoCache: 'false',
                    autoVerbose: 'false',
                    autoCookieCollection: 'false',
                    identity_link_ids: '',
                    log_level: '',
                    event: [],
                    action: '',
                    ad_campaign_id: '',
                    ad_campaign_name: '',
                    ad_group_id: '',
                    ad_group_name: '',
                    ad_mediation_name: '',
                    ad_network_name: '',
                    ad_size: '',
                    ad_type: '',
                    background: '',
                    checkout_as_guest: '',
                    completed: '',
                    content_id: '',
                    content_type: '',
                    currency: '',
                    now_date: '',
                    description: '',
                    destination: '',
                    duration: '',
                    end_date: '',
                    item_added_from: '',
                    level: '',
                    max_rating_value: '',
                    name: '',
                    order_id: '',
                    quantity: '',
                    origin: '',
                    placement: '',
                    price: '',
                    rating_value: '',
                    receipt_id: '',
                    referral_from: '',
                    registration_method: '',
                    results: '',
                    score: '',
                    search_term: '',
                    spatial_x: '',
                    spatial_y: '',
                    spatial_z: '',
                    start_date: '',
                    success: '',
                    user_id: '',
                    user_name: '',
                    uri: '',
                    validated: '',
                    info_dictionary: {}
                };
                nbatag.DB('send:2:EXTENSIONS');
                nbatag.DB(data_layer);
                query_params = [];
                Object.keys(nbatag.loader.GV(u.map)).forEach(function(mapping_key) {
                    if (data_layer[mapping_key] !== undefined && data_layer[mapping_key] !== '') {
                        var destinations = u.map[mapping_key].split(',');
                        destinations.forEach(function(parameter) {
                            if (u.data.hasOwnProperty(parameter) || parameter.indexOf('.') > -1) {
                                u.map_func(parameter.split('.'), u.data, data_layer[mapping_key]);
                            }
                        });
                    } else {
                        var event_destinations = mapping_key.split(':');
                        if (event_destinations.length === 2 && String(data_layer[event_destinations[0]]) === String(event_destinations[1])) {
                            if (u.map[mapping_key]) {
                                u.data.event = u.data.event.concat(u.map[mapping_key].split(','));
                            }
                        }
                    }
                });
                nbatag.DB('send:2:MAPPINGS');
                nbatag.DB(u.data);
                var eCommerceMapping = [{
                    eCommerceData: b._corder,
                    name: 'order_id',
                    isArray: false
                }, {
                    eCommerceData: b._csubtotal,
                    name: 'order_subtotal',
                    isArray: false
                }, {
                    eCommerceData: b._ccurrency,
                    name: 'order_currency',
                    isArray: false
                }, {
                    eCommerceData: b._ccustid,
                    name: 'customer_id',
                    isArray: false
                }, {
                    eCommerceData: b._ctotal,
                    name: 'order_total',
                    isArray: false
                }, {
                    eCommerceData: b._cship,
                    name: 'order_shipping',
                    isArray: false
                }, {
                    eCommerceData: b._ctax,
                    name: 'order_tax',
                    isArray: false
                }, {
                    eCommerceData: b._cstore,
                    name: 'order_store',
                    isArray: false
                }, {
                    eCommerceData: b._cpromo,
                    name: 'order_coupon_code',
                    isArray: false
                }, {
                    eCommerceData: b._ctype,
                    name: 'order_type',
                    isArray: false
                }, {
                    eCommerceData: b._ccity,
                    name: 'customer_city',
                    isArray: false
                }, {
                    eCommerceData: b._cstate,
                    name: 'customer_state',
                    isArray: false
                }, {
                    eCommerceData: b._czip,
                    name: 'customer_zip',
                    isArray: false
                }, {
                    eCommerceData: b._ccountry,
                    name: 'customer_country',
                    isArray: false
                }];
                eCommerceMapping.forEach(function(dataObject) {
                    if (!dataObject.isArray) {
                        u.data[dataObject.name] = u.data[dataObject.name] || dataObject.eCommerceData || '';
                    } else if (u.data[dataObject.name].length === 0 && dataObject.eCommerceData !== undefined && dataObject.isArray) {
                        u.data[dataObject.name] = dataObject.eCommerceData.slice(0);
                    }
                });
                if (!u.data.app_guid) {
                    nbatag.DB(u.id + ': Tag not fired: Required attribute app_guid not populated');
                    return;
                }
                if (u.initialized) {
                    u.loaderCallback();
                } else {
                    if (!u.scriptrequested) {
                        u.scriptrequested = true;
                        !(function(e, t, o, a, n, c, s, i) {
                            var r = (window.kochava = window.kochava || []);
                            if (r.loaded)
                                window.console && console.error && console.error("Kochava snippet already included");
                            else {
                                (r.loaded = !0), (r.methods = ["page", "identify", "activity", "conversion", "init", "submitCookieId", "getCookieId", "getMAID", "getKochavaId", ]), (stub = function(e) {
                                    return function() {
                                        var t = Array.prototype.slice.call(arguments);
                                        return t.unshift(e), "function" == typeof r.push && r.push(t), r;
                                    };
                                });
                                for (var d = 0; d < r.methods.length; d++) {
                                    var u = r.methods[d];
                                    r[u] = stub(u);
                                }
                                r.init(new Date().getTime(), e, n, c, s, i), o && null != e && '' != e && r.page();
                            }
                        })(u.data.app_guid, 'v2.2', u.forceBoolean(u.data.autoPage), u.forceBoolean(u.data.autoCache), u.forceBoolean(u.data.autoVerbose), u.forceBoolean(u.data.autoCookieCollection), null, false);
                        window.kochava.identify(u.data.app_guid);
                        nbatag.ut.loader({
                            'type': 'script',
                            'src': u.data.base_url,
                            'cb': u.loaderCallback,
                            'loc': 'script',
                            'id': 'nbatag_2',
                            'attrs': {}
                        });
                    }
                }
            }
        };
        nbatag.o[loader].loader.LOAD(id);
    }('2', 'nba.nba-web'));
} catch (error) {
    nbatag.DB(error);
}