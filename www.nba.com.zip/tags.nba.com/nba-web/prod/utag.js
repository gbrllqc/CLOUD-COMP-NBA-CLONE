//tealium universal tag - nbatag.loader ut4.0.202602061808, Copyright 2026 Tealium.com Inc. All Rights Reserved.
var nbatag_condload = false;
try {
    (function() {
        function ul(src, a, b) {
            a = document;
            b = a.createElement('script');
            b.language = 'javascript';
            b.type = 'text/javascript';
            b.src = src;
            a.getElementsByTagName('head')[0].appendChild(b)
        };
        var match = ("" + document.cookie).match("(^|;\\s)nbatag_env_nba_nba-web=(\/\/tags\.tiqcdn\.com\/nbatag\/nba\/[a-z0-9\\.-]{1,30}\\/[^\\s;]*)");
        if (match) {
            if (match[2].indexOf("/prod/") === -1) {
                var s = match[2];
                while (s.indexOf("%") != -1) {
                    s = decodeURIComponent(s);
                }
                s = s.replace(/\.\./g, "");
                ul(s);
                nbatag_condload = true;
                __tealium_default_path = '//tags.nba.com/nba-web/prod/';
            }
        }
    })();
} catch (e) {};
try {
    try {
        window.includedDcrEvents = window.includedDcrEvents || [];
        if (window.includedDcrEvents && window.includedDcrEvents.length < 1) {
            window.includedDcrEvents.push("acquisition_placement", "add favorite player", "add favorite team", "annual_LP_cxl_initiate", "annual_LP_optin", "annual_LP_optout", "annual_LP_subManage_dismiss", "annual_LP_subManage_modalView", "annual_LP_subNoRefundCancel_error", "annual_LP_subNoRefundCancel_modalView", "annual_LP_subNoRefundCancelCancelSubscription_cta", "annual_LP_subNoRefundCancelConfirmation_modalView", "annual_LP_subNoRefundCancelConfirmationCustomerSupport_link", "annual_LP_subNoRefundCancelConfirmationDismiss_icon", "annual_LP_subNoRefundCancelConfirmationExplore_cta", "annual_LP_subNoRefundCancelDismiss_icon", "annual_LP_subNoRefundCancelGoBack_cta", "annual_LP_subRefundCancel_error", "annual_LP_subRefundCancel_modalView", "annual_LP_subRefundCancelCancelSubscription_cta", "annual_LP_subRefundCancelConfirmation_modalView", "annual_LP_subRefundCancelConfirmationCustomerSupport_link", "annual_LP_subRefundCancelConfirmationDismiss_icon", "annual_LP_subRefundCancelConfirmationExplore_cta", "annual_LP_subRefundCancelDismiss_icon", "annual_LP_subRefundCancelGoBack_cta", "Braze: Hide Scores Toggled", "Cancel Deflection Offer CTA", "Click To Login Page", "Click To Packages Page", "concurrency error modal view", "confirmation", "data track attribution", "date picker dropdown selection", "DCR: Game Entitlement Modal Views", "DCR: Modal View", "DCR: Purchase Funnel Modal Views", "email signup submit", "email_pref_update", "Flourish Event", "game_details_modalView", "how to watch modal", "initiate-purchase", "Link Account Attempt", "Link Account Success", "liveDataComponentPresent", "location modal", "log braze message", "LP_change_plan_cta", "LP_change_plan_dismiss", "LP_change_plan_select_card", "LP_change_plan_tab", "LP_cxl_confirm", "LP_cxl_confirmation_modalView", "LP_cxl_cta", "LP_cxl_dismiss", "LP_cxl_error_modal_refund_dismiss", "LP_cxl_modalView", "LP_manage_plan_cta", "LP_pause_instead", "LP_reactivate_sub_confirmation_modalView", "LP_reactivate_sub_modalView", "LP_refund_cancel_error", "LP_refund_cxl_confirm", "LP_refund_cxl_confirmation_modalView", "LP_refund_cxl_dismiss", "LP_refund_cxl_modalView", "LP_subChange_plan_modalView", "LP_subReactivate_dismiss", "LP_subReactivate_modal_cta", "LP_update_plan_confirmation_modalView", "LP_update_plan_cta", "LP_update_plan_summary_cta", "LP_update_plan_summary_dismiss", "LP_update_plan_summary_error_cta", "LP_update_plan_summary_error_dismiss", "LP_update_plan_summary_error_link", "LP_update_plan_summary_error_modalView", "LP_update_plan_summary_modalView", "Modal Dismiss", "monthly_LP_cancel_error", "monthly_LP_cxl_confirm", "monthly_LP_cxl_dismiss", "monthly_LP_cxl_initiate", "monthly_LP_cxl_modalView", "monthly_LP_pause_continue_cxl", "monthly_LP_pause_cta", "monthly_LP_resume_confirm_cta", "monthly_LP_resume_cta", "monthly_LP_resume_dismiss", "monthly_LP_resume_error", "monthly_LP_resume_error_dismiss", "monthly_LP_subManage_dismiss", "monthly_LP_subManage_modalView", "monthly_LP_subPause_back", "monthly_LP_subPause_cta", "monthly_LP_subPause_custSupportLink", "monthly_LP_subPause_dismiss", "monthly_LP_subPause_modalView", "monthly_LP_subPauseConf_modalView", "monthly_LP_subResume_cta", "monthly_LP_subResume_dismiss", "monthly_LP_subResume_modalView", "monthly_LP_subResumeConfirm_modalView", "monthly_LP_subResumeError_custSupportLink", "My Account CTA", "My Account Team Update Success", "My Account Update Error", "My Account Update Success", "navigation refinement", "nba_email_first_flow", "nba_send-password_failure", "nba_send-password_success", "nba_sign-in_failure", "nba_sign-in_success", "nba_update-password_failure", "nba_update-password_success", "opin_logout_success", "opin_sign-in_success", "overlay interaction", "page view", "pagination selection", "partner in-browser messaging", "payflow: promo code invalid", "payflow: promo code valid", "payment info success", "promo-code:invalid", "promo-code:valid", "purchase confirmation dcr", "Purchase Error", "purchase funnel error", "purchase initiate direct to payment", "remove filter", "Rendezvous Login Error", "Rendezvous Login Success", "reset filter", "search performed", "search results sort", "sign out success", "sign up success", "sign up error", "sort performed", "standard filter", "standard search", "storyteller_ad_action-button-tapped", "storyteller_ad_ad-complete", "storyteller_ad_ad-start", "storyteller_ad_close", "storyteller_ad_midpoint-complete", "storyteller_ad_first-quartile-complete", "storyteller_ad_skip-ad", "storyteller_ad_third-quartile-complete", "storyteller_media_video-complete", "storyteller_media_video-start", "storyteller_story_previous-content", "storyteller_story_previous-story", "storyteller_story_share-attempt", "storyteller_story_share-success", "storyteller_story_skip-content", "storyteller_story_skip-story", "storyteller_story_close", "storyteller_story_story-complete", "storyteller_story_story-start", "storyteller_story_swipe-up", "storyteller_story_trivia-quiz-completed", "storyteller_story_trivia-quiz-question-answered", "storyteller_story_voted-poll", "tab-click", "track-click", "tve_search_failure", "tve_sign-in_failure", "tve_sign-in_success", "Unlink Account Attempt", "Unlink Account Success", "update filter", "update table sort", "upsell modal view", "user_profile_modalView", "video completed", "video search", "video start", "watch_details_modalView", "welcomeToTheTeam");
        }
    } catch (e) {
        console.log(e)
    }
} catch (e) {
    console.log(e);
}
if (!nbatag_condload) {
    try {
        try {
            window.nbatag_cfg_ovrd = window.nbatag_cfg_ovrd || {};
            window.nbatag_cfg_ovrd.noview = true;
            window.nbatag_cfg_ovrd.always_set_v_id = true;
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            if (window.location.pathname === '/purchase-redirect' && typeof window.location.search === 'string' && window.location.search.indexOf('utm') > -1 && window.sessionStorage) {
                window.sessionStorage["purchase-redirect-utm"] = window.location.search;
            }
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            window.teal = window.teal || {};
            teal.replace_keys = {
                "customData": "",
                "eventDigitalData": "",
                "eventData": ""
            };
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            window.teal = window.teal || {};
            teal.ignore_keys = teal.ignore_keys || {};
            teal.replace_keys = teal.replace_keys || {};
            teal.prefix = "";
            teal.nested_delimiter = ".";
            teal.flattener_version = 1.4;
            Object.keys || (Object.keys = function() {
                "use strict";
                var a = Object.prototype.hasOwnProperty,
                    b = !{
                        toString: null
                    }.propertyIsEnumerable("toString"),
                    c = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
                    d = c.length;
                return function(e) {
                    if ("object" != typeof e && ("function" != typeof e || null === e)) throw new TypeError("Object.keys called on non-object");
                    var g, h, f = [];
                    for (g in e) a.call(e, g) && f.push(g);
                    if (b)
                        for (h = 0; h < d; h++) a.call(e, c[h]) && f.push(c[h]);
                    return f
                }
            }());
            teal.ignoreKey = function(key, re) {
                var should_ignore_key = 0;
                if (typeof teal.ignore_keys_list === 'undefined') {
                    teal.ignore_keys_list = Object.keys(teal.ignore_keys);
                    teal.ignore_keys_list.forEach(function(name) {
                        teal.ignore_keys[name] = new RegExp("^" + name);
                        if (key.match(teal.ignore_keys[name])) {
                            should_ignore_key = 1;
                        }
                    });
                } else {
                    teal.ignore_keys_list.forEach(function(name) {
                        if (key.match(teal.ignore_keys[name])) {
                            should_ignore_key = 1;
                        }
                    });
                }
                return should_ignore_key;
            }
            teal.getKeyName = function(key, re) {
                teal.replace_keys_regex = teal.replace_keys_regex || {};
                if (typeof teal.replace_keys_list === 'undefined') {
                    teal.replace_keys_list = Object.keys(teal.replace_keys);
                    teal.replace_keys_regex.startOfString = new RegExp("^[" + teal.nested_delimiter + "]");
                    teal.replace_keys_regex.endOfString = new RegExp("[" + teal.nested_delimiter + "]$");
                    teal.replace_keys_list.forEach(function(name) {
                        teal.replace_keys_regex[name] = new RegExp("[" + teal.nested_delimiter + "]?" + name + "[" + teal.nested_delimiter + "]?", "g");
                        key = teal.keyReplace(key, name, teal.replace_keys_regex[name]);
                    });
                } else {
                    teal.replace_keys_list.forEach(function(name) {
                        key = teal.keyReplace(key, name, teal.replace_keys_regex[name]);
                    });
                }
                return key;
            }
            teal.keyReplace = function(key, name, re) {
                if (teal.replace_keys[name] === '') {
                    key = key.replace(re, teal.nested_delimiter);
                    if (key.indexOf(teal.nested_delimiter) === 0) {
                        var cleanRegEx = new RegExp("^[" + teal.nested_delimiter + "]");
                        key = key.replace(cleanRegEx, '');
                    }
                } else {
                    var origKey = key;
                    key = key.replace(re, teal.nested_delimiter + teal.replace_keys[name] + teal.nested_delimiter);
                    if (!origKey.match(teal.replace_keys_regex.startOfString)) {
                        var cleanRegEx = new RegExp("^[" + teal.nested_delimiter + "]");
                        key = key.replace(cleanRegEx, '');
                    }
                    if (!origKey.match(teal.replace_keys_regex.endOfString)) {
                        var cleanRegEx = new RegExp("[" + teal.nested_delimiter + "]$");
                        key = key.replace(cleanRegEx, '');
                    }
                }
                return key;
            }
            teal.processDataObject = function(obj, new_obj, parent_key, create_array) {
                if (typeof parent_key === "undefined") {
                    parent_key = "";
                } else {
                    teal.nested_delimiter_regex = teal.nested_delimiter_regex || new RegExp("[" + teal.nested_delimiter + "]$");
                    if (!parent_key.match(teal.nested_delimiter_regex)) {
                        parent_key += "" + teal.nested_delimiter;
                    }
                }
                Object.keys(obj).forEach(function(key) {
                    var nested_key_name = parent_key + key;
                    var new_key_name = teal.getKeyName((teal.prefix + parent_key + key).replace(/\s/g, ''));
                    var key_type = teal.typeOf(obj[key]);
                    if (key_type !== 'undefined' && key_type != null) {
                        if (key_type.match(/boolean|string|number|date/) && !teal.ignoreKey(key)) {
                            if (teal.typeOf(obj[key]) === 'date') {
                                obj[key] = obj[key].toISOString();
                            }
                            if (create_array) {
                                if (teal.typeOf(new_obj[new_key_name]) !== "array") {
                                    new_obj[new_key_name] = [];
                                }
                                new_obj[new_key_name].push("" + obj[key]);
                            } else {
                                new_obj[new_key_name] = "" + obj[key];
                            }
                        } else if (key_type === 'object' && !teal.ignoreKey(key)) {
                            teal.processDataObject(obj[key], new_obj, nested_key_name, create_array);
                        } else if (key_type === 'array') {
                            teal.processDataArray(obj[key], new_obj, nested_key_name);
                        }
                    }
                });
            }
            teal.processDataArray = function(obj, new_obj, parent_key) {
                var objLength = obj.length;
                if (typeof parent_key === "undefined") {
                    parent_key = "";
                } else if (objLength > 0 && teal.typeOf(obj[0]).match(/boolean|string|number|date/)) {} else {
                    parent_key += "" + teal.nested_delimiter;
                }
                var new_key_name = teal.getKeyName((teal.prefix + parent_key).replace(/\s/g, ''));
                for (var n = 0; n < objLength; n++) {
                    var key_type = teal.typeOf(obj[n]);
                    if (key_type.match(/boolean|string|number|date/)) {
                        if (key_type === 'date') {
                            obj[n] = obj[n].toISOString();
                        }
                        if (teal.typeOf(new_obj[new_key_name]) !== "array") {
                            new_obj[new_key_name] = [];
                        }
                        new_obj[new_key_name].push("" + obj[n]);
                    } else if (key_type === 'object') {
                        teal.processDataObject(obj[n], new_obj, new_key_name, 1);
                    }
                }
            }
            teal.typeOf = function(e) {
                return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
            }
            teal.flattenObject = function(obj, new_obj) {
                if (typeof obj === 'undefined') {
                    return false;
                }
                var mergeObject = false;
                if (obj === new_obj) {
                    mergeObject = true;
                    new_obj = {};
                }
                if (typeof new_obj === 'undefined') {
                    new_obj = {};
                }
                if (teal.typeOf(obj) === 'array') {
                    var temp_array = JSON.parse(JSON.stringify(obj));
                    var temp_array_length = temp_array.length;
                    obj = {};
                    if (obj == new_obj) {
                        if (typeof a === 'undefined') {
                            var a = 'view';
                        }
                        nbatag.loader.RD(new_obj, a);
                    }
                    for (var i = 0; i < temp_array_length; i++) {
                        teal.processDataObject(temp_array[i], new_obj);
                    }
                } else {
                    teal.processDataObject(obj, new_obj);
                }
                if (mergeObject) {
                    Object.keys(obj).forEach(function(key) {
                        delete obj[key];
                    });
                    Object.keys(new_obj).forEach(function(key) {
                        obj[key] = new_obj[key];
                    });
                }
                return new_obj;
            }
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            window.disableAmplitude = "false";
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            window.disableBraze = "false";
            window.disableKochava = "false";
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            braze_enableHtmlInAppMessages = true;
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (!nbatag_condload) {
    try {
        try {
            window.useBrowserSdk = "true";
        } catch (e) {
            console.log(e)
        }
    } catch (e) {
        console.log(e);
    }
}
if (typeof nbatag == "undefined" && !nbatag_condload) {
    var nbatag = {
        id: "nba.nba-web",
        o: {},
        sender: {},
        send: {},
        rpt: {
            ts: {
                a: new Date()
            }
        },
        dbi: [],
        db_log: [],
        loader: {
            q: [],
            lc: 0,
            f: {},
            p: 0,
            ol: 0,
            wq: [],
            lq: [],
            bq: {},
            bk: {},
            rf: 0,
            ri: 0,
            rp: 0,
            rq: [],
            ready_q: [],
            sendq: {
                "pending": 0
            },
            run_ready_q: function() {
                for (var i = 0; i < nbatag.loader.ready_q.length; i++) {
                    nbatag.DB("READY_Q:" + i);
                    try {
                        nbatag.loader.ready_q[i]()
                    } catch (e) {
                        nbatag.DB(e)
                    };
                }
            },
            lh: function(a, b, c) {
                a = "" + location.hostname;
                b = a.split(".");
                c = (/\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\.|\...\.jp$/.test(a)) ? 3 : 2;
                return b.splice(b.length - c, c).join(".");
            },
            WQ: function(a, b, c, d, g) {
                nbatag.DB('WQ:' + nbatag.loader.wq.length);
                try {
                    if (nbatag.udoname && nbatag.udoname.indexOf(".") < 0) {
                        nbatag.ut.merge(nbatag.data, window[nbatag.udoname], 0);
                    }
                    if (nbatag.cfg.load_rules_at_wait) {
                        nbatag.handler.LR(nbatag.data);
                    }
                } catch (e) {
                    nbatag.DB(e)
                };
                d = 0;
                g = [];
                for (a = 0; a < nbatag.loader.wq.length; a++) {
                    b = nbatag.loader.wq[a];
                    b.load = nbatag.loader.cfg[b.id].load;
                    if (b.load == 4) {
                        this.f[b.id] = 0;
                        nbatag.loader.LOAD(b.id)
                    } else if (b.load > 0) {
                        g.push(b);
                        d++;
                    } else {
                        this.f[b.id] = 1;
                    }
                }
                for (a = 0; a < g.length; a++) {
                    nbatag.loader.AS(g[a]);
                }
                if (d == 0) {
                    nbatag.loader.END();
                }
            },
            AS: function(a, b, c, d) {
                nbatag.send[a.id] = a;
                if (typeof a.src == 'undefined' || !nbatag.ut.hasOwn(a, 'src')) {
                    a.src = nbatag.cfg.path + ((typeof a.name != 'undefined') ? a.name : 'ut' + 'ag.' + a.id + '.js')
                }
                a.src += (a.src.indexOf('?') > 0 ? '&' : '?') + 'utv=' + (a.v ? nbatag.cfg.template + a.v : nbatag.cfg.v);
                nbatag.rpt['l_' + a.id] = a.src;
                b = document;
                this.f[a.id] = 0;
                if (a.load == 2) {
                    nbatag.DB("Attach sync: " + a.src);
                    a.uid = a.id;
                    b.write('<script id="nbatag_' + a.id + '" src="' + a.src + '"></scr' + 'ipt>')
                    if (typeof a.cb != 'undefined') a.cb();
                } else if (a.load == 1 || a.load == 3) {
                    if (b.createElement) {
                        c = 'nbatag_nba.nba-web_' + a.id;
                        if (!b.getElementById(c)) {
                            d = {
                                src: a.src,
                                id: c,
                                uid: a.id,
                                loc: a.loc
                            }
                            if (a.load == 3) {
                                d.type = "iframe"
                            };
                            if (typeof a.cb != 'undefined') d.cb = a.cb;
                            nbatag.ut.loader(d);
                        }
                    }
                }
            },
            GV: function(a, b, c) {
                b = {};
                for (c in a) {
                    if (a.hasOwnProperty(c) && typeof a[c] != "function") b[c] = a[c];
                }
                return b
            },
            OU: function(tid, tcat, a, b, c, d, f, g) {
                g = {};
                nbatag.loader.RDcp(g);
                try {
                    if (typeof g['cp.OPTOUTMULTI'] != 'undefined') {
                        c = nbatag.loader.cfg;
                        a = nbatag.ut.decode(g['cp.OPTOUTMULTI']).split('|');
                        for (d = 0; d < a.length; d++) {
                            b = a[d].split(':');
                            if (b[1] * 1 !== 0) {
                                if (b[0].indexOf('c') == 0) {
                                    for (f in nbatag.loader.GV(c)) {
                                        if (c[f].tcat == b[0].substring(1)) c[f].load = 0;
                                        if (c[f].tid == tid && c[f].tcat == b[0].substring(1)) return true;
                                    }
                                    if (tcat == b[0].substring(1)) return true;
                                } else if (b[0] * 1 == 0) {
                                    nbatag.cfg.nocookie = true
                                } else {
                                    for (f in nbatag.loader.GV(c)) {
                                        if (c[f].tid == b[0]) c[f].load = 0
                                    }
                                    if (tid == b[0]) return true;
                                }
                            }
                        }
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
                return false;
            },
            RDdom: function(o) {
                var d = document || {},
                    l = location || {};
                o["dom.referrer"] = d.referrer;
                o["dom.title"] = "" + d.title;
                o["dom.domain"] = "" + l.hostname;
                o["dom.query_string"] = ("" + l.search).substring(1);
                o["dom.hash"] = ("" + l.hash).substring(1);
                o["dom.url"] = "" + d.URL;
                o["dom.pathname"] = "" + l.pathname;
                o["dom.viewport_height"] = window.innerHeight || (d.documentElement ? d.documentElement.clientHeight : 960);
                o["dom.viewport_width"] = window.innerWidth || (d.documentElement ? d.documentElement.clientWidth : 960);
            },
            RDcp: function(o, b, c, d) {
                b = nbatag.loader.RC();
                for (d in b) {
                    if (d.match(/nbatag_(.*)/)) {
                        for (c in nbatag.loader.GV(b[d])) {
                            o["cp.nbatag_" + RegExp.$1 + "_" + c] = b[d][c];
                        }
                    }
                }
                for (c in nbatag.loader.GV((nbatag.cl && !nbatag.cl['_all_']) ? nbatag.cl : b)) {
                    if (c.indexOf("nbatag_") < 0 && typeof b[c] != "undefined") o["cp." + c] = b[c];
                }
            },
            hasSplitUtagMainCookie: function() {
                return document.cookie.match(/([\s\S]*)nbatag_main_([\s\S]*)=([\s\S]*)/g);
            },
            hasUtagMainCookie: function() {
                return document.cookie.includes("nbatag_main=");
            },
            convertingToSplitCookies: function() {
                return nbatag.cfg.split_cookie && nbatag.loader.hasUtagMainCookie();
            },
            revertingSplitCookies: function() {
                return !nbatag.cfg.split_cookie && nbatag.loader.hasSplitUtagMainCookie();
            },
            readIndividualCookies: function() {
                if (!document.cookie || document.cookie === "") {
                    return {};
                }
                var cookies = document.cookie.split("; ");
                return cookies.reduce(function(result, cookie) {
                    var kv = cookie.split("=");
                    if (kv[0].startsWith("nbatag_")) {
                        var cookieName = kv[0].split("_")[1];
                        var cookieNameWithTag = "nbatag_" + cookieName;
                        if (!result[cookieNameWithTag]) {
                            result[cookieNameWithTag] = {};
                        }
                        var nameTrimmed = kv[0].replace(cookieNameWithTag + "_", "");
                        result[cookieNameWithTag][nameTrimmed] = String(kv[1]).replace(/%3B/g, ';')
                    }
                    return result;
                }, {});
            },
            RDqp: function(o, a, b, c) {
                a = location.search + (location.hash + '').replace("#", "&");
                if (nbatag.cfg.lowerqp) {
                    a = a.toLowerCase()
                };
                if (a.length > 1) {
                    b = a.substring(1).split('&');
                    for (a = 0; a < b.length; a++) {
                        c = b[a].split("=");
                        if (c.length > 1) {
                            o["qp." + c[0]] = nbatag.ut.decode(c[1])
                        }
                    }
                }
            },
            RDmeta: function(o, a, b, h) {
                a = document.getElementsByTagName("meta");
                for (b = 0; b < a.length; b++) {
                    try {
                        h = a[b].name || a[b].getAttribute("property") || "";
                    } catch (e) {
                        h = "";
                        nbatag.DB(e)
                    };
                    if (nbatag.cfg.lowermeta) {
                        h = h.toLowerCase()
                    };
                    if (h != "") {
                        o["meta." + h] = a[b].content
                    }
                }
            },
            RDva: function(o) {
                var readAttr = function(o, l) {
                    var a = "",
                        b;
                    a = localStorage.getItem(l);
                    if (!a || a == "{}") return;
                    b = nbatag.ut.flatten({
                        va: JSON.parse(a)
                    });
                    nbatag.ut.merge(o, b, 1);
                }
                try {
                    readAttr(o, "tealium_va");
                    readAttr(o, "tealium_va_" + o["ut.account"] + "_" + o["ut.profile"]);
                } catch (e) {
                    nbatag.DB(e)
                }
            },
            RDut: function(o, a) {
                var t = {};
                var d = new Date();
                var m = (nbatag.ut.typeOf(d.toISOString) == "function");
                o["ut.domain"] = nbatag.cfg.domain;
                o["ut.version"] = nbatag.cfg.v;
                t["tealium_event"] = o["ut.event"] = a || "view";
                t["tealium_visitor_id"] = o["ut.visitor_id"] = o["cp.nbatag_main_v_id"];
                t["tealium_session_id"] = o["ut.session_id"] = o["cp.nbatag_main_ses_id"];
                t["tealium_session_number"] = o["cp.nbatag_main__sn"];
                t["tealium_session_event_number"] = o["cp.nbatag_main__se"];
                try {
                    t["tealium_datasource"] = nbatag.cfg.datasource;
                    t["tealium_account"] = o["ut.account"] = nbatag.cfg.utid.split("/")[0];
                    t["tealium_profile"] = o["ut.profile"] = nbatag.cfg.utid.split("/")[1];
                    t["tealium_environment"] = o["ut.env"] = "prod";
                } catch (e) {
                    nbatag.DB(e)
                }
                t["tealium_random"] = Math.random().toFixed(16).substring(2);
                t["tealium_library_name"] = "ut" + "ag.js";
                t["tealium_library_version"] = (nbatag.cfg.template + "0").substring(2);
                t["tealium_timestamp_epoch"] = Math.floor(d.getTime() / 1000);
                t["tealium_timestamp_utc"] = (m ? d.toISOString() : "");
                d.setHours(d.getHours() - (d.getTimezoneOffset() / 60));
                t["tealium_timestamp_local"] = (m ? d.toISOString().replace("Z", "") : "");
                nbatag.ut.merge(o, t, 0);
            },
            RDses: function(o, a, c) {
                a = (new Date()).getTime();
                c = (a + parseInt(nbatag.cfg.session_timeout)) + "";
                if (!o["cp.nbatag_main_ses_id"]) {
                    o["cp.nbatag_main_ses_id"] = a + "";
                    o["cp.nbatag_main__ss"] = "1";
                    o["cp.nbatag_main__se"] = "1";
                    o["cp.nbatag_main__sn"] = (1 + parseInt(o["cp.nbatag_main__sn"] || 0)) + "";
                } else {
                    o["cp.nbatag_main__ss"] = "0";
                    o["cp.nbatag_main__se"] = (1 + parseInt(o["cp.nbatag_main__se"] || 0)) + "";
                }
                o["cp.nbatag_main__pn"] = o["cp.nbatag_main__pn"] || "1";
                o["cp.nbatag_main__st"] = c;
                var ses_id = nbatag.loader.addExpSessionFlag(o["cp.nbatag_main_ses_id"] || a);
                var pn = nbatag.loader.addExpSessionFlag(o["cp.nbatag_main__pn"]);
                var ss = nbatag.loader.addExpSessionFlag(o["cp.nbatag_main__ss"]);
                var st = nbatag.loader.addExpSessionFlag(c);
                var se = nbatag.loader.addExpSessionFlag(o["cp.nbatag_main__se"]);
                nbatag.loader.SC("nbatag_main", {
                    _sn: (o["cp.nbatag_main__sn"] || 1),
                    _se: se,
                    _ss: ss,
                    _st: st,
                    ses_id: ses_id,
                    _pn: pn
                });
            },
            containsExpSessionFlag: function(v) {
                return String(v).replace(/%3B/g, ';').includes(";exp-session");
            },
            addExpSessionFlag: function(v) {
                return nbatag.loader.containsExpSessionFlag(v) ? v : v + ";exp-session";
            },
            containsExpFlag: function(v) {
                return String(v).replace(/%3B/g, ';').includes(";exp-");
            },
            addExpFlag: function(v, x) {
                return nbatag.loader.containsExpFlag(v) ? v : v + ";exp-" + String(x);
            },
            RDpv: function(o) {
                if (typeof nbatag.pagevars == "function") {
                    nbatag.DB("Read page variables");
                    nbatag.pagevars(o);
                }
            },
            RDlocalStorage: function(o) {
                if (nbatag.cfg.ignoreLocalStorage) {
                    return;
                }
                Object.keys(window.localStorage).forEach(function(localStorageKey) {
                    o["ls." + localStorageKey] = window.localStorage[localStorageKey];
                });
            },
            RDsessionStorage: function(o) {
                if (nbatag.cfg.ignoreSessionStorage) {
                    return;
                }
                Object.keys(window.sessionStorage).forEach(function(sessionStorageKey) {
                    o["ss." + sessionStorageKey] = window.sessionStorage[sessionStorageKey];
                });
            },
            convertCustomMultiCookies: function() {
                var cookiesToConvert = {}
                if (nbatag.loader.convertingToSplitCookies()) {
                    nbatag.loader.mapUtagCookies(function(parentCookie) {
                        cookiesToConvert[parentCookie.key] = cookiesToConvert[parentCookie.key] || {}
                        parentCookie.value.split('$').forEach(function(subCookie) {
                            var key = subCookie.split(':')[0]
                            var value = subCookie.split(':')[1]
                            cookiesToConvert[parentCookie.key][key] = (String(value).indexOf('%3Bexp-') !== -1 && String(value).indexOf('%3Bexp-session') === -1) ? String(value).replace(/%3B/g, ';') + 'u' : String(value).replace(/%3B/g, ';');
                        })
                    })
                } else if (nbatag.loader.revertingSplitCookies()) {
                    nbatag.loader.mapUtagCookies(function(splitCookie) {
                        var parentCookieName = splitCookie.key.match(/^nbatag_[^_]*/)[0];
                        var subCookieName = splitCookie.key.split(parentCookieName + '_')[1];
                        cookiesToConvert[parentCookieName] = cookiesToConvert[parentCookieName] || {};
                        cookiesToConvert[parentCookieName][subCookieName] = (String(splitCookie.value).indexOf('%3Bexp-') !== -1 && String(splitCookie.value).indexOf('%3Bexp-session')) === -1 ? String(splitCookie.value).replace(/%3B/g, ';') + 'u' : String(splitCookie.value).replace(/%3B/g, ';');
                    })
                }
                if (nbatag.loader.convertingToSplitCookies()) {
                    nbatag.loader.getUtagCookies().forEach(function(cookie) {
                        nbatag.loader.deleteCookie(cookie.key);
                    });
                } else if (nbatag.loader.revertingSplitCookies()) {
                    nbatag.loader.deleteIndividualCookies();
                }
                Object.keys(cookiesToConvert).forEach(function(key) {
                    nbatag.loader.SC(key, cookiesToConvert[key]);
                });
            },
            RD: function(o, a) {
                nbatag.DB("nbatag.loader.RD");
                nbatag.DB(o);
                nbatag.loader.RDcp(o);
                if (nbatag.cfg.split_cookie) {
                    nbatag.loader.checkCookiesAgainstWhitelist();
                }
                if (nbatag.loader.convertingToSplitCookies() || nbatag.loader.revertingSplitCookies()) {
                    nbatag.loader.convertCustomMultiCookies();
                }
                if (!nbatag.loader.rd_flag) {
                    nbatag.loader.rd_flag = 1;
                    o["cp.nbatag_main__pn"] = (1 + parseInt(o["cp.nbatag_main__pn"] || 0)) + "";
                    var setVId = window.nbatag_cfg_ovrd && window.nbatag_cfg_ovrd.always_set_v_id || false;
                    if (setVId) {
                        o["cp.nbatag_main_v_id"] = o["cp.nbatag_main_v_id"] || nbatag.ut.vi((new Date()).getTime());
                        nbatag.loader.SC("nbatag_main", {
                            "v_id": o["cp.nbatag_main_v_id"]
                        });
                    }
                    nbatag.loader.RDses(o);
                }
                if (a && !nbatag.cfg.noview) nbatag.loader.RDses(o);
                nbatag.loader.RDqp(o);
                nbatag.loader.RDmeta(o);
                nbatag.loader.RDdom(o);
                nbatag.loader.RDut(o, a || "view");
                nbatag.loader.RDpv(o);
                nbatag.loader.RDva(o);
                nbatag.loader.RDlocalStorage(o);
                nbatag.loader.RDsessionStorage(o);
            },
            whitelistDefined: function() {
                return nbatag.cfg.split_cookie_allowlist && Array.isArray(nbatag.cfg.split_cookie_allowlist);
            },
            cookieIsAllowed: function(key) {
                return !nbatag.loader.whitelistDefined() || nbatag.cfg.split_cookie_allowlist.includes(key);
            },
            checkCookiesAgainstWhitelist: function() {
                if (!nbatag.loader.whitelistDefined()) {
                    return;
                }
                nbatag.loader.mapUtagCookies(function(cookie) {
                    if (!nbatag.loader.cookieIsAllowed(cookie.key.replace("nbatag_main_", ""))) {
                        nbatag.loader.deleteCookie(cookie.key);
                    }
                }, true);
            },
            deleteIndividualCookies: function() {
                nbatag.loader.mapUtagCookies(function(cookie) {
                    nbatag.loader.deleteCookie(cookie.key);
                });
            },
            deleteCookie: function(key) {
                document.cookie = key + "=; path=/;domain=" + nbatag.cfg.domain + ";max-age=0;";
            },
            getUtagCookies: function(onlyUtagMain = false) {
                var cookies = document.cookie.split("; ");
                var result = [];
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = cookies[i];
                    if (cookie.startsWith(onlyUtagMain ? "nbatag_main_" : "nbatag_")) {
                        var kv = cookie.split("=");
                        result.push({
                            key: kv[0],
                            value: kv[1]
                        });
                    }
                }
                return result;
            },
            mapUtagCookies: function(mapFunction, onlyUtagMain = false) {
                var cookies = nbatag.loader.getUtagCookies(onlyUtagMain);
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = cookies[i];
                    mapFunction(cookie);
                }
            },
            filterArray: function(array, predicate) {
                var y = 0;
                for (var x = 0; x < array.length; x++) {
                    if (predicate(array[x])) {
                        array[y] = array[x];
                        y++;
                    }
                }
                array.length = y;
            },
            RC: function(a, x, b, c, d, e, f, g, h, i, j, k, l, m, n, o, v, ck, cv, r, s, t) {
                o = {};
                b = ("" + document.cookie != "") ? (document.cookie).split("; ") : [];
                r = /^(.*?)=(.*)$/;
                s = /^(.*);exp-(.*)$/;
                t = (new Date()).getTime();
                var newMultiCookies;
                if (nbatag.loader.hasSplitUtagMainCookie()) {
                    newMultiCookies = nbatag.loader.readIndividualCookies();
                    nbatag.loader.filterArray(b, function(cookie) {
                        return !cookie.startsWith("nbatag_")
                    });
                }
                for (c = 0; c < b.length; c++) {
                    if (b[c].match(r)) {
                        ck = RegExp.$1;
                        cv = RegExp.$2;
                    }
                    e = nbatag.ut.decode(cv);
                    if (typeof ck != "undefined") {
                        if (ck.indexOf("ulog") == 0 || ck.indexOf("nbatag_") == 0) {
                            e = cv.split("$");
                            g = [];
                            j = {};
                            for (f = 0; f < e.length; f++) {
                                try {
                                    g = e[f].split(":");
                                    if (g.length > 2) {
                                        g[1] = g.slice(1).join(":");
                                    }
                                    v = "";
                                    if (("" + g[1]).indexOf("~") == 0) {
                                        h = g[1].substring(1).split("|");
                                        for (i = 0; i < h.length; i++) h[i] = nbatag.ut.decode(h[i]);
                                        v = h
                                    } else v = nbatag.ut.decode(g[1]);
                                    j[g[0]] = v;
                                } catch (er) {
                                    nbatag.DB(er)
                                };
                            }
                            o[ck] = {};
                            for (f in nbatag.loader.GV(j)) {
                                if (nbatag.ut.typeOf(j[f]) == "array") {
                                    n = [];
                                    for (m = 0; m < j[f].length; m++) {
                                        if (j[f][m].match(s)) {
                                            k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                                            if (k > t) n[m] = (x == 0) ? j[f][m] : RegExp.$1;
                                        }
                                    }
                                    j[f] = n.join("|");
                                } else {
                                    j[f] = "" + j[f];
                                    if (j[f].match(s)) {
                                        k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                                        j[f] = (k < t) ? null : (x == 0 ? j[f] : RegExp.$1);
                                    }
                                }
                                if (j[f]) o[ck][f] = j[f];
                            }
                        } else if (nbatag.cl[ck] || nbatag.cl['_all_']) {
                            o[ck] = e
                        }
                    }
                }
                if (newMultiCookies) {
                    Object.keys(newMultiCookies).forEach(function(tag) {
                        o[tag] = {};
                        Object.keys(newMultiCookies[tag]).forEach(function(key) {
                            o[tag][key] = newMultiCookies[tag][key].split(';exp-')[0]
                        })
                    });
                }
                return (a) ? (o[a] ? o[a] : {}) : o;
            },
            SC: function(a, b, c, d, e, f, g, h, i, j, k, x, v) {
                if (!a) return 0;
                if (a == "nbatag_main" && nbatag.cfg.nocookie) return 0;
                v = "";
                var date = new Date();
                var exp = new Date();
                var data;
                exp.setTime(date.getTime() + (365 * 24 * 60 * 60 * 1000));
                x = exp.toGMTString();
                if (c && c === "da" || (nbatag.cfg.split_cookie && c === 'd')) {
                    x = "Thu, 31 Dec 2009 00:00:00 GMT";
                    data = nbatag.loader.GV(b);
                } else if (a.indexOf("nbatag_") != 0 && a.indexOf("ulog") != 0) {
                    if (typeof b != "object") {
                        v = b
                    }
                } else {
                    if (nbatag.cfg.split_cookie) {
                        d = nbatag.loader.readIndividualCookies()[a] || {};
                        data = nbatag.loader.GV(b);
                    } else {
                        d = nbatag.loader.RC(a, 0);
                    }
                    for (e in nbatag.loader.GV(b)) {
                        f = "" + b[e];
                        if (f.match(/^(.*);exp-(\d+)(\w)$/)) {
                            g = date.getTime() + parseInt(RegExp.$2) * ((RegExp.$3 == "h") ? 3600000 : 86400000);
                            if (RegExp.$3 == "u") g = parseInt(RegExp.$2);
                            f = RegExp.$1 + ";exp-" + g;
                        }
                        if (c == "i") {
                            if (d[e] == null) d[e] = f;
                        } else if (c == "d") delete d[e];
                        else if (c == "a") d[e] = (d[e] != null) ? (f - 0) + (d[e] - 0) : f;
                        else if (c == "ap" || c == "au") {
                            if (d[e] == null) d[e] = f;
                            else {
                                if (d[e].indexOf("|") > 0) {
                                    d[e] = d[e].split("|")
                                }
                                g = (nbatag.ut.typeOf(d[e]) == "array") ? d[e] : [d[e]];
                                g.push(f);
                                if (c == "au") {
                                    h = {};
                                    k = {};
                                    for (i = 0; i < g.length; i++) {
                                        if (g[i].match(/^(.*);exp-(.*)$/)) {
                                            j = RegExp.$1;
                                        }
                                        if (typeof k[j] == "undefined") {
                                            k[j] = 1;
                                            h[g[i]] = 1;
                                        }
                                    }
                                    g = [];
                                    for (i in nbatag.loader.GV(h)) {
                                        g.push(i);
                                    }
                                }
                                d[e] = g
                            }
                        } else d[e] = f;
                    }
                    if (nbatag.loader.convertingToSplitCookies() === true) {
                        delete d[a];
                    }
                    data = nbatag.loader.GV(d);
                    h = new Array();
                    for (g in data) {
                        if (nbatag.ut.typeOf(d[g]) == "array") {
                            for (c = 0; c < d[g].length; c++) {
                                d[g][c] = encodeURIComponent(d[g][c])
                            }
                            h.push(g + ":~" + d[g].join("|"))
                        } else h.push((g + ":").replace(/[\,\$\;\?]/g, "") + encodeURIComponent(d[g]))
                    }
                    if (h.length == 0) {
                        h.push("");
                        x = ""
                    }
                    v = (h.join("$"));
                }
                if (nbatag.cfg.split_cookie && c !== 'da' && c !== 'd') {
                    nbatag.loader.prepareAndWriteCookies(a, data, x);
                } else if (nbatag.cfg.split_cookie) {
                    nbatag.loader.mapUtagCookies(function(cookieInfo) {
                        var cookiesToDelete = Object.keys(data || {}).map(function(key) {
                            return a + '_' + key
                        });
                        if ((c === 'da' && cookieInfo.key.startsWith(a)) || (c === 'd' && cookiesToDelete.indexOf(cookieInfo.key) !== -1)) {
                            document.cookie = cookieInfo.key + "=" + v + ";path=/;domain=" + nbatag.cfg.domain + ";expires=" + x + (nbatag.cfg.secure_cookie ? ";secure" : "");
                        }
                    })
                } else {
                    document.cookie = a + "=" + v + ";path=/;domain=" + nbatag.cfg.domain + ";expires=" + x + (nbatag.cfg.secure_cookie ? ";secure" : "");
                }
                return 1
            },
            prepareAndWriteCookies: function(tag, data, expiration) {
                var defaultSessionExpirationCookies = ["_pn", "_ss", "_st", "_ses_id", "_se"];
                var originalExpiration = expiration;
                if (Object.keys(data).length > 0) {
                    for (var key in data) {
                        expiration = originalExpiration;
                        if (!nbatag.loader.cookieIsAllowed(key)) {
                            continue;
                        }
                        var value = String(data[key]);
                        if (defaultSessionExpirationCookies.includes(key)) {
                            value = nbatag.loader.addExpSessionFlag(value);
                        }
                        if (value.match(/exp-(\d+|session)$/)) {
                            var expValue = RegExp.$1;
                            if (expValue === "session" && !!nbatag.cfg.session_timeout) {
                                value = nbatag.loader.addExpSessionFlag(value);
                                expiration = new Date();
                                expiration.setTime(expiration.getTime() + parseInt(nbatag.cfg.session_timeout));
                                expiration = expiration.toGMTString();
                            } else {
                                var expInt = parseInt(expValue);
                                if (!!expInt) {
                                    value = nbatag.loader.addExpFlag(value, expInt);
                                    expiration = new Date(expInt);
                                    expiration = expiration.toGMTString();
                                }
                            }
                        }
                        nbatag.loader.writeCookie(tag + "_" + key, value, expiration);
                    }
                    nbatag.loader.deleteCookie(tag);
                }
            },
            writeCookie: function(key, value, expiration) {
                if (value.includes(";")) {
                    value = value.replace(/;/g, encodeURIComponent(";"));
                }
                document.cookie = key + "=" + value + ";path=/;domain=" + nbatag.cfg.domain + ";expires=" + expiration + (nbatag.cfg.secure_cookie ? ";secure" : "");
            },
            LOAD: function(a, b, c, d) {
                if (!nbatag.loader.cfg) {
                    return
                }
                if (this.ol == 0) {
                    if (nbatag.loader.cfg[a].block && nbatag.loader.cfg[a].cbf) {
                        this.f[a] = 1;
                        delete nbatag.loader.bq[a];
                    }
                    for (b in nbatag.loader.GV(nbatag.loader.bq)) {
                        if (nbatag.loader.cfg[a].load == 4 && nbatag.loader.cfg[a].wait == 0) {
                            nbatag.loader.bk[a] = 1;
                            nbatag.DB("blocked: " + a);
                        }
                        nbatag.DB("blocking: " + b);
                        return;
                    }
                    nbatag.loader.INIT();
                    return;
                }
                nbatag.DB('nbatag.loader.LOAD:' + a);
                if (this.f[a] == 0) {
                    this.f[a] = 1;
                    if (nbatag.cfg.noview != true) {
                        if (nbatag.loader.cfg[a].send) {
                            nbatag.DB("SENDING: " + a);
                            try {
                                if (nbatag.loader.sendq.pending > 0 && nbatag.loader.sendq[a]) {
                                    nbatag.DB("nbatag.loader.LOAD:sendq: " + a);
                                    while (d = nbatag.loader.sendq[a].shift()) {
                                        nbatag.DB(d);
                                        nbatag.sender[a].send(d.event, nbatag.handler.C(d.data));
                                        nbatag.loader.sendq.pending--;
                                    }
                                } else {
                                    nbatag.sender[a].send('view', nbatag.handler.C(nbatag.data));
                                }
                                nbatag.rpt['s_' + a] = 0;
                            } catch (e) {
                                nbatag.DB(e);
                                nbatag.rpt['s_' + a] = 1;
                            }
                        }
                    }
                    if (nbatag.loader.rf == 0) return;
                    for (b in nbatag.loader.GV(this.f)) {
                        if (this.f[b] == 0 || this.f[b] == 2) return
                    }
                    nbatag.loader.END();
                }
            },
            EV: function(a, b, c, d) {
                if (b == "ready") {
                    if (!nbatag.data) {
                        try {
                            nbatag.cl = {
                                '_all_': 1
                            };
                            nbatag.loader.initdata();
                            nbatag.loader.RD(nbatag.data);
                        } catch (e) {
                            nbatag.DB(e)
                        };
                    }
                    if ((document.attachEvent || nbatag.cfg.dom_complete) ? document.readyState === "complete" : document.readyState !== "loading") setTimeout(c, 1);
                    else {
                        nbatag.loader.ready_q.push(c);
                        var RH;
                        if (nbatag.loader.ready_q.length <= 1) {
                            if (document.addEventListener) {
                                RH = function() {
                                    document.removeEventListener("DOMContentLoaded", RH, false);
                                    nbatag.loader.run_ready_q()
                                };
                                if (!nbatag.cfg.dom_complete) document.addEventListener("DOMContentLoaded", RH, false);
                                window.addEventListener("load", nbatag.loader.run_ready_q, false);
                            } else if (document.attachEvent) {
                                RH = function() {
                                    if (document.readyState === "complete") {
                                        document.detachEvent("onreadystatechange", RH);
                                        nbatag.loader.run_ready_q()
                                    }
                                };
                                document.attachEvent("onreadystatechange", RH);
                                window.attachEvent("onload", nbatag.loader.run_ready_q);
                            }
                        }
                    }
                } else {
                    if (a.addEventListener) {
                        a.addEventListener(b, c, false)
                    } else if (a.attachEvent) {
                        a.attachEvent(((d == 1) ? "" : "on") + b, c)
                    }
                }
            },
            END: function(b, c, d, e, v, w) {
                if (this.ended) {
                    return
                };
                this.ended = 1;
                nbatag.DB("loader.END");
                b = nbatag.data;
                if (nbatag.handler.base && nbatag.handler.base != '*') {
                    e = nbatag.handler.base.split(",");
                    for (d = 0; d < e.length; d++) {
                        if (typeof b[e[d]] != "undefined") nbatag.handler.df[e[d]] = b[e[d]]
                    }
                } else if (nbatag.handler.base == '*') {
                    nbatag.ut.merge(nbatag.handler.df, b, 1);
                }
                nbatag.rpt['r_0'] = "t";
                for (var r in nbatag.loader.GV(nbatag.cond)) {
                    nbatag.rpt['r_' + r] = (nbatag.cond[r]) ? "t" : "f";
                }
                nbatag.rpt.ts['s'] = new Date();
                v = nbatag.cfg.path;
                w = v.indexOf("tags.nba.com");
                if (w > 0 && b["cp.nbatag_main__ss"] == 1 && !nbatag.cfg.no_session_count) nbatag.ut.loader({
                    src: "https://tags.tiqcdn.com/utag/tiqapp/ut" + "ag.v.js?a=" + nbatag.cfg.utid + (nbatag.cfg.nocookie ? "&nocookie=1" : "&cb=" + (new Date).getTime()),
                    id: "tiqapp"
                })
                if (nbatag.cfg.noview != true) nbatag.handler.RE('view', b, "end");
                nbatag.handler.INIT();
            }
        },
        DB: function(a, b) {
            if (nbatag.cfg.nbatagdb === false) {
                return;
            } else if (typeof nbatag.cfg.nbatagdb == "undefined") {
                b = document.cookie + '';
                nbatag.cfg.nbatagdb = ((b.indexOf('nbatagdb=true') >= 0) ? true : false);
            }
            if (nbatag.cfg.nbatagdb === true) {
                var t;
                if (nbatag.ut.typeOf(a) == "object") {
                    t = nbatag.handler.C(a)
                } else {
                    t = a
                }
                nbatag.db_log.push(t);
                try {
                    if (!nbatag.cfg.noconsole) console.log(t)
                } catch (e) {}
            }
        },
        RP: function(a, b, c) {
            if (typeof a != 'undefined' && typeof a.src != 'undefined' && a.src != '') {
                b = [];
                for (c in nbatag.loader.GV(a)) {
                    if (c != 'src') b.push(c + '=' + escape(a[c]))
                }
                this.dbi.push((new Image()).src = a.src + '?utv=' + nbatag.cfg.v + '&utid=' + nbatag.cfg.utid + '&' + (b.join('&')))
            }
        },
        view: function(a, c, d) {
            return this.track({
                event: 'view',
                data: a || {},
                cfg: {
                    cb: c,
                    uids: d
                }
            })
        },
        link: function(a, c, d) {
            return this.track({
                event: 'link',
                data: a || {},
                cfg: {
                    cb: c,
                    uids: d
                }
            })
        },
        track: function(a, b, c, d, e) {
            a = a || {};
            if (typeof a == "string") {
                a = {
                    event: a,
                    data: b || {},
                    cfg: {
                        cb: c,
                        uids: d
                    }
                }
            }
            for (e in nbatag.loader.GV(nbatag.o)) {
                nbatag.o[e].handler.trigger(a.event || "view", a.data || a, a.cfg || {
                    cb: b,
                    uids: c
                })
            }
            a.cfg = a.cfg || {
                cb: b
            };
            if (typeof a.cfg.cb == "function") a.cfg.cb();
            return true
        },
        handler: {
            base: "",
            df: {},
            o: {},
            send: {},
            iflag: 0,
            INIT: function(a, b, c) {
                nbatag.DB('nbatag.handler.INIT');
                if (nbatag.initcatch) {
                    nbatag.initcatch = 0;
                    return
                }
                this.iflag = 1;
                a = nbatag.loader.q.length;
                if (a > 0) {
                    nbatag.DB("Loader queue");
                    for (b = 0; b < a; b++) {
                        c = nbatag.loader.q[b];
                        nbatag.handler.trigger(c.a, c.b, c.c)
                    }
                }
            },
            test: function() {
                return 1
            },
            LR: function(b) {
                nbatag.DB("Load Rules");
                for (var d in nbatag.loader.GV(nbatag.cond)) {
                    nbatag.cond[d] = false;
                }
                nbatag.DB(b);
                nbatag.loader.loadrules(b);
                nbatag.DB(nbatag.cond);
                nbatag.loader.initcfg();
                nbatag.loader.OU();
                for (var r in nbatag.loader.GV(nbatag.cond)) {
                    nbatag.rpt['r_' + r] = (nbatag.cond[r]) ? "t" : "f";
                }
            },
            RE: function(a, b, c, d, e, f, g) {
                if (c != "alr" && !this.cfg_extend) {
                    return 0;
                }
                nbatag.DB("RE: " + c);
                if (c == "alr") nbatag.DB("All Tags EXTENSIONS");
                nbatag.DB(b);
                if (typeof this.extend != "undefined") {
                    g = 0;
                    for (d = 0; d < this.extend.length; d++) {
                        try {
                            e = 0;
                            if (typeof this.cfg_extend != "undefined") {
                                f = this.cfg_extend[d];
                                if (typeof f.count == "undefined") f.count = 0;
                                if (f[a] == 0 || (f.once == 1 && f.count > 0) || f[c] == 0) {
                                    e = 1
                                } else {
                                    if (f[c] == 1) {
                                        g = 1
                                    };
                                    f.count++
                                }
                            }
                            if (e != 1) {
                                this.extend[d](a, b);
                                nbatag.rpt['ex_' + d] = 0
                            }
                        } catch (er) {
                            nbatag.DB(er);
                            nbatag.rpt['ex_' + d] = 1;
                            nbatag.ut.error({
                                e: er.message,
                                s: nbatag.cfg.path + 'nbatag.js',
                                l: d,
                                t: 'ge'
                            });
                        }
                    }
                    nbatag.DB(b);
                    return g;
                }
            },
            trigger: function(a, b, c, d, e, f) {
                nbatag.DB('trigger:' + a + (c && c.uids ? ":" + c.uids.join(",") : ""));
                b = b || {};
                nbatag.DB(b);
                if (!this.iflag) {
                    nbatag.DB("trigger:called before tags loaded");
                    for (d in nbatag.loader.f) {
                        if (!(nbatag.loader.f[d] === 1)) nbatag.DB('Tag ' + d + ' did not LOAD')
                    }
                    nbatag.loader.q.push({
                        a: a,
                        b: nbatag.handler.C(b),
                        c: c
                    });
                    return;
                }
                nbatag.ut.merge(b, this.df, 0);
                nbatag.loader.RD(b, a);
                nbatag.cfg.noview = false;

                function sendTag(a, b, d) {
                    try {
                        if (typeof nbatag.sender[d] != "undefined") {
                            nbatag.DB("SENDING: " + d);
                            nbatag.sender[d].send(a, nbatag.handler.C(b));
                            nbatag.rpt['s_' + d] = 0;
                        } else if (nbatag.loader.cfg[d].load != 2) {
                            nbatag.loader.sendq[d] = nbatag.loader.sendq[d] || [];
                            nbatag.loader.sendq[d].push({
                                "event": a,
                                "data": nbatag.handler.C(b)
                            });
                            nbatag.loader.sendq.pending++;
                            nbatag.loader.AS({
                                id: d,
                                load: 1
                            });
                        }
                    } catch (e) {
                        nbatag.DB(e)
                    }
                }
                if (c && c.uids) {
                    this.RE(a, b, "alr");
                    for (f = 0; f < c.uids.length; f++) {
                        d = c.uids[f];
                        if (!nbatag.loader.OU(nbatag.loader.cfg[d].tid)) {
                            sendTag(a, b, d);
                        }
                    }
                } else if (nbatag.cfg.load_rules_ajax) {
                    this.RE(a, b, "blr");
                    this.LR(b);
                    this.RE(a, b, "alr");
                    for (f = 0; f < nbatag.loader.cfgsort.length; f++) {
                        d = nbatag.loader.cfgsort[f];
                        if (nbatag.loader.cfg[d].load && nbatag.loader.cfg[d].send) {
                            sendTag(a, b, d);
                        }
                    }
                } else {
                    this.RE(a, b, "alr");
                    for (d in nbatag.loader.GV(nbatag.sender)) {
                        sendTag(a, b, d);
                    }
                }
                this.RE(a, b, "end");
            },
            C: function(a, b, c) {
                b = {};
                for (c in nbatag.loader.GV(a)) {
                    if (nbatag.ut.typeOf(a[c]) == "array") {
                        b[c] = a[c].slice(0)
                    } else {
                        b[c] = a[c]
                    }
                }
                return b
            }
        },
        ut: {
            pad: function(a, b, c, d) {
                a = "" + ((a - 0).toString(16));
                d = '';
                if (b > a.length) {
                    for (c = 0; c < (b - a.length); c++) {
                        d += '0'
                    }
                }
                return "" + d + a
            },
            vi: function(t, a, b) {
                if (!nbatag.v_id) {
                    a = this.pad(t, 12);
                    b = "" + Math.random();
                    a += this.pad(b.substring(2, b.length), 16);
                    try {
                        a += this.pad((navigator.plugins.length ? navigator.plugins.length : 0), 2);
                        a += this.pad(navigator.userAgent.length, 3);
                        a += this.pad(document.URL.length, 4);
                        a += this.pad(navigator.appVersion.length, 3);
                        a += this.pad(screen.width + screen.height + parseInt((screen.colorDepth) ? screen.colorDepth : screen.pixelDepth), 5)
                    } catch (e) {
                        nbatag.DB(e);
                        a += "12345"
                    };
                    nbatag.v_id = a;
                }
                return nbatag.v_id
            },
            hasOwn: function(o, a) {
                return o != null && Object.prototype.hasOwnProperty.call(o, a)
            },
            isEmptyObject: function(o, a) {
                for (a in o) {
                    if (nbatag.ut.hasOwn(o, a)) return false
                }
                return true
            },
            isEmpty: function(o) {
                var t = nbatag.ut.typeOf(o);
                if (t == "number") {
                    return isNaN(o)
                } else if (t == "boolean") {
                    return false
                } else if (t == "string") {
                    return o.length === 0
                } else return nbatag.ut.isEmptyObject(o)
            },
            typeOf: function(e) {
                return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
            },
            flatten: function(o) {
                var a = {};

                function r(c, p) {
                    if (Object(c) !== c || nbatag.ut.typeOf(c) == "array") {
                        a[p] = c;
                    } else {
                        if (nbatag.ut.isEmptyObject(c)) {} else {
                            for (var d in c) {
                                r(c[d], p ? p + "." + d : d);
                            }
                        }
                    }
                }
                r(o, "");
                return a;
            },
            merge: function(a, b, c, d) {
                if (c) {
                    for (d in nbatag.loader.GV(b)) {
                        a[d] = b[d]
                    }
                } else {
                    for (d in nbatag.loader.GV(b)) {
                        if (typeof a[d] == "undefined") a[d] = b[d]
                    }
                }
            },
            decode: function(a, b) {
                b = "";
                try {
                    b = decodeURIComponent(a)
                } catch (e) {
                    nbatag.DB(e)
                };
                if (b == "") {
                    b = unescape(a)
                };
                return b
            },
            encode: function(a, b) {
                b = "";
                try {
                    b = encodeURIComponent(a)
                } catch (e) {
                    nbatag.DB(e)
                };
                if (b == "") {
                    b = escape(a)
                };
                return b
            },
            error: function(a, b, c) {
                if (typeof nbatag_err != "undefined") {
                    nbatag_err.push(a)
                }
            },
            loader: function(o, a, b, c, l, m) {
                nbatag.DB(o);
                a = document;
                if (o.type == "iframe") {
                    m = a.getElementById(o.id);
                    if (m && m.tagName == "IFRAME") {
                        m.parentNode.removeChild(m);
                    }
                    b = a.createElement("iframe");
                    o.attrs = o.attrs || {};
                    nbatag.ut.merge(o.attrs, {
                        "height": "1",
                        "width": "1",
                        "style": "display:none"
                    }, 0);
                } else if (o.type == "img") {
                    nbatag.DB("Attach img: " + o.src);
                    b = new Image();
                } else {
                    b = a.createElement("script");
                    b.language = "javascript";
                    b.type = "text/javascript";
                    b.async = 1;
                    b.charset = "utf-8";
                }
                if (o.id) {
                    b.id = o.id
                };
                for (l in nbatag.loader.GV(o.attrs)) {
                    b.setAttribute(l, o.attrs[l])
                }
                b.setAttribute("src", o.src);
                if (typeof o.cb == "function") {
                    if (b.addEventListener) {
                        b.addEventListener("load", function() {
                            o.cb()
                        }, false);
                    } else {
                        b.onreadystatechange = function() {
                            if (this.readyState == 'complete' || this.readyState == 'loaded') {
                                this.onreadystatechange = null;
                                o.cb()
                            }
                        };
                    }
                }
                if (typeof o.error == "function") {
                    nbatag.loader.EV(b, "error", o.error);
                }
                if (o.type != "img") {
                    l = o.loc || "head";
                    c = a.getElementsByTagName(l)[0];
                    if (c) {
                        nbatag.DB("Attach to " + l + ": " + o.src);
                        if (l == "script") {
                            c.parentNode.insertBefore(b, c);
                        } else {
                            c.appendChild(b)
                        }
                    }
                }
            }
        }
    };
    nbatag.o['nba.nba-web'] = nbatag;
    nbatag.cfg = {
        template: "ut4.51.",
        load_rules_ajax: true,
        load_rules_at_wait: false,
        lowerqp: false,
        noconsole: false,
        session_timeout: 1800000,
        readywait: 0,
        noload: 0,
        domain: nbatag.loader.lh(),
        datasource: "##UTDATASOURCE##".replace("##" + "UTDATASOURCE##", ""),
        secure_cookie: ("##UTSECURECOOKIE##".replace("##" + "UTSECURECOOKIE##", "") === "true") ? true : false,
        path: "//tags.nba.com/nba-web/prod/",
        utid: "nba/nba-web/202602061808",
        ignoreSessionStorage: false,
        ignoreLocalStorage: false,
        split_cookie: true
    };
    nbatag.cfg.v = nbatag.cfg.template + "202602061808";
    nbatag.cond = {
        28: 0,
        29: 0,
        33: 0,
        57: 0,
        58: 0
    };
    nbatag.pagevars = function(ud) {
        ud = ud || nbatag.data;
        try {
            ud['js_page.window.useBrowserSdk'] = window.useBrowserSdk
        } catch (e) {
            nbatag.DB(e)
        };
        try {
            ud['js_page.window.disableAmplitude'] = window.disableAmplitude
        } catch (e) {
            nbatag.DB(e)
        };
        try {
            ud['js_page.window.disableBraze'] = window.disableBraze
        } catch (e) {
            nbatag.DB(e)
        };
        try {
            ud['js_page.window.disableKochava'] = window.disableKochava
        } catch (e) {
            nbatag.DB(e)
        };
        try {
            ud['js_page.window.DataLayerHelper'] = window.DataLayerHelper
        } catch (e) {
            nbatag.DB(e)
        };
    };
    nbatag.loader.initdata = function() {
        try {
            nbatag.data = (typeof nbatag_data != 'undefined') ? nbatag_data : {};
            nbatag.udoname = 'nbatag_data';
        } catch (e) {
            nbatag.data = {};
            nbatag.DB('idf:' + e);
        }
    };
    nbatag.loader.loadrules = function(_pd, _pc) {
        var d = _pd || nbatag.data;
        var c = _pc || nbatag.cond;
        for (var l in nbatag.loader.GV(c)) {
            switch (l) {
                case '28':
                    try {
                        c[28] |= (d['js_page.window.disableBraze'].toString().toLowerCase() == 'false'.toLowerCase())
                    } catch (e) {
                        nbatag.DB(e)
                    };
                    break;
                case '29':
                    try {
                        c[29] |= (d['js_page.window.disableKochava'].toString().toLowerCase() == 'false'.toLowerCase())
                    } catch (e) {
                        nbatag.DB(e)
                    };
                    break;
                case '33':
                    try {
                        c[33] |= (d['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase())
                    } catch (e) {
                        nbatag.DB(e)
                    };
                    break;
                case '57':
                    try {
                        c[57] |= (d['js_page.window.useBrowserSdk'].toString().toLowerCase() == 'true'.toLowerCase())
                    } catch (e) {
                        nbatag.DB(e)
                    };
                    break;
                case '58':
                    try {
                        c[58] |= (d['js_page.window.useBrowserSdk'].toString().toLowerCase() == 'false'.toLowerCase())
                    } catch (e) {
                        nbatag.DB(e)
                    };
                    break;
            }
        }
    };
    nbatag.pre = function() {
        nbatag.loader.initdata();
        nbatag.pagevars();
        try {
            nbatag.loader.RD(nbatag.data)
        } catch (e) {
            nbatag.DB(e)
        };
        nbatag.loader.loadrules();
    };
    nbatag.loader.GET = function() {
        nbatag.cl = {
            '_all_': 1
        };
        nbatag.pre();
        nbatag.handler.extend = [function(a, b) {
            try {
                if (1) {
                    if ((b["ut.profile"] == "nba-web") || (b["ut.profile"] == "nba-web-payment") || (b["ut.profile"] == "teamsites") || (b["ut.profile"] == "nba-membership") || (b["ut.profile"] == "nba-subdomain") || (b["ut.profile"] == "nba-play") || (b["ut.profile"] == "all-star-vote") || (b["ut.profile"] == "nba-fantasy") || (b["ut.profile"] == "nba-chat") || (b["ut.profile"] == "wnba-web") || (b["ut.profile"] == "wnba-teams") || (b["ut.profile"] == "wnba-leaguepass"))
                        window.useBrowserSdk = "true";
                    else
                        window.useBrowserSdk = "false";
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b, c, d, e, f, g) {
            if (1) {
                d = b['ut.env'];
                if (typeof d == 'undefined') return;
                c = [{
                    'dev': 'f83b3aea26d8b72d906b999e68cd1802;5e38fbcc-3043-478f-a665-e1b5b2129bc0;konba-web-dev-9r9ul;client-L1yoUlbO2edJVfT7ZD9I6DQXUytxTFhi;NBA (QA);-207e-4f89-a30a-5f407383a619;konba-web-dev-9r9ul;client-L1yoUlbO2edJVfT7ZD9I6DQXUytxTFhi;'
                }, {
                    'qa': 'f83b3aea26d8b72d906b999e68cd1802;5e38fbcc-3043-478f-a665-e1b5b2129bc0;konba-web-dev-9r9ul;client-L1yoUlbO2edJVfT7ZD9I6DQXUytxTFhi;NBA (QA);'
                }, {
                    'prod': '2442d507549e560dd0b73ea4f8d990e1;cf150dab-3153-49b0-b48c-66a7c18688ea;konba-web-djk3e;client-ZaYjRa4r5iGA8CUfvRPhKZDWAz9f7UQI;NBA (Production);'
                }, {
                    'devb': 'f83b3aea26d8b72d906b999e68cd1802;5e38fbcc-3043-478f-a665-e1b5b2129bc0;konba-web-dev-9r9ul;client-L1yoUlbO2edJVfT7ZD9I6DQXUytxTFhi;NBA (QA);'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in nbatag.loader.GV(c[e])) {
                        if (d == f) {
                            b['analytics_ids'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
                if (!m) b['analytics_ids'] = '2442d507549e560dd0b73ea4f8d990e1;cf150dab-3153-49b0-b48c-66a7c18688ea;konba-web-djk3e;client-ZaYjRa4r5iGA8CUfvRPhKZDWAz9f7UQI;';
            }
        }, function(a, b) {
            try {
                if ((typeof b['analytics_ids'] != 'undefined' && typeof b['analytics_ids'] != 'undefined' && b['analytics_ids'] != '')) {
                    try {
                        b['amplitude_api_key'] = b.analytics_ids.split(";")[0]
                    } catch (e) {};
                    try {
                        b['braze_id'] = b.analytics_ids.split(";")[1]
                    } catch (e) {};
                    try {
                        b['kochava_id'] = b.analytics_ids.split(";")[2]
                    } catch (e) {};
                    try {
                        b['amplitude_experiment_key'] = b.analytics_ids.split(";")[3]
                    } catch (e) {};
                    try {
                        b['amplitude_project'] = b.analytics_ids.split(";")[4]
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if (1) {
                    try {
                        b['boolean_true'] = true
                    } catch (e) {};
                    try {
                        b['boolean_false'] = false
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['ut.env'] != 'undefined' && typeof b['ut.profile'] != 'undefined' && b['ut.profile'].toString().toLowerCase() != 'teamsites'.toLowerCase() && b['ut.profile'].toString().toLowerCase() != 'wnba-teams'.toLowerCase())) {
                    if (b["ut.profile"].indexOf("wnba") == -1) {
                        if (b["ut.env"] == "prod") {
                            b.amplitude_api_key = "2442d507549e560dd0b73ea4f8d990e1";
                            b.amplitude_project = "NBA (Production)";
                        } else {
                            b.amplitude_api_key = "f83b3aea26d8b72d906b999e68cd1802";
                            b.amplitude_project = "NBA (QA)";
                        }
                    } else {
                        if (b["ut.env"] == "prod") {
                            b.amplitude_api_key = "8f4d342632355dbcdd32e490313b5d1d";
                            b.amplitude_project = "WNBA (Production)";
                        } else {
                            b.amplitude_api_key = "f2504fb6bf9e52b43454ed7bc8395c61";
                            b.amplitude_project = "WNBA QA";
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (b['js_page.window.useBrowserSdk'].toString().toLowerCase() == 'false'.toLowerCase()) {
                    try {
                        b['amplitude_saveEvents'] = true
                    } catch (e) {};
                    try {
                        b['amplitude_includeUtm'] = true
                    } catch (e) {};
                    try {
                        b['amplitude_includeReferrer'] = true
                    } catch (e) {};
                    try {
                        b['amplitude_includeGclid'] = true
                    } catch (e) {};
                    try {
                        b['amplitude_includeFbclid'] = true
                    } catch (e) {};
                    try {
                        b['amplitude_deviceIdFromUrlParam'] = true
                    } catch (e) {};
                    try {
                        b['amplitude_unsetParamsReferrerOnNewSession'] = true
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['ut.event'] != 'undefined' && b['ut.event'].toString().toLowerCase() == 'view'.toLowerCase())) {
                    try {
                        var ampPagenameMap = {
                            "nba:onboarding:follow-your-favorite-teams": "Page View: Onboarding Follow Teams",
                            "nba:onboarding:select-your-favorite-team": "Page View: Onboarding Favorite Team",
                            "nba:onboarding:follow-your-favorite-players": "Page View: Onboarding Follow Players",
                            "nba:onboarding:upsell": "Page View: Onboarding Upsell",
                            "nba:identity:sign-in": "Page View: Login",
                            "nba:identity:sign-up": "Page View: Sign Up",
                            "nba:identity:forgot-password": "Page View: Forgot Password",
                            "nba:identity:reset-password": "Page View: Reset Password",
                            "nba:linked-accounts:already-linked": "Linked Accounts: Already Linked",
                            "nba:identity:email-first": "Page View: Email First",
                            "nba:identity:two-factor": "Page View: Two Factor Authentication",
                            "nba:home": "Page View: Home",
                            "nba:games:main": "Page View: Games",
                            "nba:games:game-details:summary": "Page View: Game Details Summary",
                            "nba:games:game-details:game-charts": "Page View: Game Details Game Charts",
                            "nba:games:game-details:play-by-play": "Page View: Game Details Plays",
                            "nba:games:game-details:box-score": "Page View: Game Details Box Score",
                            "nba:watch:featured": "Page View: Watch: Featured",
                            "nba:watch:nba-tv": "Page View: Watch: NBA TV",
                            "nba:watch:league-pass": "Page View: Watch: League Pass",
                            "nba:watch:video-playback": "Page View: Watch: Video Playback",
                            "nba:watch:videos-playlist": "Page View: Watch: Video Playback",
                            "nba:players:player:profile": "Page View: Player Profile",
                            "nba:players:main": "Page View: Players",
                            "nba:players:player:stats": "Page View: Players Player Stats",
                            "nba:players:player:bio": "Page View: Players Player Bio",
                            "nba:players:transactions": "Page View: Players Transactions",
                            "nba:players:player:videos": "Page View: Players Player Videos",
                            "nba:players:player:rotowire": "Page View: Players Player Rotowire",
                            "nba:rendezvous:main": "Page View: Rendezvous",
                            "nba:teams:main": "Page View: Teams",
                            "nba:teams:team:profile": "Page View: Teams Team Profile",
                            "nba:teams:team:stats": "Page View: Teams Team Stats",
                            "nba:teams:team:schedule": "Page View: Teams Team Schedule",
                            "nba:schedule:main": "Page View: Schedule",
                            "nba:news:article": "Page View: Article",
                            "nba:news:main": "Page View: News",
                            "nba:news:collection": "Page View: News Collection",
                            "nba:stats:main": "Page View: Stats",
                            "nba:stats:players": "Page View: Player: Stats Total",
                            "nba:stats:teams": "Page View: Team: Stats Total",
                            "nba:stats": "Page View: Stats",
                            "nba:stats:quick-links": "Page View: Stats Quick-links",
                            "nba:standings:main": "Page View: Standings League",
                            "nba:standings:division": "Page View: Standings Division",
                            "nba:my-account:main": "Page View: My Account",
                            "nba:my-account:follow-teams": "Page View: My Account",
                            "nba:my-account:my-information": "Page View: My Information",
                            "nba:my-account:my-information:password": "Page View: Change Password",
                            "nba:my-account:my-favorite-teams": "Page View: My Favorite Teams",
                            "nba:my-account:my-favorite-players": "Page View: My Favorite Players",
                            "nba:my-account:my-viewing-history": "Page View: My Viewing History",
                            "nba:my-account:follow-players": "Page View: My Account Follow Players",
                            "nba:linked-accounts:confirmation": "Page View: Linked Accounts Confirmation",
                            "nba:linked-accounts:partner-link": "Page View: Partner Link",
                            "nba:linked-accounts:connect-account": "Page View: Linked Accounts: Connect Account",
                            "nba:tentpole-hub:page": "Page View: Tentpole Hub",
                            "nba:tentpole-hub:main": "Page View: Tentpole Hub",
                            "nba:tentpole-hub:videos": "Page View: Tentpole Hub",
                            "nba:tentpole-hub:schedule": "Page View: Tentpole Hub",
                            "nba:tentpole-hub:roster:all-star": "Page View: Tentpole Hub",
                            "nba:tentpole-hub:roster:rising-stars": "Page View: Tentpole Hub",
                            "nba:summer-league:main": "Page View: Tentpole Hub",
                            "nba:summer-league:team-rosters": "Page View: Tentpole Hub",
                            "nba:free-agency:free-agent-tracker": "Page View: Tentpole Hub",
                            "nba:identity:tve-sign-in": "Page View: Partner Login",
                            "nba:identity:opin-sign-in:more-options": "Page View: Partner Login",
                            "nba:purchase-funnel:rsn-storefront": "Page View: RSN Storefront",
                            "nba:membership:main": "Page View: Membership Hub"
                        };
                        var ampPagename = "";
                        var pageNameKey = "";
                        if ((b !== undefined) && (b['page.pageInfo.pageName'] !== undefined)) {
                            pageNameKey = b['page.pageInfo.pageName'];
                            if (pageNameKey.indexOf("stats:help:videostatus") > -1)
                                ampPagename = "Page View: Stats";
                            else
                                ampPagename = ampPagenameMap[pageNameKey];
                        }
                        if ((ampPagename === undefined) || (ampPagename === ""))
                            ampPagename = "Page View: Default";
                        b.tealium_event = ampPagename;
                        b.eventPageName = (pageNameKey !== "") ? pageNameKey : b.tealium_event.replace("Page View: ", "");
                    } catch (err) {
                        nbatag.DB("**********  ERROR  **********");
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b, c, d, e, f, g) {
            if ((typeof b['direct_call_event'] != 'undefined' && typeof b['direct_call_event'] != 'undefined' && b['direct_call_event'] != '' && typeof b['ut.event'] != 'undefined' && b['ut.event'].toString().toLowerCase() == 'link'.toLowerCase())) {
                d = b['direct_call_event'];
                if (typeof d == 'undefined') return;
                c = [{
                    'email_pref_update': 'nba:my-account:my-nba-subscription:email-preferences:cta'
                }, {
                    'game_details_modalView': 'Modal View'
                }, {
                    'watch_details_modalView': 'Modal View'
                }, {
                    'DCR: Game Entitlement Modal Views': 'Modal View'
                }, {
                    'date picker dropdown selection': 'nba:game-tracker:select-date:date'
                }, {
                    'Modal Dismiss': 'Modal Dismiss'
                }, {
                    'Modal View': 'Modal View'
                }, {
                    'Modal View (Watch Party)': 'Modal View'
                }, {
                    'My Account CTA': 'Subscription Management Interaction'
                }, {
                    'My Account Update Success': 'nba:my-account:my-information:update-success'
                }, {
                    'nba_send-password_failure': 'User Account: Forgot Password Error'
                }, {
                    'nba_send-password_success': 'User Account: Forgot Password Success'
                }, {
                    'nba_sign-in_failure': 'User Account: Login Error'
                }, {
                    'nba_update-password_failure': 'User Account: Reset Password Error'
                }, {
                    'nba_update-password_success': 'User Account: Reset Password Success'
                }, {
                    'sign up error': 'User Account: Registration Error'
                }, {
                    'user_profile_modalView': 'Modal View'
                }, {
                    'upsell modal view': 'Modal View'
                }, {
                    'nba_sign-in_success': 'User Account: Login Success'
                }, {
                    'sign out success': 'User Account: Logout Success'
                }, {
                    'sign up success': 'User Account: Registration Success'
                }, {
                    'purchase initiate direct to payment': 'nba:purchase-initiate:direct-to-payment'
                }, {
                    'liveDataComponentPresent': 'Live Data Component'
                }, {
                    'storyteller_story_skip-content': 'Storyteller: Story: Skip Content'
                }, {
                    'storyteller_story_previous-content': 'Storyteller: Story: Previous Content'
                }, {
                    'storyteller_story_story-start': 'Storyteller: Story: Story Start'
                }, {
                    'storyteller_story_skip-story': 'Storyteller: Story: Skip Story'
                }, {
                    'storyteller_story_close': 'Storyteller: Story: Close'
                }, {
                    'storyteller_media_video-start': 'Video Start'
                }, {
                    'storyteller_media_video-complete': 'Video Complete'
                }, {
                    'storyteller_ad_ad-start': 'Storyteller: Ad: Ad Start'
                }, {
                    'storyteller_ad_first-quartile-complete': 'Storyteller: Ad: First Quartile Complete'
                }, {
                    'storyteller_ad_midpoint-complete': 'Storyteller: Ad: Midpoint Complete'
                }, {
                    'storyteller_ad_third-quartile-complete': 'Storyteller: Ad: Third Quartile Complete'
                }, {
                    'storyteller_ad_ad-complete': 'Storyteller: Ad: Ad Complete'
                }, {
                    'video start': 'Video Start'
                }, {
                    'Rendezvous Login Success': 'Rendezvous Login Success'
                }, {
                    'Event Name': 'Event Description'
                }, {
                    'concurrency error modal view': 'Modal View'
                }, {
                    'opin_sign-in_success': 'Partner Account: Login Success'
                }, {
                    'tve_sign-in_success': 'Partner Account: Login Success'
                }, {
                    'Click To Login Page': 'User Account: Begin Login'
                }, {
                    'Click To Packages Page': 'Packages Page Initiate'
                }, {
                    'Link Account Success': 'Add Linked Account: Success'
                }, {
                    'Unlink Account Success': 'Remove Linked Account: Success'
                }, {
                    'Rendezvous Login Error': 'Rendezvous Login Error'
                }, {
                    'how to watch modal': 'Modal View'
                }, {
                    'Link Account Attempt': 'Add Linked Account: Begin'
                }, {
                    'Unlink Account Attempt': 'Remove Linked Account: Submit'
                }, {
                    'user_profile_modalView': 'Modal View'
                }, {
                    'storyteller_ad_action-button-tapped': 'Storyteller: Ad: Action Button Tapped'
                }, {
                    'storyteller_ad_close': 'Storyteller: Ad: Close'
                }, {
                    'storyteller_ad_skip-ad': 'Storyteller: Ad: Skip Ad'
                }, {
                    'storyteller_story_share-attempt': 'Storyteller: Story: Share Attempt'
                }, {
                    'storyteller_story_share-success': 'Storyteller: Story: Share Success'
                }, {
                    'storyteller_story_previous-story': 'Storyteller: Story: Previous Story'
                }, {
                    'storyteller_story_story-complete': 'Storyteller: Story: Story Complete'
                }, {
                    'storyteller_story_swipe-up': 'Storyteller: Story: Swipe Up'
                }, {
                    'storyteller_story_trivia-quiz-question-answered': 'Storyteller: Story: Trivia Quiz Question Answered'
                }, {
                    'storyteller_story_trivia-quiz-completed': 'Storyteller: Story: Trivia Quiz Completed'
                }, {
                    'storyteller_story_voted-poll': 'Storyteller: Story: Voted Poll'
                }, {
                    'partner in-browser messaging': 'In-Browser Messaging'
                }, {
                    'opin_logout_success': 'Partner Account: Logout Success'
                }, {
                    'My Account Team Update Success': 'User Favorite: Set Favorite Team'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in nbatag.loader.GV(c[e])) {
                        if (d == f) {
                            b['tealium_event'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
                if (!m) b['tealium_event'] = 'Interaction Default';
            }
        }, function(a, b) {
            try {
                if ((typeof b['direct_call_event'] != 'undefined' && typeof b['direct_call_event'] != 'undefined' && b['direct_call_event'] != '' && b['tealium_event'].toString().toLowerCase() == 'Interaction Default'.toLowerCase())) {
                    switch (b.direct_call_event) {
                        case 'email signup submit':
                            b.tealium_event = b['page.pageInfo.pageName'] ? b['page.pageInfo.pageName'] + ":email-signup-success" : "email-signup-success";
                            break;
                        case 'My Account Update Error':
                            b.tealium_event = b.id || "";
                            break;
                        case 'My Account Team Update Success':
                            b.tealium_event = b.id || "";
                            b.interactionIdentifier = b.id || "";
                            b.teamId = b.teamID || "";
                            b.team = b.team || "";
                            b.modalName = "nba:purchase-funnel:packages:team-select-modal";
                            break;
                        case 'opin_sign-in_success':
                            b.authentication_type = "OPiN";
                            break;
                        case 'data track attribution':
                            if (b['ss.ampPage']) {
                                b.eventPageName = b['ss.ampPage'].replace("Page View: ", "");
                            }
                            b.pageURL = window.ampPageURL || "";
                            b.tealium_event = b.dataid || b.identifier || "";
                            break;
                        case 'overlay interaction':
                            b.tealium_event = b['overlayDigitalData.interaction.identifier'] || "";
                            break;
                        case 'acquisition_placement':
                            b.tealium_event = "Acquisition Placement";
                            const idArray = (b.analyticsId && typeof b.analyticsId === 'string' ? b.analyticsId.split(";") : []);
                            b.placementType = idArray[0] || "";
                            b.placementGeoLocation = idArray[1] || "";
                            b.copyId = idArray[2] || "";
                            b.interactionContent = idArray[3] || "";
                            break;
                        case 'Link Account Attempt':
                            b.tealium_event = b.identifier || "";
                            break;
                        case 'Unlink Account Attempt':
                            b.tealium_event = b.identifier || "";
                            break;
                        case 'Cancel Deflection Offer CTA':
                            b.tealium_event = b.identifier || "";
                            break;
                        case 'nba_email_first_flow':
                            b.tealium_event = b.reportingEvtName || "";
                            break;
                        case 'pagination selection':
                            b.tealium_event = b.infoID || "pagination selection";
                            break;
                        case 'search results sort':
                            b.tealium_event = b.sortID || b.sortIdentifier || "sort performed";
                            break;
                        case 'sort performed':
                            b.tealium_event = b.sortID || b.sortIdentifier || "sort performed";
                            break;
                        case 'tve_search_failure':
                            b.tealium_event = b.searchType || b.onsiteSearchTerm || "";
                            break;
                        case 'tve_sign-in_failure':
                            b.tealium_event = b.linkName || "tve sign in failure";
                            break;
                        case 'welcomeToTheTeam':
                            b.tealium_event = b.identifier || "";
                            break;
                        case 'video search':
                            b.tealium_event = b.searchIdentifier || "video search";
                            break;
                        case 'video_player_login_cta':
                            b.tealium_event = b.linkName || "";
                            break;
                        default:
                            break;
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b, c, d, e, f, g) {
            if ((typeof b['dataTrackEvent'] != 'undefined' && b['dataTrackEvent'].toString().toLowerCase() == 'true'.toLowerCase() && typeof b['interactionIdentifier'] != 'undefined' && typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'] != '' && typeof b['tealium_event'] != 'undefined' && typeof b['tealium_event'] != 'undefined' && b['tealium_event'] == '') || (typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'favorite_team_click'.toLowerCase() && typeof b['interactionIdentifier'] != 'undefined' && typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'] != '')) {
                d = b['interactionIdentifier'];
                if (typeof d == 'undefined') return;
                c = [{
                    'nba:vote:nba-id:sign-in:cta': 'User Account: Begin Login'
                }, {
                    'nba:vote:nba-id:create-account:cta': 'User Account: Registration Submit'
                }, {
                    'nba:identity:opin-sign-in:more-options:partner:button': 'Partner Account: Begin Login'
                }, {
                    'nba:identity:opin-sign-in:success': 'Partner Account: Login Success'
                }, {
                    'nba:identity:tve-sign-in:provider:icon': 'Partner Account: Begin Login'
                }, {
                    'nba:identity:tve-sign-in:success': 'Partner Account: Login Success'
                }, {
                    'nba:my-account:follow-players:follow:button': 'User Favorite: Add Player'
                }, {
                    'nba:my-account:follow-players:unfollow:button': 'User Favorite: Remove Player'
                }, {
                    'nba:my-account:follow-teams:edit-favorite:button': 'My Account: Edit Favorite Team'
                }, {
                    'nba:onboarding:follow-your-favorite-teams:favorite:logo': 'User Favorite: Follow Team'
                }, {
                    'nba:onboarding:follow-your-favorite-teams:unfavorite:logo': 'User Favorite: Unfollow Team'
                }, {
                    'nba:onboarding:select-your-favorite-team:favorite:logo': 'User Favorite: Set Favorite Team'
                }, {
                    'nba:my-account:follow-teams:follow:card': 'User Favorite: Follow Team'
                }, {
                    'overlay:multiview': 'Overlay: Multiview'
                }, {
                    'overlay:multiview:selection': 'Overlay: Multiview Selection'
                }, {
                    'overlay:multiview:remove-playback': 'Overlay: Multiview Remove Playback'
                }, {
                    'nba:my-account:follow-teams:unfollow:button': 'User Favorite: Unfollow Team'
                }, {
                    'nba:identity:email-first:continue:cta': 'User Account: Email Submit'
                }, {
                    'nba:identity:two-factor:code:submit': 'User Account: Two Factor Submit'
                }, {
                    'nba:identity:resend-code:link': 'User Account: Resend Code'
                }, {
                    'nba:identity:contact-support:link': 'Contact Support'
                }, {
                    'nba:players:player:profile:unfollow:button': 'User Favorite: Remove Player'
                }, {
                    'nba:identity:sign-in:cta': 'User Account: Login Submit'
                }, {
                    'nba:identity:begin-registration:cta': 'User Account: Begin Registration'
                }, {
                    'nba:upsell:opin-sign-in-options:cta': 'Partner Authentication Interaction'
                }, {
                    'nba:tentpole-hub:series:card': 'Tentpole Hub: Series Card'
                }, {
                    'nba:tentpole-hub:bracket:series:card': 'Tentpole Hub: Series Card'
                }, {
                    'nba:tentpole-hub:carousel:card': 'Tentpole Hub: Video Carousel'
                }, {
                    'nba:tentpole-hub:top-story-module:card': 'Tentpole Hub: Editorial Stack'
                }, {
                    'nba:tentpole-hub:featured-module:card': 'Tentpole Hub: Editorial Stack'
                }, {
                    'nba:tentpole-hub:newsstrip:card': 'Tentpole Hub: Editorial Stack'
                }, {
                    'nba:tentpole-hub:collection-cards:card': 'Tentpole Hub: Collections Card'
                }, {
                    'nba:tentpole-hub:quicklink:card': 'Tentpole Hub: Link'
                }, {
                    'nba:tentpole-hub:main:quicklink:card': 'Tentpole Hub: Link'
                }, {
                    'nba:tentpole-hub:banner:cta': 'Tentpole Hub: Banner'
                }, {
                    'nba:tentpole-hub:tab-carousel': 'Tentpole Hub: Tab Carousel'
                }, {
                    'nba:tentpole-hub:controls': 'Tentpole Hub: Controls'
                }, {
                    'nba:tentpole-hub:playlist:card': 'Tentpole Hub: Playlist'
                }, {
                    'nba:tentpole-hub:roster:player:card': 'Tentpole Hub: Player Profile'
                }, {
                    'nba:tentpole-hub:draft-component': 'Tentpole Hub: Draft Component'
                }, {
                    'nba:tentpole-hub:see-more:link': 'Tentpole Hub: More'
                }, {
                    'nba:tentpole-hub:schedule:event:card': 'Tentpole Hub: Event Card'
                }, {
                    'nba:identity:email-first:opin-sign-in:cta': 'User Account: Login Submit'
                }, {
                    'nba:games:game-details:how-to-watch:dismiss': 'Modal Dismiss'
                }, {
                    'nba:games:game-details:how-to-watch:broadcaster:link': 'Game Details: How to Watch: Broadcaster Linkout'
                }, {
                    'nba:tentpole-hub:download:button': 'Tentpole Hub: Download'
                }, {
                    'nba:navigation:logo': 'Navigation Bar Interaction'
                }, {
                    'nba:navigation:link': 'Navigation Bar Interaction'
                }, {
                    'nba:navigation:accordion': 'Navigation Bar Interaction'
                }, {
                    'nba:navigation:sign-in:link': 'User Account: Begin Identity Flow'
                }, {
                    'nba:navigation:sign-out:link': 'User Account: Logout Submit'
                }, {
                    'nba:my-account:main:sign-out:cta': 'User Account: Logout Success'
                }, {
                    'nba:games:main:hide-scores:toggle': 'Hide Scores Toggle'
                }, {
                    'nba:games:main:view-playoffs-series:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:hide-odds:toggle': 'Hide Odds Toggle'
                }, {
                    'nba:games:main:betting-odds:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:open-calendar:button': 'Games: Calendar Open'
                }, {
                    'nba:games:main:select-date:date': 'Game Calendar: Date'
                }, {
                    'nba:games:main:box-score:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:game-details:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:preview:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:tickets:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:game-charts:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:game-details:get-tickets:cta': 'Game Details Summary: Get Tickets'
                }, {
                    'nba:games:game-details:listen:cta': 'Game Details: Secondary CTA'
                }, {
                    'nba:games:game-details:watch-live:cta': 'Game Details: Watch Live'
                }, {
                    'nba:games:game-details:start-from-beginning:cta': 'Game Details: Secondary CTA'
                }, {
                    'nba:games:game-details:watch-full-game:cta': 'Game Details: Watch Full Game'
                }, {
                    'nba:games:game-details:game-recap:cta': 'Game Details: Secondary CTA'
                }, {
                    'nba:games:game-details:condensed-games:cta': 'Game Details: Secondary CTA'
                }, {
                    'nba:games:game-details:sign-in-or-join-to-watch:cta': 'Game Details: Primary CTA'
                }, {
                    'nba:games:game-details:upgrade-to-watch:cta': 'Game Details: Primary CTA'
                }, {
                    'nba:games:game-details:watch-on-the-nba-app:cta': 'Game Details: Watch on App'
                }, {
                    'nba:linked-accounts:partner-link:connect:cta': 'Add Linked Account: Submit'
                }, {
                    'nba:my-account:linked-accounts:remove:button': 'Remove Linked Account: Begin'
                }, {
                    'nba:games:game-details:registration:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:upsell:local-access:login:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:upsell:nba-id:login:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:upsell:linked-accounts:login:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:upsell:linked-accounts:sign-up:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:upsell:nba-id:create-account:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:lp-placement:login:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:identity:opin-sign-in:more-options:partner:link': 'Partner Authentication Interaction'
                }, {
                    'nba:my-account:tve-sign-in:link': 'Partner Authentication Interaction'
                }, {
                    'nba:my-account:tv-provider-faqs:link': 'Partner Authentication Interaction'
                }, {
                    'nba:identity:tve-sign-in:provider:icon': 'Partner Authentication Interaction'
                }, {
                    'nba:tve:watch-now:cta': 'Partner Authentication Interaction'
                }, {
                    'nba:games:main:game:card': 'Games: Game Card'
                }, {
                    'nba:games:subscribe:logo': 'Packages Page Initiate'
                }, {
                    'nba:games:main:view-playoffs-series:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:box-score:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:game-details:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:preview:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:main:tickets:cta': 'Games Main: Card Interactions Selection'
                }, {
                    'nba:games:game-details:resume-watching:cta': 'Game Details: Resume Watching'
                }, {
                    'nba:games:game-details:download:link': 'Download Link'
                }, {
                    'nba:games:game-details:summary:controls': 'Carousel Controls'
                }, {
                    'nba:games:game-details:summary:carousel:card': 'Game Details: Video Carousel'
                }, {
                    'nba:resume-watching:cta': 'Resume Watching'
                }, {
                    'nba:players:player:profile:controls': 'Carousel Controls'
                }, {
                    'nba:players:player:bio:controls': 'Carousel Controls'
                }, {
                    'nba:players:player:controls': 'Carousel Controls'
                }, {
                    'nba:tentpole-hub:videos:video-carousel:controls': 'Carousel Controls'
                }, {
                    'nba:tentpole-hub:main:controls': 'Carousel Controls'
                }, {
                    'nba:tentpole-hub:controls': 'Carousel Controls'
                }, {
                    'nba:games:game-details-summary:controls': 'Carousel Controls'
                }, {
                    'nba:home:controls': 'Carousel Controls'
                }, {
                    'nba:watch:featured:controls': 'Carousel Controls'
                }, {
                    'nba:watch:nba-tv:controls': 'Carousel Controls'
                }, {
                    'nba:identity:nba-sign-in:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:linked-accounts:confirmation:button': 'Linked Accounts Interaction'
                }, {
                    'nba:game-tracker:game-card': 'Game Tracker Interaction'
                }, {
                    'nba:game-tracker:game-matchup:link': 'Game Tracker Interaction'
                }, {
                    'nba:game-tracker:controls': 'Game Tracker Interaction'
                }, {
                    'nba:game-tracker:link': 'Game Tracker Interaction'
                }, {
                    'nba:game-tracker:hide-scores:toggle': 'Hide Scores Toggle'
                }, {
                    'nba:players:player:alert:follow:button': 'User Favorite: Add Player'
                }, {
                    'nba:identity:sign-in:forgot-password:link': 'User Account: Begin Forgot Password'
                }, {
                    'nba:identity:sign-in:begin-registration:link': 'User Account: Begin Registration'
                }, {
                    'video-player:catch-up-with-key-plays': 'Video Player: Catch up with Key Plays'
                }, {
                    'overlay:key-plays': 'Overlay: Key Plays'
                }, {
                    'overlay:key-plays:controls': 'Key Plays: Controls'
                }, {
                    'overlay:key-plays:selection': 'Key Plays: Selection'
                }, {
                    'key-plays:transition-to-live': 'Key Plays: Transition to Live'
                }, {
                    'nba:linked-accounts:confirmation:link': 'Linked Accounts Interaction'
                }, {
                    'nba:game-entitlement-modal:nba-sign-in:cta': 'User Account: Begin Identity Flow'
                }, {
                    'nba:players:player:profile:follow:button': 'User Favorite: Add Player'
                }, {
                    'nba:teams:team:profile:unfollow:button': 'User Favorite: Unfollow Team'
                }, {
                    'nba:teams:team:profile:follow:button': 'User Favorite: Follow Team'
                }, {
                    'nba:my-account:follow-teams:edit-favorite:success': 'User Favorite: Set Favorite Team'
                }, {
                    'nba:players:player:stats:follow:button': 'User Favorite: Add Player'
                }, {
                    'nba:players:player:stats:unfollow:button': 'User Favorite: Remove Player'
                }, {
                    'nba:players:player:videos:follow:button': 'User Favorite: Add Player'
                }, {
                    'nba:players:player:videos:unfollow:button': 'User Favorite: Remove Player'
                }, {
                    'nba:players:player:bio:follow:button': 'User Favorite: Add Player'
                }, {
                    'nba:players:player:bio:unfollow:button': 'User Favorite: Remove Player'
                }, {
                    'nba:identity:forgot-password:privacy-policy:link': 'Legal Link'
                }, {
                    'nba:identity:forgot-password:terms-of-use:link': 'Legal Link'
                }, {
                    'nba:tentpole-hub:select-tab': 'Tentpole Hub: Select Tab'
                }, {
                    'nba:tentpole-hub:dropdown:selection': 'Tentpole Hub: Dropdown'
                }, {
                    'nba:tentpole-hub:link': 'Tentpole Hub: Link'
                }, {
                    'nba:tentpole-hub:videos:select': 'Tentpole Hub: Video Select'
                }, {
                    'nba:identity:sign-up:cta': 'User Account: Registration Submit'
                }];
                var m = false;
                for (e = 0; e < c.length; e++) {
                    for (f in nbatag.loader.GV(c[e])) {
                        if (d == f) {
                            b['tealium_event'] = c[e][f];
                            m = true
                        };
                    };
                    if (m) break
                };
            }
        }, function(a, b) {
            try {
                if ((typeof b['user.userType'] == 'undefined' && typeof b['user.userState'] != 'undefined' && b['user.userState'].toString().toLowerCase() == 'guest'.toLowerCase()) || (typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'User Account: Logout Success'.toLowerCase())) {
                    b['user.userType'] = 'guest'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if (1) {
                    b['isWebview'] = ((location.pathname.indexOf('/webview/') > -1) || b['qp.webview'] === 'true' || b['qp.Hidenav'] === 'true' || b['ss.hidenav'] === true) ? true : false;
                    const keepQS = ["sku", "cid", "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "irclickid", "rtid", "gclid", "fbclid", "webview", "hidenav", "amp_device_id", "deviceType", "adobe_mc"];
                    let pageQS = (typeof b['dom.query_string'] !== 'undefined' && b['dom.query_string']) ? b['dom.query_string']
                        .split("&")
                        .filter(param => keepQS.includes(param.split("=")[0].toLowerCase()))
                        .join("&") : "";
                    b.filtered_query_string = pageQS ? `?${pageQS}` : "";
                    if (typeof b['siteSection'] != "undefined")
                        b.site_section = b['siteSection'];
                    else if ((typeof digitalData == "object") && (typeof digitalData.page == "object") && (typeof digitalData.page.pageInfo == "object") && (typeof digitalData.page.pageInfo.siteSection == "string"))
                        b.site_section = digitalData.page.pageInfo.siteSection;
                    else if ((/\.nba\.com$/.test(window.location.hostname)) && (window.location.hostname.split(".")[0].indexOf("www") < 0))
                        b.site_section = window.location.hostname.replace(/\.nba.com$/, "");
                    else if ((/\.wnba\.com$/.test(window.location.hostname)) && (window.location.hostname.split(".")[0].indexOf("www") < 0))
                        b.site_section = window.location.hostname.replace(/\.wnba.com$/, "");
                    else if ((window.location.hostname.split(".")[0].indexOf("www") < 0))
                        b.site_section = window.location.hostname.replace(".com", "") + "|NoReplace";
                    b.page_url = location.href.split("?")[0].split("#")[0];
                    b.cleaned_url = location.href.split("?")[0].split("#")[0];
                    b.site_partner = b['sitePartner'] ? b['sitePartner'] : b['site.partner'] ? b['site.partner'] : "";
                    if (b.site_partner === "") {
                        if ((typeof digitalData == "object") && (typeof digitalData.site == "object") && (typeof digitalData.site.partner == "string"))
                            b.site_partner = digitalData.site.partner;
                    }
                    if (typeof b['site.league'] != "undefined")
                        b.league = b['site.league'];
                    else if ((typeof digitalData == "object") && (typeof digitalData.site == "object") && (typeof digitalData.site.league == "string"))
                        b.league = digitalData.site.league;
                    else if (/\.nba\.com$/.test(window.location.hostname)) {
                        var e = ["2kleague", "nba2kleague", "nbat2", "76ersgc", "raptorsuprising", "blazer5gaming", "twolvesgaming", "bucksgaming", "warriorsgs", "cavslegion", "wizardsdg", "celticscrossover", "duxinfinitos", "gengtigers", "grizzgaming", "hawkstalon", "heatcheck", "hornetsvenomgt", "jazzgaming", "kingsguard", "knicksgaming", "lakersgaming", "magicgaming", "mavsgaming", "netsgc", "pacersgaming", "pistonsgt"];
                        if ((/^gleague[-.]/.test(window.location.hostname)) || (/gleague\.nba\.com$/.test(window.location.hostname)))
                            b.league = "gleague";
                        else if (/^bal[-.]/.test(window.location.hostname))
                            b.league = "bal";
                        else if (e.includes(window.location.hostname.split(".")[0]))
                            b.league = "nba2k";
                        else
                            b.league = "nba";
                    } else if (/\.wnba\.com$/.test(window.location.hostname))
                        b.league = "wnba";
                    b.league = b.league.replace("nbat2", "nba2k");
                    b.property_name = b['site.propertyName'] ? b['site.propertyName'] : b.league + ":web";
                    if (b.isWebview)
                        b.property_name = b["property_name"].replace("web", "app");
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    let ampSiteSection = "";
                    if (typeof b != "undefined") {
                        if (typeof b['page.pageInfo.siteSection'] != "undefined")
                            ampSiteSection = b['page.pageInfo.siteSection'];
                        else if ((typeof digitalData == "object") && (typeof digitalData.page == "object") && (typeof digitalData.page.pageInfo == "object") && (typeof digitalData.page.pageInfo.siteSection == "string"))
                            ampSiteSection = digitalData.page.pageInfo.siteSection;
                        else if (typeof b.eventSiteSection != "undefined")
                            ampSiteSection = b.eventSiteSection;
                        else if (typeof b.siteSection != "undefined")
                            ampSiteSection = b.siteSection;
                        else if (typeof b.site_section != "undefined")
                            ampSiteSection = b.site_section;
                    }
                    if ((ampSiteSection !== "") && (!(/^custom-[A-Z]{3}$/.test(ampSiteSection))) && (!(/^blank-slate-[A-Z]{3}$/.test(ampSiteSection))) && (!(/\|NoReplace$/.test(ampSiteSection)))) {
                        ampSiteSection = ampSiteSection.replace(/^nba\:|^wnba\:/gi, "").replaceAll("-", " ");
                        ampSiteSection = ampSiteSection.toLowerCase().replace(/^(.)|\s(.)/g, function($1) {
                            return $1.toUpperCase();
                        });
                    }
                    if (/\|NoReplace$/.test(ampSiteSection))
                        ampSiteSection = ampSiteSection.replace("|NoReplace", "");
                    b["ampSiteSection"] = (ampSiteSection !== "") ? ampSiteSection : "Default";
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    window.getCookie = function(name) {
                        var match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
                        return match ? match[2] : "";
                    }
                    if ((b['ss.nbaOrigin'] !== null) && (b['ss.nbaOrigin'] !== undefined) && (b['ss.nbaSectionOrigin'] !== null) && (b['ss.nbaSectionOrigin'] !== undefined)) {
                        b.origin = b['ss.nbaOrigin'];
                        b.sectionOrigin = b['ss.nbaSectionOrigin'];
                    } else if (/\.nba\.com$/.test(location.hostname)) {
                        let decodeVal = "";
                        if (b["cp.nbaOrigin"])
                            decodeVal = b["cp.nbaOrigin"];
                        else if (window.getCookie("nbaOrigin") !== "")
                            decodeVal = decodeURIComponent(window.getCookie("nbaOrigin"));
                        if (decodeVal !== "") {
                            b.origin = decodeVal.split("||")[0];
                            b.sectionOrigin = decodeVal.split("||")[1];
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (b['page.pageInfo.pageName'].toString().indexOf('opin') > -1 || (typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().indexOf('opin') > -1) || b['page.pageInfo.pageName'].toString().indexOf('tve') > -1 || (typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().indexOf('tve') > -1)) {
                    b.partnerAuthType = ((b.interactionIdentifier.toLowerCase().indexOf("opin") > -1) || ((typeof b["page.pageInfo.pageName"] != "undefined") && (b["page.pageInfo.pageName"].toLowerCase().indexOf("opin") > -1))) ? "OPiN" : "TVE";
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    function getQsVal(name) {
                        var re = new RegExp("[?&]" + name + "=([^&]+)");
                        var result = window.location.search.match(re);
                        return result === null ? "" : decodeURIComponent(result[1].replace(/\+/g, " "));
                    }

                    function getAmpDevIdQs() {
                        var qsDeviceId = getQsVal("amp_device_id");
                        if (qsDeviceId === "") {
                            qsDeviceId = getQsVal("ampDeviceId");
                            if (qsDeviceId === "")
                                qsDeviceId = getQsVal("deviceId");
                        }
                        return qsDeviceId;
                    }
                    window.getCookie = function(name) {
                        var match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
                        return match ? match[2] : "";
                    };

                    function isBase64(str) {
                        const base64regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
                        return base64regex.test(str);
                    }

                    function getAmpCookieObj(name) {
                        var encodedValue = (window.getCookie(name)) ? window.getCookie(name) : "";
                        if (encodedValue !== "") {
                            if (isBase64(encodedValue)) {
                                try {
                                    return JSON.parse(decodeURIComponent(atob(encodedValue)));
                                } catch (e) {
                                    return {};
                                }
                            }
                        }
                        return {};
                    }

                    function useCookieOrder(bCookie, jCookie) {
                        var ampCookie = getAmpCookieObj(bCookie);
                        if (Object.keys(ampCookie).length > 0)
                            b.ampDeviceId = (ampCookie.deviceId) ? ampCookie.deviceId : "";
                        else if (window.getCookie(jCookie) !== "")
                            b.ampDeviceId = window.getCookie(jCookie).split(".")[0];
                        else {
                            let ck10 = "AMP_" + b.amplitude_api_key.slice(0, 10);
                            let ck6 = "amp_" + b.amplitude_api_key.slice(0, 6);
                            if (window.getCookie(ck10) !== "") {
                                let ampCookie10 = getAmpCookieObj(ck10);
                                if (Object.keys(ampCookie10).length > 0)
                                    b.ampDeviceId = (ampCookie10.deviceId) ? ampCookie10.deviceId : "";
                            } else if (window.getCookie(ck6) !== "") {
                                let ampCookie6 = window.getCookie(ck6).split(".")[0];
                                b.ampDeviceId = (ampCookie6 !== "") ? ampCookie6 : "";
                            } else {
                                b.ampDeviceId = b.tealium_visitor_id;
                            }
                        }
                    }
                    b.ampDeviceId = getAmpDevIdQs();
                    if (b.ampDeviceId === "") {
                        if (b["ut.env"] == "prod")
                            b.ampDeviceId = window.getCookie("AMP_saved_deviceId");
                        else
                            b.ampDeviceId = window.getCookie("AMP_saved_deviceId_qa");
                        if ((b.ampDeviceId === "") || (b.ampDeviceId == "undefined")) {
                            if (b["ut.profile"].indexOf("wnba") < 0) {
                                if (b["ut.env"] == "prod")
                                    useCookieOrder("AMP_2442d50754", "amp_2442d5");
                                else
                                    useCookieOrder("AMP_f83b3aea26", "amp_f83b3a");
                            } else {
                                if (b["ut.env"] == "prod")
                                    useCookieOrder("AMP_8f4d342632", "amp_8f4d34");
                                else
                                    useCookieOrder("AMP_f2504fb6bf", "amp_f2504f");
                            }
                        }
                    }
                    if ((b.ampDeviceId == "undefined") || (b.ampDeviceId === ""))
                        b.ampDeviceId = b.tealium_visitor_id;
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                nbatag.runonce = nbatag.runonce || {};
                nbatag.runonce.ext = nbatag.runonce.ext || {};
                if (typeof nbatag.runonce.ext[985] == 'undefined') {
                    nbatag.runonce.ext[985] = 1;
                    if (1) {
                        window.pushLastPageLoad = function(eddl) {
                            var triggered = false;
                            var x = eddl.length - 1;
                            while (!triggered && (x >= 0)) {
                                if (eddl[x].eventType == "pageLoad") {
                                    triggered = true;
                                    eddl.push(eddl[x]);
                                }
                                --x;
                            }
                        };
                        window.trackPageLoad = function() {
                            let obj = Object.assign({}, (typeof digitalData === 'object' && digitalData !== null ? digitalData : {}));
                            obj.direct_call_event = "page view";
                            nbatag.view(teal.flattenObject(obj));
                        };
                        window.addEventListener("OneTrustGroupsUpdated", event => {
                            if (window.nbaUserConsent && window.nbaUserConsent_initted) {
                                tConsentChanged = false;
                                if ((typeof tActiveGroups == "undefined") || (tActiveGroups != OnetrustActiveGroups)) {
                                    tActiveGroups = OnetrustActiveGroups;
                                    tConsentChanged = true;
                                }
                                if (tConsentChanged) {
                                    if (OnetrustActiveGroups.includes("NBAmt")) {
                                        if ((b["ut.profile"] == "nba-web") || (b["ut.profile"] == "nba-web-payment") || (b["ut.profile"] == "nba-subdomain")) {
                                            if ((typeof window.checkForPageLoad == "function") && (window.checkForPageLoad.toString().indexOf("nbatag.view") > -1))
                                                window.checkForPageLoad();
                                        } else if ((b["ut.profile"] == "teamsites") || (b["ut.profile"] == "all-star-vote") || (b["ut.profile"] == "wnba-web") || (b["ut.profile"] == "wnba-teams"))
                                            window.pushLastPageLoad(window.appEventData);
                                        else if ((b["ut.profile"] == "nba-play") || (b["ut.profile"] == "nba-fantasy"))
                                            window.pushLastPageLoad(window.playDataLayer);
                                        else if (b["ut.profile"] == "nba-membership")
                                            window.trackPageLoad();
                                        else if (b["ut.profile"] == "wnba-leaguepass") {
                                            if ((typeof window.lastPv == "object") && (window.lastPv !== ""))
                                                window.appEventData.push(window.lastPv);
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (1) {
                    var qs = window.location.search.substring(1);
                    var qsVars = qs.split("&");
                    var utmVars = qsVars.filter(function(qsStr) {
                        if (qsStr.substring(0, 4) === 'utm_') {
                            var eq = qsStr.indexOf("=");
                            if ((eq > -1) && (qsStr.substring(eq + 1).length > 0))
                                return true;
                        }
                    });
                    if (utmVars.length > 0) {
                        for (i = 0; i < utmVars.length; i++) {
                            b["qs_" + utmVars[i].split("=")[0]] = utmVars[i].split("=")[1];
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                nbatag.runonce = nbatag.runonce || {};
                nbatag.runonce.ext = nbatag.runonce.ext || {};
                if (typeof nbatag.runonce.ext[88] == 'undefined') {
                    nbatag.runonce.ext[88] = 1;
                    if (1) {
                        var pageNameObj = {
                                pageName: b['page.pageInfo.pageName'] || "",
                            },
                            pages = {
                                "nba:home": {
                                    "brazeEvent": "viewed_home_web",
                                },
                                "nba:fantasy:main": {
                                    "brazeEvent": "viewed_fantasy_web",
                                },
                                "nba:schedule:main": {
                                    "brazeEvent": "viewed_schedule_web",
                                },
                                "nba:tentpole-hub:schedule": {
                                    "brazeEvent": "viewed_schedule_web",
                                },
                                "nba:league-pass:purchase-funnel:packages": {
                                    "brazeEvent": "viewed_packages_page_web",
                                },
                                "nba:purchase-funnel:packages": {
                                    "brazeEvent": "viewed_packages_page_web",
                                },
                                "nba:stats": {
                                    "brazeEvent": "viewed_stats_web",
                                },
                                "nba:summer-league:main": {
                                    "brazeEvent": "viewed_summer_league_hub_web",
                                },
                                "nba:nbabet:main": {
                                    "brazeEvent": "viewed_nbabet_hub_web",
                                },
                                "nba:standings:main": {
                                    "brazeEvent": "viewed_standings_web",
                                },
                                "nba:news:main": {
                                    "brazeEvent": "viewed_news_web",
                                },
                                "nba:games:main": {
                                    "brazeEvent": "viewed_game_index_web",
                                },
                                "nba:players:player": {
                                    "brazeEvent": "viewed_player_web",
                                    "playerName": b['page.content.playerName'] || "",
                                    "playerId": b['page.content.playerId'] ? b['page.content.playerId'] : b['page.content.playerID'] ? b['page.content.playerID'] : ""
                                },
                                "nba:teams:team": {
                                    "brazeEvent": "viewed_team_web",
                                    "teamName": b['page.content.teamName']
                                },
                                "nba:games:game-details": {
                                    "brazeEvent": "viewed_game_details_web",
                                    "gameID": b['page.content.gameID'],
                                    "matchup": b['page.content.gameMatchup']
                                },
                                "nba:news:article": {
                                    "brazeEvent": "viewed_article_web",
                                    "articleTitle": b['page.content.contentTitle'] || "",
                                    "articleID": b['page.content.contentID'] || ""
                                },
                                "nba:nbabet:article": {
                                    "brazeEvent": "viewed_nbabet_article_web",
                                    "articleTitle": b['page.content.contentTitle'] || "",
                                    "articleID": b['page.content.contentID'] || "",
                                    "contentNetworkProvider": ((window.__NEXT_DATA__) && (window.__NEXT_DATA__.props) && (window.__NEXT_DATA__.props.pageProps) && (window.__NEXT_DATA__.props.pageProps.article) && (window.__NEXT_DATA__.props.pageProps.article.sponsorName)) ? window.__NEXT_DATA__.props.pageProps.article.sponsorName : ""
                                },
                                "nba:draft:board": {
                                    "brazeEvent": "viewed_draft_board_web",
                                },
                                "nba:draft:main": {
                                    "brazeEvent": "viewed_draft_home_web",
                                },
                                "nba:all-star:main": {
                                    "brazeEvent": "viewed_all-star_web",
                                },
                                "nba:league-pass:purchase-funnel:enter-payment-information": {
                                    "brazeEvent": "enter_payment_information_web"
                                },
                            };

                        function getKey(pageName) {
                            if (pages[pageName] !== undefined) {
                                return pageName;
                            } else if (pageName && pageName.startsWith("nba:games:game-details")) {
                                return "nba:games:game-details";
                            } else if (pageName && pageName.startsWith("nba:teams:team")) {
                                return "nba:teams:team";
                            } else if (pageName && pageName.startsWith("nba:players:player")) {
                                return "nba:players:player";
                            } else if (pageName && pageName === "nba:tentpole-hub:main") {
                                if (b['page.content.categoryID'] && b['page.content.categoryID'] === 393640)
                                    return "nba:draft:board";
                                if (b['page.content.categoryID'] && b['page.content.categoryID'] === 52683)
                                    return "nba:draft:main";
                                if (/NBA All-Star$/.test(b['page.content.categoryTitle']))
                                    return "nba:all-star:main";
                            } else {
                                return "";
                            }
                        }
                        if (b['page.pageInfo.pageName']) {
                            var pageKey = pages[getKey(b['page.pageInfo.pageName'])];
                            Object.assign(b, (pageKey && typeof pageKey === 'object' ? pageKey : {}));
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['interactionIdentifier'] != 'undefined' && typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'] != '' && typeof b['tealium_event'] == 'undefined') || (typeof b['interactionIdentifier'] != 'undefined' && typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'] != '' && typeof b['tealium_event'] != 'undefined' && b['tealium_event'] == '')) {
                    b['tealium_event'] = b['interactionIdentifier']
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((b['tealium_event'].toString().indexOf('') > -1 && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Follow Team'.toLowerCase() && b['page.pageInfo.pageName'].toString().toLowerCase().indexOf('nba:teams:team'.toLowerCase()) > -1)) {
                    b['currentlyFollowedTeam'] = b['page.content.teamName'];
                    b['currentlyFollowedTeamID'] = b['page.content.teamId'];
                    b['brazeEvent'] = 'follow_team_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((b['tealium_event'].toString().indexOf('') > -1 && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Follow Team'.toLowerCase() && b['interactionIdentifier'].toString().toLowerCase() == 'nba:my-account:follow-teams:follow:card'.toLowerCase())) {
                    b['currentlyFollowedTeam'] = b['interactionContent'];
                    b['currentlyFollowedTeamID'] = b['interactionContentID'];
                    b['brazeEvent'] = 'follow_team_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Add Player'.toLowerCase() && b['ampSiteSection'].toString().toLowerCase() == 'My Account'.toLowerCase())) {
                    b['currentlyFavoritedPlayer'] = b['interactionContent'];
                    b['currentlyFavoritedPlayerID'] = b['interactionContentID'];
                    b['brazeEvent'] = 'add_favorite_player_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Remove Player'.toLowerCase() && b['ampSiteSection'].toString().toLowerCase() == 'My Account'.toLowerCase())) {
                    b['unfavoritedPlayer'] = b['interactionContent'];
                    b['unfavoritedPlayerID'] = b['interactionContentID'];
                    b['brazeEvent'] = 'unfollow_player_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Unfollow Team'.toLowerCase() && b['page.pageInfo.pageName'].toString().toLowerCase().indexOf('nba:teams:team'.toLowerCase()) > -1)) {
                    b['unfollowedTeam'] = b['page.content.teamName'];
                    b['unfollowedTeamID'] = b['page.content.teamId'];
                    b['brazeEvent'] = 'unfollow_team_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Unfollow Team'.toLowerCase() && b['interactionIdentifier'].toString().toLowerCase().indexOf('nba:my-account:follow-teams:unfollow:button'.toLowerCase()) > -1)) {
                    b['unfollowedTeam'] = b['interactionContent'];
                    b['unfollowedTeamID'] = b['interactionContentID'];
                    b['brazeEvent'] = 'unfollow_team_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Set Favorite Team'.toLowerCase())) {
                    b['favorite_team'] = b['team'];
                    b['favoriteTeamID'] = b['teamID'];
                    b['brazeEvent'] = 'add_favorite_team_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().toLowerCase().indexOf('nba:players:player'.toLowerCase()) > -1 && b['tealium_event'].toString().toLowerCase() == 'User Favorite: Add Player'.toLowerCase())) {
                    b['currentlyFavoritedPlayer'] = b['page.content.playerName'];
                    b['currentlyFavoritedPlayerID'] = b['page.content.playerId']
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().toLowerCase().indexOf('nba:players:player'.toLowerCase()) > -1 && b['tealium_event'].toString().indexOf('User Favorite: Remove Player') > -1)) {
                    b['unfavoritedPlayer'] = b['page.content.playerName'];
                    b['unfavoritedPlayerID'] = b['page.content.playerId']
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().indexOf('hide-scores:toggle') > -1)) {
                    b['brazeEvent'] = 'no_spoilers_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().toLowerCase() == 'nba:navigation:sign-out:link'.toLowerCase())) {
                    b['brazeEvent'] = 'sign_out_web'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if (1) {
                    try {
                        b['tealium_timestamp_locale'] = b.tealium_timestamp_utc ? new Date(b.tealium_timestamp_utc).toLocaleString("en-US") : new Date().toLocaleString("en-US");
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b, c, d) {
            try {
                if ((typeof b['qp.irclickid'] != 'undefined' && typeof b['qp.irclickid'] != 'undefined' && b['qp.irclickid'] != '')) {
                    c = [b['qp.irclickid'], b['tealium_timestamp_locale']];
                    b['impact_click_id'] = c.join('||')
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if (1) {
                    try {
                        b['impact_publisher_split'] = b["qp.utm_source"] ? b["qp.utm_source"].split("-")[0] : ""
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b, c, d) {
            try {
                if ((typeof b['impact_publisher_split'] != 'undefined' && typeof b['qp.utm_source'] != 'undefined' && b['qp.utm_source'] != '' && typeof b['qp.irclickid'] != 'undefined')) {
                    c = [b['impact_publisher_split'], b['tealium_timestamp_locale']];
                    b['impact_publisher'] = c.join('||')
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['dataTrackEventType'] != 'undefined' && b['dataTrackEventType'].toString().toLowerCase().indexOf('video'.toLowerCase()) > -1 && typeof b['page.pageInfo.pageName'] != 'undefined' && b['page.pageInfo.pageName'].toString().toLowerCase() == 'nba:summer-league:main'.toLowerCase() && typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().toLowerCase().indexOf('nba:tentpole-hub:'.toLowerCase()) > -1) || (typeof b['dataTrackEventType'] != 'undefined' && b['dataTrackEventType'].toString().toLowerCase().indexOf('click'.toLowerCase()) > -1 && typeof b['page.pageInfo.pageName'] != 'undefined' && b['page.pageInfo.pageName'].toString().toLowerCase() == 'nba:summer-league:main'.toLowerCase() && typeof b['interactionIdentifier'] != 'undefined' && b['interactionIdentifier'].toString().toLowerCase().indexOf('nba:tentpole-hub:'.toLowerCase()) > -1)) {
                    b['brazeEvent'] = 'viewed_summer_league_content_web';
                    try {
                        b['summerLeagueContentType'] = b.dataTrackEventType && b.dataTrackEventType === "video" ? "video" : "article";
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if (1) {
                    if (typeof window.nbatag_data === "object")
                        b.nbatag_data = Object.assign({}, window.nbatag_data);
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['tealium_event'].toString().toLowerCase() == 'Page View: Sign Up'.toLowerCase())) {
                    b['kochavaEvent'] = 'Start Account Creation'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['direct_call_event'] != 'undefined' && b['direct_call_event'].toString().toLowerCase() == 'purchase initiate direct to payment'.toLowerCase())) {
                    b['kochavaEvent'] = 'Checkout Start'
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['emailAddress'] != 'undefined' && typeof b['emailAddress'] != 'undefined' && b['emailAddress'] != '')) {
                    try {
                        b['emailAddress'] = b["emailAddress"].toLowerCase()
                    } catch (e) {}
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['direct_call_event'] != 'undefined' && typeof b['direct_call_event'] != 'undefined' && b['direct_call_event'] != '')) {
                    let mediaEvents = ["audio start", "audio pause", "audio complete", "video start", "video pause", "video complete"];
                    let stEvents = ["storyteller_story_share-attempt", "storyteller_story_share-success", "storyteller_story_skip-content", "storyteller_story_previous-content", "storyteller_story_skip-story", "storyteller_story_previous-story", "storyteller_story_close", "storyteller_story_swipe-up", "storyteller_story_trivia-quiz-question-answered", "storyteller_story_trivia-quiz-completed", "storyteller_story_voted-poll"];
                    if (mediaEvents.includes(b.direct_call_event)) {
                        if (typeof b.contentType != "undefined") {
                            b.mediaContentType = b.contentType;
                            delete b.contentType;
                        }
                    } else if (stEvents.includes(b.direct_call_event)) {
                        if (typeof b.contentType != "undefined") {
                            b.eventContentType = b.contentType;
                            delete b.contentType;
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['reportingEvtName'] != 'undefined' && typeof b['reportingEvtName'] != 'undefined' && b['reportingEvtName'] != '')) {
                    b['tealium_event'] = b['reportingEvtName']
                }
            } catch (e) {
                nbatag.DB(e);
            }
        }, function(a, b) {
            try {
                if ((typeof b['ut.event'] != 'undefined' && typeof b['ut.event'] != 'undefined' && b['ut.event'] != '')) {
                    if (typeof b !== "undefined") {
                        if ((typeof b.tealium_event == "undefined") || (b.tealium_event === "") || (b.tealium_event == "view") || (b.tealium_event == "link")) {
                            if (b["ut.event"] == "view")
                                b.tealium_event = "Page View: Default";
                            else if (b["ut.event"] == "link")
                                b.tealium_event = "Interaction Default";
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['direct_call_event'] != 'undefined' && /opin_sign-in_success$/i.test(b['direct_call_event'])) || (typeof b['direct_call_event'] != 'undefined' && /tve_sign-in_success$/i.test(b['direct_call_event']))) {
                    b["user.authenticationProvider.partner_name"] = b.partner;
                    b.partner = "nba engineering";
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if (b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase()) {
                    let amplitudeCheckCount = 1;

                    function setAmplitudeProps(propertiesObj) {
                        if (typeof amplitude != "undefined") {
                            const identify = new amplitude.Identify();
                            for (const [key, value] of Object.entries(propertiesObj)) {
                                identify.set(`${key}`, `${value}`);
                            }
                            amplitude.identify(identify);
                        }
                    }
                    if (window.sessionStorage["purchase-redirect-utm"]) {
                        let allParams = window.sessionStorage["purchase-redirect-utm"],
                            utms = {};
                        allParams
                            .substring(1)
                            .split("&")
                            .map((item) => {
                                if (item.match(/^utm_/)) {
                                    let keyValue = item.split("=");
                                    return (utms[keyValue[0]] = keyValue[1]);
                                }
                            });
                        if (Object.keys(utms).length > 0) {
                            setAmplitudeProps(utms);
                        }
                        delete window.sessionStorage["purchase-redirect-utm"];
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['ut.event'] != 'undefined' && b['ut.event'] != '' && b['ut.event'].toString().toLowerCase() == 'view'.toLowerCase())) {
                    var exceptionSections = {
                        "nba:identity": true,
                        "nba:purchase-funnel": true,
                        "Identity": true,
                        "Purchase Funnel": true
                    };
                    if (/\.nba\.com$/.test(location.hostname)) {
                        let sOrig = b.ampSiteSection ? b.ampSiteSection : "";
                        if ((sOrig !== "") && (!exceptionSections[sOrig])) {
                            let nbaOrigin = b.tealium_event + "||" + sOrig;
                            document.cookie = "nbaOrigin=" + encodeURIComponent(nbaOrigin) + ";domain=.nba.com;path=/";
                            sessionStorage.setItem("nbaOrigin", b.tealium_event);
                            sessionStorage.setItem("nbaSectionOrigin", b.ampSiteSection);
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                nbatag.runonce = nbatag.runonce || {};
                nbatag.runonce.ext = nbatag.runonce.ext || {};
                if (typeof nbatag.runonce.ext[977] == 'undefined') {
                    nbatag.runonce.ext[977] = 1;
                    if ((typeof b['js_page.window.disableAmplitude'] != 'undefined' && b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase())) {
                        function createDeviceIdCookie(name, value, domain) {
                            const oneYearInSeconds = 365 * 24 * 60 * 60;
                            const expirationDate = new Date();
                            expirationDate.setFullYear(expirationDate.getFullYear() + 1);
                            const expires = `expires=${expirationDate.toUTCString()}`;
                            document.cookie = `${name}=${value};max-age=${oneYearInSeconds};${expires};path=/; domain=${domain}`;
                        }

                        if ((typeof window.OnetrustActiveGroups == "string") && (window.OnetrustActiveGroups.indexOf("NBAmt") > -1)) {
                            var chkCount = 0;
                            var ampInitPromise = new Promise(function(resolve, reject) {
                                var ampTmr = setInterval(function() {
                                    if (chkCount < 2) {
                                        if ((typeof amplitude == "object") && (typeof amplitude.getDeviceId == "function")) {
                                            if (amplitude.getDeviceId() != "undefined") {
                                                clearInterval(ampTmr);
                                                resolve("initted");
                                            } else {
                                                clearInterval(ampTmr);
                                                reject("default");
                                            }
                                        }
                                        chkCount++;
                                    } else {
                                        clearInterval(ampTmr);
                                        reject("default");
                                    }
                                }, 5000);
                            });

                            ampInitPromise.then(function(result) {
                                if (result == "initted") {
                                    if (b["ut.profile"].indexOf("wnba") < 0) {
                                        if (b["ut.env"] == "prod")
                                            createDeviceIdCookie("AMP_saved_deviceId", amplitude.getDeviceId(), ".nba.com");
                                        else
                                            createDeviceIdCookie("AMP_saved_deviceId_qa", amplitude.getDeviceId(), ".nba.com");
                                    } else {
                                        if (b["ut.env"] == "prod")
                                            createDeviceIdCookie("AMP_saved_deviceId", amplitude.getDeviceId(), ".wnba.com");
                                        else
                                            createDeviceIdCookie("AMP_saved_deviceId_qa", amplitude.getDeviceId(), ".wnba.com");
                                    }
                                } else {
                                    if ((typeof b.ampDeviceId == "string") && (b.ampDeviceId != "undefined") && (b.ampDeviceId !== "")) {
                                        if (b["ut.profile"].indexOf("wnba") < 0) {
                                            if (b["ut.env"] == "prod")
                                                createDeviceIdCookie("AMP_saved_deviceId", b.ampDeviceId, ".nba.com");
                                            else
                                                createDeviceIdCookie("AMP_saved_deviceId_qa", b.ampDeviceId, ".nba.com");
                                        } else {
                                            if (b["ut.env"] == "prod")
                                                createDeviceIdCookie("AMP_saved_deviceId", b.ampDeviceId, ".wnba.com");
                                            else
                                                createDeviceIdCookie("AMP_saved_deviceId_qa", b.ampDeviceId, ".wnba.com");
                                        }
                                    }
                                }
                            });
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }];
        nbatag.handler.cfg_extend = [{
            "blr": 1,
            "alr": 0,
            "id": "942",
            "end": 0,
            "bwq": 0
        }, {
            "bwq": 0,
            "end": 0,
            "id": "1",
            "blr": 1,
            "alr": 0
        }, {
            "bwq": 0,
            "end": 0,
            "blr": 1,
            "alr": 0,
            "id": "2"
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 0,
            "blr": 1,
            "id": "884"
        }, {
            "end": 0,
            "bwq": 0,
            "id": "882",
            "alr": 0,
            "blr": 1
        }, {
            "blr": 1,
            "alr": 0,
            "id": "788",
            "end": 0,
            "bwq": 0
        }, {
            "bwq": 0,
            "end": 0,
            "id": "19",
            "blr": 1,
            "alr": 0
        }, {
            "end": 0,
            "bwq": 0,
            "id": "100",
            "alr": 0,
            "blr": 1
        }, {
            "blr": 1,
            "alr": 0,
            "id": "15",
            "end": 0,
            "bwq": 0
        }, {
            "bwq": 0,
            "end": 0,
            "blr": 1,
            "alr": 0,
            "id": "101"
        }, {
            "id": "567",
            "alr": 0,
            "blr": 1,
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 0,
            "blr": 1,
            "id": "886"
        }, {
            "id": "877",
            "blr": 1,
            "alr": 0,
            "end": 0,
            "bwq": 0
        }, {
            "alr": 0,
            "blr": 1,
            "id": "880",
            "bwq": 0,
            "end": 0
        }, {
            "bwq": 0,
            "end": 0,
            "id": "938",
            "blr": 1,
            "alr": 0
        }, {
            "alr": 0,
            "blr": 1,
            "id": "975",
            "bwq": 0,
            "end": 0
        }, {
            "bwq": 0,
            "end": 0,
            "id": "985",
            "blr": 1,
            "alr": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 0,
            "blr": 1,
            "id": "996"
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "blr": 0,
            "id": "88"
        }, {
            "end": 0,
            "bwq": 0,
            "id": "102",
            "alr": 1,
            "blr": 0
        }, {
            "id": "103",
            "blr": 0,
            "alr": 1,
            "end": 0,
            "bwq": 0
        }, {
            "bwq": 0,
            "end": 0,
            "blr": 0,
            "alr": 1,
            "id": "878"
        }, {
            "end": 0,
            "bwq": 0,
            "id": "104",
            "alr": 1,
            "blr": 0
        }, {
            "id": "105",
            "blr": 0,
            "alr": 1,
            "end": 0,
            "bwq": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "blr": 0,
            "id": "106"
        }, {
            "end": 0,
            "bwq": 0,
            "id": "879",
            "alr": 1,
            "blr": 0
        }, {
            "alr": 1,
            "blr": 0,
            "id": "107",
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "id": "81",
            "alr": 1,
            "blr": 0
        }, {
            "id": "82",
            "blr": 0,
            "alr": 1,
            "end": 0,
            "bwq": 0
        }, {
            "alr": 1,
            "blr": 0,
            "id": "86",
            "bwq": 0,
            "end": 0
        }, {
            "end": 0,
            "bwq": 0,
            "id": "87",
            "alr": 1,
            "blr": 0
        }, {
            "id": "95",
            "alr": 1,
            "blr": 0,
            "bwq": 0,
            "end": 0
        }, {
            "blr": 0,
            "alr": 1,
            "id": "94",
            "end": 0,
            "bwq": 0
        }, {
            "bwq": 0,
            "end": 0,
            "blr": 0,
            "alr": 1,
            "id": "814"
        }, {
            "bwq": 0,
            "end": 0,
            "id": "805",
            "blr": 0,
            "alr": 1
        }, {
            "end": 0,
            "bwq": 0,
            "id": "179",
            "alr": 1,
            "blr": 0
        }, {
            "bwq": 0,
            "end": 0,
            "id": "623",
            "blr": 0,
            "alr": 1
        }, {
            "end": 0,
            "bwq": 0,
            "id": "745",
            "alr": 1,
            "blr": 0
        }, {
            "blr": 0,
            "alr": 1,
            "id": "748",
            "end": 0,
            "bwq": 0
        }, {
            "end": 0,
            "bwq": 0,
            "alr": 1,
            "blr": 0,
            "id": "924"
        }, {
            "end": 0,
            "bwq": 0,
            "id": "876",
            "alr": 1,
            "blr": 0
        }, {
            "alr": 1,
            "blr": 0,
            "id": "888",
            "bwq": 0,
            "end": 0
        }, {
            "id": "887",
            "blr": 0,
            "alr": 1,
            "end": 0,
            "bwq": 0
        }, {
            "end": 0,
            "bwq": 0,
            "id": "762",
            "alr": 1,
            "blr": 0
        }, {
            "alr": 0,
            "blr": 0,
            "id": "835",
            "bwq": 0,
            "end": 1
        }, {
            "blr": 0,
            "alr": 0,
            "id": "881",
            "end": 1,
            "bwq": 0
        }, {
            "end": 1,
            "bwq": 0,
            "alr": 0,
            "blr": 0,
            "id": "977"
        }];
        if (nbatag.gdpr) {
            var consentEnabled = false;
            var preferencesEnabled = false;
            var doNotSellEnabled = false;
            nbatag.gdpr.doNotSell = nbatag.gdpr.doNotSell || {};
            nbatag.gdpr.preferences_prompt = nbatag.gdpr.preferences_prompt || {};
            nbatag.gdpr.consent_prompt = nbatag.gdpr.consent_prompt || {};
            nbatag.gdpr.applyConsentState = function() {
                var enforcementMode = nbatag.gdpr.getEnforcementMode();
                if (enforcementMode === 'none') return;
                nbatag.DB('Consent Manager: Applying consent');
                try {
                    var i, lc = nbatag.loader.cfg,
                        cs = nbatag.gdpr.getConsentState(),
                        ot = nbatag.gdpr.omittedTags || {};
                    if (typeof cs === 'number') {
                        if ((nbatag.gdpr.consent_prompt.isEnabled && parseInt(cs) !== 1) || ((!consentEnabled && preferencesEnabled && enforcementMode === 'opt-in') && (parseInt(cs) === -1 || parseInt(cs) === 0))) {
                            nbatag.DB('Consent Manager: Setting all tags to off');
                            for (i in nbatag.loader.GV(lc)) {
                                if (typeof ot[i] === 'undefined') {
                                    lc[i].load = 0;
                                }
                            }
                        }
                    } else if (((nbatag.gdpr.consent_prompt.isEnabled || nbatag.gdpr.preferences_prompt.isEnabled) || (!consentEnabled && preferencesEnabled)) && enforcementMode === 'opt-in') {
                        nbatag.DB('Consent Manager: Partial Consent');
                        for (i in nbatag.loader.GV(lc)) {
                            if (typeof ot[i] === 'undefined') {
                                if (lc[i].tcat > 0 && cs[lc[i].tcat - 1].ct != '1') {
                                    lc[i].load = 0;
                                }
                            }
                        }
                    }
                    var btl = nbatag.gdpr.dns ? nbatag.gdpr.dns.getBlockedDnsTagLookup() : null;
                    nbatag.DB('Consent Manager: Do Not Sell Tags');
                    if (enforcementMode === 'opt-out' && btl) {
                        for (i in nbatag.loader.GV(lc)) {
                            if (parseInt(btl[i]) === 1) {
                                lc[i].load = 0;
                            }
                        }
                    }
                    try {
                        if (window.tealiumConsentRegister && window.tealiumConsentRegister.currentDecision === null) {
                            var cookieValues = nbatag.gdpr.getCookieValues();
                            var hasDnsCookie = typeof cookieValues.dns === 'string';
                            var hasConsentCookie = typeof cookieValues.consent === 'string';
                            var decisionType = (enforcementMode === 'opt-in' && hasConsentCookie) || (enforcementMode === 'opt-out' && hasDnsCookie) ? 'explicit' : 'implicit';
                            var decision = (decisionType === 'implicit' && enforcementMode === 'opt-in') ? [] : nbatag.gdpr.getSelectedCategories();
                            decision.unshift('always_on');
                            decision.type = decisionType;
                            window.tealiumConsentRegister.addConsentDecision(decision);
                        }
                    } catch (e) {
                        nbatag.DB(e);
                    }
                } catch (e) {
                    nbatag.DB(e);
                }
            };
            nbatag.gdpr.promptEnabledSetting = function() {
                if (!nbatag.gdpr.dr && (nbatag.cfg.readywait || nbatag.cfg.waittimer)) {
                    nbatag.gdpr.dr = 1;
                    return;
                }
                nbatag.gdpr.consent_prompt.wasInitiallyEnabled = consentEnabled;
                nbatag.gdpr.preferences_prompt.wasInitiallyEnabled = preferencesEnabled;
                nbatag.gdpr.doNotSell.wasInitiallyEnabled = doNotSellEnabled;
                if (consentEnabled === true && !(1)) {
                    nbatag.gdpr.consent_prompt.isEnabled = false;
                }
                if (preferencesEnabled === true && (consentEnabled === true && !(1))) {
                    nbatag.gdpr.preferences_prompt.isEnabled = false;
                }
                if (doNotSellEnabled === true && !(1)) {
                    nbatag.gdpr.doNotSell.isEnabled = false;
                }
                if (preferencesEnabled === true && consentEnabled === false && !(1)) {
                    nbatag.gdpr.preferences_prompt.isEnabled = true;
                }
            };
            var splitGdprModules = false;
            if (typeof nbatag.gdpr.getEnforcementMode !== 'function') {
                splitGdprModules = true;
            }
            nbatag.gdpr.getEnforcementMode = function() {
                nbatag.gdpr.promptEnabledSetting();
                var optInModulesAreActive = (nbatag.gdpr.consent_prompt && nbatag.gdpr.consent_prompt.isEnabled === true);
                var optOutModuleIsActive = (nbatag.gdpr.doNotSell && nbatag.gdpr.doNotSell.isEnabled === true);
                var optInPreferencesOnly = (!optInModulesAreActive && !nbatag.gdpr.consent_prompt.wasInitiallyEnabled && nbatag.gdpr.preferences_prompt.wasInitiallyEnabled && !optOutModuleIsActive) || (splitGdprModules && nbatag.gdpr.preferences_prompt && nbatag.gdpr.preferences_prompt.wasInitiallyEnabled);
                var enforcementMode = 'opt-in';
                if (optOutModuleIsActive && !optInModulesAreActive) enforcementMode = 'opt-out';
                if (!optOutModuleIsActive && optInPreferencesOnly) enforcementMode = 'opt-in';
                if (!optOutModuleIsActive && !optInModulesAreActive && !optInPreferencesOnly) enforcementMode = 'none';
                return enforcementMode;
            };
        }
        nbatag.loader.initcfg = function() {
            nbatag.loader.cfg = {
                "86": {
                    load: (((nbatag.cond[33]) && (nbatag.cond[58]))),
                    send: 1,
                    v: 202601281552,
                    wait: 1,
                    tid: 1197
                },
                "90": {
                    load: (((nbatag.cond[33]) && (nbatag.cond[57]))),
                    send: 1,
                    v: 202602061808,
                    wait: 1,
                    tid: 1236
                },
                "2": {
                    load: ((nbatag.cond[29])),
                    send: 1,
                    v: 202508131455,
                    wait: 1,
                    tid: 11027
                },
                "3": {
                    load: ((nbatag.cond[28])),
                    send: 1,
                    v: 202512181647,
                    wait: 1,
                    tid: 1202
                },
                "77": {
                    load: 1,
                    send: 1,
                    v: 202508270206,
                    wait: 1,
                    tid: 20064
                }
            };
            nbatag.loader.cfgsort = ["86", "90", "2", "3", "77"];
            if (nbatag.gdpr && nbatag.gdpr.getEnforcementMode() === 'opt-in') {
                Object.keys(nbatag.loader.cfg).forEach(function(tagId) {
                    if (nbatag.loader.cfg[tagId].tcat === 16) {
                        nbatag.DB('Consent Manager: Removing uncategorized tag from nbatag.loader.cfg in opt-in mode: ' + tagId);
                        delete nbatag.loader.cfg[tagId];
                        nbatag.loader.cfgsort = nbatag.loader.cfgsort.filter(function(id) {
                            return id !== tagId;
                        });
                    }
                })
            }
        }
        nbatag.loader.initcfg();
    }

    try {
        (function(window) {
            function evaluateLoadRule(id) {
                if (!id) return false;
                if (id === "all") return true;

                var config = {};
                config[id] = 0;
                var data = window.nbatag.loader.GV(window.nbatag_data);

                window.nbatag.cl = {
                    "_all_": 1
                };
                window.nbatag.loader.rd_flag = 1;

                window.nbatag.loader.RD(data);
                window.nbatag.loader.loadrules(data, config);

                window.nbatag.cl = undefined;
                window.nbatag.loader.rd_flag = undefined;

                return Boolean(config[id]);
            }

            function checkLoadRulesConflict(map) {
                if (!map) return true;

                var counter = 0;
                for (var key in map) {
                    if (map[key]) counter += 1;
                }

                if (counter > 1) return true;

                return false;
            }

            function canIntegrationLoad(id) {
                return Boolean(!window.nbatag_tealiumCmpIntegration.loadRules.hasConflict && window.nbatag_tealiumCmpIntegration.loadRules.loadMap[id]);
            }

            window.nbatag_tealiumCmpIntegration = window.nbatag_tealiumCmpIntegration || {};
            window.nbatag_tealiumCmpIntegration.loadRules = {};

            window.nbatag_tealiumCmpIntegration.loadRules.canIntegrationLoad = canIntegrationLoad;

            window.nbatag_tealiumCmpIntegration.loadRules.loadMap = {
                "023d88c4-b2b3-4246-d779-e927abf0204f": evaluateLoadRule("all")
            };
            window.nbatag_tealiumCmpIntegration.loadRules.exemptionMap = {};
            window.nbatag_tealiumCmpIntegration.loadRules.hasConflict = checkLoadRulesConflict(window.nbatag_tealiumCmpIntegration.loadRules.loadMap);
        })(window);
        if (window.nbatag_tealiumCmpIntegration.loadRules.canIntegrationLoad("023d88c4-b2b3-4246-d779-e927abf0204f")) {
            window.nbatag_tealiumCmpIntegration = window.nbatag_tealiumCmpIntegration || {};
            window.nbatag_tealiumCmpIntegration.map = {
                "d0494fd0-8921-497a-8323-e3d29775ce1b": {
                    "req": [],
                    "NBAmt": ["8", "3", "2", "10", "86", "77", "90"],
                    "NBAad": ["8"]
                }
            };
            window.nbatag_tealiumCmpIntegration.refiringAllowed = [1, 8];
            window.nbatag_tealiumCmpIntegration.tiqGroupName = "req"; //tv:2.0.1
            //base:onetrust
            /***@module utcm/integration*@description CMP-specific component for OneTrust.**2.0.1*-Add safeguarding conditional to cmpConvertResponseToLookupObject*-Fix bug in cmpCheckForExplicitConsentDecision where an explicit opt-in was incorrectly output as an'implicit'decision one**2.0.0*-Start using keys instead of names for the lookup(breaking change,but with deactivation switch)*-Update the way the Vendor ID is pulled from the page to stop using the legacy cctId property*-Parse window.dataLayer for the decision to avoid relying on ConsentIntegrationData,which isn't always populated for all customers
             *  - Introduce a new function to help with setup (cmpConvertResponseToLookupObject) that produces a key-to-name lookup object
             *
             * 1.0.2
             *  - Improve cmpCheckForExplicitConsentDecision again - there are non-decision interactions, so now we check if it's opt-in mode and the box is open**1.0.1*-Improve cmpCheckForExplicitConsentDecision-use the interaction count instead of last interaction label(more reliable)**1.0.0*-Initial version,start versioning*/

            (function oneTrust(window) {
                // allows simple adjustment of the name/id behavior
                var useNamesInsteadOfKeys = false;
                var disableVendorIdValidation = true;
                window.nbatag_tealiumCmpIntegration = window.nbatag_tealiumCmpIntegration || {};
                window.nbatag_tealiumCmpIntegration.cmpName = "OneTrust";
                window.nbatag_tealiumCmpIntegration.cmpIntegrationVersion = "onetrust-2.0.1";
                window.nbatag_tealiumCmpIntegration.cmpFetchCurrentConsentDecision = cmpFetchCurrentConsentDecision;
                window.nbatag_tealiumCmpIntegration.cmpFetchCurrentLookupKey = cmpFetchCurrentLookupKey;
                window.nbatag_tealiumCmpIntegration.cmpCheckIfOptInModel = cmpCheckIfOptInModel;
                window.nbatag_tealiumCmpIntegration.cmpCheckForWellFormedDecision = cmpCheckForWellFormedDecision;
                window.nbatag_tealiumCmpIntegration.cmpCheckForExplicitConsentDecision = cmpCheckForExplicitConsentDecision;
                window.nbatag_tealiumCmpIntegration.cmpCheckForTiqConsent = cmpCheckForTiqConsent;
                window.nbatag_tealiumCmpIntegration.cmpConvertResponseToGroupList = cmpConvertResponseToGroupList;
                window.nbatag_tealiumCmpIntegration.cmpConvertResponseToLookupObject = cmpConvertResponseToLookupObject;

                function cmpCheckIfOptInModel() {
                    var decision = cmpFetchCurrentConsentDecision();
                    if (decision && decision.ConsentModel && decision.ConsentModel.Name === "opt-out") {
                        return false;
                    }
                    return true;
                }

                function cmpFetchCurrentConsentDecision() {
                    if (!window.OneTrust || typeof window.OneTrust.GetDomainData !== "function") return false;
                    var cmpRawOutput = window.OneTrust.GetDomainData();
                    cmpRawOutput.dataLayer = window.dataLayer;
                    return cmpRawOutput;
                }

                function cmpFetchCurrentLookupKey() {
                    var scrapeOneTrustVendorId = function() {
                        var allScripts = document.getElementsByTagName("script");
                        var re = /\/otSDKStub\.js(\?.*)*$/;
                        for (var i = 0; i < allScripts.length; i++) {
                            var isOneTrustScript = re.test(allScripts[i].src);
                            if (isOneTrustScript) {
                                var fullVendorId = allScripts[i].getAttribute("data-domain-script");
                                return fullVendorId.split("-test")[0];
                            }
                        }
                        return "error-not-found";
                    }
                    if (disableVendorIdValidation) {
                        return (window.nbatag_tealiumCmpIntegration && window.nbatag_tealiumCmpIntegration.map && Object.keys(window.nbatag_tealiumCmpIntegration.map)[0]) || "(Vendor ID check disabled)";
                    }
                    return scrapeOneTrustVendorId();
                }

                function cmpCheckForWellFormedDecision(cmpRawOutput) {
                    if (typeof cmpRawOutput !== "object") return false;
                    if (toString.call(cmpRawOutput.Groups) !== "[object Array]") return false;
                    if (toString.call(cmpRawOutput.dataLayer) !== "[object Array]") return false;
                    return true;
                }

                function cmpCheckForExplicitConsentDecision(cmpRawOutput) {
                    if (cmpCheckForWellFormedDecision(cmpRawOutput) !== true) return false;
                    return window.OneTrust && typeof window.OneTrust.IsAlertBoxClosed === "function" && window.OneTrust.IsAlertBoxClosed();
                }

                function cmpConvertResponseToLookupObject(cmpRawOutput) {
                    var decisionString = "";
                    if (cmpCheckForWellFormedDecision(cmpRawOutput) !== true) return {};
                    for (var i = cmpRawOutput.dataLayer.length - 1; i >= 0; i--) {
                        if (["OneTrustGroupsUpdated", "OneTrustLoaded"].indexOf(cmpRawOutput.dataLayer[i].event) !== -1) {
                            decisionString = cmpRawOutput.dataLayer[i].OnetrustActiveGroups;
                            break;
                        }
                    }
                    var permittedPurposeIds = decisionString.split(",").filter(function(group) {
                        return group !== "";
                    })
                    var permittedPurposesWithNames = {};
                    cmpRawOutput.Groups.forEach(function(groupInfo) {
                        if (permittedPurposeIds.indexOf(groupInfo.OptanonGroupId) !== -1) {
                            permittedPurposesWithNames[groupInfo.OptanonGroupId] = groupInfo.GroupName || "ERROR-MISSING";
                        }
                    })
                    return permittedPurposesWithNames;
                }

                function cmpConvertResponseToGroupList(cmpRawOutput) {
                    var permittedPurposesWithNames = cmpConvertResponseToLookupObject(cmpRawOutput);
                    var keysOrValues = useNamesInsteadOfKeys ? "values" : "keys";
                    return Object[keysOrValues](permittedPurposesWithNames);
                }

                function cmpCheckForTiqConsent(cmpRawOutput, tiqGroupName) {
                    if (cmpCheckForWellFormedDecision(cmpRawOutput) !== true) return false;
                    tiqGroupName = tiqGroupName || "tiq-group-name-missing";
                    var allowedGroups = cmpConvertResponseToGroupList(cmpRawOutput);
                    return allowedGroups.indexOf(tiqGroupName) !== -1;
                }
            })(window);
        }
        var hasLoadRuleMatch = Object.values(window.nbatag_tealiumCmpIntegration.loadRules.loadMap).some(value => !!value);
        var hasExemptionMatch = Object.values(window.nbatag_tealiumCmpIntegration.loadRules.exemptionMap).some(value => !!value);
        if (hasLoadRuleMatch || !hasExemptionMatch) {
            (function(window) {
                var version = "v1.2.1";
                window.nbatag_tealiumCmpIntegration = window.nbatag_tealiumCmpIntegration || {};
                window.nbatag_tealiumCmpIntegration.cmpName = window.nbatag_tealiumCmpIntegration.cmpName || "Unnamed CMP";
                var nameOfFullGroupArray = window.nbatag_tealiumCmpIntegration.nameOfFullGroupArray || "tci.purposes_with_consent_all";
                var nameOfUnprocessedGroupArray = window.nbatag_tealiumCmpIntegration.nameOfUnprocessedGroupArray || "tci.purposes_with_consent_unprocessed";
                var nameOfProcessedGroupArray = window.nbatag_tealiumCmpIntegration.nameOfProcessedGroupArray || "tci.purposes_with_consent_processed";
                var nameOfConsentTypeString = window.nbatag_tealiumCmpIntegration.nameOfConsentTypeString || "tci.consent_type";
                var nameOfEventIdString = window.nbatag_tealiumCmpIntegration.nameOfConsentTypeString || "tci.event_id";
                var nameOfImplicitQueueMarker = window.nbatag_tealiumCmpIntegration.nameOfImplicitQueueMarker || "tci.from_implicit_queue";
                window.nbatag_tealiumCmpIntegration.suppressConsentRegister = window.nbatag_tealiumCmpIntegration.suppressConsentRegister || false;
                var refiringAllowed = window.nbatag_tealiumCmpIntegration.refiringAllowed || [];
                var nameOfConsentPollingEvent = window.nbatag_tealiumCmpIntegration.nameOfConsentPollingEvent || "tiq_cmp_consent_polling";
                var consentTimeoutInterval = 250;
                var tiqInDebugMode = /nbatagdb=true/.test(document.cookie);
                var tealiumEnvironment = getTealiumEnvironment() || "prod";
                var tiqGroupName = window.nbatag_tealiumCmpIntegration.tiqGroupName || "_missing_";
                var cmpFetchCurrentConsentDecision = (typeof window.nbatag_tealiumCmpIntegration.cmpFetchCurrentConsentDecision === "function" && window.nbatag_tealiumCmpIntegration.cmpFetchCurrentConsentDecision) || function() {};
                var cmpCheckForWellFormedDecision = (typeof window.nbatag_tealiumCmpIntegration.cmpCheckForWellFormedDecision === "function" && window.nbatag_tealiumCmpIntegration.cmpCheckForWellFormedDecision) || function() {};
                var cmpFetchCurrentLookupKey = (typeof window.nbatag_tealiumCmpIntegration.cmpFetchCurrentLookupKey === "function" && window.nbatag_tealiumCmpIntegration.cmpFetchCurrentLookupKey) || function() {};
                var cmpCheckForExplicitConsentDecision = (typeof window.nbatag_tealiumCmpIntegration.cmpCheckForExplicitConsentDecision === "function" && window.nbatag_tealiumCmpIntegration.cmpCheckForExplicitConsentDecision) || function() {};
                var cmpCheckForTiqConsent = (typeof window.nbatag_tealiumCmpIntegration.cmpCheckForTiqConsent === "function" && window.nbatag_tealiumCmpIntegration.cmpCheckForTiqConsent) || function() {};
                var cmpConvertResponseToGroupList = (typeof window.nbatag_tealiumCmpIntegration.cmpConvertResponseToGroupList === "function" && window.nbatag_tealiumCmpIntegration.cmpConvertResponseToGroupList) || function() {};
                var cmpCheckIfOptInModel = (typeof window.nbatag_tealiumCmpIntegration.cmpCheckIfOptInModel === "function" && window.nbatag_tealiumCmpIntegration.cmpCheckIfOptInModel) || function() {};
                window.nbatag_tealiumCmpIntegration.version = version;
                window.nbatag_tealiumCmpIntegration.logger = logger;
                window.nbatag_tealiumCmpIntegration.getCurrentConsentDecision = getCurrentConsentDecision;
                window.nbatag_tealiumCmpIntegration.cmpFetchCurrentLookupKey = cmpFetchCurrentLookupKey;
                window.nbatag_tealiumCmpIntegration.isNoviewSet = window.nbatag_cfg_ovrd && window.nbatag_cfg_ovrd.noview === true;
                window.nbatag_tealiumCmpIntegration.nameOfFullGroupArray = nameOfFullGroupArray;
                window.nbatag_tealiumCmpIntegration.nameOfConsentTypeString = nameOfConsentTypeString;
                window.nbatag_tealiumCmpIntegration.nameOfUnprocessedGroupArray = nameOfUnprocessedGroupArray;
                window.nbatag_tealiumCmpIntegration.nameOfProcessedGroupArray = nameOfProcessedGroupArray;
                window.nbatag_tealiumCmpIntegration.implicitEventQueue = window.nbatag_tealiumCmpIntegration.implicitEventQueue || [];
                window.nbatag_tealiumCmpIntegration.earlyEventQueue = window.nbatag_tealiumCmpIntegration.earlyEventQueue || [];
                var map = window.nbatag_tealiumCmpIntegration.map || {};
                window.nbatag_tealiumCmpIntegration.tagBasedMap = generateTagBasedMap();
                var alreadyLoggedMessageIds = {};

                function messageNotLoggedYet(messageId) {
                    var output = false;
                    if (typeof alreadyLoggedMessageIds[messageId] === "undefined") {
                        alreadyLoggedMessageIds[messageId] = true;
                        output = true;
                    }
                    return output;
                }

                function buildConsentDecisionFromRawCmpOutput(cmpRawOutput) {
                    var vendorArray = cmpConvertResponseToGroupList(cmpRawOutput) || [];
                    var isWellFormed = cmpCheckForWellFormedDecision(cmpRawOutput);
                    if (!isWellFormed) {
                        vendorArray.type = "missing-well-formed-response";
                        return vendorArray;
                    }
                    var tagBasedMap = generateTagBasedMap();
                    var currentSettingsIdHasMapping = typeof tagBasedMap === "object" && Object.keys(tagBasedMap).length > 0;
                    if (!currentSettingsIdHasMapping) {
                        vendorArray.type = "missing-map";
                        return vendorArray;
                    }
                    vendorArray.type = cmpCheckForExplicitConsentDecision(cmpRawOutput) ? "explicit" : "implicit";
                    var tiqGroupName = window.nbatag_tealiumCmpIntegration.tiqGroupName || "_missing_";
                    if (cmpCheckForTiqConsent(cmpRawOutput, tiqGroupName) === false) {
                        vendorArray.type = "missing-tiq-consent";
                    }
                    return vendorArray;
                }
                class TealiumConsentRegister {
                    constructor() {
                        this.currentDecision = null;
                        this.decisions = [];
                    }
                    addConsentDecision(decision) {
                        if (!decision || (decision.type !== 'implicit' && decision.type !== 'explicit')) {
                            return;
                        }
                        if (!this.isNewDecision(this.currentDecision, decision)) {
                            return;
                        }
                        const eventType = this.currentDecision === null ? 'consent_loaded' : 'consent_updated';
                        this.currentDecision = decision;
                        this.decisions.push(decision);
                        const event = new CustomEvent(eventType, {
                            detail: {
                                decision: decision
                            }
                        });
                        window.dispatchEvent(event);
                    }
                    getCurrentDecision() {
                        return this.currentDecision;
                    }
                    getAllDecisions() {
                        return this.decisions;
                    }
                    isNewDecision(desc1, desc2) {
                        if (!desc1 || !desc2 || desc1.length !== desc2.length || desc1.type !== desc2.type) return true;
                        for (let i = 0; i < desc1.length; i++) {
                            if (desc1[i] !== desc2[i]) {
                                return true;
                            }
                        }
                        return false;
                    }
                }

                function reactToCmpResponse(cmpResponse) {
                    var cmpFound = typeof cmpResponse === "object";
                    var foundWellFormedConsentDecision = cmpCheckForWellFormedDecision(cmpResponse);
                    var tagBasedMap = generateTagBasedMap();
                    var foundMapEntryForActiveSetting = Object.keys(tagBasedMap).length > 0;
                    var foundExplicitConsent = cmpCheckForExplicitConsentDecision(cmpResponse);
                    var tiqIsAllowedToFire = cmpCheckForTiqConsent(cmpResponse, tiqGroupName);
                    var tiqIsLoaded = window.nbatag_tealiumCmpIntegration.isTiqReady || (window.nbatag && window.nbatag.handler && window.nbatag.handler.iflag === 1);
                    var conflictingIntegrations = window.nbatag_tealiumCmpIntegration.loadRules.hasConflict;
                    var noEnforcementRuleApplies = (Object.values(window.nbatag_tealiumCmpIntegration.loadRules.loadMap)).indexOf(true) === -1;
                    var currentDecision = buildConsentDecisionFromRawCmpOutput(cmpResponse);
                    try {
                        if (!window.nbatag_tealiumCmpIntegration.suppressConsentRegister) {
                            window.tealiumConsentRegister = window.tealiumConsentRegister || new TealiumConsentRegister();
                            window.tealiumConsentRegister.addConsentDecision(currentDecision);
                        }
                    } catch (e) {
                        console.warn(e)
                    }

                    function checkLater() {
                        if (!window.nbatag_tealiumCmpIntegration.alreadyPolling) {
                            window.nbatag_tealiumCmpIntegration.alreadyPolling = true;
                            return window.setTimeout(recheckForCmpAndConsent, consentTimeoutInterval);
                        }
                    }

                    function checkLaterIfNeeded() {
                        if (cmpCheckIfOptInModel() === true) {
                            return checkLater();
                        }
                        if (cmpCheckIfOptInModel() === false && !window.nbatag_tealiumCmpIntegration.isTiqReady) {
                            return checkLater();
                        }
                    }
                    if (tiqIsLoaded) {
                        window.nbatag_tealiumCmpIntegration.isTiqReady = true;
                    }
                    if (conflictingIntegrations) {
                        if (messageNotLoggedYet(0)) {
                            var message = "Conflicting consent integrations found:\n";
                            var loadMap = window.nbatag_tealiumCmpIntegration.loadRules.loadMap;
                            Object.keys(loadMap).forEach(function(key) {
                                if (loadMap[key])
                                    message += "\n- " + key
                            });
                            message += "\n\nStopping TiQ (no cookies set/removed, no tags fired).\n\nNo further polling."
                            logger(message);
                        }
                        stopTiq();
                    } else if (noEnforcementRuleApplies) {
                        if (messageNotLoggedYet(10))
                            logger("Consent Integrations are active on this environment, but none of the enforcement rules apply to this page, and no exemption applies.\n\nStopping TiQ (no cookies set/removed, no tags fired).");
                        stopTiq();
                    } else if (!cmpFound) {
                        if (messageNotLoggedYet(1))
                            logger("No CMP found on page.\n\nStopping TiQ (no cookies set/removed, no tags fired).\n\nPolling for changes.");
                        checkLater();
                        stopTiq();
                    } else if (!foundMapEntryForActiveSetting) {
                        if (messageNotLoggedYet(2))
                            logger("No map found for current CMP Lookup Key.\n\nStopping TiQ (no cookies set/removed, no tags fired).\n\nNo retries.");
                        stopTiq();
                    } else if (!foundWellFormedConsentDecision) {
                        if (messageNotLoggedYet(3))
                            logger("Found CMP and got response, but didn't understand the response.\n\nStopping TiQ (no cookies set/removed, no tags fired).\n\nPolling for changes.");
                        checkLater();
                        stopTiq();
                    } else if (!tiqIsAllowedToFire) {
                        if (messageNotLoggedYet(4))
                            logger("Found CMP and got well-formed response, but TiQ (window.nbatag_tealiumCmpIntegration.tiqGroupName, defined as " +
                                window.nbatag_tealiumCmpIntegration.tiqGroupName +
                                ") isn't allowed to run based on the response.\n\nStopping TiQ (no cookies set/removed, no tags fired).\n\nPolling for changes.");
                        checkLaterIfNeeded();
                        stopTiq();
                    } else if (!foundExplicitConsent) {
                        if (cmpCheckIfOptInModel() === true) {
                            checkLaterIfNeeded();
                            if (messageNotLoggedYet(5))
                                logger("Found CMP and got well-formed IMPLICIT response which includes TiQ.\n\nAllowing certain tags to fire based on IMPLICIT consent.\n\nPolling for changes (opt-in mode).");
                        } else {
                            if (messageNotLoggedYet(5))
                                logger("Found CMP and got well-formed IMPLICIT response which includes TiQ.\n\nAllowing certain tags to fire based on IMPLICIT consent.\n\nNo further polling (opt-out mode)");
                        }
                        if (tiqIsLoaded) {
                            processEarlyQueue();
                        } else {
                            checkLaterIfNeeded();
                        }
                        triggerOrQueue();
                    } else if (foundExplicitConsent) {
                        if (messageNotLoggedYet(6))
                            logger("Found CMP and got well-formed EXPLICIT response which includes TiQ.\n\nAllowing certain tags to fire based on EXPLICIT consent.\n\nNo further polling.");
                        processEarlyQueue();
                        processImplicitQueue();
                        triggerOrQueue();
                    } else {
                        if (messageNotLoggedYet(7))
                            logger("Something unexpected went wrong.\n\nStopping TiQ (no cookies set/removed, no tags fired).\n\nNo retries.");
                        stopTiq();
                    }
                    if (!window.nbatag_tealiumCmpIntegration.suppressConsentRegister && !window.nbatag_tealiumCmpIntegration.alreadyPolling) {
                        window.nbatag_tealiumCmpIntegration.pollingWouldHaveStopped = true;
                        return checkLater();
                    }
                }

                function overrideUtagFunctions() {
                    if (window.nbatag.handler.trigger.toString().indexOf("nbatag_tealiumCmpIntegration") !== -1) {
                        return true;
                    }
                    window.nbatag.loader.initdata_old = window.nbatag.loader.initdata;
                    window.nbatag.loader.initdata = newUtagLoaderInitdata;
                    window.nbatag.handler.trigger_old = window.nbatag.handler.trigger;
                    window.nbatag.handler.trigger = newUtagHandlerTrigger;
                    window.nbatag.handler.RE_old = window.nbatag.handler.RE;
                    window.nbatag.handler.RE = newUtagHandlerRE;
                    logger("Overrode nbatag functions!");
                    if (window.nbatag.handler.trigger.toString().indexOf("nbatag_tealiumCmpIntegration") !== -1) {
                        return true;
                    }
                    return false;
                }

                function getNewConsents(implicit, explicit) {
                    implicit = implicit || [];
                    explicit = explicit || [];
                    var changes = [];
                    for (var i = 0; i < explicit.length; i++) {
                        if (implicit.indexOf(explicit[i]) === -1) {
                            changes.push(explicit[i]);
                        }
                    }
                    return changes;
                }

                function allPurposesHaveConsent(consentedServices, assignedPurposesString) {
                    if (!consentedServices || !assignedPurposesString || typeof assignedPurposesString !== 'string') return false;
                    var splitPurposeIds = assignedPurposesString.split(',');
                    for (var i = 0; i < splitPurposeIds.length; i++) {
                        if (consentedServices.indexOf(splitPurposeIds[i]) === -1) return false;
                    }
                    return true;
                }

                function allPurposesHaveBeenPreviouslyProcessed(alreadyProcessedGroups, assignedPurposesString) {
                    if (!alreadyProcessedGroups || !assignedPurposesString || typeof assignedPurposesString !== 'string') return true;
                    var splitPurposeIds = assignedPurposesString.split(',');
                    for (var i = 0; i < splitPurposeIds.length; i++) {
                        if (alreadyProcessedGroups.indexOf(splitPurposeIds[i]) === -1) return false;
                    }
                    return true;
                }

                function blockTagsBasedOnConsent(tagBasedMap, configObject, consentedServices, alreadyProcessedGroups, notProcessedGroups, refiringAllowed) {
                    if (Array.isArray(consentedServices) !== true) {
                        consentedServices = [];
                    }
                    tagBasedMap = tagBasedMap || {};
                    var nbatagFunctionsHaveBeenOverridden = window.nbatag.handler.trigger.toString().indexOf("nbatag_tealiumCmpIntegration") !== -1;
                    if (nbatagFunctionsHaveBeenOverridden !== true) {
                        window.nbatag.handler.trigger = function() {
                            if (messageNotLoggedYet(8)) {
                                logger("Tags have been disabled because the required nbatag.loader edit hasn't been done successfully and the nbatag_tealiumCmpIntegration is active.");
                            }
                        };
                        consentedServices = [];
                    }
                    if (!window.nbatag_tealiumCmpIntegration.bundledTags) {
                        var cfg = window.nbatag.loader.cfg;
                        var tags = Object.keys(cfg);
                        window.nbatag_tealiumCmpIntegration.bundledTags = tags.filter(function(tag) {
                            return cfg[tag].load === 4
                        });
                    }
                    var deactivatedTags = [];
                    alreadyProcessedGroups = alreadyProcessedGroups || [];
                    var tiqIsAllowed = tiqGroupName && consentedServices.indexOf(tiqGroupName) !== -1;
                    var allTagUids = Object.keys(configObject);
                    var assignedPurposeIds;
                    var isAllowed;
                    for (var i = 0; i < allTagUids.length; i++) {
                        isAllowed = false;
                        assignedPurposeIds = tagBasedMap[allTagUids[i]] || [];
                        if (assignedPurposeIds) {
                            isAllowed = tiqIsAllowed && allPurposesHaveConsent(consentedServices, assignedPurposeIds) && (!allPurposesHaveBeenPreviouslyProcessed(alreadyProcessedGroups, assignedPurposeIds) || (notProcessedGroups.length > 0 && refiringAllowed.indexOf(Number(allTagUids[i])) !== -1));
                        }
                        if (isAllowed === true) {
                            configObject[allTagUids[i]].consent = 1;
                        } else {
                            configObject[allTagUids[i]].load = 0;
                            configObject[allTagUids[i]].send = 0;
                            configObject[allTagUids[i]].consent = 0;
                            deactivatedTags.push(allTagUids[i]);
                        }
                    }
                    if (messageNotLoggedYet(9)) {
                        logger("Blocked tags: " +
                            JSON.stringify(deactivatedTags, null, 2) +
                            (tiqIsAllowed ? "" : "\n\nAll tags blocked because Tealium iQ isn't allowed to fire."));
                    }
                    return configObject;
                }

                function newUtagHandlerRE(a, b, c) {
                    if (c == "alr") {
                        var tagBasedMap = generateTagBasedMap();
                        var currentlyAllowedVendors = getCurrentConsentDecision();
                        var alreadyProcessed = b[nameOfImplicitQueueMarker] === 1 ? window.nbatag_tealiumCmpIntegration.implicitServices : [];
                        var notProcessed = getNewConsents(alreadyProcessed, currentlyAllowedVendors);
                        b[nameOfFullGroupArray] = currentlyAllowedVendors;
                        b[nameOfConsentTypeString] = currentlyAllowedVendors && currentlyAllowedVendors.type;
                        b[nameOfUnprocessedGroupArray] = notProcessed;
                        b[nameOfProcessedGroupArray] = alreadyProcessed;
                        logger("Called block logic:\n\nAllowed: " +
                            JSON.stringify(currentlyAllowedVendors, null, 2) +
                            "\n\nAlready processed: " +
                            (alreadyProcessed ? JSON.stringify(alreadyProcessed, null, 2) : "(none)"));
                        logger("Map:\n\n" +
                            JSON.stringify(map, null, 2) +
                            "\n\nActive CMP Lookup Key: " +
                            cmpFetchCurrentLookupKey() +
                            "\n\nMap has entry for current settingsId: " +
                            (typeof map[cmpFetchCurrentLookupKey()] === "object" ? "true" : "false") +
                            "\n\nTag-based map for the active key: " +
                            JSON.stringify(tagBasedMap, null, 2) +
                            "\n\nTags configured to refire: " +
                            JSON.stringify(refiringAllowed.map(tag => String(tag)), null, 2));
                        logger("Consent confirmed: " +
                            currentlyAllowedVendors.type +
                            " : " +
                            JSON.stringify(currentlyAllowedVendors, null, 2));
                        var newCfg = blockTagsBasedOnConsent(tagBasedMap, window.nbatag.loader.cfg, currentlyAllowedVendors, alreadyProcessed, notProcessed, refiringAllowed);
                        window.nbatag.loader.cfg = newCfg;
                    }
                    var r = window.nbatag.handler.RE_old(a, b, c);
                    return r;
                }

                function newUtagLoaderInitdata() {
                    window.nbatag.loader.initdata_old();
                    if (!window.nbatag_tealiumCmpIntegration.isNoviewSet && !window.nbatag_tealiumCmpIntegration.alreadyFiredInitialViewEvent) {
                        var consentedServices = getCurrentConsentDecision();
                        if (consentedServices.type === "missing-well-formed-response") {
                            return;
                        }
                        window.nbatag_tealiumCmpIntegration.alreadyFiredInitialViewEvent = true;
                        if (consentedServices.type === "implicit") {
                            window.nbatag_tealiumCmpIntegration.implicitServices = consentedServices;
                            var viewEvent = {
                                event: "view",
                                data: window.nbatag.handler.C(window.nbatag.data),
                            };
                            viewEvent.data[nameOfEventIdString] = storeOriginalEvent(viewEvent);
                            queueEventWithoutFiringImplicitServices(viewEvent);
                        }
                    }
                }

                function generateTagBasedMap() {
                    var tagBasedMap = getTagBasedMap(map);
                    window.nbatag_tealiumCmpIntegration.tagBasedMap = tagBasedMap;
                    return tagBasedMap;
                }

                function newUtagHandlerTrigger(a, b, c) {
                    var isPureConsentEvent = a === nameOfConsentPollingEvent && !b && !c;
                    var isNoviewSet = window.nbatag_tealiumCmpIntegration.isNoviewSet || true;
                    var consentedServices = getCurrentConsentDecision();
                    var consentType = (consentedServices && consentedServices.type) || "none";
                    var isCmpReady = consentType === "implicit" || consentType === "explicit";
                    var isTealiumReady = window.nbatag_tealiumCmpIntegration.isTiqReady || (window.nbatag && window.nbatag.handler && window.nbatag.handler.iflag === 1) || (window.nbatag && window.nbatag.PINITCalled === true);
                    if (isTealiumReady) {
                        window.nbatag_tealiumCmpIntegration.isTiqReady = true;
                    }
                    if (!isPureConsentEvent) {
                        logger("nbatag.handler.trigger called with:\n\n" + JSON.stringify(arguments, null, 2));
                        b = b || {};
                        b[nameOfEventIdString] = b[nameOfEventIdString] || storeOriginalEvent(a, b, c);
                    }
                    if (!isCmpReady && !isTealiumReady) {
                        consentedServices.type = "tealium-and-cmp-loading";
                        logger("Waiting for CMP and Tealium to be ready, queueing early event.");
                        queueEarlyEvent(a, b, c);
                        return false;
                    } else if (!isCmpReady) {
                        consentedServices.type = "cmp-loading";
                        logger("CMP is still loading, queueing early event");
                        queueEarlyEvent(a, b, c);
                        return false;
                    } else if (!isTealiumReady) {
                        consentedServices.type = "tealium-still-loading";
                        logger("Tealium iQ is still loading, queueing early event");
                        queueEarlyEvent(a, b, c);
                        return false;
                    }
                    var hasTagUidArray = c && typeof c === "object" && c.uids && window.nbatag.ut.typeOf(c.uids) === "array";
                    var uidMap = generateTagBasedMap();
                    var allowedTagUids = [];
                    var blockedTagUids = [];
                    var assignedPurposeIds;
                    var tagUid;
                    var hasConsent;
                    if (hasTagUidArray) {
                        for (var i = 0; i < c.uids.length; i++) {
                            tagUid = c.uids[i];
                            assignedPurposeIds = uidMap[tagUid] || "(missing)";
                            hasConsent = nbatag.loader.cfg[tagUid] && nbatag.loader.cfg[tagUid].consent === 1;
                            if (hasConsent) {
                                allowedTagUids.push(tagUid);
                            } else {
                                blockedTagUids.push(tagUid);
                            }
                        }
                        c.originalUids = c.uids.slice();
                        c.uids = allowedTagUids.slice();
                        c.blockedTagUids = blockedTagUids.slice();
                        logger("Call included tagUid array:\n\n" +
                            JSON.stringify(c.originalUids) +
                            "\n\nwhich was replaced by the filtered version (after consent and refire considerations):\n\n" +
                            JSON.stringify(c.uids));
                    }
                    if (consentType === "explicit") {
                        processEarlyQueue();
                        processImplicitQueue();
                        triggerTiqLoad();
                        if (!isPureConsentEvent) {
                            return window.nbatag.handler.trigger_old(a, b, c);
                        }
                    } else if (consentType === "implicit") {
                        processEarlyQueue();
                        triggerTiqLoad();
                        window.nbatag_tealiumCmpIntegration.implicitServices = consentedServices;
                        if (!isNoviewSet && isTealiumReady && !window.nbatag_tealiumCmpIntegration.alreadyFiredInitialViewEvent) {
                            window.nbatag_tealiumCmpIntegration.alreadyFiredInitialViewEvent = true;
                            queueEventAndFireImplicitServices("view", window.nbatag.handler.C(window.nbatag.data));
                        }
                        if (!isPureConsentEvent) {
                            return queueEventAndFireImplicitServices(a, b, c);
                        }
                    } else if (consentType === "missing-map") {
                        logger("Something went wrong - all tags were blocked because no consent map was found for the active setting ID.");
                        return false;
                    } else if (consentType === "missing-tiq-consent") {
                        logger('Something went wrong - all tags were blocked because no consent was found for "' +
                            tiqGroupName +
                            '", configured Tealium iQ name.\n\nConsent found: ' +
                            JSON.stringify(consentedServices, null, 2));
                        return false;
                    } else {
                        logger("Something went wrong - all tags were blocked because the consent response was not understood.");
                        return false;
                    }
                }
                var dequeuingInterval = 150;

                function processEarlyQueue() {
                    if (window.nbatag_tealiumCmpIntegration.alreadyProcessingEarlyQueue !== true) {
                        window.nbatag_tealiumCmpIntegration.earlyEventQueue = window.nbatag_tealiumCmpIntegration.earlyEventQueue || [];
                        var count = 1;
                        var trackCallGenerator = function(event) {
                            return function() {
                                window.nbatag.track(event);
                            };
                        };
                        while (window.nbatag_tealiumCmpIntegration.earlyEventQueue.length > 0) {
                            window.nbatag_tealiumCmpIntegration.alreadyProcessingEarlyQueue = true;
                            var queuedEvent = window.nbatag_tealiumCmpIntegration.earlyEventQueue.shift();
                            queuedEvent.data[nameOfProcessedGroupArray] = [];
                            logger("Processing queued early event for currently consented tags: " + JSON.stringify(queuedEvent, null, 2));
                            var trackCall = trackCallGenerator(queuedEvent);
                            window.setTimeout(trackCall, count * dequeuingInterval);
                            count++;
                        }
                    }
                }

                function processImplicitQueue() {
                    var count = 1;
                    var trackCallGenerator = function(event) {
                        return function() {
                            var originalEventCopy = JSON.parse(JSON.stringify(window.nbatag_tealiumCmpIntegration.originalEvents[event.data[nameOfEventIdString]]));
                            originalEventCopy.data[nameOfImplicitQueueMarker] = 1;
                            return window.nbatag.track(originalEventCopy);
                        };
                    };
                    var alreadyLogged = false;
                    if (window.nbatag_tealiumCmpIntegration.alreadyProcessingImplicitQueue !== true) {
                        window.nbatag_tealiumCmpIntegration.implicitEventQueue = window.nbatag_tealiumCmpIntegration.implicitEventQueue || [];
                        while (window.nbatag_tealiumCmpIntegration.implicitEventQueue.length > 0) {
                            if (!alreadyLogged) {
                                alreadyLogged = true;
                                logger("Explicit consent tracking request received - processing past implicitly tracked events (" +
                                    window.nbatag_tealiumCmpIntegration.implicitEventQueue.length +
                                    ") for any new explicit tags.");
                            }
                            window.nbatag_tealiumCmpIntegration.alreadyProcessingImplicitQueue = true;
                            var queuedEvent = window.nbatag_tealiumCmpIntegration.implicitEventQueue.shift();
                            logger("Triggering event for explicitly-consented tags: " + JSON.stringify(queuedEvent));
                            var trackCall = trackCallGenerator(queuedEvent);
                            window.setTimeout(trackCall, count * dequeuingInterval);
                            count++;
                        }
                    }
                }

                function storeOriginalEvent(a, b, c) {
                    a = a || {};
                    if (typeof b === "object") {
                        b = JSON.parse(JSON.stringify(b));
                    }
                    if (typeof a === "string") {
                        a = {
                            event: a,
                            data: b || {},
                            cfg: c
                        };
                    }
                    var event_id = String(Date.now()) + String(Math.round(Date.now() * Math.random() * 10000));
                    a.data[nameOfEventIdString] = event_id;
                    window.nbatag_tealiumCmpIntegration.originalEvents = window.nbatag_tealiumCmpIntegration.originalEvents || {};
                    window.nbatag_tealiumCmpIntegration.originalEvents[event_id] = a;
                    logger("Stored original event " + event_id + "!");
                    return event_id;
                }

                function queueEarlyEvent(a, b, c) {
                    a = a || {};
                    if (typeof b === "object") {
                        b = JSON.parse(JSON.stringify(b));
                    }
                    if (typeof a === "string") {
                        a = {
                            event: a,
                            data: b || {},
                            cfg: c
                        };
                    }
                    a.data[nameOfEventIdString] = a.data[nameOfEventIdString] || storeOriginalEvent(a, b, c);
                    window.nbatag_tealiumCmpIntegration.earlyEventQueue = window.nbatag_tealiumCmpIntegration.earlyEventQueue || [];
                    window.nbatag_tealiumCmpIntegration.earlyEventQueue.push(a);
                    logger("Queued early event!");
                }

                function queueEventWithoutFiringImplicitServices(a, b, c) {
                    a = a || {};
                    if (typeof b === "object") {
                        b = JSON.parse(JSON.stringify(b));
                    }
                    if (typeof a === "string") {
                        a = {
                            event: a,
                            data: b || {},
                            cfg: c
                        };
                    }
                    a.data[nameOfEventIdString] = a.data[nameOfEventIdString] || storeOriginalEvent(a, b, c);
                    var newUids;
                    if (a && a.cfg && window.nbatag.ut.typeOf(a.cfg.uids) === "array") {
                        newUids = a.cfg.blockedTagUids.slice();
                        for (var i = 0; i < refiringAllowed.length; i++) {
                            if (a.cfg.originalUids && a.cfg.originalUids.indexOf(refiringAllowed[i]) !== -1 && newUids.indexOf(refiringAllowed[i]) === -1 && (b[nameOfUnprocessedGroupArray] && b[nameOfUnprocessedGroupArray].length > 0)) {
                                newUids.push(refiringAllowed[i]);
                            }
                        }
                        a.cfg.uids = newUids;
                    }
                    delete a.data[nameOfProcessedGroupArray];
                    delete a.data[nameOfFullGroupArray];
                    delete a.data[nameOfUnprocessedGroupArray];
                    window.nbatag_tealiumCmpIntegration.implicitEventQueue = window.nbatag_tealiumCmpIntegration.implicitEventQueue || [];
                    if (window.nbatag_tealiumCmpIntegration.cmpCheckIfOptInModel()) {
                        window.nbatag_tealiumCmpIntegration.implicitEventQueue.push(a);
                    }
                }

                function queueEventAndFireImplicitServices(a, b, c) {
                    window.nbatag.handler.trigger_old(a, b, c);
                    logger("Implicit consent tracking request fired (or queued, if nbatag hasn't loaded).");
                    return queueEventWithoutFiringImplicitServices(a, b, c);
                }

                function getTagBasedMap(map) {
                    if (typeof map !== "object") return {};
                    var settingsId = cmpFetchCurrentLookupKey() || "";
                    if (typeof settingsId !== "string" || settingsId === "") return {};
                    var settingSpecificMap = map[settingsId] || {};
                    var purposeIds = Object.keys(settingSpecificMap);
                    var uidMap = {};
                    for (var i = 0; i < purposeIds.length; i++) {
                        for (var j = 0; j < settingSpecificMap[purposeIds[i]].length; j++) {
                            uidMap[settingSpecificMap[purposeIds[i]][j]] = uidMap[settingSpecificMap[purposeIds[i]][j]] || []
                            uidMap[settingSpecificMap[purposeIds[i]][j]].push(purposeIds[i]);
                        }
                    }
                    Object.keys(uidMap).forEach((tag) => {
                        uidMap[tag] = uidMap[tag].join(',')
                    })
                    return uidMap;
                }

                function recheckForCmpAndConsent() {
                    var newConsentResponse = cmpFetchCurrentConsentDecision();
                    window.nbatag_tealiumCmpIntegration.alreadyPolling = false;
                    reactToCmpResponse(newConsentResponse);
                }

                function getCurrentConsentDecision() {
                    var freshConsent = cmpFetchCurrentConsentDecision();
                    return buildConsentDecisionFromRawCmpOutput(freshConsent);
                }

                function logger(message, showOutsideDebugMode) {
                    if (typeof tealiumEnvironment === "undefined" || tealiumEnvironment === "prod") {
                        showOutsideDebugMode = false;
                    }
                    if (showOutsideDebugMode || tiqInDebugMode) {
                        message = "\n" + message + "\n";
                        var formattedArr = [];
                        formattedArr.push("****************");
                        var messageArr = message.split("\n");
                        messageArr.forEach(function(messageLine) {
                            formattedArr.push("*  " + messageLine);
                        });
                        formattedArr.push("****************");
                        var outputString = formattedArr.join("\n");
                        console.log(outputString);
                    }
                }

                function stopTiq() {
                    window.nbatag_cfg_ovrd = window.nbatag_cfg_ovrd || {};
                    window.nbatag_cfg_ovrd.noload = true;
                }

                function triggerTiqLoad() {
                    if (!(window.nbatag && window.nbatag.loader && window.nbatag.loader.PINIT)) {
                        return true;
                    }
                    if (!window.nbatag.handler || !window.nbatag.handler.iflag) {
                        window.nbatag.cfg.noload = false;
                        if (!window.nbatag.PINITCalled) {
                            window.nbatag.loader.rd_flag = undefined;
                            window.nbatag.loader.PINIT();
                            for (var i in window.nbatag.loader.GV(window.nbatag.loader.cfg)) {
                                var tag = window.nbatag.loader.cfg[i];
                                if (tag.load === 4 && tag.wait === 0) {
                                    window.nbatag.loader.LOAD(i);
                                }
                            }
                            window.nbatag.PINITCalled = true;
                        }
                        return true;
                    }
                    return false;
                }

                function triggerOrQueue() {
                    var successfullyTriggeredLoadIfNeeded = triggerTiqLoad();
                    if (!successfullyTriggeredLoadIfNeeded) {
                        return window.nbatag.handler.trigger(nameOfConsentPollingEvent);
                    }
                }

                function getTealiumEnvironment() {
                    var allScripts = document.getElementsByTagName("script");
                    var re = /\/([^/]*)\/nbatag\.js(\?.*)*$/;
                    for (var i = 0; i < allScripts.length; i++) {
                        var result = re.exec(allScripts[i].src);
                        if (result && result[1]) {
                            return result[1];
                        }
                    }
                    return "prod";
                }
                if (window.nbatag_cfg_ovrd && window.nbatag_cfg_ovrd.noload === true) return false;
                logger("TiQ CMP integration active: " +
                    window.nbatag_tealiumCmpIntegration.cmpName +
                    (tiqInDebugMode ? "\n\nDEBUGGING TIP: Use /SENDING|\\*\\*\\*\\*/ in the browser console as the 'filter' to show only CMP and tag send notifications." : "\n\nActivate TiQ Debug Mode for more details: https://docs.tealium.com/platforms/javascript/debugging/"));
                overrideUtagFunctions();
                var data = window.nbatag.loader.GV(window.nbatag_data);
                window.nbatag.cl = {
                    "_all_": 1
                };
                window.nbatag.loader.rd_flag = 1;
                window.nbatag.loader.RD(data);
                window.nbatag.loader.loadrules(data);
                window.nbatag.cl = undefined;
                var cmpResponse = cmpFetchCurrentConsentDecision();
                reactToCmpResponse(cmpResponse);
            })(window);
        }
    } catch (e) {
        nbatag.DB(e)
    }
    if (typeof nbatag_cfg_ovrd != 'undefined') {
        for (nbatag._i in nbatag.loader.GV(nbatag_cfg_ovrd)) nbatag.cfg[nbatag._i] = nbatag_cfg_ovrd[nbatag._i]
    };
    nbatag.loader.PINIT = function(a, b, c) {
        nbatag.DB("Pre-INIT");
        if (nbatag.cfg.noload) {
            return;
        }
        try {
            this.GET();
            if (nbatag.handler.RE('view', nbatag.data, "blr")) {
                nbatag.handler.LR(nbatag.data);
            }
        } catch (e) {
            nbatag.DB(e)
        };
        a = this.cfg;
        c = 0;
        for (b in this.GV(a)) {
            if (a[b].block == 1 || (a[b].load > 0 && (typeof a[b].src != 'undefined' && a[b].src != ''))) {
                a[b].block = 1;
                c = 1;
                this.bq[b] = 1;
            }
        }
        if (c == 1) {
            for (b in this.GV(a)) {
                if (a[b].block) {
                    a[b].id = b;
                    if (a[b].load == 4) a[b].load = 1;
                    a[b].cb = function() {
                        var d = this.uid;
                        nbatag.loader.cfg[d].cbf = 1;
                        nbatag.loader.LOAD(d)
                    };
                    this.AS(a[b]);
                }
            }
        }
        if (c == 0) this.INIT();
    };
    nbatag.loader.INIT = function(a, b, c, d, e) {
        nbatag.DB('nbatag.loader.INIT');
        if (this.ol == 1) return -1;
        else this.ol = 1;
        if (nbatag.cfg.noview != true) nbatag.handler.RE('view', nbatag.data, "alr");
        nbatag.rpt.ts['i'] = new Date();
        d = this.cfgsort;
        for (a = 0; a < d.length; a++) {
            e = d[a];
            b = this.cfg[e];
            b.id = e;
            if (b.block != 1) {
                if (nbatag.loader.bk[b.id] || ((nbatag.cfg.readywait || nbatag.cfg.noview) && b.load == 4)) {
                    this.f[b.id] = 0;
                    nbatag.loader.LOAD(b.id)
                } else if (b.wait == 1 && nbatag.loader.rf == 0) {
                    nbatag.DB('nbatag.loader.INIT: waiting ' + b.id);
                    this.wq.push(b)
                    this.f[b.id] = 2;
                } else if (b.load > 0) {
                    nbatag.DB('nbatag.loader.INIT: loading ' + b.id);
                    this.lq.push(b);
                    this.AS(b);
                }
            }
        }
        if (this.wq.length > 0) nbatag.loader.EV('', 'ready', function(a) {
            if (nbatag.loader.rf == 0) {
                nbatag.DB('READY:nbatag.loader.wq');
                nbatag.loader.rf = 1;
                nbatag.loader.WQ();
            }
        });
        else if (this.lq.length > 0) nbatag.loader.rf = 1;
        else if (this.lq.length == 0) nbatag.loader.END();
        return 1
    };
    nbatag.loader.EV('', 'ready', function(a) {
        if (nbatag.loader.efr != 1) {
            nbatag.loader.efr = 1;
            try {
                try {
                    if (1) {
                        window._satellite = window._satellite || {};
                        if ((typeof window._satellite.track == "function") && (window._satellite.track.toString().indexOf("nbatag") < 0))
                            window.origSatelliteTrack = window._satellite.track;
                        window._satellite.track = function(event_string, event_obj) {
                            var temp = {};
                            if (event_obj) {
                                if (typeof event_obj === 'object') {
                                    if (typeof event_obj.eventName != "undefined") {
                                        temp = {
                                            reportingEvtName: event_obj.eventName
                                        };
                                        delete event_obj.eventName;
                                    }
                                    Object.assign(temp, event_obj);
                                } else {
                                    temp[event_obj] = event_obj;
                                }
                            }
                            if (window.includedDcrEvents && window.includedDcrEvents.length) {
                                var includeEvent = window.includedDcrEvents.includes(event_string);
                                if (event_string && includeEvent) {
                                    let obj = Object.assign({}, (typeof digitalData === 'object' && digitalData !== null ? digitalData : {}), temp);
                                    obj.direct_call_event = event_string;
                                    if (event_string === "page view") {
                                        nbatag.DB("====> Direct Call Page View <====");
                                        nbatag.view(teal.flattenObject(obj));
                                    } else {
                                        obj.interactionIdentifier = temp.interactionIdentifier ? temp.interactionIdentifier : temp['data-id'] ? temp['data-id'] : "";
                                        nbatag.DB("====> Direct Call Link Event <====");
                                        nbatag.link(teal.flattenObject(obj));
                                    }
                                }
                            }
                            if (window.nbaSatellite && window.nbaSatellite !== window._satellite.track) {
                                window.nbaSatellite(event_string, event_obj);
                            }
                        };
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
            try {
                try {
                    if (1) {
                        if ((typeof __NEXT_DATA__ != "undefined") && (typeof __NEXT_DATA__.props != "undefined")) {
                            if ((typeof __NEXT_DATA__.props.clientConfigSettings != "undefined") && (typeof __NEXT_DATA__.props.clientConfigSettings.features != "undefined")) {
                                if (typeof __NEXT_DATA__.props.clientConfigSettings.features.analytics != "undefined") {
                                    if (typeof __NEXT_DATA__.props.clientConfigSettings.features.analytics.disableAmplitude != "undefined")
                                        window.disableAmplitude = String(__NEXT_DATA__.props.clientConfigSettings.features.analytics.disableAmplitude);
                                }
                            }
                        }
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
            try {
                try {
                    if (1) {
                        if ((typeof NEXT_DATA != "undefined") && (typeof NEXT_DATA.props != "undefined")) {
                            if ((typeof NEXT_DATA.props.clientConfigSettings != "undefined") && (typeof NEXT_DATA.props.clientConfigSettings.features != "undefined")) {
                                if (typeof NEXT_DATA.props.clientConfigSettings.features.analytics != "undefined") {
                                    if (typeof NEXT_DATA.props.clientConfigSettings.features.analytics.disableBraze != "undefined")
                                        window.disableBraze = String(NEXT_DATA.props.clientConfigSettings.features.analytics.disableBraze);
                                    if (typeof NEXT_DATA.props.clientConfigSettings.features.analytics.disableKochava != "undefined")
                                        window.disableKochava = String(NEXT_DATA.props.clientConfigSettings.features.analytics.disableKochava);
                                }
                            }
                        }
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
            try {
                try {
                    if (1) {
                        window.checkForPageLoad = function() {
                            if ((location.pathname.indexOf("/watch/embed/") < 0) && (location.pathname.indexOf("/embed2") < 0)) {
                                if ((typeof digitalData !== "object") || (typeof digitalData.user !== "object") || (typeof digitalData.user.fetchingNbaProfileStatus === "undefined") || (digitalData.user.fetchingNbaProfileStatus !== "complete")) {
                                    let userStateCheck = 0;
                                    const maxAttempts = 3;
                                    const timer = setInterval(function() {
                                        userStateCheck++;
                                        if ((typeof digitalData === "object") && (typeof digitalData.user === "object") && (typeof digitalData.user.fetchingNbaProfileStatus !== "undefined") && (digitalData.user.fetchingNbaProfileStatus === "complete")) {
                                            window.nbatag_data = teal.flattenObject(digitalData);
                                            nbatag.view(window.nbatag_data);
                                            clearInterval(timer);
                                        } else if (userStateCheck >= maxAttempts) {
                                            if (typeof digitalData === "object") {
                                                if (typeof digitalData.user === "object" && digitalData.user.fetchingNbaProfileStatus !== "complete") {
                                                    let dataMinusUser = JSON.parse(JSON.stringify(digitalData));
                                                    delete dataMinusUser.user;
                                                    window.nbatag_data = teal.flattenObject(dataMinusUser);
                                                } else {
                                                    window.nbatag_data = teal.flattenObject(digitalData);
                                                }
                                                nbatag.view(teal.flattenObject(window.nbatag_data));
                                            } else {
                                                nbatag.view();
                                            }
                                            clearInterval(timer);
                                        }
                                    }, 500);
                                } else {
                                    window.nbatag_data = teal.flattenObject(digitalData);
                                    nbatag.view(window.nbatag_data);
                                }
                            }
                        };
                        window.checkForPageLoad();
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
            try {
                try {
                    if (1) {
                        document.addEventListener('mousedown', function(event) {
                            let targetElement = event.target.closest('[data-track]');
                            let anchor = event.target.closest('a');
                            if (targetElement !== null) {
                                var temp = {
                                    "dataTrackEventType": targetElement.getAttribute("data-track"),
                                    "dataTrackEvent": true,
                                    "premiumMedia": targetElement.getAttribute("data-premium") || "",
                                    "league_pass_feed": targetElement.getAttribute("data-stream") || "",
                                    "interactionIdentifier": targetElement.getAttribute("data-id") || "",
                                    "interactionText": targetElement.getAttribute("data-text") || "",
                                    "interactionPosition": targetElement.getAttribute("data-section-pos") || "",
                                    "interactionContentID": targetElement.getAttribute("data-content-id") || "",
                                    "interactionSection": targetElement.getAttribute("data-section") || "",
                                    "interactionType": targetElement.getAttribute("data-type") || "",
                                    "interactionContentType": targetElement.getAttribute("data-content-type") || "",
                                    "contentPosition": targetElement.getAttribute("data-pos") || "",
                                    "interactionState": targetElement.getAttribute("data-state") || "",
                                    "associated_partner": (targetElement.getAttribute("data-id") && targetElement.getAttribute("data-id").indexOf("linked-accounts") > -1 && targetElement.getAttribute("data-content")) ? targetElement.getAttribute("data-content") : "",
                                    "interactionContent": (targetElement.getAttribute("data-id") && targetElement.getAttribute("data-id").indexOf("linked-accounts") < 0 && targetElement.getAttribute("data-content")) ? targetElement.getAttribute("data-content") : "",
                                    "tealium_event": (targetElement.getAttribute("data-id") && targetElement.getAttribute("data-id").indexOf("nba:news:collection:") === 0 && ((typeof targetElement.getAttribute("data-type") === "undefined") || (targetElement.getAttribute("data-type") === ""))) ? "nba:news:collection" : ""
                                };
                                let obj = Object.assign({}, (typeof digitalData === 'object' && digitalData !== null ? digitalData : {}), temp);
                                nbatag.link(teal.flattenObject(obj));
                            }
                            let fExtList = ["avi", "css", "csv", "doc", "docx", "eps", "exe", "jpg", "js", "m4v", "mov", "mp3", "pdf", "png", "ppt", "pptx", "rar", "svg", "tab", "txt", "vsd", "vxd", "wav", "wma", "wmv", "xls", "xlsx", "xml", "zip"],
                                host = "",
                                eventProps = {},
                                href = (anchor !== null) ? anchor.getAttribute("href") : "";
                            if ((href !== null) && (href !== "") && ((href.indexOf("http://") === 0) || (href.indexOf("https://") === 0))) {
                                host = href.split("/")[2];
                                host = host.toLowerCase();
                                let ipRegex = new RegExp('(?:[0-9]{1,3}\.){3}[0-9]{1,3}');
                                if ((host.indexOf("localhost") == -1) && (!ipRegex.test(host)) && (host.slice(-8) != ".nba.com") && (host != "nba.com")) {
                                    eventProps["exit_link"] = href;
                                    eventProps["eventPageName"] = ((typeof nbatag_data == "object") && (typeof nbatag_data.eventPageName == "string")) ? nbatag_data.eventPageName : ((typeof nbatag_data == "object") && (typeof nbatag_data.tealium_event == "string")) ? nbatag_data["tealium_event"].replace("Page View: ", "") : "";
                                    eventProps["cleaned_url"] = location.href.split("?")[0].split("#")[0];
                                    eventProps.tealium_event = "Offsite Exit Link";
                                    if ((typeof temp != "undefined") && (typeof temp.interactionContent != "undefined"))
                                        eventProps.interactionContent = temp.interactionContent;
                                    if ((typeof window.digitalData != "undefined") && (typeof window.digitalData.page != "undefined") && (typeof window.digitalData.page.content != "undefined")) {
                                        if (typeof window.digitalData.page.content.gameID != "undefined")
                                            eventProps.gameID = window.digitalData.page.content.gameID;
                                        if (typeof window.digitalData.page.content.gameMatchup != "undefined")
                                            eventProps.gameMatchup = window.digitalData.page.content.gameMatchup;
                                    }
                                    nbatag.link(eventProps);
                                }
                                eventProps = {};
                                let hrefURL = href.split("?")[0];
                                hrefURL = hrefURL.split("#")[0];
                                let fnURL = hrefURL.split("/").pop();
                                let fnURLOrig = fnURL;
                                fnURL = fnURL.toLowerCase();
                                if (fnURL != host) {
                                    let fnExt = (fnURL.match(/\.([^.]*?)(?=\?|#|$)/) || [])[1];
                                    if (typeof fnExt !== "undefined")
                                        if (fExtList.indexOf(fnExt) > -1) {
                                            eventProps["download_link"] = hrefURL;
                                            eventProps["download_file"] = fnURLOrig;
                                            eventProps["eventPageName"] = ((typeof nbatag_data == "object") && (typeof nbatag_data.eventPageName == "string")) ? nbatag_data.eventPageName : ((typeof nbatag_data == "object") && (typeof nbatag_data.tealium_event == "string")) ? nbatag_data["tealium_event"].replace("Page View: ", "") : "";
                                            eventProps["cleaned_url"] = location.href.split("?")[0].split("#")[0];
                                            eventProps.tealium_event = "Download Link";
                                            nbatag.link(eventProps);
                                        }
                                }
                            }
                        });
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
            try {
                try {
                    if (typeof nbatag.data['js_page.window.DataLayerHelper'] == 'undefined') {
                        (function() {
                            'use strict';
                            var f = /\[object (Boolean|Number|String|Function|Array|Date|RegExp|Arguments)\]/;

                            function g(a) {
                                return null == a ? String(a) : (a = f.exec(Object.prototype.toString.call(Object(a)))) ? a[1].toLowerCase() : "object"
                            }

                            function m(a, b) {
                                return Object.prototype.hasOwnProperty.call(Object(a), b)
                            }

                            function n(a) {
                                if (!a || "object" != g(a) || a.nodeType || a == a.window) return !1;
                                try {
                                    if (a.constructor && !m(a, "constructor") && !m(a.constructor.prototype, "isPrototypeOf")) return !1
                                } catch (c) {
                                    return !1
                                }
                                for (var b in a);
                                return void 0 === b || m(a, b)
                            };

                            function p(a, b) {
                                var c = {},
                                    d = c;
                                a = a.split(".");
                                for (var e = 0; e < a.length - 1; e++) d = d[a[e]] = {};
                                d[a[a.length - 1]] = b;
                                return c
                            }

                            function q(a, b) {
                                var c = !a._clear,
                                    d;
                                for (d in a)
                                    if (m(a, d)) {
                                        var e = a[d];
                                        "array" === g(e) && c ? ("array" === g(b[d]) || (b[d] = []), q(e, b[d])) : n(e) && c ? (n(b[d]) || (b[d] = {}), q(e, b[d])) : b[d] = e
                                    }
                                delete b._clear
                            };

                            function r(a, b, c) {
                                b = void 0 === b ? {} : b;
                                "function" === typeof b ? b = {
                                    listener: b,
                                    listenToPast: void 0 === c ? !1 : c,
                                    processNow: !0,
                                    commandProcessors: {}
                                } : b = {
                                    listener: b.listener || function() {},
                                    listenToPast: b.listenToPast || !1,
                                    processNow: void 0 === b.processNow ? !0 : b.processNow,
                                    commandProcessors: b.commandProcessors || {}
                                };
                                this.a = a;
                                this.l = b.listener;
                                this.j = b.listenToPast;
                                this.g = this.i = !1;
                                this.c = {};
                                this.f = [];
                                this.b = b.commandProcessors;
                                this.h = u(this);
                                var d = this.a.push,
                                    e = this;
                                this.a.push = function() {
                                    var k = [].slice.call(arguments, 0),
                                        l = d.apply(e.a, k);
                                    v(e, k);
                                    return l
                                };
                                b.processNow && this.process()
                            }
                            r.prototype.process = function() {
                                this.registerProcessor("set", function() {
                                    var c = {};
                                    1 === arguments.length && "object" === g(arguments[0]) ? c = arguments[0] : 2 === arguments.length && "string" === g(arguments[0]) && (c = p(arguments[0], arguments[1]));
                                    return c
                                });
                                this.i = !0;
                                for (var a = this.a.length, b = 0; b < a; b++) v(this, [this.a[b]], !this.j)
                            };
                            r.prototype.get = function(a) {
                                var b = this.c;
                                a = a.split(".");
                                for (var c = 0; c < a.length; c++) {
                                    if (void 0 === b[a[c]]) return;
                                    b = b[a[c]]
                                }
                                return b
                            };
                            r.prototype.flatten = function() {
                                this.a.splice(0, this.a.length);
                                this.a[0] = {};
                                q(this.c, this.a[0])
                            };
                            r.prototype.registerProcessor = function(a, b) {
                                a in this.b || (this.b[a] = []);
                                this.b[a].push(b)
                            };

                            function v(a, b, c) {
                                c = void 0 === c ? !1 : c;
                                if (a.i && (a.f.push.apply(a.f, b), !a.g))
                                    for (; 0 < a.f.length;) {
                                        b = a.f.shift();
                                        if ("array" === g(b)) a: {
                                            var d = a.c;g(b[0]);
                                            for (var e = b[0].split("."), k = e.pop(), l = b.slice(1), h = 0; h < e.length; h++) {
                                                if (void 0 === d[e[h]]) break a;
                                                d = d[e[h]]
                                            }
                                            try {
                                                d[k].apply(d, l)
                                            } catch (w) {}
                                        }
                                        else if ("arguments" === g(b)) {
                                            e = a;
                                            k = [];
                                            l = b[0];
                                            if (e.b[l])
                                                for (d = e.b[l].length, h = 0; h < d; h++) k.push(e.b[l][h].apply(e.h, [].slice.call(b, 1)));
                                            a.f.push.apply(a.f, k)
                                        } else if ("function" == typeof b) try {
                                                b.call(a.h)
                                            } catch (w) {} else if (n(b))
                                                for (var t in b) q(p(t, b[t]), a.c);
                                            else continue;
                                        c || (a.g = !0, a.l(a.c, b), a.g = !1)
                                    }
                            }
                            r.prototype.registerProcessor = r.prototype.registerProcessor;
                            r.prototype.flatten = r.prototype.flatten;
                            r.prototype.get = r.prototype.get;
                            r.prototype.process = r.prototype.process;
                            window.DataLayerHelper = r;

                            function u(a) {
                                return {
                                    set: function(b, c) {
                                        q(p(b, c), a.c)
                                    },
                                    get: function(b) {
                                        return a.get(b)
                                    }
                                }
                            };
                        })();
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
            try {
                try {
                    if ((nbatag.data['ut.profile'].toString().toLowerCase() != 'wnba-leaguepass'.toLowerCase() && nbatag.data['ut.profile'].toString().toLowerCase() != 'all-star-vote'.toLowerCase())) {
                        function processAppEvent(model, evt) {
                            if ((typeof evt !== "undefined") && (typeof evt.eventType !== "undefined")) {
                                if (typeof evt.eventData !== "undefined") {
                                    if ((typeof evt.eventData.customData !== "undefined") && (typeof evt.eventData.customData.eventName !== "undefined")) {
                                        evt.eventData.customData.reportingEvtName = evt.eventData.customData.eventName;
                                        delete evt.eventData.customData.eventName;
                                    }
                                    if ((typeof evt.eventData.eventDigitalData !== "undefined") && (typeof evt.eventData.eventDigitalData.eventName !== "undefined")) {
                                        evt.eventData.eventDigitalData.reportingEvtName = evt.eventData.eventDigitalData.eventName;
                                        delete evt.eventData.eventDigitalData.eventName;
                                    }
                                }
                                if (Object.keys(teal.replace_keys).length === 0) {
                                    teal.replace_keys = {
                                        "customData": "",
                                        "eventDigitalData": "",
                                        "eventData": ""
                                    };
                                }
                                var tealEventData = teal.flattenObject(evt);
                                tealEventData.eventType = evt.eventType;
                                if (tealEventData.eventType === "pageLoad" || tealEventData.eventType === "modalView")
                                    nbatag.view(tealEventData);
                                else
                                    nbatag.link(tealEventData);
                                window.appEventDataLog.push(evt);
                                if (window.appEventDataLog.length > 100)
                                    window.appEventDataLog.splice(0, 1);
                                if (window.sessionStorage)
                                    window.sessionStorage.setItem("appEventDataLog", JSON.stringify(window.appEventDataLog));
                            }
                        }
                        window.appEventData = window.appEventData || [];
                        window.appEventDataLog = JSON.parse(window.sessionStorage.getItem("appEventDataLog")) || [];
                        window.appEventHelper = new DataLayerHelper(window.appEventData, {
                            listener: processAppEvent,
                            listenToPast: true
                        });
                    }
                } catch (e) {
                    nbatag.DB(e)
                }
            } catch (e) {
                nbatag.DB(e)
            };
        }
    })
    if (nbatag.cfg.readywait || nbatag.cfg.waittimer) {
        nbatag.loader.EV('', 'ready', function(a) {
            if (nbatag.loader.rf == 0) {
                nbatag.loader.rf = 1;
                nbatag.cfg.readywait = 1;
                nbatag.DB('READY:nbatag.cfg.readywait');
                setTimeout(function() {
                    nbatag.loader.PINIT()
                }, nbatag.cfg.waittimer || 1);
            }
        })
    } else {
        nbatag.loader.PINIT()
    }
}