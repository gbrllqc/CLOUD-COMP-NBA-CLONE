//tealium universal tag - nbatag.77 ut4.0.202602061808, Copyright 2026 Tealium.com Inc. All Rights Reserved.
if (typeof JSON !== 'object') {
    JSON = {};
}
(function() {
    'use strict';
    var rx_one = /^[\],:{}\s]*$/,
        rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
        rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
        rx_four = /(?:^|:|,)(?:\s*\[)+/g,
        rx_escapable = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

    function f(n) {
        return n < 10 ? '0' + n : n;
    }

    function this_value() {
        return this.valueOf();
    }
    if (typeof Date.prototype.toJSON !== 'function') {
        Date.prototype.toJSON = function() {
            return isFinite(this.valueOf()) ? this.getUTCFullYear() + '-' +
                f(this.getUTCMonth() + 1) + '-' + f(this.getUTCDate()) + 'T' + f(this.getUTCHours()) + ':' + f(this.getUTCMinutes()) + ':' +
                f(this.getUTCSeconds()) + 'Z' : null;
        };
        Boolean.prototype.toJSON = this_value;
        Number.prototype.toJSON = this_value;
        String.prototype.toJSON = this_value;
    }
    var gap, indent, meta, rep;

    function quote(string) {
        rx_escapable.lastIndex = 0;
        return rx_escapable.test(string) ? '"' + string.replace(rx_escapable, function(a) {
            var c = meta[a];
            return typeof c === 'string' ? c : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
        }) + '"' : '"' + string + '"';
    }

    function str(key, holder) {
        var i, k, v, length, mind = gap,
            partial, value = holder[key];
        if (value && typeof value === 'object' && typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }
        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }
        switch (typeof value) {
            case 'string':
                return quote(value);
            case 'number':
                return isFinite(value) ? String(value) : 'null';
            case 'boolean':
            case 'null':
                return String(value);
            case 'object':
                if (!value) {
                    return 'null';
                }
                gap += indent;
                partial = [];
                if (Object.prototype.toString.apply(value) === '[object Array]') {
                    length = value.length;
                    for (i = 0; i < length; i += 1) {
                        partial[i] = str(i, value) || 'null';
                    }
                    v = partial.length === 0 ? '[]' : gap ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']' : '[' + partial.join(',') + ']';
                    gap = mind;
                    return v;
                }
                if (rep && typeof rep === 'object') {
                    length = rep.length;
                    for (i = 0; i < length; i += 1) {
                        if (typeof rep[i] === 'string') {
                            k = rep[i];
                            v = str(k, value);
                            if (v) {
                                partial.push(quote(k) + (gap ? ': ' : ':') + v);
                            }
                        }
                    }
                } else {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = str(k, value);
                            if (v) {
                                partial.push(quote(k) + (gap ? ': ' : ':') + v);
                            }
                        }
                    }
                }
                v = partial.length === 0 ? '{}' : gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}' : '{' + partial.join(',') + '}';
                gap = mind;
                return v;
        }
    }
    if (typeof JSON.stringify !== 'function') {
        meta = {
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"': '\\"',
            '\\': '\\\\'
        };
        JSON.stringify = function(value, replacer, space) {
            var i;
            gap = '';
            indent = '';
            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) {
                    indent += ' ';
                }
            } else if (typeof space === 'string') {
                indent = space;
            }
            rep = replacer;
            if (replacer && typeof replacer !== 'function' && (typeof replacer !== 'object' || typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }
            return str('', {
                '': value
            });
        };
    }
}());
try {
    (function(id, loader, u) {
        try {
            u = nbatag.o[loader].sender[id] = {
                "id": id
            };
        } catch (e) {
            u = nbatag.sender[id];
        }
        nbatag.globals = window.nbatag.globals || {};
        u.toBoolean = function(val) {
            val = String(val) || "";
            return val === true || val.toLowerCase() === "true" || val.toLowerCase() === "on";
        };
        u.ev = {
            "all": 1
        };
        u.do_enrichment = function() {};
        u.deepCopy = function(input) {
            var key, copy;
            if (typeof input === "object" && input !== null) {
                if (nbatag.ut.typeOf(input) === "array") {
                    copy = [];
                } else {
                    copy = {};
                }
                for (key in input) {
                    if (typeof input[key] === "object") {
                        copy[key] = u.deepCopy(input[key]);
                    } else {
                        copy[key] = input[key];
                    }
                }
            } else {
                copy = input;
            }
            return copy;
        }
        u.get_account_profile = function(s) {
            var p;
            if (u.visitor_service_override || u.tag_config_server.indexOf("tealiumiq.com") === -1) {
                p = [u.tag_config_server.split("//")[1], u.account, u.profile]
            } else if (u.tag_config_server === u.event_url) {
                p = [s.substring(s.indexOf(u.server_domain)).split("/")[1], u.account, u.profile]
            } else {
                p = s.substring(s.indexOf(u.server_domain)).split("/");
            }
            return p;
        };

        function infixParameters(url, params) {
            var updated_url, url_parts = url.split("?");
            if (params) {
                if (url_parts[1] === undefined) {
                    updated_url = url + "?" + params;
                } else if (url_parts[1] === "") {
                    updated_url = url + params;
                } else {
                    updated_url = url_parts[0] + "?" + params + "&" + url_parts[1];
                }
            } else {
                updated_url = url;
            }
            return updated_url;
        }
        u.is_in_sample_group = function(b) {
            var group = "100";
            if (u.tag_config_sampling === "" || u.tag_config_sampling === "100") {
                return true;
            }
            if (b["cp.nbatag_main_dc_group"]) {
                group = b["cp.nbatag_main_dc_group"];
            } else {
                group = Math.floor(Math.random() * 100) + 1;
                nbatag.loader.SC("nbatag_main", {
                    "dc_group": group
                });
            }
            if (parseInt(group) <= parseInt(u.tag_config_sampling)) {
                return true;
            } else {
                return false;
            }
        };
        u.get_performance_timing = function(b) {
            var t, timing;
            var data = {};

            function subtract(val1, val2) {
                var difference = 0;
                if (val1 > val2) {
                    difference = val1 - val2;
                }
                return difference;
            }
            try {
                timing = localStorage.getItem("tealium_timing");
                t = window.performance.timing;
                if (timing !== null && timing !== "{}" && typeof b !== "undefined" && u.performance_timing_count === 0) {
                    nbatag.ut.merge(b, nbatag.ut.flatten({
                        timing: JSON.parse(timing)
                    }), 1);
                }
            } catch (e) {
                nbatag.DB(e);
                return;
            }
            u.performance_timing_count++;
            for (var k in t) {
                if ((k.indexOf("dom") === 0 || k.indexOf("load") === 0) && t[k] === 0 && u.performance_timing_count < 20) {
                    setTimeout(u.get_performance_timing, 1000);
                }
            }
            data["domain"] = location.hostname + "";
            data["pathname"] = location.pathname + "";
            data["query_string"] = ("" + location.search).substring(1);
            data["timestamp"] = (new Date()).getTime();
            data["dns"] = subtract(t.domainLookupEnd, t.domainLookupStart);
            data["connect"] = subtract(t.connectEnd, t.connectStart);
            data["response"] = subtract(t.responseEnd, t.responseStart);
            data["dom_loading_to_interactive"] = subtract(t.domInteractive, t.domLoading);
            data["dom_interactive_to_complete"] = subtract(t.domComplete, t.domInteractive);
            data["load"] = subtract(t.loadEventEnd, t.loadEventStart);
            data["time_to_first_byte"] = subtract(t.responseStart, t.connectEnd);
            data["front_end"] = subtract(t.loadEventStart, t.responseEnd);
            data["fetch_to_response"] = subtract(t.responseStart, t.fetchStart);
            data["fetch_to_complete"] = subtract(t.domComplete, t.fetchStart);
            data["fetch_to_interactive"] = subtract(t.domInteractive, t.fetchStart);
            try {
                localStorage.setItem("tealium_timing", JSON.stringify(data));
            } catch (e) {
                nbatag.DB(e);
            }
        };
        u.validateProtocol = function(address, force_ssl) {
            if (/^https?:\/\//i.test(address)) {
                if (force_ssl) {
                    if (/^http:\/\//i.test(address)) {
                        address = address.toLowerCase().replace("http", "https");
                    }
                }
            } else {
                if (/^\/\//.test(address)) {
                    if (force_ssl) {
                        address = "https:" + address;
                    } else {
                        address = location.protocol + address;
                    }
                } else {
                    if (force_ssl) {
                        address = "https://" + address;
                    } else {
                        address = location.protocol + "//" + address;
                    }
                }
            }
            return address;
        }
        u.server_domain = "tealiumiq.com";
        u.server_prefix = "";
        u.tag_config_server = "";
        u.tag_config_sampling = "100" || "100";
        if (nbatag.cfg.nbatagdb) {
            u.tag_config_sampling = "100";
        }
        u.tag_config_region = "default" || "default";
        u.region = "";
        u.performance_timing_count = 0;
        u.event_url = '//collect.tealiumiq.com/event';
        u.account = nbatag.cfg.utid.split("/")[0];
        u.data_source = "";
        u.profile = "" || nbatag.cfg.utid.split("/")[1];
        u.visitor_service_override = '';
        u.request_increment = 1;
        u.iab_v20_compliance = true;
        u.tc_string = "";
        u.use_sendBeacon = 'true';
        u.use_event_endpoint = 'false';
        u.tealium_cookie_domain = '';
        u.tealium_cookie_expiry = '';
        u.data_enrichment = "none";
        u.send_udo_variables = "true" || true;
        u.send_dom_values = "true" || true;
        u.send_cookie_values = "true" || true;
        u.send_meta_values = "true" || true;
        u.send_query_param_values = "true" || true;
        u.send_localstorage_variables = "false" || false;
        u.send_sessionstorage_variables = "false" || false;
        u.profile_specific_vid = 0;
        u.enrichment_polling = 1;
        u.enrichment_polling_delay = 500;
        u.enrichment_enabled = {};
        u.suppress_v_id_generation = false;
        u.map = {};
        u.extend = [];
        u.send = function(a, b) {
            var c, d, i;
            if (u.ev[a] || typeof u.ev["all"] !== "undefined") {
                if (a === "remote_api") {
                    nbatag.DB("Remote API event suppressed.");
                    return;
                }
                if (a === 'update_consent_cookie') {
                    nbatag.DB('Update Consent Cookie event supressed.');
                    return;
                }
                nbatag.DB("send:77:EXTENSIONS");
                nbatag.DB(b);
                c = [];
                Object.keys(nbatag.loader.GV(u.map)).forEach(function(mapping_key) {
                    if (b[mapping_key] !== undefined && b[mapping_key] !== '') {
                        var destinations = u.map[mapping_key].split(',');
                        destinations.forEach(function(parameter) {
                            u[parameter] = b[mapping_key];
                        });
                    }
                });
                nbatag.DB("send:77:MAPPINGS");
                nbatag.DB(u);
                u.use_sendBeacon = u.toBoolean(u.use_sendBeacon);
                u.use_event_endpoint = u.toBoolean(u.use_event_endpoint);
                u.send_udo_variables = u.toBoolean(u.send_udo_variables);
                u.send_cookie_values = u.toBoolean(u.send_cookie_values);
                u.send_dom_values = u.toBoolean(u.send_dom_values);
                u.send_meta_values = u.toBoolean(u.send_meta_values);
                u.send_query_param_values = u.toBoolean(u.send_query_param_values);
                u.send_localstorage_variables = u.toBoolean(u.send_localstorage_variables);
                u.send_sessionstorage_variables = u.toBoolean(u.send_sessionstorage_variables);
                if (u.tag_config_server.indexOf("-collect." + u.server_domain) > 1) {
                    u.server_prefix = u.tag_config_server.split("collect." + u.server_domain)[0];
                    if (u.tag_config_server.indexOf("/i.gif") < 0) {
                        u.tag_config_server = "https://" + [u.server_prefix + "collect." + u.server_domain, u.account, u.profile, "2", "i.gif"].join("/");
                    }
                }
                if (u.tag_config_server === "") {
                    if (u.use_event_endpoint) {
                        u.tag_config_server = u.event_url;
                    } else if (u.tag_config_region === "default") {
                        u.tag_config_server = "https://" + [u.server_prefix + "collect." + u.server_domain, u.account, u.profile, "2", "i.gif"].join("/");
                    } else {
                        u.tag_config_server = "https://" + [u.server_prefix + "collect-" + u.tag_config_region + "." + u.server_domain, u.account, u.profile, "2", "i.gif"].join("/");
                    }
                }
                if (u.tag_config_server.indexOf("-collect-") > -1) {
                    u.server_prefix = u.tag_config_server.split("collect-")[0];
                }
                if (u.tag_config_region !== "default" && u.tag_config_server.indexOf(u.server_prefix + "collect." + u.server_domain) > 0) {
                    u.tag_config_server = u.tag_config_server.replace(u.server_prefix + "collect." + u.server_domain, u.server_prefix + "collect-" + u.tag_config_region + "." + u.server_domain);
                    u.region = u.tag_config_region;
                }
                var q = u.tag_config_server.indexOf("?");
                if (q > 0 && (q + 1) == u.tag_config_server.length) {
                    u.tag_config_server = u.tag_config_server.replace("?", "");
                }
                u.server_list = u.tag_config_server.split("|");
                if (u.tealium_cookie_domain) {
                    b.tealium_cookie_domain = u.tealium_cookie_domain;
                }
                if (u.tealium_cookie_expiry) {
                    b.tealium_cookie_expiry = parseInt(u.tealium_cookie_expiry);
                }
                if (u.iab_v20_compliance === true || u.iab_v20_compliance === "true") {
                    if (typeof __tcfapi === "function") {
                        __tcfapi("getTCData", 2, function(tcData, success) {
                            if (success) {
                                u.tc_string = "gdpr=";
                                if (tcData.gdprApplies === true) {
                                    u.tc_string += "1";
                                } else if (tcData.gdprApplies === false) {
                                    u.tc_string += "0";
                                } else {
                                    u.tc_string += String(tcData.gdprApplies);
                                }
                                u.tc_string += "&gdpr_consent=" + tcData.tcString;
                                execute_send();
                            }
                        });
                    } else {
                        var frame = window;
                        var cmpFrame;
                        var cmpCallbacks = {};
                        while (frame) {
                            try {
                                if (frame.frames["__tcfapiLocator"]) {
                                    cmpFrame = frame;
                                    break;
                                }
                            } catch (error) {
                                nbatag.DB(error);
                            }
                            if (frame === window.top) {
                                break;
                            }
                            frame = frame.parent;
                        }
                        if (!cmpFrame) {
                            execute_send();
                        } else {
                            window.__tcfapi = function(cmd, version, callback, arg) {
                                var callId = String(Math.random());
                                var msg = {
                                    __tcfapiCall: {
                                        command: cmd,
                                        parameter: arg,
                                        version: version,
                                        callId: callId
                                    }
                                };
                                cmpCallbacks[callId] = callback;
                                cmpFrame.postMessage(msg, "*");
                            };
                            window.tealiumiabPostMessageHandler = function(event) {
                                var json = {};
                                try {
                                    json = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
                                } catch (error) {
                                    nbatag.DB(error);
                                }
                                var payload = json.__tcfapiReturn;
                                if (payload) {
                                    if (typeof cmpCallbacks[payload.callId] === "function") {
                                        cmpCallbacks[payload.callId](payload.returnValue, payload.success);
                                        cmpCallbacks[payload.callId] = null;
                                    }
                                }
                            };
                            window.addEventListener("message", tealiumiabPostMessageHandler, false);
                            __tcfapi("getTCData", 2, function(tcData, success) {
                                if (success) {
                                    u.tc_string = "gdpr=";
                                    if (tcData.gdprApplies === true) {
                                        u.tc_string += "1";
                                    } else if (tcData.gdprApplies === false) {
                                        u.tc_string += "0";
                                    } else {
                                        u.tc_string += String(tcData.gdprApplies);
                                    }
                                    u.tc_string += "&gdpr_consent=" + tcData.tcString;
                                    execute_send();
                                }
                            });
                        }
                    }
                } else {
                    execute_send();
                }

                function execute_send() {
                    if (u.data_source) {
                        b.tealium_datasource = u.data_source;
                    }
                    u.make_enrichment_request = false;
                    if (!u.is_in_sample_group(b)) {
                        return false;
                    }
                    u.get_performance_timing(b);
                    for (i = 0; i < u.server_list.length; i++) {
                        if (u.server_list[i].toLowerCase().indexOf("http") === -1) {
                            u.server_list[i] = u.validateProtocol(u.server_list[i], true);
                        }
                        if (u.enrichment_enabled[i] !== false) {
                            u.enrichment_enabled[u.server_list[i]] = true;
                        }
                    }
                    if (u.server_list.length > 1) {
                        u.profile_specific_vid = 1;
                    }
                    u.data = nbatag.datacloud || {};
                    u.data["loader.cfg"] = {};
                    for (d in nbatag.loader.GV(nbatag.loader.cfg)) {
                        if (nbatag.loader.cfg[d].load && nbatag.loader.cfg[d].send) {
                            nbatag.loader.cfg[d].executed = 1;
                        } else {
                            nbatag.loader.cfg[d].executed = 0;
                        }
                        u.data["loader.cfg"][d] = nbatag.loader.GV(nbatag.loader.cfg[d]);
                    }
                    u.data.data = b;
                    for (d in u.data.data) {
                        if ((d + '').indexOf("qp.") === 0) {
                            u.data.data[d] = encodeURIComponent(u.data.data[d]);
                        } else if ((d + '').indexOf("va.") === 0) {
                            delete u.data.data[d];
                        }
                    }
                    if (!u.suppress_v_id_generation) {
                        var consentCookies = nbatag.gdpr && typeof nbatag.gdpr.getCookieValues === 'function' && nbatag.gdpr.getCookieValues();
                        var consentCookieId = consentCookies && consentCookies.id;
                        u.visitor_id = u.visitor_id || b.tealium_visitor_id || b["cp.nbatag_main_v_id"] || consentCookieId || nbatag.ut.vi((new Date()).getTime());
                        nbatag.loader.SC("nbatag_main", {
                            v_id: u.visitor_id
                        });
                        b["cp.nbatag_main_v_id"] = u.visitor_id;
                        b["ut.visitor_id"] = u.visitor_id;
                        b["tealium_visitor_id"] = u.visitor_id;
                    }
                    if (!b["cp.nbatag_main_dc_event"]) {
                        b["cp.nbatag_main_dc_visit"] = (1 + (b["cp.nbatag_main_dc_visit"] ? parseInt(b["cp.nbatag_main_dc_visit"]) : 0)) + "";
                    }
                    b["cp.nbatag_main_dc_event"] = (1 + (b["cp.nbatag_main_dc_event"] ? parseInt(b["cp.nbatag_main_dc_event"]) : 0)) + "";
                    nbatag.loader.SC("nbatag_main", {
                        "dc_visit": b["cp.nbatag_main_dc_visit"],
                        "dc_event": b["cp.nbatag_main_dc_event"] + ";exp-session"
                    });
                    nbatag.data["cp.nbatag_main_dc_visit"] = b["cp.nbatag_main_dc_visit"];
                    nbatag.data["cp.nbatag_main_dc_event"] = b["cp.nbatag_main_dc_event"];
                    var dt = new Date();
                    u.data.browser = {};
                    try {
                        u.data.browser["height"] = window.innerHeight || document.body.clientHeight;
                        u.data.browser["width"] = window.innerWidth || document.body.clientWidth;
                        u.data.browser["screen_height"] = screen.height;
                        u.data.browser["screen_width"] = screen.width;
                        u.data.browser["timezone_offset"] = dt.getTimezoneOffset();
                    } catch (e) {
                        nbatag.DB(e);
                    }
                    u.data["event"] = a + '';
                    u.data["post_time"] = dt.getTime();
                    if (u.data_enrichment === "frequent" || u.data_enrichment === "infrequent") {
                        u.visit_num = b["cp.nbatag_main_dc_visit"];
                        if (parseInt(u.visit_num) > 1 && b["cp.nbatag_main_dc_event"] === "1") {
                            u.enrichment_polling = 2;
                        }
                        try {
                            u.va_update = parseInt(localStorage.getItem("tealium_va_update") || 0);
                        } catch (e) {
                            nbatag.DB(e);
                        }
                        u.visitor_id = u.visitor_id || b.tealium_visitor_id || b["cp.nbatag_main_v_id"];
                        if (u.data_enrichment === "frequent" || (u.data_enrichment === "infrequent" && parseInt(u.visit_num) > 1 && parseInt(b["cp.nbatag_main_dc_event"]) <= 5 && u.visit_num !== u.va_update)) {
                            u.make_enrichment_request = true;
                        }
                        u.visitor_service_request = function(t, server) {
                            var s, p = u.get_account_profile(server);
                            if (u.visitor_service_override) {
                                s = u.validateProtocol(u.visitor_service_override, true);
                            } else {
                                s = u.validateProtocol(u.server_prefix, true) + "visitor-service" + (u.region ? "-" + u.region : "").replace(/[^-A-Za-z0-9+_.]/g, "") + "." + u.server_domain;
                            }
                            (function(p) {
                                var prefix = "tealium_va";
                                var key = "_" + p[1] + "_" + p[2];
                                nbatag.ut["writeva" + p[2]] = function(o) {
                                    nbatag.DB("Visitor Attributes: " + prefix + key);
                                    nbatag.DB(o);
                                    var str = JSON.stringify(o);
                                    if (str !== "{}" && str !== "") {
                                        try {
                                            localStorage.setItem("tealium_va_update", nbatag.data["cp.nbatag_main_dc_visit"]);
                                            localStorage.setItem(prefix, str);
                                            localStorage.setItem(prefix + key, str);
                                        } catch (e) {
                                            nbatag.DB(e);
                                        }
                                        if (typeof tealium_enrichment === "function") {
                                            tealium_enrichment(o, prefix + key);
                                        }
                                    }
                                };
                            }(p.slice(0)));
                            var vid = u.visitor_id;
                            if (u.profile_specific_vid === 1) {
                                vid += p[2];
                            }
                            var srcUrl = s + '/' + p[1] + '/' + p[2] + '/' + vid.replace(/[\?\&]callback=.*/g, '') + '?callback=nbatag.ut%5B%22writeva' + p[2] + '%22%5D&rnd=' + t;
                            if (b.tealium_cookie_domain) {
                                srcUrl = srcUrl + '&tealium_cookie_domain=' + b.tealium_cookie_domain
                                if (b.tealium_cookie_expiry) {
                                    srcUrl = srcUrl + '&tealium_cookie_expiry=' + b.tealium_cookie_expiry
                                }
                            }
                            nbatag.ut.loader({
                                id: 'tealium_visitor_service_77' + p[2] + '_' + u.request_increment++,
                                src: srcUrl
                            });
                        };
                        u.do_enrichment = function(server, enrichment_polling, enrichment_polling_delay) {
                            if (typeof nbatag.ut.loader != "undefined") {
                                for (i = 0; i < enrichment_polling; i++) {
                                    setTimeout(function() {
                                        u.visitor_service_request((new Date).getTime(), server);
                                    }, i * enrichment_polling_delay + 1);
                                }
                            }
                        };
                    }
                    var json_string, regExpReplace = new RegExp(u.visitor_id, "g");
                    if (b.tealium_random && typeof nbatag.globals[b.tealium_random] === "object") {
                        for (var downstream_param in nbatag.globals[b.tealium_random]) {
                            u.data.data[downstream_param] = u.deepCopy(nbatag.globals[b.tealium_random][downstream_param]);
                        }
                    }

                    function getSendData(useEventData, server) {
                        var dataStringify = u.data;
                        var filterObject = u.data.data
                        if (useEventData) {
                            dataStringify = u.data.data;
                            filterObject = u.data.data;
                            u.data.data.tealium_profile = u.profile;
                        }
                        Object.keys(filterObject).forEach(dataKey => {
                            if (['cp.trace_id', 'tealium_account', 'tealium_profile'].indexOf(dataKey) !== -1) {
                                return;
                            }
                            if (dataKey.indexOf('cp.') === 0) {
                                !u.send_cookie_values && delete filterObject[dataKey];
                                return;
                            }
                            if (dataKey.indexOf('meta.') === 0) {
                                !u.send_meta_values && delete filterObject[dataKey];
                                return;
                            }
                            if (dataKey.indexOf('qp.') === 0) {
                                !u.send_query_param_values && delete filterObject[dataKey];
                                return;
                            }
                            if (dataKey.indexOf('ls.') === 0) {
                                !u.send_localstorage_variables && delete filterObject[dataKey];
                                return;
                            }
                            if (dataKey.indexOf('ss.') === 0) {
                                !u.send_sessionstorage_variables && delete filterObject[dataKey];
                                return;
                            }
                            if (dataKey.indexOf('dom.') === 0) {
                                !u.send_dom_values && delete filterObject[dataKey];
                                return;
                            }
                            if (dataKey.indexOf('dom.') !== 0 && dataKey.indexOf('ss.') !== 0 && dataKey.indexOf('ls.') !== 0 && dataKey.indexOf('qp.') !== 0 && dataKey.indexOf('meta.') !== 0 && dataKey.indexOf('cp.') !== 0) {
                                !u.send_udo_variables && delete filterObject[dataKey];
                                return;
                            }
                        });
                        json_string = JSON.stringify(dataStringify);
                        if (u.profile_specific_vid === 1 && u.visitor_id) {
                            json_string = json_string.replace(regExpReplace, u.visitor_id + u.get_account_profile(server)[2]);
                        }
                        if (useEventData) {
                            return json_string;
                        }
                        var formData = new FormData();
                        formData.append("data", json_string);
                        return formData;
                    }

                    function postData(server_index, enrichment_polling, enrichment_polling_delay, useEventData) {
                        if (server_index + 1 > u.server_list.length) {
                            return;
                        }
                        var xhr = new XMLHttpRequest();
                        var server = u.validateProtocol(u.server_list[server_index], true);
                        var data = getSendData(useEventData, server);
                        u.region = nbatag.loader.RC("nbatag_main")["dc_region"] || u.region || "";
                        if (typeof navigator.sendBeacon === 'function' && u.region !== "" && u.use_sendBeacon) {
                            u.server_list.forEach(function(serverItem) {
                                var beaconSent = navigator.sendBeacon(infixParameters(serverItem, u.tc_string), data);
                                if (!beaconSent) {
                                    xhr.open("post", infixParameters(serverItem, u.tc_string), true);
                                    xhr.withCredentials = true;
                                    xhr.send(data);
                                }
                                if (u.make_enrichment_request && u.enrichment_enabled[serverItem]) {
                                    u.do_enrichment(serverItem, enrichment_polling, enrichment_polling_delay);
                                }
                            });
                            nbatag.DB("Data sent using sendBeacon");
                            return;
                        }
                        xhr.addEventListener("readystatechange", function() {
                            if (xhr.readyState === 3) {
                                try {
                                    u.region = xhr.getResponseHeader("X-Region") || u.region || "";
                                } catch (res_error) {
                                    nbatag.DB(res_error);
                                    u.region = u.region || "";
                                }
                                if (u.region) nbatag.loader.SC("nbatag_main", {
                                    "dc_region": u.region + ";exp-session"
                                });
                                nbatag.DB("dc_region:" + u.region);
                            } else if (xhr.readyState === 4) {
                                postData(server_index + 1, enrichment_polling, enrichment_polling_delay, useEventData);
                                if (u.make_enrichment_request && u.enrichment_enabled[server]) {
                                    u.do_enrichment(server, enrichment_polling, enrichment_polling_delay);
                                }
                            }
                        });
                        if (u.server_list[server_index].toLowerCase().indexOf("http") !== 0) {
                            u.server_list[server_index] = u.validateProtocol(u.server_list[server_index], true);
                        }
                        var serverUrl = infixParameters(u.server_list[server_index], u.tc_string);
                        xhr.open("post", serverUrl, true);
                        xhr.withCredentials = true;
                        xhr.send(data);
                    }
                    if (u.use_event_endpoint && (u.tag_config_server === u.event_url || u.tag_config_region !== "default") && window.FormData) {
                        postData(0, u.enrichment_polling, u.enrichment_polling_delay, true);
                    } else if (window.FormData) {
                        postData(0, u.enrichment_polling, u.enrichment_polling_delay, false);
                    } else {
                        for (i = 0; i < u.server_list.length; i++) {
                            (function(i, enrichment_polling, enrichment_polling_delay) {
                                var server = u.server_list[i];
                                setTimeout(function() {
                                    json_string = JSON.stringify(u.data);
                                    if (u.profile_specific_vid == 1 && u.visitor_id) {
                                        json_string = json_string.replace(regExpReplace, u.visitor_id + u.get_account_profile(server)[2]);
                                    }
                                    var img = new Image();
                                    img.src = server + "?" + (u.tc_string ? u.tc_string + "&" : "") + "data=" + encodeURIComponent(json_string);
                                    if (u.make_enrichment_request && u.enrichment_enabled[server]) {
                                        u.do_enrichment(server, enrichment_polling, enrichment_polling_delay);
                                    }
                                }, i * 700);
                            }(i, u.enrichment_polling, u.enrichment_polling_delay));
                        }
                    }
                }
            }
        };
        try {
            nbatag.o[loader].loader.LOAD(id);
        } catch (e) {
            nbatag.loader.LOAD(id);
        }
    })("77", "nba.nba-web");
} catch (e) {
    nbatag.DB(e);
}