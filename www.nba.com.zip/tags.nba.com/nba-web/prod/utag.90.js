//tealium universal tag - nbatag.90 ut4.0.202602061808, Copyright 2026 Tealium.com Inc. All Rights Reserved.
var amplitude = amplitude || {
    _q: [],
    _iq: {}
};
try {
    (function(id, loader) {
        var u = {
            id: id
        };
        nbatag.o[loader].sender[id] = u;
        if (nbatag.ut === undefined) {
            nbatag.ut = {};
        }
        var match = /ut\d\.(\d*)\..*/.exec(nbatag.cfg.v);
        if (nbatag.ut.loader === undefined || !match || parseInt(match[1]) < 41) {
            u.loader = function(o, a, b, c, l, m) {
                nbatag.DB(o);
                a = document;
                if (o.type == "iframe") {
                    m = a.getElementById(o.id);
                    if (m && m.tagName == "IFRAME") {
                        b = m;
                    } else {
                        b = a.createElement("iframe");
                    }
                    o.attrs = o.attrs || {};
                    nbatag.ut.merge(o.attrs, {
                        "height": "1",
                        "width": "1",
                        "style": "display:none"
                    }, 0);
                } else if (o.type == "img") {
                    nbatag.DB("Attach img: " + o.src);
                    b = new Image();
                } else {
                    b = a.createElement("script");
                    b.language = "javascript";
                    b.type = "text/javascript";
                    b.async = 1;
                    b.charset = "utf-8";
                }
                if (o.id) {
                    b.id = o.id;
                }
                for (l in nbatag.loader.GV(o.attrs)) {
                    b.setAttribute(l, o.attrs[l]);
                }
                b.setAttribute("src", o.src);
                if (typeof o.cb == "function") {
                    if (b.addEventListener) {
                        b.addEventListener("load", function() {
                            o.cb();
                        }, false);
                    } else {
                        b.onreadystatechange = function() {
                            if (this.readyState == "complete" || this.readyState == "loaded") {
                                this.onreadystatechange = null;
                                o.cb();
                            }
                        };
                    }
                }
                if (o.type != "img" && !m) {
                    l = o.loc || "head";
                    c = a.getElementsByTagName(l)[0];
                    if (c) {
                        nbatag.DB("Attach to " + l + ": " + o.src);
                        if (l == "script") {
                            c.parentNode.insertBefore(b, c);
                        } else {
                            c.appendChild(b);
                        }
                    }
                }
            };
        } else {
            u.loader = nbatag.ut.loader;
        }
        if (nbatag.ut.typeOf === undefined) {
            u.typeOf = function(e) {
                return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
            };
        } else {
            u.typeOf = nbatag.ut.typeOf;
        }! function(e, t) {
            "object" == typeof exports && "undefined" != typeof module ? t() : "function" == typeof define && define.amd ? define(t) : t()
        }(0, function() {
            "use strict";

            function e(e) {
                var t = this.constructor;
                return this.then(function(n) {
                    return t.resolve(e()).then(function() {
                        return n
                    })
                }, function(n) {
                    return t.resolve(e()).then(function() {
                        return t.reject(n)
                    })
                })
            }

            function t(e) {
                return new this(function(t, n) {
                    function r(e, n) {
                        if (n && ("object" == typeof n || "function" == typeof n)) {
                            var f = n.then;
                            if ("function" == typeof f) return void f.call(n, function(t) {
                                r(e, t)
                            }, function(n) {
                                o[e] = {
                                    status: "rejected",
                                    reason: n
                                }, 0 == --i && t(o)
                            })
                        }
                        o[e] = {
                            status: "fulfilled",
                            value: n
                        }, 0 == --i && t(o)
                    }
                    if (!e || "undefined" == typeof e.length) return n(new TypeError(typeof e + " " + e + " is not iterable(cannot read property Symbol(Symbol.iterator))"));
                    var o = Array.prototype.slice.call(e);
                    if (0 === o.length) return t([]);
                    for (var i = o.length, f = 0; o.length > f; f++) r(f, o[f])
                })
            }

            function n(e, t) {
                this.name = "AggregateError", this.errors = e, this.message = t || ""
            }

            function r(e) {
                var t = this;
                return new t(function(r, o) {
                    if (!e || "undefined" == typeof e.length) return o(new TypeError("Promise.any accepts an array"));
                    var i = Array.prototype.slice.call(e);
                    if (0 === i.length) return o();
                    for (var f = [], u = 0; i.length > u; u++) try {
                        t.resolve(i[u]).then(r)["catch"](function(e) {
                            f.push(e), f.length === i.length && o(new n(f, "All promises were rejected"))
                        })
                    } catch (c) {
                        o(c)
                    }
                })
            }

            function o(e) {
                return !(!e || "undefined" == typeof e.length)
            }

            function i() {}

            function f(e) {
                if (!(this instanceof f)) throw new TypeError("Promises must be constructed via new");
                if ("function" != typeof e) throw new TypeError("not a function");
                this._state = 0, this._handled = !1, this._value = undefined, this._deferreds = [], s(e, this)
            }

            function u(e, t) {
                for (; 3 === e._state;) e = e._value;
                0 !== e._state ? (e._handled = !0, f._immediateFn(function() {
                    var n = 1 === e._state ? t.onFulfilled : t.onRejected;
                    if (null !== n) {
                        var r;
                        try {
                            r = n(e._value)
                        } catch (o) {
                            return void a(t.promise, o)
                        }
                        c(t.promise, r)
                    } else(1 === e._state ? c : a)(t.promise, e._value)
                })) : e._deferreds.push(t)
            }

            function c(e, t) {
                try {
                    if (t === e) throw new TypeError("A promise cannot be resolved with itself.");
                    if (t && ("object" == typeof t || "function" == typeof t)) {
                        var n = t.then;
                        if (t instanceof f) return e._state = 3, e._value = t, void l(e);
                        if ("function" == typeof n) return void s(function(e, t) {
                            return function() {
                                e.apply(t, arguments)
                            }
                        }(n, t), e)
                    }
                    e._state = 1, e._value = t, l(e)
                } catch (r) {
                    a(e, r)
                }
            }

            function a(e, t) {
                e._state = 2, e._value = t, l(e)
            }

            function l(e) {
                2 === e._state && 0 === e._deferreds.length && f._immediateFn(function() {
                    e._handled || f._unhandledRejectionFn(e._value)
                });
                for (var t = 0, n = e._deferreds.length; n > t; t++) u(e, e._deferreds[t]);
                e._deferreds = null
            }

            function s(e, t) {
                var n = !1;
                try {
                    e(function(e) {
                        n || (n = !0, c(t, e))
                    }, function(e) {
                        n || (n = !0, a(t, e))
                    })
                } catch (r) {
                    if (n) return;
                    n = !0, a(t, r)
                }
            }
            n.prototype = Error.prototype;
            var d = setTimeout;
            f.prototype["catch"] = function(e) {
                return this.then(null, e)
            }, f.prototype.then = function(e, t) {
                var n = new this.constructor(i);
                return u(this, new function(e, t, n) {
                    this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = n
                }(e, t, n)), n
            }, f.prototype["finally"] = e, f.all = function(e) {
                return new f(function(t, n) {
                    function r(e, o) {
                        try {
                            if (o && ("object" == typeof o || "function" == typeof o)) {
                                var u = o.then;
                                if ("function" == typeof u) return void u.call(o, function(t) {
                                    r(e, t)
                                }, n)
                            }
                            i[e] = o, 0 == --f && t(i)
                        } catch (c) {
                            n(c)
                        }
                    }
                    if (!o(e)) return n(new TypeError("Promise.all accepts an array"));
                    var i = Array.prototype.slice.call(e);
                    if (0 === i.length) return t([]);
                    for (var f = i.length, u = 0; i.length > u; u++) r(u, i[u])
                })
            }, f.any = r, f.allSettled = t, f.resolve = function(e) {
                return e && "object" == typeof e && e.constructor === f ? e : new f(function(t) {
                    t(e)
                })
            }, f.reject = function(e) {
                return new f(function(t, n) {
                    n(e)
                })
            }, f.race = function(e) {
                return new f(function(t, n) {
                    if (!o(e)) return n(new TypeError("Promise.race accepts an array"));
                    for (var r = 0, i = e.length; i > r; r++) f.resolve(e[r]).then(t, n)
                })
            }, f._immediateFn = "function" == typeof setImmediate && function(e) {
                setImmediate(e)
            } || function(e) {
                d(e, 0)
            }, f._unhandledRejectionFn = function(e) {
                void 0 !== console && console && console.warn("Possible Unhandled Promise Rejection:", e)
            };
            var p = function() {
                if ("undefined" != typeof self) return self;
                if ("undefined" != typeof window) return window;
                if ("undefined" != typeof global) return global;
                throw Error("unable to locate global object")
            }();
            "function" != typeof p.Promise ? p.Promise = f : (p.Promise.prototype["finally"] || (p.Promise.prototype["finally"] = e), p.Promise.allSettled || (p.Promise.allSettled = t), p.Promise.any || (p.Promise.any = r))
        });
        u.ev = {
            view: 1,
            link: 1
        };
        u.initialized = false;
        u.scriptrequested = false;
        u.ACTIONS = {
            ADD: "add",
            APPEND: "append",
            PREPEND: "prepend",
            SET: "set",
            SET_ONCE: "setOnce",
            UNSET: "unset",
            POST_INSERT: "postInsert",
            REMOVE: "remove"
        };
        u.toBoolean = function(val) {
            val = val || "";
            return val === true || val.toLowerCase() === "true" || val.toLowerCase() === "on";
        };
        u.setDefaultValue = function(val) {
            if (val === "") {
                return true;
            }
            return u.toBoolean(val);
        }
        u.mapFunc = function(arr, obj, item) {
            var i = arr.shift();
            obj[i] = obj[i] || {};
            if (arr.length > 0) {
                u.mapFunc(arr, obj[i], item);
            } else {
                obj[i] = item;
            }
        };
        u.clearEmptyKeys = function(object) {
            for (var key in object) {
                if (object[key] === "" || object[key] === undefined) {
                    delete object[key];
                }
            }
            return object;
        };
        u.map = {
            "amplitude_api_key": "api_key",
            "interactionContent": "eventProperties.Interaction Content",
            "identifier": "eventProperties.Interaction Identifier",
            "interactionText": "eventProperties.Interaction Text",
            "modalName": "eventProperties.Modal Name",
            "sku": "eventProperties.SKU",
            "interactionPosition": "eventProperties.Interaction Position",
            "offerDesc": "eventProperties.Offer Title",
            "interactionType": "eventProperties.Interaction Type",
            "interactionContentID": "eventProperties.Interaction Content ID",
            "categoryID": "eventProperties.Category ID",
            "categoryTitle": "eventProperties.Category Title",
            "page.content.gameID": "eventProperties.Game ID",
            "linkName": "eventProperties.Interaction Identifier",
            "section": "eventProperties.Interaction Section",
            "paywalledContent": "eventProperties.Interaction Content",
            "infoID": "eventProperties.Interaction Identifier",
            "infoText": "eventProperties.Interaction Text",
            "eventDesc": "eventProperties.Interaction Type",
            "placementDesc": "eventProperties.Interaction Section",
            "textElement": "eventProperties.Interaction Text",
            "campaignDesc": "eventProperties.Interaction Content",
            "sortOrder": "eventProperties.Interaction State",
            "sortIdentifier": "eventProperties.Interaction Identifier",
            "sortID": "eventProperties.Interaction Identifier",
            "searchIdentifier": "eventProperties.Interaction Identifier",
            "mvpd": "eventProperties.Authentication Provider",
            "textClicked": "eventProperties.Interaction Text",
            "teamID": "eventProperties.Team ID",
            "videoID": "eventProperties.Interaction Content",
            "videoName": "eventProperties.Media Content Game",
            "videoId": "eventProperties.Media Content ID",
            "videoCategory": "eventProperties.Video Type",
            "premiumVideo": "eventProperties.Premium Media",
            "contentType": "eventProperties.Interaction Content Type",
            "playerName": "eventProperties.Player Name",
            "teamName": "eventProperties.Team Name",
            "datatype": "eventProperties.Interaction Type",
            "datasection": "eventProperties.Interaction Section",
            "datatext": "eventProperties.Interaction Text",
            "datacontent": "eventProperties.Interaction Content",
            "contentPosition": "eventProperties.Content Position",
            "dataid": "eventProperties.Interaction Identifier",
            "premium": "eventProperties.Premium Media",
            "interactionId": "eventProperties.Interaction Identifier",
            "text": "eventProperties.Interaction Text",
            "sectionPos": "eventProperties.Interaction Section Position",
            "type": "eventProperties.Interaction Type",
            "contentId": "eventProperties.Interaction Content ID,eventProperties.Content ID",
            "content": "eventProperties.Interaction Content",
            "pos": "eventProperties.Content Position",
            "state": "eventProperties.Interaction State",
            "overlayDigitalData.interaction.identifier": "eventProperties.Interaction Identifier",
            "categories": "eventProperties.Categories",
            "currentCategory": "eventProperties.Current Category",
            "placement": "eventProperties.Placement",
            "adId": "eventProperties.Ad ID",
            "adPlacement": "eventProperties.Ad Placement",
            "adType": "eventProperties.Ad Type",
            "advertiserName": "eventProperties.Advertiser Name",
            "creativeType": "eventProperties.Creative type",
            "cta": "eventProperties.CTA",
            "destination": "eventProperties.Destination",
            "storyId": "eventProperties.Story ID",
            "storyTitle": "eventProperties.Story Title",
            "dismissedReason": "eventProperties.Dismissed Reason",
            "externalId": "eventProperties.External ID",
            "mediaCategory": "eventProperties.Media Category",
            "mediaContentId": "eventProperties.Media Content ID",
            "mediaContentName": "eventProperties.Media Content Name",
            "mediaContentType": "eventProperties.Media Content Type",
            "mediaFranchise": "eventProperties.Media Franchise",
            "mediaIdentifier": "eventProperties.Media Identifier",
            "mediaOrigin": "eventProperties.Media Origin",
            "mediaPlayerMode": "eventProperties.Media Player Mode",
            "mediaSource": "eventProperties.Media Source",
            "mediaType": "eventProperties.Media Type",
            "premiumMedia": "eventProperties.Premium Media",
            "streamFormat": "eventProperties.Stream Format",
            "streamType": "eventProperties.Stream Type",
            "contentChannel": "eventProperties.Content Channel",
            "contentLength": "eventProperties.Content Length",
            "contentPlayerName": "eventProperties.Content Player Name",
            "previousNext": "eventProperties.Previous/Next",
            "shareMethod": "eventProperties.Share Method",
            "storyKeywords": "eventProperties.Story Keywords",
            "storyPosition": "eventProperties.Story Position",
            "openedReason": "eventProperties.Opened Reason",
            "storyTriviaQuizId": "eventProperties.Story Trivia Quiz ID",
            "storyTriviaQuizTitle": "eventProperties.Story Trivia Quiz Title",
            "storyTriviaQuizScore": "eventProperties.Story Trivia Quiz Score",
            "storyTriviaQuizQuestionId": "eventProperties.Story Trivia Quiz Question ID",
            "storyTriviaQuizAnswerId": "eventProperties.Story Trivia Quiz Answer ID",
            "storyPollAnswerId": "eventProperties.Story Poll Answer ID",
            "errorDetail": "eventProperties.Error Detail",
            "amplitude_page_name": "eventProperties.Page Name",
            "property_name": "eventProperties.Property Name",
            "league": "eventProperties.League",
            "origin": "eventProperties.Origin",
            "authentication_type": "eventProperties.Authentication Type",
            "page.content.playerName": "eventProperties.Player Name",
            "page.content.partner": "eventProperties.Associated Partner",
            "page.content.categoryID": "eventProperties.Category ID",
            "page.content.categoryTitle": "eventProperties.Category Title",
            "page.content.categoryType": "eventProperties.Category Type",
            "page.content.categoryKeywords": "eventProperties.Category Keywords",
            "page.content.contentTitle": "eventProperties.Content Title",
            "page.content.contentID": "eventProperties.Content ID",
            "page.content.teamName": "eventProperties.Team Name",
            "page.content.teamId": "eventProperties.Team ID",
            "page.content.playerId": "eventProperties.Player ID",
            "user.userState": "set.Login State",
            "user.userType": "set.User Type",
            "user.authenticationProvider.partner_name": "set.Authentication Provider,set.Partner Authentication Provider,eventProperties.Partner Authentication Provider",
            "user.authenticationProvider": "set.Authentication Provider",
            "user.authenticationType": "set.Authentication Type",
            "user.entitlements": "set.Packages Purchased,set.Active DTC Entitlements",
            "user.localEntitlements": "eventProperties.Local Entitlements",
            "impact_visitor": "eventProperties.Impact Visitor",
            "isWebview": "eventProperties.Webview",
            "category_id": "eventProperties.Category ID",
            "category_name": "eventProperties.Category Name",
            "category_type": "eventProperties.Category Type",
            "category_keywords": "eventProperties.Category Keywords",
            "team_name": "eventProperties.Team Name",
            "site.league": "eventProperties.League",
            "login_state": "set.Login State",
            "league_pass_feed": "eventProperties.League Pass Feed",
            "favorite_team": "set.Currently Favorited Team",
            "associated_partner": "eventProperties.Associated Partner",
            "dom.domain": "eventProperties.Server",
            "amplitude_project": "eventProperties.Amplitude Project",
            "filtered_query_string": "eventProperties.Page URL Parameters",
            "interactionIdentifier": "eventProperties.Interaction Identifier",
            "site_partner": "eventProperties.Partner",
            "interactionSection": "eventProperties.Interaction Section",
            "placementType": "eventProperties.Placement Type",
            "placementGeoLocation": "eventProperties.Placement Geo Location",
            "copyId": "eventProperties.Copy ID",
            "componentName": "eventProperties.Component Name",
            "favoriteTeam": "set.Currently Favorited Team",
            "favoriteTeamID": "set.Favorite Team ID",
            "page.content.contentType": "eventProperties.Content Type",
            "page.content.blackout": "eventProperties.Blackout",
            "page.content.gameBroadcasters": "eventProperties.Broadcasters",
            "page.content.gameMatchup": "eventProperties.Game Matchup",
            "page.content.gameQuarter": "eventProperties.Game Quarter",
            "page.content.gameState": "eventProperties.Game State",
            "page.content.seasonType": "eventProperties.Season Type",
            "page.content.venue": "eventProperties.Game Venue",
            "page.content.season": "eventProperties.Game Season,eventProperties.Season",
            "page.content.contentKeywords": "eventProperties.Content Keywords",
            "page.content.contentId": "eventProperties.Content ID",
            "page.content.categoryId": "eventProperties.Category ID",
            "page.content.categoryAuthor": "eventProperties.Article Author",
            "page.content.contentDatePublished": "eventProperties.Content Date Published",
            "ut.env": "eventProperties.Tag Environment",
            "ut.version": "eventProperties.Tag Version",
            "ut.profile": "eventProperties.Tag Container",
            "cleaned_url": "eventProperties.Page URL",
            "user.userID": "customer_id",
            "sectionOrigin": "eventProperties.Section Origin",
            "currentlyFollowedTeam": "postInsert.Currently Followed Teams",
            "unfollowedTeam": "remove.Currently Followed Teams",
            "currentlyFavoritedPlayer": "postInsert.Currently Favorited Players",
            "unfavoritedPlayer": "remove.Currently Favorited Players",
            "currentlyFavoritedPlayerID": "postInsert.Following Player IDs",
            "unfavoritedPlayerID": "remove.Following Player IDs",
            "currentlyFollowedTeamID": "postInsert.Following Team IDs",
            "unfollowedTeamID": "remove.Following Team IDs",
            "analyticsId": "eventProperties.Analytics ID",
            "entitlements": "eventProperties.Entitlements",
            "videoType": "eventProperties.Video Type",
            "authenticationCode": "eventProperties.Authentication Code",
            "interactionState": "eventProperties.Interaction State",
            "page.pageInfo.contentTitle": "eventProperties.Content Title",
            "registrationType": "eventProperties.Registration Type",
            "impact_click_id": "set.Impact Visitor",
            "eventInteraction": "eventProperties.Interaction Identifier",
            "eventInteractionState": "eventProperties.Interaction State",
            "eventErrorDetail": "eventProperties.Error Detail",
            "eventSku": "eventProperties.SKU",
            "eventReason": "eventProperties.Reason",
            "eventInteractionContent": "eventProperties.Interaction Content",
            "eventInteractionType": "eventProperties.Interaction Type",
            "eventInteractionPosition": "eventProperties.Interaction Position,eventProperties.Interaction Section Position",
            "eventInteractionText": "eventProperties.Interaction Text",
            "eventInteractionContentID": "eventProperties.Interaction Content ID,eventProperties.Content ID",
            "eventPremium": "eventProperties.Premium Media",
            "eventPaymentMethodType": "eventProperties.Payment Method",
            "paymentMethodType": "eventProperties.Payment Method",
            "promoCodeDiscountAmount": "eventProperties.Promo Code Discount Amount",
            "tealium_event": "event_type",
            "eventPageName": "eventProperties.Page Name",
            "eventIdentifier": "eventProperties.Interaction Identifier",
            "eventPromoCode": "eventProperties.Promo Code",
            "eventPromoProductPrice": "eventProperties.Price",
            "eventPromoCodeRenewal": "eventProperties.Promo Code Renewal",
            "eventPromoCodeRenewalTerm": "eventProperties.Promo Code Renewal Term",
            "eventMarkdownPrice": "eventProperties.Markdown Price",
            "eventMarkdownPriceSet": "eventProperties.Markdown Price Set",
            "eventTransactionTax": "eventProperties.Tax",
            "eventTotalOrderValue": "eventProperties.Total Order Amount",
            "eventCurrency": "eventProperties.Currency Code",
            "eventPrice": "eventProperties.Price",
            "eventProductName": "eventProperties.Product Name",
            "eventTransactionFreeTrial": "eventProperties.Free Trial Transaction",
            "orderId": "eventProperties.Order ID",
            "eventSiteSection": "eventProperties.Site Section",
            "eventRenewalTerm": "eventProperties.Renewal Term",
            "leaguePassFeed": "eventProperties.League Pass Feed",
            "eventGiftCode": "eventProperties.Gift Code",
            "eventTeamID": "eventProperties.Team ID",
            "lpOrderID": "eventProperties.League Pass Order ID",
            "eventTeamTricode": "eventProperties.Team Tricode",
            "eventContentType": "eventProperties.Content Type",
            "eventpremiumMedia": "eventProperties.Premium Media",
            "eventleague_pass_feed": "eventProperties.League Pass Feed",
            "eventInteractionSection": "eventProperties.Interaction Section",
            "eventInteractionContentType": "eventProperties.Interaction Content Type",
            "eventContentPosition": "eventProperties.Content Position",
            "eventAssociatedPartner": "eventProperties.Associated Partner",
            "partner": "eventProperties.Partner",
            "eventGameID": "eventProperties.Game ID",
            "markdownPriceSet": "eventProperties.Markdown Price Set",
            "teamTricode": "eventProperties.Team Tricode",
            "gameMatchup": "eventProperties.Game Matchup",
            "gameID": "eventProperties.Game ID",
            "gameBroadcasters": "eventProperties.Broadcasters",
            "seasonType": "eventProperties.Season Type",
            "interactionSectionPosition": "eventProperties.Interaction Section Position",
            "page.pageInfo.pageName": "eventProperties.Page Name",
            "playerID": "eventProperties.Player ID",
            "page.content.contentPosition": "eventProperties.Content Position",
            "page.content.contentAuthor": "eventProperties.Article Author",
            "searchInfo.searchTerm": "eventProperties.Search Term",
            "searchInfo.searchType": "eventProperties.Search Type",
            "filters.basic": "eventProperties.Applied Filters",
            "filters.update": "eventProperties.Updated Filter",
            "gameState": "eventProperties.Game State",
            "contentID": "eventProperties.Content ID",
            "contentName": "eventProperties.Content Name",
            "exit_link": "eventProperties.Exit Link",
            "download_link": "eventProperties.Download Link",
            "download_file": "eventProperties.Download File",
            "partnerEntitlements": "set.Active Partner Entitlements",
            "tealium_visitor_id": "set.Tealium Visitor ID",
            "prevSku": "eventProperties.Previous SKU",
            "currentSku": "eventProperties.Current SKU",
            "orderID": "eventProperties.Order ID",
            "promoCode": "eventProperties.Promo Code",
            "flowType": "eventProperties.Flow Type",
            "eventEntitlements": "set.Active DTC Entitlements",
            "page.content.offerDesc": "eventProperties.Offer Title",
            "page.content.offerID": "eventProperties.Offer ID",
            "eventPromoProdPrice": "eventProperties.Promo Product Price",
            "partnerAuthType": "eventProperties.Partner Authentication Type",
            "videoDuration": "eventProperties.Content Length",
            "mediaAvailability": "eventProperties.Media Availability",
            "liveEventID": "eventProperties.Live Event ID",
            "dvr": "eventProperties.DVR",
            "downloaded": "eventProperties.Downloaded",
            "mkSdkVersion": "eventProperties.MediaKind SDK Version",
            "mediaAction": "eventProperties.Media Action",
            "videoPlayerIndex": "eventProperties.Video Player Index",
            "contentState": "eventProperties.Content State",
            "multigameSessionID": "eventProperties.Multigame Session ID",
            "tags": "eventProperties.Tags",
            "focused": "eventProperties.Focused",
            "premiumContent": "eventProperties.Premium Media",
            "casting": "eventProperties.Casting",
            "castingTech": "eventProperties.Casting Technology",
            "mediaFeed": "eventProperties.Media Feed",
            "collection": "eventProperties.Collection",
            "searchFilter": "eventProperties.Search Filter",
            "searchSort": "eventProperties.Search Sort",
            "page.content.registrationType": "eventProperties.Registration Type",
            "categoryName": "eventProperties.Category Name",
            "categoryId": "eventProperties.Category ID",
            "partnerAuth": "eventProperties.Partner Authentication Provider",
            "associatedPartner": "eventProperties.Associated Partner",
            "impact_publisher": "eventProperties.Impact Publisher,set.Impact Publisher",
            "user.noSpoilers": "set.No Spoilers",
            "boolean_false": "pageViews,formInteractions,elementInteractions",
            "boolean_true": "fileDownloads,attribution,sessions",
            "promoCodeRenewal": "eventProperties.Promo Code Renewal",
            "couchRightsDaysLeft": "eventProperties.Couch Rights Days Left",
            "appStorePurchaseId": "eventProperties.App Store Purchase ID",
            "page.content.flowType": "eventProperties.Flow Type",
            "cxlReason": "eventProperties.Cancel Reason",
            "contentTitle": "eventProperties.Content Title",
            "ampSiteSection": "eventProperties.Site Section",
            "pmPlacementZone": "eventProperties.Playmaker Placement Zone",
            "pmPlayName": "eventProperties.Playmaker Play Name",
            "pmCardType": "eventProperties.Playmaker Play Card Type",
            "user.followingPlayerIDs": "set.Following Player IDs",
            "followingPlayerIDs": "set.Following Player IDs",
            "interactionCategory": "eventProperties.Interaction Category",
            "interactionResponse": "eventProperties.Interaction Response",
            "playSection": "eventProperties.Play Section",
            "gameDifficulty": "eventProperties.Game Difficulty",
            "bcPicks": "eventProperties.Bracket Challenge Picks",
            "deviceName": "eventProperties.Device Name",
            "site.deviceName": "eventProperties.Device Name",
            "page.content.gameClock": "eventProperties.Game Clock",
            "page.content.playerID": "eventProperties.Player ID",
            "page.content.teamID": "eventProperties.Team ID",
            "page.content.errorMessage": "eventProperties.Error Message",
            "searchTerm": "eventProperties.Search Team",
            "page.content.contentName": "eventProperties.Content Name",
            "ampDeviceId": "deviceId",
            "destinationUrl": "eventProperties.Destination",
            "teamId": "eventProperties.Team ID",
            "user.hideOdds": "set.Hide Odds",
            "interactionContentType": "eventProperties.Interaction Content Type",
            "qs_utm_source": "set.utm_source",
            "qs_utm_medium": "set.utm_medium",
            "qs_utm_campaign": "set.utm_campaign",
            "qs_utm_content": "set.utm_content",
            "qs_utm_term": "set.utm_term"
        };
        u.extend = [function(a, b) {
            try {
                if ((typeof b['direct_call_event'] != 'undefined' && /opin_sign-in_success$/i.test(b['direct_call_event']) && b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase()) || (typeof b['direct_call_event'] != 'undefined' && /tve_sign-in_success$/i.test(b['direct_call_event']) && b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase())) {
                    let authType = (b.direct_call_event.toLowerCase().indexOf("opin") > -1) ? "OPiN" : "TVE";
                    if ((typeof amplitude == "object") && (typeof amplitude.identify == "function") && (typeof amplitude.Identify == "function")) {
                        let ampIdentify = new amplitude.Identify();
                        if (typeof ampIdentify.set == "function")
                            amplitude.identify(ampIdentify.set('Partner Authentication Type', authType));
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase() && b['tealium_event'].toString().indexOf('Remove Linked Account: Success') > -1)) {
                    if (typeof amplitude != "undefined") {
                        var identify = new amplitude.Identify();
                        var ap = b['associatedPartner'];
                        identify.remove('Linked Accounts', ap.toLowerCase());
                        amplitude.identify(identify);
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase() && b['tealium_event'].toString().indexOf('Add Linked Account: Success') > -1)) {
                    if (typeof amplitude != "undefined") {
                        var identify = new amplitude.Identify();
                        var ap = b['associatedPartner'];
                        identify.postInsert('Linked Accounts', ap.toLowerCase());
                        amplitude.identify(identify);
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }, function(a, b) {
            try {
                if ((typeof b['tealium_event'] != 'undefined' && typeof b['js_page.window.disableAmplitude'] != 'undefined' && b['js_page.window.disableAmplitude'].toString().toLowerCase() == 'false'.toLowerCase() && b['js_page.window.useBrowserSdk'].toString().toLowerCase() == 'true'.toLowerCase())) {
                    let tempUserId = null;
                    let tempUserState = "guest";
                    let tempUserType = "guest";
                    if ((b.tealium_event == "User Account: Registration Success") || (b.tealium_event == "User Account: Login Success")) {
                        if (typeof b.userID == "string")
                            tempUserId = b.userID;
                        if (typeof b.userState == "string")
                            tempUserState = b.userState;
                        if (typeof b.userType == "string")
                            tempUserType = b.userType;
                    }
                    if ((typeof amplitude == "object") && (typeof amplitude.identify == "function") && (typeof amplitude.Identify == "function") && (typeof amplitude.setUserId == "function")) {
                        var identitySuccessEvt = false;
                        if ((b.tealium_event == "User Account: Registration Success") || (b.tealium_event == "User Account: Login Success") || (b.tealium_event == "User Account: Logout Success")) {
                            amplitude.setUserId(tempUserId);
                            identitySuccessEvt = true;
                        }
                        if (identitySuccessEvt || ((typeof b["user.fetchingNbaProfileStatus"] != "undefined") && (b["user.fetchingNbaProfileStatus"] == "complete") && (typeof b["user.userID"] == "undefined"))) {
                            let ampIdentify = new amplitude.Identify();
                            if (typeof ampIdentify.set == "function")
                                amplitude.identify(ampIdentify
                                    .set('NBA ID Login State', tempUserState)
                                    .set('NBA ID User Type', tempUserType));
                        }
                    }
                }
            } catch (e) {
                nbatag.DB(e)
            }
        }];
        u.identify = function(action, obj) {
            Object.keys(obj).forEach(function(key) {
                var identifyEvent;
                switch (action) {
                    case u.ACTIONS.ADD:
                        identifyEvent = new amplitude.Identify().add(key, obj[key]);
                        break;
                    case u.ACTIONS.APPEND:
                        identifyEvent = new amplitude.Identify().append(key, obj[key]);
                        break;
                    case u.ACTIONS.PREPEND:
                        identifyEvent = new amplitude.Identify().prepend(key, obj[key]);
                        break;
                    case u.ACTIONS.SET:
                        identifyEvent = new amplitude.Identify().set(key, obj[key]);
                        break;
                    case u.ACTIONS.SET_ONCE:
                        identifyEvent = new amplitude.Identify().setOnce(key, obj[key]);
                        break;
                    case u.ACTIONS.UNSET:
                        identifyEvent = new amplitude.Identify().unset(key, obj[key]);
                        break;
                    case u.ACTIONS.POST_INSERT:
                        identifyEvent = new amplitude.Identify().postInsert(key, obj[key]);
                        break;
                    case u.ACTIONS.REMOVE:
                        identifyEvent = new amplitude.Identify().remove(key, obj[key]);
                        break;
                }
                if (identifyEvent) {
                    amplitude.identify(identifyEvent);
                }
            });
        }
        u.sdkLoaderCallback = function() {
            var sessionReplayUrl = "https://cdn.amplitude.com/libs/plugin-session-replay-browser-##session_replay_version##-min.js.gz".replace("##session_replay_version##", u.data.session_replay_version);
            Promise.all([u.toBoolean(u.data.session_replay) && new Promise(function(resolve) {
                u.loader({
                    type: "script",
                    src: sessionReplayUrl,
                    cb: resolve,
                    loc: "script",
                    id: "nbatag_session_replay_90"
                });
            }), u.toBoolean(u.data.guides_and_surveys) && new Promise(function(resolve) {
                u.loader({
                    type: "script",
                    src: "https://cdn.amplitude.com/script/" + u.data.api_key + ".engagement.js",
                    cb: resolve,
                    loc: "script",
                    id: "nbatag_guides_and_surveys_90"
                });
            })].filter(Boolean)).then(function() {
                u.loaderCallback();
            })
        }
        u.loaderCallback = function() {
            nbatag.DB('send:90:CALLBACK');
            u.initialized = true;
            var amplConfig = {
                flushIntervalMillis: u.data.flushIntervalMillis,
                flushQueueSize: u.data.flushQueueSize,
                flushMaxRetries: u.data.flushMaxRetries,
                logLevel: u.data.logLevel,
                serverUrl: u.data.serverUrl,
                serverZone: u.data.serverZone,
                useBatch: u.toBoolean(u.data.useBatch),
                autocapture: {
                    attribution: u.setDefaultValue(u.data.attribution),
                    pageViews: u.setDefaultValue(u.data.pageViews),
                    sessions: u.setDefaultValue(u.data.sessions),
                    fileDownload: u.setDefaultValue(u.data.fileDownloads),
                    formInteractions: u.setDefaultValue(u.data.formInteractions),
                    elementInteractions: u.setDefaultValue(u.data.elementInteractions)
                },
                deviceId: u.data.deviceId,
                cookieOptions: u.clearEmptyKeys({
                    domain: u.data.domain,
                    expiration: u.data.expiration,
                    sameSite: u.data.sameSite,
                    secure: u.data.secure,
                    upgrade: u.setDefaultValue(u.data.upgrade),
                }),
                identityStorage: u.data.identityStorage,
                trackingOptions: {
                    ipAddress: u.setDefaultValue(u.data.ipAddress),
                    language: u.setDefaultValue(u.data.language),
                    platform: u.setDefaultValue(u.data.platform),
                },
                transport: u.data.transport
            };
            if (!u.toBoolean(u.data.autocapture)) {
                amplConfig.autocapture = false;
            }
            if (u.data.customer_id === "" && u.data.userId) {
                u.data.customer_id = u.data.userId
            }
            if (u.toBoolean(u.data.session_replay)) {
                var sessionReplayTracking = window.sessionReplay.plugin();
                amplitude.add(sessionReplayTracking);
            }
            if (u.toBoolean(u.data.guides_and_surveys)) {
                var guidesAndSurveys = window.engagement.plugin();
                amplitude.add(guidesAndSurveys);
            }
            amplitude.init(u.data.api_key, u.data.customer_id, u.clearEmptyKeys(amplConfig));
            u.callback();
            nbatag.DB('send:90:CALLBACK:COMPLETE');
        };
        u.callback = function() {
            nbatag.DB("send:90:CALLBACK");
            amplitude.setOptOut(u.toBoolean(u.data.optOut));
            if (u.data.set) {
                var identify_par = new amplitude.Identify();
                Object.keys(u.data.set).forEach(function(key) {
                    identify_par.set(key, u.data.set[key]);
                });
                amplitude.identify(identify_par);
            }
            u.identify(u.ACTIONS.ADD, u.data.add);
            u.identify(u.ACTIONS.APPEND, u.data.append);
            u.identify(u.ACTIONS.PREPEND, u.data.prepend);
            u.identify(u.ACTIONS.SET_ONCE, u.data.setOnce);
            u.identify(u.ACTIONS.UNSET, u.data.unset);
            u.identify(u.ACTIONS.POST_INSERT, u.data.postInsert);
            u.identify(u.ACTIONS.REMOVE, u.data.remove);
            if (u.data.event_type) {
                amplitude.track({
                    event_type: u.data.event_type,
                    event_properties: u.data.eventProperties,
                    groups: u.data.group
                });
            }
            if (u.data.group) {
                Object.keys(u.data.group).forEach(function(key) {
                    amplitude.setGroup(key, u.data.group[key]);
                });
            }
            if (u.data.order_id) {
                var revenueProperties = {
                    order_id: u.data.order_id
                };
                u.data.product_id.forEach(function(productId, index) {
                    if (u.data.product_quantity[index] && u.data.product_unit_price[index]) {
                        var revenue = new amplitude
                            .Revenue()
                            .setProductId(productId)
                            .setPrice(parseFloat(u.data.product_unit_price[index]))
                            .setQuantity(parseInt(u.data.product_quantity[index]))
                            .setRevenueType(u.data.order_type)
                            .setEventProperties(revenueProperties);
                        amplitude.revenue(revenue);
                    }
                });
            }
            nbatag.DB("send:90:CALLBACK:COMPLETE");
        };
        u.send = function(nbatag_event, data_layer) {
            if (!u.ev[nbatag_event] && u.ev.all === undefined) {
                nbatag.DB('send:90:EVENT NOT SUPPORTED:COMPLETE');
                return;
            }
            var a, b, c, d, e, f, g, h;
            a = nbatag_event;
            b = data_layer;
            u.data = {
                base_url: "https://cdn.amplitude.com/libs/analytics-browser-##nbatag_sdk_version##-min.js.gz",
                api_key: "",
                sdk_version: "2.25.0",
                autocapture: true,
                elementInteractions: "",
                deviceId: "",
                flushIntervalMillis: "",
                flushQueueSize: "",
                flushMaxRetries: "",
                identityStorage: "",
                logLevel: "",
                optOut: false,
                serverUrl: "",
                serverZone: "",
                transport: "",
                useBatch: false,
                userId: "",
                add: {},
                append: {},
                prepend: {},
                set: {},
                setOnce: {},
                unset: {},
                postInsert: {},
                remove: {},
                group: {},
                customer_id: "",
                product_id: [],
                product_quantity: [],
                product_unit_price: [],
                event: "",
                custom: {},
                eventProperties: {},
                attribution: "",
                pageViews: "",
                sessions: "",
                formInteractions: "",
                fileDownloads: "",
                ipAddress: "",
                language: "",
                platform: "",
                session_replay: "false",
                session_replay_version: "",
                guides_and_surveys: "true",
                domain: "",
                expiration: "",
                sameSite: "",
                secure: false,
                upgrade: ""
            };
            for (c = 0; c < u.extend.length; c++) {
                try {
                    d = u.extend[c](a, b);
                    if (d == false) return
                } catch (e) {}
            };
            nbatag.DB("send:90:EXTENSIONS");
            nbatag.DB(data_layer);
            Object.keys(nbatag.loader.GV(u.map)).forEach(function(mapping_key) {
                if (data_layer[mapping_key] !== undefined && data_layer[mapping_key] !== '') {
                    var destinations = u.map[mapping_key].split(',');
                    destinations.forEach(function(parameter) {
                        u.mapFunc(parameter.split('.'), u.data, data_layer[mapping_key]);
                    });
                }
            });
            nbatag.DB('send:90:MAPPINGS');
            nbatag.DB(u.data);
            var eCommerceMapping = [{
                eCommerceData: data_layer._corder,
                name: 'order_id',
                isArray: false
            }, {
                eCommerceData: data_layer._ctype,
                name: 'order_type',
                isArray: false
            }, {
                eCommerceData: data_layer._ccustid,
                name: 'customer_id',
                isArray: false
            }, {
                eCommerceData: data_layer._cprod,
                name: 'product_id',
                isArray: true
            }, {
                eCommerceData: data_layer._cprice,
                name: 'product_unit_price',
                isArray: true
            }, {
                eCommerceData: data_layer._cquan,
                name: 'product_quantity',
                isArray: true
            }];
            eCommerceMapping.forEach(function(dataObject) {
                if (!dataObject.isArray) {
                    u.data[dataObject.name] = u.data[dataObject.name] || dataObject.eCommerceData || '';
                } else if (u.data[dataObject.name].length === 0 && dataObject.eCommerceData !== undefined && dataObject.isArray) {
                    u.data[dataObject.name] = dataObject.eCommerceData.slice(0);
                }
            });
            if (!u.data.api_key) {
                nbatag.DB(u.id + ": Tag not fired: Required attribute not populated");
                return;
            }
            if (u.data.sdk_version === "") {
                u.data.sdk_version = "2.6.0";
            }
            if (!u.data.session_replay_version) {
                u.data.session_replay_version = "1.13.9";
            }
            if (u.initialized) {
                u.callback();
            } else {
                if (!u.scriptrequested) {
                    u.scriptrequested = true;
                    (function() {
                        "use strict";
                        (function(e, t) {
                            var n = e.amplitude || {
                                q: [],
                                iq: {}
                            };
                            if (n.invoked) {
                                e.console && console.error && console.error("Amplitude snippet has been loaded.");
                            } else {
                                var r = function(e, t) {
                                    e.prototype[t] = function() {
                                        return this.q.push({
                                            name: t,
                                            args: Array.prototype.slice.call(arguments, 0)
                                        }), this;
                                    }
                                };
                                var s = function(e, t, n) {
                                    return function(r) {
                                        e.q.push({
                                            name: t,
                                            args: Array.prototype.slice.call(n, 0),
                                            resolve: r
                                        });
                                    }
                                };
                                var o = function(e, t, n) {
                                    e[t] = function() {
                                        if (n) {
                                            return {
                                                promise: new Promise(s(e, t, Array.prototype.slice.call(arguments)))
                                            };
                                        }
                                    }
                                };
                                var i = function(e) {
                                    for (var t = 0; t < m.length; t++) o(e, m[t], false);
                                    for (var n = 0; n < g.length; n++) o(e, g[n], true);
                                };
                                n.invoked = true;
                                for (var c = function() {
                                        return this.q = [], this;
                                    }, p = ["add", "append", "clearAll", "prepend", "set", "setOnce", "unset", "preInsert", "postInsert", "remove", "getUserProperties"], l = 0; l < p.length; l++) r(c, p[l]);
                                n.Identify = c;
                                for (var d = function() {
                                        return this.q = [], this;
                                    }, f = ["getEventProperties", "setProductId", "setQuantity", "setPrice", "setRevenue", "setRevenueType", "setEventProperties"], v = 0; v < f.length; v++) r(d, f[v]);
                                n.Revenue = d;
                                var m = ["getDeviceId", "setDeviceId", "getSessionId", "setSessionId", "getUserId", "setUserId", "setOptOut", "setTransport", "reset", "extendSession"],
                                    g = ["init", "add", "remove", "track", "logEvent", "identify", "groupIdentify", "setGroup", "revenue", "flush"];
                                i(n);
                                n.createInstance = function(e) {
                                    return n.iq[e] = {
                                        q: []
                                    }, i(n.iq[e]), n.iq[e];
                                };
                                e.amplitude = n;
                            }
                        })(window, document);
                    })();
                    u.loader({
                        type: "script",
                        src: u.data.base_url.replace("##nbatag_sdk_version##", u.data.sdk_version),
                        cb: u.sdkLoaderCallback,
                        loc: "script",
                        id: "nbatag_90",
                        attrs: {}
                    });
                }
            }
            nbatag.DB("send:90:COMPLETE");
        };
        nbatag.o[loader].loader.LOAD(id);
    }("90", "nba.nba-web"));
} catch (error) {
    nbatag.DB(error);
}